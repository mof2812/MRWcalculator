/*~-1*/
/*~XSF_LANGUAGE: C/C++*/
/*~A:1*/
/*~+:Includes*/
/*~T*/
#include "Testing.h"
#include "Global.h"
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
/*~E:A1*/
/*~A:2*/
/*~+:Defines*/
/*~T*/
#define TESTING_BLOCK_START				0
#define TESTING_BLOCK_END				70
#define TESTING_CSV_MODE				1
/*~E:A2*/
/*~A:3*/
/*~+:Funktionsdeklarationen*/
/*~T*/
void 	Testing_E2Clear(unsigned char bPrepareTest);
void 	Testing_E2Dump(void);
/*~E:A3*/
/*~A:4*/
/*~+:Variablendeklarationen*/
/*~T*/

/*~E:A4*/
/*~A:5*/
/*~+:void Testing_E2Clear(unsigned char bPrepareTest)*/
/*~F:6*/
void Testing_E2Clear(unsigned char bPrepareTest)
/*~-1*/
{
   /*~A:7*/
   /*~+:Beschreibung*/
   /*~T*/
   /*!
   \fn void E2Read(unsigned int wE2Address, unsigned int wCount, void *pMemAddress)
   
   <b>Beschreibung:</b><br>
   Liest eine beliebige Anzahl von Zeichen aus dem Eeprom aus.
    
   \param
   wE2Address: Quell-Adresse im Eeprom.  
   
   \param
   wCount: Anzahl der zu lesenden Zeichen
   
   \param
   pMemAddress: Ziel-Adresse des ersten zu lesenden Zeichens.
   
   \return
   ./.
   
   <b>Zugriff:</b><br>
   [X] �ffentlich / [ ] Privat
   
   \ref
   ExamplePage_Testing "Beispiel 'Eeprom-Treiber AT24C64'"
   */
   /*~E:A7*/
   /*~A:8*/
   /*~+:Variablendeklarationen*/
   /*~T*/
   char achBuffer[] = {0x01,0x02,0x03,0x04,0x05,0x06,0x07,0x08,0x09,0x0A,0x0B,0x0C};
   /*~E:A8*/
   /*~A:9*/
   /*~+:Variableninitialisierungen*/
   /*~T*/

   /*~E:A9*/
   /*~T*/
   Ee24c64_ClearAll();
   /*~I:10*/
   if (bPrepareTest)
   /*~-1*/
   {
      /*~T*/
      /* Spezifikation I4.2.3.1.10 */
      Ee24c64_Write(536,12,achBuffer);
   /*~-1*/
   }
   /*~E:I10*/
   /*~T*/
   Testing_E2Dump();
   /*~T*/
   return;
/*~-1*/
}
/*~E:F6*/
/*~E:A5*/
/*~A:11*/
/*~+:void Testing_E2Dump(void)*/
/*~F:12*/
void Testing_E2Dump(void)
/*~-1*/
{
   /*~A:13*/
   /*~+:Beschreibung*/
   /*~T*/
   /*!
   \fn void E2Read(unsigned int wE2Address, unsigned int wCount, void *pMemAddress)
   
   <b>Beschreibung:</b><br>
   Liest eine beliebige Anzahl von Zeichen aus dem Eeprom aus.
    
   \param
   wE2Address: Quell-Adresse im Eeprom.  
   
   \param
   wCount: Anzahl der zu lesenden Zeichen
   
   \param
   pMemAddress: Ziel-Adresse des ersten zu lesenden Zeichens.
   
   \return
   ./.
   
   <b>Zugriff:</b><br>
   [X] �ffentlich / [ ] Privat
   
   \ref
   ExamplePage_Testing "Beispiel 'Eeprom-Treiber AT24C64'"
   */
   /*~E:A13*/
   /*~A:14*/
   /*~+:Variablendeklarationen*/
   /*~T*/
   unsigned char ucBuffer[16];
   unsigned char szAdr[9];
   unsigned char szString[103];
   unsigned char szCR[] = {"\r\n"};
   unsigned int uBlock;
   unsigned char i;
   /*~E:A14*/
   /*~A:15*/
   /*~+:Variableninitialisierungen*/
   /*~T*/
   szString[0] = 0;
   /*~E:A15*/
   /*~T*/
   Communication_SendRawString(COMMUNICATION_RS232, szCR);
   /*~T*/
   /* Set header */

   /*~I:16*/
#if (TESTING_CSV_MODE != 0)
   /*~L:17*/
   for (i=0;i<16;i++)
   /*~-1*/
   {
      /*~T*/
      sprintf(szString,"%s;+0x%02bX",szString,i);
   /*~-1*/
   }
   /*~E:L17*/
   /*~T*/
   Communication_SendRawString(COMMUNICATION_RS232, szString);
   Communication_SendRawString(COMMUNICATION_RS232, szCR);
   /*~O:I16*/
   /*~-1*/
#else
   /*~T*/
   strcpy(szString,"       ");
   Communication_SendRawString(COMMUNICATION_RS232, szString);
   szString[0] = 0;
   /*~L:18*/
   for (i=0;i<16;i++)
   /*~-1*/
   {
      /*~T*/
      sprintf(szString,"%s+0x%02bX ",szString,i);
   /*~-1*/
   }
   /*~E:L18*/
   /*~T*/
   Communication_SendRawString(COMMUNICATION_RS232, szString);
   Communication_SendRawString(COMMUNICATION_RS232, szCR);
   /*~T*/
   memset(szString,'-',102);
   memset(szString+102,0,1);
   /*~T*/
   Communication_SendRawString(COMMUNICATION_RS232, szString);
   //Communication_SendRawString(COMMUNICATION_RS232, szString);
   Communication_SendRawString(COMMUNICATION_RS232, szCR);
   /*~-1*/
#endif
   /*~E:I16*/
   /*~L:19*/
   for (uBlock = TESTING_BLOCK_START;uBlock < TESTING_BLOCK_END;uBlock++)
   /*~-1*/
   {
      /*~T*/
      Ee24c64_Read(uBlock*16,16,ucBuffer);
      /*~T*/
      szString[0] = 0;

      /*~I:20*/
#if (TESTING_CSV_MODE != 0)
      /*~T*/
      sprintf(szAdr,"0x%04X;",uBlock*16);
      /*~O:I20*/
      /*~-1*/
#else
      /*~T*/
      sprintf(szAdr,"0x%04X  ",uBlock*16);
      /*~-1*/
#endif
      /*~E:I20*/
      /*~L:21*/
      for (i=0;i<16;i++)
      /*~-1*/
      {
         /*~I:22*/
#if (TESTING_CSV_MODE != 0) 
         /*~I:23*/
         if (i < 15)
         /*~-1*/
         {
            /*~T*/
            sprintf(szString,"%s0x%02bX;",szString,ucBuffer[i]);
         /*~-1*/
         }
         /*~O:I23*/
         /*~-2*/
         else
         {
            /*~T*/
            sprintf(szString,"%s0x%02bX",szString,ucBuffer[i]);
         /*~-1*/
         }
         /*~E:I23*/
         /*~O:I22*/
         /*~-1*/
#else
         /*~T*/
         sprintf(szString,"%s0x%02bX  ",szString,ucBuffer[i]);
         /*~-1*/
#endif
         /*~E:I22*/
      /*~-1*/
      }
      /*~E:L21*/
      /*~T*/
      Communication_SendRawString(COMMUNICATION_RS232, szAdr);
      Communication_SendRawString(COMMUNICATION_RS232, szString);
      Communication_SendRawString(COMMUNICATION_RS232, szCR);
   /*~-1*/
   }
   /*~E:L19*/
   /*~T*/
   return;
/*~-1*/
}
/*~E:F12*/
/*~E:A11*/
