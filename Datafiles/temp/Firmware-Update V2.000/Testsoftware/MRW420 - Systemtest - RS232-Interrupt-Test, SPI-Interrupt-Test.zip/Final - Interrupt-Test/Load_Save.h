/*~-1*/
/*~XSF_LANGUAGE: C/C++*/
/*~A:1*/
/*~+:Versions-Beschreibung*/
/*~A:2*/
/*~+:Version und Versionsdatum*/
/*~T*/
/*!
\mainpage "Modul-Beschreibung"
\author Michael Offenbach
\date 09.02.2022
\version V1.002
\warning
*/
/*~E:A2*/
/*~A:3*/
/*~+:Lifecycle*/
/*~T*/
/*!\page LifeCyclePage Lifecycle

\section sec_LifeCyclePage_Load_Save_Modul 'Datenablage im Eeprom'

<table border=1 width=100% height=1% rules=rows cellspacing=0 bgcolor="#E0E0F0">

<tr align=left valign=top>
	<th>Version</th>
	<th>Datum</th>
	<th>Programmierer</th>
	<th>�nderungen</th>
</tr>

<tr>
	<td>1.001</td>
	<td>03.06.05</td>
	<td>Michael Offenbach</td>
	<td>Erste lauff�hige Version</td>
</tr>

<tr>
	<td>1.002</td>
	<td>29.11.21</td>
	<td>Michael Offenbach</td>
	<td>Funktionen zum Speichern und Laden der nichtfl�chtigen Daten 'RS232-Kommunikationssperre' und 'Versionsablage' erg�nzt.</td>
</tr>
</table>

*/
/*~E:A3*/
/*~E:A1*/
/*~I:4*/
#ifndef __LOAD_SAVE_H
/*~T*/
#define __LOAD_SAVE_H
/*~A:5*/
/*~+:Includes*/
/*~T*/
#include "load_save.def"

/*~E:A5*/
/*~A:6*/
/*~+:Definitionen*/
/*~T*/

/*~E:A6*/
/*~A:7*/
/*~+:Funktionsdeklarationen*/
/*~T*/
extern void Load_Parameter(unsigned char byWhat, void* ptrParameter, unsigned char byChars2Load);
extern char Save_Parameter(unsigned char byWhat,void* ptrParameter, unsigned char byChars2Save);
/*~E:A7*/
/*~A:8*/
/*~+:Variablen*/
/*~T*/

/*~E:A8*/
/*~-1*/
#endif
/*~E:I4*/
