/*~-1*/
/*~XSF_LANGUAGE: C/C++*/
/*~K*/
/*~+:File :        Compensation.h*/
/*~+:*/
/*~+:Version :     V1.0*/
/*~+:*/
/*~+:Date :        18.10.2005*/
/*~+:*/
/*~+:Time :        10:23*/
/*~+:*/
/*~+:Author :      MOF*/
/*~+:*/
/*~+:Hardware :*/
/*~+:*/
/*~+:Description :*/
/*~I:1*/
#ifndef __COMPENSATION_H

/*~T*/
#define __COMPENSATION_H

/*~A:2*/
/*~+:Includes*/
/*~T*/
#include "Global.h"
/*~E:A2*/
/*~A:3*/
/*~+:Definitionen*/
/*~T*/
#define COMPENSATION_STATE		g_chCompensationState
/*~E:A3*/
/*~A:4*/
/*~+:Struktur-Definitionen*/
/*~T*/

/*~E:A4*/
/*~A:5*/
/*~+:Funktionsdeklarationen*/
/*~T*/
extern void 			Compensation(void);
extern int  			Compensation_GetCompensationValue(char byTemperature);
extern void 			Compensation_Ini(unsigned char byMode);
extern void 			Compensation_PrintCompensationValues(unsigned char chWhat2Print,unsigned char chSelection,char chAddParameter,unsigned char byPrintChannelHeader);

extern char 			Compensation_SetCompensationValues(char chTemperature, int nValue2Set);
extern void 			Compensation_SuppressOutput(unsigned char bSuppress);

/*~E:A5*/
/*~A:6*/
/*~+:Variablen*/
/*~T*/
extern unsigned char	g_chCompensationState;
/*~E:A6*/
/*~-1*/
#endif
/*~E:I1*/
