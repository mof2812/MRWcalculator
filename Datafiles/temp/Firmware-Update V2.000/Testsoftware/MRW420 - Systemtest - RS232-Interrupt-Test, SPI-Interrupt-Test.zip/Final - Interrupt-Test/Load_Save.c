/*~-1*/
/*~XSF_LANGUAGE: C/C++*/
/*~K*/
/*~+:File :        Load_Save.c*/
/*~+:*/
/*~+:Version :     V1.002*/
/*~+:*/
/*~+:Date :        21.11.2021*/
/*~+:*/
/*~+:Time :        08:16*/
/*~+:*/
/*~+:Author :      MOF*/
/*~+:*/
/*~+:Hardware :*/
/*~+:*/
/*~+:Description :*/
/*~A:1*/
/*~+:Includes*/
/*~T*/
#include "Load_Save.h"
#include "Global.h"
#include <string.h>
#include <stdlib.h>
/*~K*/
/*~+:/~* Hinzugef�gt am 09.02.2022 *~/*/
/*~T*/
#include "Version.h"
/*~K*/
/*~+:/~* Ende - Hinzugef�gt am 09.02.2022 *~/*/
/*~E:A1*/
/*~A:2*/
/*~+:Funktionseigene Definitionen*/
/*~T*/

/*~E:A2*/
/*~A:3*/
/*~+:Funktionsprototypen*/
/*~T*/
void Load_Parameter(unsigned char byWhat, void* ptrParameter, unsigned char byChars2Load);
char Save_Parameter(unsigned char byWhat,void* ptrParameter, unsigned char byChars2Save);


/*~E:A3*/
/*~A:4*/
/*~+:Globale Variablen*/
/*~T*/

/*~E:A4*/
/*~A:5*/
/*~+:void Load_Parameter(unsigned char byWhat, void* ptrParameter, unsigned char byChars2Load)*/
/*~F:6*/
void Load_Parameter(unsigned char byWhat, void* ptrParameter, unsigned char byChars2Load)
/*~-1*/
{
   /*~A:7*/
   /*~+:Beschreibung*/
   /*~T*/
   /*!
   \fn void Load_Parameter(unsigned char byWhat, void* ptrParameter, unsigned char byChars2Load)
   
   <b>Beschreibung:</b><br>
   Laden von Eeprom-Eintr�gen.
   
   \param
   byWhat: Angabe �ber den auszulesenden Parameter. Vordefinierte IDs stehen in 'Load_Save.def' zur Verf�gung. 
   
   \param
   ptrParameter: Zieladresse, an die der Eeprom-Inhalt geschrieben werden soll.
   
   \param
   byChars2Load: Angabe �ber die Anzahl der auszulesenden Bytes. Die meisten Parameter haben aber bereits intern einen Vermerk auf die Datenl�nge, soda� bei diesen eine Eingabe ohne Bedeutung ist. 
   
   \return
   ./.
   
   <b>Zugriff:</b><br>
   [X] �ffentlich / [ ] Privat
   

   /*~E:A7*/
   /*~A:8*/
   /*~+:Variablendeklarationen*/
   /*~T*/
   char byRetVal;
   /*~E:A8*/
   /*~A:9*/
   /*~+:Variableninitialisierungen*/
   /*~T*/
   byRetVal = 0;
   /*~E:A9*/
   /*~C:10*/
   switch (byWhat)
   /*~-1*/
   {
      /*~A:11*/
      /*~+:Debug*/
      /*~I:12*/
#ifdef MIT_DEBUG
      /*~A:13*/
      /*~+:LOAD_SAVE_DEBUG_VARIABLES*/
      /*~F:14*/
      case LOAD_SAVE_DEBUG_VARIABLES:
      /*~-1*/
      {
         /*~T*/
         Ee24c64_Read(EEPROM_DEBUG_VARIABLES,4*DEBUG_NB_DEBUGVARIABLES,ptrParameter);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F14*/
      /*~E:A13*/
      /*~-1*/
#endif
      /*~E:I12*/
      /*~E:A11*/
      /*~A:15*/
      /*~+:Filterparameter*/
      /*~A:16*/
      /*~+:LOAD_SAVE_FILTER_DEPTH_WEIGHT*/
      /*~F:17*/
      case LOAD_SAVE_FILTER_DEPTH_WEIGHT:
      /*~-1*/
      {
         /*~T*/
         Ee24c64_Read(EEPROM_FILTER_FILTERTIEFE_GEWICHT,1,ptrParameter);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F17*/
      /*~E:A16*/
      /*~I:18*/
#ifdef CHANNEL_0
      /*~A:19*/
      /*~+:LOAD_SAVE_FILTER_DEPTH_POWERSUPPLY*/
      /*~F:20*/
      case LOAD_SAVE_FILTER_DEPTH_POWERSUPPLY:
      /*~-1*/
      {
         /*~T*/
         Ee24c64_Read(EEPROM_FILTER_FILTERTIEFE_NETZTEIL,1,ptrParameter);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F20*/
      /*~E:A19*/
      /*~-1*/
#endif
      /*~E:I18*/
      /*~I:21*/
#ifdef SYSTEM_CND_WITH_DEADBAND_FILTER
      /*~A:22*/
      /*~+:LOAD_SAVE_FILTER_BANDWIDTH_WEIGHT*/
      /*~F:23*/
      case LOAD_SAVE_FILTER_BANDWIDTH_WEIGHT:
      /*~-1*/
      {
         /*~T*/
         Ee24c64_Read(EEPROM_FILTER_BANDBREITE_GEWICHT,2,ptrParameter);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F23*/
      /*~E:A22*/
      /*~-1*/
#endif
      /*~E:I21*/
      /*~E:A15*/
      /*~A:24*/
      /*~+:Gewichtswertparameter*/
      /*~A:25*/
      /*~+:LOAD_SAVE_WEIGHT_ZERO*/
      /*~F:26*/
      case LOAD_SAVE_WEIGHT_ZERO:
      /*~-1*/
      {
         /*~T*/
         Ee24c64_Read(EEPROM_GEWICHT_NULLPUNKT,4,ptrParameter);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F26*/
      /*~E:A25*/
      /*~A:27*/
      /*~+:LOAD_SAVE_WEIGHT_OVERLOAD_LIMIT*/
      /*~F:28*/
      case LOAD_SAVE_WEIGHT_OVERLOAD_LIMIT:
      /*~-1*/
      {
         /*~T*/
         Ee24c64_Read(EEPROM_GEWICHT_UEBERLAST,4,ptrParameter);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F28*/
      /*~E:A27*/
      /*~A:29*/
      /*~+:LOAD_SAVE_WEIGHT_CALIBRATION_FACTOR*/
      /*~F:30*/
      case LOAD_SAVE_WEIGHT_CALIBRATION_FACTOR:
      /*~-1*/
      {
         /*~T*/
         Ee24c64_Read(EEPROM_GEWICHT_KALIBRIERFAKTOR,4,ptrParameter);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F30*/
      /*~E:A29*/
      /*~A:31*/
      /*~+:LOAD_SAVE_WEIGHT_MEASUREMENT_DEPTH*/
      /*~F:32*/
      case LOAD_SAVE_WEIGHT_MEASUREMENT_DEPTH:
      /*~-1*/
      {
         /*~T*/
         Ee24c64_Read(EEPROM_GEWICHT_MESSWERTTIEFE,1,ptrParameter);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F32*/
      /*~E:A31*/
      /*~A:33*/
      /*~+:LOAD_SAVE_WEIGHT_MEASUREMENT_FROM_ADC*/
      /*~F:34*/
      case LOAD_SAVE_WEIGHT_MEASUREMENT_FROM_ADC:
      /*~-1*/
      {
         /*~T*/
         Ee24c64_Read(EEPROM_GEWICHT_MESSWERT_VOM_ADC,4,ptrParameter);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F34*/
      /*~E:A33*/
      /*~A:35*/
      /*~+:LOAD_SAVE_WEIGHT_MOTIONPARAMETER*/
      /*~F:36*/
      case LOAD_SAVE_WEIGHT_MOTIONPARAMETER:
      /*~-1*/
      {
         /*~T*/
         Ee24c64_Read(EEPROM_GEWICHT_MOTIONPARAMETER,sizeof(MEASUREMENT_MOTIONPARAMETER),ptrParameter);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F36*/
      /*~E:A35*/
      /*~A:37*/
      /*~+:LOAD_SAVE_WEIGHT_TARA*/
      /*~F:38*/
      case LOAD_SAVE_WEIGHT_TARA:
      /*~-1*/
      {
         /*~T*/
         Ee24c64_Read(EEPROM_GEWICHT_TARA,4,ptrParameter);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F38*/
      /*~E:A37*/
      /*~A:39*/
      /*~+:LOAD_SAVE_WEIGHT_UNIT*/
      /*~F:40*/
      case LOAD_SAVE_WEIGHT_UNIT:
      /*~-1*/
      {
         /*~T*/
         Ee24c64_Read(EEPROM_GEWICHT_UNIT,1,ptrParameter);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F40*/
      /*~E:A39*/
      /*~E:A24*/
      /*~A:41*/
      /*~+:Grenzwertparameter*/
      /*~F:42*/
      case LOAD_SAVE_LIMIT_ZEROPOINTCHECK:
      /*~-1*/
      {
         /*~T*/
         Ee24c64_Read(EEPROM_LIMIT_NULLPUNKTCHECK,4,ptrParameter);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F42*/
      /*~E:A41*/
      /*~A:43*/
      /*~+:Kommunikation*/
      /*~A:44*/
      /*~+:LOAD_SAVE_RS232_BAUDRATE*/
      /*~F:45*/
      case LOAD_SAVE_RS232_BAUDRATE:
      /*~-1*/
      {
         /*~T*/
         Ee24c64_Read(EEPROM_RS232_BAUDRATE,4,ptrParameter);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F45*/
      /*~E:A44*/
      /*~A:46*/
      /*~+:LOAD_SAVE_SPI_FAULT_COUNTER*/
      /*~F:47*/
      case LOAD_SAVE_SPI_FAULT_COUNTER:
      /*~-1*/
      {
         /*~T*/
         Ee24c64_Read(EEPROM_SPI_FAULT_COUNTER,1,ptrParameter);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F47*/
      /*~E:A46*/
      /*~A:48*/
      /*~+:LOAD_SAVE_FLAG_DONOT_RESET*/
      /*~F:49*/
      case LOAD_SAVE_FLAG_DONOT_RESET:
      /*~-1*/
      {
         /*~T*/
         Ee24c64_Read(EEPROM_FLAG_DONT_RESET,1,ptrParameter);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F49*/
      /*~E:A48*/
      /*~K*/
      /*~+:/~* Ge�ndert am 09.02.2022 *~/*/
      /*~A:50*/
      /*~+:LOAD_SAVE_RS232_DISABLE_CODE*/
      /*~F:51*/
      case LOAD_SAVE_RS232_DISABLE_CODE:
      /*~-1*/
      {
         /*~T*/
         Ee24c64_Read(EEPROM_RS232_DISABLE_CODE,4,ptrParameter);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F51*/
      /*~E:A50*/
      /*~K*/
      /*~+:/~* Ende - Ge�ndert am 09.02.2022 *~/*/
      /*~E:A43*/
      /*~A:52*/
      /*~+:Messwertparameter*/
      /*~A:53*/
      /*~+:LOAD_SAVE_MEASUREMENT_FILTER*/
      /*~F:54*/
      case LOAD_SAVE_MEASUREMENT_FILTER:
      /*~-1*/
      {
         /*~T*/
         Ee24c64_Read(EEPROM_MESSWERT_FILTERTIEFE,1,ptrParameter);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F54*/
      /*~E:A53*/
      /*~A:55*/
      /*~+:LOAD_SAVE_MEASUREMENT_CONVERSIONRATE*/
      /*~F:56*/
      case LOAD_SAVE_MEASUREMENT_CONVERSIONRATE:
      /*~-1*/
      {
         /*~T*/
         Ee24c64_Read(EEPROM_MESSWERT_CONVERSIONRATE,4,ptrParameter);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F56*/
      /*~E:A55*/
      /*~E:A52*/
      /*~A:57*/
      /*~+:Sonstige Parameter*/
      /*~A:58*/
      /*~+:LOAD_SAVE_ARTICLENUMBER*/
      /*~F:59*/
      case LOAD_SAVE_ARTICLENUMBER:
      /*~-1*/
      {
         /*~T*/
         Ee24c64_Read(EEPROM_ARTICLENUMBER,11,ptrParameter);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F59*/
      /*~E:A58*/
      /*~A:60*/
      /*~+:LOAD_SAVE_CELLTYPE*/
      /*~F:61*/
      case LOAD_SAVE_CELLTYPE:
      /*~-1*/
      {
         /*~T*/
         Ee24c64_Read(EEPROM_CELLTYPE,1,ptrParameter);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F61*/
      /*~E:A60*/
      /*~A:62*/
      /*~+:LOAD_SAVE_CHECK_EEWRITE*/
      /*~F:63*/
      case LOAD_SAVE_CHECK_EEWRITE:
      /*~-1*/
      {
         /*~T*/
         Ee24c64_Read(EEPROM_CHECK_EEWRITE,1,ptrParameter);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F63*/
      /*~E:A62*/
      /*~A:64*/
      /*~+:LOAD_SAVE_E_MODUL_COMPENSATION_ONOFF*/
      /*~F:65*/
      case LOAD_SAVE_E_MODUL_COMPENSATION_ONOFF:
      /*~-1*/
      {
         /*~T*/
         Ee24c64_Read(EEPROM_E_MODUL_COMPENSATION_ONOFF,1,ptrParameter);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F65*/
      /*~E:A64*/
      /*~A:66*/
      /*~+:LOAD_SAVE_INITIALIZE_IDENTIFICATION*/
      /*~F:67*/
      case LOAD_SAVE_INITIALIZE_IDENTIFICATION:
      /*~-1*/
      {
         /*~T*/
         Ee24c64_Read(EEPROM_KENNUNG_EEPROM,4,ptrParameter);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F67*/
      /*~E:A66*/
      /*~A:68*/
      /*~+:LOAD_SAVE_OPERATING_HOURS_INITCODE*/
      /*~F:69*/
      case LOAD_SAVE_OPERATING_HOURS_INITCODE:
      /*~-1*/
      {
         /*~T*/
         Ee24c64_Read(EEPROM_OPERATING_HOURS_INITCODE,4,ptrParameter);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F69*/
      /*~E:A68*/
      /*~A:70*/
      /*~+:LOAD_SAVE_OPERATING_HOURS*/
      /*~F:71*/
      case LOAD_SAVE_OPERATING_HOURS:
      /*~-1*/
      {
         /*~T*/
         Ee24c64_Read(EEPROM_OPERATING_HOURS,4,ptrParameter);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F71*/
      /*~E:A70*/
      /*~A:72*/
      /*~+:LOAD_SAVE_OPERATING_HOURS_2*/
      /*~F:73*/
      case LOAD_SAVE_OPERATING_HOURS_2:
      /*~-1*/
      {
         /*~T*/
         Ee24c64_Read(EEPROM_OPERATING_HOURS_2,4,ptrParameter);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F73*/
      /*~E:A72*/
      /*~A:74*/
      /*~+:LOAD_SAVE_SERIALNUMBER*/
      /*~F:75*/
      case LOAD_SAVE_SERIALNUMBER:
      /*~-1*/
      {
         /*~T*/
         Ee24c64_Read(EEPROM_SERIALNUMBER,13,ptrParameter);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F75*/
      /*~E:A74*/
      /*~A:76*/
      /*~+:LOAD_SAVE_SYSTEM_ID*/
      /*~F:77*/
      case LOAD_SAVE_SYSTEM_ID:
      /*~-1*/
      {
         /*~T*/
         Ee24c64_Read(EEPROM_SYSTEM_ID,4,ptrParameter);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F77*/
      /*~E:A76*/
      /*~A:78*/
      /*~+:LOAD_SAVE_TEMPERATURE_OFFSET*/
      /*~F:79*/
      case LOAD_SAVE_TEMPERATURE_OFFSET:
      /*~-1*/
      {
         /*~T*/
         Ee24c64_Read(EEPROM_TEMPERATURE_OFFSET,1,ptrParameter);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F79*/
      /*~E:A78*/
      /*~K*/
      /*~+:/~* Hinzugef�gt am 09.02.2022 *~/*/
      /*~A:80*/
      /*~+:LOAD_SAVE_VERSION*/
      /*~F:81*/
      case LOAD_SAVE_VERSION:
      /*~-1*/
      {
         /*~I:82*/
         if (ptrParameter != 0)
         /*~-1*/
         {
            /*~T*/
            Ee24c64_Read(EEPROM_VERSION,4,ptrParameter);
            /*~I:83*/
            if (*(unsigned long*)ptrParameter == 0xFFFFFFFF)	// falls nur FFs im Eeprom stehen
            /*~-1*/
            {
               /*~T*/
               *(unsigned long*)ptrParameter = 0L;
            /*~-1*/
            }
            /*~E:I83*/
         /*~-1*/
         }
         /*~E:I82*/
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F81*/
      /*~E:A80*/
      /*~K*/
      /*~+:/~* Ende - Hinzugef�gt am 09.02.2022 *~/*/
      /*~A:84*/
      /*~+:LOAD_SAVE_WATCHDOG_ADDRESS*/
      /*~F:85*/
      case LOAD_SAVE_WATCHDOG_ADDRESS:
      /*~-1*/
      {
         /*~T*/
         Ee24c64_Read(EEPROM_WATCHDOG_ADDRESS,2,ptrParameter);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F85*/
      /*~E:A84*/
      /*~E:A57*/
      /*~A:86*/
      /*~+:Statistik*/
      /*~A:87*/
      /*~+:LOAD_SAVE_STATISTICS_MAXCURRENT_CH0*/
      /*~F:88*/
      case LOAD_SAVE_STATISTICS_MAXCURRENT_CH0:
      /*~-1*/
      {
         /*~T*/
         Ee24c64_Read(EEPROM_STATISTICS_MAXCURRENT_CH0,4,ptrParameter);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F88*/
      /*~E:A87*/
      /*~A:89*/
      /*~+:LOAD_SAVE_STATISTICS_MAXCURRENT_CH1*/
      /*~F:90*/
      case LOAD_SAVE_STATISTICS_MAXCURRENT_CH1:
      /*~-1*/
      {
         /*~T*/
         Ee24c64_Read(EEPROM_STATISTICS_MAXCURRENT_CH1,4,ptrParameter);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F90*/
      /*~E:A89*/
      /*~A:91*/
      /*~+:LOAD_SAVE_STATISTICS_MAXRMW_CH0*/
      /*~F:92*/
      case LOAD_SAVE_STATISTICS_MAXRMW_CH0:
      /*~-1*/
      {
         /*~T*/
         Ee24c64_Read(EEPROM_STATISTICS_MAXRMW_CH0,4,ptrParameter);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F92*/
      /*~E:A91*/
      /*~A:93*/
      /*~+:LOAD_SAVE_STATISTICS_MAXRMW_CH1*/
      /*~F:94*/
      case LOAD_SAVE_STATISTICS_MAXRMW_CH1:
      /*~-1*/
      {
         /*~T*/
         Ee24c64_Read(EEPROM_STATISTICS_MAXRMW_CH1,4,ptrParameter);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F94*/
      /*~E:A93*/
      /*~A:95*/
      /*~+:LOAD_SAVE_STATISTICS_MAXTEMP_CH0*/
      /*~F:96*/
      case LOAD_SAVE_STATISTICS_MAXTEMP_CH0:
      /*~-1*/
      {
         /*~T*/
         Ee24c64_Read(EEPROM_STATISTICS_MAXTEMP_CH0,1,ptrParameter);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F96*/
      /*~E:A95*/
      /*~A:97*/
      /*~+:LOAD_SAVE_STATISTICS_MAXTEMP_CH1*/
      /*~F:98*/
      case LOAD_SAVE_STATISTICS_MAXTEMP_CH1:
      /*~-1*/
      {
         /*~T*/
         Ee24c64_Read(EEPROM_STATISTICS_MAXTEMP_CH1,1,ptrParameter);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F98*/
      /*~E:A97*/
      /*~A:99*/
      /*~+:LOAD_SAVE_STATISTICS_MAXWEIGHT_CH0*/
      /*~F:100*/
      case LOAD_SAVE_STATISTICS_MAXWEIGHT_CH0:
      /*~-1*/
      {
         /*~T*/
         Ee24c64_Read(EEPROM_STATISTICS_MAXWEIGHT_CH0,4,ptrParameter);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F100*/
      /*~E:A99*/
      /*~A:101*/
      /*~+:LOAD_SAVE_STATISTICS_MAXWEIGHT_CH1*/
      /*~F:102*/
      case LOAD_SAVE_STATISTICS_MAXWEIGHT_CH1:
      /*~-1*/
      {
         /*~T*/
         Ee24c64_Read(EEPROM_STATISTICS_MAXWEIGHT_CH1,4,ptrParameter);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F102*/
      /*~E:A101*/
      /*~A:103*/
      /*~+:LOAD_SAVE_STATISTICS_MINTEMP_CH0*/
      /*~F:104*/
      case LOAD_SAVE_STATISTICS_MINTEMP_CH0:
      /*~-1*/
      {
         /*~T*/
         Ee24c64_Read(EEPROM_STATISTICS_MINTEMP_CH0,1,ptrParameter);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F104*/
      /*~E:A103*/
      /*~A:105*/
      /*~+:LOAD_SAVE_STATISTICS_MINTEMP_CH1*/
      /*~F:106*/
      case LOAD_SAVE_STATISTICS_MINTEMP_CH1:
      /*~-1*/
      {
         /*~T*/
         Ee24c64_Read(EEPROM_STATISTICS_MINTEMP_CH1,1,ptrParameter);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F106*/
      /*~E:A105*/
      /*~A:107*/
      /*~+:LOAD_SAVE_STATISTICS_NBOVERLIMITS_CH0*/
      /*~F:108*/
      case LOAD_SAVE_STATISTICS_NBOVERLIMITS_CH0:
      /*~-1*/
      {
         /*~T*/
         Ee24c64_Read(EEPROM_STATISTICS_NBOVERLIMITS_CH0,2,ptrParameter);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F108*/
      /*~E:A107*/
      /*~A:109*/
      /*~+:LOAD_SAVE_STATISTICS_NBOVERLIMITS_CH1*/
      /*~F:110*/
      case LOAD_SAVE_STATISTICS_NBOVERLIMITS_CH1:
      /*~-1*/
      {
         /*~T*/
         Ee24c64_Read(EEPROM_STATISTICS_NBOVERLIMITS_CH1,2,ptrParameter);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F110*/
      /*~E:A109*/
      /*~A:111*/
      /*~+:LOAD_SAVE_STATISTICS_NBOVERLOADS_CH0*/
      /*~F:112*/
      case LOAD_SAVE_STATISTICS_NBOVERLOADS_CH0:
      /*~-1*/
      {
         /*~T*/
         Ee24c64_Read(EEPROM_STATISTICS_NBOVERLOADS_CH0,2,ptrParameter);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F112*/
      /*~E:A111*/
      /*~A:113*/
      /*~+:LOAD_SAVE_STATISTICS_NBOVERLOADS_CH1*/
      /*~F:114*/
      case LOAD_SAVE_STATISTICS_NBOVERLOADS_CH1:
      /*~-1*/
      {
         /*~T*/
         Ee24c64_Read(EEPROM_STATISTICS_NBOVERLOADS_CH1,2,ptrParameter);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F114*/
      /*~E:A113*/
      /*~A:115*/
      /*~+:LOAD_SAVE_STATISTICS_SETUP*/
      /*~F:116*/
      case LOAD_SAVE_STATISTICS_SETUP:
      /*~-1*/
      {
         /*~T*/
         Ee24c64_Read(EEPROM_STATISTICS_SETUP,byChars2Load,ptrParameter);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F116*/
      /*~E:A115*/
      /*~A:117*/
      /*~+:LOAD_SAVE_STATISTICS_TIMEMAXWEIGHT_CH0*/
      /*~F:118*/
      case LOAD_SAVE_STATISTICS_TIMEMAXWEIGHT_CH0:
      /*~-1*/
      {
         /*~T*/
         Ee24c64_Read(EEPROM_STATISTICS_TIMEMAXWEIGHT_CH0,4,ptrParameter);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F118*/
      /*~E:A117*/
      /*~A:119*/
      /*~+:LOAD_SAVE_STATISTICS_TIMEMAXWEIGHT_CH1*/
      /*~F:120*/
      case LOAD_SAVE_STATISTICS_TIMEMAXWEIGHT_CH1:
      /*~-1*/
      {
         /*~T*/
         Ee24c64_Read(EEPROM_STATISTICS_TIMEMAXWEIGHT_CH1,4,ptrParameter);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F120*/
      /*~E:A119*/
      /*~E:A86*/
      /*~A:121*/
      /*~+:Stromschnittstelle*/
      /*~A:122*/
      /*~+:LOAD_SAVE_DAC_COPY_CALIBRATION*/
      /*~F:123*/
      case LOAD_SAVE_DAC_COPY_CALIBRATION:
      /*~-1*/
      {
         /*~T*/
         Ee24c64_Read(EEPROM_DAC_COPY_CALIBRATION,byChars2Load,ptrParameter);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F123*/
      /*~E:A122*/
      /*~A:124*/
      /*~+:LOAD_SAVE_DAC_GAIN_FEEDBACK*/
      /*~F:125*/
      case LOAD_SAVE_DAC_GAIN_FEEDBACK:
      /*~-1*/
      {
         /*~T*/
         Ee24c64_Read(EEPROM_DAC_FEEDBACK_GAIN,4,ptrParameter);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F125*/
      /*~E:A124*/
      /*~A:126*/
      /*~+:LOAD_SAVE_DAC_OFFSET_FEEDBACK*/
      /*~F:127*/
      case LOAD_SAVE_DAC_OFFSET_FEEDBACK:
      /*~-1*/
      {
         /*~T*/
         Ee24c64_Read(EEPROM_DAC_FEEDBACK_OFFSET,4,ptrParameter);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F127*/
      /*~E:A126*/
      /*~A:128*/
      /*~+:LOAD_SAVE_DAC_RMW_1ST_REFPOINT*/
      /*~F:129*/
      case LOAD_SAVE_DAC_RMW_1ST_REFPOINT:
      /*~-1*/
      {
         /*~T*/
         Ee24c64_Read(EEPROM_DAC_RMW_1ST_REFPOINT,4,ptrParameter);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F129*/
      /*~E:A128*/
      /*~A:130*/
      /*~+:LOAD_SAVE_DAC_RMW_2ND_REFPOINT*/
      /*~F:131*/
      case LOAD_SAVE_DAC_RMW_2ND_REFPOINT:
      /*~-1*/
      {
         /*~T*/
         Ee24c64_Read(EEPROM_DAC_RMW_2ND_REFPOINT,4,ptrParameter);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F131*/
      /*~E:A130*/
      /*~A:132*/
      /*~+:LOAD_SAVE_DAC_SETTINGS*/
      /*~F:133*/
      case LOAD_SAVE_DAC_SETTINGS:
      /*~-1*/
      {
         /*~T*/
         Ee24c64_Read(EEPROM_DAC_SETTINGS,sizeof(DAC_SETTINGS),ptrParameter);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F133*/
      /*~E:A132*/
      /*~A:134*/
      /*~+:LOAD_SAVE_CURRENTINTERFACE_MAXDEVIATION*/
      /*~F:135*/
      case LOAD_SAVE_CURRENTINTERFACE_MAXDEVIATION:
      /*~-1*/
      {
         /*~T*/
         Ee24c64_Read(EEPROM_DAC_MAXDEVIATION,4,ptrParameter);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F135*/
      /*~E:A134*/
      /*~A:136*/
      /*~+:LOAD_SAVE_INTEGRALPORTION_FEEDBACK*/
      /*~F:137*/
      case LOAD_SAVE_INTEGRALPORTION_FEEDBACK :
      /*~-1*/
      {
         /*~T*/
         Ee24c64_Read(EEPROM_DAC_FEEDBACK_INTEGRALPORTION,1,ptrParameter);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F137*/
      /*~E:A136*/
      /*~A:138*/
      /*~+:LOAD_SAVE_MEASUREMENT_DEPTH_FEEDBACK*/
      /*~F:139*/
      case LOAD_SAVE_MEASUREMENT_DEPTH_FEEDBACK :
      /*~-1*/
      {
         /*~T*/
         Ee24c64_Read(EEPROM_DAC_FEEDBACK_MEASUREMENTDEPTH,1,ptrParameter);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F139*/
      /*~E:A138*/
      /*~A:140*/
      /*~+:LOAD_SAVE_CURRENTINTERFACE_TIME_HYSTERESIS*/
      /*~F:141*/
      case LOAD_SAVE_CURRENTINTERFACE_TIME_HYSTERESIS:
      /*~-1*/
      {
         /*~T*/
         Ee24c64_Read(EEPROM_DAC_TIME_HYSTERESIS,2,ptrParameter);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F141*/
      /*~E:A140*/
      /*~A:142*/
      /*~+:LOAD_SAVE_PROPORTIONAL_FEEDBACK*/
      /*~F:143*/
      case LOAD_SAVE_PROPORTIONALPORTION_FEEDBACK :
      /*~-1*/
      {
         /*~T*/
         Ee24c64_Read(EEPROM_DAC_FEEDBACK_PROPORTIONALPORTION,1,ptrParameter);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F143*/
      /*~E:A142*/
      /*~E:A121*/
      /*~A:144*/
      /*~+:Temperaturkompensation*/
      /*~A:145*/
      /*~+:LOAD_SAVE_COMPENSATION*/
      /*~F:146*/
      case LOAD_SAVE_COMPENSATION:
      /*~-1*/
      {
         /*~T*/
         Ee24c64_Read(EEPROM_COMPENSATION,byChars2Load,ptrParameter);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F146*/
      /*~E:A145*/
      /*~A:147*/
      /*~+:LOAD_SAVE_COMPENSATIONLIMITS*/
      /*~F:148*/
      case LOAD_SAVE_COMPENSATIONLIMITS:
      /*~-1*/
      {
         /*~T*/
         Ee24c64_Read(EEPROM_COMPENSATIONLIMITS,byChars2Load,ptrParameter);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F148*/
      /*~E:A147*/
      /*~E:A144*/
   /*~-1*/
   }
   /*~E:C10*/
/*~-1*/
}
/*~E:F6*/
/*~E:A5*/
/*~A:149*/
/*~+:char Save_Parameter(unsigned char byWhat, void* ptrParameter, unsigned char byChars2Save)*/
/*~F:150*/
char Save_Parameter(unsigned char byWhat,void* ptrParameter, unsigned char byChars2Save)
/*~-1*/
{
   /*~A:151*/
   /*~+:Beschreibung*/
   /*~T*/
   /*!
   \fn char Save_Parameter(unsigned char byWhat,void* ptrParameter, unsigned char byChars2Save)
   
   <b>Beschreibung:</b><br>
   Speichern von Daten in den Eeprom-Speicher.
   
   \param
   byWhat: Angabe �ber den zu schreibenden Parameter. Vordefinierte IDs stehen in 'Load_Save.def' zur Verf�gung. 
   
   \param
   ptrParameter: Quelladresse, die die zu schreibenden Daten enth�lt.
   
   \param
   byChars2Save: Angabe �ber die Anzahl der zu schreibenden Bytes. Die meisten Parameter haben aber bereits intern einen Vermerk auf die Datenl�nge, soda� bei diesen eine Eingabe ohne Bedeutung ist. 
   
   \return
   Status der Funktionsausf�hrung
   
   \retval
   0: Alles okay
   
   \retval
   1: Datum fehlerhaft eingetragen
   
   <b>Zugriff:</b><br>
   [X] �ffentlich / [ ] Privat
   

   /*~E:A151*/
   /*~A:152*/
   /*~+:Variablendeklarationen*/
   /*~T*/
   char byRetVal;
   /*~E:A152*/
   /*~A:153*/
   /*~+:Variableninitialisierungen*/
   /*~T*/
   byRetVal = 0;
   /*~E:A153*/
   /*~C:154*/
   switch (byWhat)
   /*~-1*/
   {
      /*~A:155*/
      /*~+:Debug*/
      /*~I:156*/
#ifdef MIT_DEBUG
      /*~A:157*/
      /*~+:LOAD_SAVE_DEBUG_VARIABLES*/
      /*~F:158*/
      case LOAD_SAVE_DEBUG_VARIABLES:
      /*~-1*/
      {
         /*~T*/
         byRetVal = Ee24c64_Write(EEPROM_DEBUG_VARIABLES,4*DEBUG_NB_DEBUGVARIABLES,ptrParameter);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F158*/
      /*~E:A157*/
      /*~-1*/
#endif
      /*~E:I156*/
      /*~E:A155*/
      /*~A:159*/
      /*~+:Filterparameter*/
      /*~A:160*/
      /*~+:LOAD_SAVE_FILTER_DEPTH_WEIGHT*/
      /*~F:161*/
      case LOAD_SAVE_FILTER_DEPTH_WEIGHT:
      /*~-1*/
      {
         /*~T*/
         byRetVal = Ee24c64_Write(EEPROM_FILTER_FILTERTIEFE_GEWICHT,1,ptrParameter);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F161*/
      /*~E:A160*/
      /*~I:162*/
#ifdef CHANNEL_0
      /*~A:163*/
      /*~+:LOAD_SAVE_FILTER_DEPTH_POWERSUPPLY*/
      /*~F:164*/
      case LOAD_SAVE_FILTER_DEPTH_POWERSUPPLY:
      /*~-1*/
      {
         /*~T*/
         byRetVal = Ee24c64_Write(EEPROM_FILTER_FILTERTIEFE_NETZTEIL,1,ptrParameter);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F164*/
      /*~E:A163*/
      /*~-1*/
#endif
      /*~E:I162*/
      /*~I:165*/
#ifdef SYSTEM_CND_WITH_DEADBAND_FILTER
      /*~A:166*/
      /*~+:LOAD_SAVE_FILTER_BANDWIDTH_WEIGHT*/
      /*~F:167*/
      case LOAD_SAVE_FILTER_BANDWIDTH_WEIGHT:
      /*~-1*/
      {
         /*~T*/
         /*#LJ:0=12*/
         byRetVal = Ee24c64_Write(EEPROM_FILTER_BANDBREITE_GEWICHT,2,ptrParameter);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F167*/
      /*~E:A166*/
      /*~-1*/
#endif
      /*~E:I165*/
      /*~E:A159*/
      /*~A:168*/
      /*~+:Gewichtswertparameter*/
      /*~A:169*/
      /*~+:LOAD_SAVE_WEIGHT_ZERO*/
      /*~F:170*/
      case LOAD_SAVE_WEIGHT_ZERO:
      /*~-1*/
      {
         /*~T*/
         byRetVal = Ee24c64_Write(EEPROM_GEWICHT_NULLPUNKT,4,ptrParameter);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F170*/
      /*~E:A169*/
      /*~A:171*/
      /*~+:LOAD_SAVE_WEIGHT_OVERLOAD_LIMIT*/
      /*~F:172*/
      case LOAD_SAVE_WEIGHT_OVERLOAD_LIMIT:
      /*~-1*/
      {
         /*~T*/
         byRetVal = Ee24c64_Write(EEPROM_GEWICHT_UEBERLAST,4,ptrParameter);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F172*/
      /*~E:A171*/
      /*~A:173*/
      /*~+:LOAD_SAVE_WEIGHT_CALIBRATION_FACTOR*/
      /*~F:174*/
      case LOAD_SAVE_WEIGHT_CALIBRATION_FACTOR:
      /*~-1*/
      {
         /*~T*/
         byRetVal = Ee24c64_Write(EEPROM_GEWICHT_KALIBRIERFAKTOR,4,ptrParameter);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F174*/
      /*~E:A173*/
      /*~A:175*/
      /*~+:LOAD_SAVE_WEIGHT_MEASUREMENT_DEPTH*/
      /*~F:176*/
      case LOAD_SAVE_WEIGHT_MEASUREMENT_DEPTH:
      /*~-1*/
      {
         /*~T*/
         byRetVal = Ee24c64_Write(EEPROM_GEWICHT_MESSWERTTIEFE,1,ptrParameter);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F176*/
      /*~E:A175*/
      /*~A:177*/
      /*~+:LOAD_SAVE_WEIGHT_MEASUREMENT_FROM_ADC*/
      /*~F:178*/
      case LOAD_SAVE_WEIGHT_MEASUREMENT_FROM_ADC:
      /*~-1*/
      {
         /*~T*/
         byRetVal = Ee24c64_Write(EEPROM_GEWICHT_MESSWERT_VOM_ADC,4,ptrParameter);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F178*/
      /*~E:A177*/
      /*~A:179*/
      /*~+:LOAD_SAVE_WEIGHT_MOTIONPARAMETER*/
      /*~F:180*/
      case LOAD_SAVE_WEIGHT_MOTIONPARAMETER:
      /*~-1*/
      {
         /*~T*/
         byRetVal = Ee24c64_Write(EEPROM_GEWICHT_MOTIONPARAMETER,sizeof(MEASUREMENT_MOTIONPARAMETER),ptrParameter);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F180*/
      /*~E:A179*/
      /*~A:181*/
      /*~+:LOAD_SAVE_WEIGHT_TARA*/
      /*~F:182*/
      case LOAD_SAVE_WEIGHT_TARA:
      /*~-1*/
      {
         /*~T*/
         byRetVal = Ee24c64_Write(EEPROM_GEWICHT_TARA,4,ptrParameter);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F182*/
      /*~E:A181*/
      /*~A:183*/
      /*~+:LOAD_SAVE_WEIGHT_UNIT*/
      /*~F:184*/
      case LOAD_SAVE_WEIGHT_UNIT:
      /*~-1*/
      {
         /*~T*/
         byRetVal = Ee24c64_Write(EEPROM_GEWICHT_UNIT,1,ptrParameter);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F184*/
      /*~E:A183*/
      /*~E:A168*/
      /*~A:185*/
      /*~+:Kommunikation*/
      /*~A:186*/
      /*~+:LOAD_SAVE_RS232_BAUDRATE*/
      /*~F:187*/
      case LOAD_SAVE_RS232_BAUDRATE:
      /*~-1*/
      {
         /*~T*/
         byRetVal = Ee24c64_Write(EEPROM_RS232_BAUDRATE,4,ptrParameter);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F187*/
      /*~E:A186*/
      /*~A:188*/
      /*~+:LOAD_SAVE_SPI_FAULT_COUNTER*/
      /*~F:189*/
      case LOAD_SAVE_SPI_FAULT_COUNTER:
      /*~-1*/
      {
         /*~T*/
         byRetVal = Ee24c64_Write(EEPROM_SPI_FAULT_COUNTER,1,ptrParameter);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F189*/
      /*~E:A188*/
      /*~A:190*/
      /*~+:LOAD_SAVE_FLAG_DONOT_RESET*/
      /*~F:191*/
      case LOAD_SAVE_FLAG_DONOT_RESET:
      /*~-1*/
      {
         /*~T*/
         byRetVal = Ee24c64_Write(EEPROM_FLAG_DONT_RESET,1,ptrParameter);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F191*/
      /*~E:A190*/
      /*~K*/
      /*~+:/~* Ge�ndert am 09.02.2022 *~/*/
      /*~A:192*/
      /*~+:LOAD_SAVE_RS232_DISABLE_CODE*/
      /*~F:193*/
      case LOAD_SAVE_RS232_DISABLE_CODE:
      /*~-1*/
      {
         /*~T*/
         byRetVal = Ee24c64_Write(EEPROM_RS232_DISABLE_CODE,4,ptrParameter);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F193*/
      /*~E:A192*/
      /*~K*/
      /*~+:/~* Ende - Ge�ndert am 09.02.2022 *~/*/
      /*~E:A185*/
      /*~A:194*/
      /*~+:Grenzwertparameter*/
      /*~F:195*/
      case LOAD_SAVE_LIMIT_ZEROPOINTCHECK:
      /*~-1*/
      {
         /*~T*/
         byRetVal = Ee24c64_Write(EEPROM_LIMIT_NULLPUNKTCHECK,4,ptrParameter);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F195*/
      /*~E:A194*/
      /*~A:196*/
      /*~+:Messwertparameter*/
      /*~A:197*/
      /*~+:LOAD_SAVE_MEASUREMENT_FILTER*/
      /*~F:198*/
      case LOAD_SAVE_MEASUREMENT_FILTER:
      /*~-1*/
      {
         /*~T*/
         byRetVal = Ee24c64_Write(EEPROM_MESSWERT_FILTERTIEFE,1,ptrParameter);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F198*/
      /*~E:A197*/
      /*~A:199*/
      /*~+:LOAD_SAVE_MEASUREMENT_CONVERSIONRATE*/
      /*~F:200*/
      case LOAD_SAVE_MEASUREMENT_CONVERSIONRATE:
      /*~-1*/
      {
         /*~T*/
         byRetVal = Ee24c64_Write(EEPROM_MESSWERT_CONVERSIONRATE,4,ptrParameter);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F200*/
      /*~E:A199*/
      /*~E:A196*/
      /*~A:201*/
      /*~+:Sonstige Parameter*/
      /*~A:202*/
      /*~+:LOAD_SAVE_ARTICLENUMBER*/
      /*~F:203*/
      case LOAD_SAVE_ARTICLENUMBER:
      /*~-1*/
      {
         /*~T*/
         byRetVal = Ee24c64_Write(EEPROM_ARTICLENUMBER,11,ptrParameter);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F203*/
      /*~E:A202*/
      /*~A:204*/
      /*~+:LOAD_SAVE_CELLTYPE*/
      /*~F:205*/
      case LOAD_SAVE_CELLTYPE:
      /*~-1*/
      {
         /*~T*/
         byRetVal = Ee24c64_Write(EEPROM_CELLTYPE,1,ptrParameter);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F205*/
      /*~E:A204*/
      /*~A:206*/
      /*~+:LOAD_SAVE_CHECK_EEWRITE*/
      /*~F:207*/
      case LOAD_SAVE_CHECK_EEWRITE:
      /*~-1*/
      {
         /*~T*/
         byRetVal = Ee24c64_Write(EEPROM_CHECK_EEWRITE,1,ptrParameter);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F207*/
      /*~E:A206*/
      /*~A:208*/
      /*~+:LOAD_SAVE_E_MODUL_COMPENSATION_ONOFF*/
      /*~F:209*/
      case LOAD_SAVE_E_MODUL_COMPENSATION_ONOFF:
      /*~-1*/
      {
         /*~T*/
         byRetVal = Ee24c64_Write(EEPROM_E_MODUL_COMPENSATION_ONOFF,1,ptrParameter);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F209*/
      /*~E:A208*/
      /*~A:210*/
      /*~+:LOAD_SAVE_INITIALIZE_IDENTIFICATION*/
      /*~F:211*/
      case LOAD_SAVE_INITIALIZE_IDENTIFICATION:
      /*~-1*/
      {
         /*~T*/
         byRetVal = Ee24c64_Write(EEPROM_KENNUNG_EEPROM,4,ptrParameter);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F211*/
      /*~E:A210*/
      /*~A:212*/
      /*~+:LOAD_SAVE_OPERATING_HOURS*/
      /*~F:213*/
      case LOAD_SAVE_OPERATING_HOURS:
      /*~-1*/
      {
         /*~T*/
         byRetVal = Ee24c64_Write(EEPROM_OPERATING_HOURS,4,ptrParameter);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F213*/
      /*~E:A212*/
      /*~A:214*/
      /*~+:LOAD_SAVE_OPERATING_HOURS_2*/
      /*~F:215*/
      case LOAD_SAVE_OPERATING_HOURS_2:
      /*~-1*/
      {
         /*~T*/
         byRetVal = Ee24c64_Write(EEPROM_OPERATING_HOURS_2,4,ptrParameter);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F215*/
      /*~E:A214*/
      /*~A:216*/
      /*~+:LOAD_SAVE_OPERATING_HOURS_INITCODE*/
      /*~F:217*/
      case LOAD_SAVE_OPERATING_HOURS_INITCODE:
      /*~-1*/
      {
         /*~T*/
         byRetVal = Ee24c64_Write(EEPROM_OPERATING_HOURS_INITCODE,4,ptrParameter);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F217*/
      /*~E:A216*/
      /*~A:218*/
      /*~+:LOAD_SAVE_SERIALNUMBER*/
      /*~F:219*/
      case LOAD_SAVE_SERIALNUMBER:
      /*~-1*/
      {
         /*~T*/
         byRetVal = Ee24c64_Write(EEPROM_SERIALNUMBER,13,ptrParameter);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F219*/
      /*~E:A218*/
      /*~A:220*/
      /*~+:LOAD_SAVE_SYSTEM_ID*/
      /*~F:221*/
      case LOAD_SAVE_SYSTEM_ID:
      /*~-1*/
      {
         /*~T*/
         byRetVal = Ee24c64_Write(EEPROM_SYSTEM_ID,4,ptrParameter);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F221*/
      /*~E:A220*/
      /*~A:222*/
      /*~+:LOAD_SAVE_TEMPERATURE_OFFSET*/
      /*~F:223*/
      case LOAD_SAVE_TEMPERATURE_OFFSET:
      /*~-1*/
      {
         /*~T*/
         byRetVal = Ee24c64_Write(EEPROM_TEMPERATURE_OFFSET,1,ptrParameter);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F223*/
      /*~E:A222*/
      /*~K*/
      /*~+:/~* Hinzugef�gt am 09.02.2022 *~/*/
      /*~A:224*/
      /*~+:LOAD_SAVE_VERSION*/
      /*~F:225*/
      case LOAD_SAVE_VERSION:
      /*~-1*/
      {
         /*~A:226*/
         /*~+:Variablendeklarationen*/
         /*~T*/
         unsigned long ulVersion;
         /*~E:A226*/
         /*~A:227*/
         /*~+:Variableninitialisierungen*/
         /*~T*/

         /*~E:A227*/
         /*~T*/
         ulVersion = Version_SoftwareVersionToLong();
         /*~T*/
         byRetVal = Ee24c64_Write(EEPROM_VERSION,4,&ulVersion);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F225*/
      /*~E:A224*/
      /*~K*/
      /*~+:/~* Ende - Hinzugef�gt am 09.02.2022 *~/*/
      /*~A:228*/
      /*~+:LOAD_SAVE_WATCHDOG_ADDRESS*/
      /*~F:229*/
      case LOAD_SAVE_WATCHDOG_ADDRESS:
      /*~-1*/
      {
         /*~T*/
         byRetVal = Ee24c64_Write(EEPROM_WATCHDOG_ADDRESS,2,ptrParameter);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F229*/
      /*~E:A228*/
      /*~E:A201*/
      /*~A:230*/
      /*~+:Statistik*/
      /*~A:231*/
      /*~+:LOAD_SAVE_STATISTICS_MAXCURRENT_CH0*/
      /*~F:232*/
      case LOAD_SAVE_STATISTICS_MAXCURRENT_CH0:
      /*~-1*/
      {
         /*~T*/
         byRetVal = Ee24c64_Write(EEPROM_STATISTICS_MAXCURRENT_CH0,4,ptrParameter);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F232*/
      /*~E:A231*/
      /*~A:233*/
      /*~+:LOAD_SAVE_STATISTICS_MAXCURRENT_CH1*/
      /*~F:234*/
      case LOAD_SAVE_STATISTICS_MAXCURRENT_CH1:
      /*~-1*/
      {
         /*~T*/
         byRetVal = Ee24c64_Write(EEPROM_STATISTICS_MAXCURRENT_CH1,4,ptrParameter);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F234*/
      /*~E:A233*/
      /*~A:235*/
      /*~+:LOAD_SAVE_STATISTICS_MAXRMW_CH0*/
      /*~F:236*/
      case LOAD_SAVE_STATISTICS_MAXRMW_CH0:
      /*~-1*/
      {
         /*~T*/
         byRetVal = Ee24c64_Write(EEPROM_STATISTICS_MAXRMW_CH0,4,ptrParameter);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F236*/
      /*~E:A235*/
      /*~A:237*/
      /*~+:LOAD_SAVE_STATISTICS_MAXRMW_CH1*/
      /*~F:238*/
      case LOAD_SAVE_STATISTICS_MAXRMW_CH1:
      /*~-1*/
      {
         /*~T*/
         byRetVal = Ee24c64_Write(EEPROM_STATISTICS_MAXRMW_CH1,4,ptrParameter);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F238*/
      /*~E:A237*/
      /*~A:239*/
      /*~+:LOAD_SAVE_STATISTICS_MAXTEMP_CH0*/
      /*~F:240*/
      case LOAD_SAVE_STATISTICS_MAXTEMP_CH0:
      /*~-1*/
      {
         /*~T*/
         byRetVal = Ee24c64_Write(EEPROM_STATISTICS_MAXTEMP_CH0,1,ptrParameter);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F240*/
      /*~E:A239*/
      /*~A:241*/
      /*~+:LOAD_SAVE_STATISTICS_MAXTEMP_CH1*/
      /*~F:242*/
      case LOAD_SAVE_STATISTICS_MAXTEMP_CH1:
      /*~-1*/
      {
         /*~T*/
         byRetVal = Ee24c64_Write(EEPROM_STATISTICS_MAXTEMP_CH1,1,ptrParameter);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F242*/
      /*~E:A241*/
      /*~A:243*/
      /*~+:LOAD_SAVE_STATISTICS_MAXWEIGHT_CH0*/
      /*~F:244*/
      case LOAD_SAVE_STATISTICS_MAXWEIGHT_CH0:
      /*~-1*/
      {
         /*~T*/
         byRetVal = Ee24c64_Write(EEPROM_STATISTICS_MAXWEIGHT_CH0,4,ptrParameter);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F244*/
      /*~E:A243*/
      /*~A:245*/
      /*~+:LOAD_SAVE_STATISTICS_MAXWEIGHT_CH1*/
      /*~F:246*/
      case LOAD_SAVE_STATISTICS_MAXWEIGHT_CH1:
      /*~-1*/
      {
         /*~T*/
         byRetVal = Ee24c64_Write(EEPROM_STATISTICS_MAXWEIGHT_CH1,4,ptrParameter);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F246*/
      /*~E:A245*/
      /*~A:247*/
      /*~+:LOAD_SAVE_STATISTICS_MINTEMP_CH0*/
      /*~F:248*/
      case LOAD_SAVE_STATISTICS_MINTEMP_CH0:
      /*~-1*/
      {
         /*~T*/
         byRetVal = Ee24c64_Write(EEPROM_STATISTICS_MINTEMP_CH0,1,ptrParameter);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F248*/
      /*~E:A247*/
      /*~A:249*/
      /*~+:LOAD_SAVE_STATISTICS_MINTEMP_CH1*/
      /*~F:250*/
      case LOAD_SAVE_STATISTICS_MINTEMP_CH1:
      /*~-1*/
      {
         /*~T*/
         byRetVal = Ee24c64_Write(EEPROM_STATISTICS_MINTEMP_CH1,1,ptrParameter);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F250*/
      /*~E:A249*/
      /*~A:251*/
      /*~+:LOAD_SAVE_STATISTICS_NBOVERLOADS_CH0*/
      /*~F:252*/
      case LOAD_SAVE_STATISTICS_NBOVERLOADS_CH0:
      /*~-1*/
      {
         /*~T*/
         byRetVal = Ee24c64_Write(EEPROM_STATISTICS_NBOVERLOADS_CH0,2,ptrParameter);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F252*/
      /*~E:A251*/
      /*~A:253*/
      /*~+:LOAD_SAVE_STATISTICS_NBOVERLOADS_CH1*/
      /*~F:254*/
      case LOAD_SAVE_STATISTICS_NBOVERLOADS_CH1:
      /*~-1*/
      {
         /*~T*/
         byRetVal = Ee24c64_Write(EEPROM_STATISTICS_NBOVERLOADS_CH1,2,ptrParameter);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F254*/
      /*~E:A253*/
      /*~A:255*/
      /*~+:LOAD_SAVE_STATISTICS_NBOVERLIMITS_CH0*/
      /*~F:256*/
      case LOAD_SAVE_STATISTICS_NBOVERLIMITS_CH0:
      /*~-1*/
      {
         /*~T*/
         byRetVal = Ee24c64_Write(EEPROM_STATISTICS_NBOVERLIMITS_CH0,2,ptrParameter);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F256*/
      /*~E:A255*/
      /*~A:257*/
      /*~+:LOAD_SAVE_STATISTICS_NBOVERLIMITS_CH1*/
      /*~F:258*/
      case LOAD_SAVE_STATISTICS_NBOVERLIMITS_CH1:
      /*~-1*/
      {
         /*~T*/
         byRetVal = Ee24c64_Write(EEPROM_STATISTICS_NBOVERLIMITS_CH1,2,ptrParameter);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F258*/
      /*~E:A257*/
      /*~A:259*/
      /*~+:LOAD_SAVE_STATISTICS_SETUP*/
      /*~F:260*/
      case LOAD_SAVE_STATISTICS_SETUP:
      /*~-1*/
      {
         /*~T*/
         byRetVal = Ee24c64_Write(EEPROM_STATISTICS_SETUP,byChars2Save,ptrParameter);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F260*/
      /*~E:A259*/
      /*~A:261*/
      /*~+:LOAD_SAVE_STATISTICS_TIMEMAXWEIGHT_CH0*/
      /*~F:262*/
      case LOAD_SAVE_STATISTICS_TIMEMAXWEIGHT_CH0:
      /*~-1*/
      {
         /*~T*/
         byRetVal = Ee24c64_Write(EEPROM_STATISTICS_TIMEMAXWEIGHT_CH0,4,ptrParameter);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F262*/
      /*~E:A261*/
      /*~A:263*/
      /*~+:LOAD_SAVE_STATISTICS_TIMEMAXWEIGHT_CH1*/
      /*~F:264*/
      case LOAD_SAVE_STATISTICS_TIMEMAXWEIGHT_CH1:
      /*~-1*/
      {
         /*~T*/
         byRetVal = Ee24c64_Write(EEPROM_STATISTICS_TIMEMAXWEIGHT_CH1,4,ptrParameter);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F264*/
      /*~E:A263*/
      /*~E:A230*/
      /*~A:265*/
      /*~+:Stromschnittstelle*/
      /*~A:266*/
      /*~+:LOAD_SAVE_DAC_COPY_CALIBRATION*/
      /*~F:267*/
      case LOAD_SAVE_DAC_COPY_CALIBRATION:
      /*~-1*/
      {
         /*~T*/
         byRetVal = Ee24c64_Write(EEPROM_DAC_COPY_CALIBRATION,byChars2Save,ptrParameter);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F267*/
      /*~E:A266*/
      /*~A:268*/
      /*~+:LOAD_SAVE_DAC_GAIN_FEEDBACK*/
      /*~F:269*/
      case LOAD_SAVE_DAC_GAIN_FEEDBACK:
      /*~-1*/
      {
         /*~T*/
         byRetVal = Ee24c64_Write(EEPROM_DAC_FEEDBACK_GAIN,4,ptrParameter);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F269*/
      /*~E:A268*/
      /*~A:270*/
      /*~+:LOAD_SAVE_DAC_OFFSET_FEEDBACK*/
      /*~F:271*/
      case LOAD_SAVE_DAC_OFFSET_FEEDBACK:
      /*~-1*/
      {
         /*~T*/
         byRetVal = Ee24c64_Write(EEPROM_DAC_FEEDBACK_OFFSET,4,ptrParameter);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F271*/
      /*~E:A270*/
      /*~A:272*/
      /*~+:LOAD_SAVE_DAC_RMW_1ST_REFPOINT*/
      /*~F:273*/
      case LOAD_SAVE_DAC_RMW_1ST_REFPOINT:
      /*~-1*/
      {
         /*~T*/
         byRetVal = Ee24c64_Write(EEPROM_DAC_RMW_1ST_REFPOINT,4,ptrParameter);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F273*/
      /*~E:A272*/
      /*~A:274*/
      /*~+:LOAD_SAVE_DAC_RMW_2ND_REFPOINT*/
      /*~F:275*/
      case LOAD_SAVE_DAC_RMW_2ND_REFPOINT:
      /*~-1*/
      {
         /*~T*/
         byRetVal = Ee24c64_Write(EEPROM_DAC_RMW_2ND_REFPOINT,4,ptrParameter);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F275*/
      /*~E:A274*/
      /*~A:276*/
      /*~+:LOAD_SAVE_DAC_SETTINGS*/
      /*~F:277*/
      case LOAD_SAVE_DAC_SETTINGS:
      /*~-1*/
      {
         /*~T*/
         byRetVal = Ee24c64_Write(EEPROM_DAC_SETTINGS,sizeof(DAC_SETTINGS),ptrParameter);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F277*/
      /*~E:A276*/
      /*~A:278*/
      /*~+:LOAD_SAVE_CURRENTINTERFACE_MAXDEVIATION*/
      /*~F:279*/
      case LOAD_SAVE_CURRENTINTERFACE_MAXDEVIATION:
      /*~-1*/
      {
         /*~T*/
         byRetVal = Ee24c64_Write(EEPROM_DAC_MAXDEVIATION,4,ptrParameter);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F279*/
      /*~E:A278*/
      /*~A:280*/
      /*~+:LOAD_SAVE_INTEGRALPORTION_FEEDBACK*/
      /*~F:281*/
      case LOAD_SAVE_INTEGRALPORTION_FEEDBACK :
      /*~-1*/
      {
         /*~T*/
         byRetVal = Ee24c64_Write(EEPROM_DAC_FEEDBACK_INTEGRALPORTION,1,ptrParameter);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F281*/
      /*~E:A280*/
      /*~A:282*/
      /*~+:LOAD_SAVE_MEASUREMENT_DEPTH_FEEDBACK*/
      /*~F:283*/
      case LOAD_SAVE_MEASUREMENT_DEPTH_FEEDBACK :
      /*~-1*/
      {
         /*~T*/
         byRetVal = Ee24c64_Write(EEPROM_DAC_FEEDBACK_MEASUREMENTDEPTH,1,ptrParameter);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F283*/
      /*~E:A282*/
      /*~A:284*/
      /*~+:LOAD_SAVE_CURRENTINTERFACE_TIME_HYSTERESIS*/
      /*~F:285*/
      case LOAD_SAVE_CURRENTINTERFACE_TIME_HYSTERESIS:
      /*~-1*/
      {
         /*~T*/
         byRetVal = Ee24c64_Write(EEPROM_DAC_TIME_HYSTERESIS,2,ptrParameter);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F285*/
      /*~E:A284*/
      /*~A:286*/
      /*~+:LOAD_SAVE_PROPORTIONALPORTION_FEEDBACK*/
      /*~F:287*/
      case LOAD_SAVE_PROPORTIONALPORTION_FEEDBACK :
      /*~-1*/
      {
         /*~T*/
         byRetVal = Ee24c64_Write(EEPROM_DAC_FEEDBACK_PROPORTIONALPORTION,1,ptrParameter);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F287*/
      /*~E:A286*/
      /*~E:A265*/
      /*~A:288*/
      /*~+:Temperaturkompensation*/
      /*~A:289*/
      /*~+:LOAD_SAVE_COMPENSATION*/
      /*~F:290*/
      case LOAD_SAVE_COMPENSATION:
      /*~-1*/
      {
         /*~T*/
         byRetVal = Ee24c64_Write(EEPROM_COMPENSATION,sizeof(MRW_COMPENSATION_TEMPERATURE_COMPENSATION),ptrParameter);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F290*/
      /*~E:A289*/
      /*~A:291*/
      /*~+:LOAD_SAVE_COMPENSATIONLIMITS*/
      /*~F:292*/
      case LOAD_SAVE_COMPENSATIONLIMITS:
      /*~-1*/
      {
         /*~T*/
         byRetVal = Ee24c64_Write(EEPROM_COMPENSATIONLIMITS,sizeof(MRW_COMPENSATION_LIMITS),ptrParameter);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F292*/
      /*~E:A291*/
      /*~E:A288*/
   /*~-1*/
   }
   /*~E:C154*/
   /*~I:293*/
   if (byRetVal)
   /*~-1*/
   {
      /*~T*/
      Diagnosis_SecurityMemory(WRITE_EEPROM);

      return 1;
   /*~-1*/
   }
   /*~O:I293*/
   /*~-2*/
   else
   {
      /*~T*/
      return 0;
   /*~-1*/
   }
   /*~E:I293*/
/*~-1*/
}
/*~E:F150*/
/*~E:A149*/
