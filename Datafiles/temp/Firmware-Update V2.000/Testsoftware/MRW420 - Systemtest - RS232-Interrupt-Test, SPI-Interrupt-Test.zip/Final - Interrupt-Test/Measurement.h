/*~-1*/
/*~XSF_LANGUAGE: C/C++*/
/*~K*/
/*~+:File :        Measurement.h*/
/*~+:*/
/*~+:Version :     V1.003*/
/*~+:*/
/*~+:Date :        05.04.2005*/
/*~+:*/
/*~+:Time :        */
/*~+:*/
/*~+:Author :      MOF*/
/*~+:*/
/*~+:Hardware :*/
/*~+:*/
/*~+:Description :*/
/*~I:1*/
#ifndef __MEASUREMENT_H

/*~T*/
#define __MEASUREMENT_H
/*~A:2*/
/*~+:Includes*/
/*~T*/

/*~E:A2*/
/*~A:3*/
/*~+:Versions-Beschreibung*/
/*~A:4*/
/*~+:Version und Versionsdatum*/
/*~T*/
/*!
@cond FOR_LIBRARY_DOCS
\mainpage "Modul-Beschreibung"
\section sec_MainPage_Measurement 'Messwertverarbeitung'

\author Michael Offenbach
\date Erstellung :     05.05.2008
\version V1.007
\warning
@endcond
*/
/*~T*/
/*!
\addtogroup versions_externals
@cond FOR_APPLICATION_DOCS
@{
<tr>
	<td>Measurement.h</td>
	<td>Michael Offenbach</td>
	<td>1.007</td>
	<td>05.05.2008</td>
	<td></td>
</tr>
@}
@endcond
*/
/*~E:A4*/
/*~A:5*/
/*~+:Ziel-Hardware*/
/*~T*/
/*!
@cond FOR_LIBRARY_DOCS
\page HardwarePage Ziel-Hardware

\section sec_HardwarePage_Measurement 'Messwertverarbeitung'

<table border=1 width=100% height=1% rules=rows cellspacing=0 bgcolor="#E0E0F0">

<tr align=left valign=top>
	<th>Motherboard</th>
	<th>Prozessor</th>
	<th>ROM</th>
	<th>RAM</th>
</tr>

<tr>
	<td>MRW-Limit V1.2B 2/2004</td>
	<td>8051-Core</td>
	<td>62 <B>kByte</B></td>
	<td>2 <B>kByte</B></td>
</tr></table>
@endcond
*/
/*~T*/
/*!
\addtogroup peripherals_externals
@cond FOR_APPLICATION_DOCS
@{
<tr>
	<td>Measurement.h</td>
	<td>MRW-Limit V1.2B 2/2004</td>
	<td>8051-Core</td>
	<td>62 <B>kByte</B></td>
	<td>2 <B>kByte</B></td>
</tr>
@}
@endcond
*/
/*~E:A5*/
/*~A:6*/
/*~+:Compiler-Einstellungen*/
/*~T*/
/*!
@cond FOR_LIBRARY_DOCS
\page CompilerPage Compiler-Einstellungen
\section sec_CompilerPage_Measurement 'Messwertverarbeitung'

<table border=1 width=100% height=1% rules=rows cellspacing=0 bgcolor="#E0E0F0">

<tr align=left valign=top>
	<th>Compiler</th>
	<th>Betriebssystem</th>
	<th>Speichermodell</th>
	<th>Code-Speicher-Gr��e</th>
	<th>Optimierungen</th>
	<th>Sonstiges</th>
</tr>

<tr>
	<td>Keil uVision2 V2.40<BR>C51 V7.08<BR>A51 V7.08a</td>
	<td>Kein Betriebssystem</td>
	<td>Large: variables in XDATA</td>
	<td>Large: 64k program</td>
	<td>
	[ ] 0 Constant Folding<BR>
	[ ] 1 Dead Code Elimination<BR>
	[ ] 2 Data Overlaying<BR>
	[ ] 3 Peephole Optimization<BR>
	[ ] 4 Register Variables<BR>
	[ ] 5 Common Subexpression Elimination<BR>
	[ ] 6 Loop Rotation<BR>
	[ ] 7 Extended Index Access Optimizing<BR>
	[ ] 8 Reuse Common Entry Code<BR>
	[X] 9 Common Block Subroutines<BR>
	<BR>
	[X]Favor size<BR>
	[ ]Favor speed</td>
	<td>---</td>
</tr></table>
@endcond
*/
/*~T*/
/*!
\addtogroup compilersettings_externals
@cond FOR_APPLICATION_DOCS
@{
<tr>
	<td>Measurement.h</td>
	<td>Keil uVision2 V2.40<BR>C51 V7.08<BR>A51 V7.08a</td>
	<td>Kein Betriebssystem</td>
	<td>Large: variables in XDATA</td>
	<td>Large: 64k program</td>
	<td>
	[ ] 0 Constant Folding<BR>
	[ ] 1 Dead Code Elimination<BR>
	[ ] 2 Data Overlaying<BR>
	[ ] 3 Peephole Optimization<BR>
	[ ] 4 Register Variables<BR>
	[ ] 5 Common Subexpression Elimination<BR>
	[ ] 6 Loop Rotation<BR>
	[ ] 7 Extended Index Access Optimizing<BR>
	[ ] 8 Reuse Common Entry Code<BR>
	[X] 9 Common Block Subroutines<BR>
	<BR>
	[X]Favor size<BR>
	[ ]Favor speed</td>
	<td>---</td>
</tr>
@}
@endcond
*/
/*~E:A6*/
/*~A:7*/
/*~+:Ressourcen*/
/*~T*/
/*!
@cond FOR_LIBRARY_DOCS
\page RessourcePage Ressourcen
\section sec_RessourcePage_Measurement 'Messwertverarbeitung'

<table border=1 width=100% height=1% rules=rows cellspacing=0 bgcolor="#E0E0F0">

<tr align=left valign=top>
	<th>CODE</th>
	<th>IDATA</th>
	<th>XDATA</th>
	<th>Dynamische Variablen</th>
</tr>

<tr>
	<td>--- <B>Bytes</B></td>
	<td>--- <B>Bytes</B></td>
	<td>--- <B>Bytes</B></td>
	<td>--- <B>Bytes</B></td>
</tr></table>
@endcond
*/
/*~T*/
/*!
\addtogroup ressources_externals
@cond FOR_APPLICATION_DOCS
@{
<tr>
	<td>Measurement.h</td>
	<td>--- <B>Bytes</B></td>
	<td>--- <B>Bytes</B></td>
	<td>--- <B>Bytes</B></td>
	<td>--- <B>Bytes</B></td>
</tr>
@}
@endcond
*/
/*~E:A7*/
/*~A:8*/
/*~+:Zykluszeiten*/
/*~T*/
/*!
@cond FOR_LIBRARY_DOCS
\page CycletimePage Zykluszeiten
\section sec_CycletimePage_Measurement 'Messwertverarbeitung'

<table border=1 width=100% height=1% rules=rows cellspacing=0 bgcolor="#E0E0F0">

<tr align=left valign=top>
	<th>Minimale Durchlaufzeit</th>
	<th>Maximale Durchlaufzeit</th>
</tr>

<tr>
	<td>--- <B>ms</B></td>
	<td>--- <B>ms</B></td>
</tr></table>
@endcond
*/
/*~T*/
/*!
\addtogroup cycletimes_externals
@cond FOR_APPLICATION_DOCS
@{
<tr>
	<td>Measurement.h</td>
	<td>--- <B>ms</B></td>
	<td>--- <B>ms</B></td>
</tr>
@}
@endcond
*/
/*~E:A8*/
/*~A:9*/
/*~+:Verschiedenes*/
/*~T*/
/*!
@cond FOR_LIBRARY_DOCS
\page MiscPage Verschiedenes
\section sec_MiscPage_Measurement 'Messwertverarbeitung'

<table border=1 width=100% height=1% rules=rows cellspacing=0 bgcolor="#E0E0F0">

<tr align=left valign=top>
	<th>Benutzte Interrups</th>
	<th>Benutzte Registerb�nke</th>
</tr>

<tr>
	<td>---</td>
	<td>---</td>
</tr></table>
@endcond
*/
/*~T*/
/*!
\addtogroup misc_externals
@cond FOR_APPLICATION_DOCS
@{
<tr>
	<td>Measurement.h</td>
	<td>---</td>
	<td>---</td>
</tr>
@}
@endcond
*/
/*~E:A9*/
/*~A:10*/
/*~+:Lifecycle*/
/*~T*/
/*!
@cond FOR_LIBRARY_DOCS
\page LifeCyclePage Lifecycle
\section sec_LifeCyclePage_Measurement 'Messwertverarbeitung'

<table border=1 width=100% height=1% rules=rows cellspacing=0 bgcolor="#E0E0F0">

<tr align=left valign=top>
	<th>Version</th>
	<th>Datum</th>
	<th>Programmierer</th>
	<th>�nderungen</th>
	<th>ersetzt Version</th>
</tr>

<tr>
	<td>1.000</td>
	<td>31.03.05</td>
	<td>Michael Offenbach</td>
	<td>Erste lauff�hige Version</td>
	<td>----</td>
</tr>

<tr>
	<td>1.001</td>
	<td>31.03.05</td>
	<td>Michael Offenbach</td>
	<td>Zwischenergebnisse k�nnen abgespeichert werden</td>
	<td>Alle fr�heren Versionen</td>
</tr>
<tr>
	<td>1.002</td>
	<td>18.04.05</td>
	<td>Michael Offenbach</td>
	<td>Mittelwertberechnung, Berechnung der Kanalabweichung, Setzen des Nullpunktes auf den aktuellen Messwert und Berechnung des Kalibrierfaktors �ber den aktuellen Messwert eingef�gt. Ausgabe der Ergebnisse erweitert. Interne Flags in einer Variablen gespeichert. Interne lokale Variablen durch Pointer ersetzt (Einsparung an XDATA). Dokumentation und Definitionen �berarbeitet.</td>
	<td>Alle fr�heren Versionen</td>
</tr>

<tr>
	<td>1.003</td>
	<td>01.06.05</td>
	<td>Michael Offenbach</td>
	<td>Mittelwertberechnung wegen der Komplexit�t wieder herausgenommen. Die Funktion Measurement_SetZero(...) hei�t nun Measurement_SetZeroValue(...). �ber eine neue Funktion Measurement_SetZero('Kanal') wird nun direkt der Nullpunkt gesetzt. Entfall der Routine CalcZero(...). Measurement_CalcCalibrationFactor(...) berechnet den Kalibrierfaktor jetzt ebenfalls unmittelbar. In der Sequenzliste muss jetzt beim Aufruf der Funktion zur Normierung des Rohmesswertes der Datentyp des resultierenden Gewichtswertes nicht mehr mit angegeben werden. Diese Angabe erfolgt nun im neu hinzugef�gten dritten Parameter der Funktion Measurement_Setup(...). Umbennenung der Funktion Measurement_SetTare(...) in
Measurement_SetTareValue(...). Umbenennung der Funktion Measurement_SetTareAutomatic(...) in Measurement_SetTare(...) und Wegfall des zweiten Parameters. Dieser wird nun vom Typ des resultierenden Gewichtswertes abgeleitet.</td>
	<td>Alle fr�heren Versionen</td>
</tr>

<tr>
	<td>1.004</td>
	<td>30.06.05</td>
	<td>Michael Offenbach</td>
	<td>Nullpunkt wurde mittels des reinen Rohmesswertes gesetzt. War dieser mit einer Messwertspitze versehen, f�hrte dies zu einem fehlerhaften nullpunktbereinigten Messwert. Jetzt wird intern immer der Messwert zwischengespeichert, der zur Nullpunktverrechnung ansteht und dieser dann im Falle einer Nullpunktbestimmung verwendet.<BR>Funktion Measurement_IsMotion(...) zur direkten Abfrage einer Messwertbewegung eingef�gt.<BR>Bei der Berechnung des Kalibrierfaktors bei Longwerten wurden diese nicht in Float gecastet, so dass sich nur ganzzalige Kalibrierfaktoren ergaben - Cast eingef�gt.<BR>Beim Allokieren von dynamischen Variablen wurde nicht korrekt �berpr�ft, ob gen�gend Speicherplatz vorhanden ist - �berpr�fung �berarbeitet.<BR>Um XDATA- und Code-Speicher einsparen zu k�nnen, wurde jeder Funktion nun ein eigenes Modul geg�nnt.</td>
	<td>Alle fr�heren Versionen</td>
</tr>

<tr>
	<td>1.005</td>
	<td>26.02.08</td>
	<td>Michael Offenbach</td>
	<td>Erkennung einer Gewichtsbewegung erfolgt nun gem�ss der Funktion bei der MRW-Limit.</td>
	<td>Alle fr�heren Versionen</td>
</tr>

<tr>
	<td>1.006</td>
	<td></td>
	<td></td>
	<td>Version wurde �bersprungen</td>
	<td></td>
</tr>

<tr>
	<td>1.007</td>
	<td>05.05.08</td>
	<td>Michael Offenbach</td>
	<td>Negative Taras werden zugelassen.</td>
	<td>Alle fr�heren Versionen</td>
</tr>


</table>
@endcond
*/
/*~T*/
/*!
\addtogroup lifecycle_externals
@cond FOR_APPLICATION_DOCS
@{
<tr>
	<td>Measurement.h</td>
	<td>1.000</td>
	<td>31.03.05</td>
	<td>Michael Offenbach</td>
	<td>Erste lauff�hige Version</td>
	<td>----</td>
</tr>

<tr>
	<td></td>
	<td>1.001</td>
	<td>31.03.05</td>
	<td>Michael Offenbach</td>
	<td>Zwischenergebnisse k�nnen abgespeichert werden</td>
	<td>Alle fr�heren Versionen</td>
</tr>
<tr>
	<td></td>
	<td>1.002</td>
	<td>18.04.05</td>
	<td>Michael Offenbach</td>
	<td>Mittelwertberechnung, Berechnung der Kanalabweichung, Setzen des Nullpunktes auf den aktuellen Messwert und Berechnung des Kalibrierfaktors �ber den aktuellen Messwert eingef�gt. Ausgabe der Ergebnisse erweitert. Interne Flags in einer Variablen gespeichert. Interne lokale Variablen durch Pointer ersetzt (Einsparung an XDATA). Dokumentation und Definitionen �berarbeitet.</td>
	<td>Alle fr�heren Versionen</td>
</tr>

<tr>
	<td></td>
	<td>1.003</td>
	<td>01.06.05</td>
	<td>Michael Offenbach</td>
	<td>Mittelwertberechnung wegen der Komplexit�t wieder herausgenommen. Die Funktion Measurement_SetZero(...) hei�t nun Measurement_SetZeroValue(...). �ber eine neue Funktion Measurement_SetZero('Kanal') wird nun direkt der Nullpunkt gesetzt. Entfall der Routine CalcZero(...). Measurement_CalcCalibrationFactor(...) berechnet den Kalibrierfaktor jetzt ebenfalls unmittelbar. In der Sequenzliste muss jetzt beim Aufruf der Funktion zur Normierung des Rohmesswertes der Datentyp des resultierenden Gewichtswertes nicht mehr mit angegeben werden. Diese Angabe erfolgt nun im neu hinzugef�gten dritten Parameter der Funktion Measurement_Setup(...). Umbennenung der Funktion Measurement_SetTare(...) in
Measurement_SetTareValue(...). Umbenennung der Funktion Measurement_SetTareAutomatic(...) in Measurement_SetTare(...) und Wegfall des zweiten Parameters. Dieser wird nun vom Typ des resultierenden Gewichtswertes abgeleitet.</td>
	<td>Alle fr�heren Versionen</td>
</tr>

<tr>
	<td></td>
	<td>1.004</td>
	<td>30.06.05</td>
	<td>Michael Offenbach</td>
	<td>Nullpunkt wurde mittels des reinen Rohmesswertes gesetzt. War dieser mit einer Messwertspitze versehen, f�hrte dies zu einem fehlerhaften nullpunktbereinigten Messwert. Jetzt wird intern immer der Messwert zwischengespeichert, der zur Nullpunktverrechnung ansteht und dieser dann im Falle einer Nullpunktbestimmung verwendet.<BR>Funktion Measurement_IsMotion(...) zur direkten Abfrage einer Messwertbewegung eingef�gt.<BR>Bei der Berechnung des Kalibrierfaktors bei Longwerten wurden diese nicht in Float gecastet, so dass sich nur ganzzalige Kalibrierfaktoren ergaben - Cast eingef�gt.<BR>Beim Allokieren von dynamischen Variablen wurde nicht korrekt �berpr�ft, ob gen�gend Speicherplatz vorhanden ist - �berpr�fung �berarbeitet.<BR>Um XDATA- und Code-Speicher einsparen zu k�nnen, wurde jeder Funktion nun ein eigenes Modul geg�nnt.</td>
	<td>Alle fr�heren Versionen</td>
</tr>

<tr>
	<td></td>
	<td>1.005</td>
	<td>26.02.08</td>
	<td>Michael Offenbach</td>
	<td>Erkennung einer Gewichtsbewegung erfolgt nun gem�ss der Funktion bei der MRW-Limit.</td>
	<td>Alle fr�heren Versionen</td>
</tr>

<tr>
	<td></td>
	<td>1.006</td>
	<td></td>
	<td></td>
	<td>Version wurde �bersprungen</td>
	<td></td>
</tr>

<tr>
	<td></td>
	<td>1.007</td>
	<td>05.05.08</td>
	<td>Michael Offenbach</td>
	<td>Negative Taras werden zugelassen.</td>
	<td>Alle fr�heren Versionen</td>
</tr>

@}
@endcond
*/
/*~E:A10*/
/*~A:11*/
/*~+:Beispiel*/
/*~T*/
/*!
@cond FOR_LIBRARY_DOCS
\page ExamplePage_Measurement Beispiel 'Messwertverarbeitung'
\code

//Modulbeschreibung:
//Demo-Programm zur Demonstration der Einbindung der Befehle der Messwertverarbeitung.


//Includes
#include <aduc836.h>
#include <stdlib.h>
#include "Measurement.h"
#include "d:\Daten\Aduc836-Projekte\Filter\AverageFilter\AverageFilter.h "
#define MASTER_CHANEL		0
#define SLAVE_CHANEL		1

// Wiederholungen der Werte bis zum n�chsten Wert
#define REPEAT_RMW_VALUE	0

// Zwischenspeicher 'Gefilterter Rohmesswert'
#define FILTERED_VALUE	0
// Zwischenspeicher 'Nullpunkt korrigierter Rohmesswert'
#define ZERO_CORRECTED_VALUE	1	
#pragma NOAREGS

char Correction(MEASUREMENT_CORRECTIONPARAMETERS *pCorrectionParameters);
void Correction_Ini(unsigned char byMode);
void Filter_Ini(unsigned char byMode);
char Filter(MEASUREMENT_FILTERPARAMETERS *pFilterParameters);
code long lWerte_1[] =
{100,  100,  100,  100,  100,  100,  100,  100,  100,  100,  100,  100,  100,  100,  100,  100, 4187, 4189, 4190, 4195, 4193, 4152, 4159, 4157, 4156, 4215, 4205, 4222, 4230, 4237, 4161, 4151, 4068, 4017, 4016, 3992, 3992, 4031, 4020, 4020, 4113, 4258, 4258, 4258, 4337, 4336, 4336, 4317, 4317, 4373, 4356, 4356, 4312, 4221, 4221, 4249, 4222, 4222, 4175, 4144, 4144, 4144, 4196, 4196, 4127, 4042, 4042, 4067, 4128, 4128, 4128, 4130, 4107, 4107, 4136, 4136, 4162, 4162, 4141, 4141, 4144, 4149, 4149, 4175, 4256, 4243, 4243, 4221, 4221, 4214, 4213, 4217, 4217, 4206, 4229, 4229, 4221, 4221, 4166, 4166, 4175, 4175, 4174, 4174, 4171, 4171, 4174, 4205, 4275, 4275, 4272, 4272, 4273, 4273, 4294, 4294, 4294, 4285, 4270, 4270, 4266, 4266, 4276, 4277, 4277, 4293, 4293, 4305, 4305, 4301, 4301, 4305, 4305, 4305, 4301, 4301, 4300, 4300, 4300, 4288, 4292, 4292, 4285, 4285, 4278, 4285, 4291, 4291, 4303, 4295, 4284, 4276, 4276, 4272, 4272, 4266, 4267, 4267, 4278, 4290, 4293, 4293, 4265, 4265, 4260, 4260, 4249, 4241, 4241, 4238, 4243, 4243, 4262, 4268, 4280, 4280, 4281, 4239, 4239, 4145, 4092, 4092, 4085, 4076, 4076, 4076, 4076, 4130, 4130, 4222, 4222, 4258, 4258, 4258, 4245, 4236, 4226, 4226, 4227, 4227, 4227, 4240, 4250, 4253, 4253, 4117, 4117, 4027, 4013, 4013, 4014, 4014, 4040, 4040, 4148, 4239, 4251, 4251, 4256, 4256, 4250, 4201, 4201, 4157, 4139, 4139, 4135, 4135, 4138, 4140, 4140, 4182, 4182, 4114, 4080, 4080, 4080, 4079, 4075, 4075, 4075, 4083, 4086, 4199, 4199, 4232, 4160, 4160, 4160, 4135, 4132, 4133, 4138, 4138, 4154, 4230,  0x7FFF};

code long lWerte_2[] =
{ 400,   400,   400,   400,  400,   400,   400,   400,   400,   400,   400,   400,   400,   400,   400,   400, 11963, 11963, 12003, 12003, 12002, 11746, 11746, 11990, 11990, 12247, 12247, 12106, 12052, 11790, 11550, 11550, 11429, 11943, 11943, 11957, 11957, 12281, 11725, 11725, 12110, 12299, 12299, 12299, 12419, 11947, 11947, 12171, 12171, 12057, 12009, 12009, 12035, 11875, 11875, 12115, 12009, 12009, 11771, 11825, 11825, 12036, 12185, 12185, 11702, 11497, 11497, 11925, 12187, 12187, 12187, 12053, 12043, 12043, 11875, 11875, 11954, 11954, 12062, 12062, 12068, 12072, 12072, 12036, 12112, 11872, 11872, 11932, 11932, 12026, 12065, 12060, 12060, 12050, 12009, 12009, 11885, 11885, 11693, 11693, 12121, 12121, 12054, 12054, 12028, 12028, 12032, 12070, 12112, 12112, 12104, 12104, 12060, 12060, 12068, 12068, 12068, 12015, 12022, 12022, 12082, 12082, 12120, 12120, 12120, 12082, 12082, 12095, 12095, 12060, 12060, 12143, 12143, 12117, 12078, 12078, 12071, 12071, 12071, 12027, 12081, 12081, 12105, 12105, 12074, 12119, 12104, 12104, 12104, 12029, 12038, 12028, 12028, 12094, 12094, 12071, 12110, 12110, 12094, 12107, 12051, 12051, 11964, 11964, 12080, 12080, 12026, 12062, 12062, 12033, 12061, 12061, 12078, 12112, 12100, 12100, 12068, 11782, 11782, 11496, 11760, 11760, 12070, 12047, 12047, 12047, 12067, 12107, 12107, 12049, 12049, 11988, 11988, 11988, 11965, 12017, 12048, 12048, 12055, 12057, 12057, 12063, 12028, 12035, 12035, 11381, 11381, 11513, 11983, 11983, 12033, 12037, 12057, 12057, 12034, 12054, 12060, 12060, 12059, 12059, 12004, 11760, 11760, 11769, 11950, 11950, 12034, 12034, 12079, 12017, 12017, 12011, 12011, 11360, 11744, 11744, 11744, 12029, 12053, 12053, 12053, 12069, 12027, 12036, 12036, 11945, 11594, 11594, 11594, 11905, 12052, 12034, 12062, 12062, 12042, 12053, 12053, 12055, 12055, 12056, 12056, 12051, 12075, 12075, 12034, 12045, 11778, 11472, 11484, 11484, 11484, 11422, 11543, 11539, 11539, 11522, 11508, 11508, 11508, 11562, 11575, 11488, 11488, 11380, 11490, 11388, 11388, 11404, 11479, 11596, 11526, 11526, 115
6, 11499, 11499, 11499, 11524, 11524, 11522, 11529, 11529, 11527, 0x7FFF};
code char byTemperature_1[] = {75,50,25,27,-35,0,0x7F};
code char byTemperature_2[] = {75,50,25,27,-35,0,0x7F};
unsigned char ptrDynVar[0x300];
unsigned char *pTestVar;
main()
{
   int nPtr;
   long lRohmesswert_Master;
   long lRohmesswert_Slave;
   MEASUREMENT_VALUE Messwert[2];
   MEASUREMENT_VALUE Sollwert[2];
   MEASUREMENT_VALUE Kalibrierfaktor[2];
   MEASUREMENT_VALUE NullpunktKorrigierterMesswert[2];
   MEASUREMENT_VALUE Kanalabstand[2];
   MEASUREMENT_RESULTS Results[2];

   unsigned int nCycleCounterRohmesswerte;

   unsigned char byError;

   unsigned char byChannel;
   MEASUREMENT_VALUE Zero;
   MEASUREMENT_MOTIONPARAMETER MotionParameter;

   CFG836 |= 1;
   PLLCON &= 0xF8;
   T0 = 0;
   nCycleCounterRohmesswerte = 0;
   nPtr = 0;

   byError = 0;
   init_mempool(ptrDynVar,sizeof(ptrDynVar));
   // Filterfunktion initialisieren
   Filter_Ini(0);

   // Korrekturfunktion initialisieren
   Correction_Ini(0);
   // Messwertroutinen initialisieren - Ein Kanal
   Measurement_Init(2);	//
   // Messwertkanal einrichten
   Measurement_Setup(MASTER_CHANEL,MEASUREMENT_LONGDATA,MEASUREMENT_FLOATDATA);
   Measurement_Setup(SLAVE_CHANEL,MEASUREMENT_LONGDATA,MEASUREMENT_FLOATDATA);
   // Nullpunkt manuell setzen
   Zero.nLong = 10;
   Measurement_SetZeroValue(MASTER_CHANEL,&Zero);
   Zero.nLong = 30;
   Measurement_SetZeroValue(SLAVE_CHANEL,&Zero);
   // Kalibrierfaktor setzen
   Measurement_SetCalibrationFactor(MASTER_CHANEL,0.06);
   Measurement_SetCalibrationFactor(SLAVE_CHANEL,0.0275);

   // Motion-Grenze und �berpr�fungsrate setzen
   // Motion�berpr�fung erfolgt bei jedem Aufruf von Measurement_Processing und wird
   // bei einer Messwertbewegung von mehr als 0.3 als solche erkannt.
   MotionParameter.fMotionLimit = 0.3;
   MotionParameter.nMotionCheckRate = 1;
   MotionParameter.byMotionFilter = 1;
   Measurement_SetMotionParameter(MASTER_CHANEL,MotionParameter);
   Measurement_SetMotionParameter(SLAVE_CHANEL,MotionParameter);

   // Master-Sequenzen setzen
   Measurement_SetSequence	(	MASTER_CHANEL,
   							// Korrekturfunktion aufrufen
   							MEASUREMENT_SEQLIST_CORRECTION,0,
   							// Filterfunktion aufrufen	
   							MEASUREMENT_SEQLIST_FILTER,0,
   							// Ergebnis im Speicher 0
   							MEASUREMENT_SEQLIST_STORERESULT,FILTERED_VALUE,
   							// Nullpunktkorrektur
   							MEASUREMENT_SEQLIST_ZERO,0,
   							// Ergebnis im Speicher 1 zwischenspeichern
   							MEASUREMENT_SEQLIST_STORERESULT,ZERO_CORRECTED_VALUE,
   							// Normierung mit Ergebnis als Float	
   							MEASUREMENT_SEQLIST_STANDARDIZATION,0,
   							// Mittelwertbildung
   							MEASUREMENT_SEQLIST_CALCAVERAGE,0,
   							// Motion-Untersuchung	
   							MEASUREMENT_SEQLIST_MOTION,0,
   							// Abschlu� - Taraverrechnung		
   							MEASUREMENT_SEQLIST_END,MEASUREMENT_CALC_TARE
   						);

   // SlaveSequenzen setzen
   Measurement_SetSequence	(	SLAVE_CHANEL,
   							// Mittelwertbildung
   							MEASUREMENT_SEQLIST_STOREVALUE_4_CALCAVERAGE,0,
   							// Korrekturfunktion aufrufen
   							MEASUREMENT_SEQLIST_CORRECTION,0,
   							// Filterfunktion aufrufen	
   							MEASUREMENT_SEQLIST_FILTER,0,
   							// Ergebnis im Speicher 0
   							MEASUREMENT_SEQLIST_STORERESULT,FILTERED_VALUE,
   							// Nullpunktkorrektur
   							MEASUREMENT_SEQLIST_ZERO,0,
   							// Ergebnis im Speicher 1 zwischenspeichern
   							MEASUREMENT_SEQLIST_STORERESULT,ZERO_CORRECTED_VALUE,
   							// Normierung mit Ergebnis als Float	
   							MEASUREMENT_SEQLIST_STANDARDIZATION,0,
   							// Mittelwertbildung
   							MEASUREMENT_SEQLIST_STOREVALUE_4_CALCAVERAGE,0,
   							// Motion-Untersuchung	
   							MEASUREMENT_SEQLIST_MOTION,0,
   							// Abschlu� - Taraverrechnung		
   							MEASUREMENT_SEQLIST_END,MEASUREMENT_CALC_TARE
   						);

   // noch gen�gend dynamischer Speicher vorhanden ?
   if (pTestVar = (char*)malloc(1))
   {
      while (!byError)
      {
         // Zyklisch neue Rohmesswerte und neue Temperaturen auslesen
         if (nCycleCounterRohmesswerte-- == 0)
         {
            nCycleCounterRohmesswerte = REPEAT_RMW_VALUE;
            if (lWerte_1[nPtr] == 0x7FFF)
            {
               nPtr = 0;
            }
            lRohmesswert_Master = lWerte_1[nPtr];
            lRohmesswert_Slave = lWerte_2[nPtr];
            nPtr++;
         }
         if (nPtr == 20)
         {
            // Beide Kan�le werden auf 100% abgeglichen 
            Sollwert[MASTER_CHANEL].fFloat = Sollwert[SLAVE_CHANEL].fFloat = 100;

            // Master
            Measurement_CalcCalibrationFactor(MASTER_CHANEL,Sollwert[MASTER_CHANEL],0);

            // Slave
            Measurement_CalcCalibrationFactor(SLAVE_CHANEL,Sollwert[SLAVE_CHANEL],0);
         }
         // Messwerte setzen
         Messwert[MASTER_CHANEL].nLong = lRohmesswert_Master;
         Messwert[SLAVE_CHANEL].nLong = lRohmesswert_Slave;
         // Sequentielle Messwertverarbeitung aufrufen und 20 als Index f�r die Korrekturfunktion �bergeben
         Measurement_Processing(MASTER_CHANEL,&Messwert[MASTER_CHANEL],20);
         Measurement_Processing(SLAVE_CHANEL,&Messwert[SLAVE_CHANEL],20);
         for (byChannel = MASTER_CHANEL;byChannel <= SLAVE_CHANEL; byChannel++)
         {
            // Ergebnisse auslesen
            Measurement_GetResults(byChannel,&Results[byChannel],0);

            // Nun �ber ein Makro die Nullpunkt korrigierten Werte,
            NullpunktKorrigierterMesswert[byChannel] = Measurement_GetResult(byChannel,MEASUREMENT_GET_PROVISIONAL,ZERO_CORRECTED_VALUE);
            // den Kanalabstand,
            Kanalabstand[byChannel] = Measurement_GetResult(byChannel,MEASUREMENT_GET_DEVIATION,0);

            // und den Kalibrierfaktor auslesen
            Kalibrierfaktor[byChannel] = Measurement_GetResult(byChannel,MEASUREMENT_GET_CALIBRATION,0);
         }
      }
   }
}
char Correction_Interface(MEASUREMENT_CORRECTIONPARAMETERS *pCorrectionParameters)
{
   switch (pCorrectionParameters->chHow2Correct)
   {
      case 0:
      {
         break;
      }
      case 1:
      {
         break;
      }
      case 2:
      {
         break;
      }
      case 3:
      {
         break;
      }
      case 4:
      {
         break;
      }
   }
   return 0;
}
char Filter_Interface(MEASUREMENT_FILTERPARAMETERS *pFilterParameters)
{
   return  AverageFilter_Filter(pFilterParameters->byChannel,pFilterParameters->pValue);
}
void Filter_Ini(unsigned char byMode)
{
   // Einen Filterkanal anlegen
   AverageFilter_Init(2);
   // Mittelwertfilter mit einer Filtertiefe von 10 anlegen, Long-Werte werden �bergeben 
   AverageFilter_Setup(MASTER_CHANEL,10,AVERAGEFILTER_LONGDATA);

   // Mittelwertfilter mit einer Filtertiefe von 10 anlegen, Long-Werte werden �bergeben 
   AverageFilter_Setup(SLAVE_CHANEL,10,AVERAGEFILTER_LONGDATA);
}
void Correction_Ini(unsigned char byMode)
{
   return;
}

\endcode
@endcond
*/ 
/*~E:A11*/
/*~A:12*/
/*~+:Globale R�ckgabewerte*/
/*~T*/
/*!
@cond FOR_LIBRARY_DOCS
\page GlobalReturnValues Globale R�ckgabewerte
\section sec_GlobalReturnValues_Measurement 'Messwertverarbeitung'

\retval
0 = Alles okay.

\retval
1 = Nicht gen�gend Speicherplatz f�r dynamische Variablen vorhanden.

\retval
2 = Angegebener Kanal existiert nicht.

\retval
3 = Datentyp existiert nicht.

\retval
4 = noch frei - R�ckgabewert kann noch vergeben werden !!!

\retval
5 = Es gibt keinen freien Speicher f�r Zwischenergebnisse.

\retval
6 = Angegebener Zwischenergebnis-Speicher existiert nicht.

\retval
7 = Messwert in Bewegung.

\retval
8 = Tarierung w�rde zu einem negativen Tara f�hren - Tarierung wird nicht durchgef�hrt.
@endcond
*/

/*~T*/
/*!
\addtogroup global_returns_externals
@cond FOR_APPLICATION_DOCS

\section sec_GlobalReturnValues_Measurement 'Messwertverarbeitung'

\retval
0 = Alles okay.

\retval
1 = Nicht gen�gend Speicherplatz f�r dynamische Variablen vorhanden.

\retval
2 = Angegebener Kanal existiert nicht.

\retval
3 = Datentyp existiert nicht.

\retval
4 = noch frei - R�ckgabewert kann noch vergeben werden !!!

\retval
5 = Es gibt keinen freien Speicher f�r Zwischenergebnisse.

\retval
6 = Angegebener Zwischenergebnis-Speicher existiert nicht.

\retval
7 = Messwert in Bewegung.

\retval
8 = Tarierung w�rde zu einem negativen Tara f�hren - Tarierung wird nicht durchgef�hrt.

@endcond
*/
/*~E:A12*/
/*~K*/
/*~+:*/
/*~A:13*/
/*~+:Beschreibungen extern zu definierenden Funktionen*/
/*~T*/
/*!
@cond FOR_LIBRARY_DOCS
\page ExternalFunctionsPage Extern zu definierende Funktionen
\section sec_ExternalFunctionsPage_Measurement 'Messwertverarbeitung'

char Filter_Interface(MEASUREMENT_FILTERPARAMETERS *pFilterParameters)<br>
char Correction_Interface(MEASUREMENT_CORRECTIONPARAMETERS *pCorrectionParameters)

@endcond
*/ 
/*~T*/
/*!
\addtogroup applikation_functions_externals
@cond FOR_APPLICATION_DOCS

\section sec_applikation_functions_externals 'Messwertverarbeitung'

<table border="1" width="100%" height="1%" rules="rows" cellspacing="0" bgcolor="#E0E0F0" cellpadding="3">
<tr align="left" valign="top>">
	<th>char Filter_Interface(MEASUREMENT_FILTERPARAMETERS *pFilterParameters)</th>
</tr>
</table>

<b>Beschreibung:</b><br>
Extern definierte Interface-Funktion zur Filterung des Messwertes.

\param
pFilterParameters: Filterparameter, welche dem Filter-Interface �bergeben wird. Das Resultat der Filterung ist ebenso hierin enthalten.

\return
Status der Filterung.

\retval
0    = Alles okay<BR>  
<> 0 = Fehler<BR>
(Achtung: das Filterinterface muss diese R�ckgaben treffen !!!)

<b>Zugriff:</b><br>
[X] �ffentlich / [ ] Privat
<BR>
<BR>
<BR>
<BR>
<BR>
<table border="1" width="100%" height="1%" rules="rows" cellspacing="0" bgcolor="#E0E0F0" cellpadding="3">
<tr align="left" valign="top>">
	<th>char Correction_Interface(MEASUREMENT_CORRECTIONPARAMETERS *pCorrectionParameters)</th>
</tr>
</table>

<b>Beschreibung:</b><br>
Extern definierte Interface-Funktion zur Korrektur des Messwertes.

\param
pCorrectionParameters: Korrekturparameter, welche dem Korrektur-Interface �bergeben wird. Das Resultat der Korrektur ist ebenso hierin enthalten.

\return
Status der Korrektur.

\retval
0    = Alles okay<BR>
<> 0 = Fehler<BR>
(Achtung: das Filterinterface muss diese R�ckgaben treffen !!!)

<b>Zugriff:</b><br>
[X] �ffentlich / [ ] Privat 

@endcond
*/
/*~A:14*/
/*~+:char Filter_Interface(MEASUREMENT_FILTERPARAMETERS *pFilterParameters)*/
/*~T*/
/*!
\fn char Filter_Interface(MEASUREMENT_FILTERPARAMETERS *pFilterParameters)

<b>Beschreibung:</b><br>
Extern definierte Interface-Funktion zur Filterung des Messwertes.

\param
pFilterParameters: Filterparameter, welche dem Filter-Interface �bergeben wird. Das Resultat der Filterung ist ebenso hierin enthalten.

\return
Status der Filterung.

\retval
0: Alles okay (Achtung: das Filterinterface muss diese R�ckgaben treffen !!!)  

<b>Zugriff:</b><br>
[X] �ffentlich / [ ] Privat
*/
/*~E:A14*/
/*~A:15*/
/*~+:char Correction_Interface(MEASUREMENT_CORRECTIONPARAMETERS *pCorrectionParameters)*/
/*~T*/
/*!
\fn char Correction_Interface(MEASUREMENT_CORRECTIONPARAMETERS *pCorrectionParameters)

<b>Beschreibung:</b><br>
Extern definierte Interface-Funktion zur Korrektur des Messwertes.

\param
pCorrectionParameters: Korrekturparameter, welche dem Korrektur-Interface �bergeben wird. Das Resultat der Korrektur ist ebenso hierin enthalten.

\return
Status der Korrektur.

\retval
0: Alles okay (Achtung: das Filterinterface muss diese R�ckgaben treffen !!!)

<b>Zugriff:</b><br>
[X] �ffentlich / [ ] Privat
*/
/*~E:A15*/
/*~E:A13*/
/*~E:A3*/
/*~A:16*/
/*~+:Konfiguration*/
/*~T*/
#define MEASUREMENT_MIT_FILTERSCHNITTSTELLE
#define MEASUREMENT_MIT_KORREKTURSCHNITTSTELLE
/*~T*/
#define MEASUREMENT_NB_CHANELS			2
/*~T*/
#define MEASUREMENT_MOTION_OHNE_FILTER		// Motion-Untersuchung ohne Filterung 
/*~T*/
#define MEASUREMENT_ALLOW_NEG_TARE			// negatives Tara erlauben
/*~E:A16*/
/*~A:17*/
/*~+:Definitionen*/
/*~T*/
#define MEASUREMENT_LONGDATA			0
#define MEASUREMENT_FLOATDATA			1

/*~T*/
#define MEASUREMENT_PROCESSING_ZERO							1
///< Nullpunktkorrektur durchf�hren
#define MEASUREMENT_PROCESSING_STANDARDIZATION				2
///< Normierung durchf�hren
///< Parameter: 
///< 0 = Datentyp des Ausgangsdatum ist identisch mit dem des Eingangsdatums
///< 1 = Ausgangsdatum liegt als Float vor
#define MEASUREMENT_PROCESSING_CORRECTION					3
///< Externe Funktion zur Korrektur aufrufen
#define MEASUREMENT_PROCESSING_FILTER						4
///< Externe Funktion zur Filterung aufrufen
#define MEASUREMENT_PROCESSING_MOTION						5
///< Untersuchung des Messwertes auf Bewegung
#define MEASUREMENT_PROCESSING_STORERESULT					6
///< Zwischenergebnis abspeichern
#define MEASUREMENT_PROCESSING_RESOLVE						7
///< Rundungsfunktion
#define MEASUREMENT_PROCESSING_TARE							100
///< Netto,Tara und Bruttoberechnung

/*~T*/
#define MEASUREMENT_CALC_TARE		0x01
///< Am Ende der sequentiallen Abarbeitung soll noch eine Tara-Verrechnung ausgef�hrt werden
/*~A:18*/
/*~+:Definitionen zur Ergebnisausgabe*/
/*~T*/
/*#LJ:Definitionen=133*/
#define MEASUREMENT_GET_NET				0x00	///< Ausgabe des Nettowertes
#define MEASUREMENT_GET_TARE			0x01	///< Ausgabe des Tarawertes
#define MEASUREMENT_GET_GROSS			0x02	///< Ausgabe des Bruttowertes
#define MEASUREMENT_GET_ZERO			0x03	///< Ausgabe des Nullpunktes
#define MEASUREMENT_GET_ZEROCORRECTED_MEASUREMENT	0x04 ///< Ausgabe des Nullpunkt korrigierten Messwertes
#define MEASUREMENT_GET_CALIBRATION		0x05	///< Ausgabe des Kalibrierfaktors
#define MEASUREMENT_GET_MOTION			0x09	///< Ausgabe der Messwertbewegung
#define MEASUREMENT_GET_MOTIONSTATUS	0x0A	///< Ausgabe des Zustands der Messwertbewegung
/*~E:A18*/
/*~A:19*/
/*~+:Makros zur Ergebnisausgabe*/
/*~T*/
#define MEASUREMENT_GETRESULT_NET(A,B)		Measurement_GetResult(A,MEASUREMENT_GET_NET,0,&B);
///< Makro zur Ausgabe des Nettowertes

#define MEASUREMENT_GETRESULT_TARE(A,B)		Measurement_GetResult(A,MEASUREMENT_GET_TARE,0,&B);
///< Makro zur Ausgabe des Tarawertes 

#define MEASUREMENT_GETRESULT_GROSS(A,B)		Measurement_GetResult(A,MEASUREMENT_GET_GROSS,0,&B);
///< Makro zur Ausgabe des Bruttowertes 

#define MEASUREMENT_GETRESULT_ZERO(A,B)		Measurement_GetResult(A,MEASUREMENT_GET_ZERO,0,&B);
///< Makro zur Ausgabe des Nullpunktes 

/*~E:A19*/
/*~E:A17*/
/*~A:20*/
/*~+:Struktur-Definitionen*/
/*~A:21*/
/*~+:MEASUREMENT_VALUE*/
/*~T*/
typedef union
{
	long nLong;			///< Long-Wert.
	float fFloat;		///< Float-Wert.
}MEASUREMENT_VALUE;		///< UNION zur Speicherung von Long- oder Float-Werten.
/*~E:A21*/
/*~A:22*/
/*~+:MEASUREMENT_RESULTS*/
/*~T*/
/*#LJ:MEASUREMENT_RESULTS=455*/
typedef struct
{
	MEASUREMENT_VALUE Zero;				///< Nullpunkt
	float fCalibrationFactor;			///< Kalibrierfaktor
	MEASUREMENT_VALUE Net;				///< Netto-Messwert
	MEASUREMENT_VALUE Tare;				///< Tara-Messwert
	MEASUREMENT_VALUE Gross;			///< Brutto-Messwert
	MEASUREMENT_VALUE* pProvisionalResult;	///< Zeiger auf die Zwischenergebnisse
	MEASUREMENT_VALUE Motion;			///< Messwertbewegung
	unsigned char bMotion;				///< Kennzeichner der Gewichtsbewegung

}MEASUREMENT_RESULTS;
/*~E:A22*/
/*~A:23*/
/*~+:MEASUREMENT_MOTIONPARAMETER*/
/*~T*/
typedef struct
{
	float fMotionLimit;	///< Grenzwert zur Erkennung einer Messwertbewegung
//	unsigned char byMotionCheckOn;	///< gibt an, ob eine Motion-Pr�fung stattfinden soll
	unsigned char byMotionFilter;	///< Erst bei byMotionFilter maligem �berschreiten des Grenzwertes, wird eine Messwertbewegung erkannt

/*~I:24*/
#ifndef MEASUREMENT_MOTION_OHNE_FILTER 
/*~T*/
	unsigned char byNoMotionFilter;	///< Erst bei byNoMotionFilter maligem �berschreiten des Grenzwertes, wird eine Messwertberuhigung erkannt

/*~-1*/
#endif
/*~E:I24*/
/*~T*/
}MEASUREMENT_MOTIONPARAMETER;
/*~E:A23*/
/*~E:A20*/
/*~A:25*/
/*~+:Funktionsdeklarationen*/
/*~T*/
extern char 	Measurement_CalcCalibrationFactor(unsigned char byChannel,MEASUREMENT_VALUE SetValue, unsigned char byMode);
/*~T*/
/*!
\fn char Measurement_CalcCalibrationFactor(unsigned char byChannel,MEASUREMENT_VALUE SetValue)

<b>Beschreibung:</b><br>
Berechnet aus dem zuletztermitteltem Gewichtswertwert und einem vorgegebenen Sollwert den Kalibrierfaktor. Die Berechnung findet aber nur bei Messwertbewegungsstillstand statt. 

\param
byChannel: Messwertkanal, f�r den der Kalibrierfaktor berechnet werden soll.

\param
SetValue: Sollwert des normierten Messwertes.


\return
Status der Berechnung des Kalibrierfaktors.

\retval
0: Alles okay.

\retval
2: Angegebener Kanal existiert nicht.

\retval
7: Messwertbewegung registriert - eine Berechnung des Kalibrierfaktors ist nicht m�glich.

<b>Zugriff:</b><br>
[X] �ffentlich / [ ] Privat

\ref
ExamplePage_Measurement "Beispiel 'Messwertverarbeitung'"

*/
/*~T*/
extern void 	Measurement_CalcResolution(float *pfValue,float fResolution);

extern char 	Measurement_GetCalibrationFactor(unsigned char byChannel,float *pfCalibrationFactor);

//extern char 	Measurement_GetMotion(unsigned char byChannel,unsigned char *byMotion);

extern char 	Measurement_GetMotionParameter(unsigned char byChannel,MEASUREMENT_MOTIONPARAMETER* pMotionParameter);

extern char 	Measurement_GetResolution(unsigned char byChannel,float* pfResolution);

extern char 	Measurement_GetResult(unsigned char byChannel,unsigned char byWhat2Get,MEASUREMENT_VALUE *pResult);

extern char 	Measurement_GetResults(unsigned char byChannel,MEASUREMENT_RESULTS *pValues,float fResolution);

extern char 	Measurement_GetZero(unsigned char byChannel,MEASUREMENT_VALUE *pZero);

extern void 	Measurement_Init(void);

extern char 	Measurement_IsMotion(unsigned char byChannel);

extern char 	Measurement_Processing(unsigned char chWhat2Process,unsigned char chChanel,MEASUREMENT_VALUE* Messwert);

extern char 	Measurement_SetCalibrationFactor(unsigned char byChannel,float fCalibrationFactor);

extern char 	Measurement_SetMotionParameter(unsigned char byChannel,MEASUREMENT_MOTIONPARAMETER MotionParameter);

extern char 	Measurement_SetResolution(unsigned char byChannel,float fResolution);

extern char 	Measurement_SetTareValue(unsigned char byChannel,float* pfTare);

extern char 	Measurement_SetTare(unsigned char byChannel,float* pfTare);

extern char 	Measurement_SettleZero(unsigned char byChannel,MEASUREMENT_VALUE* pValue);

extern char 	Measurement_SetZero(unsigned char byChannel);

extern char 	Measurement_SetZeroValue(unsigned char byChannel,MEASUREMENT_VALUE *pZero);
extern char* 	Measurement_Version(void);
/*~A:26*/
/*~+:Deklarationen externer Funktionen - bitte nicht �ndern !!!*/
/*~I:27*/
#ifdef MEASUREMENT_MIT_FILTERSCHNITTSTELLE 
/*~T*/
extern char Filter_Interface(unsigned char byChannel,MEASUREMENT_VALUE *pMeasurement2Filter);

/*~-1*/
#endif
/*~E:I27*/
/*~I:28*/
#ifdef MEASUREMENT_MIT_KORREKTURSCHNITTSTELLE
/*~T*/
extern char Correction_Interface(unsigned char byChannel,MEASUREMENT_VALUE *pMeasurement2Correct);
/*~-1*/
#endif
/*~E:I28*/
/*~E:A26*/
/*~E:A25*/
/*~A:29*/
/*~+:Variablen*/
/*~T*/

/*~E:A29*/
/*~-1*/
#endif
/*~E:I1*/
