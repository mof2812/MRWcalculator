/*~-1*/
/*~XSF_LANGUAGE: C/C++*/
/*~K*/
/*~+:File :        Global.c*/
/*~+:*/
/*~+:Version :     V1.0*/
/*~+:*/
/*~+:Date :        17.03.2005*/
/*~+:*/
/*~+:Time :        10:23*/
/*~+:*/
/*~+:Author :      MOF*/
/*~+:*/
/*~+:Hardware :*/
/*~+:*/
/*~+:Description :*/
/*~+:*/
/*~+:*/
/*~A:1*/
/*~+:Includes*/
/*~T*/
#include "Global.h"
/*~E:A1*/
/*~A:2*/
/*~+:Projektglobale Definitionen*/
/*~T*/

/*~E:A2*/
/*~A:3*/
/*~+:Projektglobale Struktur-Definitionen*/
/*~T*/

/*~E:A3*/
/*~A:4*/
/*~+:Projektglobale Funktionsprototypen*/
/*~T*/


/*~E:A4*/
/*~A:5*/
/*~+:Projektglobale Variablen*/
/*~A:6*/
/*~+:Speicherplatz f�r Dynamische Variablen*/
/*~T*/
unsigned char volatile xdata ptrDynVar[SIZE_DYNAMIC_VARIABLES] _at_ 0x0010; // _at_ 0x7FF - SIZE_DYNAMIC_VARIABLES;
/*~E:A6*/
/*~A:7*/
/*~+:Timerflags*/
/*~T*/
bit Flag100ms;
bit Flag300ms;
bit Flag500ms;
bit Flag1000ms;
bit Flag2000ms;
bit Flag10000ms;
/*~E:A7*/
/*~A:8*/
/*~+:Allgemeine Variablen*/
/*~T*/
GLOBAL Global;
long g_lWeightOffset4Limitest = 0;	// Offset zur Grenzwertpr�fung;
/*~E:A8*/
/*~E:A5*/
