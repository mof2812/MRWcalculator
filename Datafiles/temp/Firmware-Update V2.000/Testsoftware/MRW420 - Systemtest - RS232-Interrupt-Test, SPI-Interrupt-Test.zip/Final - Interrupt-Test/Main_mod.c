/*~-1*/
/*~XSF_LANGUAGE: C/C++*/
/*~A:1*/
/*~+:Versions-Beschreibung*/
/*~A:2*/
/*~+:Version und Versionsdatum*/
/*~T*/
/*!
\mainpage "Modul-Beschreibung"
\author Michael Offenbach
\date 31.12.2005
\version V1.000
\warning
*/
/*~E:A2*/
/*~A:3*/
/*~+:Ziel-Hardware*/
/*~T*/
/*!\page HardwarePage Ziel-Hardware

\section sec_HardwarePage_MRW420 'Applikation MRW420'

<table border=1 width=100% height=1% rules=rows cellspacing=0 bgcolor="#E0E0F0">

<tr align=left valign=top>
	<th>Motherboard</th>
	<th>Prozessor</th>
	<th>ROM</th>
	<th>RAM</th>
</tr>

<tr>
	<td>MRW420 </td>
	<td>8051-Core</td>
	<td>62 <B>kByte</B></td>
	<td>2 <B>kByte</B></td>
</tr></table>

*/
/*~E:A3*/
/*~A:4*/
/*~+:Compiler-Einstellungen*/
/*~T*/
/*!\page CompilerPage Compiler-Einstellungen

\section sec_CompilerPage_MRW420 'Applikation MRW420'

<table border=1 width=100% height=1% rules=rows cellspacing=0 bgcolor="#E0E0F0">

<tr align=left valign=top>
	<th>Compiler</th>
	<th>Betriebssystem</th>
	<th>Speichermodell</th>
	<th>Code-Speicher-Gr��e</th>
	<th>Optimierungen</th>
	<th>Sonstiges</th>
</tr>

<tr>
	<td>Keil uVision2 V2.40<BR>C51 V7.08<BR>A51 V7.08a</td>
	<td>Kein Betriebssystem</td>
	<td>Large: variables in XDATA</td>
	<td>Large: 64k program</td>
	<td>
	[ ] 0 Constant Folding<BR>
	[ ] 1 Dead Code Elimination<BR>
	[ ] 2 Data Overlaying<BR>
	[ ] 3 Peephole Optimization<BR>
	[ ] 4 Register Variables<BR>
	[ ] 5 Common Subexpression Elimination<BR>
	[X] 6 Loop Rotation<BR>
	[ ] 7 Extended Index Access Optimizing<BR>
	[ ] 8 Reuse Common Entry Code<BR>
	[ ] 9 Common Block Subroutines<BR>
	<BR>
	[X]Favor size<BR>
	[ ]Favor speed</td>
	<td>---</td>
</tr></table>

*/
/*~E:A4*/
/*~A:5*/
/*~+:Ressourcen*/
/*~T*/
/*!\page RessourcePage Ressourcen

\section sec_RessourcePage_MRW420 'Applikation MRW420'

<table border=1 width=100% height=1% rules=rows cellspacing=0 bgcolor="#E0E0F0">

<tr align=left valign=top>
	<th>CODE</th>
	<th>IDATA</th>
	<th>XDATA</th>
	<th>Dynamische Variablen</th>
</tr>

<tr>
	<td>--- <B>Bytes</B></td>
	<td>--- <B>Bytes</B></td>
	<td>--- <B>Bytes</B></td>
	<td>(2*(Anzahl der Sequenzeintr�ge+1)+46) * Anzahl der Messwertkan�le <B>Bytes</B></td>
</tr></table>

*/
/*~E:A5*/
/*~A:6*/
/*~+:Zykluszeiten*/
/*~T*/
/*!\page CycletimePage Zykluszeiten

\section sec_CycletimePage_MRW420 'Applikation MRW420'

<table border=1 width=100% height=1% rules=rows cellspacing=0 bgcolor="#E0E0F0">

<tr align=left valign=top>
	<th>Minimale Durchlaufzeit</th>
	<th>Maximale Durchlaufzeit</th>
</tr>

<tr>
	<td>--- <B>ms</B></td>
	<td>--- <B>ms</B></td>
</tr></table>

*/
/*~E:A6*/
/*~A:7*/
/*~+:Verschiedenes*/
/*~T*/
/*!\page MiscPage Verschiedenes

\section sec_MiscPage_MRW420 'Applikation MRW420'

<table border=1 width=100% height=1% rules=rows cellspacing=0 bgcolor="#E0E0F0">

<tr align=left valign=top>
	<th>Benutzte Interrups</th>
	<th>Benutzte Registerb�nke</th>
</tr>

<tr>
	<td>4,6</td>
	<td>---</td>
</tr></table>

*/
/*~E:A7*/
/*~A:8*/
/*~+:Lifecycle*/
/*~T*/
/*!\page LifeCyclePage Lifecycle

\section sec_LifeCyclePage_MRW420 'Applikation MRW420'

<table border=1 width=100% height=1% rules=rows cellspacing=0 bgcolor="#E0E0F0">

<tr align=left valign=top>
	<th>Version</th>
	<th>Datum</th>
	<th>Programmierer</th>
	<th>�nderungen</th>
</tr>

<tr>
	<td>1.100</td>
	<td>04.08.08</td>
	<td>Michael Offenbach</td>
	<td>Erste lauff�hige Version</td>
</tr>
</table>

*/
/*~E:A8*/
/*~E:A1*/
/*~K*/
/*~+:*/
/*~A:9*/
/*~+:Includes*/
/*~T*/
#include "Global.h"
#include "Version.h"
#include <Stdlib.h>
#include <Stdio.h>
#include <String.h>
/*~E:A9*/
/*~T*/
extern SPI_T SPI;
/*~A:10*/
/*~+:Funktionseigene Definitionen*/
/*~T*/

/*~E:A10*/
/*~A:11*/
/*~+:Funktionseigene Struktur-Definitionen*/
/*~T*/

/*~E:A11*/
/*~A:12*/
/*~+:Funktionsprototypen*/
/*~I:13*/
#ifdef SYSTEM_CND_PRINT_SPI_ERRORS
/*~T*/
void Main_Check4SPIErrors(void);

/*~-1*/
#endif
/*~E:I13*/
/*~T*/
void Main_ClearTimerFlags(void);
unsigned long Main_Init(void);
void Main_SetTimerFlags(void);

/*~E:A12*/
/*~T*/
void ADuC836_SPIInterruptCallback(char* pRecBuffer);
/*~A:14*/
/*~+:Globale Variablen*/
/*~T*/

/*~E:A14*/
/*~A:15*/
/*~+:void Main(void)*/
/*~F:16*/
void Main(void)
/*~-1*/
{
   /*~A:17*/
   /*~+:Variablendeklarationen*/
   /*~T*/
   unsigned char 	*ptrTest;					// Speicherplatzpr�fung 'Dynamische Variablen'
   unsigned char 	byFailed;
   unsigned char 	byCounter;
   /*~I:18*/
#ifdef CHANNEL_0
   /*~T*/
   unsigned char 	byInitializationReady;
   unsigned char 	byPrintState;

   /*~-1*/
#endif
   /*~E:I18*/
   /*~E:A17*/
   /*~A:19*/
   /*~+:Variableninitialisierungen*/
   /*~T*/
   byFailed = 0;
   byCounter = 3;
   /*~I:20*/
#ifdef CHANNEL_0
   /*~T*/
   byInitializationReady = 0;
   byPrintState = 0;
   /*~-1*/
#endif
   /*~E:I20*/
   /*~E:A19*/
   /*~T*/
   // Interne Taktrate: 12 MHz
   PLLCON = 0;
   /*~T*/
   // Dynamischen Speicherbereich festlegen
   init_mempool(ptrDynVar,sizeof(ptrDynVar));
   /*~A:21*/
   /*~+:Initialisierung*/
   /*~I:22*/
   if (!Main_Init())
   /*~-1*/
   {
      /*~T*/
      // Intialisierung fehlerfrei abgelaufen
      /*~A:23*/
      /*~+:ausgeklammert*/
      /*~I:24*/
#ifdef MOF
      /*~I:25*/
#ifdef CHANNEL_0
      /*~I:26*/
      if (!SYSTEM_MRW_MANAGER)
      /*~-1*/
      {
         /*~T*/
         Communication_SendString(COMMUNICATION_RS232,T_TEXT_SYSTEM_INITIALISATION,1,0);

         Communication_SendString(COMMUNICATION_RS232,T_TEXT_2_OKAY,0,0);
      /*~-1*/
      }
      /*~E:I26*/
      /*~-1*/
#endif
      /*~E:I25*/
      /*~-1*/
#endif
      /*~E:I24*/
      /*~E:A23*/
   /*~-1*/
   }
   /*~O:I22*/
   /*~-2*/
   else
   {
      /*~T*/
      // Fehler bei der Initialisierung
      /*~A:27*/
      /*~+:ausgeklammert*/
      /*~I:28*/
#ifdef MOF
      /*~I:29*/
#ifdef CHANNEL_0
      /*~I:30*/
      if (!SYSTEM_MRW_MANAGER)
      /*~-1*/
      {
         /*~T*/
         Communication_SendMessage(COMMUNICATION_RS232,COMMUNICATION_NOK);
      /*~-1*/
      }
      /*~O:I30*/
      /*~-2*/
      else
      {
         /*~T*/
         Communication_SendString(COMMUNICATION_RS232,T_TEXT_SYSTEM_INITIALISATION,1,0);

         Communication_SendString(COMMUNICATION_RS232,T_TEXT_SYSTEM_INITIALISATION_ERROR,0,0);
      /*~-1*/
      }
      /*~E:I30*/
      /*~-1*/
#endif
      /*~E:I29*/
      /*~-1*/
#endif
      /*~E:I28*/
      /*~E:A27*/
      /*~T*/
      Diagnosis_SecurityInitialization(SYTEM_ERROR_INITIALIZATION);
   /*~-1*/
   }
   /*~E:I22*/
   /*~E:A21*/
   /*~A:31*/
   /*~+:Watchdog-�berwachung einschalten*/
   /*~T*/
   Watchdog_Ini();
   /*~E:A31*/
   /*~I:32*/
   /* ausgeklammert ab Version V1.009 */
#ifdef MOF
   /*~A:33*/
   /*~+:Docklight-Modus einschalten*/
   /*~T*/
   // Wenn das Docklight-Terminal angeschlossen ist, in den Docklight-Modus schalten

   /*~I:34*/
#ifdef CHANNEL_0
   /*~T*/
   // Wenn das Docklight-Terminal angeschlossen ist, in den Docklight-Modus schalten

   /*~I:35*/
#ifdef MIT_CRC16
   /*~T*/
   // Doch zun�chst die CRC16-Pr�fung ausschalten
   Communication_EnableCRC16(FALSE);

   /*~-1*/
#endif
   /*~E:I35*/
   /*~T*/
   Communication_SendString(COMMUNICATION_RS232,"ISDL",1,0);
   /*~I:36*/
#ifdef MIT_CRC16
   /*~T*/
   // Die CRC16-Pr�fung wieder einschalten
   Communication_EnableCRC16(TRUE);

   /*~-1*/
#endif
   /*~E:I36*/
   /*~T*/
   byFailed = 0;
   /*~U:37*/
   /*~-2*/
   do
   {
      /*~T*/
      System_Wait(100);
      /*~T*/
      InstructionDecoder();
   /*~-1*/
   }
   /*~O:U37*/
   /* neu ab Version V1.009 */
   while ((SYSTEM_MRW_MANAGER)&&(byFailed++ < 2));
   /* bis Version V1.008
   while ((SYSTEM_MRW_MANAGER)&&(byFailed++ < 5));
    */
   /*~E:U37*/
   /*~-1*/
#endif
   /*~E:I34*/
   /*~E:A33*/
   /*~-1*/
#endif
   /*~E:I32*/
   /*~A:38*/
   /*~+:Flags zur Signalisierung eines neuen Kommandos l�schen*/
   /*~T*/
   // Flags zur Signalisierung eines neuen Kommandos l�schen
   ADuC836_RS232SetNewCommandFlag(0);
   /*~E:A38*/
   /*~A:39*/
   /*~+:�berpr�fung, ob gen�gend dynamische Speicher vorhanden ist.*/
   /*~I:40*/
#ifdef CHANNEL_0
   /*~I:41*/
   if (!SYSTEM_MRW_MANAGER)
   /*~-1*/
   {
      /*~T*/
      Communication_SendString(COMMUNICATION_RS232,T_TEXT_SYSTEM_CHECK_DYNAMIC_VARIABLES_MEMORY,1,0);
   /*~-1*/
   }
   /*~E:I41*/
   /*~-1*/
#endif
   /*~E:I40*/
   /*~I:42*/
   ptrTest = (unsigned char*)malloc(1);

   if ((unsigned char)ptrTest == 0)
   /*~-1*/
   {
      /*~A:43*/
      /*~+:Nicht genug dynamischer Speicher vorhanden*/
      /*~I:44*/
#ifdef CHANNEL_0
      /*~I:45*/
      if (SYSTEM_MRW_MANAGER)
      /*~-1*/
      {
         /*~T*/
         Communication_SendMessage(COMMUNICATION_RS232,COMMUNICATION_NOK);
      /*~-1*/
      }
      /*~O:I45*/
      /*~-2*/
      else
      {
         /*~T*/
         Communication_SendString(COMMUNICATION_RS232,T_TEXT_SYSTEM_NOT_ENOUGH_MEMORY_4_DYNAMIC_VARIABLES,0,0);
      /*~-1*/
      }
      /*~E:I45*/
      /*~-1*/
#endif
      /*~E:I44*/
      /*~T*/
      Diagnosis_SecurityMemory(DYNAMIC_VARIABLES);
      /*~T*/
      // System-Reset ausf�hren
      System_Reset();
      /*~E:A43*/
   /*~-1*/
   }
   /*~O:I42*/
   /*~-2*/
   else
   {
      /*~A:46*/
      /*~+:okay*/
      /*~I:47*/
#ifdef CHANNEL_0
      /*~I:48*/
      if (!SYSTEM_MRW_MANAGER)
      /*~-1*/
      {
         /*~T*/
         Communication_SendString(COMMUNICATION_RS232,T_TEXT_2_OKAY,0,0);
      /*~-1*/
      }
      /*~E:I48*/
      /*~-1*/
#endif
      /*~E:I47*/
      /*~E:A46*/
   /*~-1*/
   }
   /*~E:I42*/
   /*~T*/
   free(ptrTest);
   /*~E:A39*/
   /*~I:49*/
#ifndef NO_STARTSYNC 
   /*~A:50*/
   /*~+:Synchronisation*/
   /*~A:51*/
   /*~+:Textausgabe Kanal 0*/
   /*~I:52*/
#ifdef CHANNEL_0
   /*~I:53*/
   if (!SYSTEM_MRW_MANAGER)
   /*~-1*/
   {
      /*~T*/
      Communication_SendString(COMMUNICATION_RS232,T_TEXT_SYSTEM_CHECK_SYNCHRONISATION,1,0);
   /*~-1*/
   }
   /*~E:I53*/
   /*~-1*/
#endif
   /*~E:I52*/
   /*~E:A51*/
   /*~T*/
   System_Synchronization();
   /*~T*/
   // Synchronisation abgeschlossen
   /*~A:54*/
   /*~+:Textausgabe Kanal 0*/
   /*~I:55*/
#ifdef CHANNEL_0
   /*~I:56*/
   if (!SYSTEM_MRW_MANAGER)
   /*~-1*/
   {
      /*~T*/
      Communication_SendString(COMMUNICATION_RS232,T_TEXT_2_OKAY,0,0);
   /*~-1*/
   }
   /*~E:I56*/
   /*~-1*/
#endif
   /*~E:I55*/
   /*~E:A54*/
   /*~E:A50*/
   /*~-1*/
#endif
   /*~E:I49*/
   /*~A:57*/
   /*~+:�berpr�fung auf vorhandene System-ID */
   /*~I:58*/
#ifdef CHANNEL_0
   /*~I:59*/
   if (!SYSTEM_MRW_MANAGER)
   /*~-1*/
   {
      /*~T*/
      Communication_SendString(COMMUNICATION_RS232,T_TEXT_SYSTEM_CHECK_ID,1,0);
   /*~-1*/
   }
   /*~E:I59*/
   /*~I:60*/
   if (!Global.ulSystemID)
   /*~-1*/
   {
      /*~A:61*/
      /*~+:Keine ID vergeben*/
      /*~I:62*/
      if (SYSTEM_MRW_MANAGER)
      /*~-1*/
      {
         /*~T*/
         Communication_SendMessage(COMMUNICATION_RS232,COMMUNICATION_NOK);
      /*~-1*/
      }
      /*~O:I62*/
      /*~-2*/
      else
      {
         /*~T*/
         Communication_SendString(COMMUNICATION_RS232,T_TEXT_SYSTEM_ID_MISSING,0,0);
      /*~-1*/
      }
      /*~E:I62*/
      /*~A:63*/
      /*~+:Eintrag in Diagnosespeicher vornehmen*/
      /*~T*/
      Diagnosis_WriteMessage2Flash(DIAGNOSIS_ERROR_ID);
      /*~E:A63*/
      /*~I:64*/
#ifdef SPAETER_WIEDER_EINBAUEN
      /*~L:65*/
      while (!Global.ulSystemID)
      /*~-1*/
      {
         /*~T*/
         // Systemfehler
         System_SetSystemState(SYSTEM_ERROR);
         /*~T*/
         InstructionDecoder();
         Digital();						///< Digitalkan�le zur Anzeige des System-Alarms
      /*~-1*/
      }
      /*~E:L65*/
      /*~-1*/
#endif
      /*~E:I64*/
      /*~E:A61*/
   /*~-1*/
   }
   /*~O:I60*/
   /*~-2*/
   else
   {
      /*~A:66*/
      /*~+:ID vorhanden*/
      /*~I:67*/
      if (!SYSTEM_MRW_MANAGER)
      /*~-1*/
      {
         /*~T*/
         // Communication_SendString(COMMUNICATION_RS232,T_TEXT_2_OKAY,0,0);
         Communication_SendLong(COMMUNICATION_RS232,0,(long)Global.ulSystemID,0,0);
      /*~-1*/
      }
      /*~E:I67*/
      /*~E:A66*/
   /*~-1*/
   }
   /*~E:I60*/
   /*~-1*/
#endif
   /*~E:I58*/
   /*~E:A57*/
   /*~I:68*/
   /* neu ab Version V1.009 */
#ifdef PRUEFE_SW_VERSIONEN 
   /*~A:69*/
   /*~+:�berpr�fung der Software-Versionen*/
   /*~I:70*/
#ifndef NO_VERSIONCHECK
   /*~I:71*/
#ifdef CHANNEL_0
   /*~I:72*/
   if (!SYSTEM_MRW_MANAGER)
   /*~-1*/
   {
      /*~T*/
      Communication_SendString(COMMUNICATION_RS232,T_TEXT_SYSTEM_CHECK_SOFTWARE_VERSIONS,1,0);
      /*~I:73*/
      if (System_CheckVersion())
      /*~-1*/
      {
         /*~A:74*/
         /*~+:Fehler bei der Versionspr�fung*/
         /*~A:75*/
         /*~+:Eintrag in Diagnosespeicher vornehmen*/
         /*~T*/
         Diagnosis_WriteMessage2Flash(DIAGNOSIS_ERROR_SOFTWARE_INCOMPATIBILITY);
         /*~E:A75*/
         /*~I:76*/
#ifdef CHANNEL_0
         /*~I:77*/
         if (SYSTEM_MRW_MANAGER)
         /*~-1*/
         {
            /*~T*/
            Communication_SendMessage(COMMUNICATION_RS232,COMMUNICATION_NOK);
         /*~-1*/
         }
         /*~O:I77*/
         /*~-2*/
         else
         {
            /*~T*/
            Communication_SendString(COMMUNICATION_RS232,T_TEXT_SYSTEM_SOFTWARE_INCOMPATIBLE,0,0);
         /*~-1*/
         }
         /*~E:I77*/
         /*~-1*/
#endif
         /*~E:I76*/
         /*~L:78*/
         while (1)
         /*~-1*/
         {
            /*~T*/
            // Systemfehler
            System_SetSystemState(SYSTEM_ERROR);
            /*~T*/
            InstructionDecoder();			///< Instruction-Dekoder wg. der M�glichkeit, sich den Diagnosespeicher anzusehen
            Digital();						///< Digitalkan�le zur Anzeige des System-Alarms
         /*~-1*/
         }
         /*~E:L78*/
         /*~E:A74*/
      /*~-1*/
      }
      /*~O:I73*/
      /*~-2*/
      else
      {
         /*~A:79*/
         /*~+:Softwaren sind kompatibel*/
         /*~I:80*/
#ifdef CHANNEL_0
         /*~I:81*/
         if (!SYSTEM_MRW_MANAGER)
         /*~-1*/
         {
            /*~T*/
            Communication_SendString(COMMUNICATION_RS232,T_TEXT_2_OKAY,0,0);
         /*~-1*/
         }
         /*~E:I81*/
         /*~-1*/
#endif
         /*~E:I80*/
         /*~E:A79*/
      /*~-1*/
      }
      /*~E:I73*/
   /*~-1*/
   }
   /*~E:I72*/
   /*~-1*/
#endif
   /*~E:I71*/
   /*~-1*/
#endif
   /*~E:I70*/
   /*~E:A69*/
   /*~-1*/
#endif
   /*~E:I68*/
   /*~A:82*/
   /*~+:Systemstart f�r Diagnose merken*/
   /*~T*/
   /* Systemstart f�r Diagnose merken */
   Diagnosis_SetSystemStart();
   /*~E:A82*/
   /*~I:83*/
   /* ausgeklammert ab Version V1.009 */
#ifdef MOF
   /*~A:84*/
   /*~+:Alles okay - SW-Versionen,Zellentyp,... ausgeben*/
   /*~T*/
   Diagnosis_SetSystemStart();
   /*~I:85*/
#ifdef CHANNEL_0
   /*~I:86*/
   if (SYSTEM_MRW_MANAGER)
   /*~-1*/
   {
      /*~T*/
      Communication_SendMessage(COMMUNICATION_RS232,COMMUNICATION_OK);
   /*~-1*/
   }
   /*~O:I86*/
   /*~-2*/
   else
   {
      /*~U:87*/
      /*~-2*/
      do
      {
         /*~C:88*/
         switch (byPrintState)
         /*~-1*/
         {
            /*~F:89*/
            case 0:
            /*~-1*/
            {
               /*~A:90*/
               /*~+:Hardware-Version ausgeben*/
               /*~T*/
               Communication_SendString(COMMUNICATION_RS232,T_TEXT_MOBA_AG_HW,2,0);
               /*~T*/
               Communication_SendString(COMMUNICATION_RS232,TEXT_HARDWARE_VERSION,0,1);
               /*~E:A90*/
               /*~T*/
               break;
            /*~-1*/
            }
            /*~E:F89*/
            /*~F:91*/
            case 1:
            /*~-1*/
            {
               /*~A:92*/
               /*~+:Software-Modul-Versionen ausgeben*/
               /*~T*/
               Version_PrintVersions(1);
               /*~E:A92*/
               /*~T*/
               break;
            /*~-1*/
            }
            /*~E:F91*/
            /*~F:93*/
            case 2:
            /*~-1*/
            {
               /*~A:94*/
               /*~+:Zellentyp ausgeben*/
               /*~T*/
               Communication_SendString(COMMUNICATION_RS232,T_TEXT_LOADCELL_TYPE,1,0);

               /*~C:95*/
               switch (g_SystemControl.byLoadCellType)
               /*~-1*/
               {
                  /*~F:96*/
                  case 1:
                  /*~-1*/
                  {
                     /*~T*/
                     Communication_SendString(COMMUNICATION_RS232,"Std-W�gezelle",0,0);

                     /*~T*/
                     break;
                  /*~-1*/
                  }
                  /*~E:F96*/
                  /*~F:97*/
                  case 2:
                  /*~-1*/
                  {
                     /*~T*/
                     Communication_SendString(COMMUNICATION_RS232,"XL-W�gezelle",0,0);

                     /*~T*/
                     break;
                  /*~-1*/
                  }
                  /*~E:F97*/
                  /*~O:C95*/
                  /*~-2*/
                  default:
                  {
                     /*~T*/
                     Communication_SendString(COMMUNICATION_RS232,"nicht definiert",0,0);

                  /*~-1*/
                  }
               /*~-1*/
               }
               /*~E:C95*/
               /*~E:A94*/
               /*~T*/
               break;
            /*~-1*/
            }
            /*~E:F93*/
            /*~F:98*/
            case 3:
            /*~-1*/
            {
               /*~A:99*/
               /*~+:Status der Temperaturkompensation*/
               /*~I:100*/
               if (MRW_Compensation_GetCompensationOnOffStatus())
               /*~-1*/
               {
                  /*~T*/
                  Communication_SendString(COMMUNICATION_RS232,T_TEXT_COMPENSATION_SWITCHED_ON,2,0);

               /*~-1*/
               }
               /*~O:I100*/
               /*~-2*/
               else
               {
                  /*~T*/
                  Communication_SendString(COMMUNICATION_RS232,T_TEXT_COMPENSATION_SWITCHED_OFF,2,0);

               /*~-1*/
               }
               /*~E:I100*/
               /*~E:A99*/
               /*~T*/
               break;
            /*~-1*/
            }
            /*~E:F98*/
            /*~F:101*/
            case 4:
            /*~-1*/
            {
               /*~A:102*/
               /*~+:Status der E-Modul-Kompensation*/
               /*~I:103*/
               if (Weight_GetEModulCompensationOnOff())
               /*~-1*/
               {
                  /*~T*/
                  Communication_SendString(COMMUNICATION_RS232,T_TEXT_E_MODUL_COMPENSATION_SWITCHED_ON,1,0);

               /*~-1*/
               }
               /*~O:I103*/
               /*~-2*/
               else
               {
                  /*~T*/
                  Communication_SendString(COMMUNICATION_RS232,T_TEXT_E_MODUL_COMPENSATION_SWITCHED_OFF,1,0);

               /*~-1*/
               }
               /*~E:I103*/
               /*~E:A102*/
               /*~T*/
               break;
            /*~-1*/
            }
            /*~E:F101*/
            /*~F:104*/
            case 5:
            /*~-1*/
            {
               /*~A:105*/
               /*~+:Status der Stromr�ckf�hrung*/
               /*~I:106*/
               if (CurrentInterface_GetFeedBackState())
               /*~-1*/
               {
                  /*~T*/
                  Communication_SendString(COMMUNICATION_RS232,T_TEXT_FEEDBACK_STATE_ON,1,0);

               /*~-1*/
               }
               /*~O:I106*/
               /*~-2*/
               else
               {
                  /*~T*/
                  Communication_SendString(COMMUNICATION_RS232,T_TEXT_FEEDBACK_STATE_OFF,1,0);

               /*~-1*/
               }
               /*~E:I106*/
               /*~E:A105*/
               /*~T*/
               break;
            /*~-1*/
            }
            /*~E:F104*/
         /*~-1*/
         }
         /*~E:C88*/
         /*~T*/
         // Da alle Ausgaben zusammen recht lange dauern, zyklisch den Watchdog neu antriggern
         Watchdog();
      /*~-1*/
      }
      /*~O:U87*/
      while (byPrintState++ < 0x06);
      /*~E:U87*/
   /*~-1*/
   }
   /*~E:I86*/
   /*~-1*/
#endif
   /*~E:I85*/
   /*~E:A84*/
   /*~A:107*/
   /*~+:ggf. in den Docklight-Modus wechseln*/
   /*~I:108*/
#ifdef CHANNEL_0
   /*~I:109*/
   if (!SYSTEM_MRW_MANAGER)
   /*~-1*/
   {
      /*~I:110*/
#ifdef SYSTEM_CND_DISABLE_SPI_COMMUNICATION_AT_FAULTS 
      /*~A:111*/
      /*~+:Mit Abschaltung der SPI-Kommunikation bei Ausfall der SPI-Schnittstelle*/
      /*~I:112*/
      if (!Communication_IsSPICommuncationDisabled())
      /*~-1*/
      {
         /*~U:113*/
         /*~-2*/
         do
         {
            /*~T*/
            Communication_SendSPICommand("iCDL");
         /*~-1*/
         }
         /*~O:U113*/
         while (!Communication_IsOK() && --byCounter);
         /*~E:U113*/
      /*~-1*/
      }
      /*~E:I112*/
      /*~E:A111*/
      /*~O:I110*/
      /*~-1*/
#else
      /*~A:114*/
      /*~+:Ohne Abschaltung der SPI-Kommunikation bei Ausfall der SPI-Schnittstelle*/
      /*~U:115*/
      /*~-2*/
      do
      {
         /*~T*/
         Communication_SendSPICommand("iCDL");
      /*~-1*/
      }
      /*~O:U115*/
      while (!Communication_IsOK() && --byCounter);
      /*~E:U115*/
      /*~E:A114*/
      /*~-1*/
#endif
      /*~E:I110*/
   /*~-1*/
   }
   /*~E:I109*/
   /*~T*/
   // Z�hler f�r sp�tere Benutzung l�schen
   byCounter = 0;
   /*~-1*/
#endif
   /*~E:I108*/
   /*~E:A107*/
   /*~-1*/
#endif
   /*~E:I83*/
   /*~A:116*/
   /*~+:RS232-Empfangspuffer l�schen*/
   /*~T*/
   ADuC836_RS232SetNewCommandFlag(0);
   /*~E:A116*/
   /*~T*/
   System_SetSystemState(SYSTEM_RUNNING);
   /*~I:117*/
#ifdef CHANNEL_0
   /*~A:118*/
   /*~+:Wenn das Docklight-Terminal angeschlossen ist, in den Docklight-Modus schalten*/
   /*~T*/
   // Wenn das Docklight-Terminal angeschlossen ist, in den Docklight-Modus schalten

   /*~I:119*/
#ifdef MIT_CRC16
   /*~T*/
   // Doch zun�chst die CRC16-Pr�fung ausschalten
   Communication_EnableCRC16(FALSE);

   /*~-1*/
#endif
   /*~E:I119*/
   /*~T*/
   Communication_SendString(COMMUNICATION_RS232,"ISDL",1,0);
   /*~I:120*/
#ifdef MIT_CRC16 
   /*~T*/
   // Jetzt die die CRC16-Pr�fung wieder zuschalten
   Communication_EnableCRC16(TRUE);
   /*~-1*/
#endif
   /*~E:I120*/
   /*~E:A118*/
   /*~-1*/
#endif
   /*~E:I117*/
   /*~K*/
   /*~+:*/
   /*~+:*/
   /*~+:// E N D L E S S L O O P //*/
   /*~+:*/
   /*~L:121*/
   while (1)
   /*~-1*/
   {
      /*~A:122*/
      /*~+:LED-Anzeige zur Zykluszeitermittlung*/
      /*~I:123*/
#ifdef SYSTEM_CND_LEDS_4_DEBUG_P06_CYCLETIME
      /*~T*/
      P06 = !P06;
      /*~-1*/
#endif
      /*~E:I123*/
      /*~E:A122*/
      /*~A:124*/
      /*~+:Zeitflags setzen*/
      /*~T*/
      // Zeitflags setzen
      Main_SetTimerFlags();
      /*~E:A124*/
      /*~I:125*/
      if (Global.Mode.bySetStateManualy)
      /*~-1*/
      {
         /*~T*/
         // Betriebszustand wird manuel gesetzt

      /*~-1*/
      }
      /*~E:I125*/
      /*~I:126*/
#ifndef MIT_TEACHIN_FUNKTION 
      /*~T*/
      InstructionDecoder();			///< Befehlsbearbeitung
      /*~O:I126*/
      /*~-1*/
#else
      /*~I:127*/
      if (!TeachInModul_IsModulActive())
      /*~-1*/
      {
         /*~T*/
         // TeachIn-Modul ist nicht aktiv
         InstructionDecoder();			///< Befehlsbearbeitung

      /*~-1*/
      }
      /*~E:I127*/
      /*~-1*/
#endif
      /*~E:I126*/
      /*~I:128*/
#ifdef SYSTEM_CND_LEDS_4_DEBUG_P06_MISC_2
      /*~T*/
      P06 = 1;
      /*~-1*/
#endif
      /*~E:I128*/
      /*~T*/
      Weight();
      /*~I:129*/
#ifdef SYSTEM_CND_LEDS_4_DEBUG_P06_MISC_2
      /*~T*/
      P06 = 0;
      /*~-1*/
#endif
      /*~E:I129*/
      /*~T*/
      System();						///< Systemparameter austauschen
      Analog();						///< Analogeing�nge
      Compensation();					///< Temperaturkompensation

      /*~I:130*/
#ifndef SPEZIALVERSION_FUER_TESTSYSTEME
      /*~T*/
      // CurrentInterface(Weight_ZeroCorrectedMeasurement.nLong);			///< ohne Tara
      CurrentInterface(Weight_ZeroCorrectedMeasurementWithTare.nLong + g_lWeightOffset4Limitest);	///< Stromausgang
      /*~O:I130*/
      /*~-1*/
#else
      /*~T*/
      CurrentInterface(g_Weight_lSimulatedRMW); // Stromausgang mit vorgegebenem Stromwert setzen
      /*~-1*/
#endif
      /*~E:I130*/
      /*~T*/
      Digital();						///< Digitalkan�le
      /*~I:131*/
      if (Flag100ms)
      /*~-1*/
      {
         /*~T*/
         Limit();						///< Grenzwert�berwachung
         /*~I:132*/
#ifdef MIT_TEACHIN_FUNKTION
         /*~T*/
         TeachInModul();					///< TeachIn-Modul
         /*~-1*/
#endif
         /*~E:I132*/
         /*~A:133*/
         /*~+:bis Version V1.008*/
         /*~F:134*/
         /* bis Version V1.008 */

         /*~-1*/
         {
            /*~I:135*/
#ifdef MOF
            /*~T*/
            Watchdog();						///< Watchdog

            /*~-1*/
#endif
            /*~E:I135*/
         /*~-1*/
         }
         /*~E:F134*/
         /*~E:A133*/
      /*~-1*/
      }
      /*~E:I131*/
      /*~K*/
      /*~+:*/
      /*~I:136*/
      if (Flag300ms)
      /*~-1*/
      {
         /*~F:137*/
         /* neu ab Version V1.009 */
         /*~-1*/
         {
            /*~A:138*/
            /*~+:Kanal 0: Beim zweiten Eintreffen SW-Versionen,Zellentyp,... im Docklightmodus ausgeben*/
            /*~I:139*/
#ifdef CHANNEL_0
            /*~C:140*/
            switch (byInitializationReady)
            /*~-1*/
            {
               /*~F:141*/
               case 0:
               /*~-1*/
               {
                  /*~T*/
                  byInitializationReady++;
                  /*~T*/
                  break;
               /*~-1*/
               }
               /*~E:F141*/
               /*~F:142*/
               case 1:
               /*~-1*/
               {
                  /*~T*/
                  byInitializationReady++;
                  /*~I:143*/
                  if (!SYSTEM_MRW_MANAGER)
                  /*~-1*/
                  {
                     /*~U:144*/
                     /*~-2*/
                     do
                     {
                        /*~C:145*/
                        switch (byPrintState)
                        /*~-1*/
                        {
                           /*~F:146*/
                           case 0:
                           /*~-1*/
                           {
                              /*~A:147*/
                              /*~+:Hardware-Version ausgeben*/
                              /*~T*/
                              Communication_SendString(COMMUNICATION_RS232,T_TEXT_MOBA_AG_HW,2,0);
                              /*~T*/
                              Communication_SendString(COMMUNICATION_RS232,TEXT_HARDWARE_VERSION,0,1);
                              /*~E:A147*/
                              /*~T*/
                              break;
                           /*~-1*/
                           }
                           /*~E:F146*/
                           /*~F:148*/
                           case 1:
                           /*~-1*/
                           {
                              /*~A:149*/
                              /*~+:Software-Modul-Versionen ausgeben*/
                              /*~T*/
                              Version_PrintVersions(1);
                              /*~E:A149*/
                              /*~T*/
                              break;
                           /*~-1*/
                           }
                           /*~E:F148*/
                           /*~F:150*/
                           case 2:
                           /*~-1*/
                           {
                              /*~A:151*/
                              /*~+:Zellentyp ausgeben*/
                              /*~T*/
                              Communication_SendString(COMMUNICATION_RS232,T_TEXT_LOADCELL_TYPE,1,0);

                              /*~C:152*/
                              switch (g_SystemControl.byLoadCellType)
                              /*~-1*/
                              {
                              /*~F:153*/
                              case 1:
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendString(COMMUNICATION_RS232,"Std-W�gezelle",0,0);

                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F153*/
                              /*~F:154*/
                              case 2:
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendString(COMMUNICATION_RS232,"XL-W�gezelle",0,0);

                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F154*/
                              /*~O:C152*/
                              /*~-2*/
                              default:
                              {
                              /*~T*/
                              Communication_SendString(COMMUNICATION_RS232,"nicht definiert",0,0);

                              /*~-1*/
                              }
                              /*~-1*/
                              }
                              /*~E:C152*/
                              /*~E:A151*/
                              /*~T*/
                              break;
                           /*~-1*/
                           }
                           /*~E:F150*/
                           /*~F:155*/
                           case 3:
                           /*~-1*/
                           {
                              /*~A:156*/
                              /*~+:Status der Temperaturkompensation*/
                              /*~I:157*/
                              if (MRW_Compensation_GetCompensationOnOffStatus())
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendString(COMMUNICATION_RS232,T_TEXT_COMPENSATION_SWITCHED_ON,2,0);

                              /*~-1*/
                              }
                              /*~O:I157*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              Communication_SendString(COMMUNICATION_RS232,T_TEXT_COMPENSATION_SWITCHED_OFF,2,0);

                              /*~-1*/
                              }
                              /*~E:I157*/
                              /*~E:A156*/
                              /*~T*/
                              break;
                           /*~-1*/
                           }
                           /*~E:F155*/
                           /*~F:158*/
                           case 4:
                           /*~-1*/
                           {
                              /*~A:159*/
                              /*~+:Status der E-Modul-Kompensation*/
                              /*~I:160*/
                              if (Weight_GetEModulCompensationOnOff())
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendString(COMMUNICATION_RS232,T_TEXT_E_MODUL_COMPENSATION_SWITCHED_ON,1,0);

                              /*~-1*/
                              }
                              /*~O:I160*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              Communication_SendString(COMMUNICATION_RS232,T_TEXT_E_MODUL_COMPENSATION_SWITCHED_OFF,1,0);

                              /*~-1*/
                              }
                              /*~E:I160*/
                              /*~E:A159*/
                              /*~T*/
                              break;
                           /*~-1*/
                           }
                           /*~E:F158*/
                           /*~F:161*/
                           case 5:
                           /*~-1*/
                           {
                              /*~A:162*/
                              /*~+:Status der Stromr�ckf�hrung*/
                              /*~I:163*/
                              if (CurrentInterface_GetFeedBackState())
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendString(COMMUNICATION_RS232,T_TEXT_FEEDBACK_STATE_ON,1,0);

                              /*~-1*/
                              }
                              /*~O:I163*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              Communication_SendString(COMMUNICATION_RS232,T_TEXT_FEEDBACK_STATE_OFF,1,0);

                              /*~-1*/
                              }
                              /*~E:I163*/
                              /*~E:A162*/
                              /*~T*/
                              break;
                           /*~-1*/
                           }
                           /*~E:F161*/
                           /*~F:164*/
                           case 6:
                           /*~-1*/
                           {
                              /*~A:165*/
                              /*~+:Wandlungsrate der Gewichtsermittlung*/
                              /*~T*/
                              /* Die Wandlungsrate muss durch vier geteilt werden, da der ADC im Togglebetrieb l�uft. D.h. es wird nur mit bei jeder zweiten Wandlung der DMS-Messwert ermittelt - bei der anderen Messung der Rohmesswert der Stromr�ckf�hrung. Zudem wird bei jeder Umschaltung ein Reset der ADCs ausgef�hrt, was zur Folge hat, dass der Messwert erst nach zweiten Wandlung zur Verf�gung steht.
                              /*~T*/
                              Communication_SendFloat(COMMUNICATION_RS232,TEXT_WEIGHT_CONVERSIONRATE_CHANNEL_0,ADuC836_ADCGetConversionRate(ADuC836_ADC_FREQUENCY_32KHZ)/4,2,1,0);
                              /*~E:A165*/
                              /*~T*/
                              break;
                           /*~-1*/
                           }
                           /*~E:F164*/
                        /*~-1*/
                        }
                        /*~E:C145*/
                        /*~T*/
                        // Da alle Ausgaben zusammen recht lange dauern, zyklisch den Watchdog neu antriggern
                        Watchdog();
                     /*~-1*/
                     }
                     /*~O:U144*/
                     while (byPrintState++ < 0x07);
                     /*~E:U144*/
                  /*~-1*/
                  }
                  /*~E:I143*/
                  /*~T*/
                  break;
               /*~-1*/
               }
               /*~E:F142*/
            /*~-1*/
            }
            /*~E:C140*/
            /*~-1*/
#endif
            /*~E:I139*/
            /*~E:A138*/
         /*~-1*/
         }
         /*~E:F137*/
         /*~T*/
         Statistics();					///< Statistik
      /*~-1*/
      }
      /*~E:I136*/
      /*~F:166*/
      /* neu ab Version V1.009 */

      /*~-1*/
      {
         /*~I:167*/
         if (Flag500ms)
         /*~-1*/
         {
            /*~T*/
            Watchdog();						///< Watchdog

         /*~-1*/
         }
         /*~E:I167*/
      /*~-1*/
      }
      /*~E:F166*/
      /*~K*/
      /*~+:*/
      /*~I:168*/
      if (Flag1000ms)
      /*~-1*/
      {
         /*~T*/
         System_UpdateOperatingHours(0);	///< Betriebsstundenz�hler

         /*~I:169*/
#ifdef SYSTEM_CND_PRINT_SPI_ERRORS
         /*~T*/
         Main_Check4SPIErrors();
         /*~-1*/
#endif
         /*~E:I169*/
      /*~-1*/
      }
      /*~E:I168*/
      /*~K*/
      /*~+:*/
      /*~I:170*/
      if (Flag2000ms)
      /*~-1*/
      {
         /*~T*/

      /*~-1*/
      }
      /*~E:I170*/
      /*~K*/
      /*~+:*/
      /*~I:171*/
      if (Flag10000ms)
      /*~-1*/
      {
         /*~I:172*/
#ifdef SYSTEM_CND_DISABLE_SPI_COMMUNICATION_AT_FAULTS
         /*~A:173*/
         /*~+:Mit Abschaltung der SPI-Kommunikation bei Ausfall der SPI-Schnittstelle - Wiederholungsz�hler der erfolgten Resets l�schen*/
         /*~T*/
         // Mit Abschaltung der SPI-Kommunikation bei Ausfall der SPI-Schnittstelle - Wiederholungsz�hler der erfolgten Resets l�schen
         /*~I:174*/
         if (byCounter++ >= 6)
         /*~-1*/
         {
            /*~T*/
            byCounter = 0;

            Communication_ClearSPIFaultCounter(1);
         /*~-1*/
         }
         /*~E:I174*/
         /*~E:A173*/
         /*~-1*/
#endif
         /*~E:I172*/
      /*~-1*/
      }
      /*~E:I171*/
      /*~A:175*/
      /*~+:Alle Zeitflags wieder l�schen*/
      /*~T*/
      // Alle Zeitflags wieder l�schen
      Main_ClearTimerFlags();
      /*~E:A175*/
   /*~-1*/
   }
   /*~E:L121*/
/*~-1*/
}
/*~E:F16*/
/*~E:A15*/
/*~I:176*/
#ifdef SYSTEM_CND_PRINT_SPI_ERRORS
/*~A:177*/
/*~+:void Main_Check4SPIErrors(void)*/
/*~F:178*/
void Main_Check4SPIErrors(void)
/*~-1*/
{
   /*~A:179*/
   /*~+:Variablendeklarationen*/
   /*~T*/
   // Variablendeklarationen
   SPI_ERRORBUFFER_T ErrorBuffer;
   /*~E:A179*/
   /*~A:180*/
   /*~+:Variableninitialisierungen*/
   /*~T*/
   // Variableninitialisierungen
   /*~E:A180*/
   /*~T*/
   ErrorBuffer = ADuC836_SPIGetErrors();
   /*~I:181*/
   if (ErrorBuffer.bNewError)
   /*~-1*/
   {
      /*~I:182*/
#ifdef CHANNEL_0
      /*~T*/
      Communication_SendLong(COMMUNICATION_RS232,TEXT_SPI_ERRORS_RECCHAR_CHANNEL_0,ErrorBuffer.uiErrorCounterSPI_RecChar,1,0);
      Communication_SendLong(COMMUNICATION_RS232,TEXT_SPI_ERRORS_SENDCHAR_CHANNEL_0,ErrorBuffer.uiErrorCounterSPI_SendChar,1,0);
      Communication_SendLong(COMMUNICATION_RS232,TEXT_SPI_ERRORS_WAIT4FRAME_CHANNEL_0,ErrorBuffer.uiErrorCounterSPI_WaitForFrame,1,0);
      Communication_SendLong(COMMUNICATION_RS232,TEXT_SPI_ERRORS_MISC_1_CHANNEL_0,ErrorBuffer.uiErrorCounterSPI_Misc_1,1,0);
      Communication_SendLong(COMMUNICATION_RS232,TEXT_SPI_ERRORS_MISC_2_CHANNEL_0,ErrorBuffer.uiErrorCounterSPI_Misc_2,1,1);
      /*~-1*/
#endif
      /*~E:I182*/
      /*~I:183*/
#ifdef CHANNEL_1
      /*~T*/
      Communication_SendLong(COMMUNICATION_RS232,TEXT_SPI_ERRORS_RECCHAR_CHANNEL_1,ErrorBuffer.uiErrorCounterSPI_RecChar,1,0);
      Communication_SendLong(COMMUNICATION_RS232,TEXT_SPI_ERRORS_SENDCHAR_CHANNEL_1,ErrorBuffer.uiErrorCounterSPI_SendChar,1,0);
      Communication_SendLong(COMMUNICATION_RS232,TEXT_SPI_ERRORS_WAIT4FRAME_CHANNEL_1,ErrorBuffer.uiErrorCounterSPI_WaitForFrame,1,0);
      Communication_SendLong(COMMUNICATION_RS232,TEXT_SPI_ERRORS_MISC_1_CHANNEL_1,ErrorBuffer.uiErrorCounterSPI_Misc_1,1,0);
      Communication_SendLong(COMMUNICATION_RS232,TEXT_SPI_ERRORS_MISC_2_CHANNEL_1,ErrorBuffer.uiErrorCounterSPI_Misc_2,1,1);
      /*~-1*/
#endif
      /*~E:I183*/
   /*~-1*/
   }
   /*~E:I181*/
/*~-1*/
}
/*~E:F178*/
/*~E:A177*/
/*~-1*/
#endif
/*~E:I176*/
/*~A:184*/
/*~+:void Main_ClearTimerFlags(void)*/
/*~F:185*/
void Main_ClearTimerFlags(void)
/*~-1*/
{
   /*~T*/
   Flag100ms = 0;
   Flag300ms = 0;
   Flag500ms = 0;
   Flag1000ms = 0;
   Flag2000ms = 0;
   Flag10000ms = 0;
/*~-1*/
}
/*~E:F185*/
/*~E:A184*/
/*~A:186*/
/*~+:unsigned long Main_Init(void)*/
/*~F:187*/
#pragma NOAREGS    // Wichtig f�r internen 2k-XDATA-RAM !!
unsigned long Main_Init(void)

/*~-1*/
{
   /*~A:188*/
   /*~+:Beschreibung*/
   /*~K*/
   /*~+:*/
   /*~E:A188*/
   /*~A:189*/
   /*~+:Variablendeklarationen*/
   /*~T*/
   unsigned long ulRetVal;
   unsigned long ulInititializationStep;
   unsigned char chCounter;
   unsigned char chIniMode;
   //   unsigned char byMeasurementDepth;

   unsigned long ulInitialIdentification = 0L;
   /*~E:A189*/
   /*~A:190*/
   /*~+:Variableninitialisierungen*/
   /*~T*/
   memset(&Global,0,sizeof(GLOBAL));
   /*~T*/
   ulRetVal = 0L;
   ulInititializationStep = 1L;
   chCounter = 0;
   ulInitialIdentification = 0;
   chIniMode = BYDEFAULT;
   /*~E:A190*/
   /*~A:191*/
   /*~+:Eeprom initialisieren*/
   /*~T*/
   Ee24c64_Init();
   Ee24c64_WriteEnable();
   /*~E:A191*/
   /*~A:192*/
   /*~+:Diagnose initialisieren*/
   /*~T*/
   Diagnosis_Ini();
   /*~E:A192*/
   /*~A:193*/
   /*~+:Kennung f�r eine Erstinbetriebnahme abfragen*/
   /*~U:194*/
   /*~-2*/
   do
   {
      /*~T*/
      Load_Parameter(LOAD_SAVE_INITIALIZE_IDENTIFICATION,(void*)&ulInitialIdentification,0);
      /*~I:195*/
      if (ulInitialIdentification == 0xA5A5A5A5)
      /*~-1*/
      {
         /*~T*/
         // Kennung gefunden - Parameter m�ssen im Eeprom liegen
         chCounter = 5;
         chIniMode = BYMEMORY; 
      /*~-1*/
      }
      /*~O:I195*/
      /*~-2*/
      else
      {
         /*~I:196*/
         if (ulInitialIdentification == 0xAAAA5555)
         /*~-1*/
         {
            /*~T*/
            // Neuinitialisierung
            chCounter = 5;
            chIniMode = REINITIALISATION;
            /*~T*/
            // Reinitialisierung

            // Kennung setzen
            ulInitialIdentification = 0xA5A5A5A5;

            Save_Parameter(LOAD_SAVE_INITIALIZE_IDENTIFICATION,&ulInitialIdentification,0);
         /*~-1*/
         }
         /*~O:I196*/
         /*~-2*/
         else
         {
            /*~I:197*/
            if (chCounter >= 4)
            /*~-1*/
            {
               /*~T*/
               // Erstinbetriebnahme

               // Kennung setzen
               ulInitialIdentification = 0xA5A5A5A5;

               Save_Parameter(LOAD_SAVE_INITIALIZE_IDENTIFICATION,&ulInitialIdentification,0);

               // Diagnosespeicher l�schen
               Diagnosis_ClearDiagnosis(DIAGNOSIS_CLEAR_ALL_BY_INITITALISATION);

               // System ID l�schen
               Global.ulSystemID = 0;

               Save_Parameter(LOAD_SAVE_SYSTEM_ID,&Global.ulSystemID,4);
            /*~-1*/
            }
            /*~E:I197*/
         /*~-1*/
         }
         /*~E:I196*/
      /*~-1*/
      }
      /*~E:I195*/
   /*~-1*/
   }
   /*~O:U194*/
   while (++chCounter < 5);
   /*~E:U194*/
   /*~E:A193*/
   /*~A:198*/
   /*~+:ADuC836-Bibliothek initialisieren*/
   /*~+:*/
   /*~T*/
   ///< ADuC836-Bibliothek initialisieren
   ADuC836_Ini(0);
   /*~E:A198*/
   /*~A:199*/
   /*~+:Messwert-Modul initialisieren*/
   /*~T*/
   Measurement_Init();
   /*~E:A199*/
   /*~A:200*/
   /*~+:ADC initialsieren*/
   /*~T*/
   // ADC mit Defaultwerten initialsieren


   // Hauptkanal mit folgenden Einstellungen initialisieren:
   // Messbereich +/-20mV
   // Bipolare Betriebsart
   // Eingangspins A1 und A2
   // Externe Referenzquelle
   // 19.79Hz Abtastrate
   // Togglebetrieb

   // 1.Hilfskanal mit folgenden Einstellungen initialisieren:
   // Bipolare Betriebsart
   // Temperatursensor als Messeingang
   // Interne Referenzquelle
   // 5.35Hz Abtastrate

   // 2.Hilfskanal mit folgenden Einstellungen initialisieren:
   // Bipolare Betriebsart
   // AIN3 als Messeingang
   // Externe Referenzquelle
   // 5.35Hz Abtastrate
   /*~T*/
   ADuC836_ADCIni(DEFAULT_PRIMARY_ADC_SETTING,0);
   ADuC836_ADCIni(DEFAULT_AUXILIARY_ADC_SETTING,0);

   /*~I:201*/
#ifndef OHNE_STROMRUECKFUEHRUNG
   /*~T*/
   ADuC836_ADCIni(DEFAULT_PRIMARY_TOGGLE_ADC_SETTING,0);

   /*~-1*/
#endif
   /*~E:I201*/
   /*~T*/
   // Messwertoffset vorgeben
   ADuC836_ADCSetZeroOffset(ADuC836_ADC_PRIMARY,0x8000);
   /*~T*/
   // Messwerttiefe vorgeben.
   ADuC836_ADCSetMeasurementDepth(ADuC836_ADC_AUXILIARY,1);

   /*~A:202*/
   /*~+:Kanal 0 - Netzteilspannung*/
   /*~I:203*/
#ifdef CHANNEL_0
   /*~T*/
   ADuC836_ADCIni(DEFAULT_AUXILIARY_TOGGLE_ADC_SETTING,0);

   /*~T*/
   ADuC836_ADCSetMeasurementDepth(ADuC836_ADC_AUXILIARY_TOGGLE,1);
   /*~-1*/
#endif
   /*~E:I203*/
   /*~E:A202*/
   /*~K*/
   /*~+:*/
   /*~I:204*/
#ifdef MIT_EINSTELLBARER_MESSWERTTIEFE
   /*~A:205*/
   /*~+:Mit einstellbarer Messwerttiefe*/
   /*~C:206*/
   switch (chIniMode)
   /*~-1*/
   {
      /*~F:207*/
      case BYDEFAULT:
      case REINITIALISATION:
      /*~-1*/
      {
         /*~T*/
         byMeasurementDepth = 1;	// Werte kleiner von 2 �berlasten den ADC - Hilfs-ADC kommt nicht zum Zuge
         /*~T*/
         // Messwerttiefe der Gewichtsermittlung vorgeben.
         ADuC836_ADCSetMeasurementDepth(ADuC836_ADC_PRIMARY,byMeasurementDepth);
         /*~A:208*/
         /*~+:und speichern*/
         /*~T*/
         // und speichern
         Save_Parameter(LOAD_SAVE_WEIGHT_MEASUREMENT_DEPTH,&byMeasurementDepth,1);
         /*~E:A208*/
         /*~I:209*/
#ifndef OHNE_STROMRUECKFUEHRUNG
         /*~T*/
         byMeasurementDepth = 1;
         /*~T*/
         // Messwerttiefe der Stromr�ckf�hrung vorgeben.
         ADuC836_ADCSetMeasurementDepth(ADuC836_ADC_PRIMARY_TOGGLE,byMeasurementDepth);

         /*~A:210*/
         /*~+:und speichern*/
         /*~T*/
         // und speichern
         Save_Parameter(LOAD_SAVE_MEASUREMENT_DEPTH_FEEDBACK,&byMeasurementDepth,1);
         /*~E:A210*/
         /*~-1*/
#endif
         /*~E:I209*/
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F207*/
      /*~F:211*/
      case BYMEMORY:
      /*~-1*/
      {
         /*~T*/
         Load_Parameter(LOAD_SAVE_WEIGHT_MEASUREMENT_DEPTH,&byMeasurementDepth,1);
         /*~T*/
         // Messwerttiefe der Gewichtsermittlung vorgeben.
         ADuC836_ADCSetMeasurementDepth(ADuC836_ADC_PRIMARY,byMeasurementDepth);
         /*~K*/
         /*~+:*/
         /*~T*/
         Load_Parameter(LOAD_SAVE_MEASUREMENT_DEPTH_FEEDBACK,&byMeasurementDepth,1);
         /*~T*/
         // Messwerttiefe der Stromr�ckf�hrung vorgeben.
         ADuC836_ADCSetMeasurementDepth(ADuC836_ADC_PRIMARY_TOGGLE,byMeasurementDepth);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F211*/
   /*~-1*/
   }
   /*~E:C206*/
   /*~E:A205*/
   /*~O:I204*/
   /*~-1*/
#else
   /*~I:212*/
#ifndef OHNE_STROMRUECKFUEHRUNG 
   /*~T*/
   // Messwerttiefe der Gewichtsermittlung vorgeben.
   ADuC836_ADCSetMeasurementDepth(ADuC836_ADC_PRIMARY,1);
   /*~T*/
   // Messwerttiefe der Stromr�ckf�hrung vorgeben.
   ADuC836_ADCSetMeasurementDepth(ADuC836_ADC_PRIMARY_TOGGLE,1);
   /*~O:I212*/
   /*~-1*/
#else
   /*~T*/
   // Messwerttiefe der Gewichtsermittlung vorgeben.
   ADuC836_ADCSetMeasurementDepth(ADuC836_ADC_PRIMARY,1);
   /*~-1*/
#endif
   /*~E:I212*/
   /*~-1*/
#endif
   /*~E:I204*/
   /*~E:A200*/
   /*~A:213*/
   /*~+:Analogteil initialisieren*/
   /*~C:214*/
   switch (chIniMode)
   /*~-1*/
   {
      /*~F:215*/
      case BYDEFAULT:
      case REINITIALISATION:
      /*~-1*/
      {
         /*~T*/
         Analog_Ini(0);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F215*/
      /*~F:216*/
      case BYMEMORY:
      /*~-1*/
      {
         /*~T*/
         Analog_Ini(1);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F216*/
   /*~-1*/
   }
   /*~E:C214*/
   /*~E:A213*/
   /*~A:217*/
   /*~+:Stromschnittstelle initialisieren*/
   /*~T*/
   // Stromschnittstelle initialisieren
   /*~C:218*/
   switch (chIniMode)
   /*~-1*/
   {
      /*~F:219*/
      case BYDEFAULT:
      case REINITIALISATION:
      /*~-1*/
      {
         /*~T*/
         CurrentInterface_Ini(0);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F219*/
      /*~F:220*/
      case BYMEMORY:
      /*~-1*/
      {
         /*~T*/
         CurrentInterface_Ini(1);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F220*/
   /*~-1*/
   }
   /*~E:C218*/
   /*~I:221*/
   /* neu ab Version V1.009 */
#ifdef STROM_SOFORT_EINSCHALTEN
   /*~T*/
   // Ausgangsstrom sofort auf Defaultwert (ca. 4mA) setzen
   CurrentInterface(0);
   /*~-1*/
#endif
   /*~E:I221*/
   /*~E:A217*/
   /*~A:222*/
   /*~+:Digitalteil initialisieren*/
   /*~T*/
   Digital_Init();
   /*~E:A222*/
   /*~A:223*/
   /*~+:RS232-Schnittstelle initialisieren*/
   /*~T*/
   ulInititializationStep <<= 1;
   /*~I:224*/
   // RS232-Schnittstelle mit einer Datenbreite von 8 Bit bei 9600Baud initialisieren
   if (ADuC836_RS232Ini(8,9600,&CommunicationControl.chRecBuffer[COMMUNICATION_RS232][0],RECBUFFER_SIZE,&CommunicationControl.chTransBuffer[COMMUNICATION_RS232],1))

   /*~-1*/
   {
      /*~T*/
      ulRetVal |= ulInititializationStep;
   /*~-1*/
   }
   /*~E:I224*/
   /*~E:A223*/
   /*~I:225*/
#ifdef CHANNEL_0
   /*~A:226*/
   /*~+:SPI-Schnittstelle initialisieren*/
   /*~T*/
   ADuC836_SPIDefaultIni(1,&CommunicationControl.chRecBuffer[COMMUNICATION_SPI][0]);	// Master-Mode
   /*~E:A226*/
   /*~-1*/
#endif
   /*~E:I225*/
   /*~I:227*/
#ifdef CHANNEL_1 
   /*~A:228*/
   /*~+:SPI-Schnittstelle initialisieren*/
   /*~T*/
   ADuC836_SPIDefaultIni(0,&CommunicationControl.chRecBuffer[COMMUNICATION_SPI][0]);	// Slave-Mode
   /*~E:A228*/
   /*~-1*/
#endif
   /*~E:I227*/
   /*~A:229*/
   /*~+:Kommunikationsroutine initialisieren*/
   /*~T*/
   // Kommunikation initialisieren
   // Parametertrennzeichen ist ein SPACE
   Communication_Ini(' ',chIniMode);
   /*~E:A229*/
   /*~A:230*/
   /*~+:Gewichtsermittlung initialisieren*/
   /*~T*/
   ulInititializationStep <<= 1;
   /*~C:231*/
   switch (chIniMode)
   /*~-1*/
   {
      /*~F:232*/
      case BYDEFAULT:
      case REINITIALISATION:
      /*~-1*/
      {
         /*~I:233*/
         if (Weight_Ini(0))
         /*~-1*/
         {
            /*~T*/
            ulRetVal |= ulInititializationStep;
         /*~-1*/
         }
         /*~E:I233*/
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F232*/
      /*~F:234*/
      case BYMEMORY:
      /*~-1*/
      {
         /*~I:235*/
         if (Weight_Ini(1))
         /*~-1*/
         {
            /*~T*/
            ulRetVal |= ulInititializationStep;
         /*~-1*/
         }
         /*~E:I235*/
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F234*/
   /*~-1*/
   }
   /*~E:C231*/
   /*~E:A230*/
   /*~A:236*/
   /*~+:Filterfunktion initialisieren.*/
   /*~T*/
   ulInititializationStep <<= 1;
   /*~C:237*/
   switch (chIniMode)
   /*~-1*/
   {
      /*~F:238*/
      case BYDEFAULT:
      case REINITIALISATION:
      /*~-1*/
      {
         /*~I:239*/
         if (Filter_Ini(0))
         /*~-1*/
         {
            /*~T*/
            // Fehler bei der Initialisierung des Filters
            ulRetVal |= ulInititializationStep;
         /*~-1*/
         }
         /*~E:I239*/
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F238*/
      /*~F:240*/
      case BYMEMORY:
      /*~-1*/
      {
         /*~T*/
         Analog_Ini(1);
         /*~I:241*/
         if (Filter_Ini(1))
         /*~-1*/
         {
            /*~T*/
            // Fehler bei der Initialisierung des Filters
            ulRetVal |= ulInititializationStep;
         /*~-1*/
         }
         /*~E:I241*/
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F240*/
   /*~-1*/
   }
   /*~E:C237*/
   /*~E:A236*/
   /*~A:242*/
   /*~+:Zeitgeber initialisieren*/
   /*~T*/
   ADuC836_TimerIni(1,0);

   ADuC836_TimerSetTimer(T100MS,100);
   ADuC836_TimerSetTimer(T300MS,300);
   ADuC836_TimerSetTimer(T500MS,500);
   ADuC836_TimerSetTimer(T1000MS,1000);
   ADuC836_TimerSetTimer(T2000MS,2000);
   ADuC836_TimerSetTimer(T10000MS,10000);
   /*~E:A242*/
   /*~A:243*/
   /*~+:Systemfunktionen initialisieren*/
   /*~C:244*/
   switch (chIniMode)
   /*~-1*/
   {
      /*~F:245*/
      case BYDEFAULT:
      /*~-1*/
      {
         /*~T*/
         System_Ini(0);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F245*/
      /*~F:246*/
      case BYMEMORY:
      case REINITIALISATION:
      /*~-1*/
      {
         /*~T*/
         System_Ini(1);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F246*/
   /*~-1*/
   }
   /*~E:C244*/
   /*~E:A243*/
   /*~I:247*/
#ifdef CHANNEL_0
   /*~A:248*/
   /*~+:TeachIn-Modul f�r zwei Level initialisieren*/
   /*~T*/
   TeachIn_Ini(2);
   /*~E:A248*/
   /*~-1*/
#endif
   /*~E:I247*/
   /*~A:249*/
   /*~+:Temperaturkompensation initialisieren*/
   /*~T*/
   // Temperaturkompensation initialisieren
   /*~C:250*/
   switch (chIniMode)
   /*~-1*/
   {
      /*~F:251*/
      case BYDEFAULT:
      case REINITIALISATION:
      /*~-1*/
      {
         /*~T*/
         Compensation_Ini(0);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F251*/
      /*~F:252*/
      case BYMEMORY:
      /*~-1*/
      {
         /*~T*/
         Compensation_Ini(1);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F252*/
   /*~-1*/
   }
   /*~E:C250*/
   /*~E:A249*/
   /*~I:253*/
#ifdef MOF
   /*~A:254*/
   /*~+:Externen Interrupt initialisieren*/
   /*~T*/
   ADuC836_ExternalIni(EXTERNAL_EDGE_CONTROLLED|EXTERNAL_LOW_PRIORITY,1,EXTERNAL_EDGE_CONTROLLED|EXTERNAL_LOW_PRIORITY,0);
   /*~E:A254*/
   /*~-1*/
#endif
   /*~E:I253*/
   /*~A:255*/
   /*~+:Statistik initialisieren*/
   /*~I:256*/
   if (chIniMode == BYDEFAULT)
   /*~-1*/
   {
      /*~T*/
      Statistics_Ini(1);
   /*~-1*/
   }
   /*~O:I256*/
   /*~-2*/
   else
   {
      /*~T*/
      Statistics_Ini(0);
   /*~-1*/
   }
   /*~E:I256*/
   /*~E:A255*/
   /*~A:257*/
   /*~+:Grenzwert�berwachung initialisieren*/
   /*~T*/
   // Grenzwert�berwachung initialisieren
   /*~C:258*/
   switch (chIniMode)
   /*~-1*/
   {
      /*~F:259*/
      case BYDEFAULT:
      case REINITIALISATION:
      /*~-1*/
      {
         /*~T*/
         Limit_Init(0);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F259*/
      /*~F:260*/
      case BYMEMORY:
      /*~-1*/
      {
         /*~T*/
         Limit_Init(1);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F260*/
   /*~-1*/
   }
   /*~E:C258*/
   /*~E:A257*/
   /*~T*/
   return ulRetVal;
/*~-1*/
}
/*~E:F187*/
/*~E:A186*/
/*~A:261*/
/*~+:void Main_SetTimerFlags(void)*/
/*~F:262*/
/*#LJ:Main_SetTimerFlags=6*/
void Main_SetTimerFlags(void)
/*~-1*/
{
   /*~T*/
   Flag100ms = ADuC836_TimerCheckTime(T100MS,2);
   Flag300ms = ADuC836_TimerCheckTime(T300MS,2);
   Flag500ms = ADuC836_TimerCheckTime(T500MS,2);
   Flag1000ms = ADuC836_TimerCheckTime(T1000MS,2);
   Flag2000ms = ADuC836_TimerCheckTime(T2000MS,2);
   Flag10000ms = ADuC836_TimerCheckTime(T10000MS,2); 
/*~-1*/
}
/*~E:F262*/
/*~E:A261*/
/*~K*/
/*~+:Externals*/
/*~F:263*/
void ADuC836_SPIInterruptCallback(char* pRecBuffer)
/*~-1*/
{
   /*~T*/
   Communication_SendString(COMMUNICATION_RS232,pRecBuffer,0,1);
/*~-1*/
}
/*~E:F263*/
