/*~-1*/
/*~XSF_LANGUAGE: C/C++*/
/*~K*/
/*~+:File :        Diagnosis.c*/
/*~+:*/
/*~+:Version :     V1.002*/
/*~+:*/
/*~+:Date :        09.02.2022*/
/*~+:*/
/*~+:Time :        10:23*/
/*~+:*/
/*~+:Author :      MOF*/
/*~+:*/
/*~+:Hardware :*/
/*~+:*/
/*~+:Description :*/
/*~+:*/
/*~+:*/
/*~A:1*/
/*~+:Includes*/
/*~T*/
#include "Diagnosis.h"
#include "global.h"
#include <string.h>
#include <stdio.h>
/*~E:A1*/
/*~A:2*/
/*~+:Funktionseigene Definitionen*/
/*~T*/
#define BLOCKMASK_POWERSUPPLY_OUT_OF_LIMITS		0x00000001			///< Netzteilspannung au�er Bereich
#define BLOCKMASK_CURRENT_DEVIATION				0x00000002			///< Stromdifferenz zwischen Soll-und Istwert zu gro�
#define BLOCKMASK_MEMORY_DYNAMIC_VARIABLES		0x00000004			///< Fehler 'Dynamische Variablen'
#define BLOCKMASK_MEMORY_WRITE_EEPROM			0x00000008			///< Fehler beim Beschreiben des Eeproms
#define BLOCKMASK_MEMORY_READ_EEPROM			0x00000010			///< Fehler beim Auslesen des Eeproms
#define BLOCKMASK_MEMORY_WRITE_FLASH			0x00000020			///< Fehler beim Beschreiben des Flashs
#define BLOCKMASK_MEMORY_READ_FLASH				0x00000040			///< Fehler beim Auslesen des Flashs
#define BLOCKMASK_ERROR_INTERNAL_COMMUNICATION	0x00000080			///< Fehler 'Partnerkommunication'
#define BLOCKMASK_GLOBAL_PARTNER_IN_SYSTEMERROR	0x00000100			///< Fehler 'Partner im Sicherheitszustand'
#define BLOCKMASK_INITIALIZATION				0x00000200			///< Fehler 'Initialisierung'
#define BLOCKMASK_POWERSUPPLY_NOK				0x00000400			///< Fehler 'Netzteilstatus'
/*~E:A2*/
/*~A:3*/
/*~+:Funktionseigene Struktur-Definitionen*/
/*~T*/

/*~E:A3*/
/*~A:4*/
/*~+:Funktionsprototypen*/
/*~T*/
void Diagnosis_ClearDiagnosis(unsigned char byMode);

/*~I:5*/
#ifdef TERMINALBETRIEB 
/*~T*/
char Diagnosis_GetText(unsigned long ulErrorID,char* szErrorText);
/*~-1*/
#endif
/*~E:I5*/
/*~T*/
void Diagnosis_Ini(void);
void Diagnosis_InitReadProcedure(void);
void Diagnosis_PrintFreeMemory(void);
void Diagnosis_PrintMemory(void);
char Diagnosis_ReadMessageFromFlash(unsigned long *ulTime, unsigned long *ulMessage);
void Diagnosis_SetSystemStart(void);
void Diagnosis_WriteMessage2Flash(unsigned long ulMessage);
/*~T*/
void Diagnosis_SecurityCurrentInterface(unsigned char chError);
void Diagnosis_SecurityInitialization(unsigned char chError);
void Diagnosis_SecurityInternalCommunication(unsigned char chError);
void Diagnosis_SecurityMemory(unsigned char chError);
void Diagnosis_SecurityPartnerSystemError(unsigned char chError);
void Diagnosis_SecurityPowerSupply(unsigned char chError);

/*~E:A4*/
/*~A:6*/
/*~+:Globale Variablen*/
/*~T*/
DIAGNOSIS Diagnosis;							///< Diagnose-Struktur
unsigned char g_bDiagnosis_Systemneustart;
/*~E:A6*/
/*~A:7*/
/*~+:void Diagnosis_ClearDiagnosis(unsigned char byMode)*/
/*~F:8*/
void Diagnosis_ClearDiagnosis(unsigned char byMode)
/*~-1*/
{
   /*~A:9*/
   /*~+:Beschreibung*/
   /*~T*/
   /*!
   \fn void Diagnosis_ClearDiagnosis(unsigned char byMode)
   
   <b>Beschreibung:</b><br>
   L�scht den Diagnosespeicher.
   
   \param
   byMode: Gibt an, wie weit der L�schvorgang greift.
   \param
   0 = Es wird nur der Merker f�r einen Systemfehler gel�scht - das System kann zun�chst normal weiterlaufen.
   \param
   1 = Komplettes L�schen des Diagnosespeichers und Anlegene eines Vermerks im Diagnose-Speicher.
   \param
   2 = Komplettes L�schen des Diagnosespeichers nach einer System-Neuinitialisierung und Anlegene eines Vermerks im Diagnose-Speicher.
   
   \return
   ./.
   
   <b>Zugriff:</b><br>
   [X] �ffentlich / [ ] Privat
   */

   /*~E:A9*/
   /*~A:10*/
   /*~+:Variablendeklarationen*/
   /*~T*/
   unsigned char byErrorSystemID;
   unsigned long ulStartTime;
   /*~E:A10*/
   /*~A:11*/
   /*~+:Variableninitialisierungen*/
   /*~T*/
   ulStartTime = Diagnosis.ulTimeSystemStart; 
   /*~I:12*/
   // ID-Fehler ?
   if (Diagnosis.ucID)	
   /*~-1*/
   {
      /*~T*/
      // Ja
      byErrorSystemID = 1;
   /*~-1*/
   }
   /*~O:I12*/
   /*~-2*/
   else
   {
      /*~T*/
      // Nein
      byErrorSystemID = 0;
   /*~-1*/
   }
   /*~E:I12*/
   /*~E:A11*/
   /*~T*/
   // Diagnosestruktur l�schen
   memset(&Diagnosis,0,sizeof(Diagnosis));
   /*~T*/
   // Kennung f�r gefundene ID zur�ckschreiben
   Diagnosis.ucID = byErrorSystemID;
   // Zeitpunkt des Neustarts zur�ckschreiben
   Diagnosis.ulTimeSystemStart = ulStartTime;
   g_bDiagnosis_Systemneustart = 1;
   Diagnosis.byReadInitFlag = 1;  
   /*~I:13*/
   if (byMode)
   /*~-1*/
   {
      /*~A:14*/
      /*~+:Statusvariablen f�r Fehlerspeicher l�schen*/
      /*~T*/
      // Speicher-Pointer abspeichern
      ADuC836_FlashDataWritePtr((char*)&Diagnosis.uiMemoryPointer,FLASHADR_MEMPOINTER,2);
      // Speicher-�berlauf Flag speichern
      ADuC836_FlashDataWritePtr((char*)&Diagnosis.byOverrunFlag,FLASHADR_MEMOVERRUN,1);

      /*~E:A14*/
      /*~A:15*/
      /*~+:Meldung ins Flash schreiben*/
      /*~C:16*/
      switch (byMode)
      /*~-1*/
      {
         /*~F:17*/
         case 2:
         /*~-1*/
         {
            /*~T*/
            Diagnosis_WriteMessage2Flash(DIAGNOSIS_MESSAGE_INITIALISATION);
            /*~T*/
            break;
         /*~-1*/
         }
         /*~E:F17*/
         /*~F:18*/
         case 1:
         /*~-1*/
         {
            /*~T*/
            Diagnosis_WriteMessage2Flash(DIAGNOSIS_MESSAGE_DIAGNOSISBUFFER_CLEARED);
            /*~T*/
            break;
         /*~-1*/
         }
         /*~E:F18*/
      /*~-1*/
      }
      /*~E:C16*/
      /*~E:A15*/
   /*~-1*/
   }
   /*~O:I13*/
   /*~-2*/
   else
   {
      /*~A:19*/
      /*~+:Statusvariablen f�r Fehlerspeicher in die Struktur zur�ckschreiben*/
      /*~T*/
      // Speicher-Pointer abspeichern
      ADuC836_FlashDataReadPtr((char*)&Diagnosis.uiMemoryPointer,FLASHADR_MEMPOINTER,2);
      // Speicher-�berlauf Flag speichern
      ADuC836_FlashDataReadPtr((char*)&Diagnosis.byOverrunFlag,FLASHADR_MEMOVERRUN,1);

      /*~E:A19*/
      /*~A:20*/
      /*~+:Meldung ins Flash schreiben*/
      /*~T*/
      Diagnosis_WriteMessage2Flash(DIAGNOSIS_MESSAGE_ALARMSTATUS_CLEARED);
      /*~E:A20*/
   /*~-1*/
   }
   /*~E:I13*/
/*~-1*/
}
/*~E:F8*/
/*~E:A7*/
/*~A:21*/
/*~+:void Diagnosis_Ini(void)*/
/*~F:22*/
void Diagnosis_Ini(void)
/*~-1*/
{
   /*~A:23*/
   /*~+:Beschreibung*/
   /*~T*/
   /*!
   \fn void Diagnosis_Ini(void)
   
   <b>Beschreibung:</b><br>
   Initialisierung des Diagnosespeichers
   
   \param
   ./.
   
   \return
   ./.
   
   <b>Zugriff:</b><br>
   [X] �ffentlich / [ ] Privat
   */

   /*~E:A23*/
   /*~A:24*/
   /*~+:Variablendeklarationen*/
   /*~T*/
   unsigned char byCounter;
   /*~E:A24*/
   /*~A:25*/
   /*~+:Variableninitialisierungen*/
   /*~T*/
   byCounter = 10;

   g_bDiagnosis_Systemneustart = 1;
   /*~E:A25*/
   /*~T*/
   // Diagnosestruktur initialsieren
   memset(&Diagnosis,0,sizeof(Diagnosis));

   Diagnosis.byReadInitFlag = 1;

   /*~U:26*/
   /*~-2*/
   do
   {
      /*~T*/
      // Speicher-Pointer auslesen
      ADuC836_FlashDataReadPtr((char*)&Diagnosis.uiMemoryPointer,FLASHADR_MEMPOINTER,2);
      // Speicher-�berlauf Flag auslesen
      ADuC836_FlashDataReadPtr((char*)&Diagnosis.byOverrunFlag,FLASHADR_MEMOVERRUN,1);
   /*~-1*/
   }
   /*~O:U26*/
   while (((Diagnosis.uiMemoryPointer == 0xFFFF)||(Diagnosis.byOverrunFlag == 0xFF))&&(--byCounter));
   /*~E:U26*/
   /*~A:27*/
   /*~+:Auslesen fehlgeschlagen*/
   /*~I:28*/
   if (!byCounter)
   /*~-1*/
   {
      /*~T*/
      Diagnosis.uiMemoryPointer = 0;
      Diagnosis.byOverrunFlag = 0;
   /*~-1*/
   }
   /*~E:I28*/
   /*~E:A27*/
/*~-1*/
}
/*~E:F22*/
/*~E:A21*/
/*~A:29*/
/*~+:void Diagnosis_InitReadProcedure(void)*/
/*~F:30*/
void Diagnosis_InitReadProcedure(void)
/*~-1*/
{
   /*~A:31*/
   /*~+:Beschreibung*/
   /*~T*/
   /*!
   \fn void Diagnosis_InitReadProcedure(void)
   
   <b>Beschreibung:</b><br>
   Initialisierung des Leseprozesses des Diagnosespeichers
   
   \param
   ./.
   
   \return
   ./.
   
   <b>Zugriff:</b><br>
   [X] �ffentlich / [ ] Privat
   */

   /*~E:A31*/
   /*~T*/
   Diagnosis.byReadInitFlag = 1;
/*~-1*/
}
/*~E:F30*/
/*~E:A29*/
/*~A:32*/
/*~+:void Diagnosis_PrintFreeMemory(void)*/
/*~F:33*/
void Diagnosis_PrintFreeMemory(void)
/*~-1*/
{
   /*~A:34*/
   /*~+:Variablendeklarationen*/
   /*~T*/
   unsigned int	uFreeEntries;
   char			szString[32];
   /*~E:A34*/
   /*~A:35*/
   /*~+:Variableninitialisierungen*/
   /*~T*/

   /*~E:A35*/
   /*~I:36*/
   /*#LJ:1=29*/
   if (!Diagnosis.byOverrunFlag)
   /*~-1*/
   {
      /*~T*/
      uFreeEntries = DIAGNOSISMEMORYSIZE - Diagnosis.uiMemoryPointer; 
   /*~-1*/
   }
   /*~O:I36*/
   /*~-2*/
   else
   {
      /*~T*/
      //�berlauf
      uFreeEntries = 0;
   /*~-1*/
   }
   /*~E:I36*/
   /*~T*/
   sprintf(szString,"%u (von %u)",uFreeEntries,DIAGNOSISMEMORYSIZE);
   /*~T*/
   // Communication_SendLong(COMMUNICATION_RS232,TEXT_FREE_DIAGNOSIS_MEMORY,uFreeEntries,1,0);
   Communication_SendString(COMMUNICATION_RS232,T_TEXT_FREE_DIAGNOSIS_MEMORY,1,0);
   Communication_SendString(COMMUNICATION_RS232,szString,0,0);
/*~-1*/
}
/*~E:F33*/
/*~E:A32*/
/*~A:37*/
/*~+:void Diagnosis_PrintMemory(void)*/
/*~F:38*/
void Diagnosis_PrintMemory(void)
/*~-1*/
{
   /*~A:39*/
   /*~+:Variablendeklarationen*/
   /*~T*/
   unsigned long 	ulMessage;
   unsigned long 	ulTime;
   unsigned char 	chCategory;
   char				byChannel;
   unsigned char	chRetVal;
   unsigned char 	byCounter;
   char 			szString2Send[16];
   /*~E:A39*/
   /*~A:40*/
   /*~+:Variableninitialisierungen*/
   /*~T*/
   byChannel = 0;
   byCounter = 0;
   /*~E:A40*/
   /*~I:41*/
   if (!SYSTEM_MRW_MANAGER)
   /*~-1*/
   {
      /*~A:42*/
      /*~+:Abbruch durch Benutzer ???*/
      /*~I:43*/
      if (Communication_IsESC())
      /*~-1*/
      {
         /*~T*/
         // Abbruch durch Benutzer

         /*~T*/
         Communication_SendString(COMMUNICATION_RS232,T_TEXT_4_ESC,0,0);
         // Flag zur Initialierung des n�chsten Lese-Aufrufs setzen
         Diagnosis_InitReadProcedure();
         /*~T*/
         return;
      /*~-1*/
      }
      /*~E:I43*/
      /*~E:A42*/
      /*~I:44*/
#ifdef CHANNEL_0
      /*~A:45*/
      /*~+:Kanal 0 - Kopf ausgeben*/
      /*~T*/
      // Kopf anlegen

      // Systemzeit

      /*~T*/
      sprintf(szString2Send,"%s %ld:%02ld:%02ld",T_TEXT_SYSTEM_TIME,OPERATINGHOURS/3600,(OPERATINGHOURS%3600)/60,OPERATINGHOURS%60);

      Communication_SendString(COMMUNICATION_RS232,szString2Send,2,0);

      // Kanal 0
      Communication_SendString(COMMUNICATION_RS232,T_TEXT_CHANNEL_0,2,0);
      Communication_SendString(COMMUNICATION_RS232,T_TEXT_DOUBLE_LINE,1,0);
      /*~E:A45*/
      /*~O:I44*/
      /*~-1*/
#else
      /*~I:46*/
#ifdef CHANNEL_1
      /*~A:47*/
      /*~+:Kanal 1*/
      /*~T*/
      // Kanal 1
      Communication_SendString(COMMUNICATION_RS232,T_TEXT_CHANNEL_1,2,0);
      Communication_SendString(COMMUNICATION_RS232,T_TEXT_DOUBLE_LINE,1,0);

      /*~E:A47*/
      /*~K*/
      /*~+:// da wg. der langen Zeitdauer die Synchronistationspr�fung ausgeschaltet wurde, diese wieder einschalten*/
      /*~T*/
      System_SetCheckSynchronisation(1);
      /*~-1*/
#endif
      /*~E:I46*/
      /*~-1*/
#endif
      /*~E:I44*/
   /*~-1*/
   }
   /*~E:I41*/
   /*~A:48*/
   /*~+:Ausgabe der Diagnoseeintr�ge*/
   /*~U:49*/
   /*~-2*/
   do
   {
      /*~T*/
      // Da die Ausgabe l�nger dauern kann, den Watchdog neu antriggern
      Watchdog();
      /*~T*/
      // Diagnoseeintrag auslesen

      chRetVal = Diagnosis_ReadMessageFromFlash(&ulTime,&ulMessage);
      /*~I:50*/
      if (!SYSTEM_MRW_MANAGER)
      /*~-1*/
      {
         /*~I:51*/
         if (chRetVal < 2)
         /*~-1*/
         {
            /*~C:52*/
            switch (ulMessage & 0xC0000000)
            /*~-1*/
            {
               /*~A:53*/
               /*~+:DIAGNOSIS_CATEGORY_ERROR*/
               /*~F:54*/
               case DIAGNOSIS_CATEGORY_ERROR:
               /*~-1*/
               {
                  /*~T*/
                  chCategory = 'E';
                  /*~T*/
                  break;
               /*~-1*/
               }
               /*~E:F54*/
               /*~E:A53*/
               /*~A:55*/
               /*~+:DIAGNOSIS_CATEGORY_WARNING*/
               /*~F:56*/
               case DIAGNOSIS_CATEGORY_WARNING:
               /*~-1*/
               {
                  /*~T*/
                  chCategory = 'W';
                  /*~T*/
                  break;
               /*~-1*/
               }
               /*~E:F56*/
               /*~E:A55*/
               /*~A:57*/
               /*~+:DIAGNOSIS_CATEGORY_MESSAGE*/
               /*~F:58*/
               case DIAGNOSIS_CATEGORY_MESSAGE:
               /*~-1*/
               {
                  /*~T*/
                  chCategory = 'M';
                  /*~T*/
                  break;
               /*~-1*/
               }
               /*~E:F58*/
               /*~E:A57*/
               /*~A:59*/
               /*~+:DIAGNOSIS_CATEGORY_MISC*/
               /*~F:60*/
               case DIAGNOSIS_CATEGORY_MISC:
               /*~-1*/
               {
                  /*~T*/
                  chCategory = ' ';
                  /*~T*/
                  break;
               /*~-1*/
               }
               /*~E:F60*/
               /*~E:A59*/
            /*~-1*/
            }
            /*~E:C52*/
            /*~I:61*/
            if (chRetVal < 2)
            /*~-1*/
            {
               /*~A:62*/
               /*~+:Zeitpunkt des Eintrags ausgeben*/
               /*~T*/
               sprintf(szString2Send,"%6ld:%02ld:%02ld  ",ulTime/3600,(ulTime%3600)/60,ulTime%60);

               Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
               /*~E:A62*/
               /*~A:63*/
               /*~+:ID des Eintrags ausgeben*/
               /*~T*/
               sprintf(szString2Send,"%c%04ld",chCategory,ulMessage & 0x3FFFFFFF);

               Communication_SendString(COMMUNICATION_RS232,szString2Send,0,0);
               /*~E:A63*/
            /*~-1*/
            }
            /*~E:I61*/
         /*~-1*/
         }
         /*~O:I51*/
         /*~-2*/
         else
         {
            /*~I:64*/
            if (chRetVal == 2)
            /*~-1*/
            {
               /*~T*/
               // kein Eintrag vorhanden


               Communication_SendString(COMMUNICATION_RS232,T_TEXT_DIAGNOSIS_NO_ENTRY,1,0);
            /*~-1*/
            }
            /*~O:I64*/
            /*~-2*/
            else
            {
               /*~T*/
               // Fehler

               /*~I:65*/
#ifdef SYSTEM_CND_DISABLE_SPI_COMMUNICATION_AT_FAULTS 
               /*~A:66*/
               /*~+:Mit Abschaltung der SPI-Kommunikation bei Ausfall der SPI-Schnittstelle*/
               /*~I:67*/
               if (!Communication_IsSPICommuncationDisabled())
               /*~-1*/
               {
                  /*~U:68*/
                  /*~-2*/
                  do
                  {
                     /*~T*/
                     Communication_SendSPICommand("iVDG");
                  /*~-1*/
                  }
                  /*~O:U68*/
                  while (!Communication_IsOK() && --byCounter);
                  /*~E:U68*/
               /*~-1*/
               }
               /*~O:I67*/
               /*~-2*/
               else
               {
                  /*~T*/
                  chRetVal = 0;
               /*~-1*/
               }
               /*~E:I67*/
               /*~E:A66*/
               /*~O:I65*/
               /*~-1*/
#else
               /*~A:69*/
               /*~+:Ohne Abschaltung der SPI-Kommunikation bei Ausfall der SPI-Schnittstelle*/
               /*~U:70*/
               /*~-2*/
               do
               {
                  /*~T*/
                  Communication_SendSPICommand("iVDG");
               /*~-1*/
               }
               /*~O:U70*/
               while (!Communication_IsOK() && --byCounter);
               /*~E:U70*/
               /*~E:A69*/
               /*~-1*/
#endif
               /*~E:I65*/
            /*~-1*/
            }
            /*~E:I64*/
         /*~-1*/
         }
         /*~E:I51*/
      /*~-1*/
      }
      /*~O:I50*/
      /*~-2*/
      else
      {
         /*~T*/
         sprintf(szString2Send,"%ld %ld %bd",ulTime,ulMessage,chRetVal);

         Communication_SendString(COMMUNICATION_RS232,szString2Send,0,0);

         chRetVal = 255;
      /*~-1*/
      }
      /*~E:I50*/
   /*~-1*/
   }
   /*~O:U49*/
   while (!chRetVal);
   /*~E:U49*/
   /*~E:A48*/
   /*~I:71*/
   if (!SYSTEM_MRW_MANAGER)
   /*~-1*/
   {
      /*~T*/
      Diagnosis_PrintFreeMemory();
   /*~-1*/
   }
   /*~E:I71*/
/*~-1*/
}
/*~E:F38*/
/*~E:A37*/
/*~A:72*/
/*~+:char Diagnosis_ReadMessageFromFlash(unsigned long *ulTime, unsigned long *ulMessage)*/
/*~F:73*/
char Diagnosis_ReadMessageFromFlash(unsigned long *ulTime, unsigned long *ulMessage)
/*~-1*/
{
   /*~A:74*/
   /*~+:Beschreibung*/
   /*~T*/
   /*!
   \fn char Diagnosis_ReadMessageFromFlash(unsigned long *ulTime, unsigned long *ulMessage)
   
   <b>Beschreibung:</b><br>
   Lesen einer Mitteilung aus dem Diagnosespeicher.
   
   \param
   ulTime: Zeitpunkt (Betriebszeit) des Eintrags der Mitteilung.
   
   \param
   ulMessage: Kennung der Mitteilung.
   
   \return
   Status des Diagnosespeichers.
   
   \retval
   0: Es folgen noch weitere Eintr�ge
   \retval
   1: Kein weiterer Eintrag mehr vorhanden.
   \retval
   2: Kein Eintrag vorhanden.
   
   <b>Zugriff:</b><br>
   [X] �ffentlich / [ ] Privat
   */

   /*~E:A74*/
   /*~A:75*/
   /*~+:Variablendeklarationen*/
   /*~T*/

   /*~E:A75*/
   /*~A:76*/
   /*~+:Variableninitialisierungen*/
   /*~T*/

   /*~E:A76*/
   /*~I:77*/
   if (Diagnosis.byReadInitFlag)
   /*~-1*/
   {
      /*~T*/
      // Initialisierungsflag l�schen
      Diagnosis.byReadInitFlag = 0;
      /*~I:78*/
      if (Diagnosis.byOverrunFlag)
      /*~-1*/
      {
         /*~T*/
         // Startpunkt setzen
         Diagnosis.nReadPointer = Diagnosis.uiMemoryPointer; // 

         // Anzahl der Eintr�ge
         Diagnosis.nReadEntries = DIAGNOSISMEMORYSIZE;
      /*~-1*/
      }
      /*~O:I78*/
      /*~-2*/
      else
      {
         /*~T*/
         // Startpunkt setzen
         Diagnosis.nReadPointer = 0;

         // Anzahl der Eintr�ge
         Diagnosis.nReadEntries = Diagnosis.uiMemoryPointer;
      /*~-1*/
      }
      /*~E:I78*/
   /*~-1*/
   }
   /*~E:I77*/
   /*~I:79*/
   if (Diagnosis.nReadEntries)
   /*~-1*/
   {
      /*~T*/
      // Zeit auslesen
      ADuC836_FlashDataReadPtr((char*)ulTime,Diagnosis.nReadPointer,4);
      // Diagnosestatus auslesen
      ADuC836_FlashDataReadPtr((char*)ulMessage,Diagnosis.nReadPointer + DIAGNOSISMEMORYSIZE,4);
      /*~I:80*/
      if (--Diagnosis.nReadEntries)
      /*~-1*/
      {
         /*~I:81*/
         if (++Diagnosis.nReadPointer>= DIAGNOSISMEMORYSIZE)
         /*~-1*/
         {
            /*~T*/
            Diagnosis.nReadPointer = 0;
         /*~-1*/
         }
         /*~E:I81*/
         /*~T*/
         return 0;
      /*~-1*/
      }
      /*~O:I80*/
      /*~-2*/
      else
      {
         /*~T*/
         Diagnosis.byReadInitFlag = 1;

         return 1;
      /*~-1*/
      }
      /*~E:I80*/
   /*~-1*/
   }
   /*~O:I79*/
   /*~-2*/
   else
   {
      /*~T*/
      *ulTime = Timer.ulOperatingTime;
      *ulMessage = 0L;

      Diagnosis.byReadInitFlag = 1;

      return 2;
   /*~-1*/
   }
   /*~E:I79*/
/*~-1*/
}
/*~E:F73*/
/*~E:A72*/
/*~A:82*/
/*~+:void Diagnosis_SetSystemStart(void)*/
/*~F:83*/
void Diagnosis_SetSystemStart(void)
/*~-1*/
{
   /*~T*/
   g_bDiagnosis_Systemneustart = 1;

   // Diagnosis.ulTimeSystemStart = Timer.ulOperatingTime;

   Diagnosis.ulTimeSystemStart = OPERATINGHOURS;
/*~-1*/
}
/*~E:F83*/
/*~E:A82*/
/*~A:84*/
/*~+:void Diagnosis_WriteMessage2Flash(unsigned long ulMessage)*/
/*~F:85*/
void Diagnosis_WriteMessage2Flash(unsigned long ulMessage)
/*~-1*/
{
   /*~A:86*/
   /*~+:Beschreibung*/
   /*~T*/
   /*!
   \fn void Diagnosis_WriteMessage2Flash(unsigned long ulMessage, unsigned char byCategory)
   
   <b>Beschreibung:</b><br>
   Schreiben eines Mitteilung in den Diagnosespeicher.
   
   \param
   ulMessage: Kennung der einzuschreibenden Mitteilung
   
   \return
   ./.
   
   <b>Zugriff:</b><br>
   [X] �ffentlich / [ ] Privat
   */

   /*~E:A86*/
   /*~A:87*/
   /*~+:Variablendeklarationen*/
   /*~T*/
   unsigned long ulMessage2;
   /*~E:A87*/
   /*~A:88*/
   /*~+:Variableninitialisierungen*/
   /*~T*/

   /*~E:A88*/
   /*~I:89*/
   if ((Diagnosis.ulTimeSystemStart)&&(g_bDiagnosis_Systemneustart))
   /*~-1*/
   {
      /*~T*/
      g_bDiagnosis_Systemneustart = 0;
      /*~A:90*/
      /*~+:Meldung des Systemstarts im Fehlerspeichereintrag*/
      /*~+:*/
      /*~T*/
      ulMessage2 = DIAGNOSIS_MESSAGE_SYSTEMSTART; 
      /*~T*/
      ADuC836_FlashDataWritePtr((char*)&Diagnosis.ulTimeSystemStart,Diagnosis.uiMemoryPointer,4);
      /*~T*/
      // Fehler eintragen
      ADuC836_FlashDataWritePtr((char*)&ulMessage2,Diagnosis.uiMemoryPointer+DIAGNOSISMEMORYSIZE,4);

      /*~I:91*/
      if (++Diagnosis.uiMemoryPointer >= DIAGNOSISMEMORYSIZE)
      /*~-1*/
      {
         /*~T*/
         Diagnosis.uiMemoryPointer = 0;
         Diagnosis.byOverrunFlag = 1;
         /*~T*/
         // Speicher-Pointer abspeichern
         ADuC836_FlashDataWritePtr((char*)&Diagnosis.uiMemoryPointer,FLASHADR_MEMPOINTER,2);
         // Speicher-�berlauf Flag speichern
         ADuC836_FlashDataWritePtr((char*)&Diagnosis.byOverrunFlag,FLASHADR_MEMOVERRUN,1);

      /*~-1*/
      }
      /*~E:I91*/
      /*~E:A90*/
   /*~-1*/
   }
   /*~E:I89*/
   /*~A:92*/
   /*~+:Eintrag vornehmen*/
   /*~I:93*/
   // Zeit eintragen
   if (ulMessage == DIAGNOSIS_MESSAGE_SYSTEMSTART) // Systemneustart
   /*~-1*/
   {
      /*~T*/
      ADuC836_FlashDataWritePtr((char*)&Diagnosis.ulTimeSystemStart,Diagnosis.uiMemoryPointer,4);
   /*~-1*/
   }
   /*~O:I93*/
   /*~-2*/
   else
   {
      /*~T*/
      ADuC836_FlashDataWritePtr((char*)&OPERATINGHOURS,Diagnosis.uiMemoryPointer,4);

   /*~-1*/
   }
   /*~E:I93*/
   /*~I:94*/
#ifdef MOF
   /*~T*/
   // Fehler eintragen
   ADuC836_FlashDataWritePtr((char*)&ulMessage,Diagnosis.uiMemoryPointer+DIAGNOSISMEMORYSIZE,4);

   /*~I:95*/
   if (++Diagnosis.uiMemoryPointer >= DIAGNOSISMEMORYSIZE)
   /*~-1*/
   {
      /*~T*/
      /*#LJ:0=40*/
      Diagnosis.uiMemoryPointer = 0;
      Diagnosis.byOverrunFlag = 1;
   /*~-1*/
   }
   /*~E:I95*/
   /*~T*/
   // Speicher-Pointer abspeichern
   ADuC836_FlashDataWritePtr((char*)&Diagnosis.uiMemoryPointer,FLASHADR_MEMPOINTER,2);
   // Speicher-�berlauf Flag speichern
   ADuC836_FlashDataWritePtr((char*)&Diagnosis.byOverrunFlag,FLASHADR_MEMOVERRUN,1);

   /*~-1*/
#endif
   /*~E:I94*/
   /*~A:96*/
   /*~+:Betriebsstundenz�hlerstand abspeichern*/
   /*~I:97*/
   if (OPERATINGHOURS)
   /*~-1*/
   {
      /*~T*/
      Ee24c64_Write(EEPROM_OPERATING_HOURS,4,&OPERATINGHOURS);
   /*~-1*/
   }
   /*~E:I97*/
   /*~E:A96*/
   /*~E:A92*/
/*~-1*/
}
/*~E:F85*/
/*~E:A84*/
/*~K*/
/*~+:*/
/*~K*/
/*~+:*/
/*~A:98*/
/*~+:void Diagnosis_SecurityCurrentInterface(unsigned char chError)*/
/*~F:99*/
void Diagnosis_SecurityCurrentInterface(unsigned char chError)
/*~-1*/
{
   /*~A:100*/
   /*~+:Beschreibung*/
   /*~T*/
   /*!
   \fn void Diagnosis_SecurityCurrentInterface(unsigned char chError)
   
   <b>Beschreibung:</b><br>
   Sicherheitsfunktion 'Strominterface'. Diese wird im Falle eines Fehlers in der Stromschnittstelle aufgerufen.
    
   \param
   chError: Fehlerkennzeichnung
   
   \return
   ./.
   
   <b>Zugriff:</b><br>
   [X] �ffentlich / [ ] Privat
   */
   /*~E:A100*/
   /*~C:101*/
   switch (chError)
   /*~-1*/
   {
      /*~A:102*/
      /*~+:CURRENT_DEVIATION*/
      /*~F:103*/
      case CURRENT_DEVIATION:
      /*~-1*/
      {
         /*~I:104*/
         if (!(Diagnosis.ulBlockMask & BLOCKMASK_CURRENT_DEVIATION))
         /*~-1*/
         {
            /*~T*/
            // Sperrmaske setzen
            Diagnosis.ulBlockMask |= BLOCKMASK_CURRENT_DEVIATION;
            /*~T*/
            // Eintrag in den Diagnosespeicher vornehmen
            Diagnosis_WriteMessage2Flash(DIAGNOSIS_ERROR_CURRENT_DEVIATION);

         /*~-1*/
         }
         /*~E:I104*/
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F103*/
      /*~E:A102*/
   /*~-1*/
   }
   /*~E:C101*/
   /*~K*/
   /*~+:/~* Ge�ndert am 09.02.2022 *~/*/
   /*~T*/
   System_SetSystemState(SYSTEM_ERROR);
   /*~K*/
   /*~+:/~* Ende - Ge�ndert am 09.02.2022 *~/*/
/*~-1*/
}
/*~E:F99*/
/*~E:A98*/
/*~A:105*/
/*~+:void Diagnosis_SecurityInitialization(unsigned char chError)*/
/*~F:106*/
void Diagnosis_SecurityInitialization(unsigned char chError)
/*~-1*/
{
   /*~A:107*/
   /*~+:Beschreibung*/
   /*~T*/
   /*!
   \fn void Diagnosis_SecurityPowerSupply(unsigned char chError)
   
   <b>Beschreibung:</b><br>
   Sicherheitsfunktion 'Netzteilspannung'. Diese wird im Falle eines Fehlers in der Spannungsversorgung aufgerufen.
    
   \param
   chError: Fehlerkennzeichnung
   
   \return
   ./.
   
   <b>Zugriff:</b><br>
   [X] �ffentlich / [ ] Privat
   */
   /*~E:A107*/
   /*~C:108*/
   switch (chError)
   /*~-1*/
   {
      /*~F:109*/
      case SYTEM_ERROR_INITIALIZATION:
      /*~-1*/
      {
         /*~I:110*/
         if (!(Diagnosis.ulBlockMask & BLOCKMASK_INITIALIZATION))
         /*~-1*/
         {
            /*~T*/
            // Sperrmaske setzen
            Diagnosis.ulBlockMask |= BLOCKMASK_INITIALIZATION;
            /*~T*/
            // Eintrag in den Diagnosespeicher vornehmen
            Diagnosis_WriteMessage2Flash(DIAGNOSIS_ERROR_INITIALIZATION);

         /*~-1*/
         }
         /*~E:I110*/
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F109*/
   /*~-1*/
   }
   /*~E:C108*/
   /*~I:111*/
#ifdef MIT_SICHERHEITSALARM_FUNKTION
   /*~T*/
   System_SetSystemState(SYSTEM_ERROR);
   /*~-1*/
#endif
   /*~E:I111*/
/*~-1*/
}
/*~E:F106*/
/*~E:A105*/
/*~A:112*/
/*~+:void Diagnosis_SecurityInternalCommunication(unsigned char chError)*/
/*~F:113*/
void Diagnosis_SecurityInternalCommunication(unsigned char chError)
/*~-1*/
{
   /*~A:114*/
   /*~+:Beschreibung*/
   /*~T*/
   /*!
   \fn void Diagnosis_SecurityPowerSupply(unsigned char chError)
   
   <b>Beschreibung:</b><br>
   Sicherheitsfunktion 'Synchronistation'. Diese wird im Falle eines Fehlers in der Kommunication mit dem Partner aufgerufen.
    
   \param
   chError: Fehlerkennzeichnung
   
   \return
   ./.
   
   <b>Zugriff:</b><br>
   [X] �ffentlich / [ ] Privat
   */
   /*~E:A114*/
   /*~C:115*/
   switch (chError)
   /*~-1*/
   {
      /*~F:116*/
      case SYTEM_ERROR_INTERNAL_COMMUNICATION:
      /*~-1*/
      {
         /*~I:117*/
         if (!(Diagnosis.ulBlockMask & BLOCKMASK_ERROR_INTERNAL_COMMUNICATION))
         /*~-1*/
         {
            /*~T*/
            // Sperrmaske setzen
            Diagnosis.ulBlockMask |= BLOCKMASK_ERROR_INTERNAL_COMMUNICATION;
            /*~T*/
            // Eintrag in den Diagnosespeicher vornehmen
            Diagnosis_WriteMessage2Flash(DIAGNOSIS_ERROR_INTERNAL_COMMUNICATION);

         /*~-1*/
         }
         /*~E:I117*/
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F116*/
   /*~-1*/
   }
   /*~E:C115*/
   /*~I:118*/
#ifdef MIT_SICHERHEITSALARM_FUNKTION
   /*~T*/
   System_SetSystemState(SYSTEM_ERROR);
   /*~-1*/
#endif
   /*~E:I118*/
/*~-1*/
}
/*~E:F113*/
/*~E:A112*/
/*~A:119*/
/*~+:void Diagnosis_SecurityMemory(unsigned char chError)*/
/*~F:120*/
void Diagnosis_SecurityMemory(unsigned char chError)
/*~-1*/
{
   /*~C:121*/
   switch (chError)
   /*~-1*/
   {
      /*~A:122*/
      /*~+:Beschreibung*/
      /*~T*/
      /*!
      \fn void Diagnosis_SecurityMemory(unsigned char chError)
      
      <b>Beschreibung:</b><br>
      Sicherheitsfunktion 'Speicherzugriff'. Diese wird im Falle eines fehlerhaften Speicherzugriffs aufgerufen.
       
      \param
      chError: Fehlerkennzeichnung
      
      \return
      ./.
      
      <b>Zugriff:</b><br>
      [X] �ffentlich / [ ] Privat
      */
      /*~E:A122*/
      /*~A:123*/
      /*~+:DYNAMIC_VARIABLES*/
      /*~F:124*/
      case DYNAMIC_VARIABLES:
      /*~-1*/
      {
         /*~I:125*/
         if (!(Diagnosis.ulBlockMask & BLOCKMASK_MEMORY_DYNAMIC_VARIABLES))
         /*~-1*/
         {
            /*~T*/
            // Sperrmaske setzen
            Diagnosis.ulBlockMask |= BLOCKMASK_MEMORY_DYNAMIC_VARIABLES;
            /*~T*/
            Diagnosis_WriteMessage2Flash(DIAGNOSIS_ERROR_MEMORY_DYNAMIC_VARIABLES);
         /*~-1*/
         }
         /*~E:I125*/
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F124*/
      /*~E:A123*/
      /*~A:126*/
      /*~+:WRITE_EEPROM*/
      /*~F:127*/
      case WRITE_EEPROM:
      /*~-1*/
      {
         /*~I:128*/
         if (!(Diagnosis.ulBlockMask & BLOCKMASK_MEMORY_WRITE_EEPROM))
         /*~-1*/
         {
            /*~T*/
            // Sperrmaske setzen
            Diagnosis.ulBlockMask |= BLOCKMASK_MEMORY_WRITE_EEPROM;
            /*~T*/
            Diagnosis_WriteMessage2Flash(DIAGNOSIS_ERROR_MEMORY_WRITE_EEPROM);

         /*~-1*/
         }
         /*~E:I128*/
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F127*/
      /*~E:A126*/
      /*~A:129*/
      /*~+:READ_EEPROM*/
      /*~F:130*/
      case READ_EEPROM:
      /*~-1*/
      {
         /*~I:131*/
         if (!(Diagnosis.ulBlockMask & BLOCKMASK_MEMORY_READ_EEPROM))
         /*~-1*/
         {
            /*~T*/
            // Sperrmaske setzen
            Diagnosis.ulBlockMask |= BLOCKMASK_MEMORY_READ_EEPROM;
            /*~T*/
            Diagnosis_WriteMessage2Flash(DIAGNOSIS_ERROR_MEMORY_READ_EEPROM);

         /*~-1*/
         }
         /*~E:I131*/
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F130*/
      /*~E:A129*/
      /*~A:132*/
      /*~+:WRITE_FLASH*/
      /*~F:133*/
      case WRITE_FLASH:
      /*~-1*/
      {
         /*~I:134*/
         if (!(Diagnosis.ulBlockMask & BLOCKMASK_MEMORY_WRITE_FLASH))
         /*~-1*/
         {
            /*~T*/
            // Sperrmaske setzen
            Diagnosis.ulBlockMask |= BLOCKMASK_MEMORY_WRITE_FLASH;
            /*~T*/
            Diagnosis_WriteMessage2Flash(DIAGNOSIS_ERROR_MEMORY_WRITE_FLASH);

         /*~-1*/
         }
         /*~E:I134*/
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F133*/
      /*~E:A132*/
      /*~A:135*/
      /*~+:READ_FLASH*/
      /*~F:136*/
      case READ_FLASH:
      /*~-1*/
      {
         /*~I:137*/
         if (!(Diagnosis.ulBlockMask & BLOCKMASK_MEMORY_READ_FLASH))
         /*~-1*/
         {
            /*~T*/
            // Sperrmaske setzen
            Diagnosis.ulBlockMask |= BLOCKMASK_MEMORY_READ_FLASH;
            /*~T*/
            Diagnosis_WriteMessage2Flash(DIAGNOSIS_ERROR_MEMORY_READ_FLASH);

         /*~-1*/
         }
         /*~E:I137*/
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F136*/
      /*~E:A135*/
      /*~I:138*/
#ifdef MIT_SICHERHEITSALARM_FUNKTION
      /*~T*/
      System_SetSystemState(SYSTEM_ERROR);
      /*~-1*/
#endif
      /*~E:I138*/
   /*~-1*/
   }
   /*~E:C121*/
/*~-1*/
}
/*~E:F120*/
/*~E:A119*/
/*~A:139*/
/*~+:void Diagnosis_SecurityPartnerSystemError(unsigned char chError)*/
/*~F:140*/
void Diagnosis_SecurityPartnerSystemError(unsigned char chError)
/*~-1*/
{
   /*~A:141*/
   /*~+:Beschreibung*/
   /*~T*/
   /*!
   \fn void Diagnosis_SecurityPowerSupply(unsigned char chError)
   
   <b>Beschreibung:</b><br>
   Sicherheitsfunktion 'Netzteilspannung'. Diese wird im Falle eines Fehlers in der Spannungsversorgung aufgerufen.
    
   \param
   chError: Fehlerkennzeichnung
   
   \return
   ./.
   
   <b>Zugriff:</b><br>
   [X] �ffentlich / [ ] Privat
   */
   /*~E:A141*/
   /*~C:142*/
   switch (chError)
   /*~-1*/
   {
      /*~F:143*/
      case SYSTEM_PARTNER_IN_SYSTEMERROR:
      /*~-1*/
      {
         /*~I:144*/
         if (!(Diagnosis.ulBlockMask & BLOCKMASK_GLOBAL_PARTNER_IN_SYSTEMERROR))
         /*~-1*/
         {
            /*~T*/
            // Sperrmaske setzen
            Diagnosis.ulBlockMask |= BLOCKMASK_GLOBAL_PARTNER_IN_SYSTEMERROR;
            /*~T*/
            // Eintrag in den Diagnosespeicher vornehmen
            Diagnosis_WriteMessage2Flash(DIAGNOSIS_ERROR_PARTNER_IN_SYSTEMERROR);

         /*~-1*/
         }
         /*~E:I144*/
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F143*/
   /*~-1*/
   }
   /*~E:C142*/
   /*~I:145*/
#ifdef MIT_SICHERHEITSALARM_FUNKTION
   /*~T*/
   System_SetSystemState(SYSTEM_ERROR);
   /*~-1*/
#endif
   /*~E:I145*/
/*~-1*/
}
/*~E:F140*/
/*~E:A139*/
/*~A:146*/
/*~+:void Diagnosis_SecurityPowerSupply(unsigned char chError)*/
/*~F:147*/
void Diagnosis_SecurityPowerSupply(unsigned char chError)
/*~-1*/
{
   /*~A:148*/
   /*~+:Beschreibung*/
   /*~T*/
   /*!
   \fn void Diagnosis_SecurityPowerSupply(unsigned char chError)
   
   <b>Beschreibung:</b><br>
   Sicherheitsfunktion 'Netzteilspannung'. Diese wird im Falle eines Fehlers in der Spannungsversorgung aufgerufen.
    
   \param
   chError: Fehlerkennzeichnung
   
   \return
   ./.
   
   <b>Zugriff:</b><br>
   [X] �ffentlich / [ ] Privat
   */
   /*~E:A148*/
   /*~C:149*/
   switch (chError)
   /*~-1*/
   {
      /*~F:150*/
      case POWERSUPPLY_OUT_OF_LIMITS:
      /*~-1*/
      {
         /*~I:151*/
         if (!(Diagnosis.ulBlockMask & BLOCKMASK_POWERSUPPLY_OUT_OF_LIMITS))
         /*~-1*/
         {
            /*~T*/
            // Sperrmaske setzen
            Diagnosis.ulBlockMask |= BLOCKMASK_POWERSUPPLY_OUT_OF_LIMITS;
            /*~T*/
            // Eintrag in den Diagnosespeicher vornehmen
            Diagnosis_WriteMessage2Flash(DIAGNOSIS_ERROR_POWERSUPPLY_OUT_OF_LIMITS);

         /*~-1*/
         }
         /*~E:I151*/
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F150*/
      /*~F:152*/
      case POWERSUPPLY_VCC_NOK:
      /*~-1*/
      {
         /*~I:153*/
         if (!(Diagnosis.ulBlockMask & BLOCKMASK_POWERSUPPLY_NOK))
         /*~-1*/
         {
            /*~T*/
            // Sperrmaske setzen
            Diagnosis.ulBlockMask |= BLOCKMASK_POWERSUPPLY_NOK;
            /*~T*/
            // Eintrag in den Diagnosespeicher vornehmen
            Diagnosis_WriteMessage2Flash(DIAGNOSIS_ERROR_POWERSUPPLY_STATE);

         /*~-1*/
         }
         /*~E:I153*/
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F152*/
   /*~-1*/
   }
   /*~E:C149*/
   /*~T*/
   System_SetSystemState(SYSTEM_ERROR);
/*~-1*/
}
/*~E:F147*/
/*~E:A146*/
