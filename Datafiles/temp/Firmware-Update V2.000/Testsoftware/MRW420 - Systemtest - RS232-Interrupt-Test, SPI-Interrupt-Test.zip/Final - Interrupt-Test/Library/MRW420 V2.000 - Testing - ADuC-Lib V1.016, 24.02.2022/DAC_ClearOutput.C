/*~-1*/
/*~XSF_LANGUAGE: C/C++*/
/*~T*/
/*

   (1) MODULNAME             :  DAC_ClearOutput.c
   (2) VERSION               :  1.00
   (3) DATUM                 :  

   (4) LETZTE �NDERUNG       :  
   (5) PROJEKT (Vers.)       :  MRW Limit
   (6) PROGRAMMIERER         :  MOF

*/
/*~A:1*/
/*~+:Includes*/
/*~T*/
#include "DAC_Global.h"
#include "string.h"
/*~E:A1*/
/*~A:2*/
/*~+:Defines */
/*~T*/

/*~E:A2*/
/*~A:3*/
/*~+:Funktionsprototypen*/
/*~T*/
unsigned char ADuC836_DACClearOutput(char chMode);
/*~E:A3*/
/*~A:4*/
/*~+:Globale Variablen*/
/*~T*/

/*~E:A4*/
/*~A:5*/
/*~+:unsigned char ADuC836_DACClearOutput(char chMode)*/
/*~F:6*/
unsigned char ADuC836_DACClearOutput(char chMode)
/*~-1*/
{
   /*~A:7*/
   /*~+:Beschreibung*/
   /*~T*/
   /*!
   \fn unsigned char ADuC836_DACClearOutput(char chMode)
   
   <b>Beschreibung:</b><br>
   Diese Funktion erm�glicht das L�schen/Zur�cksetzen des DAC-Ausgangs  
   
   \param
   chMode: 
   \param
   0 = Normale Betriebsart.
   \param
   1 = L�schen das DAC-Ausgangs.
   \param
   >1 = Nur R�ckgabe.  
   
   \return
   Zustand des SFR-Bits DACCON./DACCLR.
   
   <b>Zugriff:</b><br>
   [X] �ffentlich / [ ] Privat
   
   \ref
   ExamplePage_ADuC836Driver "Beispiel 'ADuC836-Treiber'"
   */
   /*~E:A7*/
   /*~I:8*/
   if (chMode < 2)
   /*~-1*/
   {
      /*~I:9*/
      if (chMode == 1)
      /*~-1*/
      {
         /*~T*/
         g_DAC.Results.fLastCurrent = 0;
      /*~-1*/
      }
      /*~E:I9*/
      /*~T*/
      chMode ^= 0x01;
      chMode <<= 1;
      DACCON &= 0xFD;
      DACCON |= chMode;
   /*~-1*/
   }
   /*~E:I8*/
   /*~T*/
   return ((DACCON & 0x02) >> 1);
/*~-1*/
}
/*~E:F6*/
/*~E:A5*/
