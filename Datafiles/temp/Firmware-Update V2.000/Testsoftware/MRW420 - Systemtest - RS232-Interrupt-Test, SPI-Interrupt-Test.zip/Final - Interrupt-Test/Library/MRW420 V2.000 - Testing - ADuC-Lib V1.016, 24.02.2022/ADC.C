/*~-1*/
/*~XSF_LANGUAGE: C/C++*/
/*~T*/
/*

   (1) MODULNAME             :  ADC.c
   (2) VERSION               :  1.00
   (3) DATUM                 :  

   (4) LETZTE �NDERUNG       :  
   (5) PROJEKT (Vers.)       :  ADuc836-Driver
   (6) PROGRAMMIERER         :  MOF

*/
/*~A:1*/
/*~+:Includes*/
/*~T*/
#include "ADC_Global.h"
/*~E:A1*/
/*~A:2*/
/*~+:Defines */
/*~T*/

/*~E:A2*/
/*~A:3*/
/*~+:Funktionsprototypen*/
/*~T*/
void ADuC836_ADC(void);
/*~E:A3*/
/*~A:4*/
/*~+:Modulvariablen*/
/*~T*/
extern ADC_SETTINGS ADC_Settings[];		///< ADC-Parameter f�r Haupt- und Hilfs-ADC
extern ADC_RESULTS 	ADC_Results[];			///< Ergebnisse der AD-Wandlungen
/*~E:A4*/
/*~F:5*/
void ADuC836_ADC(void)
/*~-1*/
{
   /*~A:6*/
   /*~+:Variablendeklarationen*/
   /*~T*/
   unsigned char byChannel;
   //unsigned char bDataConverted[4];
   // long lADC;
   /*~E:A6*/
   /*~A:7*/
   /*~+:Variableninitialisierungen*/
   /*~T*/

   /*~E:A7*/
   /*~L:8*/
   for (byChannel = ADuC836_ADC_PRIMARY;byChannel <= ADuC836_ADC_AUXILIARY_TOGGLE;byChannel++)
   /*~-1*/
   {
      /*~I:9*/
      if (g_ADC.Results[byChannel].bDataConverted == 1)
      /*~-1*/
      {
         /*~F:10*/
         // Muss noch untersucht werden
         /*~-1*/
         {
            /*~T*/
            // ADC-Interrupt sperren
            EADC = 0;
            /*~T*/
            g_ADC.Results[byChannel].lProvisionalResult += ((long)g_ADC.Results[byChannel].byADCxH << 8) + (long)g_ADC.Results[byChannel].byADCxM;
            /*~T*/
            g_ADC.Results[byChannel].bDataConverted = 0;
            /*~T*/
            // ADC-Interrupt wieder freigeben
            EADC = 1;
            /*~F:11*/
            // Messwerttiefe ber�cksichtigen
            /*~-1*/
            {
               /*~T*/
               g_ADC.byMeasurementCounter[byChannel]++;
               /*~I:12*/
               if ((g_ADC.byMeasurementCounter[byChannel] == g_ADC.Settings[byChannel].byMeasurementDepth)||(g_ADC.Settings[byChannel].byMeasurementDepth == 0))
               /*~-1*/
               {
                  /*~T*/
                  g_ADC.Results[byChannel].lResult = g_ADC.Results[byChannel].lProvisionalResult - g_ADC.Settings[byChannel].lZeroOffset;
                  /*~T*/
                  // Variablen wieder zur�cksetzen
                  g_ADC.Results[byChannel].lProvisionalResult = 0;
                  g_ADC.byMeasurementCounter[byChannel] = 0;

                  /*~T*/
                  // Das Flag beinhaltet noch die Information, von welchem Multiplexereingang das Eingangssignal kam
                  g_ADC.Results[byChannel].byNewConversionValueFlag = 1 + ((g_ADC.Settings[byChannel].byADCCON >> 4) & 0x03);
               /*~-1*/
               }
               /*~E:I12*/
            /*~-1*/
            }
            /*~E:F11*/
         /*~-1*/
         }
         /*~E:F10*/
      /*~-1*/
      }
      /*~E:I9*/
   /*~-1*/
   }
   /*~E:L8*/
/*~-1*/
}
/*~E:F5*/
