/*~-1*/
/*~XSF_LANGUAGE: C/C++*/
/*~T*/
/*

   (1) MODULNAME             :  DAC_SetOutput.c
   (2) VERSION               :  1.00
   (3) DATUM                 :  

   (4) LETZTE �NDERUNG       :  
   (5) PROJEKT (Vers.)       :  MRW Limit
   (6) PROGRAMMIERER         :  MOF

*/
/*~A:1*/
/*~+:Includes*/
/*~T*/
#include "DAC_Global.h"
#include "string.h"
/*~E:A1*/
/*~A:2*/
/*~+:Defines */
/*~T*/

/*~E:A2*/
/*~A:3*/
/*~+:Funktionsprototypen*/
/*~T*/
unsigned char ADuC836_DACSetOutput(char chMode);
/*~E:A3*/
/*~A:4*/
/*~+:Globale Variablen*/
/*~T*/

/*~E:A4*/
/*~A:5*/
/*~+:unsigned char ADuC836_DACSetOutput(char chMode)*/
/*~F:6*/
unsigned char ADuC836_DACSetOutput(char chMode)
/*~-1*/
{
   /*~A:7*/
   /*~+:Beschreibung*/
   /*~T*/
   /*!
   \fn unsigned char ADuC836_DACSetOutput(char chMode)
   
   <b>Beschreibung:</b><br>
   Setzen des ADuC836-DAC-Ausgangspins.
    
   \param
   chMode:
   \param
   0 = DAC-Ausgang an Pin 3. 
   \param
   1 = DAC-Ausgang an Pin 12.
   \param
   >1 = Nur R�ckgabe.
   
   \return
   Zustand des SFR-Bits DACCON.PIN.
   
   <b>Zugriff:</b><br>
   [X] �ffentlich / [ ] Privat
   
   \ref
   
   ExamplePage_ADuC836Driver "Beispiel 'ADuC836-Treiber'"
   */

   /*~E:A7*/
   /*~I:8*/
   if (chMode < 2)
   /*~-1*/
   {
      /*~T*/
      chMode <<= 4;
      DACCON &= 0xE8;
      DACCON |= chMode;
   /*~-1*/
   }
   /*~E:I8*/
   /*~T*/
   return ((DACCON & 0x10)>>4);
/*~-1*/
}
/*~E:F6*/
/*~E:A5*/
