/*~-1*/
/*~XSF_LANGUAGE: C/C++*/
/*~K*/
/*~+:File :        SPI_SendChar.c*/
/*~+:*/
/*~+:Version :     V1.0*/
/*~+:*/
/*~+:Date :        14.06.2005*/
/*~+:*/
/*~+:Time :        10:23*/
/*~+:*/
/*~+:Author :      MOF*/
/*~+:*/
/*~+:Hardware :*/
/*~+:*/
/*~+:Description :*/
/*~A:1*/
/*~+:Includes*/
/*~T*/
#include "ADuC836Driver.h"
#include "SPI_Global.h"
/*~E:A1*/
/*~T*/
#include "String.h"
/*~A:2*/
/*~+:Funktionseigene Definitionen*/
/*~T*/

/*~E:A2*/
/*~A:3*/
/*~+:Funktionseigene Struktur-Definitionen*/
/*~T*/

/*~E:A3*/
/*~A:4*/
/*~+:Funktionsprototypen*/
/*~T*/
char ADuC836_SPISendChar(unsigned char chData);
/*~E:A4*/
/*~A:5*/
/*~+:Globale Variablen*/
/*~T*/

/*~E:A5*/
/*~A:6*/
/*~+:char ADuC836_SPISendChar(unsigned char chData)*/
/*~F:7*/
char ADuC836_SPISendChar(unsigned char chData)
/*~-1*/
{
   /*~A:8*/
   /*~+:Beschreibung*/
   /*~T*/
   /*!
   \fn char ADuC836_SPISendChar(unsigned char chData)
   
   <b>Beschreibung:</b><br>
   Sendet ein Zeichen �ber die SPI-Schnittstelle.
   
   \param
   chData: zu sendendes Zeichen.
   
   \return
   Status der Funktionsausf�hrung.
   
   \retval
   0 : Alles okay.
   \retval
   1 : Timeout
   \retval
   2 : Datenkollision(z.Z.nicht aktiv)
   
   <b>Zugriff:</b><br>
   [X] �ffentlich / [ ] Privat
   
   \ref
   ExamplePage_ADuC836Driver "Beispiel 'ADuC836-Treiber'"
   */

   /*~E:A8*/
   /*~A:9*/
   /*~+:Variablendeklarationen*/
   /*~T*/
   unsigned char 			byTimeoutTimer;

   /*~I:10*/
#ifdef SPI_DEBUG_SLAVE_COMMUNICATION
   /*~T*/
   static unsigned char* pchTransBuffer;
   /*~-1*/
#endif
   /*~E:I10*/
   /*~I:11*/
#ifdef SPI_DEBUG_MASTER_COMMUNICATION 
   /*~T*/
   static unsigned char* pchTransBuffer;
   /*~-1*/
#endif
   /*~E:I11*/
   /*~E:A9*/
   /*~A:12*/
   /*~+:Variableninitialisierungen*/
   /*~T*/
   byTimeoutTimer = 10;

   /*~E:A12*/
   /*~I:13*/
#ifdef MOF
   /*~A:14*/
   /*~+:FOR_DEBUGGING_ONLY*/
   /*~I:15*/
#ifdef SPI_SLAVE
   /*~I:16*/
#ifdef SPI_DEBUG_SLAVE_COMMUNICATION
   /*~I:17*/
   if (chData == 0x02)
   /*~-1*/
   {
      /*~T*/
      pchTransBuffer = RS232.pchTransBuffer; 
      /*~T*/
      *pchTransBuffer++ = '(';
      *pchTransBuffer++ = 'S';
      *pchTransBuffer++ = ')';
      *pchTransBuffer++ = '>';
      *pchTransBuffer++ = '[';
      *pchTransBuffer++ = 'S';
      *pchTransBuffer++ = 'T';
      *pchTransBuffer++ = 'X';
      *pchTransBuffer++ = ']';
      *pchTransBuffer = 0;
   /*~-1*/
   }
   /*~O:I17*/
   /*~-2*/
   else
   {
      /*~I:18*/
      if (chData == 0x03)
      /*~-1*/
      {
         /*~T*/
         *pchTransBuffer++ = '[';
         *pchTransBuffer++ = 'E';
         *pchTransBuffer++ = 'T';
         *pchTransBuffer++ = 'X';
         *pchTransBuffer++ = ']';
         *pchTransBuffer = 0;

         TI = 1;
      /*~-1*/
      }
      /*~O:I18*/
      /*~-2*/
      else
      {
         /*~T*/
         *pchTransBuffer++ = chData;
         *pchTransBuffer = 0;
      /*~-1*/
      }
      /*~E:I18*/
   /*~-1*/
   }
   /*~E:I17*/
   /*~-1*/
#endif
   /*~E:I16*/
   /*~O:I15*/
   /*~-1*/
#else
   /*~I:19*/
#ifdef SPI_DEBUG_MASTER_COMMUNICATION
   /*~I:20*/
   if (chData == 0x02)
   /*~-1*/
   {
      /*~T*/
      pchTransBuffer = RS232.pchTransBuffer; 
      /*~T*/
      *pchTransBuffer++ = '(';
      *pchTransBuffer++ = 'M';
      *pchTransBuffer++ = ')';
      *pchTransBuffer++ = '>';
      *pchTransBuffer++ = '[';
      *pchTransBuffer++ = 'S';
      *pchTransBuffer++ = 'T';
      *pchTransBuffer++ = 'X';
      *pchTransBuffer++ = ']';
      *pchTransBuffer = 0;
   /*~-1*/
   }
   /*~O:I20*/
   /*~-2*/
   else
   {
      /*~I:21*/
      if (chData == 0x03)
      /*~-1*/
      {
         /*~T*/
         *pchTransBuffer++ = '[';
         *pchTransBuffer++ = 'E';
         *pchTransBuffer++ = 'T';
         *pchTransBuffer++ = 'X';
         *pchTransBuffer++ = ']';
         *pchTransBuffer = 0;

         TI = 1;
      /*~-1*/
      }
      /*~O:I21*/
      /*~-2*/
      else
      {
         /*~T*/
         *pchTransBuffer++ = chData;
         *pchTransBuffer = 0;
      /*~-1*/
      }
      /*~E:I21*/
   /*~-1*/
   }
   /*~E:I20*/
   /*~-1*/
#endif
   /*~E:I19*/
   /*~-1*/
#endif
   /*~E:I15*/
   /*~E:A14*/
   /*~-1*/
#endif
   /*~E:I13*/
   /*~T*/
   ISPI = 0;

   // Datum ins SPI-Senderegister eintragen 
   SPIDAT = chData;

   /*~K*/
   /*~+:Warte bis die Daten gesendet sind - Timeout liefert 2 zur�ck*/
   /*~L:22*/
   while ((!ISPI)&&(--byTimeoutTimer))
   /*~-1*/
   {
      /*~T*/

   /*~-1*/
   }
   /*~E:L22*/
   /*~I:23*/
   if (ISPI)
   /*~-1*/
   {
      /*~T*/
      //ISPI = 0;
      /*~T*/
      return 0;
   /*~-1*/
   }
   /*~O:I23*/
   /*~-2*/
   else
   {
      /*~I:24*/
#ifdef ADUC836_SPI_GLOBALS_DEBUG_COM
      /*~T*/
      // inkrementiere den Fehlerz�hler
      ADuC836_SPIIncErrors(SPI_ERROR_SENDCHAR);
      /*~-1*/
#endif
      /*~E:I24*/
      /*~T*/
      return 1;
   /*~-1*/
   }
   /*~E:I23*/
/*~-1*/
}
/*~E:F7*/
/*~E:A6*/
