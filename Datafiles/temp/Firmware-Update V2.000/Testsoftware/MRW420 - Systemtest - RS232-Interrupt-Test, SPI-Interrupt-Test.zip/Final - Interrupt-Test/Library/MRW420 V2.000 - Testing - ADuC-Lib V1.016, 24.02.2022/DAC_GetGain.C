/*~-1*/
/*~XSF_LANGUAGE: C/C++*/
/*~T*/
/*

   (1) MODULNAME             :  DAC_GetGain.c
   (2) VERSION               :  1.00
   (3) DATUM                 :  

   (4) LETZTE �NDERUNG       :  
   (5) PROJEKT (Vers.)       :  MRW Limit
   (6) PROGRAMMIERER         :  MOF

*/
/*~A:1*/
/*~+:Includes*/
/*~T*/
#include "DAC_Global.h"
#include "string.h"
/*~E:A1*/
/*~A:2*/
/*~+:Defines */
/*~T*/

/*~E:A2*/
/*~A:3*/
/*~+:Funktionsprototypen*/
/*~T*/
float ADuC836_DACGetGain(unsigned char byWhat2Get);
/*~E:A3*/
/*~A:4*/
/*~+:Globale Variablen*/
/*~T*/

/*~E:A4*/
/*~A:5*/
/*~+:float ADuC836_DACGetGain(unsigned char byWhat2Get)*/
/*~F:6*/
float ADuC836_DACGetGain(unsigned char byWhat2Get)
/*~-1*/
{
   /*~A:7*/
   /*~+:Beschreibung*/
   /*~T*/
   /*!
   \fn float ADuC836_DACGetGain(unsigned char byWhat2Get)
   
   <b>Beschreibung:</b><br>
   Ausgabe des Verst�rkungsfaktor der DAC-Normierung.
   
   \param
   byWhat2Get: 0 = Verst�rkung der Normierung der Rohmesswerte, 1 = Verst�rkung der Normierung der Ausgangsgr��e.
   
   \retval
   Verst�rkungsfaktor der DAC-Normierung.
   
   <b>Zugriff:</b><br>
   [X] �ffentlich / [ ] Privat
   
   \ref
   ExamplePage_ADuC836Driver "Beispiel 'ADuC836-Treiber'"
   */
   /*~E:A7*/
   /*~C:8*/
   switch (byWhat2Get)
   /*~-1*/
   {
      /*~F:9*/
      case 0:
      /*~-1*/
      {
         /*~T*/
         return g_DAC.Settings.fGain_RMV;
      /*~-1*/
      }
      /*~E:F9*/
      /*~F:10*/
      case 1:
      /*~-1*/
      {
         /*~T*/
         return g_DAC.Settings.fGain_Norm;
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F10*/
   /*~-1*/
   }
   /*~E:C8*/
/*~-1*/
}
/*~E:F6*/
/*~E:A5*/
