/*~-1*/
/*~XSF_LANGUAGE: C/C++*/
/*~K*/
/*~+:File :        DAC_Global.h*/
/*~+:*/
/*~+:Version :     V1.000*/
/*~+:*/
/*~+:Date :        */
/*~+:Time :        */
/*~+:*/
/*~+:Author :      MOF*/
/*~+:*/
/*~+:Hardware :*/
/*~+:*/
/*~+:Description :*/
/*~I:1*/
#ifndef __DAC_GLOBAL_H 
/*~T*/
#define __DAC_GLOBAL_H
/*~A:2*/
/*~+:Konfiguration*/
/*~T*/

/*~E:A2*/
/*~A:3*/
/*~+:Includes*/
/*~T*/
#include "ADuC836Driver.h"
/*~E:A3*/
/*~A:4*/
/*~+:Definitionen*/
/*~T*/
#define DAC_NO_LIMIT_REACHED			0
#define DAC_LOWER_LIMIT_REACHED			1
#define DAC_LOWER_UPPER_REACHED			2
/*~E:A4*/
/*~A:5*/
/*~+:Strukturdefinitionen*/
/*~T*/
typedef struct
{
	long lRMV_DAC;									///< aktueller digitaler Wert der Wandlung ohne Offset- und Gain-Verrechnung

	long lActualConvertionValue;					///< aktueller digitaler Wert der Wandlung inklusive Offset- und Gain-Verrechnung

	float fLastCurrent;								///< Letzter gewandelter Stromwert
	unsigned char byLimitReached;					///< Merker f�r erreichte Grenzwert�berschreitungen
}DAC_RESULTS;
/*~T*/
typedef struct
{
	long lOffset;									///< Offset f�r Korrekturen (z.B. R�ckkopplung)
	DAC_SETTINGS Settings;
	DAC_RESULTS Results;
}DAC;
/*~E:A5*/
/*~A:6*/
/*~+:Funktionsdeklarationen*/
/*~T*/

/*~E:A6*/
/*~A:7*/
/*~+:Variablendeklarationen*/
/*~T*/
extern DAC g_DAC;
/*~E:A7*/
/*~-1*/
#endif
/*~E:I1*/
