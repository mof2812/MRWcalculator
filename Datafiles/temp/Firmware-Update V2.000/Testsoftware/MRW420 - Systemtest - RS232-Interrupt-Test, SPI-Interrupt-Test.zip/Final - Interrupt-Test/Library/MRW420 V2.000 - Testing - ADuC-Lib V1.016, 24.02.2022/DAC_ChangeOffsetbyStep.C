/*~-1*/
/*~XSF_LANGUAGE: C/C++*/
/*~T*/
/*

   (1) MODULNAME             :  DAC_ChangeOffsetbyStep.c
   (2) VERSION               :  1.00
   (3) DATUM                 :  

   (4) LETZTE �NDERUNG       :  
   (5) PROJEKT (Vers.)       :  MRW Limit
   (6) PROGRAMMIERER         :  MOF

*/
/*~A:1*/
/*~+:Includes*/
/*~T*/
#include "DAC_Global.h"
#include "string.h"
/*~E:A1*/
/*~A:2*/
/*~+:Defines */
/*~T*/

/*~E:A2*/
/*~A:3*/
/*~+:Funktionsprototypen*/
/*~T*/
long ADuC836_DACChangeOffsetbyStep(long lStep);
/*~E:A3*/
/*~A:4*/
/*~+:Globale Variablen*/
/*~T*/

/*~E:A4*/
/*~A:5*/
/*~+:long ADuC836_DACChangeOffsetbyStep(long lStep)*/
/*~F:6*/
long ADuC836_DACChangeOffsetbyStep(long lStep)

/*~-1*/
{
   /*~A:7*/
   /*~+:Beschreibung*/
   /*~T*/
   /*!
   \fn long ADuC836_DACChangeOffsetbyStep(long lStep)
   
   <b>Beschreibung:</b><br>
   Ver�ndern des Offsets um einen bestimmten Wert.
   
   \param
   lStep: Schrittweite, um die der Offset ver�ndert werden soll.
   
   \return
   Neuer Offsetwert.
   
   <b>Zugriff:</b><br>
   [X] �ffentlich / [ ] Privat
   
   \ref
   ExamplePage_ADuC836Driver "Beispiel 'ADuC836-Treiber'"
   */
   /*~E:A7*/
   /*~T*/
   g_DAC.Settings.fOffset_Norm += lStep;

   return(g_DAC.Settings.fOffset_RMV += lStep);
/*~-1*/
}
/*~E:F6*/
/*~E:A5*/
