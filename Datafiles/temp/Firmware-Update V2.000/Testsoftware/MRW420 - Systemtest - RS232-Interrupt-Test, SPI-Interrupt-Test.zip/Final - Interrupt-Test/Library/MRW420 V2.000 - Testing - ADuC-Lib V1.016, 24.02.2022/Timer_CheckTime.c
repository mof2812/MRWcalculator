/*~-1*/
/*~XSF_LANGUAGE: C/C++*/
/*~K*/
/*~+:File :        Timer_CheckTime.c*/
/*~+:*/
/*~+:Version :     V1.000*/
/*~+:*/
/*~+:Date :        03.06.2005*/
/*~+:*/
/*~+:Time :        */
/*~+:*/
/*~+:Author :      MOF*/
/*~+:*/
/*~+:Hardware :*/
/*~+:*/
/*~+:Description :*/
/*~A:1*/
/*~+:Includes*/
/*~T*/
#include "ADuC836Driver.h"

/*~E:A1*/
/*~A:2*/
/*~+:Funktionseigene Definitionen*/
/*~T*/

/*~E:A2*/
/*~A:3*/
/*~+:Funktionseigene Struktur-Definitionen*/
/*~T*/

/*~E:A3*/
/*~A:4*/
/*~+:Funktionsprototypen*/
/*~T*/
unsigned char ADuC836_TimerCheckTime(unsigned char chWhichTimer,unsigned char chMode);
/*~E:A4*/
/*~A:5*/
/*~+:Globale Variablen*/
/*~T*/
extern TIMER Timer;
/*~E:A5*/
/*~A:6*/
/*~+:unsigned char ADuC836_TimerCheckTime(unsigned char chWhichTimer,unsigned char chMode)*/
/*~F:7*/
unsigned char ADuC836_TimerCheckTime(unsigned char chWhichTimer,unsigned char chMode)
/*~-1*/
{
   /*~A:8*/
   /*~+:Beschreibung*/
   /*~T*/
   /*!
   \fn unsigned char ADuC836_TimerCheckTime(unsigned char chWhichTimer,unsigned char chMode)
   
   <b>Beschreibung:</b><br>
   
   \param
   chWhichTimer: Kennzeichnung des Timers, welcher �berpr�ft werden soll.
   
   \param
   chMode: Beschreibt das Verhalten bei Erreichen der Zielzeit.
   \param
   0: Zielzeit wird nicht neu gesetzt.
   \param
   1: Zielzeit wird in Abh�ngigkeit der aktuellen Betriebszeit neu berechnet.   
   \param
   2: Zielzeit wird in Abh�ngigkeit der letzten Zielzeit neu berechnet.
   
   \return
   Status der Zeit�berwachung.
   
   \retval
   0: Zielzeit noch nicht erreicht.
   \retval
   1: Zielzeit erreicht.
   
   <b>Zugriff:</b><br>
   [X] �ffentlich / [ ] Privat
   
   \ref
   ExamplePage_ADuC836Driver "Beispiel 'ADuC836-Treiber'"
   */
   /*~E:A8*/
   /*~I:9*/
   if (Timer.ulDestinationTime[chWhichTimer] <= Timer.ulOperatingTime)
   /*~-1*/
   {
      /*~I:10*/
      if (chMode)
      /*~-1*/
      {
         /*~T*/
         ADuC836_TimerCalcNewDestinationTime(chWhichTimer,chMode-1);
      /*~-1*/
      }
      /*~E:I10*/
      /*~T*/
      return 1;
   /*~-1*/
   }
   /*~O:I9*/
   /*~-2*/
   else
   {
      /*~T*/
      return 0;
   /*~-1*/
   }
   /*~E:I9*/
/*~-1*/
}
/*~E:F7*/
/*~E:A6*/
