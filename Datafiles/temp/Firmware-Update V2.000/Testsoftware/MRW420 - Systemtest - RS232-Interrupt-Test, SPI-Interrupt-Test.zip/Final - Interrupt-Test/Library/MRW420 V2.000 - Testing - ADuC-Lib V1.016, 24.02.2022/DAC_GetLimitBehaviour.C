/*~-1*/
/*~XSF_LANGUAGE: C/C++*/
/*~T*/
/*

   (1) MODULNAME             :  DAC_GetLimitBehaviour.c
   (2) VERSION               :  1.00
   (3) DATUM                 :  

   (4) LETZTE �NDERUNG       :  
   (5) PROJEKT (Vers.)       :  MRW Limit
   (6) PROGRAMMIERER         :  MOF

*/
/*~A:1*/
/*~+:Includes*/
/*~T*/
#include "DAC_Global.h"
#include "string.h"
/*~E:A1*/
/*~A:2*/
/*~+:Defines */
/*~T*/

/*~E:A2*/
/*~A:3*/
/*~+:Funktionsprototypen*/
/*~T*/
unsigned char  ADuC836_DACGetLimitBehaviour(unsigned char byWhichLimit);
/*~E:A3*/
/*~A:4*/
/*~+:Globale Variablen*/
/*~T*/

/*~E:A4*/
/*~A:5*/
/*~+:unsigned char  ADuC836_DACGetLimitBehaviour(unsigned char byWhichLimit)*/
/*~F:6*/
unsigned char ADuC836_DACGetLimitBehaviour(unsigned char byWhichLimit)
/*~-1*/
{
   /*~A:7*/
   /*~+:Beschreibung*/
   /*~T*/
   /*!
   \fn long ADuC836_DACGetLimit(unsigned char byWhichLimit)
   
   <b>Beschreibung:</b><br>
   Ausgabe des Verhaltensmusters bei DAC-Grenzwert�berschreitung.
   
   \param
   byWhichLimit: Angabe �ber den auszugebenden Grenzwert (0 = unterer Grenzwert, 1 = oberer Grenzwert)
   
   \return
   Verhaltensmusters bei DAC-Grenzwert�berschreitung.
   
   <b>Zugriff:</b><br>
   [X] �ffentlich / [ ] Privat
   
   \ref
   ExamplePage_ADuC836Driver "Beispiel 'ADuC836-Treiber'"
   */

   /*~E:A7*/
   /*~C:8*/
   switch (byWhichLimit)
   /*~-1*/
   {
      /*~F:9*/
      case ADUC836_DAC_LOWER_LIMIT:
      /*~-1*/
      {
         /*~T*/
         return g_DAC.Settings.Limits.byLowerLimitBehavior;
      /*~-1*/
      }
      /*~E:F9*/
      /*~F:10*/
      case ADUC836_DAC_UPPER_LIMIT:
      /*~-1*/
      {
         /*~T*/
         return g_DAC.Settings.Limits.byUpperLimitBehavior; 
      /*~-1*/
      }
      /*~E:F10*/
   /*~-1*/
   }
   /*~E:C8*/
/*~-1*/
}
/*~E:F6*/
/*~E:A5*/
