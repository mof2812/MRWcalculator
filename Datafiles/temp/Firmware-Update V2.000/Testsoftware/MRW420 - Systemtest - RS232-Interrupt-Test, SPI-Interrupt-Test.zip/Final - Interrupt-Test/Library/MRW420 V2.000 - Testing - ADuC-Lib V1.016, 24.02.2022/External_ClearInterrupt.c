/*~-1*/
/*~XSF_LANGUAGE: C/C++*/
/*~K*/
/*~+:File :        External_ClearInterrupt.c*/
/*~+:*/
/*~+:Version :     V1.0*/
/*~+:*/
/*~+:Date :        03.06.2005*/
/*~+:*/
/*~+:Time :        10:23*/
/*~+:*/
/*~+:Author :      MOF*/
/*~+:*/
/*~+:Hardware :*/
/*~+:*/
/*~+:Description :*/
/*~+:*/
/*~+:*/
/*~A:1*/
/*~+:Includes*/
/*~T*/
#include "ADuC836.h"
#include "ADuC836Driver.h"
/*~E:A1*/
/*~A:2*/
/*~+:Funktionseigene Definitionen*/
/*~T*/

/*~E:A2*/
/*~A:3*/
/*~+:Funktionseigene Struktur-Definitionen*/
/*~T*/

/*~E:A3*/
/*~A:4*/
/*~+:Funktionsprototypen*/
/*~T*/
void ADuC836_ExternalClearInterrupt(unsigned char chInterrupt2Clear);
/*~E:A4*/
/*~A:5*/
/*~+:Globale Variablen*/
/*~T*/

/*~E:A5*/
/*~A:6*/
/*~+:void ADuC836_ExternalClearInterrupt(unsigned char chInterrupt2Clear)*/
/*~F:7*/
void ADuC836_ExternalClearInterrupt(unsigned char chInterrupt2Clear)
/*~-1*/
{
   /*~C:8*/
   switch (chInterrupt2Clear)
   /*~-1*/
   {
      /*~F:9*/
      case EXTERNAL_INTERRUPT_0:
      /*~-1*/
      {
         /*~T*/
         IE0 = 0;
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F9*/
      /*~F:10*/
      case EXTERNAL_INTERRUPT_1:
      /*~-1*/
      {
         /*~T*/
         IE1 = 0;
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F10*/
   /*~-1*/
   }
   /*~E:C8*/
/*~-1*/
}
/*~E:F7*/
/*~E:A6*/
