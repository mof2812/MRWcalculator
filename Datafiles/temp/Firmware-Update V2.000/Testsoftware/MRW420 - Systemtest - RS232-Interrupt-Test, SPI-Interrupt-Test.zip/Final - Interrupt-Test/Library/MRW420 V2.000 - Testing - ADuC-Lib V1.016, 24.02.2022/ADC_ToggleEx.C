/*~-1*/
/*~XSF_LANGUAGE: C/C++*/
/*~T*/
/*

   (1) MODULNAME             :  ADC_ToggleEx.c
   (2) VERSION               :  1.00
   (3) DATUM                 :  

   (4) LETZTE �NDERUNG       :  
   (5) PROJEKT (Vers.)       :  MRW Limit
   (6) PROGRAMMIERER         :  MOF

*/
/*~A:1*/
/*~+:Includes*/
/*~T*/
#include "ADC_Global.h"
/*~E:A1*/
/*~A:2*/
/*~+:Defines */
/*~T*/

/*~E:A2*/
/*~A:3*/
/*~+:Funktionsprototypen*/
/*~T*/
void 		ADuC836_ADCToggleEx(unsigned char byADC,unsigned char byConversionChanel);
/*~E:A3*/
/*~A:4*/
/*~+:Modulvariablen*/
/*~T*/

/*~E:A4*/
/*~A:5*/
/*~+:void ADuC836_ADCToggleEx(unsigned char byADC,unsigned char byConversionChanel)*/
/*~F:6*/
void ADuC836_ADCToggleEx(unsigned char byADC,unsigned char byConversionChanel)
/*~-1*/
{
   /*~A:7*/
   /*~+:Variablendeklarationen*/
   /*~T*/
   unsigned char byChanel;
   /*~E:A7*/
   /*~A:8*/
   /*~+:Variableninitialisierungen*/
   /*~T*/

   /*~E:A8*/
   /*~T*/
   // Falls der automatische Toggle-Modus gesetzt war, diesen jetzt abschalten
   g_ADC.Settings[byADC].byToggleMode = 0;
   /*~I:9*/
   if (!byConversionChanel)
   /*~-1*/
   {
      /*~T*/
      g_ADC.byActualConversionChanel[byADC] = 0;
   /*~-1*/
   }
   /*~O:I9*/
   /*~-2*/
   else
   {
      /*~T*/
      g_ADC.byActualConversionChanel[byADC] = 1;
   /*~-1*/
   }
   /*~E:I9*/
   /*~T*/
   byChanel = byADC + 2*g_ADC.byActualConversionChanel[byADC];
   /*~I:10*/
   if (byChanel & 0x01)	// Auxiliary-ADC
   /*~-1*/
   {
      /*~T*/
      ADC1CON = g_ADC.Settings[byChanel].byADCCON;
   /*~-1*/
   }
   /*~O:I10*/
   /*~-2*/
   else
   {
      /*~T*/
      ADC0CON = g_ADC.Settings[byChanel].byADCCON;
   /*~-1*/
   }
   /*~E:I10*/
/*~-1*/
}
/*~E:F6*/
/*~E:A5*/
