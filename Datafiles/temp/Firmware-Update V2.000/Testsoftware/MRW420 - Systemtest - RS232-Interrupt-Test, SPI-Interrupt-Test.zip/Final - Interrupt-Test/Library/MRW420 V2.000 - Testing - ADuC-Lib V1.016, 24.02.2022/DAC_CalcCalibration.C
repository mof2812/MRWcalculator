/*~-1*/
/*~XSF_LANGUAGE: C/C++*/
/*~T*/
/*

   (1) MODULNAME             :  DAC_CalcCalibration.c
   (2) VERSION               :  1.00
   (3) DATUM                 :  

   (4) LETZTE �NDERUNG       :  
   (5) PROJEKT (Vers.)       :  MRW Limit
   (6) PROGRAMMIERER         :  MOF

*/
/*~A:1*/
/*~+:Includes*/
/*~T*/
#include "DAC_Global.h"
#include "string.h"
/*~E:A1*/
/*~A:2*/
/*~+:Defines */
/*~T*/

/*~E:A2*/
/*~A:3*/
/*~+:Funktionsprototypen*/
/*~T*/
unsigned char ADuC836_DACCalcCalibration(void);
/*~E:A3*/
/*~A:4*/
/*~+:Globale Variablen*/
/*~T*/

/*~E:A4*/
/*~A:5*/
/*~+:unsigned char ADuC836_DACCalcCalibration(void)*/
/*~F:6*/
/*#LJ:ADuC836_DACCalcCalibration=15*/
unsigned char ADuC836_DACCalcCalibration(void)

/*~-1*/
{
   /*~A:7*/
   /*~+:Beschreibung*/
   /*~T*/
   /*!
   \fn unsigned char ADuC836_DACCalcCalibration(void)
    
   <b>Beschreibung:</b><br>
   Normierung des DAC-Ausgangs aus mit der Hilfe von zwei zuvor gesetzten Referenzpunkten. Hierzu wird zun�chst die Kennlinie des DACs und anschlie�end die Sollkennlinie berechnet und hieraus der Offsetwert und der Verst�rkungsfaktor bestimmt.
   
   \param
   void:
   
   \return
   
   \retval
   0 : Kalibrierung erfolgreich abgeschlossen.
   \retval
   1 : Es wurden nicht gen�gend Referenzpunkte �bergeben.
   
   <b>Zugriff:</b><br>
   [X] �ffentlich / [ ] Privat
   
   \ref
   
   ExamplePage_ADuC836Driver "Beispiel 'ADuC836-Treiber'"
   */

   /*~E:A7*/
   /*~A:8*/
   /*~+:Variablendeklarationen*/
   /*~T*/
   float fDAC_Desired_CalibrationPoint[2];	// DAC-Digitalwerte bei den Sollausgangswerten

   /*~E:A8*/
   /*~I:9*/
   if (g_DAC.Settings.CalibrationPoint[0].byPointsSet & 0x03)
   /*~-1*/
   {
      /*~T*/
      // Messwert-Normierung

      g_DAC.Settings.fGain_Norm = (g_DAC.Settings.CalibrationPoint[1].fTrueValue - g_DAC.Settings.CalibrationPoint[0].fTrueValue) / (g_DAC.Settings.CalibrationPoint[1].lConvertionValue - g_DAC.Settings.CalibrationPoint[0].lConvertionValue);

      g_DAC.Settings.fOffset_Norm = g_DAC.Settings.CalibrationPoint[0].fTrueValue - g_DAC.Settings.fGain_Norm * g_DAC.Settings.CalibrationPoint[0].lConvertionValue;

      /*~T*/
      // RMW-Normierung
      // DAC-Sollwerte digital berechnen
      fDAC_Desired_CalibrationPoint[0] = (g_DAC.Settings.CalibrationPoint[0].fDesiredValue - g_DAC.Settings.fOffset_Norm) / g_DAC.Settings.fGain_Norm;
      fDAC_Desired_CalibrationPoint[1] = (g_DAC.Settings.CalibrationPoint[1].fDesiredValue - g_DAC.Settings.fOffset_Norm) / g_DAC.Settings.fGain_Norm;


      g_DAC.Settings.fGain_RMV = (fDAC_Desired_CalibrationPoint[1] - fDAC_Desired_CalibrationPoint[0]) / (float)(g_DAC.Settings.CalibrationPoint[1].lRMV - g_DAC.Settings.CalibrationPoint[0].lRMV);

      g_DAC.Settings.fOffset_RMV = fDAC_Desired_CalibrationPoint[0] - g_DAC.Settings.fGain_RMV * g_DAC.Settings.CalibrationPoint[0].lRMV;
      /*~T*/
      return 0;
   /*~-1*/
   }
   /*~O:I9*/
   /*~-2*/
   else
   {
      /*~T*/
      return 1;
   /*~-1*/
   }
   /*~E:I9*/
/*~-1*/
}
/*~E:F6*/
/*~E:A5*/
