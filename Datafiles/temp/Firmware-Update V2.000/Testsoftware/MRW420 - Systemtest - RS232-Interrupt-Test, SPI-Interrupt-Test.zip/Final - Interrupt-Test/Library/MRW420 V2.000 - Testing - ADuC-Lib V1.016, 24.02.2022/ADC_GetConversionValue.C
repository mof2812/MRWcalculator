/*~-1*/
/*~XSF_LANGUAGE: C/C++*/
/*~T*/
/*

   (1) MODULNAME             :  ADC_GetConversionValue.c
   (2) VERSION               :  1.01
   (3) DATUM                 :  01.11.2016

   (4) LETZTE �NDERUNG       :  
   (5) PROJEKT (Vers.)       :  MRW Limit
   (6) PROGRAMMIERER         :  MOF

*/
/*~A:1*/
/*~+:Includes*/
/*~T*/
#include "ADC_Global.h"
/*~E:A1*/
/*~A:2*/
/*~+:Defines */
/*~T*/

/*~E:A2*/
/*~A:3*/
/*~+:Funktionsprototypen*/
/*~T*/
long ADuC836_ADCGetConversionValue(unsigned char byADC_Chanel,unsigned char byIgnoreNewConversionFlag);
/*~E:A3*/
/*~A:4*/
/*~+:Modulvariablen*/
/*~T*/
extern ADC_SETTINGS ADC_Settings[];		///< ADC-Parameter f�r Haupt- und Hilfs-ADC
extern ADC_RESULTS 	ADC_Results[];			///< Ergebnisse der AD-Wandlungen
/*~E:A4*/
/*~I:5*/
#ifdef OKAY_OLD
/*~A:6*/
/*~+:long ADuC836_ADCGetConversionValue(unsigned char byADC_Chanel,unsigned char byIgnoreNewConversionFlag)*/
/*~F:7*/
long ADuC836_ADCGetConversionValue(unsigned char byADC_Chanel,unsigned char byIgnoreNewConversionFlag)
/*~-1*/
{
   /*~A:8*/
   /*~+:Beschreibung*/
   /*~T*/
   /*!
   \fn long ADuC836_ADCGetConversionValue(unsigned char byADC_Chanel)
   
   <b>Beschreibung:</b><br>
   Liefert das endg�ltige Ergebnis der Analog-Digital-Wandlung eines Kanals zur�ck.
   
   \param
   byADC_Chanel: Kanal, dessen Ergebnis abgefragt werden soll.
   
   \return
   Ergebnis der Analgog-Digital-Wandlung, bzw. eine Fehlermitteilung.
   
   \retval
   0x80000000: Der angegebene Kanal existiert nicht oder es gibt keinen neuen gewandelten Wert.
   \retval
   ansonsten: Ergebnis.
   
   <b>Zugriff:</b><br>
   [X] �ffentlich / [ ] Privat
   
   \ref
   ExamplePage_ADuC836Driver "Beispiel 'ADuC836-Treiber'"
   */

   /*~E:A8*/
   /*~A:9*/
   /*~+:Variablendeklarationen*/
   /*~T*/
   long lReturnValue;
   /*~E:A9*/
   /*~A:10*/
   /*~+:Variableninitialisierungen*/
   /*~T*/

   /*~E:A10*/
   /*~I:11*/
   if (byADC_Chanel < ADC_MAX_CHANELS)
   /*~-1*/
   {
      /*~I:12*/
      if ((g_ADC.Results[byADC_Chanel].byNewConversionValueFlag)||(byIgnoreNewConversionFlag))
      /*~-1*/
      {
         /*~T*/
         EADC = 0;          // ADC-Interrupt sperren
         /*~T*/
         lReturnValue = g_ADC.Results[byADC_Chanel].lResult;
         // Merker zur Signalisierung eines neuen gewandelten Wertes zur�cksetzen
         g_ADC.Results[byADC_Chanel].byNewConversionValueFlag = 0; 
         /*~T*/
         EADC = 1;          // ADC-Interrupt freigeben
      /*~-1*/
      }
      /*~O:I12*/
      /*~-2*/
      else
      {
         /*~T*/
         lReturnValue = 0x80000000;
      /*~-1*/
      }
      /*~E:I12*/
   /*~-1*/
   }
   /*~O:I11*/
   /*~-2*/
   else
   {
      /*~T*/
      lReturnValue = 0x80000000;
   /*~-1*/
   }
   /*~E:I11*/
   /*~T*/
   return lReturnValue; 
/*~-1*/
}
/*~E:F7*/
/*~E:A6*/
/*~-1*/
#endif
/*~E:I5*/
/*~I:13*/
#ifdef MOD_1ST
/*~A:14*/
/*~+:long ADuC836_ADCGetConversionValue(unsigned char byADC_Chanel,unsigned char byIgnoreNewConversionFlag)*/
/*~F:15*/
long ADuC836_ADCGetConversionValue(unsigned char byADC_Chanel,unsigned char byIgnoreNewConversionFlag)
/*~-1*/
{
   /*~A:16*/
   /*~+:Beschreibung*/
   /*~T*/
   /*!
   \fn long ADuC836_ADCGetConversionValue(unsigned char byADC_Chanel)
   
   <b>Beschreibung:</b><br>
   Liefert das endg�ltige Ergebnis der Analog-Digital-Wandlung eines Kanals zur�ck.
   
   \param
   byADC_Chanel: Kanal, dessen Ergebnis abgefragt werden soll.
   
   \return
   Ergebnis der Analgog-Digital-Wandlung, bzw. eine Fehlermitteilung.
   
   \retval
   0x80000000: Der angegebene Kanal existiert nicht oder es gibt keinen neuen gewandelten Wert.
   \retval
   ansonsten: Ergebnis.
   
   <b>Zugriff:</b><br>
   [X] �ffentlich / [ ] Privat
   
   \ref
   ExamplePage_ADuC836Driver "Beispiel 'ADuC836-Treiber'"
   */

   /*~E:A16*/
   /*~A:17*/
   /*~+:Variablendeklarationen*/
   /*~T*/
   long lReturnValue;
   unsigned char byCounter;
   /*~E:A17*/
   /*~A:18*/
   /*~+:Variableninitialisierungen*/
   /*~T*/
   byCounter = 0;
   /*~E:A18*/
   /*~I:19*/
   if (byADC_Chanel < ADC_MAX_CHANELS)
   /*~-1*/
   {
      /*~I:20*/
      if ((g_ADC.Results[byADC_Chanel].byNewConversionValueFlag)||(byIgnoreNewConversionFlag))
      /*~-1*/
      {
         /*~U:21*/
         /*~-2*/
         do
         {
            /*~T*/
            lReturnValue = g_ADC.Results[byADC_Chanel].lResult;
            // Merker zur Signalisierung eines neuen gewandelten Wertes zur�cksetzen
            g_ADC.Results[byADC_Chanel].byNewConversionValueFlag = 0; 
         /*~-1*/
         }
         /*~O:U21*/
         while ((lReturnValue != g_ADC.Results[byADC_Chanel].lResult) && (byCounter++ < 10));
         /*~E:U21*/
         /*~I:22*/
         if (byCounter >= 10)
         /*~-1*/
         {
            /*~T*/
            lReturnValue = 0x80000000;
         /*~-1*/
         }
         /*~E:I22*/
      /*~-1*/
      }
      /*~O:I20*/
      /*~-2*/
      else
      {
         /*~T*/
         lReturnValue = 0x80000000;
      /*~-1*/
      }
      /*~E:I20*/
   /*~-1*/
   }
   /*~O:I19*/
   /*~-2*/
   else
   {
      /*~T*/
      lReturnValue = 0x80000000;
   /*~-1*/
   }
   /*~E:I19*/
   /*~T*/
   return lReturnValue; 
/*~-1*/
}
/*~E:F15*/
/*~E:A14*/
/*~-1*/
#endif
/*~E:I13*/
/*~A:23*/
/*~+:long ADuC836_ADCGetConversionValue(unsigned char byADC_Chanel,unsigned char byIgnoreNewConversionFlag)*/
/*~F:24*/
long ADuC836_ADCGetConversionValue(unsigned char byADC_Chanel,unsigned char byIgnoreNewConversionFlag)
/*~-1*/
{
   /*~A:25*/
   /*~+:Beschreibung*/
   /*~T*/
   /*!
   \fn long ADuC836_ADCGetConversionValue(unsigned char byADC_Chanel)
   
   <b>Beschreibung:</b><br>
   Liefert das endg�ltige Ergebnis der Analog-Digital-Wandlung eines Kanals zur�ck.
   
   \param
   byADC_Chanel: Kanal, dessen Ergebnis abgefragt werden soll.
   
   \return
   Ergebnis der Analgog-Digital-Wandlung, bzw. eine Fehlermitteilung.
   
   \retval
   0x80000000: Der angegebene Kanal existiert nicht oder es gibt keinen neuen gewandelten Wert.
   \retval
   ansonsten: Ergebnis.
   
   <b>Zugriff:</b><br>
   [X] �ffentlich / [ ] Privat
   
   \ref
   ExamplePage_ADuC836Driver "Beispiel 'ADuC836-Treiber'"
   */

   /*~E:A25*/
   /*~A:26*/
   /*~+:Variablendeklarationen*/
   /*~T*/
   long lReturnValue;
   unsigned char byCounter;
   /*~E:A26*/
   /*~A:27*/
   /*~+:Variableninitialisierungen*/
   /*~T*/
   byCounter = 0;
   /*~E:A27*/
   /*~I:28*/
   if (byADC_Chanel < ADC_MAX_CHANELS)
   /*~-1*/
   {
      /*~I:29*/
      if ((g_ADC.Results[byADC_Chanel].byNewConversionValueFlag)||(byIgnoreNewConversionFlag))
      /*~-1*/
      {
         /*~T*/
         // Merker zur Signalisierung eines neuen gewandelten Wertes zur�cksetzen
         g_ADC.Results[byADC_Chanel].byNewConversionValueFlag = 0; 
         /*~T*/
         return g_ADC.Results[byADC_Chanel].lResult;

      /*~-1*/
      }
      /*~O:I29*/
      /*~-2*/
      else
      {
         /*~T*/
         return 0x80000000;
      /*~-1*/
      }
      /*~E:I29*/
   /*~-1*/
   }
   /*~O:I28*/
   /*~-2*/
   else
   {
      /*~T*/
      return 0x80000000;
   /*~-1*/
   }
   /*~E:I28*/
/*~-1*/
}
/*~E:F24*/
/*~E:A23*/
