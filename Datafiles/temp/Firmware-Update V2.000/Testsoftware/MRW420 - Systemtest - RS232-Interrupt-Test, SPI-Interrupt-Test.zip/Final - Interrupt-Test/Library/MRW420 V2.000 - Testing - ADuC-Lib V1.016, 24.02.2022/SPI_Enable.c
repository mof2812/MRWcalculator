/*~-1*/
/*~XSF_LANGUAGE: C/C++*/
/*~K*/
/*~+:File :        SPI_Enable.c*/
/*~+:*/
/*~+:Version :     V1.0*/
/*~+:*/
/*~+:Date :        14.06.2005*/
/*~+:*/
/*~+:Time :        10:23*/
/*~+:*/
/*~+:Author :      MOF*/
/*~+:*/
/*~+:Hardware :*/
/*~+:*/
/*~+:Description :*/
/*~A:1*/
/*~+:Includes*/
/*~T*/
#include "ADuC836Driver.h"
#include "SPI_Global.h"
/*~E:A1*/
/*~A:2*/
/*~+:Funktionseigene Definitionen*/
/*~T*/
#
/*~E:A2*/
/*~A:3*/
/*~+:Funktionseigene Struktur-Definitionen*/
/*~T*/

/*~E:A3*/
/*~A:4*/
/*~+:Funktionsprototypen*/
/*~T*/
void ADuC836_SPIEnable(bit bEnable);
/*~E:A4*/
/*~A:5*/
/*~+:Globale Variablen*/
/*~T*/

/*~E:A5*/
/*~A:6*/
/*~+:void ADuC836_SPIEnable(bit bEnable)*/
/*~F:7*/
void ADuC836_SPIEnable(bit bEnable)
/*~-1*/
{
   /*~A:8*/
   /*~+:Beschreibung*/
   /*~T*/
   /*!
   \fn void ADuC836_SPIEnable(bit bEnable)
   
   <b>Beschreibung:</b><br>
   Setzen der Freigabe der SPI-Schnittstelle
   
   \param
   bEnable:
   \param
   0 = Schnittstelle sperren.
   \param
   1 = Schnittstelle freigeben. 
   
   \return
   ./.
   
   <b>Zugriff:</b><br>
   [X] �ffentlich / [ ] Privat
   
   \ref
   ExamplePage_ADuC836Driver "Beispiel 'ADuC836-Treiber'"
   */
   /*~E:A8*/
   /*~I:9*/
   if (bEnable)
   /*~-1*/
   {
      /*~T*/
      SPE = 1;
      /*~I:10*/
      if (!SPIM)
      /*~-1*/
      {
         /*~T*/
         // SPI-Interrupt freigeben
         IEIP2 |= 0x01;
      /*~-1*/
      }
      /*~E:I10*/
   /*~-1*/
   }
   /*~O:I9*/
   /*~-2*/
   else
   {
      /*~T*/
      SPE = 0;
      /*~T*/
      // SPI-Interrupt sperren
      IEIP2 &= 0xFE;
   /*~-1*/
   }
   /*~E:I9*/
/*~-1*/
}
/*~E:F7*/
/*~E:A6*/
