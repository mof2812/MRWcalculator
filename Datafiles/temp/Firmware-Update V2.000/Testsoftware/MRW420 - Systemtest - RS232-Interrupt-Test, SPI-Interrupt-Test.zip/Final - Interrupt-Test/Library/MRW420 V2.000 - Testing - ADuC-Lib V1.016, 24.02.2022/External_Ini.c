/*~-1*/
/*~XSF_LANGUAGE: C/C++*/
/*~K*/
/*~+:File :        External_Ini.c*/
/*~+:*/
/*~+:Version :     V1.0*/
/*~+:*/
/*~+:Date :        03.06.2005*/
/*~+:*/
/*~+:Time :        10:23*/
/*~+:*/
/*~+:Author :      MOF*/
/*~+:*/
/*~+:Hardware :*/
/*~+:*/
/*~+:Description :*/
/*~+:*/
/*~+:*/
/*~A:1*/
/*~+:Includes*/
/*~T*/
#include "ADuC836.h"
#include "ADuC836Driver.h"
/*~E:A1*/
/*~A:2*/
/*~+:Funktionseigene Definitionen*/
/*~T*/

/*~E:A2*/
/*~A:3*/
/*~+:Funktionseigene Struktur-Definitionen*/
/*~T*/

/*~E:A3*/
/*~A:4*/
/*~+:Funktionsprototypen*/
/*~T*/
void ADuC836_ExternalIni(unsigned char chModeExt0,unsigned char bOnOffExt0,unsigned char chModeExt1,unsigned char bOnOffExt1);
/*~E:A4*/
/*~A:5*/
/*~+:Globale Variablen*/
/*~T*/

/*~E:A5*/
/*~A:6*/
/*~+:void ADuC836_ExternalIni(unsigned char chModeExt0,unsigned char bOnOffExt0,unsigned char chModeExt1,unsigned char bOnOffExt1)*/
/*~F:7*/
void ADuC836_ExternalIni(unsigned char chModeExt0,unsigned char bOnOffExt0,unsigned char chModeExt1,unsigned char bOnOffExt1)
/*~-1*/
{
   /*~A:8*/
   /*~+:Interruptverhalten*/
   /*~I:9*/
   if (chModeExt0 & EXTERNAL_EDGE_CONTROLLED)
   /*~-1*/
   {
      /*~T*/
      IT0 = 1;
   /*~-1*/
   }
   /*~O:I9*/
   /*~-2*/
   else
   {
      /*~T*/
      IT0 = 0;
   /*~-1*/
   }
   /*~E:I9*/
   /*~I:10*/
   if (chModeExt1 & EXTERNAL_EDGE_CONTROLLED)
   /*~-1*/
   {
      /*~T*/
      IT1 = 1;
   /*~-1*/
   }
   /*~O:I10*/
   /*~-2*/
   else
   {
      /*~T*/
      IT1 = 0;
   /*~-1*/
   }
   /*~E:I10*/
   /*~E:A8*/
   /*~A:11*/
   /*~+:Priorit�t*/
   /*~I:12*/
   if (chModeExt0 & EXTERNAL_HIGH_PRIORITY)
   /*~-1*/
   {
      /*~T*/
      PX0 = 1;
   /*~-1*/
   }
   /*~O:I12*/
   /*~-2*/
   else
   {
      /*~T*/
      PX0 = 0;
   /*~-1*/
   }
   /*~E:I12*/
   /*~I:13*/
   if (chModeExt1 & EXTERNAL_HIGH_PRIORITY)
   /*~-1*/
   {
      /*~T*/
      PX1 = 1;
   /*~-1*/
   }
   /*~O:I13*/
   /*~-2*/
   else
   {
      /*~T*/
      PX1 = 0;
   /*~-1*/
   }
   /*~E:I13*/
   /*~E:A11*/
   /*~A:14*/
   /*~+:Steuerleitung auf 0 setzen*/
   /*~T*/
   P35 = 0;
   /*~E:A14*/
   /*~A:15*/
   /*~+:Aktivierung*/
   /*~I:16*/
   if (bOnOffExt0)
   /*~-1*/
   {
      /*~T*/
      EX0 = 1;
   /*~-1*/
   }
   /*~O:I16*/
   /*~-2*/
   else
   {
      /*~T*/
      EX0 = 0;
   /*~-1*/
   }
   /*~E:I16*/
   /*~I:17*/
   if (bOnOffExt1)
   /*~-1*/
   {
      /*~T*/
      EX1 = 1;
   /*~-1*/
   }
   /*~O:I17*/
   /*~-2*/
   else
   {
      /*~T*/
      EX1 = 0;
   /*~-1*/
   }
   /*~E:I17*/
   /*~E:A15*/
/*~-1*/
}
/*~E:F7*/
/*~E:A6*/
