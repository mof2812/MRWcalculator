/*~-1*/
/*~XSF_LANGUAGE: C/C++*/
/*~K*/
/*~+:File :        RS232_Ini.c*/
/*~+:*/
/*~+:Version :     V1.0*/
/*~+:*/
/*~+:Date :        09.02.2022*/
/*~+:*/
/*~+:Time :        10:23*/
/*~+:*/
/*~+:Author :      MOF*/
/*~+:*/
/*~+:Hardware :*/
/*~+:*/
/*~+:Description :*/
/*~+:*/
/*~+:*/
/*~A:1*/
/*~+:Includes*/
/*~T*/
#include "ADuC836.h"
#include "ADuC836Driver.h"
/*~E:A1*/
/*~A:2*/
/*~+:Funktionseigene Definitionen*/
/*~T*/

/*~E:A2*/
/*~A:3*/
/*~+:Funktionseigene Struktur-Definitionen*/
/*~T*/

/*~E:A3*/
/*~A:4*/
/*~+:Funktionsprototypen*/
/*~T*/
char ADuC836_RS232Ini(unsigned char chDatabits,unsigned long ulBaudrate,unsigned char* pchRecBuffer,unsigned char chBufferSize,unsigned char* pchTransBuffer,char byHighPriority);
/*~E:A4*/
/*~A:5*/
/*~+:Globale Variablen*/
/*~T*/

/*~E:A5*/
/*~A:6*/
/*~+:char ADuC836_RS232Ini(unsigned char chDatabits,unsigned long ulBaudrate,unsigned char* pchRecBuffer,unsigned char chBufferSize,unsigned char* pchTransBuffer,char byHighPriority)*/
/*~F:7*/
char ADuC836_RS232Ini(unsigned char chDatabits,unsigned long ulBaudrate,unsigned char* pchRecBuffer,unsigned char chBufferSize,unsigned char* pchTransBuffer,char byHighPriority)
/*~-1*/
{
   /*~A:8*/
   /*~+:Beschreibung*/
   /*~T*/
   /*!
   \fn unsigned char RS232_Ini(unsigned char chDatabits,unsigned int uBaudrate)
   
   <b>Beschreibung:</b><br>
   Initialisierungsroutine zur RS232-Schnittstelle. Hierzu z�hlt das Setzen der Baudrate und der Datenbreite. Diese Routine gilt nur f�r Prozessoren mit einer internen Taktung von 12MHz!
   
   \param
   chDatabits: Einzustellende Datenbreite.
   
   \param
   uBaudrate: Einzustellende �bertragungsgeschwindigkeit.
   
   \return
   Status der Funktionsausf�hrung.
   
   \retval
   0: Alles okay
   
   \retval
   1: Datenbreite konnte nicht eingestellt werden - �bergebener Wert au�erhalb der Spezifikation.
   
   \retval
   2: Baudrate konnte nicht eingestellt werden - �bergebener Wert au�erhalb der Spezifikation.
   
   <b>Zugriff:</b><br>
   [X] �ffentlich / [ ] Privat
   
   \ref
   ExamplePage_RS232Kommunikation "RS232-Kommunikation"
   */

   /*~E:A8*/
   /*~I:9*/
   if (!ADuC836_RS232SetDataBits(chDatabits))
   /*~-1*/
   {
      /*~I:10*/
      if (!ADuC836_RS232SetBaudrate(ulBaudrate))
      /*~-1*/
      {
         /*~T*/
         ES = 1;
         EA = 1;
         /*~I:11*/
         if (byHighPriority)
         /*~-1*/
         {
            /*~T*/
            PS = 1;
         /*~-1*/
         }
         /*~O:I11*/
         /*~-2*/
         else
         {
            /*~T*/
            PS = 0;
         /*~-1*/
         }
         /*~E:I11*/
         /*~T*/
         RS232.chNewCommandReceived = 0;

         RS232.bEOT = 1;
         RS232.nTransPointer = 0;

         RS232.bTransmissionReleased = 0;
         RS232.ulTimeoutRS232Release = -1;
         /*~T*/
         RS232.pchRecBuffer = pchRecBuffer;

         RS232.pchTransBuffer = pchTransBuffer;

         RS232.chBufferSize = chBufferSize;
         /*~I:12*/
#ifdef RS232_WITH_STATISTICS
         /*~T*/
         // Statistikspeicher l�schen
         RS232.Statistics.ulSTXCount = 0;
         RS232.Statistics.ulETXCount = 0;
         /*~-1*/
#endif
         /*~E:I12*/
         /*~T*/
         // Alles okay
         return 0;
      /*~-1*/
      }
      /*~O:I10*/
      /*~-2*/
      else
      {
         /*~T*/
         // Baudrate konnte nicht eingestellt werden - �bergebener Wert au�erhalb der Spezifikation.
         return 2;
      /*~-1*/
      }
      /*~E:I10*/
   /*~-1*/
   }
   /*~O:I9*/
   /*~-2*/
   else
   {
      /*~T*/
      // Datenbreite konnte nicht eingestellt werden - �bergebener Wert au�erhalb der Spezifikation.
      return 1;
   /*~-1*/
   }
   /*~E:I9*/
/*~-1*/
}
/*~E:F7*/
/*~E:A6*/
