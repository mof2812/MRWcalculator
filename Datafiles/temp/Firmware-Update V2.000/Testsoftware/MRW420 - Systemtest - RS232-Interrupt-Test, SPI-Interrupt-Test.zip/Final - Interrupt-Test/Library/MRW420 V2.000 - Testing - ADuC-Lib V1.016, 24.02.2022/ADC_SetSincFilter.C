/*~-1*/
/*~XSF_LANGUAGE: C/C++*/
/*~T*/
/*

   (1) MODULNAME             :  ADC_SetSincFilter.c
   (2) VERSION               :  1.00
   (3) DATUM                 :  

   (4) LETZTE �NDERUNG       :  
   (5) PROJEKT (Vers.)       :  MRW Limit
   (6) PROGRAMMIERER         :  MOF

*/
/*~A:1*/
/*~+:Includes*/
/*~T*/
#include "ADC_Global.h"
/*~E:A1*/
/*~A:2*/
/*~+:Defines */
/*~T*/

/*~E:A2*/
/*~A:3*/
/*~+:Funktionsprototypen*/
/*~T*/
unsigned char ADuC836_ADCSetSincFilter(float fOutputUpdateRate,float fProcessorFrequency);
/*~E:A3*/
/*~A:4*/
/*~+:Modulvariablen*/
/*~T*/

/*~E:A4*/
/*~A:5*/
/*~+:unsigned char ADuC836_ADCSetSincFilter(float fOutputUpdateRate,float fProcessorFrequency)*/
/*~F:6*/
unsigned char ADuC836_ADCSetSincFilter(float fOutputUpdateRate,float fProcessorFrequency)
/*~-1*/
{
   /*~A:7*/
   /*~+:Beschreibung*/
   /*~T*/
   /*!
   \fn unsigned char ADuC836_ADCSetSincFilter(float fOutputUpdateRate,float fProcessorFrequency)
   
   <b>Beschreibung:</b><br>
   Setzen der ADC-Sampling-Rate.
   
   \param
   fOutputUpdateRate: zu setzende Samplingrate.
   
   \param
   fProcessorFrequency: ADC-Frequenz. Wird zur Berechnung des ins SF-Register einzutragenden Wertes ben�tigt.
   
   \return
   Status der Funktionsausf�hrung
   
   \retval
   0: Alles okay
   \retval
   1: Sampling-Rate konnte nicht gesetzt werden. Gew�nschter Wert zu gro� oder zu klein.
   
   <b>Zugriff:</b><br>
   [X] �ffentlich / [ ] Privat
   
   \ref
   ExamplePage_ADuC836Driver "Beispiel 'ADuC836-Treiber'"
   */
   /*~E:A7*/
   /*~A:8*/
   /*~+:Variablendeklarationen*/
   /*~T*/
   unsigned char byADCMODECopy;
   /*~E:A8*/
   /*~A:9*/
   /*~+:Variableninitialisierungen*/
   /*~T*/

   /*~E:A9*/
   /*~K*/
   /*~+:/~* bis Version V1.002 *~/*/
   /*~+:bySincValue = (unsigned char)(fProcessorFrequency/24/fOutputUpdateRate);*/
   /*~I:10*/
   if (g_ADC.Settings[ADuC836_ADC_PRIMARY].byToggleMode)
   /*~-1*/
   {
      /*~T*/
      /* Die Wandlungsrate muss mal vier genommen werden, da der ADC im Togglebetrieb l�uft. D.h. es wird nur mit bei jeder zweiten Wandlung der DMS-Messwert ermittelt - bei der anderen Messung der Rohmesswert der Stromr�ckf�hrung. Zudem wird bei jeder Umschaltung ein Reset der ADCs ausgef�hrt, was zur Folge hat, dass der Messwert erst nach zweiten Wandlung zur Verf�gung steht.
      /*~T*/
      fOutputUpdateRate *= 4;
   /*~-1*/
   }
   /*~E:I10*/
   /*~T*/
   /* �nderung ab Version V1.004 */
   g_ADC.bySincFilter = (unsigned char)((fProcessorFrequency/24/fOutputUpdateRate) + 0.5);
   /*~I:11*/
   if ((g_ADC.bySincFilter < 256)&&(g_ADC.bySincFilter > 12))
   /*~-1*/
   {
      /*~T*/
      byADCMODECopy = ADCMODE;
      ADCMODE &= 0xD9;
      /*~T*/
      SF = g_ADC.bySincFilter;
      /*~T*/
      ADCMODE = byADCMODECopy;
      /*~T*/
      return 0;
   /*~-1*/
   }
   /*~O:I11*/
   /*~-2*/
   else
   {
      /*~T*/
      return 1;
   /*~-1*/
   }
   /*~E:I11*/
/*~-1*/
}
/*~E:F6*/
/*~E:A5*/
