/*~-1*/
/*~XSF_LANGUAGE: C/C++*/
/*~K*/
/*~+:File :        SPI_IsNewCommand.c*/
/*~+:*/
/*~+:Version :     V1.0*/
/*~+:*/
/*~+:Date :        03.06.2005*/
/*~+:*/
/*~+:Time :        10:23*/
/*~+:*/
/*~+:Author :      MOF*/
/*~+:*/
/*~+:Hardware :*/
/*~+:*/
/*~+:Description :*/
/*~+:*/
/*~+:*/
/*~A:1*/
/*~+:Includes*/
/*~T*/
#include "ADuC836.h"
#include "ADuC836Driver.h"
#include "SPI_Global.h"
/*~E:A1*/
/*~A:2*/
/*~+:Funktionseigene Definitionen*/
/*~T*/

/*~E:A2*/
/*~A:3*/
/*~+:Funktionseigene Struktur-Definitionen*/
/*~T*/

/*~E:A3*/
/*~A:4*/
/*~+:Funktionsprototypen*/
/*~T*/
char ADuC836_SPIIsAcknowledge(char byWithTimeoutControl);
/*~E:A4*/
/*~A:5*/
/*~+:Globale Variablen*/
/*~T*/

/*~E:A5*/
/*~A:6*/
/*~+:char ADuC836_SPIIsAcknowledge(char byWithTimeoutControl)*/
/*~F:7*/
char ADuC836_SPIIsAcknowledge(char byWithTimeoutControl)
/*~-1*/
{
   /*~I:8*/
   if (SPI.chACKReceived)
   /*~-1*/
   {
      /*~T*/
      // Neuen Befehl empfangen
      SPI.chACKReceived = 0;

      /*~T*/
      return 1;
   /*~-1*/
   }
   /*~O:I8*/
   /*~-2*/
   else
   {
      /*~I:9*/
      if (SPI.chNAKReceived)
      /*~-1*/
      {
         /*~T*/
         // Neuen Befehl empfangen
         SPI.chNAKReceived = 0;

         /*~T*/
         return 2;
      /*~-1*/
      }
      /*~O:I9*/
      /*~-2*/
      else
      {
         /*~I:10*/
         if (byWithTimeoutControl)
         /*~-1*/
         {
            /*~I:11*/
            if (ADuC836_SPICheckTimeout())
            /*~-1*/
            {
               /*~T*/
               // Zeit ist abgelaufen

               /*~T*/
               return 3;
            /*~-1*/
            }
            /*~O:I11*/
            /*~-2*/
            else
            {
               /*~T*/
               // Zeit ist noch nicht abgelaufen
               return 0;
            /*~-1*/
            }
            /*~E:I11*/
         /*~-1*/
         }
         /*~O:I10*/
         /*~-2*/
         else
         {
            /*~T*/
            return 0;
         /*~-1*/
         }
         /*~E:I10*/
      /*~-1*/
      }
      /*~E:I9*/
   /*~-1*/
   }
   /*~E:I8*/
/*~-1*/
}
/*~E:F7*/
/*~E:A6*/
