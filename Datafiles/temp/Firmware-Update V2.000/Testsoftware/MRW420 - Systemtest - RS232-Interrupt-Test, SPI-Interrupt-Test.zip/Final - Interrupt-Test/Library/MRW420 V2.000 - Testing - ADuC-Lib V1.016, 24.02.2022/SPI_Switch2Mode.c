/*~-1*/
/*~XSF_LANGUAGE: C/C++*/
/*~K*/
/*~+:File :        SPI_Switch2Mode.c*/
/*~+:*/
/*~+:Version :     V1.0*/
/*~+:*/
/*~+:Date :        14.06.2005*/
/*~+:*/
/*~+:Time :        10:23*/
/*~+:*/
/*~+:Author :      MOF*/
/*~+:*/
/*~+:Hardware :*/
/*~+:*/
/*~+:Description :*/
/*~A:1*/
/*~+:Includes*/
/*~T*/
#include "ADuC836Driver.h"
#include "SPI_Global.h"
/*~E:A1*/
/*~A:2*/
/*~+:Funktionseigene Definitionen*/
/*~T*/
#
/*~E:A2*/
/*~A:3*/
/*~+:Funktionseigene Struktur-Definitionen*/
/*~T*/

/*~E:A3*/
/*~A:4*/
/*~+:Funktionsprototypen*/
/*~T*/
void ADuC836_SPISwitch2Mode(unsigned char chMode);
/*~E:A4*/
/*~A:5*/
/*~+:Globale Variablen*/
/*~T*/

/*~E:A5*/
/*~A:6*/
/*~+:void ADuC836_SPISwitch2Mode(unsigned char chMode)*/
/*~F:7*/
void ADuC836_SPISwitch2Mode(unsigned char chMode)
/*~-1*/
{
   /*~C:8*/
   switch (chMode)
   /*~-1*/
   {
      /*~A:9*/
      /*~+:ADUC836_SPI_MASTER_MODE*/
      /*~F:10*/
      case ADUC836_SPI_MASTER_MODE:
      /*~-1*/
      {
         /*~T*/
         SPE = 0;					///< SPI-Schnittstelle l�schen

         SPIM = 1;					///< SPI-Master-Mode setzen

         ISPI = 0;					///< Interrupt-Flag f�r empfangenes Zeichen l�schen

         IEIP2 &= 0xFE;				///< SPI-Interrupt sperren

         P35 = 1;					///< /SS-Signalleitung (SlaveSelect) auf 1 setzen

         SPE = 1;					///< SPI-Schnittstelle freigeben
         /*~T*/
         // F�r 1ms warten
         ADuC836_TimerWait(10);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F10*/
      /*~E:A9*/
      /*~A:11*/
      /*~+:ADUC836_SPI_SLAVE_MODE*/
      /*~F:12*/
      case ADUC836_SPI_SLAVE_MODE:
      /*~-1*/
      {
         /*~T*/
         SPE = 0;					///< SPI-Schnittstelle l�schen

         SPIM = 0;					///< SPI-Slave-Mode setzen

         ISPI = 0;					///< Interrupt-Flag f�r empfangenes Zeichen l�schen

         IEIP2 |= 0x01;				///< SPI-Interrupt freigeben

         /*~T*/
         P35 = 0;					///< /SS-Signalleitung (SlaveSelect) auf 0 setzen

         SPE = 1;					///< SPI-Schnittstelle freigeben
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F12*/
      /*~E:A11*/
   /*~-1*/
   }
   /*~E:C8*/
/*~-1*/
}
/*~E:F7*/
/*~E:A6*/
