/*~-1*/
/*~XSF_LANGUAGE: C/C++*/
/*~K*/
/*~+:File :        Timer_CalcNewDestinationTime.c*/
/*~+:*/
/*~+:Version :     V1.000*/
/*~+:*/
/*~+:Date :        03.06.2005*/
/*~+:*/
/*~+:Time :        */
/*~+:*/
/*~+:Author :      MOF*/
/*~+:*/
/*~+:Hardware :*/
/*~+:*/
/*~+:Description :*/
/*~A:1*/
/*~+:Includes*/
/*~T*/
#include "ADuC836Driver.h"

/*~E:A1*/
/*~A:2*/
/*~+:Funktionseigene Definitionen*/
/*~T*/

/*~E:A2*/
/*~A:3*/
/*~+:Funktionseigene Struktur-Definitionen*/
/*~T*/

/*~E:A3*/
/*~A:4*/
/*~+:Funktionsprototypen*/
/*~T*/
void ADuC836_TimerCalcNewDestinationTime(unsigned char chWhichTimer,unsigned char chMode);
/*~E:A4*/
/*~A:5*/
/*~+:Globale Variablen*/
/*~T*/
extern TIMER Timer;
/*~E:A5*/
/*~A:6*/
/*~+:void ADuC836_TimerCalcNewDestinationTime(unsigned char chWhichTimer,unsigned char chMode)*/
/*~F:7*/
void ADuC836_TimerCalcNewDestinationTime(unsigned char chWhichTimer,unsigned char chMode)
/*~-1*/
{
   /*~A:8*/
   /*~+:Beschreibung*/
   /*~T*/
   /*!
   \fn void ADuC836_TimerCalcNewDestinationTime(unsigned char chWhichTimer,unsigned char chMode)
   
   <b>Beschreibung:</b><br>
   Berechnung der neuen Zielzeit eines Timers.
   
   \param
   chWhichTimer: Kennziffer des Timers, dessen Zielzeit neu berechnet werden soll.
   
   \param
   chMode: Beschreibt den Modus der Berechnung
   \param 
   0: Zielzeit errechnet sich aus der Summe der Betriebszeit und der Zeitbasis.
   \param 
   1: Zielzeit errechnet sich aus der Summe der aktuellen Zielzeit und der Zeitbasis.
   
   \return
   ./.
   
   <b>Zugriff:</b><br>
   [X] �ffentlich / [ ] Privat
   
   \ref
   ExamplePage_ADuC836Driver "Beispiel 'ADuC836-Treiber'"
   */
   /*~E:A8*/
   /*~C:9*/
   switch (chMode)
   /*~-1*/
   {
      /*~F:10*/
      case 0:
      /*~-1*/
      {
         /*~T*/
         // Neue Zielzeit von der Betriebszeit abgeleitet
         Timer.ulDestinationTime[chWhichTimer] = Timer.ulOperatingTime + Timer.uTimebase[chWhichTimer];
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F10*/
      /*~F:11*/
      case 1:
      /*~-1*/
      {
         /*~U:12*/
         /*~-2*/
         do
         {
            /*~T*/
            // Neue Zielzeit von der alten abgeleitet
            Timer.ulDestinationTime[chWhichTimer] += Timer.uTimebase[chWhichTimer];
         /*~-1*/
         }
         /*~O:U12*/
         // ggf. mehrmals durchf�hren, damit die neue Zielzeit nicht in der Vergangenheit liegt
         while (Timer.ulDestinationTime[chWhichTimer] <= Timer.ulOperatingTime);
         /*~E:U12*/
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F11*/
   /*~-1*/
   }
   /*~E:C9*/
/*~-1*/
}
/*~E:F7*/
/*~E:A6*/
