/*~-1*/
/*~XSF_LANGUAGE: C/C++*/
/*~T*/
/*

   (1) MODULNAME             :  ADC_Ini.c
   (2) VERSION               :  1.00
   (3) DATUM                 :  

   (4) LETZTE �NDERUNG       :  21.11.2006
   (5) PROJEKT (Vers.)       :  MRW Limit
   (6) PROGRAMMIERER         :  MOF

*/
/*~A:1*/
/*~+:Includes*/
/*~T*/
#include "ADC_Global.h"
#include <String.h>
/*~E:A1*/
/*~A:2*/
/*~+:Defines */
/*~T*/

/*~E:A2*/
/*~A:3*/
/*~+:Funktionsprototypen*/
/*~T*/
unsigned char ADuC836_ADCIni(unsigned char byADC_Chanel, unsigned char byADC_Mode, unsigned char byADC_Configuration,float fOutputUpdateRate,float fProcessorFrequency,char chHighPriority);
/*~E:A3*/
/*~A:4*/
/*~+:Modulvariablen*/
/*~T*/

/*~E:A4*/
/*~A:5*/
/*~+:unsigned char ADuC836_ADCIni(unsigned char byADC_Chanel, unsigned char byADC_Mode, unsigned char byADC_Configuration,float fOutputUpdateRate,float fProcessorFrequency,char chHighPriority)*/
/*~F:6*/
unsigned char ADuC836_ADCIni(unsigned char byADC_Chanel, unsigned char byADC_Mode, unsigned char byADC_Configuration,float fOutputUpdateRate,float fProcessorFrequency,char chHighPriority)
/*~-1*/
{
   /*~A:7*/
   /*~+:Beschreibung*/
   /*~T*/
   /*!
   \fn unsigned char ADuC836_ADCIni(unsigned char byADC_Chanel, unsigned char byADC_Mode, unsigned char byADC_Configuration,float fOutputUpdateRate,float fProcessorFrequency)
   
   <b>Beschreibung:</b><br>
   Initialisierung der beiden ADCs. Dabei wird der Parameter- und der Ergebnisspeicher mit Nullwerten gef�llt. 
   
   \param
   byADC_Chanel: Angabe des Kanals, welcher initialisiert werden soll (0 = Haupt-ADC, 1 = Hilfs-ADC, 2 = Haupt-ADC Nr.2 bei Toggle-Betrieb, 3 = Hilfs-ADC Nr.2 bei Toggle-Betrieb)
   
   \param
   byADC_Mode: Betriebsmodus des ADC's. Das ADCMODE-Register wird dabei vom Haupt-ADC absolut gesetzt, w�hrend bei der Angabe des Betriebsmodus f�r den Hilfs-ADC nur Bits gesetzt werden k�nnen (ODER-Verkn�pfung). F�r weitere Angabe siehe im Datenblatt zum ADuC836!
   
   \param
   byADC_Configuration: Angabe zur Konfiguration des ADC's. F�r weitere Angabe siehe im Datenblatt zum ADuC836! 
   
   \param
   fOutputUpdateRate: Parametrierung des SincFilters beider ADC's. Dieser Parameter gibt die Anzahl der Wandlungen pro Sekunde wieder. ACHTUNG! nur die Parametrierung des Hauptkanals kann den Sinc-Filter setzen! F�r weitere Angabe siehe im Datenblatt zum ADuC836!
   
   \param
   fProcessorFrequency: Zur Berechnung des Sinc-Filters wird die Taktfrequenz des ADC's ben�tigt.
   
   \return
   Status der Funktionsausf�hrung.
   
   \retval
   0: Alles okay
   
   \retval
   1: Angegebener Kanal existiert nicht.
   
   \retval
   2: Sinc-Filter konnte f�r die gew�nschte Sampling-Rate nicht gesetzt werden. 
   
   <b>Zugriff:</b><br>
   [X] �ffentlich / [ ] Privat
   
   \ref
   ExamplePage_ADuC836Driver "Beispiel 'ADuC836-Treiber'"
   */

   /*~E:A7*/
   /*~A:8*/
   /*~+:Variablenintialisierungen*/
   /*~T*/
   g_byDisableRDY0NextTime = 0;
   g_ADC.bDisableInterrupt = 0;
   /*~E:A8*/
   /*~I:9*/
   if (byADC_Chanel < ADC_MAX_CHANELS)
   /*~-1*/
   {
      /*~C:10*/
      switch (byADC_Chanel)
      /*~-1*/
      {
         /*~F:11*/
         case ADuC836_ADC_PRIMARY:
         /*~-1*/
         {
            /*~T*/
            memset(&g_ADC.Settings[ADuC836_ADC_PRIMARY],0,sizeof(ADC_SETTINGS));
            memset(&g_ADC.Results[ADuC836_ADC_PRIMARY],0,sizeof(ADC_RESULTS));
            g_ADC.byActualConversionChanel[ADuC836_ADC_PRIMARY] = 0;
            /*~T*/
            ADCMODE = byADC_Mode;
            ADC0CON = g_ADC.Settings[ADuC836_ADC_PRIMARY].byADCCON = byADC_Configuration;
            /*~T*/
            // Messwerttiefe einstellen
            ADuC836_ADCSetMeasurementDepth(ADuC836_ADC_PRIMARY,1);
            /*~I:12*/
            if (ADCMODE & 0x20)
            /*~-1*/
            {
               /*~T*/
               EADC = 1;          // ADC-Interrupt freigeben
               EA = 1;            // EnableAll ebenfalls
            /*~-1*/
            }
            /*~E:I12*/
            /*~T*/
            break;
         /*~-1*/
         }
         /*~E:F11*/
         /*~F:13*/
         case ADuC836_ADC_PRIMARY_TOGGLE:
         /*~-1*/
         {
            /*~T*/
            memset(&g_ADC.Settings[ADuC836_ADC_PRIMARY_TOGGLE],0,sizeof(ADC_SETTINGS));
            memset(&g_ADC.Results[ADuC836_ADC_PRIMARY_TOGGLE],0,sizeof(ADC_RESULTS));
            /*~T*/
            g_ADC.Settings[ADuC836_ADC_PRIMARY].byToggleMode = 1;
            /*~T*/
            g_ADC.Settings[ADuC836_ADC_PRIMARY_TOGGLE].byADCCON = byADC_Configuration;
            /*~T*/
            // Messwerttiefe einstellen
            ADuC836_ADCSetMeasurementDepth(ADuC836_ADC_PRIMARY_TOGGLE,1);
            /*~I:14*/
            if (ADCMODE & 0x20)
            /*~-1*/
            {
               /*~T*/
               EADC = 1;          // ADC-Interrupt freigeben
               EA = 1;            // EnableAll ebenfalls
            /*~-1*/
            }
            /*~E:I14*/
            /*~T*/
            break;
         /*~-1*/
         }
         /*~E:F13*/
         /*~F:15*/
         case ADuC836_ADC_AUXILIARY:
         /*~-1*/
         {
            /*~T*/
            memset(&g_ADC.Settings[ADuC836_ADC_AUXILIARY],0,sizeof(ADC_SETTINGS));
            memset(&g_ADC.Results[ADuC836_ADC_AUXILIARY],0,sizeof(ADC_RESULTS));
            g_ADC.byActualConversionChanel[ADuC836_ADC_AUXILIARY] = 0;
            /*~T*/
            ADCMODE |= byADC_Mode;
            ADC1CON = g_ADC.Settings[ADuC836_ADC_AUXILIARY].byADCCON = byADC_Configuration;
            /*~T*/
            // Messwerttiefe einstellen
            ADuC836_ADCSetMeasurementDepth(ADuC836_ADC_AUXILIARY,1);
            /*~I:16*/
            if (ADCMODE & 0x10)
            /*~-1*/
            {
               /*~T*/
               EADC = 1;          // ADC-Interrupt freigeben
               EA = 1;            // EnableAll ebenfalls
            /*~-1*/
            }
            /*~E:I16*/
            /*~T*/
            break;
         /*~-1*/
         }
         /*~E:F15*/
         /*~F:17*/
         case ADuC836_ADC_AUXILIARY_TOGGLE:
         /*~-1*/
         {
            /*~T*/
            memset(&g_ADC.Settings[ADuC836_ADC_AUXILIARY_TOGGLE],0,sizeof(ADC_SETTINGS));
            memset(&g_ADC.Results[ADuC836_ADC_AUXILIARY_TOGGLE],0,sizeof(ADC_RESULTS));
            /*~T*/
            g_ADC.Settings[ADuC836_ADC_AUXILIARY].byToggleMode = 1;
            /*~T*/
            g_ADC.Settings[ADuC836_ADC_AUXILIARY_TOGGLE].byADCCON = byADC_Configuration;
            /*~T*/
            // Messwerttiefe einstellen
            ADuC836_ADCSetMeasurementDepth(ADuC836_ADC_AUXILIARY_TOGGLE,1);
            /*~I:18*/
            if (ADCMODE & 0x10)
            /*~-1*/
            {
               /*~T*/
               EADC = 1;          // ADC-Interrupt freigeben
               EA = 1;            // EnableAll ebenfalls
            /*~-1*/
            }
            /*~E:I18*/
            /*~T*/
            break;
         /*~-1*/
         }
         /*~E:F17*/
         /*~O:C10*/
         /*~-2*/
         default:
         {
            /*~T*/
            return 1;
         /*~-1*/
         }
      /*~-1*/
      }
      /*~E:C10*/
      /*~I:19*/
      if (!ADuC836_ADCSetSincFilter(fOutputUpdateRate,fProcessorFrequency))
      /*~-1*/
      {
         /*~I:20*/
         if (chHighPriority)
         /*~-1*/
         {
            /*~T*/
            PADC = 1;
         /*~-1*/
         }
         /*~O:I20*/
         /*~-2*/
         else
         {
            /*~T*/
            PADC = 0;
         /*~-1*/
         }
         /*~E:I20*/
         /*~T*/
         return 0;
      /*~-1*/
      }
      /*~O:I19*/
      /*~-2*/
      else
      {
         /*~T*/
         return 2; 
      /*~-1*/
      }
      /*~E:I19*/
   /*~-1*/
   }
   /*~O:I9*/
   /*~-2*/
   else
   {
      /*~T*/
      return 1;
   /*~-1*/
   }
   /*~E:I9*/
/*~-1*/
}
/*~E:F6*/
/*~E:A5*/
