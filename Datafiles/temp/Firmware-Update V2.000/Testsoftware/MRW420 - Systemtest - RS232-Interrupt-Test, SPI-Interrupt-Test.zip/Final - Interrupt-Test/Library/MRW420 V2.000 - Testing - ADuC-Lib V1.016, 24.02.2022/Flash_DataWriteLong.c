/*~-1*/
/*~XSF_LANGUAGE: C/C++*/
/*~T*/
/*

   (1) MODULNAME             :  Flash_DataWriteLong.c
   (2) VERSION               :  1.00
   (3) DATUM                 :  17.06.2003

   (4) LETZTE �NDERUNG       :  17.05.2005
   (5) PROJEKT (Vers.)       :  
   (6) PROGRAMMIERER         :  n.l./MOF

*/


/*~A:1*/
/*~+:Includes*/
/*~T*/
#include "ADuC836Driver.h"
/*~E:A1*/
/*~A:2*/
/*~+:Moduleigene Definitionen */
/*~T*/

/*~E:A2*/
/*~A:3*/
/*~+:Funktionsprototypen*/
/*~T*/
char ADuC836_FlashDataWriteLong(long* plData, int nPageNr, unsigned int nAnzahl);
/*~E:A3*/
/*~A:4*/
/*~+:Modulvariablen*/
/*~T*/

/*~E:A4*/
/*~A:5*/
/*~+:char ADuC836_FlashDataWriteLong(long* plData, int nPageNr, unsigned int nAnzahl)*/
/*~F:6*/
char ADuC836_FlashDataWriteLong(long* plData, int nPageNr, unsigned int nAnzahl)
/*~-1*/
{
   /*~A:7*/
   /*~+:Beschreibung*/
   /*~T*/
   /*
   Beschreibe eine Long-Variable in der angegebenen Page (0...1023).
   
   R�ckgabe:
   - 0 Funktion konnte erfolgreich durchgef�hrt werden
   -1 Pagenummer ung�ltig
   -2 Allgemeiner Schreibfehler 
   
   
   */
   /*~E:A7*/
   /*~A:8*/
   /*~+:Variablendeklarationen*/
   /*~T*/
   signed char cErgebnis;
   unsigned char i;
   unsigned char* pC;
   /*~E:A8*/
   /*~A:9*/
   /*~+:Variableninitialisierungen*/
   /*~T*/
   cErgebnis = 0;
   /*~E:A9*/
   /*~I:10*/
   if (nAnzahl > 0)
   /*~-1*/
   {
      /*~T*/
      pC = (unsigned char*)plData;
      /*~L:11*/
      for (i=0;i<nAnzahl && cErgebnis==0;i++)
      /*~-1*/
      {
         /*~T*/
         cErgebnis = ADuC836_FlashDataWritePtr(pC,nPageNr,4);

         nPageNr += 4;
         pC += 4;
         nAnzahl--;
      /*~-1*/
      }
      /*~E:L11*/
   /*~-1*/
   }
   /*~E:I10*/
   /*~T*/
   return (cErgebnis);
/*~-1*/
}
/*~E:F6*/
/*~E:A5*/
