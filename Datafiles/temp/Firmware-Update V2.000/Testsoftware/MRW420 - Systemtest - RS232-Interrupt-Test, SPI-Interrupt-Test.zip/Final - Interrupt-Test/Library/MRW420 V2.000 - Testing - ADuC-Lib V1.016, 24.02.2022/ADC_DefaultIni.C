/*~-1*/
/*~XSF_LANGUAGE: C/C++*/
/*~T*/
/*

   (1) MODULNAME             :  ADC_DefaultIni.c
   (2) VERSION               :  1.00
   (3) DATUM                 :  

   (4) LETZTE �NDERUNG       :  
   (5) PROJEKT (Vers.)       :  MRW Limit
   (6) PROGRAMMIERER         :  MOF

*/
/*~A:1*/
/*~+:Includes*/
/*~T*/
#include "ADC_Global.h"
/*~E:A1*/
/*~A:2*/
/*~+:Defines */
/*~T*/

/*~E:A2*/
/*~A:3*/
/*~+:Funktionsprototypen*/
/*~T*/
void ADuC836_ADCDefaultIni(void);
/*~E:A3*/
/*~A:4*/
/*~+:Modulvariablen*/
/*~T*/

/*~E:A4*/
/*~A:5*/
/*~+:void ADuC836_ADCDefaultIni(void)*/
/*~F:6*/
void ADuC836_ADCDefaultIni(void)
/*~-1*/
{
   /*~A:7*/
   /*~+:Beschreibung*/
   /*~T*/
   /*!
   \fn void ADuC836_ADCDefaultIni(void)
   
   <b>Beschreibung:</b><br>
   Initialisiert die beiden ADCs mit Defaultwerten, welche als Definition unter 
   ADuC836_ADC_DEFAULT_PRIMARY_SETTING (f�r den Haupt-ADC) und unter ADuC836_ADC_DEFAULT_AUXILIARY_SETTING (f�r den Hilfs-ADC) abgelegt sind.
   Zudem wird die Messwerttiefe f�r den Haupt-ADC auf 2 und f�r den Hilfs-ADC auf 1 gesetzt.
    
   \param
   void:
   
   \retval
   ./.
   
   <b>Zugriff:</b><br>
   [X] �ffentlich / [ ] Privat
   
   \ref
   ExamplePage_ADuC836Driver "Beispiel 'ADuC836-Treiber'"
   */
   /*~E:A7*/
   /*~T*/
   // Hauptkanal mit folgenden Einstellungen initialisieren:
   // Messbereich +/-20mV
   // Bipolare Betriebsart
   // Eingangspins A1 und A2
   // Externe Referenzquelle
   // 5.35Hz Abtastrate

   // Hilfskanal mit folgenden Einstellungen initialisieren:
   // Messbereich +/-20mV
   // Bipolare Betriebsart
   // Temperatursensor als Messeingang

   ADuC836_ADCIni(ADuC836_ADC_DEFAULT_PRIMARY_SETTING,0);
   ADuC836_ADCIni(ADuC836_ADC_DEFAULT_AUXILIARY_SETTING,0);
   // Toggle-Betrieb
   ADuC836_ADCIni(ADuC836_ADC_DEFAULT_PRIMARY_TOGGLE_SETTING,0);
   ADuC836_ADCIni(ADuC836_ADC_DEFAULT_AUXILIARY_TOGGLE_SETTING,0);
   /*~T*/
   // Messwerttiefe einstellen
   ADuC836_ADCSetMeasurementDepth(ADuC836_ADC_PRIMARY,2);		// 2 Messwerte
   ADuC836_ADCSetMeasurementDepth(ADuC836_ADC_AUXILIARY,1);	// 1 Messwert	
   // Toggle-Betrieb
   ADuC836_ADCSetMeasurementDepth(ADuC836_ADC_PRIMARY_TOGGLE,2);	// 2 Messwerte
   ADuC836_ADCSetMeasurementDepth(ADuC836_ADC_AUXILIARY_TOGGLE,1);	// 1 Messwert	


/*~-1*/
}
/*~E:F6*/
/*~E:A5*/
