/*~-1*/
/*~XSF_LANGUAGE: C/C++*/
/*~K*/
/*~+:File :        SPI_DefaultIni.c*/
/*~+:*/
/*~+:Version :     V1.001*/
/*~+:*/
/*~+:Date :        09.02.2022*/
/*~+:*/
/*~+:Time :        10:23*/
/*~+:*/
/*~+:Author :      MOF*/
/*~+:*/
/*~+:Hardware :*/
/*~+:*/
/*~+:Description :*/
/*~A:1*/
/*~+:Includes*/
/*~T*/
#include "ADuC836Driver.h"
#include "SPI_Global.h"
/*~E:A1*/
/*~A:2*/
/*~+:Funktionseigene Definitionen*/
/*~T*/
#
/*~E:A2*/
/*~A:3*/
/*~+:Funktionseigene Struktur-Definitionen*/
/*~T*/

/*~E:A3*/
/*~A:4*/
/*~+:Funktionsprototypen*/
/*~T*/
void ADuC836_SPIDefaultIni(unsigned char chMasterMode,unsigned char *pRecBuffer,unsigned char byRecBufferSize);
/*~E:A4*/
/*~A:5*/
/*~+:Globale Variablen*/
/*~T*/

/*~E:A5*/
/*~A:6*/
/*~+:void ADuC836_SPIDefaultIni(unsigned char chMasterMode,unsigned char *pRecBuffer,unsigned char byRecBufferSize)*/
/*~F:7*/
void ADuC836_SPIDefaultIni(unsigned char chMasterMode,unsigned char *pRecBuffer, unsigned char byRecBufferSize)
/*~-1*/
{
   /*~A:8*/
   /*~+:Beschreibung*/
   /*~T*/
   /*!
   \fn void ADuC836_SPIDefaultIni(unsigned char chMasterMode)
   
   <b>Beschreibung:</b><br>
   Initialisierung der SPI-Routinen mit Defaultwerten.
   Diese w�ren:
   - Birate = fCore/16 
   - F�hrender ClockImpuls
   - Clock-Leerlauf bei LOW-Pegel
   - Schnittstellenfreigabe
   - hohe Priorit�t
    
   \param
   chMasterMode: 
   \param
   0 = Initialisierung als Slave
   \param
   1 = Initialisierung als Master
   
   \return
   ./.
   
   <b>Zugriff:</b><br>
   [X] �ffentlich / [ ] Privat
   
   \ref
   ExamplePage_ADuC836Driver "Beispiel 'ADuC836-Treiber'"
   */

   /*~E:A8*/
   /*~I:9*/
   if (chMasterMode)
   /*~-1*/
   {
      /*~T*/
      ADuC836_SPIIni(ADUC836_SPI_BITRATE_FCORE_16 | ADUC836_SPI_CLOCKPHASE_LEADING | ADUC836_SPI_CLOCKPOLARITY_HIGH | ADUC836_SPI_MASTER_MODE,ADUC836_SPI_ENABLE,ADUC836_SPI_HIGH_INTERRUPT_PRIORITY,pRecBuffer,byRecBufferSize);
      /*~T*/
      // ADuC836_SPIIni(ADUC836_SPI_BITRATE_FCORE_8 | ADUC836_SPI_CLOCKPHASE_LEADING | ADUC836_SPI_CLOCKPOLARITY_LOW | ADUC836_SPI_MASTER_MODE,ADUC836_SPI_ENABLE,ADUC836_SPI_LOW_INTERRUPT_PRIORITY,pRecBuffer);
   /*~-1*/
   }
   /*~O:I9*/
   /*~-2*/
   else
   {
      /*~T*/
      ADuC836_SPIIni(ADUC836_SPI_BITRATE_FCORE_16 | ADUC836_SPI_CLOCKPHASE_LEADING | ADUC836_SPI_CLOCKPOLARITY_HIGH | ADUC836_SPI_SLAVE_MODE,ADUC836_SPI_ENABLE,ADUC836_SPI_HIGH_INTERRUPT_PRIORITY,pRecBuffer,byRecBufferSize);
      /*~T*/
      // ADuC836_SPIIni(ADUC836_SPI_BITRATE_FCORE_8 | ADUC836_SPI_CLOCKPHASE_LEADING | ADUC836_SPI_CLOCKPOLARITY_LOW | ADUC836_SPI_SLAVE_MODE,ADUC836_SPI_ENABLE,ADUC836_SPI_LOW_INTERRUPT_PRIORITY,pRecBuffer);
   /*~-1*/
   }
   /*~E:I9*/
/*~-1*/
}
/*~E:F7*/
/*~E:A6*/
