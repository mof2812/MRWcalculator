/*~-1*/
/*~XSF_LANGUAGE: C/C++*/
/*~K*/
/*~+:File :        Timer_Delay.c*/
/*~+:*/
/*~+:Version :     V1.000*/
/*~+:*/
/*~+:Date :        03.06.2005*/
/*~+:*/
/*~+:Time :        */
/*~+:*/
/*~+:Author :      MOF*/
/*~+:*/
/*~+:Hardware :*/
/*~+:*/
/*~+:Description :*/
/*~A:1*/
/*~+:Includes*/
/*~T*/
#include "ADuC836Driver.h"

/*~E:A1*/
/*~A:2*/
/*~+:Funktionseigene Definitionen*/
/*~T*/

/*~E:A2*/
/*~A:3*/
/*~+:Funktionseigene Struktur-Definitionen*/
/*~T*/

/*~E:A3*/
/*~A:4*/
/*~+:Funktionsprototypen*/
/*~T*/
void ADuC836_TimerDelay(unsigned int uTimeMS);
/*~E:A4*/
/*~A:5*/
/*~+:Globale Variablen*/
/*~T*/
extern TIMER Timer;
/*~E:A5*/
/*~A:6*/
/*~+:void ADuC836_TimerDelay(unsigned int uTimeMS)*/
/*~F:7*/
void ADuC836_TimerDelay(unsigned int uTimeMS)
/*~-1*/
{
   /*~A:8*/
   /*~+:Beschreibung*/
   /*~T*/
   /*!
   \fn void ADuC836_TimerDelay(unsigned int uTimeMS)
   
   <b>Beschreibung:</b><br>
   Programmlauf verweilt an dieser Stelle f�r eine vorgegeben Zeit.
   
   \param
   uTimeMS: Verweilzeit in Millisekunden. Da die kleinste Zeiteinheit jedoch 10ms sind, ist hier nur eine Aufl�sung im 10ms-Raster m�glich.
   
   \return
   ./.
   
   <b>Zugriff:</b><br>
   [X] �ffentlich / [ ] Privat
   
   \ref
   ExamplePage_ADuC836Driver "Beispiel 'ADuC836-Treiber'"
   */
   /*~E:A8*/
   /*~A:9*/
   /*~+:Variablendeklarationen*/
   /*~T*/
   // Variablendeklarationen
   unsigned long ulDestinationTime;
   /*~E:A9*/
   /*~T*/
   // Zielzeit setzen
   ulDestinationTime = Timer.ulOperatingTime + uTimeMS; 
   /*~L:10*/
   while (Timer.ulOperatingTime < ulDestinationTime)
   /*~-1*/
   {
      /*~T*/

   /*~-1*/
   }
   /*~E:L10*/
/*~-1*/
}
/*~E:F7*/
/*~E:A6*/
