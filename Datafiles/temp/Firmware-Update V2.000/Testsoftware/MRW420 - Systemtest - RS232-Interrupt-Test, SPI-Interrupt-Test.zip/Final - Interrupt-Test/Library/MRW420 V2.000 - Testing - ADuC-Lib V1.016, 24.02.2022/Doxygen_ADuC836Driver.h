/*~-1*/
/*~XSF_LANGUAGE: C/C++*/
/*~A:1*/
/*~+:Version und Versionsdatum*/
/*~T*/
/*!
\~german
\page SUBPAGE_SOFTWARE_VERSION_ADUC836_DRIVER 'ADuC836-Treiber'
\~english
\page SUBPAGE_SOFTWARE_VERSION_ADUC836_DRIVER 'ADuC836-drivers'
\~

<table width=100% height=1% rules=rows bgcolor="#E0E0F0">
\~german
<tr align=center valign=top><th>Modul</th><th>\version</th><th>\date</th><th>\author</th><th>Lifecycle</th></tr>
\~english
<tr align=center valign=top><th>Module</th><th>\author</th><th>\version</th><th>\date</th><th>lifecycle</th></tr>
\~
<tr><td>ADuC836</td><td>V1.001</td><td>28.06.2005</td><td>Michael Offenbach</td><td>\ref SUBPAGE_SOFTWARE_LIFECYCLE_ADUC836_DRIVER</td></tr>
<tr><td>ADuC836_ADC</td><td>V1.004</td><td>02.11.2011</td><td>Michael Offenbach</td><td>\ref SUBPAGE_SOFTWARE_LIFECYCLE_ADUC836_DRIVER_ADC</td></tr>
<tr><td>ADuC836_DAC</td><td>V1.004</td><td>14.12.2007</td><td>Michael Offenbach</td><td>\ref SUBPAGE_SOFTWARE_LIFECYCLE_ADUC836_DRIVER_DAC</td></tr>
<tr><td>ADuC836_External</td><td>V1.000</td><td>21.11.2006</td><td>Michael Offenbach</td><td>\ref SUBPAGE_SOFTWARE_LIFECYCLE_ADUC836_DRIVER_EXTERNAL</td></tr>
<tr><td>ADuC836_Flash</td><td>V1.001</td><td>24.04.2008</td><td>Michael Offenbach</td><td>\ref SUBPAGE_SOFTWARE_LIFECYCLE_ADUC836_DRIVER_FLASH</td></tr>
<tr><td>ADuC836_RS232</td><td>V1.005</td><td>18.02.2008</td><td>Michael Offenbach</td><td>\ref SUBPAGE_SOFTWARE_LIFECYCLE_ADUC836_DRIVER_RS232</td></tr>
<tr><td>ADuC836_SPI</td><td>V1.003</td><td>12.02.2008</td><td>Michael Offenbach</td><td>\ref SUBPAGE_SOFTWARE_LIFECYCLE_ADUC836_DRIVER_SPI</td></tr>
<tr><td>ADuC836_Timer</td><td>V1.000</td><td>21.11.2006</td><td>Michael Offenbach</td><td>\ref SUBPAGE_SOFTWARE_LIFECYCLE_ADUC836_DRIVER_TIMER</td></tr>
<tr><td>ADuC836_Watchdog</td><td>V1.000</td><td>21.11.2006</td><td>Michael Offenbach</td><td>\ref SUBPAGE_SOFTWARE_LIFECYCLE_ADUC836_DRIVER_WATCHDOG</td></tr>
</table>
*/
/*~E:A1*/
/*~A:2*/
/*~+:Ziel-Hardware*/
/*~T*/
/*!
\~german
\page SUBPAGE_HARDWARE_ADUC836_DRIVER 'ADuC836-Treiber'

<table border=1 width=100% height=1% rules=rows cellspacing=0 bgcolor="#E0E0F0">

<tr align=left valign=top>
	<td>Motherboard</td>
	<td>Prozessor</td>
	<td>ROM</td>
	<td>RAM</td>
</tr>

<tr>
	<td>MRW420 / MRWcan</td>
	<td>8051-Core</td>
	<td>62 <B>kByte</B></td>
	<td>2 <B>kByte</B></td>
</tr></table>



\attention <b>Diese Angaben gelten auch f�r die untergeordneten Treibermodule !!!</b>
\~
*/
/*~T*/
/*!
\~english
\page SUBPAGE_HARDWARE_ADUC836_DRIVER 'ADuC836-drivers'

<table border=1 width=100% height=1% rules=rows cellspacing=0 bgcolor="#E0E0F0">

<tr align=left valign=top>
	<td>motherboard</td>
	<td>processor</td>
	<td>ROM</td>
	<td>RAM</td>
</tr>

<tr>
	<td>MRW420 / MRWcan</td>
	<td>8051-Core</td>
	<td>62 <B>kbyte</B></td>
	<td>2 <B>kbyte</B></td>
</tr></table>



\attention <b>This informations are also valide for all subordinated drivermodules !!!</b>
\~
*/
/*~E:A2*/
/*~A:3*/
/*~+:Compiler-Einstellungen*/
/*~T*/
/*!
\~german
\page SUBPAGE_SOFTWARE_COMPILER_SETTINGS_ADUC836_DRIVER 'ADuC836-Treiber'

<table border=1 width=100% height=1% rules=rows cellspacing=0 bgcolor="#E0E0F0">

<tr align=left valign=top>
	<th>Compiler</th>
	<th>Betriebssystem</th>
	<th>Speichermodell</th>
	<th>Code-Speicher-Gr��e</th>
	<th>Optimierungen</th>
	<th>Sonstiges</th>
</tr>

<tr>
	<td>Keil uVision2 V2.40<BR>C51 V7.08<BR>A51 V7.08a</td>
	<td>Kein Betriebssystem</td>
	<td>Large: variables in XDATA</td>
	<td>Large: 64k program</td>
	<td>
	[ ] 0 Constant Folding<BR>
	[ ] 1 Dead Code Elimination<BR>
	[ ] 2 Data Overlaying<BR>
	[ ] 3 Peephole Optimization<BR>
	[ ] 4 Register Variables<BR>
	[ ] 5 Common Subexpression Elimination<BR>
	[ ] 6 Loop Rotation<BR>
	[ ] 7 Extended Index Access Optimizing<BR>
	[ ] 8 Reuse Common Entry Code<BR>
	[X] 9 Common Block Subroutines<BR>
	<BR>
	[X]Favor size<BR>
	[ ]Favor speed</td>
	<td>---</td>
</tr></table>



\attention <b>Diese Angaben gelten auch f�r die untergeordneten Treibermodule !!!</b>
\~
*/
/*~T*/
/*!
\~english
\page SUBPAGE_SOFTWARE_COMPILER_SETTINGS_ADUC836_DRIVER 'ADuC836-drivers'

<table border=1 width=100% height=1% rules=rows cellspacing=0 bgcolor="#E0E0F0">

<tr align=left valign=top>
	<th>compiler</th>
	<th>operatingsystem</th>
	<th>memorymodel</td>
	<th>code-memory-size</th>
	<th>optimizations</th>
	<th>miscellaneous</th>
</tr>

<tr>
	<td>Keil uVision2 V2.40<BR>C51 V7.08<BR>A51 V7.08a</td>
	<td>no operating-system</td>
	<td>Large: variables in XDATA</td>
	<td>Large: 64k program</td>
	<td>
	[ ] 0 Constant Folding<BR>
	[ ] 1 Dead Code Elimination<BR>
	[ ] 2 Data Overlaying<BR>
	[ ] 3 Peephole Optimization<BR>
	[ ] 4 Register Variables<BR>
	[ ] 5 Common Subexpression Elimination<BR>
	[ ] 6 Loop Rotation<BR>
	[ ] 7 Extended Index Access Optimizing<BR>
	[ ] 8 Reuse Common Entry Code<BR>
	[X] 9 Common Block Subroutines<BR>
	<BR>
	[X]Favor size<BR>
	[ ]Favor speed</td>
	<td>---</td>
</tr></table>



\attention <b>This informations are also valide for all subordinated drivermodules !!!</b>
\~
*/
/*~E:A3*/
/*~A:4*/
/*~+:Ressourcen*/
/*~T*/
/*!
\~german
\page SUBPAGE_SOFTWARE_RESSOURCES_ADUC836_DRIVER 'ADuC836-Treiber'

<table border=1 width=100% height=1% rules=rows cellspacing=0 bgcolor="#E0E0F0">

<tr align=left valign=top>
	<td>CODE</td>
	<td>IDATA</td>
	<td>XDATA</td>
	<td>Dynamische Variablen</td>
</tr>

<tr>
	<td>--- <B>Bytes</B></td>
	<td>--- <B>Bytes</B></td>
	<td>--- <B>Bytes</B></td>
	<td>(2*(Anzahl der Sequenzeintr�ge+1)+46) * Anzahl der Messwertkan�le <B>Bytes</B></td>
</tr></table>



\attention <b>Diese Angaben gelten f�r das gesamte Treiberpaket !!!</b>
*/
/*~T*/
/*!
\~english
\page SUBPAGE_SOFTWARE_RESSOURCES_ADUC836_DRIVER 'ADuC836-drivers'

<table border=1 width=100% height=1% rules=rows cellspacing=0 bgcolor="#E0E0F0">

<tr align=left valign=top>
	<td>CODE</td>
	<td>IDATA</td>
	<td>XDATA</td>
	<td>dynamic variables</td>
</tr>

<tr>
	<td>--- <B>bytes</B></td>
	<td>--- <B>bytes</B></td>
	<td>--- <B>bytes</B></td>
	<td>(2*(number of sequenceentries+1)+46) * number of measurement-channels <B>bytes</B></td>
</tr></table>



\attention <b>This informations includes the whole driverpackage !!!</b>
\~
*/
/*~E:A4*/
/*~A:5*/
/*~+:Zykluszeiten*/
/*~T*/
/*!
\~german
\page SUBPAGE_SOFTWARE_CYCLE_TIMES_ADUC836_DRIVER 'ADuC836-Treiber'

<table border=1 width=100% height=1% rules=rows cellspacing=0 bgcolor="#E0E0F0">

<tr align=left valign=top>
	<td>Minimale Durchlaufzeit</td>
	<td>Maximale Durchlaufzeit</td>
</tr>

<tr>
	<td>--- <B>ms</B></td>
	<td>--- <B>ms</B></td>
</tr></table>

\~english
\page SUBPAGE_SOFTWARE_CYCLE_TIMES_ADUC836_DRIVER 'ADuC836-Treiber'

<table border=1 width=100% height=1% rules=rows cellspacing=0 bgcolor="#E0E0F0">

<tr align=left valign=top>
	<td>minimal cycle time</td>
	<td>maximum cycle time</td>
</tr>

<tr>
	<td>--- <B>ms</B></td>
	<td>--- <B>ms</B></td>
</tr></table>
\~
- \subpage SUBPAGE_SOFTWARE_CYCLE_TIMES_ADUC836_DRIVER_ADC
- \subpage SUBPAGE_SOFTWARE_CYCLE_TIMES_ADUC836_DRIVER_DAC
- \subpage SUBPAGE_SOFTWARE_CYCLE_TIMES_ADUC836_DRIVER_EXTERNAL
- \subpage SUBPAGE_SOFTWARE_CYCLE_TIMES_ADUC836_DRIVER_FLASH
- \subpage SUBPAGE_SOFTWARE_CYCLE_TIMES_ADUC836_DRIVER_RS232
- \subpage SUBPAGE_SOFTWARE_CYCLE_TIMES_ADUC836_DRIVER_SPI
- \subpage SUBPAGE_SOFTWARE_CYCLE_TIMES_ADUC836_DRIVER_TIMER
- \subpage SUBPAGE_SOFTWARE_CYCLE_TIMES_ADUC836_DRIVER_WATCHDOG
*/
/*~E:A5*/
/*~A:6*/
/*~+:Interrupts und Registerb�nke*/
/*~T*/
/*!
\~german
\page SUBPAGE_SOFTWARE_INTERRUPTS_REGISTERBANKS_ADUC836_DRIVER 'ADuC836-Treiber'
\~english
\page SUBPAGE_SOFTWARE_INTERRUPTS_REGISTERBANKS_ADUC836_DRIVER 'ADuC836-drivers'
\~
<table width=100% rules=all bgcolor="#E0E0F0">
\~german
<tr align=center valign=top><td><b>Benutzte Interrupts</b></td><td><b>Priorit�t</b></td><td><b>Benutzte Registerb�nke</b></td></tr>
\~english
<tr align=center valign=top><td><b>used interrupts</b></td><td><b>priority</b></td><td><b>used registerbanks</b></td></tr>
\~
<tr align=left valign=top><td>[ ] Power Supply Monitor Interrupt</td><th align=center>[ ] High [ ] Low</td><th align=center>[ ] Bank 0</td></tr>
<tr align=left valign=top><td>[ ] Watchdog Interrupt</td><th align=center>[ ] High [ ] Low</td><th align=center>[ ] Bank 1</td></tr>
<tr align=left valign=top><td>[ ] External Interrupt 0</td><th align=center>[ ] High [ ] Low</td><th align=center>[ ] Bank 2</td></tr>
<tr align=left valign=top><td>[ ] ADC Interrupt</td><th align=center>[ ] High [ ] Low</td><th align=center>[ ] Bank 3</td></tr>
<tr align=left valign=top><td>[ ] Timer/Counter 0 Interrupt</td><th align=center>[ ] High [ ] Low</td><td></td></tr>
<tr align=left valign=top><td>[ ] External Interrupt 1</td><th align=center>[ ] High [ ] Low</td><td></td></tr>
<tr align=left valign=top><td>[ ] Timer/Counter 1 Interrupt</td><th align=center>[ ] High [ ] Low</td><td></td></tr>
<tr align=left valign=top><td>[ ] SPI Interrupt</td><th align=center>[ ] High [ ] Low</td><td></td></tr>
<tr align=left valign=top><td>[ ] Serial Interrupt</td><th align=center>[ ] High [ ] Low</td><td></td></tr>
<tr align=left valign=top><td>[ ] Timer/Counter 2 Interrupt</td><th align=center>[ ] High [ ] Low</td><td></td></tr>
<tr align=left valign=top><td>[ ] Time Interval Counter Interrupt</td><th align=center>[ ] High [ ] Low</td><td></td></tr>
</table>

- \subpage SUBPAGE_SOFTWARE_INTERRUPTS_REGISTERBANKS_ADUC836_DRIVER_ADC
- \subpage SUBPAGE_SOFTWARE_INTERRUPTS_REGISTERBANKS_ADUC836_DRIVER_DAC
- \subpage SUBPAGE_SOFTWARE_INTERRUPTS_REGISTERBANKS_ADUC836_DRIVER_EXTERNAL
- \subpage SUBPAGE_SOFTWARE_INTERRUPTS_REGISTERBANKS_ADUC836_DRIVER_FLASH
- \subpage SUBPAGE_SOFTWARE_INTERRUPTS_REGISTERBANKS_ADUC836_DRIVER_RS232
- \subpage SUBPAGE_SOFTWARE_INTERRUPTS_REGISTERBANKS_ADUC836_DRIVER_SPI
- \subpage SUBPAGE_SOFTWARE_INTERRUPTS_REGISTERBANKS_ADUC836_DRIVER_TIMER
- \subpage SUBPAGE_SOFTWARE_INTERRUPTS_REGISTERBANKS_ADUC836_DRIVER_WATCHDOG
*/
/*~E:A6*/
/*~A:7*/
/*~+:Lifecycle*/
/*~T*/
/*!
\~german
\page SUBPAGE_SOFTWARE_LIFECYCLE_ADUC836_DRIVER 'ADuC836-Treiber'

<table border=1 width=100% height=1% rules=rows cellspacing=0 bgcolor="#E0E0F0">

<tr align=left valign=top>
	<td>Version</td>
	<td>Datum</td>
	<td>Programmierer</td>
	<td>�nderungen</td>
</tr>

<tr>
	<td>1.000</td>
	<td>14.06.05</td>
	<td>Michael Offenbach</td>
	<td>Erste lauff�hige Version</td>
</tr>

<tr>
	<td>1.001</td>
	<td>28.06.05</td>
	<td>Michael Offenbach</td>
	<td>Die Ausgangsgr��e des DAC's kann nun direkt gesetzt werden.</td>
</tr>
</table>

*/
/*~T*/
/*!
\~english
\page SUBPAGE_SOFTWARE_LIFECYCLE_ADUC836_DRIVER 'ADuC836-drivers'

<table border=1 width=100% height=1% rules=rows cellspacing=0 bgcolor="#E0E0F0">

<tr align=left valign=top>
	<td>version</td>
	<td>date</td>
	<td>programmer</td>
	<td>changes</td>
</tr>

<tr>
	<td>1.000</td>
	<td>14.06.05</td>
	<td>Michael Offenbach</td>
	<td>first running version</td>
</tr>

<tr>
	<td>1.001</td>
	<td>28.06.05</td>
	<td>Michael Offenbach</td>
	<td>the output of the DAC's can be set directly.</td>
</tr>
</table>

*/
/*~T*/
/*!
- \subpage SUBPAGE_SOFTWARE_LIFECYCLE_ADUC836_DRIVER_ADC
- \subpage SUBPAGE_SOFTWARE_LIFECYCLE_ADUC836_DRIVER_DAC
- \subpage SUBPAGE_SOFTWARE_LIFECYCLE_ADUC836_DRIVER_EXTERNAL
- \subpage SUBPAGE_SOFTWARE_LIFECYCLE_ADUC836_DRIVER_FLASH
- \subpage SUBPAGE_SOFTWARE_LIFECYCLE_ADUC836_DRIVER_RS232
- \subpage SUBPAGE_SOFTWARE_LIFECYCLE_ADUC836_DRIVER_SPI
- \subpage SUBPAGE_SOFTWARE_LIFECYCLE_ADUC836_DRIVER_TIMER
- \subpage SUBPAGE_SOFTWARE_LIFECYCLE_ADUC836_DRIVER_WATCHDOG
*/

/*~E:A7*/
/*~A:8*/
/*~+:Globale R�ckgabewerte*/
/*~T*/
/*!
\~german
\page SUBPAGE_SOFTWARE_GLOBAL_RETURNS_ADUC836_DRIVER 'ADuC836-Treiber'
\~english
\page SUBPAGE_SOFTWARE_GLOBAL_RETURNS_ADUC836_DRIVER 'ADuC836-drivers'
\~
\~german
<b>keine</b>
\~english
<b>none</b>
\~
- \subpage SUBPAGE_SOFTWARE_GLOBAL_RETURNS_ADUC836_DRIVER_ADC
- \subpage SUBPAGE_SOFTWARE_GLOBAL_RETURNS_ADUC836_DRIVER_DAC
- \subpage SUBPAGE_SOFTWARE_GLOBAL_RETURNS_ADUC836_DRIVER_EXTERNAL
- \subpage SUBPAGE_SOFTWARE_GLOBAL_RETURNS_ADUC836_DRIVER_FLASH
- \subpage SUBPAGE_SOFTWARE_GLOBAL_RETURNS_ADUC836_DRIVER_RS232
- \subpage SUBPAGE_SOFTWARE_GLOBAL_RETURNS_ADUC836_DRIVER_SPI
- \subpage SUBPAGE_SOFTWARE_GLOBAL_RETURNS_ADUC836_DRIVER_TIMER
- \subpage SUBPAGE_SOFTWARE_GLOBAL_RETURNS_ADUC836_DRIVER_WATCHDOG
*/

/*~E:A8*/
/*~A:9*/
/*~+:Beispiel*/
/*~T*/
/*!
\~german 
\page SUBPAGE_SOFTWARE_EXAMPLES_ADUC836_DRIVER 'ADuC836-Treiber'
\~english
\page SUBPAGE_SOFTWARE_EXAMPLES_ADUC836_DRIVER 'ADuC836-drivers'
\~

\code


//Modulbeschreibung:
//Demo-Programm zur Demonstration der Einbindung der ADuC836-Treiber-Befehle 


// Includes
#include "ADuC836.h"
#include "ADuC836Driver.h"
#include "Flash.h"
#include <String.h>

// Direktive f�r ADuC836
#pragma NOAREGS

// Funktionsdeklarationen

main()
{
   // Timing

   unsigned long ulDestinationTime;
   // Flash-Routinen
   char szText[32];

   // ADC-Routinen
   long lADC_Resultat_0;	// Ergebnis der AD-Wandlung des Hauptkanals
   long lADC_Resultat_1;	// Ergebnis der AD-Wandlung des Hilfskanals

   // DAC-Routinen
   unsigned int uDigital;

   // SPI-Routinen
   unsigned char chReturn;
   unsigned char chData;

   // Systemvariablen ADuC836 setzen
   CFG836 |= 1;
   PLLCON &= 0xF8;
   T0 = 0;
   ulDestinationTime = Timer.ulOperatingTime + 250;
   strcpy(szText,"Hallo");

   chData = 0x30;
   // *************************************************************************************** //
   // * Demonstartion der ADC-Routinen														* //
   // *************************************************************************************** //


   // ADC mit Defaultwerten initialsieren
   ADuC836_ADCDefaultIni();
   // Messwerttiefe vorgeben.
   ADuC836_ADCSetMeasurementDepth(ADuC836_ADC_PRIMARY,2);
   // Messwertoffset vorgeben
   ADuC836_ADCSetZeroOffset(ADuC836_ADC_PRIMARY,0x8000);
   // Filterfrequenz einstellen
   ADuC836_ADCSetSincFilter(1,ADuC836_ADC_FREQUENCY_32KHZ);

   // *************************************************************************************** //
   // * Demonstartion der DAC-Routinen														* //
   // *************************************************************************************** //


   // DAC initialsieren
   ADuC836_DACIni(ADUC836_DAC_OUTPUTPIN_3,ADUC836_DAC_RESOLUTION_12BIT,ADUC836_DAC_RANGE_2_REF,ADUC836_DAC_ENABLE);
   // Offset vorgeben
   ADuC836_DACSetOffset(0,ADUC836_DAC_RMV,256);

   // Verst�rkung vorgeben
   ADuC836_DACSetGain(0.75);

   // Unteres Limit setzen
   ADuC836_DACSetLimit(ADUC836_DAC_LOWER_LIMIT,50,ADUC836_DAC_KEEP_OUTPUT);
   // Oberes Limit setzen
   ADuC836_DACSetLimit(ADUC836_DAC_UPPER_LIMIT,4050,ADUC836_DAC_SET2ZERO);



   // DAC auf ersten Kalibrierpunkt fahren
   // ADuC836_DACConvert(0);
   ADuC836_DACConvert(100);
   // und diesem Punkt den Ist- und Sollwert zuweisen
   // ADuC836_DACCalibrationSetPoint(0,1.140,2.5);
   ADuC836_DACCalibrationSetPoint(0,1.505,2.5);

   // DAC auf zweiten Kalibrierpunkt fahren
   // ADuC836_DACConvert(4095);
   ADuC836_DACConvert(4000);
   // und diesem Punkt den Ist- und Sollwert zuweisen
   // ADuC836_DACCalibrationSetPoint(1,18.874,23);
   ADuC836_DACCalibrationSetPoint(1,17.795,23);

   // Kalibrierfaktor berechnen
   ADuC836_DACCalcCalibration();
   // Kalibrierung �berpr�fen

   // 1.Punkt -> 2.5mA
   ADuC836_DACConvert(100);

   // 2.Punkt -> 23mA
   ADuC836_DACConvert(4000);

   // Unteren Grenzwert unterschreiten
   ADuC836_DACConvert(51);
   ADuC836_DACConvert(0);

   // Oberen Grenzwert �berschreiten
   ADuC836_DACConvert(4049);
   ADuC836_DACConvert(4095);

   // Stromwert in Digitalwert wandeln 
   uDigital = ADuC836_DACGetDigital(2.5);

   uDigital = ADuC836_DACGetDigital(23);
   // *************************************************************************************** //
   // * Demonstartion der Flash-Routinen													* //
   // *************************************************************************************** //


   ADuC836_FlashDataWritePtr(szText,0,sizeof(szText));

   memset(szText,0,sizeof(szText));

   ADuC836_FlashDataReadPtr(szText,0,5);
   // *************************************************************************************** //
   // * Demonstartion der SPI-Routinen														* //
   // *************************************************************************************** //

#ifdef SPI_MASTER
   ADuC836_SPIDefaultIni(1); 	// Master-Mode
#endif
#ifdef SPI_SLAVE
   // Der Slave-Kanal darf erst nach dem Master-Kanal initialisieren. Aus diesem Grund wird hier gewartet, bis der Master den Port SPICONTROL (/SS) nach LOW zieht. 
   while (SPICONTROL)
   {

   }
   ADuC836_SPIDefaultIni(0);	// Slave-Mode
#endif
   while (1)
   {
   	  // ************************************************************************************ //
      // * Demonstartion der ADC-Routinen													* //
   	  // ************************************************************************************ //

      lADC_Resultat_0 = ADuC836_ADCGetConversionValue(ADuC836_ADC_PRIMARY,0);
      lADC_Resultat_1 = ADuC836_ADCGetConversionValue(ADuC836_ADC_AUXILIARY,0);
   	  // ************************************************************************************ //
      // * Demonstartion der SPI-Routinen													* //
   	  // ************************************************************************************ //


      if (ulDestinationTime <= Timer.ulOperatingTime)
      {
         ulDestinationTime = Timer.ulOperatingTime + 250;
#ifdef SPI_MASTER
         // Kanal 0 (SPI-Master) liest 4mal pro Sekunde einen String vom Slave aus.
         chReturn =  ADuC836_SPIReadPtr(szText,0);
#endif
      }
#ifdef SPI_SLAVE
      // Kanal 1 (SPI-Slave) stellt einen String zum Auslesen bereit und wartet auf dessen Abschlu�.
      chReturn = ADuC836_SPISendPtr(szText,0);
#endif
   }
}

\endcode
*/
/*~E:A9*/
/*~I:10*/
#ifdef MOF
/*~A:11*/
/*~+:Beschreibungen extern definierter Funktionen*/
/*~T*/
/*!\page ExternalFunctionsPage Extern zu definierende Funktionen

\section sec_ExternalFunctionsPage_ADuC836Driver 'ADuC836-Treiber'

char Filter_Interface(MEASUREMENT_FILTERPARAMETERS *pFilterParameters)<br>
char Correction_Interface(MEASUREMENT_CORRECTIONPARAMETERS *pCorrectionParameters)

*/ 
/*~E:A11*/
/*~-1*/
#endif
/*~E:I10*/
