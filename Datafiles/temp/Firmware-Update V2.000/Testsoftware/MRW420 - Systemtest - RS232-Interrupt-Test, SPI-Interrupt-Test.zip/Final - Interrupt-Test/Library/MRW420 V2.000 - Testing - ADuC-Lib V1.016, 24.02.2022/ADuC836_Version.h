/*~-1*/
/*~XSF_LANGUAGE: C/C++*/
/*~K*/
/*~+:File :        ADuC836_Version.h*/
/*~+:*/
/*~+:Version :     V1.016*/
/*~+:*/
/*~+:Date :        24.02.2022*/
/*~+:*/
/*~+:Time :        */
/*~+:*/
/*~+:Author :      MOF*/
/*~+:*/
/*~+:Hardware :*/
/*~+:*/
/*~+:Description :*/
/*~A:1*/
/*~+:Versions-Beschreibung*/
/*~K*/
/*#LH:0F"Doxygen_ADuC836Driver.h"=29-51*/
/*~+:-> Doxygen_ADuC836Driver.h*/
/*~+:*/
/*~+:Doxygen_ADuC836Driver.h*/
/*~E:A1*/
/*~I:2*/
#ifndef __ADUC836_VERSION_H

/*~T*/
#define __ADUC836_VERSION_H
/*~K*/
/*~+:// Versionsangabe*/
/*~T*/
char code ADUC836_SOFTWAREVERSION[] = {"V1.016, 24.02.2022"};
/*~-1*/
#endif
/*~E:I2*/
