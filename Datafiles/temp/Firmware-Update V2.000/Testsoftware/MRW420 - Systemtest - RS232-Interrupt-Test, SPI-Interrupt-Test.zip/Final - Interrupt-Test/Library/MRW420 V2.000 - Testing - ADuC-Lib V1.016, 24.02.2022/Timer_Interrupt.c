/*~-1*/
/*~XSF_LANGUAGE: C/C++*/
/*~K*/
/*~+:File :        Timer_Interrupt.c*/
/*~+:*/
/*~+:Version :     V1.000*/
/*~+:*/
/*~+:Date :        03.06.2005*/
/*~+:*/
/*~+:Time :        */
/*~+:*/
/*~+:Author :      MOF*/
/*~+:*/
/*~+:Hardware :*/
/*~+:*/
/*~+:Description :*/
/*~A:1*/
/*~+:Includes*/
/*~T*/
#include "ADuC836Driver.h"

/*~E:A1*/
/*~A:2*/
/*~+:Funktionseigene Definitionen*/
/*~T*/

/*~E:A2*/
/*~A:3*/
/*~+:Funktionseigene Struktur-Definitionen*/
/*~T*/

/*~E:A3*/
/*~A:4*/
/*~+:Funktionsprototypen*/
/*~T*/

/*~E:A4*/
/*~A:5*/
/*~+:Globale Variablen*/
/*~T*/
extern TIMER Timer;
/*~E:A5*/
/*~A:6*/
/*~+:void ADuC836_TimerInterrupt() interrupt 1*/
/*~F:7*/
void ADuC836_TimerInterrupt() interrupt 1 // using 3
/*~-1*/
{
   /*~A:8*/
   /*~+:Beschreibung*/
   /*~T*/
   /*!
   \fn void ADuC836_TimerInterrupt() interrupt 1
   
   <b>Beschreibung:</b><br>
   Timerinterrupt. Diese Funktion setzt alle 10ms den Betriebszeitz�hler um eins hoch.
   
   \return
   ./.
   
   <b>Zugriff:</b><br>
   [X] �ffentlich / [ ] Privat
   
   \ref
   ExamplePage_ADuC836Driver "Beispiel 'ADuC836-Treiber'"
   */
   /*~E:A8*/
   /*~A:9*/
   /*~+:Variablendeklarationen*/
   /*~T*/
   unsigned char chTimer;
   /*~E:A9*/
   /*~A:10*/
   /*~+:Variableninitialisierungen*/
   /*~I:11*/
#ifdef TIMER_TIMEBASE_10MS
   /*~T*/
   TL0 = 0x0B;
   TH0 = 0xD7;	// Atomzeit = 10msec
   /*~O:I11*/
   /*~-1*/
#else
   /*~I:12*/
#ifdef TIMER_TIMEBASE_1MS
   /*~T*/
   TL0 = 0x18;
   TH0 = 0xFC; // Atomzeit = 1ms
   /*~-1*/
#endif
   /*~E:I12*/
   /*~-1*/
#endif
   /*~E:I11*/
   /*~E:A10*/
   /*~I:13*/
#ifdef TIMER_TIMEBASE_1MS
   /*~T*/
   Timer.ulOperatingTime++;
   /*~-1*/
#endif
   /*~E:I13*/
   /*~I:14*/
#ifdef TIMER_TIMEBASE_10MS
   /*~T*/
   Timer.ulOperatingTime += 10;
   /*~-1*/
#endif
   /*~E:I14*/
   /*~I:15*/
   if (Timer.ulOperatingTime >= 0xFFFF0000)
   /*~-1*/
   {
      /*~T*/
      // Einem �berlauf vorbeugen und die Betriebszeit und die Zielzeitpunkte zur�cksetzen
      Timer.ulOperatingTime = 0;
      /*~L:16*/
      for (chTimer = 0;chTimer < TIMER_NB_TIMERS;chTimer++)
      /*~-1*/
      {
         /*~T*/
         Timer.ulDestinationTime[chTimer] = 0;
      /*~-1*/
      }
      /*~E:L16*/
   /*~-1*/
   }
   /*~E:I15*/
   /*~I:17*/
   if (Timer.chTimerInterfaceOnOff)
   /*~-1*/
   {
      /*~T*/
      Timer_Interface();
   /*~-1*/
   }
   /*~E:I17*/
/*~-1*/
}
/*~E:F7*/
/*~E:A6*/
