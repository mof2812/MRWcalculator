/*~-1*/
/*~XSF_LANGUAGE: C/C++*/
/*~T*/
/*

   (1) MODULNAME             :  ADC_GetConversionTime.c
   (2) VERSION               :  1.00
   (3) DATUM                 :  24.05.2007

   (4) LETZTE �NDERUNG       :  
   (5) PROJEKT (Vers.)       :  MRW Limit
   (6) PROGRAMMIERER         :  MOF

*/
/*~A:1*/
/*~+:Includes*/
/*~T*/
#include "ADC_Global.h"
/*~E:A1*/
/*~A:2*/
/*~+:Defines */
/*~T*/

/*~E:A2*/
/*~A:3*/
/*~+:Funktionsprototypen*/
/*~T*/
unsigned int ADC_GetConvertionTime(unsigned char byChanel);
/*~E:A3*/
/*~A:4*/
/*~+:Modulvariablen*/
/*~T*/
extern ADC_SETTINGS ADC_Settings[];		///< ADC-Parameter f�r Haupt- und Hilfs-ADC
extern ADC_RESULTS 	ADC_Results[];			///< Ergebnisse der AD-Wandlungen
/*~E:A4*/
/*~I:5*/
#ifdef ADC_MIT_WANDLERRATENERMITTLUNG
/*~A:6*/
/*~+:unsigned int ADuC836_ADCGetConversionTime(unsigned char byChanel)*/
/*~F:7*/
unsigned int ADuC836_ADCGetConversionTime(unsigned char byChanel)
/*~-1*/
{
   /*~T*/
   return g_ADC.Results[byChanel].uConversionTimeMS; 
/*~-1*/
}
/*~E:F7*/
/*~E:A6*/
/*~-1*/
#endif
/*~E:I5*/
