/*~-1*/
/*~XSF_LANGUAGE: C/C++*/
/*~T*/
/*

   (1) MODULNAME             :  DAC_Ini.c
   (2) VERSION               :  1.00
   (3) DATUM                 :  

   (4) LETZTE �NDERUNG       :  
   (5) PROJEKT (Vers.)       :  MRW Limit
   (6) PROGRAMMIERER         :  MOF

*/
/*~A:1*/
/*~+:Includes*/
/*~T*/
#include "DAC_Global.h"
#include "string.h"
/*~E:A1*/
/*~A:2*/
/*~+:Defines */
/*~T*/

/*~E:A2*/
/*~A:3*/
/*~+:Funktionsprototypen*/
/*~T*/
void ADuC836_DACIni(char chOutput,char chResolution,char chRange,char chEnable);
/*~E:A3*/
/*~A:4*/
/*~+:Globale Variablen*/
/*~T*/

/*~E:A4*/
/*~A:5*/
/*~+:void ADuC836_DACIni(char chOutput,char chResolution,char chRange,char chEnable)*/
/*~F:6*/
void ADuC836_DACIni(char chOutput,char chResolution,char chRange,char chEnable)
/*~-1*/
{
   /*~A:7*/
   /*~+:Beschreibung*/
   /*~T*/
   /*!
   \fn void ADuC836_DACIni(char chOutput,char chResolution,char chRange,char chEnable)
   
   <b>Beschreibung:</b><br>
   Initialisierung des DAC's. Hierzu geh�rt das Setzen von DAC-Ausgangspin, Aufl�sung, Ausgangsspannungsbereich und DAC-Freigabe.
   \param
   chOutput: DAC-Ausgangspin
   
   \param
   chResolution: Aufl�sung
   
   \param
   chRange: Ausgangsspannungsbereich
   
   \param
   chEnable: DAC-Freigabe
   
   \retval
   ./.
   
   <b>Zugriff:</b><br>
   [X] �ffentlich / [ ] Privat
   
   \ref
   ExamplePage_ADuC836Driver "Beispiel 'ADuC836-Treiber'"
   */
   /*~E:A7*/
   /*~A:8*/
   /*~+:Struktur-Inhalte l�schen*/
   /*~T*/
   memset(&g_DAC.Settings,0,sizeof(DAC_SETTINGS));
   /*~E:A8*/
   /*~T*/
   ADuC836_DACSetOutput(chOutput);
   ADuC836_DACSetResolution(chResolution);
   ADuC836_DACSetRange(chRange);
   ADuC836_DACEnable(chEnable);

   ADuC836_DACClearOutput(ADUC836_DAC_NORM_OP);
   /*~T*/
   g_DAC.Settings.fOffset_Norm = g_DAC.Settings.fOffset_RMV = 0;
   g_DAC.Settings.fGain_Norm = g_DAC.Settings.fGain_RMV = 1;
   g_DAC.Settings.bCorrectionOn = 1;
   g_DAC.Settings.Limits.byLimitState = DAC_NO_LIMIT_REACHED;			// kein Grenzwert erreicht
   g_DAC.Settings.Limits.uHysteresisLowerLimit = 0;
   g_DAC.Settings.Limits.uHysteresisUpperLimit = 0;
   g_DAC.Settings.Limits.uLimitHysteresisCounter = 0;					// Z�hler f�r Zeithysterese zur�cksetzen
   g_DAC.lOffset = 0;
/*~-1*/
}
/*~E:F6*/
/*~E:A5*/
