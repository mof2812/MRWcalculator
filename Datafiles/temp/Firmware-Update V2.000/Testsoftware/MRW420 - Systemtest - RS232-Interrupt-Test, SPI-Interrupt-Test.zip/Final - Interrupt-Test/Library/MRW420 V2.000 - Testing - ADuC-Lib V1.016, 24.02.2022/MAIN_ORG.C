/*~-1*/
/*~XSF_LANGUAGE: C/C++*/
/*~A:1*/
/*~+:Includes*/
/*~T*/
#include "ADuC836.h"
#include "DAC.h"
#include "Flash.h"
#include <String.h>
/*~E:A1*/
/*~T*/
#pragma NOAREGS

/*~A:2*/
/*~+:Funktionsdeklarationen*/
/*~T*/
void SecurityFunk(unsigned char byError);
/*~E:A2*/
/*~F:3*/
main()
/*~-1*/
{
   /*~A:4*/
   /*~+:Variablendeklarationen*/
   /*~T*/
   char szText[32];
   /*~E:A4*/
   /*~A:5*/
   /*~+:Variableninitialisierungen*/
   /*~T*/
   CFG836 |= 1;
   PLLCON &= 0xF8;
   T0 = 0;
   /*~T*/
   strcpy(szText,"Hallo");
   /*~E:A5*/
   /*~T*/
   ADuC836_DACIni(ADUC836_DAC_OUTPUTPIN_3,ADUC836_DAC_RESOLUTION_12BIT,ADUC836_DAC_RANGE_2_REF,ADUC836_DAC_ENABLE);
   /*~T*/
   ADuC836_DACSetOffset(0,256);
   ADuC836_DACSetGain(0.75);

   ADuC836_DACConvert(0);
   ADuC836_DACCalibrationSetPoint(0,1.138,2.5);

   ADuC836_DACConvert(4095);
   ADuC836_DACCalibrationSetPoint(1,18.87,23);

   ADuC836_DACCalcCalibration();

   /*~T*/
   ADuC836_DACConvert(0);
   ADuC836_DACConvert(4095);
   ADuC836_DACConvert(255);
   ADuC836_DACConvert(511);
   ADuC836_DACConvert(767);
   ADuC836_DACConvert(1023);
   ADuC836_DACConvert(1279);
   ADuC836_DACConvert(1535);
   ADuC836_DACConvert(1791);
   ADuC836_DACConvert(2047);
   ADuC836_DACConvert(2303);
   ADuC836_DACConvert(2559);
   ADuC836_DACConvert(2815);
   ADuC836_DACConvert(3071);
   ADuC836_DACConvert(3327);
   ADuC836_DACConvert(3583);
   ADuC836_DACConvert(3839);
   /*~K*/
   /*~+:*/
   /*~T*/
   ADuC836_FlashDataWritePtr(szText,0,sizeof(szText));

   memset(szText,0,sizeof(szText));

   ADuC836_FlashDataReadPtr(szText,0,5);
   /*~L:6*/
   while (1)
   /*~-1*/
   {
      /*~T*/

   /*~-1*/
   }
   /*~E:L6*/
/*~-1*/
}
/*~E:F3*/
