/*~-1*/
/*~XSF_LANGUAGE: C/C++*/
/*~T*/
/*

   (1) MODULNAME             :  ADC_Enable.c
   (2) VERSION               :  1.00
   (3) DATUM                 :  

   (4) LETZTE �NDERUNG       :  
   (5) PROJEKT (Vers.)       :  ADuc836-Driver
   (6) PROGRAMMIERER         :  MOF

*/
/*~A:1*/
/*~+:Includes*/
/*~T*/
#include "ADC_Global.h"
/*~E:A1*/
/*~A:2*/
/*~+:Defines */
/*~T*/

/*~E:A2*/
/*~A:3*/
/*~+:Funktionsprototypen*/
/*~T*/
void ADuC836_ADCEnable(unsigned char byEnable);
/*~E:A3*/
/*~A:4*/
/*~+:Modulvariablen*/
/*~T*/

/*~E:A4*/
/*~A:5*/
/*~+:void ADuC836_ADCEnable(unsigned char byEnable)*/
/*~F:6*/
void ADuC836_ADCEnable(unsigned char byEnable)
/*~-1*/
{
   /*~T*/
   g_byEnable = byEnable;
/*~-1*/
}
/*~E:F6*/
/*~E:A5*/
