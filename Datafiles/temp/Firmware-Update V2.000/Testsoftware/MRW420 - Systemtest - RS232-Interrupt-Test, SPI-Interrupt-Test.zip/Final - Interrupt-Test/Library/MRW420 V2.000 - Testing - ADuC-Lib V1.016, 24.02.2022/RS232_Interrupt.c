/*~-1*/
/*~XSF_LANGUAGE: C/C++*/
/*~K*/
/*~+:File :        RS232_Interrupt.c*/
/*~+:*/
/*~+:Version :     V1.008*/
/*~+:*/
/*~+:Date :        09.02.2022*/
/*~+:*/
/*~+:Time :        10:23*/
/*~+:*/
/*~+:Author :      MOF*/
/*~+:*/
/*~+:Hardware :*/
/*~+:*/
/*~+:Description :*/
/*~+:*/
/*~+:*/
/*~A:1*/
/*~+:Includes*/
/*~T*/
#include "ADuC836.h"
#include "ADuC836Driver.h"
#include <string.h>
/*~E:A1*/
/*~A:2*/
/*~+:Funktionseigene Definitionen*/
/*~T*/

/*~E:A2*/
/*~A:3*/
/*~+:Funktionseigene Struktur-Definitionen*/
/*~T*/

/*~E:A3*/
/*~A:4*/
/*~+:Funktionsprototypen*/
/*~T*/

/*~E:A4*/
/*~A:5*/
/*~+:Globale Variablen*/
/*~T*/

/*~E:A5*/
/*~A:6*/
/*~+:void ADuC836_RS232Interrupt() interrupt 4*/
/*~F:7*/
void ADuC836_RS232Interrupt() interrupt 4 // using 3

/*~-1*/
{
   /*~A:8*/
   /*~+:Beschreibung*/
   /*~T*/
   /*!
   \fn void RS232_Interrupt() interrupt 4
   
   <b>Beschreibung:</b><br>
   Interruptroutine zum Empfangen oder Senden einzelner Zeichen �ber die RS232-Schnittstelle.
   
   \return
   ./.
   
   <b>Zugriff:</b><br>
   [] �ffentlich / [X] Privat
   
   \ref
   ExamplePage_RS232Kommunikation "RS232-Kommunikation"
   */

   /*~E:A8*/
   /*~A:9*/
   /*~+:Variablendeklarationen*/
   /*~T*/
   unsigned char 			chRS232Data;
   /*~I:10*/
#ifdef DEVELOPMENT_SW
   /*~I:11*/
#ifdef DEVELOPMENT_SW_TEST_IRQS
   /*~T*/
   static unsigned char chDataBehindBuffer;
   /*~-1*/
#endif
   /*~E:I11*/
   /*~-1*/
#endif
   /*~E:I10*/
   /*~E:A9*/
   /*~A:12*/
   /*~+:Variableninitialisierungen*/
   /*~T*/

   /*~E:A12*/
   /*~I:13*/
   if (RI)
   /*~-1*/
   {
      /*~A:14*/
      /*~+:Empfangs-Interrupt*/
      /*~I:15*/
      if (!RS232.chNewCommandReceived)
      /*~-1*/
      {
         /*~T*/
         chRS232Data = SBUF;
         /*~I:16*/
         if (chRS232Data == 0x02)	// STX
         /*~-1*/
         {
            /*~T*/
            /* STX empfangen */
            RS232.pchRecBufferIndex = RS232.pchRecBuffer;
            /*~I:17*/
#ifdef RS232_WITH_STATISTICS
            /*~T*/
            RS232.Statistics.ulSTXCount++;
            /*~-1*/
#endif
            /*~E:I17*/
            /*~I:18*/
#ifdef DEVELOPMENT_SW
            /*~I:19*/
#ifdef DEVELOPMENT_SW_TEST_IRQS
            /*~T*/
            /* Kennung an die letzte Stelle im Empfangspuffer schreiben */
            *(RS232.pchRecBuffer + RS232.chBufferSize - 1) = 0xAA;
            /*~-1*/
#endif
            /*~E:I19*/
            /*~-1*/
#endif
            /*~E:I18*/
         /*~-1*/
         }
         /*~O:I16*/
         /*~-2*/
         else
         {
            /*~I:20*/
            if (RS232.pchRecBufferIndex != 0)
            /*~-1*/
            {
               /*~I:21*/
               /* STX bereits empfangen - bereit f�r die n�chsten Zeichen */
               if (chRS232Data == 0x03)	// ETX)
               /*~-1*/
               {
                  /*~T*/
                  /* ETX bereits empfangen - Empfangsstring abschlie�en und den Empfangsindex auf 0 setzen */

                  *RS232.pchRecBufferIndex = 0;

                  RS232.pchRecBufferIndex = 0;
                  /*~I:22*/
                  if (*RS232.pchRecBuffer == 0x1B)
                  /*~-1*/
                  {
                     /*~T*/
                     /* Vermerk setzen, dass der Empfangsstring ein ESC-Zeichen war */
                     RS232.bESC = 1;
                  /*~-1*/
                  }
                  /*~O:I22*/
                  /*~-2*/
                  else
                  {
                     /*~T*/
                     /* Flag f�r empfangenen Befehlsstring setzen */
                     RS232.chNewCommandReceived = 1;
                  /*~-1*/
                  }
                  /*~E:I22*/
                  /*~I:23*/
#ifdef RS232_WITH_STATISTICS
                  /*~T*/
                  RS232.Statistics.ulETXCount++;
                  /*~-1*/
#endif
                  /*~E:I23*/
               /*~-1*/
               }
               /*~O:I21*/
               /*~-2*/
               else
               {
                  /*~I:24*/
                  if (RS232.pchRecBufferIndex - RS232.pchRecBuffer < RS232.chBufferSize - 1)
                  /*~-1*/
                  {
                     /*~T*/
                     /* Ausreichend Speicher vorhanden - Daten im Speicher eintragen und Index inkrementieren */

                     *RS232.pchRecBufferIndex = chRS232Data;

                     RS232.pchRecBufferIndex++;
                  /*~-1*/
                  }
                  /*~O:I24*/
                  /*~-2*/
                  else
                  {
                     /*~T*/
                     /* Speicher voll - Empfangsindex auf 0 setzen - jetzt muss es wieder mit STX losgehen */

                     RS232.pchRecBufferIndex = 0;
                  /*~-1*/
                  }
                  /*~E:I24*/
               /*~-1*/
               }
               /*~E:I21*/
            /*~-1*/
            }
            /*~O:I20*/
            /*~-2*/
            else
            {
               /*~T*/
               // Es kommt ein Zeichen, ohne dass zuvor ein STX empfangen wurde - oder Buffer ist voll
            /*~-1*/
            }
            /*~E:I20*/
            /*~I:25*/
#ifdef DEVELOPMENT_SW
            /*~I:26*/
#ifdef DEVELOPMENT_SW_TEST_IRQS
            /*~I:27*/
            if ((RS232.pchRecBufferIndex == 0L)&&(*(RS232.pchRecBuffer + 4) == 0x30))
            /*~-1*/
            {
               /*~T*/
               chDataBehindBuffer = *(RS232.pchRecBuffer + RS232.chBufferSize);
            /*~-1*/
            }
            /*~E:I27*/
            /*~-1*/
#endif
            /*~E:I26*/
            /*~-1*/
#endif
            /*~E:I25*/
         /*~-1*/
         }
         /*~E:I16*/
      /*~-1*/
      }
      /*~E:I15*/
      /*~E:A14*/
      /*~T*/
      RI = 0;
   /*~-1*/
   }
   /*~O:I13*/
   /*~-2*/
   else
   {
      /*~A:28*/
      /*~+:Sende-Interrupt*/
      /*~T*/
      chRS232Data = *(RS232.pchTransBuffer+RS232.nTransPointer);
      *(RS232.pchTransBuffer+RS232.nTransPointer) = 0;
      /*~I:29*/
      if (chRS232Data)
      /*~-1*/
      {
         /*~T*/
         RS232.nTransPointer++;
         SBUF = chRS232Data;
         /*~I:30*/
         if (RS232.ulTimeoutRS232Release != -1)
         /*~-1*/
         {
            /*~T*/
            // f�r l�ngere Daten, die Timeoutzeit erweitern

            RS232.ulTimeoutRS232Release = Timer.ulOperatingTime + 50; 
         /*~-1*/
         }
         /*~E:I30*/
      /*~-1*/
      }
      /*~O:I29*/
      /*~-2*/
      else
      {
         /*~T*/
         // Sendestring-Pointer zur�cksetzen
         RS232.nTransPointer = 0;

         // �bertragung beendet
         RS232.bEOT = 1;
         /*~T*/
         TXD = 1;
      /*~-1*/
      }
      /*~E:I29*/
      /*~E:A28*/
      /*~T*/
      TI = 0;
   /*~-1*/
   }
   /*~E:I13*/
/*~-1*/
}
/*~E:F7*/
/*~E:A6*/
