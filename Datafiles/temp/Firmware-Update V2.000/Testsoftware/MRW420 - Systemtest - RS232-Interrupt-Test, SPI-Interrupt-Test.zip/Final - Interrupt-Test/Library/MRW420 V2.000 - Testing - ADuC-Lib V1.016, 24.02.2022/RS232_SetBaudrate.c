/*~-1*/
/*~XSF_LANGUAGE: C/C++*/
/*~K*/
/*~+:File :        RS232_SetBaudrate.c*/
/*~+:*/
/*~+:Version :     V1.0*/
/*~+:*/
/*~+:Date :        03.06.2005*/
/*~+:*/
/*~+:Time :        10:23*/
/*~+:*/
/*~+:Author :      MOF*/
/*~+:*/
/*~+:Hardware :*/
/*~+:*/
/*~+:Description :*/
/*~+:*/
/*~+:*/
/*~A:1*/
/*~+:Includes*/
/*~T*/
#include "ADuC836.h"
#include "ADuC836Driver.h"
/*~E:A1*/
/*~A:2*/
/*~+:Funktionseigene Definitionen*/
/*~T*/

/*~E:A2*/
/*~A:3*/
/*~+:Funktionseigene Struktur-Definitionen*/
/*~T*/

/*~E:A3*/
/*~A:4*/
/*~+:Funktionsprototypen*/
/*~T*/
char ADuC836_RS232SetBaudrate(unsigned long ulBaudrate);
/*~E:A4*/
/*~A:5*/
/*~+:Globale Variablen*/
/*~T*/

/*~E:A5*/
/*~A:6*/
/*~+:char ADuC836_RS232SetBaudrate(unsigned long ulBaudrate)*/
/*~F:7*/
char ADuC836_RS232SetBaudrate(unsigned long ulBaudrate)
/*~-1*/
{
   /*~A:8*/
   /*~+:Beschreibung*/
   /*~T*/
   /*!
   \fn unsigned char RS232_SetBaudrate(unsigned int uBaudrate)
   
   <b>Beschreibung:</b><br>
   Setzen der Baudrate der RS232-Kommunikation. Es sind die �bertragungsgeschwindigkeiten 9600,19200,38400,57600 und 115200 Baud m�glich. Diese Routine gilt nur f�r Prozessoren mit einer internen Taktung von 12MHz! 
   
   \param
   uBaudrate: zu setzende Baudrate.
   
   \return
   Status der Funktionsausf�hrung.
   
   \retval
   0: Alles okay.
   
   \retval
   2: Ung�ltiger Parameterwert - Baudrate konnte nicht eingestellt werden.
   
   <b>Zugriff:</b><br>
   [X] �ffentlich / [ ] Privat
   
   \ref
   ExamplePage_RS232Kommunikation "RS232-Kommunikation"
   */

   /*~E:A8*/
   /*~I:9*/
   if ((ulBaudrate != 9600)&&(ulBaudrate != 19200)&&(ulBaudrate != 38400)&&(ulBaudrate != 57600)&&(ulBaudrate != 115200))
   /*~-1*/
   {
      /*~T*/
      ulBaudrate = 9600;
   /*~-1*/
   }
   /*~E:I9*/
   /*~T*/
   // Timer 3 ausschalten und die Bits f�r die Baudrate l�schen
   //      T3CON &= 0x74;
   T3CON &= 0x78;
   /*~C:10*/
   switch (ulBaudrate)
   /*~-1*/
   {
      /*~F:11*/
      case 9600:
      /*~-1*/
      {
         /*~T*/
         T3CON |= 0x05;
         T3FD = 0x12;
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F11*/
      /*~F:12*/
      case 19200:
      /*~-1*/
      {
         /*~T*/
         T3CON |= 0x04;
         T3FD = 0x12;
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F12*/
      /*~F:13*/
      case 38400:
      /*~-1*/
      {
         /*~T*/
         T3CON |= 0x03;
         T3FD = 0x12;
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F13*/
      /*~F:14*/
      case 57600:
      /*~-1*/
      {
         /*~T*/
         T3CON |= 0x02;
         T3FD = 0x2D;
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F14*/
      /*~F:15*/
      case 115200:
      /*~-1*/
      {
         /*~T*/
         T3CON |= 0x01;
         T3FD = 0x2D;
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F15*/
   /*~-1*/
   }
   /*~E:C10*/
   /*~T*/
   // Timer 3 einschalten
   T3CON |= 0x80;
   /*~T*/
   return 0;
/*~-1*/
}
/*~E:F7*/
/*~E:A6*/
