/*~-1*/
/*~XSF_LANGUAGE: C/C++*/
/*~T*/
/*

   (1) MODULNAME             :  CRC16_Clear.c
   (2) VERSION               :  1.00
   (3) DATUM                 :  

   (4) LETZTE �NDERUNG       :  
   (5) PROJEKT (Vers.)       :  MRW Limit
   (6) PROGRAMMIERER         :  MOF

*/
/*~A:1*/
/*~+:Includes*/
/*~T*/
#include "CRC16.h"

/*~E:A1*/
/*~A:2*/
/*~+:Defines */
/*~T*/

/*~E:A2*/
/*~A:3*/
/*~+:Funktionsprototypen*/
/*~T*/
unsigned int CRC16_Clear(void);
/*~E:A3*/
/*~A:4*/
/*~+:Globale Variablen*/
/*~T*/

/*~E:A4*/
/*~A:5*/
/*~+:unsigned int CRC16_Clear(void)*/
/*~F:6*/
unsigned int CRC16_Clear(void)
/*~-1*/
{
   /*~A:7*/
   /*~+:Beschreibung*/
   /*~T*/
   /*!
   \fn unsigned int CRC16_Clear(void)
   
   <b>Beschreibung:</b><br>
   Setzt die CRC16-Pr�fsumme zur�ck 
   
   \param
   ./.
   
   \return
   Aktualisierte Pr�fsumme.
   
   <b>Zugriff:</b><br>
   [X] �ffentlich / [ ] Privat
   
   \ref
   */

   /*~E:A7*/
   /*~A:8*/
   /*~+:Variablendeklarationen*/
   /*~T*/

   /*~E:A8*/
   /*~A:9*/
   /*~+:Variableninitialisierungen*/
   /*~T*/

   /*~E:A9*/
   /*~T*/
   g_uiCRC16 = 0;
   /*~T*/
   return g_uiCRC16;
/*~-1*/
}
/*~E:F6*/
/*~E:A5*/
