/*~-1*/
/*~XSF_LANGUAGE: C/C++*/
/*~K*/
/*~+:File :        SPI_Wait4Response.c*/
/*~+:*/
/*~+:Version :     V1.0*/
/*~+:*/
/*~+:Date :        18.01.2008*/
/*~+:*/
/*~+:Time :        10:23*/
/*~+:*/
/*~+:Author :      MOF*/
/*~+:*/
/*~+:Hardware :*/
/*~+:*/
/*~+:Description :*/
/*~A:1*/
/*~+:Includes*/
/*~T*/
#include "ADuC836Driver.h"
#include "SPI_Global.h"
/*~E:A1*/
/*~A:2*/
/*~+:Funktionseigene Definitionen*/
/*~T*/
#
/*~E:A2*/
/*~A:3*/
/*~+:Funktionseigene Struktur-Definitionen*/
/*~T*/

/*~E:A3*/
/*~A:4*/
/*~+:Funktionsprototypen*/
/*~T*/
char ADuC836_SPIWait4Response(unsigned long ulTimeout);
/*~E:A4*/
/*~A:5*/
/*~+:Globale Variablen*/
/*~T*/

/*~E:A5*/
/*~A:6*/
/*~+:char ADuC836_SPIWait4Response(unsigned long ulTimeout)*/
/*~F:7*/
char ADuC836_SPIWait4Response(unsigned long ulTimeout)
/*~-1*/
{
   /*~A:8*/
   /*~+:Variablendeklarationen*/
   /*~T*/
   unsigned long 	ulLastTime;
   unsigned long 	ulCounter;
   /*~E:A8*/
   /*~A:9*/
   /*~+:Variableninitialisierungen*/
   /*~T*/
   ulLastTime = Timer.ulOperatingTime; 
   /*~I:10*/
#ifdef TIMER_TIMEBASE_1MS
   /*~T*/
   ulCounter = ulTimeout; 
   /*~O:I10*/
   /*~-1*/
#else
   /*~T*/
   ulCounter = ulTimeout / 10; 
   /*~-1*/
#endif
   /*~E:I10*/
   /*~E:A9*/
   /*~U:11*/
   /*~-2*/
   do
   {
      /*~I:12*/
      if (SPI.chNewCommandReceived)
      /*~-1*/
      {
         /*~T*/
         // Neues Frame gefunden
         return 0;
      /*~-1*/
      }
      /*~O:I12*/
      /*~-2*/
      else
      {
         /*~I:13*/
         if (ulTimeout > 0)
         /*~-1*/
         {
            /*~I:14*/
            if (Timer.ulOperatingTime > ulLastTime)
            /*~-1*/
            {
               /*~T*/
               ulLastTime = Timer.ulOperatingTime;
               ulCounter--;
            /*~-1*/
            }
            /*~E:I14*/
         /*~-1*/
         }
         /*~E:I13*/
      /*~-1*/
      }
      /*~E:I12*/
   /*~-1*/
   }
   /*~O:U11*/
   while (ulCounter > 0);
   /*~E:U11*/
   /*~I:15*/
#ifdef ADUC836_SPI_GLOBALS_DEBUG_COM
   /*~T*/
   // inkrementiere den Fehlerz�hler
   ADuC836_SPIIncErrors(SPI_ERROR_WAIT4CHAR);
   /*~-1*/
#endif
   /*~E:I15*/
   /*~T*/
   return 1;
/*~-1*/
}
/*~E:F7*/
/*~E:A6*/
