/*~-1*/
/*~XSF_LANGUAGE: C/C++*/
/*~K*/
/*~+:File :        RS232_IsEscape.c*/
/*~+:*/
/*~+:Version :     V1.0*/
/*~+:*/
/*~+:Date :        03.06.2005*/
/*~+:*/
/*~+:Time :        10:23*/
/*~+:*/
/*~+:Author :      MOF*/
/*~+:*/
/*~+:Hardware :*/
/*~+:*/
/*~+:Description :*/
/*~+:*/
/*~+:*/
/*~A:1*/
/*~+:Includes*/
/*~T*/
#include "ADuC836.h"
#include "ADuC836Driver.h"
#include <string.h>
/*~E:A1*/
/*~A:2*/
/*~+:Funktionseigene Definitionen*/
/*~T*/

/*~E:A2*/
/*~A:3*/
/*~+:Funktionseigene Struktur-Definitionen*/
/*~T*/

/*~E:A3*/
/*~A:4*/
/*~+:Funktionsprototypen*/
/*~T*/
char ADuC836_RS232IsEscape(void);
/*~E:A4*/
/*~A:5*/
/*~+:Globale Variablen*/
/*~T*/

/*~E:A5*/
/*~A:6*/
/*~+:char ADuC836_RS232IsEscape(void)*/
/*~F:7*/
char ADuC836_RS232IsEscape(void)
/*~-1*/
{
   /*~I:8*/
   if (RS232.bESC)
   /*~-1*/
   {
      /*~T*/
      RS232.bESC = 0;
      /*~T*/
      return 1;
   /*~-1*/
   }
   /*~O:I8*/
   /*~-2*/
   else
   {
      /*~T*/
      return 0;
   /*~-1*/
   }
   /*~E:I8*/
/*~-1*/
}
/*~E:F7*/
/*~E:A6*/
