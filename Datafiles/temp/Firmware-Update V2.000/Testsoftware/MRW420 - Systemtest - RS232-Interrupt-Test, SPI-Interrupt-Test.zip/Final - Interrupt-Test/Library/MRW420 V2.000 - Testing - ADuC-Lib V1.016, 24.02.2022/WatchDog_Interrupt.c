/*~-1*/
/*~XSF_LANGUAGE: C/C++*/
/*~T*/
/*
   (1) MODULNAME             :  WatchDog_Interrupt.c
   (2) VERSION               :  1.00
   (3) DATUM                 :  11.08.2004

   (4) LETZTE �NDERUNG       :
   (5) PROJEKT (Vers.)       :  MRW Master / MRW Slave
   (6) PROGRAMMIERER         :  MOF
*/


/*~A:1*/
/*~+:Includes*/
/*~T*/
#include "ADuC836.h"
#include "ADuC836Driver.h"
/*~E:A1*/
/*~A:2*/
/*~+:Defines*/
/*~T*/

/*~E:A2*/
/*~A:3*/
/*~+:Funktionsprototypen*/
/*~T*/
// extern void ADuC836_WatchdogReset(void);
/*~E:A3*/
/*~A:4*/
/*~+:Modulvariablen*/
/*~T*/
extern unsigned int g_nWatchDogAddress;		///< Adresse, an der der Watchdog auftrat.
/*~E:A4*/
/*~A:5*/
/*~+:void ADuC836_WatchdogInterrupt() interrupt 11*/
/*~F:6*/
void ADuC836_WatchdogInterrupt() interrupt 11 // using 3
/*~-1*/
{
   /*~A:7*/
   /*~+:Beschreibung*/
   /*~T*/
   /*!
   \fn void ADuC836_WatchdogInterrupt() interrupt 11
   
   <b>Beschreibung:</b><br>
   Watchdog-Interruptfunktion. Diese Funktion wird bei jedem Watchdog ausgef�hrt und ruft ihrerseits die externe Funktion 'Watchdog-Interface()' auf und �bergibt die "Watchdog-Adresse" zur Speicherung. 
   
   \return
   ./.
   
   <b>Zugriff:</b><br>
   [X] �ffentlich / [ ] Privat
   
   \ref
   ExamplePage_ADuC836Driver "Beispiel 'ADuC836-Treiber'"
   */

   /*~E:A7*/
   /*~A:8*/
   /*~+:Variablendeklarationen*/
   /*~T*/

   /*~E:A8*/
   /*~A:9*/
   /*~+:Variableninitialisierungen*/
   /*~T*/

   /*~E:A9*/
   /*~A:10*/
   /*~+:R�cksprungadresse auslesen*/
   /*~T*/
   // R�cksprungadresse auslesen
   /*~T*/
#pragma asm
   /*~T*/
   extrn CODE (ADuC836_WatchdogReset)
   /*~T*/
   mov DPTR,#g_nWatchDogAddress
   /*~T*/
   mov A,SP
   subb A,#13
   mov SP,A
   /*~T*/
   pop ACC
   movx @DPTR,A
   inc DPTR
   pop ACC
   movx @DPTR,A

   /* Daf�r Sorge tragen, dass in die Funktion Reset gesprungen wird*/
   mov  	A,#LOW (ADuC836_WatchdogReset)
   push ACC
   MOV  	A,#HIGH (ADuC836_WatchdogReset)
   push ACC

   /*~T*/
   mov A,SP
   add A,#13
   mov SP,A
   /*~T*/
#pragma endasm
   /*~E:A10*/
   /*~T*/
   // Watchdog zum Debuggen zun�chst mal kurz deaktivieren
   ADuC836_WatchdogEnable(0);
   /*~T*/
   WatchdogInterface(ADuC836_WATCHDOG_WRITEADDRESS,&g_nWatchDogAddress);
   /*~T*/
   // Watchdog nochmals aktivieren, jetzt aber ohne Interrupt

   EA = 0;
   WDWR = 1;

   // Watchdog-Interrupt ausschalten und sofort einen Reset bewirken
   WDCON = 0x82;

   EA = 1;
/*~-1*/
}
/*~E:F6*/
/*~E:A5*/
