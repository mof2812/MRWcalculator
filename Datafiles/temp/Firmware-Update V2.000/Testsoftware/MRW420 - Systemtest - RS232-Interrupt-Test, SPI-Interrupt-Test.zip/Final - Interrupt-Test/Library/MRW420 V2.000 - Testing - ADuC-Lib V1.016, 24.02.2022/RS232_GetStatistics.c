/*~-1*/
/*~XSF_LANGUAGE: C/C++*/
/*~K*/
/*~+:File :        RS232_GetStatistics.c*/
/*~+:*/
/*~+:Version :     V1.0*/
/*~+:*/
/*~+:Date :        12.05.2016*/
/*~+:*/
/*~+:Time :        10:23*/
/*~+:*/
/*~+:Author :      MOF*/
/*~+:*/
/*~+:Hardware :*/
/*~+:*/
/*~+:Description :*/
/*~A:1*/
/*~+:Includes*/
/*~T*/
#include "ADuC836Driver.h"
#include "SPI_Global.h"
#include <string.h>
/*~E:A1*/
/*~A:2*/
/*~+:Funktionseigene Definitionen*/
/*~T*/
#
/*~E:A2*/
/*~A:3*/
/*~+:Funktionseigene Struktur-Definitionen*/
/*~T*/

/*~E:A3*/
/*~A:4*/
/*~+:Funktionsprototypen*/
/*~I:5*/
#ifdef RS232_WITH_STATISTICS
/*~T*/
RS232_STATISTICS_T ADuC836_RS232GetStatistics(void);
/*~-1*/
#endif
/*~E:I5*/
/*~E:A4*/
/*~A:6*/
/*~+:Globale Variablen*/
/*~T*/

/*~E:A6*/
/*~I:7*/
#ifdef RS232_WITH_STATISTICS
/*~A:8*/
/*~+:RS232_STATISTICS_T ADuC836_RS232GetStatistics(void)*/
/*~F:9*/
RS232_STATISTICS_T ADuC836_RS232GetStatistics(void)
/*~-1*/
{
   /*~A:10*/
   /*~+:Beschreibung*/
   /*~K*/
   /*~+:/~* RS232_STATISTICS_T ADuC836_RS232GetStatistics(void)*/
   /*~+: */
   /*~+:Ausgabe der RS232-Kommunikationsstatistik*/
   /*~+:*/
   /*~+:R�ckgaben :		Struktur der statistischen Daten*/
   /*~+:*~/*/
   /*~+:*/
   /*~E:A10*/
   /*~A:11*/
   /*~+:Variablendeklarationen*/
   /*~T*/

   /*~E:A11*/
   /*~A:12*/
   /*~+:Variableninitialisierungen*/
   /*~T*/

   /*~E:A12*/
   /*~T*/
   return RS232.Statistics;
/*~-1*/
}
/*~E:F9*/
/*~E:A8*/
/*~-1*/
#endif
/*~E:I7*/
