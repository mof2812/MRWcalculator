/*~-1*/
/*~XSF_LANGUAGE: C/C++*/
/*~K*/
/*~+:File :        CurrentInterface.c*/
/*~+:*/
/*~+:Version :     V1.0*/
/*~+:*/
/*~+:Date :        17.03.2005*/
/*~+:*/
/*~+:Time :        10:23*/
/*~+:*/
/*~+:Author :      MOF*/
/*~+:*/
/*~+:Hardware :*/
/*~+:*/
/*~+:Description :*/
/*~+:*/
/*~+:*/
/*~A:1*/
/*~+:Includes*/
/*~T*/
#include "CurrentInterface.h"
#include "Diagnosis.h"
#include "Global.h"
#include <math.h>
#include <string.h>
#include <Stdlib.h>
/*~E:A1*/
/*~A:2*/
/*~+:Funktionseigene Definitionen*/
/*~T*/
#define CURRENTINTERFACE_TIMETICS2SEC		100		///< Anzahl der Durchl�ufe pro Sekunde (wird nur f�r die Einstellung der Zeithystere ben�tigt)
/*~E:A2*/
/*~A:3*/
/*~+:Funktionseigene Struktur-Definitionen*/
/*~T*/

/*~E:A3*/
/*~A:4*/
/*~+:Funktionsprototypen*/
/*~T*/
void 			CurrentInterface(long lValue2Convert);
char 			CurrentInterface_Calibration(unsigned char chWhat2Do,float fTrueValue);

char 			CurrentInterface_FeedBack(void);
float 			CurrentInterface_GetCurrent(unsigned char byMode);
char 			CurrentInterface_GetFeedBackIntegralPortion(void);
char 			CurrentInterface_GetFeedBackProportionalPortion(void);
char 			CurrentInterface_GetFeedBackState(void);
unsigned int 	CurrentInterface_GetTimeHysteresis(void);
char 			CurrentInterface_Ini(unsigned char byMode);
void			CurrentInterface_LoadDACSettings(unsigned char chWhat2Load);
void 			CurrentInterface_PrepareCalibration(unsigned char byCalPoint,float fWeight);

void 			CurrentInterface_SaveDACSettings(unsigned char chWhat2Save);
char 			CurrentInterface_SetCalibrationFactorOfFeedBack(float fCalibrationFactor);
void 			CurrentInterface_SetFeedBackOnOff(unsigned char bOnOff,unsigned char bSave);
void 			CurrentInterface_SetFeedBackIntegralPortion(char chIntegralPortion);
void 			CurrentInterface_SetFeedBackProportionalPortion(char chProportionalPortion);
void 			CurrentInterface_SetLimits(long lLowerLimit,long lUpperLimit);
void 			CurrentInterface_SetManualMode(unsigned char byOnOff,long lRatedDACOutput);
void 			CurrentInterface_SetTimeHysteresis(unsigned int uTime);
char			CurrentInterface_SetZeroOfFeedBack(long lZero2Set);
char			CurrentInterface_SetZeroOfFeedBackRegardingActualWeight(void);

/*~E:A4*/
/*~A:5*/
/*~+:Globale Variablen*/
/*~T*/
CURRENT_INTERFACE g_CurrentInterface;
unsigned char byDisableFeedbackCounter = 0;
/*~E:A5*/
/*~K*/
/*~+:*/
/*~A:6*/
/*~+:void 			CurrentInterface(long lValue2Convert)*/
/*~F:7*/
void CurrentInterface(long lValue2Convert)
/*~-1*/
{
   /*~A:8*/
   /*~+:Beschreibung*/
   /*~T*/
   /*!
   \fn void CurrentInterface(long lValue2Convert)
   
   <b>Beschreibung:</b><br>
   Hauptfunktion zur Stromschnittstelle. Diese ruft die Wandlungsroutine des DACs auf und gibt den Nullpunkt korrigierten Rohmesswert aus.
   
   \param
   lValue2Convert: zu wandelnder Wert.
   
   \return
   ./.
   
   <b>Zugriff:</b><br>
   [X] �ffentlich / [ ] Privat
   */

   /*~E:A8*/
   /*~A:9*/
   /*~+:Variablendeklarationen*/
   /*~T*/
   static long lLastConverted = 0;
   static float fLastConverted = 0;
   float 		fDeviation;
   /*~E:A9*/
   /*~A:10*/
   /*~+:Variableninitialisierungen*/
   /*~T*/

   /*~E:A10*/
   /*~A:11*/
   /*~+:FOR_DEBUGGING_ONLY*/
   /*~I:12*/
#ifdef FOR_DEBUGGING_ONLY
   /*~I:13*/
#ifdef CHANNEL_1
   /*~T*/
   Communication_SendString(COMMUNICATION_RS232,"Value2Convert = ",0,0);
   Communication_SendLong(COMMUNICATION_RS232,0,lValue2Convert,0,1);
   /*~-1*/
#endif
   /*~E:I13*/
   /*~-1*/
#endif
   /*~E:I12*/
   /*~E:A11*/
   /*~I:14*/
#ifdef MIT_SYSTEMFEHLER_BEI_PARTNER_SYSTEMFEHLER

   if (((SYSTEMSTATE != SYSTEM_ERROR)&&(SYSTEMSTATE_PARTNER != SYSTEM_ERROR))||(g_CurrentInterface.byAdjustCurrentInterface))

#else

   if ((SYSTEMSTATE != SYSTEM_ERROR)||(g_CurrentInterface.byAdjustCurrentInterface))

#endif

   /*~-1*/
   {
      /*~A:15*/
      /*~+:Stromausgang bei Abgleich der Stromschnittstelle freigeben*/
      /*~I:16*/
      if (ADuC836_DACIsOutputCleared())
      /*~-1*/
      {
         /*~T*/
         // Stromausgang freigeben
         ADuC836_DACClearOutput(0);

         // Korrekturwert der Stromregelung zur�cksetzen
         ADuC836_DACClearCurrentDeviation();
         /*~T*/
         // Stromr�ckf�hrung das n�chste mal �bergehen

         byDisableFeedbackCounter = 1;
      /*~-1*/
      }
      /*~E:I16*/
      /*~E:A15*/
      /*~I:17*/
      if (g_CurrentInterface.byAdjustCurrentInterface == 1)
      /*~-1*/
      {
         /*~T*/
         lValue2Convert = g_CurrentInterface.lRMWForCalibration[0];
      /*~-1*/
      }
      /*~O:I17*/
      /*~-2*/
      else
      {
         /*~I:18*/
         if (g_CurrentInterface.byAdjustCurrentInterface == 2)
         /*~-1*/
         {
            /*~T*/
            lValue2Convert = g_CurrentInterface.lRMWForCalibration[1];
         /*~-1*/
         }
         /*~E:I18*/
      /*~-1*/
      }
      /*~E:I17*/
      /*~A:19*/
      /*~+:Wandlung und Grenzwert�berwachung*/
      /*~I:20*/
      if (!DAC_TESTMODE)
      /*~-1*/
      {
         /*~T*/
         g_CurrentInterface.DAC.lRatedDACOutput = lValue2Convert;
         /*~I:21*/
#ifndef OHNE_STROMRUECKFUEHRUNG
         /*~I:22*/
         if (ADuC836_DACGetCurrentDeviationCorrectionState())
         /*~-1*/
         {
            /*~T*/
            // R�ckkopplung
            CurrentInterface_FeedBack(); 
         /*~-1*/
         }
         /*~O:I22*/
         /*~-2*/
         else
         {
            /*~T*/
            // Sollwert auslesen
            //            fRated = ADuC836_DACGetLastConvertedCurrent(); 
            /*~T*/
            fDeviation = lValue2Convert - lLastConverted;
            /*~T*/
            // Regelgr��e bestimmen
            lLastConverted = (long)(fDeviation * (g_CurrentInterface.FeedBack.chProportionalPortion * 0.01) + fDeviation * (1 - (float)g_CurrentInterface.FeedBack.chProportionalPortion * 0.01) * (float)g_CurrentInterface.FeedBack.chIntegralPortion * 0.01);
            /*~T*/
            // ohne R�ckkopplung
            g_CurrentInterface.byConversionState = ADuC836_DACConvert(&lLastConverted,0);
            /*~A:23*/
            /*~+:FOR_DEBUGGING_ONLY*/
            /*~I:24*/
#ifdef FOR_DEBUGGING_ONLY
            /*~T*/
            Communication_SendString(COMMUNICATION_RS232,"DAC-Value (Soll) = ",0,0);
            Communication_SendLong(COMMUNICATION_RS232,0,lValue2Convert,0,1);
            /*~T*/
            Communication_SendString(COMMUNICATION_RS232,"DAC-Value = ",0,0);
            Communication_SendLong(COMMUNICATION_RS232,0,lLastConverted,0,1);
            /*~T*/
            Communication_SendString(COMMUNICATION_RS232,"DAC-Value[mA] = ",0,0);
            Communication_SendFloat(COMMUNICATION_RS232,0,fLastConverted,2,0,1);
            /*~-1*/
#endif
            /*~E:I24*/
            /*~E:A23*/
         /*~-1*/
         }
         /*~E:I22*/
         /*~O:I21*/
         /*~-1*/
#else
         /*~T*/
         fDeviation = lValue2Convert - lLastConverted;
         /*~T*/
         // Regelgr��e bestimmen
         lLastConverted = (long)(fDeviation * (g_CurrentInterface.FeedBack.chProportionalPortion * 0.01) + fDeviation * (1 - (float)g_CurrentInterface.FeedBack.chProportionalPortion * 0.01) * (float)g_CurrentInterface.FeedBack.chIntegralPortion * 0.01);
         /*~T*/
         // ohne R�ckkopplung
         g_CurrentInterface.byConversionState = ADuC836_DACConvert(&lLastConverted,0);
         /*~-1*/
#endif
         /*~E:I21*/
         /*~I:25*/
         if (g_CurrentInterface.byConversionState & 0x06)
         /*~-1*/
         {
            /*~T*/
            // unterer Grenzwert unterschritten

            Limit_SetLimitState(LIMIT_HANGINGLIMT_EXCEEDED);
         /*~-1*/
         }
         /*~E:I25*/
         /*~I:26*/
         if (g_CurrentInterface.byConversionState & 0x60)
         /*~-1*/
         {
            /*~T*/
            // oberer Grenzwert �berschritten

            Limit_SetLimitState(LIMIT_ALARMLIMIT_EXCEEDED);
            /*~T*/
            ADuC836_DACClearOutput(1);
         /*~-1*/
         }
         /*~O:I26*/
         /*~-2*/
         else
         {
            /*~I:27*/
            if (g_CurrentInterface.byLastConversionState & 0x60)
            /*~-1*/
            {
               /*~T*/
               // Wenn zuletzt eine �berlast anlag, den DAC-Ausgang wieder freigeben
               ADuC836_DACClearOutput(0);
            /*~-1*/
            }
            /*~E:I27*/
         /*~-1*/
         }
         /*~E:I26*/
         /*~I:28*/
         if (!g_CurrentInterface.byConversionState)
         /*~-1*/
         {
            /*~T*/
            // kein Grenzwert erreicht

            // Digital_SetLED(DIGITAL_LED_ST_OUT,DIGITAL_OFF);
            Limit_ClearLimitState(LIMIT_HANGINGLIMT_EXCEEDED | LIMIT_ALARMLIMIT_EXCEEDED);

         /*~-1*/
         }
         /*~E:I28*/
         /*~T*/
         g_CurrentInterface.byLastConversionState = g_CurrentInterface.byConversionState;
      /*~-1*/
      }
      /*~O:I20*/
      /*~-2*/
      else
      {
         /*~T*/
         lValue2Convert = g_CurrentInterface.DAC.lRatedDACOutput;
         /*~T*/
         g_CurrentInterface.byConversionState = ADuC836_DACConvert(&lValue2Convert,0);
      /*~-1*/
      }
      /*~E:I20*/
      /*~E:A19*/
   /*~-1*/
   }
   /*~O:I14*/
   /*~-2*/
   else
   {
      /*~T*/
      // System-Fehler - Stromausgang l�schen

      ADuC836_DACClearOutput(1);
      /*~I:29*/
#ifndef OHNE_STROMRUECKFUEHRUNG
      /*~T*/
      // R�ckkopplung
      CurrentInterface_FeedBack(); 
      /*~-1*/
#endif
      /*~E:I29*/
   /*~-1*/
   }
   /*~E:I14*/
/*~-1*/
}
/*~E:F7*/
/*~E:A6*/
/*~A:30*/
/*~+:char 			CurrentInterface_Calibration(unsigned char chWhat2Do,float fTrueValue)*/
/*~F:31*/
char CurrentInterface_Calibration(unsigned char chWhat2Do,float fTrueValue)
/*~-1*/
{
   /*~A:32*/
   /*~+:Beschreibung*/
   /*~T*/
   /*!
   \fn void CurrentInterface_Calibration(unsigned char chWhat2Do,float fTrueValue, float fDesiredValue)
   
   <b>Beschreibung:</b><br>
   Kalibrierung/Normierung der Stromschnittstelle. Diese l�uft in der Regel in mehreren Schritten ab. Zun�chst werden zwei Punkte angefahren und bei dem Aufruf dieser Funktion jeweils Ist- und Sollwert des Stromausgangs �bergeben. Anschlie�end wird diese Funktion mit der Aufforderung zur Berechnung der Kalibrier-/Normierwerte aufgerufen.
   
   \param
   chWhat2Do: 
   \param
   CURRENTINTERFACE_SETPOINT_0 bzw. 0 = Setzen des Ist- und Sollwertes am ersten Kalibrierpunkt.
   \param
   CURRENTINTERFACE_SETPOINT_1 bzw. 1 = Setzen des Ist- und Sollwertes am zweiten Kalibrierpunkt. 
   \param
   CURRENTINTERFACE_CALIBRATE bzw.2 = Berechnung der Kalibrier-/Normierwerte.
   \param
   \param
   fTrueValue: Istwert
   
   \param
   fDesiredValue: Sollwert
   
   \retval
   0: Alles okay.
   \retval
   2: ertser Wert wurde noch nicht erfasst.
   
   <b>Zugriff:</b><br>
   [X] �ffentlich / [ ] Privat
   */

   /*~E:A32*/
   /*~A:33*/
   /*~+:Variablendeklarationen*/
   /*~I:34*/
#ifndef OHNE_STROMRUECKFUEHRUNG 
   /*~T*/
   float fGain;
   float fOffset;
   /*~-1*/
#endif
   /*~E:I34*/
   /*~E:A33*/
   /*~A:35*/
   /*~+:Variableninitialisierungen*/
   /*~T*/

   /*~E:A35*/
   /*~I:36*/
   if (!chWhat2Do)
   /*~-1*/
   {
      /*~T*/
      // 4mA
      ADuC836_DACCalibrationSetPoint(chWhat2Do,fTrueValue,4);
   /*~-1*/
   }
   /*~O:I36*/
   /*~-2*/
   else
   {
      /*~T*/
      // 20mA
      ADuC836_DACCalibrationSetPoint(chWhat2Do,fTrueValue,20);
   /*~-1*/
   }
   /*~E:I36*/
   /*~I:37*/
   // R�ckkoplung-Kalibrierpunkte setzen
   if (!chWhat2Do)
   /*~-1*/
   {
      /*~T*/
      g_CurrentInterface.lCalPointFeedBack_RMW[0] = g_CurrentInterface.FeedBack.Results.FilteredMeasurementFromADC.nLong;

      g_CurrentInterface.fCalPointFeedBack_Actual[0] = fTrueValue;
   /*~-1*/
   }
   /*~O:I37*/
   /*~-2*/
   else
   {
      /*~I:38*/
#ifndef OHNE_STROMRUECKFUEHRUNG
      /*~T*/
      g_CurrentInterface.lCalPointFeedBack_RMW[1] = g_CurrentInterface.FeedBack.Results.FilteredMeasurementFromADC.nLong;

      g_CurrentInterface.fCalPointFeedBack_Actual[1] = fTrueValue;
      /*~I:39*/
      if (g_CurrentInterface.lCalPointFeedBack_RMW[0] == 0x80000000)
      /*~-1*/
      {
         /*~T*/
         // ertser Wert wurde noch nicht erfasst
         return 2;
      /*~-1*/
      }
      /*~O:I39*/
      /*~-2*/
      else
      {
         /*~T*/
         // Verst�rkung und Offset berechnen

         fGain = (g_CurrentInterface.lCalPointFeedBack_RMW[1] - g_CurrentInterface.lCalPointFeedBack_RMW[0]) / (g_CurrentInterface.fCalPointFeedBack_Actual[1] - g_CurrentInterface.fCalPointFeedBack_Actual[0]);

         fOffset = g_CurrentInterface.lCalPointFeedBack_RMW[1] - fGain * g_CurrentInterface.fCalPointFeedBack_Actual[1];

         /*~T*/
         // Verst�rkung setzen
         CurrentInterface_SetCalibrationFactorOfFeedBack(1/fGain);

         // neuen Nullpunkt setzen
         CurrentInterface_SetZeroOfFeedBack((long)fOffset);
      /*~-1*/
      }
      /*~E:I39*/
      /*~-1*/
#endif
      /*~E:I38*/
   /*~-1*/
   }
   /*~E:I37*/
   /*~T*/
   return 0;
/*~-1*/
}
/*~E:F31*/
/*~E:A30*/
/*~A:40*/
/*~+:char 			CurrentInterface_FeedBack(void)*/
/*~F:41*/
char CurrentInterface_FeedBack(void)
/*~-1*/
{
   /*~A:42*/
   /*~+:Variablendeklarationen*/
   /*~T*/
   float fRated;
   float fDeviation;
   float fIntegralPortion;
   long lValue2Convert;
   MEASUREMENT_VALUE ActualRMW_Current;
   /*~E:A42*/
   /*~A:43*/
   /*~+:Variableninitialisierungen*/
   /*~T*/

   /*~E:A43*/
   /*~I:44*/
   // Liegt ein neuer gewandelter Rohmesswert vor ?
   if (ADuC836_ADCIsNewConversionValue(ADuC836_ADC_PRIMARY_TOGGLE))
   /*~-1*/
   {
      /*~K*/
      /*~+:// Ja*/
      /*~+:*/
      /*~A:45*/
      /*~+:R�ckkopplung des Stromausgangs auswerten*/
      /*~T*/
      // R�ckkopplung des Stromausgangs
      /*~T*/
      // Roh-Messwert vom ADC holen
      ActualRMW_Current.nLong = ADuC836_ADCGetConversionValue(ADuC836_ADC_PRIMARY_TOGGLE,0);
      /*~T*/
      // Communication_SendLong(COMMUNICATION_RS232,TEXT_CURRENT_INTERFACE_ACTUAL_CURRENT_CHANNEL_0,ActualRMW_Current.nLong,1,0);
      /*~T*/
      g_CurrentInterface.FeedBack.Results.FilteredMeasurementFromADC = ActualRMW_Current;

      // Nullpunktverrechnung
      Measurement_Processing(CURRENTINTERFACE_FEEDBACKCHANEL,CURRENTINTERFACE_FEEDBACKCHANEL,&ActualRMW_Current);
      //            g_CurrentInterface.FeedBack.Results.ZeroCorrectedMeasurement = Measurement;

      // Normierung
      Measurement_Processing(MEASUREMENT_PROCESSING_STANDARDIZATION,CURRENTINTERFACE_FEEDBACKCHANEL,&ActualRMW_Current);
      /*~A:46*/
      /*~+:ggf. Ist-Sollwert-Abweichung simulieren */
      /*~I:47*/
#ifdef MIT_STROM_ABWEICHUNGSSIMULATION
      /*~T*/
      ActualRMW_Current.fFloat+= g_CurrentInterface.FeedBack.fSimulatedDerivation;
      /*~-1*/
#endif
      /*~E:I47*/
      /*~E:A46*/
      /*~T*/
      g_CurrentInterface.FeedBack.Results.CalibratedMeasurement.fFloat = ActualRMW_Current.fFloat;

      // Motion-�berpr�fung
      Measurement_Processing(MEASUREMENT_PROCESSING_MOTION,CURRENTINTERFACE_FEEDBACKCHANEL,&ActualRMW_Current);

      // Flag f�r neuen Messwert setzen
      g_CurrentInterface.FeedBack.Results.byNewMeasurement = 1;

      /*~E:A45*/
      /*~I:48*/
      if (!byDisableFeedbackCounter)
      /*~-1*/
      {
         /*~I:49*/
         if (!(Limit_GetLimitState() & LIMIT_ALARMLIMIT_EXCEEDED)&& (SYSTEMSTATE != SYSTEM_ERROR) && (SYSTEMSTATE_PARTNER != SYSTEM_ERROR)/* && (SYSTEMSTATE != SYSTEM_ERROR_CURRENT_DEVIATION)*/)
         /*~-1*/
         {
            /*~T*/
            // Es liegt keine Messwertbewegung vor
            /*~T*/
            // Sollwert auslesen
            fRated = ADuC836_DACGetLastConvertedCurrent(); 
            /*~T*/
            // Abweichung = Sollwert - Istwert;
            g_CurrentInterface.FeedBack.Results.Deviation.fFloat = fDeviation = fRated - ActualRMW_Current.fFloat;
            /*~I:50*/
            if (ADuC836_DACGetCurrentDeviationCorrectionState())
            /*~-1*/
            {
               /*~T*/
               // Stromr�ckf�hrung ist eingeschaltet
               /*~A:51*/
               /*~+:Abweichung zu gro� ?*/
               /*~I:52*/
               if (fabs(fDeviation) > g_CurrentInterface.FeedBack.fMaxDeviation)	// Abweichung zu gro�
               /*~-1*/
               {
                  /*~I:53*/
#ifdef MIT_SICHERHEITSALARM_FUNKTION

                  if (g_CurrentInterface.FeedBack.byMaxDeviationCounter > 20)

#else 

                  if ((g_CurrentInterface.FeedBack.byMaxDeviationCounter > 20)||(SYSTEMSTATE != SYSTEM_ERROR_CURRENT_DEVIATION))

#endif
                  /*~-1*/
                  {
                     /*~I:54*/
#ifndef SPEZIALVERSION_FUER_TESTSYSTEME 
                     /*~I:55*/
#ifdef MIT_SICHERHEITSALARM_FUNKTION 
                     /*~A:56*/
                     /*~+:Abweichung mehrmals hintereinander zu hoch*/
                     /*~T*/
                     // Sicherheitsfunktion aufrufen
                     Diagnosis_SecurityCurrentInterface(CURRENT_DEVIATION);
                     /*~T*/
                     // Korrekturwert auf 0 setzen
                     ADuC836_DACSetCurrentDeviation(0);
                     /*~T*/
                     Limit_SetLimitState(SYSTEM_ERROR_CURRENT_DEVIATION);
                     /*~E:A56*/
                     /*~O:I55*/
                     /*~-1*/
#else
                     /*~A:57*/
                     /*~+:Abweichung mehrmals hintereinander zu hoch*/
                     /*~T*/
                     // Korrekturwert auf 0 setzen
                     ADuC836_DACSetCurrentDeviation(0);
                     /*~T*/
                     Limit_SetLimitState(SYSTEM_ERROR_CURRENT_DEVIATION);
                     /*~E:A57*/
                     /*~-1*/
#endif
                     /*~E:I55*/
                     /*~-1*/
#endif
                     /*~E:I54*/
                     /*~T*/
                     // Flag f�r neue ermittelte R�ckkoppelspannung l�schen
                     g_CurrentInterface.FeedBack.Results.byNewMeasurement = 0;
                     /*~T*/
                     // Ausstieg
                     return 0;
                  /*~-1*/
                  }
                  /*~O:I53*/
                  /*~-2*/
                  else
                  {
                     /*~T*/
                     g_CurrentInterface.FeedBack.byMaxDeviationCounter++;
                  /*~-1*/
                  }
                  /*~E:I53*/
               /*~-1*/
               }
               /*~O:I52*/
               /*~-2*/
               else
               {
                  /*~A:58*/
                  /*~+:Abweichung nicht gr��er als ein vorgegebener Grenzwert*/
                  /*~T*/
                  g_CurrentInterface.FeedBack.byMaxDeviationCounter = 0;
                  /*~E:A58*/
                  /*~I:59*/
#ifndef MIT_SICHERHEITSALARM_FUNKTION 
                  /*~T*/
                  Limit_ClearLimitState(SYSTEM_ERROR_CURRENT_DEVIATION);
                  /*~-1*/
#endif
                  /*~E:I59*/
               /*~-1*/
               }
               /*~E:I52*/
               /*~E:A51*/
               /*~T*/
               // Regelgr��e bestimmen
               fIntegralPortion = g_CurrentInterface.FeedBack.chIntegralPortion;

               fDeviation = fDeviation * ((float)g_CurrentInterface.FeedBack.chProportionalPortion * 0.01) + fDeviation * (1 - (float)g_CurrentInterface.FeedBack.chProportionalPortion * 0.01) * fIntegralPortion * 0.01;
               /*~A:60*/
               /*~+:FOR_DEBUGGING_ONLY*/
               /*~I:61*/
#ifdef FOR_DEBUGGING_ONLY
               /*~T*/
               Communication_SendString(COMMUNICATION_RS232,"Korrektur = ",0,0);
               Communication_SendFloat(COMMUNICATION_RS232,0,fDeviation,2,0,1);
               /*~-1*/
#endif
               /*~E:I61*/
               /*~E:A60*/
               /*~T*/
               // Regelabweichung setzen
               ADuC836_DACSetCurrentDeviation(fDeviation);

               /*~A:62*/
               /*~+:FOR_DEBUGGING_ONLY*/
               /*~I:63*/
#ifdef FOR_DEBUGGING_ONLY
               /*~T*/
               Communication_SendString(COMMUNICATION_RS232,"DAC-Value (Soll) = ",0,0);
               Communication_SendLong(COMMUNICATION_RS232,0,lValue2Convert,0,1);
               /*~T*/
               Communication_SendString(COMMUNICATION_RS232,"DAC-Value = ",0,0);
               Communication_SendFloat(COMMUNICATION_RS232,0,fDeviation,2,0,1);
               /*~-1*/
#endif
               /*~E:I63*/
               /*~E:A62*/
            /*~-1*/
            }
            /*~O:I50*/
            /*~-2*/
            else
            {
               /*~T*/
               // Stromr�ckf�hrung ist ausgeschaltet
               /*~T*/
               // Regelabweichung setzen
               ADuC836_DACSetCurrentDeviation(fRated);

            /*~-1*/
            }
            /*~E:I50*/
            /*~T*/
            // Analog-Ausgang aktualisieren
            lValue2Convert = g_CurrentInterface.DAC.lRatedDACOutput;

            // g_CurrentInterface.byConversionState = ADuC836_DACConvert(&lValue2Convert,0);

            g_CurrentInterface.byConversionState = ADuC836_DACConvertByOutputCurrent(fDeviation);
            /*~A:64*/
            /*~+:FOR_DEBUGGING_ONLY*/
            /*~I:65*/
#ifdef FOR_DEBUGGING_ONLY
            /*~I:66*/
#ifdef CHANNEL_1
            /*~T*/

            /*~-1*/
#endif
            /*~E:I66*/
            /*~-1*/
#endif
            /*~E:I65*/
            /*~T*/
            Communication_SendString(COMMUNICATION_RS232,"FB-Value2Convert = ",0,0);
            Communication_SendLong(COMMUNICATION_RS232,0,lValue2Convert,0,1);
            Communication_SendString(COMMUNICATION_RS232,"FB-Value2Convert(mA) = ",0,0);
            Communication_SendFloat(COMMUNICATION_RS232,0,fDeviation,2,0,1);
            /*~E:A64*/
         /*~-1*/
         }
         /*~O:I49*/
         /*~-2*/
         else
         {
            /*~T*/
            g_CurrentInterface.FeedBack.Results.CalibratedMeasurement.fFloat = 0;
         /*~-1*/
         }
         /*~E:I49*/
      /*~-1*/
      }
      /*~O:I48*/
      /*~-2*/
      else
      {
         /*~T*/
         byDisableFeedbackCounter--;
      /*~-1*/
      }
      /*~E:I48*/
      /*~T*/
      // Flag f�r neue ermittelte R�ckkoppelspannung l�schen
      g_CurrentInterface.FeedBack.Results.byNewMeasurement = 0;
      /*~T*/
      return 0;
   /*~-1*/
   }
   /*~O:I44*/
   /*~-2*/
   else
   {
      /*~T*/
      return 1;
   /*~-1*/
   }
   /*~E:I44*/
/*~-1*/
}
/*~E:F41*/
/*~E:A40*/
/*~A:67*/
/*~+:float 			CurrentInterface_GetCurrent(unsigned char byMode)*/
/*~F:68*/
float CurrentInterface_GetCurrent(unsigned char byMode)
/*~-1*/
{
   /*~T*/
   // return ADuC836_ADCGetConversionValue(ADuC836_ADC_AUXILIARY_TOGGLE,1);

   /*~I:69*/
   if (byMode)
   /*~-1*/
   {
      /*~T*/
      return g_CurrentInterface.FeedBack.Results.CalibratedMeasurement.fFloat; 
   /*~-1*/
   }
   /*~O:I69*/
   /*~-2*/
   else
   {
      /*~T*/
      return ADuC836_DACGetLastConvertedCurrent();
   /*~-1*/
   }
   /*~E:I69*/
/*~-1*/
}
/*~E:F68*/
/*~E:A67*/
/*~A:70*/
/*~+:char 			CurrentInterface_GetFeedBackIntegralPortion(void)*/
/*~F:71*/
char CurrentInterface_GetFeedBackIntegralPortion(void)
/*~-1*/
{
   /*~T*/
   return g_CurrentInterface.FeedBack.chIntegralPortion;
/*~-1*/
}
/*~E:F71*/
/*~E:A70*/
/*~A:72*/
/*~+:char 			CurrentInterface_GetFeedBackProportionalPortion(void)*/
/*~F:73*/
char CurrentInterface_GetFeedBackProportionalPortion(void)
/*~-1*/
{
   /*~T*/
   return g_CurrentInterface.FeedBack.chProportionalPortion;
/*~-1*/
}
/*~E:F73*/
/*~E:A72*/
/*~A:74*/
/*~+:char 			CurrentInterface_GetFeedBackState(void)*/
/*~F:75*/
char CurrentInterface_GetFeedBackState(void)
/*~-1*/
{
   /*~T*/
   return ADuC836_DACGetCurrentDeviationCorrectionState();
/*~-1*/
}
/*~E:F75*/
/*~E:A74*/
/*~A:76*/
/*~+:unsigned int 	CurrentInterface_GetTimeHysteresis(void)*/
/*~F:77*/
unsigned int CurrentInterface_GetTimeHysteresis(void)
/*~-1*/
{
   /*~T*/
   return ADuC836_DACGetLimitHysteresis(ADUC836_DAC_UPPER_LIMIT) / CURRENTINTERFACE_TIMETICS2SEC;
/*~-1*/
}
/*~E:F77*/
/*~E:A76*/
/*~A:78*/
/*~+:char 			CurrentInterface_Ini(unsigned char byMode)*/
/*~F:79*/
char CurrentInterface_Ini(unsigned char byMode)
/*~-1*/
{
   /*~A:80*/
   /*~+:Beschreibung*/
   /*~T*/
   /*!
   \fn void CurrentInterface_Ini(unsigned char byMode)
   
   <b>Beschreibung:</b><br>
   Initialisierung der Stromschnittstelle.
   
   \param
   byMode:
   \param
   0 = Initialisierung der Stromschnittstelle mit Defaultwerten.
   \param
   1 = Initialisierung mit den abgespeicherten Werten.  
   \param
   2 = Initialisierung der Stromschnittstelle mit Defaultwerten.Diese werden zus�tzlich abgespeichert und stehen auch beim n�chsten Systemstart zur Verf�gung.
   
   \return
   ./.
   
   <b>Zugriff:</b><br>
   [X] �ffentlich / [ ] Privat
   */
   /*~E:A80*/
   /*~A:81*/
   /*~+:Variablendeklarationen*/
   /*~T*/
   unsigned char 			chDACLimitStatus;
   /*~E:A81*/
   /*~A:82*/
   /*~+:Variableninitialisierungen*/
   /*~T*/
   g_CurrentInterface.lCalPointFeedBack_RMW[0] = 0x80000000L;

   g_CurrentInterface.FeedBack.fSimulatedDerivation = 0;
   g_CurrentInterface.byAdjustCurrentInterface = 0;

   g_CurrentInterface.byLastConversionState = 0;
   /*~E:A82*/
   /*~A:83*/
   /*~+:DAC initialsieren*/
   /*~T*/
   // DAC initialsieren
   ADuC836_DACIni(ADUC836_DAC_OUTPUTPIN_3,ADUC836_DAC_RESOLUTION_12BIT,ADUC836_DAC_RANGE_2_REF,ADUC836_DAC_ENABLE);
   /*~E:A83*/
   /*~C:84*/
   switch (byMode)
   /*~-1*/
   {
      /*~F:85*/
      case 0:		// Initialisierung mit Defaultwerten
      /*~-1*/
      {
         /*~T*/
         // Default-Offset und Default-Verst�runksfaktor setzen

         /*~I:86*/
#ifndef SPEZIALVERSION_FUER_TESTSYSTEME 
         /*~T*/
         ADuC836_DACSetOffset(0,700);
         /*~I:87*/
         if (g_SystemControl.byLoadCellType < 2)
         /*~-1*/
         {
            /*~T*/
            ADuC836_DACSetGain(0.3);

         /*~-1*/
         }
         /*~O:I87*/
         /*~-2*/
         else
         {
            /*~T*/
            ADuC836_DACSetGain(1.5);

         /*~-1*/
         }
         /*~E:I87*/
         /*~T*/
         // Grenzwert�berwachung
         ADuC836_DACEnableLimit(ADUC836_DAC_LOWER_LIMIT,0);
         ADuC836_DACEnableLimit(ADUC836_DAC_UPPER_LIMIT,0);
         chDACLimitStatus = ADuC836_DACGetLimitState(255);

         // Kalibrierpunkte l�schen
         ADuC836_DACCalibrationClearPoints();

         // Zeithysterese bei Grenzwert�berschreitung
         ADuC836_DACSetLimitHysteresis(ADUC836_DAC_LOWER_LIMIT,0);	// 0 Sekunden

         /*~T*/
         ADuC836_DACSetLimitHysteresis(ADUC836_DAC_UPPER_LIMIT,1);	// in 10ms, alter Wert 400
         /*~T*/
         // Stromr�ckkopplung ausschalten
         CurrentInterface_SetFeedBackOnOff(0,0);
         /*~T*/
         // Integralanteil der Stromregelung auf 50%
         CurrentInterface_SetFeedBackIntegralPortion(50);

         /*~T*/
         // Proportionalanteil der Stromregelung auf 50%
         CurrentInterface_SetFeedBackProportionalPortion(50);

         /*~T*/
         // DAC-Settings speichern
         CurrentInterface_SaveDACSettings(CURRENTINTERFACE_ALL_SETTINGS);
         /*~I:88*/
#ifndef OHNE_STROMRUECKFUEHRUNG
         /*~A:89*/
         /*~+:Parameter f�r R�ckkoppelzweig*/
         /*~T*/
         // Verst�rkung setzen
         CurrentInterface_SetCalibrationFactorOfFeedBack(0.000707);

         // neuen Nullpunkt setzen
         CurrentInterface_SetZeroOfFeedBack(0);


         /*~I:90*/
#ifdef MIT_UEBERWACHUNG_SOLL_ISTSTROM_ABWEICHUNG
         /*~T*/
         // maximal zul�ssige Soll-Istwert-Abweichung auf 2mA
         g_CurrentInterface.FeedBack.fMaxDeviation = 2;

         /*~O:I90*/
         /*~-1*/
#else
         /*~T*/
         // maximal zul�ssige Soll-Istwert-Abweichung auf 50mA (= Abschaltung)
         g_CurrentInterface.FeedBack.fMaxDeviation = 50;

         /*~-1*/
#endif
         /*~E:I90*/
         /*~T*/
         // und speichern
         CurrentInterface_SaveDACSettings(CURRENTINTERFACE_MAXDEVIATION_FEEDBACK);

         /*~E:A89*/
         /*~-1*/
#endif
         /*~E:I88*/
         /*~O:I86*/
         /*~-1*/
#else
         /*~A:91*/
         /*~+:Spezialsoftware f�r Testsysteme*/
         /*~T*/
         ADuC836_DACSetOffset(0,0);
         /*~T*/
         ADuC836_DACSetGain(0.175);

         /*~T*/
         // Grenzwert�berwachung
         ADuC836_DACEnableLimit(ADUC836_DAC_LOWER_LIMIT,0);
         ADuC836_DACEnableLimit(ADUC836_DAC_UPPER_LIMIT,0);
         chDACLimitStatus = ADuC836_DACGetLimitState(255);

         // Kalibrierpunkte l�schen
         ADuC836_DACCalibrationClearPoints();

         // Zeithysterese bei Grenzwert�berschreitung
         ADuC836_DACSetLimitHysteresis(ADUC836_DAC_LOWER_LIMIT,0);	// 0 Sekunden

         /*~T*/
         ADuC836_DACSetLimitHysteresis(ADUC836_DAC_UPPER_LIMIT,1);	// in 10ms, alter Wert 400
         /*~T*/
         // Stromr�ckkopplung ausschalten
         CurrentInterface_SetFeedBackOnOff(0,0);
         /*~T*/
         // Integralanteil der Stromregelung auf 50%
         CurrentInterface_SetFeedBackIntegralPortion(50);

         /*~T*/
         // DAC-Settings speichern
         CurrentInterface_SaveDACSettings(CURRENTINTERFACE_ALL_SETTINGS);
         /*~I:92*/
#ifndef OHNE_STROMRUECKFUEHRUNG
         /*~A:93*/
         /*~+:Parameter f�r R�ckkoppelzweig*/
         /*~T*/
         // Verst�rkung setzen
         CurrentInterface_SetCalibrationFactorOfFeedBack(0.000707);

         // neuen Nullpunkt setzen
         CurrentInterface_SetZeroOfFeedBack(0);


         /*~I:94*/
         /*#LJ:0=1*/
#ifdef MIT_UEBERWACHUNG_SOLL_ISTSTROM_ABWEICHUNG
         /*~T*/
         // maximal zul�ssige Soll-Istwert-Abweichung auf 2mA
         g_CurrentInterface.FeedBack.fMaxDeviation = 2;

         /*~O:I94*/
         /*~-1*/
#else
         /*~T*/
         // maximal zul�ssige Soll-Istwert-Abweichung auf 50mA (= Abschaltung)
         g_CurrentInterface.FeedBack.fMaxDeviation = 50;

         /*~-1*/
#endif
         /*~E:I94*/
         /*~T*/
         // und speichern
         CurrentInterface_SaveDACSettings(CURRENTINTERFACE_MAXDEVIATION_FEEDBACK);

         /*~E:A93*/
         /*~-1*/
#endif
         /*~E:I92*/
         /*~E:A91*/
         /*~-1*/
#endif
         /*~E:I86*/
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F85*/
      /*~F:95*/
      case 1:		// Initialisierung mit abgespeicherten Werten
      /*~-1*/
      {
         /*~T*/
         CurrentInterface_LoadDACSettings(CURRENTINTERFACE_ALL_SETTINGS);
         /*~I:96*/
#ifndef OHNE_STROMRUECKFUEHRUNG
         /*~A:97*/
         /*~+:Parameter f�r R�ckkoppelzweig*/
         /*~T*/
         // Messwertoffset setzen
         CurrentInterface_LoadDACSettings(CURRENTINTERFACE_OFFSET_FEEDBACK);
         // Messwert-Kalibrierwert setzen
         CurrentInterface_LoadDACSettings(CURRENTINTERFACE_GAIN_FEEDBACK);
         // maximal zul�ssige Soll-Istwert-Abweichung
         CurrentInterface_LoadDACSettings(CURRENTINTERFACE_MAXDEVIATION_FEEDBACK);
         // Integral-Anteil der Stromregelung
         CurrentInterface_LoadDACSettings(CURRENTINTERFACE_INTEGRALPORTION_FEEDBACK);
         // Integral-Anteil der Stromregelung
         CurrentInterface_LoadDACSettings(CURRENTINTERFACE_PROPORTIONALPORTION_FEEDBACK);
         /*~E:A97*/
         /*~-1*/
#endif
         /*~E:I96*/
         /*~T*/
         // Parameter zur R�ckrechnung des Gewichts vom Ausgangsstrom laden
         CurrentInterface_LoadDACSettings(CURRENTINTERFACE_WEIGHTCALCULATION);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F95*/
      /*~O:C84*/
      /*~-2*/
      default:
      {
         /*~T*/
         return 1;
      /*~-1*/
      }
   /*~-1*/
   }
   /*~E:C84*/
   /*~T*/
   return 0;
/*~-1*/
}
/*~E:F79*/
/*~E:A78*/
/*~A:98*/
/*~+:void 			CurrentInterface_LoadDACSettings(unsigned char chWhat2Load)*/
/*~F:99*/
void CurrentInterface_LoadDACSettings(unsigned char chWhat2Load)
/*~-1*/
{
   /*~A:100*/
   /*~+:Beschreibung*/
   /*~T*/
   /*!
   \fn void CurrentInterface_LoadDACSettings(void)
   
   <b>Beschreibung:</b><br>
   Speicherung aller Stromschnittstellenparameter.
   
   \param
   void:
   
   \return
   ./.
   
   <b>Zugriff:</b><br>
   [X] �ffentlich / [ ] Privat
   */
   /*~E:A100*/
   /*~A:101*/
   /*~+:Variablendeklarationen*/
   /*~T*/
   typedef struct{
   	float fGain_RMV;
   	long lOffset_RMV;
   }COPY_CALIBRATION;

   COPY_CALIBRATION Copy_Calibration;
   /*~T*/
   DAC_SETTINGS DAC_Settings;
   /*~E:A101*/
   /*~A:102*/
   /*~+:Variableninitialisierungen*/
   /*~T*/

   /*~E:A102*/
   /*~C:103*/
   switch (chWhat2Load)
   /*~-1*/
   {
      /*~A:104*/
      /*~+:CURRENTINTERFACE_RMW_1ST_REFPOINT (nicht hinter CURRENTINTERFACE_ALL_SETTINGS einreihen)*/
      /*~F:105*/
      case CURRENTINTERFACE_RMW_1ST_REFPOINT:
      /*~-1*/
      {
         /*~T*/
         Load_Parameter(LOAD_SAVE_DAC_RMW_1ST_REFPOINT,&g_CurrentInterface.lRMWForCalibration[0],4);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F105*/
      /*~E:A104*/
      /*~A:106*/
      /*~+:CURRENTINTERFACE_RMW_2ND_REFPOINT (nicht hinter CURRENTINTERFACE_ALL_SETTINGS einreihen)*/
      /*~F:107*/
      case CURRENTINTERFACE_RMW_2ND_REFPOINT:
      /*~-1*/
      {
         /*~T*/
         Load_Parameter(LOAD_SAVE_DAC_RMW_2ND_REFPOINT,&g_CurrentInterface.lRMWForCalibration[1],4);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F107*/
      /*~E:A106*/
      /*~K*/
      /*~+:*/
      /*~A:108*/
      /*~+:CURRENTINTERFACE_ALL_SETTINGS*/
      /*~F:109*/
      case CURRENTINTERFACE_ALL_SETTINGS:
      /*~-1*/
      {
         /*~T*/
         Load_Parameter(LOAD_SAVE_DAC_SETTINGS,&DAC_Settings,0);

         // DAC-Einstellungen auslesen
         ADuC836_DACLoadSettings(DAC_Settings);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F109*/
      /*~E:A108*/
      /*~A:110*/
      /*~+:CURRENTINTERFACE_CALIBRATION_BACKUP*/
      /*~F:111*/
      case CURRENTINTERFACE_CALIBRATION_BACKUP:
      /*~-1*/
      {
         /*~T*/
         Load_Parameter(LOAD_SAVE_DAC_COPY_CALIBRATION,&Copy_Calibration,8);

         ADuC836_DACSetGain(Copy_Calibration.fGain_RMV);
         ADuC836_DACSetOffset(0,Copy_Calibration.lOffset_RMV);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F111*/
      /*~E:A110*/
      /*~A:112*/
      /*~+:CURRENTINTERFACE_GAIN_FEEDBACK*/
      /*~F:113*/
      case CURRENTINTERFACE_GAIN_FEEDBACK:
      /*~-1*/
      {
         /*~A:114*/
         /*~+:Variablendeklarationen*/
         /*~T*/
         float fGain;
         /*~E:A114*/
         /*~A:115*/
         /*~+:Variableninitialisierungen*/
         /*~T*/

         /*~E:A115*/
         /*~T*/
         // Nullpunkt auslesen
         Load_Parameter(LOAD_SAVE_DAC_GAIN_FEEDBACK,&fGain,4);
         /*~T*/
         // und setzen
         Measurement_SetCalibrationFactor(CURRENTINTERFACE_FEEDBACKCHANEL,fGain);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F113*/
      /*~E:A112*/
      /*~A:116*/
      /*~+:CURRENTINTERFACE_INTEGRALPORTION_FEEDBACK*/
      /*~F:117*/
      case CURRENTINTERFACE_INTEGRALPORTION_FEEDBACK:
      /*~-1*/
      {
         /*~A:118*/
         /*~+:Variablendeklarationen*/
         /*~T*/
         char chPortion;
         /*~E:A118*/
         /*~A:119*/
         /*~+:Variableninitialisierungen*/
         /*~T*/

         /*~E:A119*/
         /*~T*/
         // Integralanteil der Stromregelung auslesen
         Load_Parameter(LOAD_SAVE_INTEGRALPORTION_FEEDBACK,&chPortion,1);
         /*~T*/
         // und setzen
         CurrentInterface_SetFeedBackIntegralPortion(chPortion);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F117*/
      /*~E:A116*/
      /*~A:120*/
      /*~+:CURRENTINTERFACE_OFFSET_FEEDBACK*/
      /*~F:121*/
      case CURRENTINTERFACE_OFFSET_FEEDBACK:
      /*~-1*/
      {
         /*~A:122*/
         /*~+:Variablendeklarationen*/
         /*~T*/
         MEASUREMENT_VALUE Zero;
         /*~E:A122*/
         /*~A:123*/
         /*~+:Variableninitialisierungen*/
         /*~T*/

         /*~E:A123*/
         /*~T*/
         // Nullpunkt auslesen
         Load_Parameter(LOAD_SAVE_DAC_OFFSET_FEEDBACK,&Zero,4);
         /*~T*/
         // und setzen
         Measurement_SetZeroValue(CURRENTINTERFACE_FEEDBACKCHANEL,&Zero);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F121*/
      /*~E:A120*/
      /*~A:124*/
      /*~+:CURRENTINTERFACE_MAXDEVIATION_FEEDBACK*/
      /*~F:125*/
      case CURRENTINTERFACE_MAXDEVIATION_FEEDBACK:
      /*~-1*/
      {
         /*~T*/
         // maximal zul�ssige Soll-Istwert-Abweichung auslesen 
         Load_Parameter(LOAD_SAVE_CURRENTINTERFACE_MAXDEVIATION,&g_CurrentInterface.FeedBack.fMaxDeviation,4);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F125*/
      /*~E:A124*/
      /*~A:126*/
      /*~+:CURRENTINTERFACE_TIME_HYSTERESIS*/
      /*~F:127*/
      case CURRENTINTERFACE_TIME_HYSTERESIS:
      /*~-1*/
      {
         /*~A:128*/
         /*~+:Variablendeklarationen*/
         /*~T*/
         unsigned int uTimeHysteresis;
         /*~E:A128*/
         /*~A:129*/
         /*~+:Variableninitialisierungen*/
         /*~T*/

         /*~E:A129*/
         /*~T*/
         // Zeithysterese auslesen
         Load_Parameter(LOAD_SAVE_CURRENTINTERFACE_TIME_HYSTERESIS,&uTimeHysteresis,2);
         /*~T*/
         // und setzen
         ADuC836_DACSetLimitHysteresis(ADUC836_DAC_UPPER_LIMIT,uTimeHysteresis);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F127*/
      /*~E:A126*/
      /*~A:130*/
      /*~+:CURRENTINTERFACE_PROPORTIONALPORTION_FEEDBACK*/
      /*~F:131*/
      case CURRENTINTERFACE_PROPORTIONALPORTION_FEEDBACK:
      /*~-1*/
      {
         /*~A:132*/
         /*~+:Variablendeklarationen*/
         /*~T*/
         char chPortion;
         /*~E:A132*/
         /*~A:133*/
         /*~+:Variableninitialisierungen*/
         /*~T*/

         /*~E:A133*/
         /*~T*/
         // Integralanteil der Stromregelung auslesen
         Load_Parameter(LOAD_SAVE_PROPORTIONALPORTION_FEEDBACK,&chPortion,1);
         /*~T*/
         // und setzen
         CurrentInterface_SetFeedBackProportionalPortion(chPortion);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F131*/
      /*~E:A130*/
   /*~-1*/
   }
   /*~E:C103*/
/*~-1*/
}
/*~E:F99*/
/*~E:A98*/
/*~A:134*/
/*~+:void 			CurrentInterface_PrepareCalibration(unsigned char byCalPoint,float fWeight)*/
/*~F:135*/
void CurrentInterface_PrepareCalibration(unsigned char byCalPoint,float fWeight)
/*~-1*/
{
   /*~A:136*/
   /*~+:Variablendeklarationen*/
   /*~T*/
   float fCalibrationFactor;
   /*~E:A136*/
   /*~A:137*/
   /*~+:Variableninitialisierungen*/
   /*~I:138*/
#ifndef SPEZIALVERSION_FUER_TESTSYSTEME
   /*~T*/
   Measurement_GetCalibrationFactor(WEIGHT_WEIGHTCHANNEL,&fCalibrationFactor);
   /*~O:I138*/
   /*~-1*/
#else
   /*~T*/
   fCalibrationFactor = 0.001;
   /*~-1*/
#endif
   /*~E:I138*/
   /*~E:A137*/
   /*~C:139*/
   switch (byCalPoint)
   /*~-1*/
   {
      /*~F:140*/
      case 1:		// 4mA-Kalibrierung
      /*~-1*/
      {
         /*~T*/
         g_CurrentInterface.byAdjustCurrentInterface = 1;
         g_CurrentInterface.lRMWForCalibration[0] = (long)(fWeight / fCalibrationFactor); 
         /*~T*/
         // und speichern
         CurrentInterface_SaveDACSettings(CURRENTINTERFACE_RMW_1ST_REFPOINT);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F140*/
      /*~F:141*/
      case 2:		// 20mA-Kalibrierung
      /*~-1*/
      {
         /*~T*/
         g_CurrentInterface.byAdjustCurrentInterface = 2;
         g_CurrentInterface.lRMWForCalibration[1] = (long)(fWeight / fCalibrationFactor); 
         /*~T*/
         // und speichern
         CurrentInterface_SaveDACSettings(CURRENTINTERFACE_RMW_2ND_REFPOINT);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F141*/
      /*~O:C139*/
      /*~-2*/
      default:
      {
         /*~T*/
         g_CurrentInterface.byAdjustCurrentInterface = 0;
      /*~-1*/
      }
   /*~-1*/
   }
   /*~E:C139*/
/*~-1*/
}
/*~E:F135*/
/*~E:A134*/
/*~A:142*/
/*~+:void 			CurrentInterface_SaveDACSettings(unsigned char chWhat2Save)*/
/*~F:143*/
void CurrentInterface_SaveDACSettings(unsigned char chWhat2Save)
/*~-1*/
{
   /*~A:144*/
   /*~+:Beschreibung*/
   /*~T*/
   /*!
   \fn void CurrentInterface_SaveDACSettings(unsigned char chWhat2Save)
   
   <b>Beschreibung:</b><br>
   Speicherung aller Stromschnittstellenparameter.
   
   \param
   chWhat2Save: Angabe �ber den Umfang der zu speichernden Daten (s.CURRENTINTERFACE_ALL_SETTINGS und CURRENTINTERFACE_CALIBRATION_BACKUP). 
   
   \return
   ./.
   
   <b>Zugriff:</b><br>
   [X] �ffentlich / [ ] Privat
   */
   /*~E:A144*/
   /*~A:145*/
   /*~+:Variablendeklarationen*/
   /*~T*/
   typedef struct{
   	float fGain_RMV;
   	long lOffset_RMV;
   }COPY_CALIBRATION;

   COPY_CALIBRATION Copy_Calibration;
   /*~T*/
   DAC_SETTINGS DAC_Settings;
   /*~E:A145*/
   /*~A:146*/
   /*~+:Variableninitialisierungen*/
   /*~T*/
   // DAC-Einstellungen auslesen
   DAC_Settings = ADuC836_DACSaveSettings();

   /*~E:A146*/
   /*~C:147*/
   switch (chWhat2Save)
   /*~-1*/
   {
      /*~A:148*/
      /*~+:CURRENTINTERFACE_RMW_1ST_REFPOINT (nicht hinter CURRENTINTERFACE_ALL_SETTINGS einreihen)*/
      /*~F:149*/
      case CURRENTINTERFACE_RMW_1ST_REFPOINT:
      /*~-1*/
      {
         /*~T*/
         // und speichern
         Save_Parameter(LOAD_SAVE_DAC_RMW_1ST_REFPOINT,&g_CurrentInterface.lRMWForCalibration[0],4);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F149*/
      /*~E:A148*/
      /*~A:150*/
      /*~+:CURRENTINTERFACE_RMW_2ND_REFPOINT (nicht hinter CURRENTINTERFACE_ALL_SETTINGS einreihen)*/
      /*~F:151*/
      case CURRENTINTERFACE_RMW_2ND_REFPOINT:
      /*~-1*/
      {
         /*~T*/
         // und speichern
         Save_Parameter(LOAD_SAVE_DAC_RMW_2ND_REFPOINT,&g_CurrentInterface.lRMWForCalibration[1],4);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F151*/
      /*~E:A150*/
      /*~K*/
      /*~+:*/
      /*~A:152*/
      /*~+:CURRENTINTERFACE_ALL_SETTINGS*/
      /*~F:153*/
      case CURRENTINTERFACE_ALL_SETTINGS:
      /*~-1*/
      {
         /*~T*/
         // alle Parameter speichern
         Save_Parameter(LOAD_SAVE_DAC_SETTINGS,&DAC_Settings,0);
      /*~-1*/
      }
      /*~E:F153*/
      /*~E:A152*/
      /*~A:154*/
      /*~+:CURRENTINTERFACE_GAIN_FEEDBACK (muss direkt hinter CURRENTINTERFACE_ALL_SETTINGS stehen !!!)*/
      /*~F:155*/
      case CURRENTINTERFACE_GAIN_FEEDBACK:
      /*~-1*/
      {
         /*~A:156*/
         /*~+:Variablendeklarationen*/
         /*~T*/
         float fGain;
         /*~E:A156*/
         /*~A:157*/
         /*~+:Variableninitialisierungen*/
         /*~T*/

         /*~E:A157*/
         /*~T*/
         // Kalibrierfaktor auslesen
         Measurement_GetCalibrationFactor(CURRENTINTERFACE_FEEDBACKCHANEL,&fGain);
         /*~T*/
         // und speichern
         Save_Parameter(LOAD_SAVE_DAC_GAIN_FEEDBACK,&fGain,4);
         /*~I:158*/
         if (chWhat2Save != CURRENTINTERFACE_ALL_SETTINGS)
         /*~-1*/
         {
            /*~T*/
            break;
         /*~-1*/
         }
         /*~E:I158*/
      /*~-1*/
      }
      /*~E:F155*/
      /*~E:A154*/
      /*~A:159*/
      /*~+:CURRENTINTERFACE_OFFSET_FEEDBACK (muss direkt hinter CURRENTINTERFACE_GAIN_FEEDBACK stehen !!!)*/
      /*~F:160*/
      case CURRENTINTERFACE_OFFSET_FEEDBACK:
      /*~-1*/
      {
         /*~A:161*/
         /*~+:Variablendeklarationen*/
         /*~T*/
         MEASUREMENT_VALUE Zero;
         /*~E:A161*/
         /*~A:162*/
         /*~+:Variableninitialisierungen*/
         /*~T*/

         /*~E:A162*/
         /*~T*/
         // Nullpunkt auslesen
         Measurement_GetZero(CURRENTINTERFACE_FEEDBACKCHANEL,&Zero);
         /*~T*/
         // und speichern
         Save_Parameter(LOAD_SAVE_DAC_OFFSET_FEEDBACK,&Zero,4);
         /*~I:163*/
         if (chWhat2Save != CURRENTINTERFACE_ALL_SETTINGS)
         /*~-1*/
         {
            /*~T*/
            break;
         /*~-1*/
         }
         /*~E:I163*/
      /*~-1*/
      }
      /*~E:F160*/
      /*~E:A159*/
      /*~A:164*/
      /*~+:CURRENTINTERFACE_INTEGRALPORTION_FEEDBACK (muss direkt hinter CURRENTINTERFACE_OFFSET_FEEDBACK !!!)*/
      /*~F:165*/
      case CURRENTINTERFACE_INTEGRALPORTION_FEEDBACK:
      /*~-1*/
      {
         /*~A:166*/
         /*~+:Variablendeklarationen*/
         /*~T*/
         char chPortion;
         /*~E:A166*/
         /*~A:167*/
         /*~+:Variableninitialisierungen*/
         /*~T*/

         /*~E:A167*/
         /*~T*/
         // Integral-Anteil der Stromregelung auslesen
         chPortion = CurrentInterface_GetFeedBackIntegralPortion();
         /*~T*/
         // und speichern
         Save_Parameter(LOAD_SAVE_INTEGRALPORTION_FEEDBACK,&chPortion,1);
         /*~I:168*/
         if (chWhat2Save != CURRENTINTERFACE_ALL_SETTINGS)
         /*~-1*/
         {
            /*~T*/
            break;
         /*~-1*/
         }
         /*~E:I168*/
      /*~-1*/
      }
      /*~E:F165*/
      /*~E:A164*/
      /*~A:169*/
      /*~+:CURRENTINTERFACE_PROPORTIONALPORTION_FEEDBACK (muss direkt hinter CURRENTINTERFACE_INTEGRALPORTION_FEEDBACK !!!)*/
      /*~F:170*/
      case CURRENTINTERFACE_PROPORTIONALPORTION_FEEDBACK:
      /*~-1*/
      {
         /*~A:171*/
         /*~+:Variablendeklarationen*/
         /*~T*/
         char chPortion;
         /*~E:A171*/
         /*~A:172*/
         /*~+:Variableninitialisierungen*/
         /*~T*/

         /*~E:A172*/
         /*~T*/
         // Integral-Anteil der Stromregelung auslesen
         chPortion = CurrentInterface_GetFeedBackProportionalPortion();
         /*~T*/
         // und speichern
         Save_Parameter(LOAD_SAVE_PROPORTIONALPORTION_FEEDBACK,&chPortion,1);
         /*~I:173*/
         if (chWhat2Save != CURRENTINTERFACE_ALL_SETTINGS)
         /*~-1*/
         {
            /*~T*/
            break;
         /*~-1*/
         }
         /*~E:I173*/
      /*~-1*/
      }
      /*~E:F170*/
      /*~E:A169*/
      /*~A:174*/
      /*~+:CURRENTINTERFACE_TIME_HYSTERESIS (muss direkt hinter CURRENTINTERFACE_INTEGRALPORTION_FEEDBACK !!!)*/
      /*~F:175*/
      case CURRENTINTERFACE_TIME_HYSTERESIS:
      /*~-1*/
      {
         /*~T*/
         // maximal zul�ssige Soll-Istwert-Abweichung speichern 
         Save_Parameter(LOAD_SAVE_CURRENTINTERFACE_TIME_HYSTERESIS,&DAC_Settings.Limits.uHysteresisUpperLimit,2);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F175*/
      /*~E:A174*/
      /*~A:176*/
      /*~+:CURRENTINTERFACE_CALIBRATION_BACKUP*/
      /*~F:177*/
      case CURRENTINTERFACE_CALIBRATION_BACKUP:
      /*~-1*/
      {
         /*~T*/
         Copy_Calibration.fGain_RMV = ADuC836_DACGetGain(0);
         Copy_Calibration.lOffset_RMV = ADuC836_DACGetOffset(0);

         Save_Parameter(LOAD_SAVE_DAC_COPY_CALIBRATION,&Copy_Calibration,8);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F177*/
      /*~E:A176*/
      /*~A:178*/
      /*~+:CURRENTINTERFACE_MAXDEVIATION_FEEDBACK*/
      /*~F:179*/
      case CURRENTINTERFACE_MAXDEVIATION_FEEDBACK:
      /*~-1*/
      {
         /*~T*/
         // maximal zul�ssige Soll-Istwert-Abweichung speichern 
         Save_Parameter(LOAD_SAVE_CURRENTINTERFACE_MAXDEVIATION,&g_CurrentInterface.FeedBack.fMaxDeviation,4);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F179*/
      /*~E:A178*/
   /*~-1*/
   }
   /*~E:C147*/
/*~-1*/
}
/*~E:F143*/
/*~E:A142*/
/*~A:180*/
/*~+:char 			CurrentInterface_SetCalibrationFactorOfFeedBack(float fCalibrationFactor)*/
/*~F:181*/
char CurrentInterface_SetCalibrationFactorOfFeedBack(float fCalibrationFactor)
/*~-1*/
{
   /*~A:182*/
   /*~+:Beschreibung*/
   /*~T*/
   /*!
   \fn char CurrentInterface_SetCalibrationFactor(float fCalibrationFactor)
   
   <b>Beschreibung:</b><br>
   Manuelles Setzen des Kalibrierfaktors.
   
   \param
   fCalibrationFactor: Zu setzender Kalibrierfaktor.
   
   \return
   Status der Funktionsausf�hrung.
   
   \retval
   0: Alles okay.
   \retval
   1: Fehler beim Setzen des Kalibrierfaktors - alter Wert wird beibehalten.
   
   <b>Zugriff:</b><br>
   [X] �ffentlich / [ ] Privat
   */
   /*~E:A182*/
   /*~A:183*/
   /*~+:Variablendeklarationen*/
   /*~T*/
   float fOldCalibrationFactor;
   /*~E:A183*/
   /*~A:184*/
   /*~+:Variableninitialisierungen*/
   /*~T*/
   Measurement_GetCalibrationFactor (CURRENTINTERFACE_FEEDBACKCHANEL,&fOldCalibrationFactor);  
   /*~E:A184*/
   /*~I:185*/
   if ((fCalibrationFactor >= MIN_KALIBRIERFAKTOR)&&(fCalibrationFactor <= MAX_KALIBRIERFAKTOR))
   /*~-1*/
   {
      /*~I:186*/
      // Kalibrierfaktor berechnen
      if (!Measurement_SetCalibrationFactor(CURRENTINTERFACE_FEEDBACKCHANEL,fCalibrationFactor))
      /*~-1*/
      {
         /*~I:187*/
         if (fCalibrationFactor != fOldCalibrationFactor)
         /*~-1*/
         {
            /*~T*/
            // Kalibrierfaktor abspeichern
            //CurrentInterface_SaveDACSettings(CURRENTINTERFACE_GAIN_FEEDBACK);
         /*~-1*/
         }
         /*~E:I187*/
         /*~T*/
         return 0;
         /*~K*/
         /*~+:*/
      /*~-1*/
      }
      /*~O:I186*/
      /*~-2*/
      else
      {
         /*~T*/
         // Fehler
         /*~T*/
         // alten Kalibrierfaktor wieder setzen
         Measurement_SetCalibrationFactor(CURRENTINTERFACE_FEEDBACKCHANEL,fOldCalibrationFactor);
      /*~-1*/
      }
      /*~E:I186*/
   /*~-1*/
   }
   /*~O:I185*/
   /*~-2*/
   else
   {
      /*~T*/
      // Fehler
   /*~-1*/
   }
   /*~E:I185*/
   /*~T*/
   return 1;
/*~-1*/
}
/*~E:F181*/
/*~E:A180*/
/*~A:188*/
/*~+:void 			CurrentInterface_SetFeedBackIntegralPortion(char chIntegralPortion)*/
/*~F:189*/
void CurrentInterface_SetFeedBackIntegralPortion(char chIntegralPortion)
/*~-1*/
{
   /*~T*/
   // Grenzen pr�fen
   chIntegralPortion = MAX(0,chIntegralPortion);
   chIntegralPortion = MIN(100,chIntegralPortion);
   /*~T*/
   g_CurrentInterface.FeedBack.chIntegralPortion = chIntegralPortion;

   // und speichern
   CurrentInterface_SaveDACSettings(CURRENTINTERFACE_INTEGRALPORTION_FEEDBACK);
/*~-1*/
}
/*~E:F189*/
/*~E:A188*/
/*~A:190*/
/*~+:void 			CurrentInterface_SetFeedBackProportionalPortion(char chProportionalPortion)*/
/*~F:191*/
void CurrentInterface_SetFeedBackProportionalPortion(char chProportionalPortion)
/*~-1*/
{
   /*~T*/
   // Grenzen pr�fen
   chProportionalPortion = MAX(0,chProportionalPortion);
   chProportionalPortion = MIN(100,chProportionalPortion);
   /*~T*/
   g_CurrentInterface.FeedBack.chProportionalPortion = chProportionalPortion;

   // und speichern
   CurrentInterface_SaveDACSettings(CURRENTINTERFACE_PROPORTIONALPORTION_FEEDBACK);
/*~-1*/
}
/*~E:F191*/
/*~E:A190*/
/*~A:192*/
/*~+:void 			CurrentInterface_SetFeedBackOnOff(unsigned char bOnOff,unsigned char bSave)*/
/*~F:193*/
void CurrentInterface_SetFeedBackOnOff(unsigned char bOnOff,unsigned char bSave)
/*~-1*/
{
   /*~I:194*/
   if (bOnOff)
   /*~-1*/
   {
      /*~T*/
      // Soll-Istwert-Korrektur einschalten
      ADuC836_DACSetCurrentDeviationCorrectionOn(1);
      // Regelabweichung setzen
      ADuC836_DACSetCurrentDeviation(0);

   /*~-1*/
   }
   /*~O:I194*/
   /*~-2*/
   else
   {
      /*~T*/
      // Soll-Istwert-Korrektur ausschalten
      ADuC836_DACSetCurrentDeviationCorrectionOn(0);
   /*~-1*/
   }
   /*~E:I194*/
   /*~I:195*/
   if (bSave)
   /*~-1*/
   {
      /*~T*/
      CurrentInterface_SaveDACSettings(CURRENTINTERFACE_ALL_SETTINGS);
   /*~-1*/
   }
   /*~E:I195*/
/*~-1*/
}
/*~E:F193*/
/*~E:A192*/
/*~A:196*/
/*~+:void 			CurrentInterface_SetLimits(long lLowerLimit,long lUpperLimit)*/
/*~F:197*/
void CurrentInterface_SetLimits(long lLowerLimit,long lUpperLimit)
/*~-1*/
{
   /*~A:198*/
   /*~+:Beschreibung*/
   /*~T*/
   /*!
   \fn void CurrentInterface_SetLimits(long lLowerLimit,long lUpperLimit)
   
   <b>Beschreibung:</b><br>
   Setzen der Grenzwerte der Stromschnittstelle.
   
   \param
   lLowerLimit: unterer Grenzwert.
   
   \param
   lUpperLimit: oberer Grenzwert.
   
   \return
   ./.
   
   <b>Zugriff:</b><br>
   [X] �ffentlich / [ ] Privat
   */

   /*~E:A198*/
   /*~T*/
   ADuC836_DACSetLimit(ADUC836_DAC_LOWER_LIMIT,lLowerLimit,ADUC836_DAC_KEEP_OUTPUT);
   ADuC836_DACSetLimit(ADUC836_DAC_UPPER_LIMIT,lUpperLimit,ADUC836_DAC_SET2ZERO);

   // und speichern
   CurrentInterface_SaveDACSettings(CURRENTINTERFACE_ALL_SETTINGS);

/*~-1*/
}
/*~E:F197*/
/*~E:A196*/
/*~A:199*/
/*~+:void 			CurrentInterface_SetManualMode(unsigned char byOnOff,long lRatedDACOutput)*/
/*~F:200*/
void CurrentInterface_SetManualMode(unsigned char byOnOff,long lRatedDACOutput)
/*~-1*/
{
   /*~T*/
   // DAC-Testmode aktiv setzen
   SET_DAC_TESTMODE(byOnOff);

   /*~T*/
   g_CurrentInterface.DAC.lRatedDACOutput = lRatedDACOutput;
/*~-1*/
}
/*~E:F200*/
/*~E:A199*/
/*~A:201*/
/*~+:void 			CurrentInterface_SetTimeHysteresis(unsigned int uTime)*/
/*~F:202*/
void CurrentInterface_SetTimeHysteresis(unsigned int uTime)
/*~-1*/
{
   /*~A:203*/
   /*~+:Beschreibung*/
   /*~T*/
   /*!
   \fn void CurrentInterface_SetTimeHysteresis(unsigned int uTime)
   
   <b>Beschreibung:</b><br>
   Setzen der Zeithysterese zum Verlassen des Grenzwertstatus.
   
   \param
   uTime: Zeit in Sekunden.
   
   \return
   ./.
   
   <b>Zugriff:</b><br>
   [X] �ffentlich / [ ] Privat
   */


   /*~E:A203*/
   /*~T*/
   ADuC836_DACSetLimitHysteresis(ADUC836_DAC_UPPER_LIMIT,uTime * CURRENTINTERFACE_TIMETICS2SEC);

   // und speichern
   CurrentInterface_SaveDACSettings(CURRENTINTERFACE_ALL_SETTINGS);

/*~-1*/
}
/*~E:F202*/
/*~E:A201*/
/*~A:204*/
/*~+:char			CurrentInterface_SetZeroOfFeedBack(long lZero2Set)*/
/*~F:205*/
char CurrentInterface_SetZeroOfFeedBack(long lZero2Set)
/*~-1*/
{
   /*~A:206*/
   /*~+:Beschreibung*/
   /*~T*/
   /*!
   \fn char CurrentInterface_SetZero(long lZero2Set)
   
   <b>Beschreibung:</b><br>
   Manuelles Setzen des Nullpunktes.
   
   \param
   lZero2Set: Zu setzender Nullpunkt.
   
   \return
   Status der Funktionsausf�hrung.
   
   \retval
   0: Alles okay.
   \retval
   1: Fehler beim Setzen des Nullpunktes - alter Wert wird beibehalten.
   
   <b>Zugriff:</b><br>
   [X] �ffentlich / [ ] Privat
   */

   /*~E:A206*/
   /*~A:207*/
   /*~+:Variablendeklarationen*/
   /*~T*/
   MEASUREMENT_VALUE Zero;
   MEASUREMENT_VALUE OldZero;
   /*~E:A207*/
   /*~A:208*/
   /*~+:Variabelninitialisierungen*/
   /*~T*/
   Measurement_GetZero (CURRENTINTERFACE_FEEDBACKCHANEL,&OldZero);
   Zero.nLong = lZero2Set;
   /*~E:A208*/
   /*~I:209*/
   if ((Zero.nLong >= MIN_NULLPUNKT)&&(Zero.nLong <= MAX_NULLPUNKT))
   /*~-1*/
   {
      /*~I:210*/
      if (!Measurement_SetZeroValue(CURRENTINTERFACE_FEEDBACKCHANEL,&Zero))
      /*~-1*/
      {
         /*~I:211*/
         if (Zero.nLong != OldZero.nLong)
         /*~-1*/
         {
            /*~T*/
            // Messwertoffset abspeichern
            // CurrentInterface_SaveDACSettings(CURRENTINTERFACE_OFFSET_FEEDBACK);
         /*~-1*/
         }
         /*~E:I211*/
         /*~T*/
         return 0;
         /*~K*/
         /*~+:*/
      /*~-1*/
      }
      /*~O:I210*/
      /*~-2*/
      else
      {
         /*~T*/
         // Fehler
      /*~-1*/
      }
      /*~E:I210*/
   /*~-1*/
   }
   /*~O:I209*/
   /*~-2*/
   else
   {
      /*~T*/
      // Fehler
   /*~-1*/
   }
   /*~E:I209*/
   /*~T*/
   // alten Nullpunkt wieder setzen
   Measurement_SetZeroValue(CURRENTINTERFACE_FEEDBACKCHANEL,&OldZero);
   /*~T*/
   return 1;
/*~-1*/
}
/*~E:F205*/
/*~E:A204*/
/*~K*/
/*~+:*/
