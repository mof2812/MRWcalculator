/*~-1*/
/*~XSF_LANGUAGE: C/C++*/
/*~K*/
/*~+:File :        CRC16.h*/
/*~+:*/
/*~+:Version :     V1.000*/
/*~+:*/
/*~+:Date :        10.05.2016*/
/*~+:Time :        */
/*~+:*/
/*~+:Author :      MOF*/
/*~+:*/
/*~+:Hardware :*/
/*~+:*/
/*~+:Description :*/
/*~I:1*/
#ifndef __CRC16_H 
/*~T*/
#define __CRC16_H
/*~A:2*/
/*~+:Includes*/
/*~T*/

/*~E:A2*/
/*~A:3*/
/*~+:Konfiguration*/
/*~T*/

/*~E:A3*/
/*~A:4*/
/*~+:Definitionen*/
/*~T*/

/*~E:A4*/
/*~A:5*/
/*~+:Strukturdefinitionen*/
/*~T*/

/*~E:A5*/
/*~A:6*/
/*~+:Funktionsdeklarationen*/
/*~T*/
extern unsigned int 	CRC16_Build(unsigned char byData);
extern unsigned int 	CRC16_Clear(void);
extern unsigned char* 	CRC16_ToASCII(void);
extern char* 			CRC16_Version(void);
/*~E:A6*/
/*~A:7*/
/*~+:Variablendeklarationen*/
/*~T*/
extern unsigned int g_uiCRC16;
/*~E:A7*/
/*~-1*/
#endif
/*~E:I1*/
