/*~-1*/
/*~XSF_LANGUAGE: C/C++*/
/*~K*/
/*~+:File :        InstuctionDecoder.c*/
/*~+:*/
/*~+:Version :     V1.002*/
/*~+:*/
/*~+:Date :        21.11.2021*/
/*~+:*/
/*~+:Time :        10:23*/
/*~+:*/
/*~+:Author :      MOF*/
/*~+:*/
/*~+:Hardware :*/
/*~+:*/
/*~+:Description :*/
/*~+:*/
/*~+:*/
/*~A:1*/
/*~+:Includes*/
/*~T*/
#include "global.h"
#include "InstructionDecoder.h"
#include "ADuc836Driver.h"
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
/*~E:A1*/
/*~A:2*/
/*~+:Funktionseigene Definitionen und Makros*/
/*~T*/
#define DATATYPE_CHAR									0
#define DATATYPE_UNSIGNED_CHAR							1
#define DATATYPE_INT									2
#define DATATYPE_UNSIGNED_INT							3
#define DATATYPE_LONG									4
#define DATATYPE_UNSIGNED_LONG							5
#define DATATYPE_FLOAT									6
/*~T*/
#define SHOW_ERRORS_BY_NONE								0x00
#define SHOW_ERRORS_BY_CH0								0x01
#define SHOW_ERRORS_BY_CH1								0x02
#define SHOW_ERRORS_BY_ALL								0x03
/*~T*/
#define HANDSHAKING_TIMEOUT								500
/*~I:3*/
#ifdef CHANNEL_0
/*~T*/
#define GET_RESPONSE				Communication_GetSPIResponse()
#define RELEASE_INSTRUCTIONDECODER	System_ReleaseExternalInterrupt()
/*~-1*/
#endif
/*~E:I3*/
/*~I:4*/
#ifdef CHANNEL_1
/*~T*/
#define GET_RESPONSE		(bDoNotWriteResult2Buffer = 0)
/*~-1*/
#endif
/*~E:I4*/
/*~E:A2*/
/*~A:5*/
/*~+:Funktionseigene Struktur-Definitionen*/
/*~T*/

/*~E:A5*/
/*~A:6*/
/*~+:Funktionsprototypen*/
/*~T*/
void 			InstructionDecoder(void);
char 			InstructionDecoder_CheckLimits(void *pParameter2Check, void *pLimitLow, void *pLimitHigh,unsigned char chDataType);

char 			InstructionDecoder_CheckNbParameters(unsigned char byNbParametersExpected,char byShowErrorsBy,unsigned char *pStatus);

void 			InstructionDecoder_SendStoredValue(unsigned char byValue2Get);

void 			InstructionDecoder_StoreValue(unsigned char byValue2Store,GLOBAL_UNIVALUE_SHORT* pValue);

/*~E:A6*/
/*~A:7*/
/*~+:Globale Variablen*/
/*~T*/
unsigned char g_chRCWLast;
/*~I:8*/
#ifdef CHANNEL_1
/*~T*/
unsigned char g_byLastCommandExecutionResult = 0xA5;		///< Letztes Ergebnis einer Funktionsausf�hrung. Es ist noch nichts eingetragen
/*~T*/
unsigned char 			g_byValueStored = 0;		///< Angabe zum gespeicherten Wert
GLOBAL_UNIVALUE_SHORT 	g_Value;					///< zu �bergebender Wert
unsigned long 			g_ulTimeoutValue;			///< Zeit, zu der der Wert sp�testens gel�scht wird
/*~-1*/
#endif
/*~E:I8*/
/*~E:A7*/
/*~A:9*/
/*~+:void 			InstructionDecoder(void)*/
/*~F:10*/
void InstructionDecoder(void)
/*~-1*/
{
   /*~A:11*/
   /*~+:Variablendeklarationen*/
   /*~T*/
   unsigned char 		szCommand[80];
   unsigned char 		byChecksumError = FALSE;
   unsigned char 		byCommandStatus;
   unsigned long 		lText2Send;
   unsigned long		ulDiagnosisEntry2Set;

   /*~I:12*/
#ifdef CHANNEL_1
   /*~T*/
   static unsigned long		ulDiagnosisEntry2SetAtiGRS = 0;

   /*~-1*/
#endif
   /*~E:I12*/
   /*~T*/
   GLOBAL_UNIVALUE 	Parameter[4];
   unsigned char 		byTemp;
   float fTemp;
   unsigned char 		byRetVal;
   MEASUREMENT_VALUE 	MVTemp;
   unsigned char 		byLoopCounter;
   char 				szString2Send[24];

   /*~I:13*/
#ifdef CHANNEL_0
   /*~T*/
   unsigned char 		byStartPartnerInstructionDecoder;
   unsigned char		byStatelineStatus;
   /*~-1*/
#endif
   /*~E:I13*/
   /*~I:14*/
#ifdef CHANNEL_1
   /*~T*/
   // GLOBAL_UNIVALUE 	ParameterRead;
   unsigned char 		bDoNotWriteResult2Buffer;
   /*~I:15*/
#ifdef SYSTEM_CND_ENABLE_SPI_DEBUGGING
   /*~T*/
   // Nur zu Testzwecken
   char achString[24];
   /*~-1*/
#endif
   /*~E:I15*/
   /*~-1*/
#endif
   /*~E:I14*/
   /*~E:A11*/
   /*~A:16*/
   /*~+:Variableninitialisierungen*/
   /*~I:17*/
#ifdef CHANNEL_0
   /*~T*/
   byCommandStatus = INSTRUCTIONDECODER_SEND_E004;

   /*~-1*/
#endif
   /*~E:I17*/
   /*~I:18*/
#ifdef CHANNEL_1
   /*~T*/
   byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
   bDoNotWriteResult2Buffer = 1;

   /*~-1*/
#endif
   /*~E:I18*/
   /*~T*/
   ulDiagnosisEntry2Set = 0;
   lText2Send = 0;
   byRetVal = 0;
   byLoopCounter = 5;
   byChecksumError = FALSE;

   /*~I:19*/
#ifdef CHANNEL_0
   /*~T*/
   byStartPartnerInstructionDecoder = 0;
   /*~-1*/
#endif
   /*~E:I19*/
   /*~E:A16*/
   /*~A:20*/
   /*~+:Befehlsauswertung und -ausf�hrung*/
   /*~A:21*/
   /*~+:Kanal 0 - Zugangssteuerung*/
   /*~I:22*/
#ifdef CHANNEL_0
   /*~I:23*/
   if (ADuC836_RS232IsNewCommand())
   /*~-1*/
   {
      /*~K*/
      /*~+:// �ber die RS232 kam ein Kommando rein */
      /*~T*/
      CommunicationControl.chLine2Interprete = COMMUNICATION_RS232;
      /*~T*/
      // R�ckleitung des Handshakings auf HIGH legen
      COMMUNICATION_INSTUCTIONDECODER_STATE_LINE = TRUE;
      /*~T*/
      // Status der Instuction-Decoder - Leitung abfragen und den Status zwischenspeichern

      byStatelineStatus = COMMUNICATION_INSTUCTIONDECODER_STATE_LINE;
      /*~T*/
      // Freigabeleitung f�r Start des Instruction-Decoders auf Partner-Seite setzen

      COMMUNICATION_INSTUCTIONDECODER_RELEASE_LINE = 1;	
   /*~-1*/
   }
   /*~O:I23*/
   /*~-2*/
   else
   {
      /*~K*/
      /*~+:// Es gibt nichts zu tun*/
      /*~T*/
      return;
   /*~-1*/
   }
   /*~E:I23*/
   /*~-1*/
#endif
   /*~E:I22*/
   /*~E:A21*/
   /*~A:24*/
   /*~+:Kanal 1 - Zugangssteuerung*/
   /*~I:25*/
#ifdef CHANNEL_1
   /*~I:26*/
   if (ADuC836_SPIIsNewCommand())
   /*~-1*/
   {
      /*~K*/
      /*~+:// �ber die SPI kam ein Kommando rein */
      /*~T*/
      CommunicationControl.chLine2Interprete = COMMUNICATION_SPI;
   /*~-1*/
   }
   /*~O:I26*/
   /*~-2*/
   else
   {
      /*~I:27*/
      if (COMMUNICATION_INSTUCTIONDECODER_STATE_LINE)
      /*~-1*/
      {
         /*~T*/
         // Partner hat die RS232-Abarbeitung des Instruction-Decoders freigegeben
         /*~I:28*/
         if (ADuC836_RS232IsNewCommand())
         /*~-1*/
         {
            /*~T*/
            // R�ckleitung des Handshakings auf HIGH legen
            COMMUNICATION_INSTUCTIONDECODER_STATE_LINE = TRUE;
            /*~K*/
            /*~+:// �ber die RS232 kam ein Kommando rein */
            /*~T*/
            CommunicationControl.chLine2Interprete = COMMUNICATION_RS232;
            /*~A:29*/
            /*~+:Das Ergebnis der letzten Ausf�hrung zur�cksetzen*/
            /*~T*/
            // Das Ergebnis der letzten Ausf�hrung zur�cksetzen

            g_byLastCommandExecutionResult = 0xA5;
            /*~E:A29*/
         /*~-1*/
         }
         /*~O:I28*/
         /*~-2*/
         else
         {
            /*~K*/
            /*~+:// Es gibt nichts zu tun*/
            /*~T*/
            return;
         /*~-1*/
         }
         /*~E:I28*/
      /*~-1*/
      }
      /*~O:I27*/
      /*~-2*/
      else
      {
         /*~T*/
         return;
      /*~-1*/
      }
      /*~E:I27*/
   /*~-1*/
   }
   /*~E:I26*/
   /*~-1*/
#endif
   /*~E:I25*/
   /*~E:A24*/
   /*~A:30*/
   /*~+:Befehl holen, auswerten und ggf. Pr�fsumme bilden*/
   /*~T*/
   Communication_GetRecBuffer(CommunicationControl.chLine2Interprete,szCommand);
   /*~I:31*/
#ifdef MIT_CRC16
   /*~I:32*/
   if ((CommunicationControl.chLine2Interprete == COMMUNICATION_RS232)&&(strncmp(szCommand,"CDL",3) != 0))
   /*~-1*/
   {
      /*~T*/
      byChecksumError = Communication_CheckReceiveFrame(szCommand);

   /*~-1*/
   }
   /*~E:I32*/
   /*~-1*/
#endif
   /*~E:I31*/
   /*~T*/
   strcpy(szCommand,Communication_Interpret(szCommand));
   /*~E:A30*/
   /*~I:33*/
#ifdef MIT_CRC16
   /*~A:34*/
   /*~+:Nur bei CRC16-Pr�fung*/
   /*~I:35*/
#ifdef CHANNEL_0
   /*~I:36*/
   if (CommunicationControl.chLine2Interprete == COMMUNICATION_RS232)
   /*~-1*/
   {
      /*~A:37*/
      /*~+:Ausgabe Teil 1 - Fehlermeldung wg. fehlerhafter CRC*/
      /*~A:38*/
      /*~+:Warte bis Kanal 1 die Freigabe wieder zur�ckgibt*/
      /*~F:39*/
      // Warte bis Kanal 1 die Freigabe wieder zur�ckgibt
      /*~-1*/
      {
         /*~T*/
         ulTimeout = SYSTEMTIME + HANDSHAKING_TIMEOUT; 
         /*~L:40*/
         while ((byStatelineStatus == COMMUNICATION_INSTUCTIONDECODER_STATE_LINE)&&(ulTimeout >= SYSTEMTIME))
         /*~-1*/
         {
            /*~T*/

         /*~-1*/
         }
         /*~E:L40*/
      /*~-1*/
      }
      /*~E:F39*/
      /*~E:A38*/
      /*~A:41*/
      /*~+:Kanal 1 hat die Freigabe wieder zur�ckgegeben. jetzt kann eine CRC16-Fehlermeldung erfolgen*/
      /*~T*/
      // Kanal 1 hat die Freigabe wieder zur�ckgegeben. jetzt kann eine CRC16-Fehlermeldung erfolgen
      COMMUNICATION_INSTUCTIONDECODER_RELEASE_LINE = FALSE;	
      /*~A:42*/
      /*~+:Im Fehlerfall eine Fehlermeldung (E012) ausgeben - ansonsten 1ms warten*/
      /*~I:43*/
      if (byChecksumError)
      /*~-1*/
      {
         /*~T*/
         Communication_SendString(COMMUNICATION_RS232,TEXT_E012,1,0);
         /*~T*/
         ulTimeout = SYSTEMTIME + HANDSHAKING_TIMEOUT; 
         /*~L:44*/
         while ((ADuC836_RS232IsTransmissionReady() == FALSE)&&(ulTimeout >= SYSTEMTIME))
         /*~-1*/
         {
            /*~T*/

         /*~-1*/
         }
         /*~E:L44*/
      /*~-1*/
      }
      /*~O:I43*/
      /*~-2*/
      else
      {
         /*~T*/
         System_Wait(1);
      /*~-1*/
      }
      /*~E:I43*/
      /*~E:A42*/
      /*~E:A41*/
      /*~A:45*/
      /*~+:Kanal 1 wieder die Freigabe zur Datanausgabe �bergeben*/
      /*~T*/
      // Status der Instuction-Decoder - Leitung abfragen und den umgekehrten Status zwischenspeichern
      byStatelineStatus = COMMUNICATION_INSTUCTIONDECODER_STATE_LINE;
      /*~T*/
      // Kanal 1 wieder die Freigabe zur Datanausgabe �bergeben
      COMMUNICATION_INSTUCTIONDECODER_RELEASE_LINE = TRUE;
      /*~E:A45*/
      /*~E:A37*/
   /*~-1*/
   }
   /*~E:I36*/
   /*~-1*/
#endif
   /*~E:I35*/
   /*~I:46*/
#ifdef CHANNEL_1
   /*~I:47*/
   if (CommunicationControl.chLine2Interprete == COMMUNICATION_RS232)
   /*~-1*/
   {
      /*~A:48*/
      /*~+:Ausgabe Teil 1 - Fehlermeldung wg. fehlerhafter CRC*/
      /*~A:49*/
      /*~+:Im Fehlerfall eine Fehlermeldung (E012) ausgeben*/
      /*~I:50*/
      if (byChecksumError)
      /*~-1*/
      {
         /*~T*/
         Communication_SendString(COMMUNICATION_RS232,TEXT_E012,1,0);
         /*~T*/
         ulTimeout = SYSTEMTIME + HANDSHAKING_TIMEOUT; 
         /*~L:51*/
         while ((ADuC836_RS232IsTransmissionReady() == FALSE)&&(ulTimeout >= SYSTEMTIME))
         /*~-1*/
         {
            /*~T*/

         /*~-1*/
         }
         /*~E:L51*/
      /*~-1*/
      }
      /*~E:I50*/
      /*~E:A49*/
      /*~T*/
      ulTimeout = SYSTEMTIME + HANDSHAKING_TIMEOUT; 
      /*~A:52*/
      /*~+:Fehlerausgabe erfolgt - Handshakeleitung umschalten*/
      /*~T*/
      // Fehlerausgabe erfolgt - Handshakeleitung umschalten
      COMMUNICATION_INSTUCTIONDECODER_RELEASE_LINE = !COMMUNICATION_INSTUCTIONDECODER_RELEASE_LINE;
      /*~E:A52*/
      /*~A:53*/
      /*~+:Warte auf einen Pegelwechsel von LOW nach HIGH. Wenn dieser erfolgt ist, kann Kanal 1 beginnen, das Datum zu senden*/
      /*~F:54*/
      // Warte auf einen Pegelwechsel von LOW nach HIGH. Wenn dieser erfolgt ist, kann Kanal 1 beginnen, das Datum zu senden
      /*~-1*/
      {
         /*~L:55*/
         while ((COMMUNICATION_INSTUCTIONDECODER_STATE_LINE)&&(ulTimeout >= SYSTEMTIME))
         /*~-1*/
         {
            /*~T*/

         /*~-1*/
         }
         /*~E:L55*/
         /*~L:56*/
         while ((!COMMUNICATION_INSTUCTIONDECODER_STATE_LINE)&&(ulTimeout >= SYSTEMTIME))
         /*~-1*/
         {
            /*~T*/

         /*~-1*/
         }
         /*~E:L56*/
      /*~-1*/
      }
      /*~E:F54*/
      /*~E:A53*/
      /*~E:A48*/
   /*~-1*/
   }
   /*~E:I47*/
   /*~-1*/
#endif
   /*~E:I46*/
   /*~E:A34*/
   /*~-1*/
#endif
   /*~E:I33*/
   /*~I:57*/
   if (szCommand[0])

   /*~-1*/
   {
      /*~I:58*/
#ifdef CHANNEL_1
      	if (strcmp(szCommand,"GPA"))
#endif
      /*~-1*/
      {
         /*~I:59*/
         if ((byChecksumError == FALSE)||(strcmp(szCommand,"CDL") == 0)) 
         /*~-1*/
         {
            /*~K*/
            /*~+:/~* Ge�ndert am 09.02.2022 *~/*/
            /*~I:60*/
            if ((Communication_IsCommunicationEnabled() != 0)||(strcmp(szCommand,"ENA") == 0)||(strcmp(szCommand,"CDL") == 0)||(CommunicationControl.chLine2Interprete != COMMUNICATION_RS232))
            /*~-1*/
            {
               /*~K*/
               /*~+:/~* Ende - Ge�ndert am 09.02.2022 *~/*/
               /*~C:61*/
               // switch (*(char*)szCommand)
               switch (szCommand[0])
               /*~-1*/
               {
                  /*~A:62*/
                  /*~+:A*/
                  /*~F:63*/
                  case 'A':
                  /*~-1*/
                  {
                     /*~A:64*/
                     /*~+:ACR - AutomaticCompensationResults*/
                     /*~I:65*/
                     if (!strcmp(szCommand,"ACR"))
                     /*~-1*/
                     {
                        /*~A:66*/
                        /*~+:Variablendeklarationen*/
                        /*~T*/
                        unsigned char byCounter;
                        /*~E:A66*/
                        /*~A:67*/
                        /*~+:Variableninitialisierungen*/
                        /*~T*/
                        byCounter = 3;
                        /*~E:A67*/
                        /*~T*/
                        // Text wurde bereits gesendet
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:68*/
#ifdef CHANNEL_0
                        /*~I:69*/
                        if (!InstructionDecoder_CheckNbParameters(3,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           // Parameter einlesen
                           // Kanal
                           Parameter[0].nLong = Communication_GetLongParameter(0);
                           // Welche Ausgabe
                           Parameter[1].nLong = Communication_GetLongParameter(1);
                           // zus�tzliche Angabe
                           Parameter[2].nLong = Communication_GetLongParameter(2);

                           /*~I:70*/
                           if (((Parameter[1].nLong > 7)&&(Parameter[1].nLong != 255))||(Parameter[0].nLong > 1))
                           /*~-1*/
                           {
                              /*~A:71*/
                              /*~+:Parameter au�erhalb des Bereichs*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~E:A71*/
                           /*~-1*/
                           }
                           /*~O:I70*/
                           /*~-2*/
                           else
                           {
                              /*~I:72*/
                              if ((!SYSTEM_MRW_MANAGER)||(Parameter[0].nLong == 0))
                              /*~-1*/
                              {
                              /*~A:73*/
                              /*~+:Ausgabe 'Kanal 0'*/
                              /*~T*/
                              // Synchronisationspr�fung wg. der langen Ausf�hrungsdauer abschalten
                              /*~A:74*/
                              /*~+:ausgeklammert*/
                              /*~I:75*/
#ifdef MOF
                              /*~U:76*/
                              /*~-2*/
                              do
                              {
                              /*~T*/
                              Communication_SendSPICommand("iSCS 0");
                              /*~-1*/
                              }
                              /*~O:U76*/
                              while (!Communication_IsOK() && --byCounter);
                              /*~E:U76*/
                              /*~-1*/
#endif
                              /*~E:I75*/
                              /*~E:A74*/
                              /*~I:77*/
#ifdef MOF
                              /*~T*/
                              Communication_SendSPICommand("iSCS 0");
                              /*~I:78*/
                              if (Communication_IsOK())
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendSPICommand("iSCS 1");
                              /*~-1*/
                              }
                              /*~E:I78*/
                              /*~-1*/
#endif
                              /*~E:I77*/
                              /*~T*/
                              Compensation_PrintCompensationValues(1,Parameter[1].nLong,(char)Parameter[2].nLong,0);
                              /*~E:A73*/
                              /*~-1*/
                              }
                              /*~E:I72*/
                           /*~-1*/
                           }
                           /*~E:I70*/
                           /*~I:79*/
                           if ((!SYSTEM_MRW_MANAGER)||(Parameter[0].nLong == 1))
                           /*~-1*/
                           {
                              /*~A:80*/
                              /*~+:Ausgabe Kanal '1' veranlassen*/
                              /*~T*/
                              // Frame zusammensetzen
                              sprintf(szString2Send,"iACR %ld %ld",Parameter[1].nLong,Parameter[2].nLong);
                              /*~I:81*/
                              if (!Communication_SendSPICommand(szString2Send))
                              /*~-1*/
                              {
                              /*~I:82*/
                              if (Communication_IsOK())
                              /*~-1*/
                              {
                              /*~T*/
                              // Alles okay

                              // Wg. der langen Dauer der Ausgabe die Synchronisationspr�fung ausschalten
                              System_SetCheckSynchronisation(0);
                              /*~-1*/
                              }
                              /*~O:I82*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~-1*/
                              }
                              /*~E:I82*/
                              /*~-1*/
                              }
                              /*~O:I81*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~-1*/
                              }
                              /*~E:I81*/
                              /*~E:A80*/
                           /*~-1*/
                           }
                           /*~E:I79*/
                        /*~-1*/
                        }
                        /*~O:I69*/
                        /*~-2*/
                        else
                        {
                           /*~A:83*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A83*/
                        /*~-1*/
                        }
                        /*~E:I69*/
                        /*~-1*/
#endif
                        /*~E:I68*/
                     /*~-1*/
                     }
                     /*~E:I65*/
                     /*~E:A64*/
                     /*~A:84*/
                     /*~+:ACV - AutomaticCompensationValues*/
                     /*~I:85*/
                     if (!strcmp(szCommand,"ACV"))
                     /*~-1*/
                     {
                        /*~T*/
                        // Text wurde bereits gesendet
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:86*/
                        if (!InstructionDecoder_CheckNbParameters(2,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           // Parameter einlesen
                           // Kanal
                           Parameter[0].nLong = Communication_GetLongParameter(0);
                           // Welche Ausgabe
                           Parameter[1].nLong = Communication_GetLongParameter(1);

                           /*~I:87*/
                           if (Parameter[0].nLong < 2)
                           /*~-1*/
                           {
                              /*~I:88*/
                              if (!Parameter[0].nLong)
                              /*~-1*/
                              {
                              /*~I:89*/
#ifdef CHANNEL_1
                              /*~T*/
                              return;
                              /*~-1*/
#endif
                              /*~E:I89*/
                              /*~-1*/
                              }
                              /*~O:I88*/
                              /*~-2*/
                              else
                              {
                              /*~I:90*/
#ifdef CHANNEL_0
                              /*~T*/
                              return;
                              /*~-1*/
#endif
                              /*~E:I90*/
                              /*~-1*/
                              }
                              /*~E:I88*/
                              /*~T*/
                              // Zyklische Ausgabe unterdr�cken
                              Compensation_SuppressOutput(1);
                              /*~T*/
                              // Wert ausgeben
                              Compensation_PrintCompensationValues(0,Parameter[1].nLong,0,0);
                           /*~-1*/
                           }
                           /*~O:I87*/
                           /*~-2*/
                           else
                           {
                              /*~A:91*/
                              /*~+:Parameter au�erhalb des Bereichs*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~E:A91*/
                           /*~-1*/
                           }
                           /*~E:I87*/
                        /*~-1*/
                        }
                        /*~O:I86*/
                        /*~-2*/
                        else
                        {
                           /*~A:92*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A92*/
                        /*~-1*/
                        }
                        /*~E:I86*/
                     /*~-1*/
                     }
                     /*~E:I85*/
                     /*~E:A84*/
                     /*~A:93*/
                     /*~+:ART - AutomaticRecordTemperaturecompensation*/
                     /*~I:94*/
                     if (!strcmp(szCommand,"ART"))
                     /*~-1*/
                     {
                        /*~A:95*/
                        /*~+:Variablendeklarationen*/
                        /*~T*/
                        float fCalibrationFactor;
                        unsigned char chError;
                        unsigned char byCounter;
                        /*~E:A95*/
                        /*~A:96*/
                        /*~+:Variableninitialisierungen*/
                        /*~T*/
                        chError = 0;
                        byCounter = 3;

                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~E:A96*/
                        /*~I:97*/
                        if (!InstructionDecoder_CheckNbParameters(2,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0);
                           Parameter[1].nLong = Communication_GetLongParameter(1);
                           /*~I:98*/
                           if (Parameter[0].nLong < 6)
                           /*~-1*/
                           {
                              /*~A:99*/
                              /*~+:Kalibrierfaktor auslesen*/
                              /*~T*/
                              // Kalibrierfaktor auslesen
                              Measurement_GetCalibrationFactor(WEIGHT_WEIGHTCHANNEL,&fCalibrationFactor);
                              /*~E:A99*/
                              /*~C:100*/
                              switch (Parameter[0].nLong)
                              /*~-1*/
                              {
                              /*~A:101*/
                              /*~+:Kennlinienaufnahme stoppen*/
                              /*~F:102*/
                              case 0x00:
                              /*~-1*/
                              {
                              /*~T*/
                              // Synchronistaionspr�fung einschalten
                              System_SetCheckSynchronisation(TRUE);
                              /*~T*/
                              Digital_Init();
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F102*/
                              /*~E:A101*/
                              /*~A:103*/
                              /*~+:komplette Kennlinienaufnahme*/
                              /*~F:104*/
                              case 0x01:	// komplette Kennlinienaufnahme
                              /*~-1*/
                              {
                              /*~T*/
                              // Synchronistaionspr�fung ausschalten
                              System_SetCheckSynchronisation(FALSE);
                              /*~T*/
                              MRW_Compensation_InitRecCharacteristics(fCalibrationFactor,MRW_COMPENSATION_MODE_REC_DRIFT|MRW_COMPENSATION_MODE_REC_CHARACTERISTICS|MRW_COMPENSATION_MODE_TEST_COMPENSATION);
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F104*/
                              /*~E:A103*/
                              /*~A:105*/
                              /*~+:komplette Kennlinienaufnahme ohne �berpr�fung*/
                              /*~F:106*/
                              case 0x02:	// komplette Kennlinienaufnahme ohne �berpr�fung
                              /*~-1*/
                              {
                              /*~T*/
                              // Synchronistaionspr�fung ausschalten
                              System_SetCheckSynchronisation(FALSE);
                              /*~T*/
                              MRW_Compensation_InitRecCharacteristics(fCalibrationFactor,MRW_COMPENSATION_MODE_REC_DRIFT|MRW_COMPENSATION_MODE_REC_CHARACTERISTICS);
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F106*/
                              /*~E:A105*/
                              /*~A:107*/
                              /*~+:Kennlinienaufnahme ohne Drift und ohne �berpr�fung*/
                              /*~F:108*/
                              case 0x03:	// Kennlinienaufnahme ohne Drift und ohne �berpr�fung
                              /*~-1*/
                              {
                              /*~T*/
                              // Synchronistaionspr�fung ausschalten
                              System_SetCheckSynchronisation(FALSE);
                              /*~T*/
                              MRW_Compensation_InitRecCharacteristics(fCalibrationFactor,MRW_COMPENSATION_MODE_REC_CHARACTERISTICS);
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F108*/
                              /*~E:A107*/
                              /*~A:109*/
                              /*~+:�berpr�fung der Temperaturkompensation*/
                              /*~F:110*/
                              case 4:
                              /*~-1*/
                              {
                              /*~T*/
                              // Synchronistaionspr�fung ausschalten
                              System_SetCheckSynchronisation(FALSE);
                              /*~T*/
                              MRW_Compensation_InitRecCharacteristics(fCalibrationFactor,MRW_COMPENSATION_MODE_TEST_COMPENSATION);
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F110*/
                              /*~E:A109*/
                              /*~A:111*/
                              /*~+:�berpr�fung der Temperaturkompensation - nur f�r SW-Entwicklung*/
                              /*~F:112*/
                              case 5:
                              /*~-1*/
                              {
                              /*~T*/
                              // Synchronistaionspr�fung ausschalten
                              System_SetCheckSynchronisation(FALSE);
                              /*~T*/
                              MRW_Compensation_InitRecCharacteristics(fCalibrationFactor,MRW_COMPENSATION_TEST_1);
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F112*/
                              /*~E:A111*/
                              /*~-1*/
                              }
                              /*~E:C100*/
                              /*~I:113*/
                              if (Parameter[1].nLong)
                              /*~-1*/
                              {
                              /*~T*/
                              // mit zyklischer Ausgabe
                              Compensation_SuppressOutput(0);
                              /*~-1*/
                              }
                              /*~O:I113*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              // Zyklische Ausgabe unterdr�cken
                              Compensation_SuppressOutput(1);
                              /*~-1*/
                              }
                              /*~E:I113*/
                              /*~I:114*/
                              if (!GET_RESPONSE)
                              /*~-1*/
                              {
                              /*~I:115*/
                              if (!Parameter[0].nLong)
                              /*~-1*/
                              {
                              /*~T*/
                              // Kennlinienaufnahme stoppen
                              MRW_Compensation_SetRecCharacteristicsOn(0);

                              System_SetSystemState(SYSTEM_RUNNING);
                              /*~A:116*/
                              /*~+:Eintrag in Diagnosespeicher vornehmen*/
                              /*~T*/
                              ulDiagnosisEntry2Set = DIAGNOSIS_MESSAGE_TEMPCOMPENSATION_STOPPED;
                              /*~E:A116*/
                              /*~-1*/
                              }
                              /*~O:I115*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              // Kennlinienaufnahme starten
                              MRW_Compensation_SetRecCharacteristicsOn(1);

                              System_SetSystemState(SYSTEM_REC_CHARACTERISTICS_ON);

                              /*~A:117*/
                              /*~+:Eintrag in Diagnosespeicher vornehmen*/
                              /*~T*/
                              ulDiagnosisEntry2Set = DIAGNOSIS_MESSAGE_TEMPCOMPENSATION_STARTED;
                              /*~E:A117*/
                              /*~-1*/
                              }
                              /*~E:I115*/
                              /*~A:118*/
                              /*~+:Ausf�hrungsstatus auf 'OKAY' setzen*/
                              /*~+:*/
                              /*~T*/
                              // Ausf�hrungsstatus auf 'OKAY' setzen
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              /*~E:A118*/
                              /*~A:119*/
                              /*~+:Kanal 0*/
                              /*~I:120*/
#ifdef CHANNEL_0
                              /*~I:121*/
                              if (!Parameter[0].nLong)
                              /*~-1*/
                              {
                              /*~T*/
                              // Textausgabe vornehmen
                              lText2Send = TEXT_STOP_REC_CHARACTERISTICS;
                              /*~-1*/
                              }
                              /*~O:I121*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              // Textausgabe vornehmen
                              lText2Send = TEXT_START_REC_CHARACTERISTICS;
                              /*~-1*/
                              }
                              /*~E:I121*/
                              /*~-1*/
#endif
                              /*~E:I120*/
                              /*~E:A119*/
                              /*~-1*/
                              }
                              /*~O:I114*/
                              /*~-2*/
                              else
                              {
                              /*~K*/
                              /*~+:Fehler !!!*/
                              /*~I:122*/
#ifdef CHANNEL_0
                              /*~A:123*/
                              /*~+:Kennlinienaufnahme im Kanal 1 zus�tzlich stoppen*/
                              /*~U:124*/
                              /*~-2*/
                              do
                              {
                              /*~T*/
                              Communication_SendSPICommand("iART");
                              /*~-1*/
                              }
                              /*~O:U124*/
                              while (!Communication_IsOK() && --byCounter);
                              /*~E:U124*/
                              /*~E:A123*/
                              /*~A:125*/
                              /*~+:Ausf�hrungsstatus auf 'E005' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A125*/
                              /*~-1*/
#endif
                              /*~E:I122*/
                              /*~-1*/
                              }
                              /*~E:I114*/
                           /*~-1*/
                           }
                           /*~O:I98*/
                           /*~-2*/
                           else
                           {
                              /*~A:126*/
                              /*~+:Kanal 0*/
                              /*~I:127*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I127*/
                              /*~E:A126*/
                           /*~-1*/
                           }
                           /*~E:I98*/
                        /*~-1*/
                        }
                        /*~O:I97*/
                        /*~-2*/
                        else
                        {
                           /*~A:128*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A128*/
                        /*~-1*/
                        }
                        /*~E:I97*/
                     /*~-1*/
                     }
                     /*~E:I94*/
                     /*~E:A93*/
                     /*~T*/
                     break;
                  /*~-1*/
                  }
                  /*~E:F63*/
                  /*~E:A62*/
                  /*~A:129*/
                  /*~+:C*/
                  /*~F:130*/
                  case 'C':
                  /*~-1*/
                  {
                     /*~A:131*/
                     /*~+:CAA - ClearActualAlarmstatus*/
                     /*~I:132*/
                     if (!strcmp(szCommand,"CAA"))
                     /*~-1*/
                     {
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:133*/
                        if (!InstructionDecoder_CheckNbParameters(0,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~I:134*/
                           if (!GET_RESPONSE)
                           /*~-1*/
                           {
                              /*~T*/
                              // System in den normalen Betriebsmodus versetzen
                              System_ClearSystemError();
                              /*~A:135*/
                              /*~+:Ausf�hrungsstatus auf 'OKAY' setzen*/
                              /*~+:*/
                              /*~T*/
                              // Ausf�hrungsstatus auf 'OKAY' setzen
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              /*~E:A135*/
                              /*~A:136*/
                              /*~+:Kanal 0*/
                              /*~I:137*/
#ifdef CHANNEL_0
                              /*~A:138*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              lText2Send = TEXT_ALARM_STATUS_CLEARED;
                              /*~E:A138*/
                              /*~-1*/
#endif
                              /*~E:I137*/
                              /*~E:A136*/
                           /*~-1*/
                           }
                           /*~O:I134*/
                           /*~-2*/
                           else
                           {
                              /*~K*/
                              /*~+:Fehler !!!*/
                              /*~A:139*/
                              /*~+:Ausf�hrungsstatus auf 'E005' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A139*/
                           /*~-1*/
                           }
                           /*~E:I134*/
                        /*~-1*/
                        }
                        /*~O:I133*/
                        /*~-2*/
                        else
                        {
                           /*~A:140*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A140*/
                        /*~-1*/
                        }
                        /*~E:I133*/
                     /*~-1*/
                     }
                     /*~E:I132*/
                     /*~E:A131*/
                     /*~A:141*/
                     /*~+:CAS - ClearAlarmStatus*/
                     /*~I:142*/
                     if (!strcmp(szCommand,"CAS"))
                     /*~-1*/
                     {
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:143*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0);
                           /*~A:144*/
                           /*~+:Kanal 1 - ADMINCODE automatisch vorgeben*/
                           /*~I:145*/
#ifdef CHANNEL_1
                           /*~T*/
                           Parameter[0].nLong = ADMINCODE;
                           /*~-1*/
#endif
                           /*~E:I145*/
                           /*~E:A144*/
                           /*~I:146*/
                           if (
                           	(Parameter[0].nLong == ADMINCODE)			// Passwort
                           	||
                           	(Parameter[0].nLong = 1399)
                           )
                           /*~-1*/
                           {
                              /*~I:147*/
                              if (!GET_RESPONSE)
                              /*~-1*/
                              {
                              /*~T*/
                              Diagnosis_ClearDiagnosis(DIAGNOSIS_CLEAR_ALL);
                              /*~T*/
                              // System in den normalen Betriebsmodus versetzen
                              System_ClearSystemError();
                              /*~A:148*/
                              /*~+:Ausf�hrungsstatus auf 'OKAY' setzen*/
                              /*~+:*/
                              /*~T*/
                              // Ausf�hrungsstatus auf 'OKAY' setzen
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              /*~E:A148*/
                              /*~A:149*/
                              /*~+:Kanal 0 - Textausgabe*/
                              /*~I:150*/
#ifdef CHANNEL_0 
                              /*~A:151*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              lText2Send = TEXT_DIAGNOSIS_MEMORY_CLEARED;
                              /*~E:A151*/
                              /*~-1*/
#endif
                              /*~E:I150*/
                              /*~E:A149*/
                              /*~-1*/
                              }
                              /*~O:I147*/
                              /*~-2*/
                              else
                              {
                              /*~K*/
                              /*~+:Fehler !!!*/
                              /*~A:152*/
                              /*~+:Ausf�hrungsstatus auf 'E005' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A152*/
                              /*~-1*/
                              }
                              /*~E:I147*/
                           /*~-1*/
                           }
                           /*~O:I146*/
                           /*~-2*/
                           else
                           {
                              /*~K*/
                              /*~+:// Parameterfehler*/
                              /*~A:153*/
                              /*~+:Kanal 0*/
                              /*~I:154*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E002;
                              /*~-1*/
#endif
                              /*~E:I154*/
                              /*~E:A153*/
                              /*~A:155*/
                              /*~+:Kanal 1 - NAK ausgeben*/
                              /*~I:156*/
#ifdef CHANNEL_1
                              /*~T*/
                              Communication_SendMessage(COMMUNICATION_SPI,COMMUNICATION_NAK);
                              /*~-1*/
#endif
                              /*~E:I156*/
                              /*~E:A155*/
                           /*~-1*/
                           }
                           /*~E:I146*/
                        /*~-1*/
                        }
                        /*~O:I143*/
                        /*~-2*/
                        else
                        {
                           /*~A:157*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A157*/
                        /*~-1*/
                        }
                        /*~E:I143*/
                     /*~-1*/
                     }
                     /*~E:I142*/
                     /*~E:A141*/
                     /*~A:158*/
                     /*~+:CDB - ClearDeBug*/
                     /*~I:159*/
#ifdef MIT_DEBUG
                     /*~I:160*/
                     if (!strcmp(szCommand,"CDB"))
                     /*~-1*/
                     {
                        /*~A:161*/
                        /*~+:Variablendeklarationen*/
                        /*~T*/
                        long lDebVar[DEBUG_NB_DEBUGVARIABLES];
                        /*~E:A161*/
                        /*~A:162*/
                        /*~+:Variableninitialisierungen*/
                        /*~T*/

                        /*~E:A162*/
                        /*~T*/
                        // Text wurde bereits gesendet
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:163*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0);
                           Parameter[1].nLong = Communication_GetLongParameter(1);
                           /*~C:164*/
                           switch (Parameter[0].nLong)
                           /*~-1*/
                           {
                              /*~F:165*/
                              case 0:
                              /*~-1*/
                              {
                              /*~A:166*/
                              /*~+:Kanal 0*/
                              /*~I:167*/
#ifdef CHANNEL_0
                              /*~I:168*/
                              if (Parameter[1].nLong == 255)
                              /*~-1*/
                              {
                              /*~T*/
                              memset(lDebVar,0,32);
                              /*~T*/
                              Communication_SendString(COMMUNICATION_RS232,T_TEXT_CONTENT_DEBUG_VARIABLES_CLEARED_ALL_CHANNEL_0,1,0);
                              /*~-1*/
                              }
                              /*~O:I168*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              // Debug-Variablen aus dem Eeprom laden
                              Load_Parameter(LOAD_SAVE_DEBUG_VARIABLES,lDebVar,4*DEBUG_NB_DEBUGVARIABLES);
                              /*~T*/
                              lDebVar[Parameter[1].nLong] = 0;
                              /*~T*/
                              // Text
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_CONFIRMATION_DEBUG_VARIABLES_CLEARED_CHANNEL_0,Parameter[1].nLong,1,0);
                              /*~-1*/
                              }
                              /*~E:I168*/
                              /*~T*/
                              // Debug-Variablen in das Eeprom schreiben
                              Save_Parameter(LOAD_SAVE_DEBUG_VARIABLES,lDebVar,4*DEBUG_NB_DEBUGVARIABLES);
                              /*~-1*/
#endif
                              /*~E:I167*/
                              /*~E:A166*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F165*/
                              /*~F:169*/
                              case 1:
                              /*~-1*/
                              {
                              /*~A:170*/
                              /*~+:Kanal 1*/
                              /*~I:171*/
#ifdef CHANNEL_1
                              /*~I:172*/
                              if (Parameter[1].nLong == 255)
                              /*~-1*/
                              {
                              /*~T*/
                              memset(lDebVar,0,32);
                              /*~T*/
                              Communication_SendString(COMMUNICATION_RS232,T_TEXT_CONTENT_DEBUG_VARIABLES_CLEARED_ALL_CHANNEL_1,1,0);
                              /*~-1*/
                              }
                              /*~O:I172*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              // Debug-Variablen aus dem Eeprom laden
                              Load_Parameter(LOAD_SAVE_DEBUG_VARIABLES,lDebVar,4*DEBUG_NB_DEBUGVARIABLES);
                              /*~T*/
                              lDebVar[Parameter[1].nLong] = 0;
                              /*~T*/
                              // Text
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_CONFIRMATION_DEBUG_VARIABLES_CLEARED_CHANNEL_1,Parameter[1].nLong,1,0);
                              /*~-1*/
                              }
                              /*~E:I172*/
                              /*~T*/
                              // Debug-Variablen in das Eeprom schreiben
                              Save_Parameter(LOAD_SAVE_DEBUG_VARIABLES,lDebVar,4*DEBUG_NB_DEBUGVARIABLES);
                              /*~-1*/
#endif
                              /*~E:I171*/
                              /*~E:A170*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F169*/
                              /*~O:C164*/
                              /*~-2*/
                              default:
                              {
                              /*~A:173*/
                              /*~+:Kanal 0*/
                              /*~I:174*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I174*/
                              /*~E:A173*/
                              /*~-1*/
                              }
                           /*~-1*/
                           }
                           /*~E:C164*/
                        /*~-1*/
                        }
                        /*~O:I163*/
                        /*~-2*/
                        else
                        {
                           /*~A:175*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A175*/
                        /*~-1*/
                        }
                        /*~E:I163*/
                     /*~-1*/
                     }
                     /*~E:I160*/
                     /*~-1*/
#endif
                     /*~E:I159*/
                     /*~E:A158*/
                     /*~I:176*/
#ifdef MOF
                     /*~A:177*/
                     /*~+:CDG - ClearDiaGnosis*/
                     /*~I:178*/
                     if ((!strcmp(szCommand,"CAS"))||(!strcmp(szCommand,"CDG")))
                     /*~-1*/
                     {
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:179*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0);
                           /*~A:180*/
                           /*~+:Kanal 1 - ADMINCODE automatisch vorgeben*/
                           /*~I:181*/
#ifdef CHANNEL_1
                           /*~T*/
                           Parameter[0].nLong = ADMINCODE;
                           /*~-1*/
#endif
                           /*~E:I181*/
                           /*~E:A180*/
                           /*~I:182*/
                           if (
                           	(Parameter[0].nLong == ADMINCODE)			// Passwort
                           	||
                           	(Parameter[0].nLong = 1399)
                           )
                           /*~-1*/
                           {
                              /*~I:183*/
                              if (!GET_RESPONSE)
                              /*~-1*/
                              {
                              /*~T*/
                              Diagnosis_ClearDiagnosis(DIAGNOSIS_CLEAR_ALL);
                              /*~T*/
                              // System in den normalen Betriebsmodus versetzen
                              System_ClearSystemError();
                              /*~A:184*/
                              /*~+:Ausf�hrungsstatus auf 'OKAY' setzen*/
                              /*~+:*/
                              /*~T*/
                              // Ausf�hrungsstatus auf 'OKAY' setzen
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              /*~E:A184*/
                              /*~A:185*/
                              /*~+:Kanal 0 - Textausgabe*/
                              /*~I:186*/
#ifdef CHANNEL_0 
                              /*~A:187*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              lText2Send = TEXT_DIAGNOSIS_MEMORY_CLEARED;
                              /*~E:A187*/
                              /*~-1*/
#endif
                              /*~E:I186*/
                              /*~E:A185*/
                              /*~-1*/
                              }
                              /*~O:I183*/
                              /*~-2*/
                              else
                              {
                              /*~K*/
                              /*~+:Fehler !!!*/
                              /*~A:188*/
                              /*~+:Ausf�hrungsstatus auf 'E005' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A188*/
                              /*~-1*/
                              }
                              /*~E:I183*/
                           /*~-1*/
                           }
                           /*~O:I182*/
                           /*~-2*/
                           else
                           {
                              /*~K*/
                              /*~+:// Parameterfehler*/
                              /*~A:189*/
                              /*~+:Kanal 0*/
                              /*~I:190*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E002;
                              /*~-1*/
#endif
                              /*~E:I190*/
                              /*~E:A189*/
                              /*~A:191*/
                              /*~+:Kanal 1 - NAK ausgeben*/
                              /*~I:192*/
#ifdef CHANNEL_1
                              /*~T*/
                              Communication_SendMessage(COMMUNICATION_SPI,COMMUNICATION_NAK);
                              /*~-1*/
#endif
                              /*~E:I192*/
                              /*~E:A191*/
                           /*~-1*/
                           }
                           /*~E:I182*/
                        /*~-1*/
                        }
                        /*~O:I179*/
                        /*~-2*/
                        else
                        {
                           /*~A:193*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A193*/
                        /*~-1*/
                        }
                        /*~E:I179*/
                     /*~-1*/
                     }
                     /*~E:I178*/
                     /*~E:A177*/
                     /*~-1*/
#endif
                     /*~E:I176*/
                     /*~A:194*/
                     /*~+:CDL - Connect2DockLight*/
                     /*~I:195*/
                     if (!strcmp(szCommand,"CDL"))
                     /*~-1*/
                     {
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:196*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0);
                           /*~I:197*/
                           if (!Parameter[0].nLong)
                           /*~-1*/
                           {
                              /*~K*/
                              /*~+:// Docklight-Modus ausschalten*/
                              /*~T*/
                              System_Connect2MRW_Manager(1);
                              /*~A:198*/
                              /*~+:Textausgabe �ber Kanal 0*/
                              /*~I:199*/
#ifdef CHANNEL_0
                              /*~T*/
                              // Communication_SendString(COMMUNICATION_RS232,TEXT_DOCKLIGHT_MODE_CLEARED,0,1);
                              Communication_SendString(COMMUNICATION_RS232,T_TEXT_3_OKAY,0,1);
                              /*~-1*/
#endif
                              /*~E:I199*/
                              /*~E:A198*/
                           /*~-1*/
                           }
                           /*~O:I197*/
                           /*~-2*/
                           else
                           {
                              /*~K*/
                              /*~+:// Docklight-Modus einschalten*/
                              /*~T*/
                              System_Connect2MRW_Manager(0);
                              /*~A:200*/
                              /*~+:Textausgabe �ber Kanal 0*/
                              /*~I:201*/
#ifdef CHANNEL_0
                              /*~T*/
                              Communication_SendString(COMMUNICATION_RS232,T_TEXT_DOCKLIGHT_MODE_SET,1,1);
                              /*~-1*/
#endif
                              /*~E:I201*/
                              /*~E:A200*/
                           /*~-1*/
                           }
                           /*~E:I197*/
                        /*~-1*/
                        }
                        /*~O:I196*/
                        /*~-2*/
                        else
                        {
                           /*~A:202*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A202*/
                        /*~-1*/
                        }
                        /*~E:I196*/
                     /*~-1*/
                     }
                     /*~E:I195*/
                     /*~E:A194*/
                     /*~I:203*/
#ifdef MOF
                     /*~A:204*/
                     /*~+:CEI,CEK,CRI - ClearEepromId*/
                     /*~I:205*/
                     if ((!strcmp(szCommand,"CEI"))||(!strcmp(szCommand,"CEK"))||(!strcmp(szCommand,"CRI")))
                     /*~-1*/
                     {
                        /*~A:206*/
                        /*~+:Variablendeklarationen*/
                        /*~T*/
                        unsigned long ulID;
                        /*~E:A206*/
                        /*~A:207*/
                        /*~+:Variableninitialisierungen*/
                        /*~T*/
                        ulID = 0L;

                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~E:A207*/
                        /*~I:208*/
                        if (!InstructionDecoder_CheckNbParameters(0,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~I:209*/
                           if (!GET_RESPONSE)
                           /*~-1*/
                           {
                              /*~A:210*/
                              /*~+:ausgeklammert - hier besteht die M�glichkeit, das Eeprom als jungfr�ulich zu deklarieren - es wird auch die ID gel�scht !!!*/
                              /*~I:211*/
#ifdef MOF
                              /*~I:212*/
                              if (!strcmp(szCommand,"CRI"))
                              /*~-1*/
                              {
                              /*~T*/
                              // Kennung zur Neuinitialisierung setzen
                              ulID = 0xAAAA5555;
                              /*~-1*/
                              }
                              /*~O:I212*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              // Kennung l�schen - System jungfr�ulich
                              ulID = 0;
                              /*~-1*/
                              }
                              /*~E:I212*/
                              /*~-1*/
#endif
                              /*~E:I211*/
                              /*~E:A210*/
                              /*~T*/
                              Save_Parameter(LOAD_SAVE_INITIALIZE_IDENTIFICATION,&ulID,0);
                              /*~A:213*/
                              /*~+:Ausf�hrungsstatus auf 'OKAY' setzen*/
                              /*~+:*/
                              /*~T*/
                              // Ausf�hrungsstatus auf 'OKAY' setzen
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              /*~E:A213*/
                              /*~A:214*/
                              /*~+:Kanal 0 - Textausgabe*/
                              /*~I:215*/
#ifdef CHANNEL_0
                              /*~A:216*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              lText2Send = TEXT_RESTART_HARDWARE;
                              /*~E:A216*/
                              /*~-1*/
#endif
                              /*~E:I215*/
                              /*~E:A214*/
                           /*~-1*/
                           }
                           /*~O:I209*/
                           /*~-2*/
                           else
                           {
                              /*~K*/
                              /*~+:Fehler !!!*/
                              /*~A:217*/
                              /*~+:Ausf�hrungsstatus auf 'E005' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A217*/
                           /*~-1*/
                           }
                           /*~E:I209*/
                        /*~-1*/
                        }
                        /*~O:I208*/
                        /*~-2*/
                        else
                        {
                           /*~A:218*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A218*/
                        /*~-1*/
                        }
                        /*~E:I208*/
                     /*~-1*/
                     }
                     /*~E:I205*/
                     /*~E:A204*/
                     /*~-1*/
#endif
                     /*~E:I203*/
                     /*~A:219*/
                     /*~+:CEK - ClearEepromKennung*/
                     /*~I:220*/
                     if (!strcmp(szCommand,"CEK"))
                     /*~-1*/
                     {
                        /*~A:221*/
                        /*~+:Variablendeklarationen*/
                        /*~T*/
                        unsigned long ulID;
                        /*~E:A221*/
                        /*~A:222*/
                        /*~+:Variableninitialisierungen*/
                        /*~T*/
                        ulID = 0L;

                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~E:A222*/
                        /*~I:223*/
                        if (!InstructionDecoder_CheckNbParameters(0,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~I:224*/
                           if (!GET_RESPONSE)
                           /*~-1*/
                           {
                              /*~A:225*/
                              /*~+:ausgeklammert - hier besteht die M�glichkeit, das Eeprom als jungfr�ulich zu deklarieren - es wird auch die ID gel�scht !!!*/
                              /*~I:226*/
#ifdef MOF
                              /*~I:227*/
                              if (!strcmp(szCommand,"CRI"))
                              /*~-1*/
                              {
                              /*~T*/
                              // Kennung zur Neuinitialisierung setzen
                              ulID = 0xAAAA5555;
                              /*~-1*/
                              }
                              /*~O:I227*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              // Kennung l�schen - System jungfr�ulich
                              ulID = 0;
                              /*~-1*/
                              }
                              /*~E:I227*/
                              /*~-1*/
#endif
                              /*~E:I226*/
                              /*~E:A225*/
                              /*~T*/
                              Save_Parameter(LOAD_SAVE_INITIALIZE_IDENTIFICATION,&ulID,0);
                              /*~A:228*/
                              /*~+:Ausf�hrungsstatus auf 'OKAY' setzen*/
                              /*~+:*/
                              /*~T*/
                              // Ausf�hrungsstatus auf 'OKAY' setzen
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              /*~E:A228*/
                              /*~A:229*/
                              /*~+:Kanal 0 - Textausgabe*/
                              /*~I:230*/
#ifdef CHANNEL_0
                              /*~A:231*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              lText2Send = TEXT_RESTART_HARDWARE;
                              /*~E:A231*/
                              /*~-1*/
#endif
                              /*~E:I230*/
                              /*~E:A229*/
                           /*~-1*/
                           }
                           /*~O:I224*/
                           /*~-2*/
                           else
                           {
                              /*~K*/
                              /*~+:Fehler !!!*/
                              /*~A:232*/
                              /*~+:Ausf�hrungsstatus auf 'E005' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A232*/
                           /*~-1*/
                           }
                           /*~E:I224*/
                        /*~-1*/
                        }
                        /*~O:I223*/
                        /*~-2*/
                        else
                        {
                           /*~A:233*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A233*/
                        /*~-1*/
                        }
                        /*~E:I223*/
                     /*~-1*/
                     }
                     /*~E:I220*/
                     /*~E:A219*/
                     /*~A:234*/
                     /*~+:CIC - CurrentInterfaceCalibration*/
                     /*~I:235*/
                     if (!strcmp(szCommand,"CIC"))
                     /*~-1*/
                     {
                        /*~A:236*/
                        /*~+:Variablendeklarationen*/
                        /*~I:237*/
#ifdef SYSTEM_CND_WITH_DEADBAND_FILTER
                        /*~T*/
                        int nBandWidth;
                        /*~-1*/
#endif
                        /*~E:I237*/
                        /*~E:A236*/
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:238*/
                        if (!InstructionDecoder_CheckNbParameters(3,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           // Parameter einlesen
                           Parameter[0].nLong = Communication_GetLongParameter(0);
                           Parameter[1].nLong = Communication_GetLongParameter(1);

                           /*~T*/
                           Parameter[2].fFloat = Communication_GetFloatParameter(2);
                           /*~C:239*/
                           switch (Parameter[0].nLong)
                           /*~-1*/
                           {
                              /*~F:240*/
                              case 0:
                              /*~-1*/
                              {
                              /*~A:241*/
                              /*~+:Kanal 0*/
                              /*~I:242*/
#ifdef CHANNEL_0
                              /*~C:243*/
                              switch (Parameter[1].nLong)
                              /*~-1*/
                              {
                              /*~A:244*/
                              /*~+:Initialisierung */
                              /*~F:245*/
                              case 0:		// Initialisierung
                              /*~-1*/
                              {
                              /*~I:246*/
#ifndef OHNE_STROMRUECKFUEHRUNG 
                              /*~A:247*/
                              /*~+:Mitteilung, dass die Stromr�ckf�hrung ausgeschaltet wurde*/
                              /*~I:248*/
                              if (!SYSTEM_MRW_MANAGER)
                              /*~-1*/
                              {
                              /*~T*/
                              // Mitteilung, dass die Stromr�ckf�hrung ausgeschaltet wurde
                              Communication_SendString(COMMUNICATION_RS232,T_TEXT_FEEDBACK_STATE_OFF,1,0);

                              /*~-1*/
                              }
                              /*~E:I248*/
                              /*~E:A247*/
                              /*~T*/
                              // Stromr�ckf�hrung ausschalten
                              CurrentInterface_SetFeedBackOnOff(0,0);
                              /*~-1*/
#endif
                              /*~E:I246*/
                              /*~I:249*/
#ifdef SYSTEM_CND_WITH_DEADBAND_FILTER
                              /*~A:250*/
                              /*~+:Totbandfilter-Bandbreite f�r die Gewichtsermittlung ausschalten*/
                              /*~T*/
                              // Totbandfilter-Bandbreite f�r die Gewichtsermittlung ausschalten
                              DeadBandFilter_Setup(0,0,DEADBANDFILTER_LONGDATA);

                              /*~E:A250*/
                              /*~-1*/
#endif
                              /*~E:I249*/
                              /*~T*/
                              CurrentInterface_Ini(0);
                              /*~T*/
                              ulDiagnosisEntry2Set = DIAGNOSIS_MESSAGE_DAC_CALIBRATION_CLEARED;
                              /*~A:251*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              lText2Send = TEXT_CURRENT_INTERFACE_INITIALIZED_CHANNEL_0;
                              /*~E:A251*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F245*/
                              /*~E:A244*/
                              /*~A:252*/
                              /*~+:Vorbereitung f�r 1.Referenzpunkt*/
                              /*~F:253*/
                              case 1:		// Vorbereitung f�r 1.Referenzpunkt
                              /*~-1*/
                              {
                              /*~T*/
                              CurrentInterface_PrepareCalibration(1,Parameter[2].fFloat);
                              /*~A:254*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              lText2Send = TEXT_CURRENT_INTERFACE_PREPARE_4_CAL_1ST_POINT_CHANNEL_0;
                              /*~E:A254*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F253*/
                              /*~E:A252*/
                              /*~A:255*/
                              /*~+:Ersten Referenzpunkt setzen*/
                              /*~F:256*/
                              case 2:		// Ersten Referenzpunkt setzen
                              /*~-1*/
                              {
                              /*~T*/
                              CurrentInterface_Calibration(0,Parameter[2].fFloat);
                              /*~A:257*/
                              /*~+:Eintrag in Diagnosespeicher vornehmen*/
                              /*~T*/
                              ulDiagnosisEntry2Set = DIAGNOSIS_MESSAGE_DAC_1ST_POINT_CALIBRATION_SET;
                              /*~E:A257*/
                              /*~A:258*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              lText2Send = TEXT_CURRENT_INTERFACE_1ST_CAL_POINT_SET_CHANNEL_0;
                              /*~E:A258*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F256*/
                              /*~E:A255*/
                              /*~A:259*/
                              /*~+:Vorbereitung f�r 2.Referenzpunkt*/
                              /*~F:260*/
                              case 3:		// Vorbereitung f�r 2.Referenzpunkt
                              /*~-1*/
                              {
                              /*~T*/
                              CurrentInterface_PrepareCalibration(2,Parameter[2].fFloat);
                              /*~A:261*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              lText2Send = TEXT_CURRENT_INTERFACE_PREPARE_4_CAL_2ND_POINT_CHANNEL_0;
                              /*~E:A261*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F260*/
                              /*~E:A259*/
                              /*~A:262*/
                              /*~+:Zweiten Referenzpunkt setzen*/
                              /*~F:263*/
                              case 4:		// Zweiten Referenzpunkt setzen
                              /*~-1*/
                              {
                              /*~I:264*/
                              if(!CurrentInterface_Calibration(1,Parameter[2].fFloat))
                              /*~-1*/
                              {
                              /*~A:265*/
                              /*~+:Eintrag in Diagnosespeicher vornehmen*/
                              /*~T*/
                              ulDiagnosisEntry2Set = DIAGNOSIS_MESSAGE_DAC_2ND_POINT_CALIBRATION_SET;
                              /*~E:A265*/
                              /*~A:266*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              lText2Send = TEXT_CURRENT_INTERFACE_2ND_CAL_POINT_SET_CHANNEL_0;
                              /*~E:A266*/
                              /*~-1*/
                              }
                              /*~O:I264*/
                              /*~-2*/
                              else
                              {
                              /*~K*/
                              /*~+:Fehler*/
                              /*~A:267*/
                              /*~+:Text f�r Terminalbetrieb "E005"*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              lText2Send = TEXT_ERROR_1ST_REFPOINT_MISSING;
                              /*~E:A267*/
                              /*~-1*/
                              }
                              /*~E:I264*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F263*/
                              /*~E:A262*/
                              /*~A:268*/
                              /*~+:Kalibrierung speichern*/
                              /*~F:269*/
                              case 5:		// Kalibrierung speichern
                              /*~-1*/
                              {
                              /*~A:270*/
                              /*~+:Grenzwerte setzen*/
                              /*~T*/
                              // Grenzwerte setzen
                              Limit_SetAlarmLimits();
                              /*~E:A270*/
                              /*~I:271*/
#ifndef OHNE_STROMRUECKFUEHRUNG 
                              /*~A:272*/
                              /*~+:Strom-R�ckf�hrung aktivieren*/
                              /*~T*/
                              // Strom-R�ckf�hrung aktivieren
                              CurrentInterface_SetFeedBackOnOff(1,0);
                              /*~E:A272*/
                              /*~A:273*/
                              /*~+:Mitteilung, dass die Stromr�ckf�hrung eingeschaltet wurde*/
                              /*~I:274*/
                              if (!SYSTEM_MRW_MANAGER)
                              /*~-1*/
                              {
                              /*~T*/
                              // Mitteilung, dass die Stromr�ckf�hrung eingeschaltet wurde
                              Communication_SendString(COMMUNICATION_RS232,T_TEXT_FEEDBACK_STATE_ON,1,0);

                              /*~-1*/
                              }
                              /*~E:I274*/
                              /*~E:A273*/
                              /*~-1*/
#endif
                              /*~E:I271*/
                              /*~I:275*/
#ifdef SYSTEM_CND_WITH_DEADBAND_FILTER 
                              /*~A:276*/
                              /*~+:Totbandfilter-Bandbreite f�r die Gewichtsermittlung wieder in Ursprungszustand versetzen*/
                              /*~T*/
                              // Totbandfilter-Bandbreite f�r die Gewichtsermittlung laden
                              Load_Parameter(LOAD_SAVE_FILTER_BANDWIDTH_WEIGHT,&nBandWidth,0);

                              DeadBandFilter_Setup(0,(float)nBandWidth,DEADBANDFILTER_LONGDATA);

                              /*~E:A276*/
                              /*~-1*/
#endif
                              /*~E:I275*/
                              /*~A:277*/
                              /*~+:Eintrag in Diagnosespeicher vornehmen*/
                              /*~T*/
                              ulDiagnosisEntry2Set = DIAGNOSIS_MESSAGE_DAC_CALIBRATION_FINISHED;
                              /*~E:A277*/
                              /*~T*/
                              CurrentInterface_SaveDACSettings(CURRENTINTERFACE_ALL_SETTINGS);
                              /*~T*/
                              // Simulation des Rohmesswerts ausschalten
                              CurrentInterface_PrepareCalibration(0,0);
                              /*~A:278*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              /*~T*/
                              lText2Send = TEXT_CURRENT_INTERFACE_CALIBRATION_FINISHED_CHANNEL_0;
                              /*~E:A278*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F269*/
                              /*~E:A268*/
                              /*~O:C243*/
                              /*~-2*/
                              default:
                              {
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E002;
                              /*~-1*/
                              }
                              /*~-1*/
                              }
                              /*~E:C243*/
                              /*~-1*/
#endif
                              /*~E:I242*/
                              /*~T*/
                              break;
                              /*~E:A241*/
                              /*~-1*/
                              }
                              /*~E:F240*/
                              /*~F:279*/
                              case 1:
                              /*~-1*/
                              {
                              /*~A:280*/
                              /*~+:Kanal 1*/
                              /*~I:281*/
#ifdef CHANNEL_1 
                              /*~C:282*/
                              switch (Parameter[1].nLong)
                              /*~-1*/
                              {
                              /*~A:283*/
                              /*~+:Initialisierung*/
                              /*~F:284*/
                              case 0:		// Initialisierung
                              /*~-1*/
                              {
                              /*~I:285*/
#ifndef OHNE_STROMRUECKFUEHRUNG 
                              /*~A:286*/
                              /*~+:Mitteilung, dass die Stromr�ckf�hrung ausgeschaltet wurde*/
                              /*~I:287*/
                              if (!SYSTEM_MRW_MANAGER)
                              /*~-1*/
                              {
                              /*~T*/
                              // Mitteilung, dass die Stromr�ckf�hrung ausgeschaltet wurde
                              Communication_SendString(COMMUNICATION_RS232,T_TEXT_FEEDBACK_STATE_OFF,1,0);

                              /*~-1*/
                              }
                              /*~E:I287*/
                              /*~E:A286*/
                              /*~T*/
                              // Stromr�ckf�hrung ausschalten
                              CurrentInterface_SetFeedBackOnOff(0,0);
                              /*~-1*/
#endif
                              /*~E:I285*/
                              /*~I:288*/
#ifdef SYSTEM_CND_WITH_DEADBAND_FILTER
                              /*~A:289*/
                              /*~+:Totbandfilter-Bandbreite f�r die Gewichtsermittlung ausschalten*/
                              /*~T*/
                              // Totbandfilter-Bandbreite f�r die Gewichtsermittlung ausschalten
                              DeadBandFilter_Setup(0,0,DEADBANDFILTER_LONGDATA);

                              /*~E:A289*/
                              /*~-1*/
#endif
                              /*~E:I288*/
                              /*~T*/
                              CurrentInterface_Ini(0);
                              /*~A:290*/
                              /*~+:Eintrag in Diagnosespeicher vornehmen*/
                              /*~T*/
                              ulDiagnosisEntry2Set = DIAGNOSIS_MESSAGE_DAC_CALIBRATION_CLEARED;
                              /*~E:A290*/
                              /*~A:291*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              lText2Send = TEXT_CURRENT_INTERFACE_INITIALIZED_CHANNEL_1;
                              /*~E:A291*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F284*/
                              /*~E:A283*/
                              /*~A:292*/
                              /*~+:Vorbereitung f�r 1.Referenzpunkt*/
                              /*~F:293*/
                              case 1:		// Vorbereitung f�r 1.Referenzpunkt
                              /*~-1*/
                              {
                              /*~T*/
                              CurrentInterface_PrepareCalibration(1,Parameter[2].fFloat);
                              /*~A:294*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              lText2Send = TEXT_CURRENT_INTERFACE_PREPARE_4_CAL_1ST_POINT_CHANNEL_1;
                              /*~E:A294*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F293*/
                              /*~E:A292*/
                              /*~A:295*/
                              /*~+:Ersten Referenzpunkt setzen*/
                              /*~F:296*/
                              case 2:		// Ersten Referenzpunkt setzen
                              /*~-1*/
                              {
                              /*~I:297*/
                              if(!CurrentInterface_Calibration(0,Parameter[2].fFloat))
                              /*~-1*/
                              {
                              /*~A:298*/
                              /*~+:Eintrag in Diagnosespeicher vornehmen*/
                              /*~T*/
                              ulDiagnosisEntry2Set = DIAGNOSIS_MESSAGE_DAC_1ST_POINT_CALIBRATION_SET;
                              /*~E:A298*/
                              /*~A:299*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              lText2Send = TEXT_CURRENT_INTERFACE_1ST_CAL_POINT_SET_CHANNEL_1;
                              /*~E:A299*/
                              /*~-1*/
                              }
                              /*~O:I297*/
                              /*~-2*/
                              else
                              {
                              /*~K*/
                              /*~+:Fehler*/
                              /*~A:300*/
                              /*~+:Text f�r Terminalbetrieb "E005"*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              lText2Send = TEXT_ERROR_WEIGHT_INSTABILE;
                              /*~E:A300*/
                              /*~-1*/
                              }
                              /*~E:I297*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F296*/
                              /*~E:A295*/
                              /*~A:301*/
                              /*~+:Vorbereitung f�r 2.Referenzpunkt*/
                              /*~F:302*/
                              case 3:		// Vorbereitung f�r 2.Referenzpunkt
                              /*~-1*/
                              {
                              /*~T*/
                              CurrentInterface_PrepareCalibration(2,Parameter[2].fFloat);
                              /*~A:303*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              lText2Send = TEXT_CURRENT_INTERFACE_PREPARE_4_CAL_2ND_POINT_CHANNEL_1;
                              /*~E:A303*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F302*/
                              /*~E:A301*/
                              /*~A:304*/
                              /*~+:Zweiten Referenzpunkt setzen*/
                              /*~F:305*/
                              case 4:		// Zweiten Referenzpunkt setzen
                              /*~-1*/
                              {
                              /*~I:306*/
                              if(!CurrentInterface_Calibration(1,Parameter[2].fFloat))
                              /*~-1*/
                              {
                              /*~A:307*/
                              /*~+:Eintrag in Diagnosespeicher vornehmen*/
                              /*~T*/
                              ulDiagnosisEntry2Set = DIAGNOSIS_MESSAGE_DAC_2ND_POINT_CALIBRATION_SET;
                              /*~E:A307*/
                              /*~A:308*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              lText2Send = TEXT_CURRENT_INTERFACE_2ND_CAL_POINT_SET_CHANNEL_1;
                              /*~E:A308*/
                              /*~-1*/
                              }
                              /*~O:I306*/
                              /*~-2*/
                              else
                              {
                              /*~K*/
                              /*~+:Fehler*/
                              /*~A:309*/
                              /*~+:Text f�r Terminalbetrieb "E005"*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              lText2Send = TEXT_ERROR_WEIGHT_INSTABILE;
                              /*~E:A309*/
                              /*~-1*/
                              }
                              /*~E:I306*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F305*/
                              /*~E:A304*/
                              /*~A:310*/
                              /*~+:Kalibrierung speichern*/
                              /*~F:311*/
                              case 5:		// Kalibrierung speichern
                              /*~-1*/
                              {
                              /*~A:312*/
                              /*~+:Grenzwerte setzen*/
                              /*~T*/
                              // Grenzwerte setzen
                              Limit_SetAlarmLimits();
                              /*~E:A312*/
                              /*~I:313*/
#ifndef OHNE_STROMRUECKFUEHRUNG 
                              /*~A:314*/
                              /*~+:Stromr�ckf�hrung einschalten*/
                              /*~T*/
                              // Stromr�ckf�hrung einschalten
                              CurrentInterface_SetFeedBackOnOff(1,0);
                              /*~E:A314*/
                              /*~A:315*/
                              /*~+:Mitteilung, dass die Stromr�ckf�hrung eingeschaltet wurde*/
                              /*~I:316*/
                              if (!SYSTEM_MRW_MANAGER)
                              /*~-1*/
                              {
                              /*~T*/
                              // Mitteilung, dass die Stromr�ckf�hrung eingeschaltet wurde
                              Communication_SendString(COMMUNICATION_RS232,T_TEXT_FEEDBACK_STATE_ON,1,0);

                              /*~-1*/
                              }
                              /*~E:I316*/
                              /*~E:A315*/
                              /*~-1*/
#endif
                              /*~E:I313*/
                              /*~I:317*/
#ifdef SYSTEM_CND_WITH_DEADBAND_FILTER
                              /*~A:318*/
                              /*~+:Totbandfilter-Bandbreite f�r die Gewichtsermittlung wieder in Ursprungszustand versetzen*/
                              /*~T*/
                              // Totbandfilter-Bandbreite f�r die Gewichtsermittlung laden
                              Load_Parameter(LOAD_SAVE_FILTER_BANDWIDTH_WEIGHT,&nBandWidth,0);

                              DeadBandFilter_Setup(0,(float)nBandWidth,DEADBANDFILTER_LONGDATA);

                              /*~E:A318*/
                              /*~-1*/
#endif
                              /*~E:I317*/
                              /*~A:319*/
                              /*~+:Eintrag in Diagnosespeicher vornehmen*/
                              /*~T*/
                              ulDiagnosisEntry2Set = DIAGNOSIS_MESSAGE_DAC_CALIBRATION_FINISHED;
                              /*~E:A319*/
                              /*~T*/
                              CurrentInterface_SaveDACSettings(CURRENTINTERFACE_ALL_SETTINGS);
                              /*~T*/
                              // Simulation des Rohmesswerts ausschalten
                              CurrentInterface_PrepareCalibration(0,0);
                              /*~A:320*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              /*~T*/
                              lText2Send = TEXT_CURRENT_INTERFACE_CALIBRATION_FINISHED_CHANNEL_1;
                              /*~E:A320*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F311*/
                              /*~E:A310*/
                              /*~O:C282*/
                              /*~-2*/
                              default:
                              {
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E002;
                              /*~-1*/
                              }
                              /*~-1*/
                              }
                              /*~E:C282*/
                              /*~-1*/
#endif
                              /*~E:I281*/
                              /*~T*/
                              break;
                              /*~E:A280*/
                              /*~-1*/
                              }
                              /*~E:F279*/
                              /*~O:C239*/
                              /*~-2*/
                              default:
                              {
                              /*~A:321*/
                              /*~+:Kanal 0*/
                              /*~I:322*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I322*/
                              /*~E:A321*/
                              /*~-1*/
                              }
                           /*~-1*/
                           }
                           /*~E:C239*/
                        /*~-1*/
                        }
                        /*~O:I238*/
                        /*~-2*/
                        else
                        {
                           /*~A:323*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A323*/
                        /*~-1*/
                        }
                        /*~E:I238*/
                     /*~-1*/
                     }
                     /*~E:I235*/
                     /*~E:A234*/
                     /*~A:324*/
                     /*~+:CID - ClearsystemID*/
                     /*~I:325*/
                     if (!strcmp(szCommand,"CID"))
                     /*~-1*/
                     {
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~A:326*/
                        /*~+:Kanal 0*/
                        /*~I:327*/
#ifdef CHANNEL_0
                        /*~A:328*/
                        /*~+:Variablendeklarationen*/
                        /*~T*/

                        /*~E:A328*/
                        /*~I:329*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~I:330*/
                           if (Communication_GetLongParameter(0) == ADMINCODE)
                           /*~-1*/
                           {
                              /*~T*/
                              Global.ulSystemID = 0;

                              Save_Parameter(LOAD_SAVE_SYSTEM_ID,&Global.ulSystemID,4);
                              /*~A:331*/
                              /*~+:Eintrag im Diagnosespeicher vornehmen*/
                              /*~T*/
                              ulDiagnosisEntry2Set = DIAGNOSIS_WARNING_ID_CLEARED;
                              /*~E:A331*/
                              /*~A:332*/
                              /*~+:Textausgabe*/
                              /*~T*/
                              // Textausgabe
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              lText2Send = TEXT_ID_CLEARED;
                              /*~E:A332*/
                           /*~-1*/
                           }
                           /*~O:I330*/
                           /*~-2*/
                           else
                           {
                              /*~T*/
                              // Textausgabe
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;

                              lText2Send = TEXT_SYSTEM_CLEAR_ID_FAULT;
                           /*~-1*/
                           }
                           /*~E:I330*/
                        /*~-1*/
                        }
                        /*~O:I329*/
                        /*~-2*/
                        else
                        {
                           /*~A:333*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A333*/
                        /*~-1*/
                        }
                        /*~E:I329*/
                        /*~-1*/
#endif
                        /*~E:I327*/
                        /*~E:A326*/
                     /*~-1*/
                     }
                     /*~E:I325*/
                     /*~E:A324*/
                     /*~A:334*/
                     /*~+:CIF - CurrentInterfaceFeedback onoff*/
                     /*~I:335*/
                     if (!strcmp(szCommand,"CIF"))
                     /*~-1*/
                     {
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:336*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0); 
                           /*~I:337*/
                           if (!GET_RESPONSE)
                           /*~-1*/
                           {
                              /*~T*/
                              // Kanal best�tigte mit ACKNOWLEDGE
                              /*~I:338*/
                              if (Parameter[0].nLong)
                              /*~-1*/
                              {
                              /*~T*/
                              CurrentInterface_SetFeedBackOnOff(1,1);
                              /*~A:339*/
                              /*~+:Eintrag in Diagnosespeicher vornehmen*/
                              /*~T*/
                              ulDiagnosisEntry2Set = DIAGNOSIS_WARNING_DAC_FEEDBACK_SWITCHED_ON;
                              /*~E:A339*/
                              /*~A:340*/
                              /*~+:Ausf�hrungsstatus auf 'OKAY' setzen*/
                              /*~+:*/
                              /*~T*/
                              // Ausf�hrungsstatus auf 'OKAY' setzen
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              /*~E:A340*/
                              /*~A:341*/
                              /*~+:Kanal 0 - Textausgabe*/
                              /*~I:342*/
#ifdef CHANNEL_0 
                              /*~A:343*/
                              /*~+:Textausgabe �ber Kanal 0*/
                              /*~I:344*/
#ifdef CHANNEL_0
                              /*~T*/
                              lText2Send = TEXT_FEEDBACK_SWITCHED_ON;
                              /*~-1*/
#endif
                              /*~E:I344*/
                              /*~E:A343*/
                              /*~-1*/
#endif
                              /*~E:I342*/
                              /*~E:A341*/
                              /*~-1*/
                              }
                              /*~O:I338*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              CurrentInterface_SetFeedBackOnOff(0,1);
                              /*~A:345*/
                              /*~+:Eintrag in Diagnosespeicher vornehmen*/
                              /*~T*/
                              ulDiagnosisEntry2Set = DIAGNOSIS_WARNING_DAC_FEEDBACK_SWITCHED_OFF;
                              /*~E:A345*/
                              /*~A:346*/
                              /*~+:Ausf�hrungsstatus auf 'OKAY' setzen*/
                              /*~+:*/
                              /*~T*/
                              // Ausf�hrungsstatus auf 'OKAY' setzen
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              /*~E:A346*/
                              /*~A:347*/
                              /*~+:Kanal 0 - Textausgabe*/
                              /*~I:348*/
#ifdef CHANNEL_0 
                              /*~A:349*/
                              /*~+:Textausgabe �ber Kanal 0*/
                              /*~I:350*/
#ifdef CHANNEL_0
                              /*~T*/
                              lText2Send = TEXT_FEEDBACK_SWITCHED_OFF;
                              /*~-1*/
#endif
                              /*~E:I350*/
                              /*~E:A349*/
                              /*~-1*/
#endif
                              /*~E:I348*/
                              /*~E:A347*/
                              /*~-1*/
                              }
                              /*~E:I338*/
                           /*~-1*/
                           }
                           /*~O:I337*/
                           /*~-2*/
                           else
                           {
                              /*~K*/
                              /*~+:Fehler !!!*/
                              /*~A:351*/
                              /*~+:Ausf�hrungsstatus auf 'E005' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A351*/
                           /*~-1*/
                           }
                           /*~E:I337*/
                        /*~-1*/
                        }
                        /*~O:I336*/
                        /*~-2*/
                        else
                        {
                           /*~A:352*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A352*/
                        /*~-1*/
                        }
                        /*~E:I336*/
                     /*~-1*/
                     }
                     /*~E:I335*/
                     /*~E:A334*/
                     /*~A:353*/
                     /*~+:CIG - CurrentInterfacechangeGain*/
                     /*~I:354*/
                     if (!strcmp(szCommand,"CIG"))
                     /*~-1*/
                     {
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:355*/
                        if (!InstructionDecoder_CheckNbParameters(2,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0);
                           Parameter[1].fFloat = Communication_GetFloatParameter(1);
                           /*~C:356*/
                           switch (Parameter[0].nLong)
                           /*~-1*/
                           {
                              /*~F:357*/
                              case 0:
                              /*~-1*/
                              {
                              /*~A:358*/
                              /*~+:Kanal 0*/
                              /*~I:359*/
#ifdef CHANNEL_0
                              /*~T*/
                              // Offset in-/dekrementieren
                              ADuC836_DACChangeGainbyStep(Parameter[1].fFloat);
                              // und neue Einstellungen sichern
                              CurrentInterface_SaveDACSettings(CURRENTINTERFACE_ALL_SETTINGS);
                              /*~A:360*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              lText2Send = TEXT_CURRENT_INTERFACE_GAIN_CHANGED_CHANNEL_0;
                              /*~E:A360*/
                              /*~-1*/
#endif
                              /*~E:I359*/
                              /*~E:A358*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F357*/
                              /*~F:361*/
                              case 1:
                              /*~-1*/
                              {
                              /*~A:362*/
                              /*~+:Kanal 1*/
                              /*~I:363*/
#ifdef CHANNEL_1
                              /*~T*/
                              // Offset in-/dekrementieren
                              ADuC836_DACChangeGainbyStep(Parameter[1].fFloat);
                              // und neue Einstellungen sichern
                              CurrentInterface_SaveDACSettings(CURRENTINTERFACE_ALL_SETTINGS);
                              /*~A:364*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              lText2Send = TEXT_CURRENT_INTERFACE_GAIN_CHANGED_CHANNEL_1;
                              /*~E:A364*/
                              /*~-1*/
#endif
                              /*~E:I363*/
                              /*~E:A362*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F361*/
                              /*~O:C356*/
                              /*~-2*/
                              default:
                              {
                              /*~K*/
                              /*~+:// Parameterfehler*/
                              /*~A:365*/
                              /*~+:Kanal 0*/
                              /*~I:366*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I366*/
                              /*~E:A365*/
                              /*~-1*/
                              }
                           /*~-1*/
                           }
                           /*~E:C356*/
                        /*~-1*/
                        }
                        /*~O:I355*/
                        /*~-2*/
                        else
                        {
                           /*~A:367*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A367*/
                        /*~-1*/
                        }
                        /*~E:I355*/
                     /*~-1*/
                     }
                     /*~E:I354*/
                     /*~E:A353*/
                     /*~I:368*/
#ifndef OHNE_STROMRUECKFUEHRUNG
                     /*~A:369*/
                     /*~+:CII - CurrentInterfaceIntegralportion*/
                     /*~I:370*/
                     if (!strcmp(szCommand,"CII"))
                     /*~-1*/
                     {
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:371*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0); 
                           /*~I:372*/
                           if ((Parameter[0].nLong >= 0)&&(Parameter[0].nLong <= 100))
                           /*~-1*/
                           {
                              /*~T*/
                              // Parameter[0].nLong = 100 - Parameter[0].nLong;
                              /*~I:373*/
                              if (!GET_RESPONSE)
                              /*~-1*/
                              {
                              /*~T*/
                              // Kanal best�tigte mit ACKNOWLEDGE
                              /*~T*/
                              CurrentInterface_SetFeedBackIntegralPortion((char)Parameter[0].nLong);
                              /*~A:374*/
                              /*~+:Ausf�hrungsstatus auf 'OKAY' setzen*/
                              /*~+:*/
                              /*~T*/
                              // Ausf�hrungsstatus auf 'OKAY' setzen
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              /*~E:A374*/
                              /*~A:375*/
                              /*~+:Kanal 0 - Textausgabe*/
                              /*~I:376*/
#ifdef CHANNEL_0 
                              /*~A:377*/
                              /*~+:Textausgabe �ber Kanal 0*/
                              /*~I:378*/
#ifdef CHANNEL_0
                              /*~T*/
                              lText2Send = TEXT_FEEDBACK_INTEGRAL_PORTION_SET;
                              /*~-1*/
#endif
                              /*~E:I378*/
                              /*~E:A377*/
                              /*~-1*/
#endif
                              /*~E:I376*/
                              /*~E:A375*/
                              /*~-1*/
                              }
                              /*~O:I373*/
                              /*~-2*/
                              else
                              {
                              /*~K*/
                              /*~+:Fehler !!!*/
                              /*~A:379*/
                              /*~+:Ausf�hrungsstatus auf 'E005' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A379*/
                              /*~-1*/
                              }
                              /*~E:I373*/
                           /*~-1*/
                           }
                           /*~O:I372*/
                           /*~-2*/
                           else
                           {
                              /*~K*/
                              /*~+:Fehler - Wert au�erhalb des Bereichs !!!*/
                              /*~A:380*/
                              /*~+:Kanal 0 - Ausf�hrungsstatus auf 'E002' setzen*/
                              /*~I:381*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E002;
                              /*~-1*/
#endif
                              /*~E:I381*/
                              /*~E:A380*/
                           /*~-1*/
                           }
                           /*~E:I372*/
                        /*~-1*/
                        }
                        /*~O:I371*/
                        /*~-2*/
                        else
                        {
                           /*~A:382*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A382*/
                        /*~-1*/
                        }
                        /*~E:I371*/
                     /*~-1*/
                     }
                     /*~E:I370*/
                     /*~E:A369*/
                     /*~-1*/
#endif
                     /*~E:I368*/
                     /*~A:383*/
                     /*~+:CIM - CurrentInterfaceManualmode*/
                     /*~I:384*/
                     if (!strcmp(szCommand,"CIM"))
                     /*~-1*/
                     {
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:385*/
                        if (!InstructionDecoder_CheckNbParameters(2,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0);
                           Parameter[1].nLong = Communication_GetLongParameter(1);
                           /*~C:386*/
                           switch (Parameter[0].nLong)
                           /*~-1*/
                           {
                              /*~F:387*/
                              case 0:
                              /*~-1*/
                              {
                              /*~A:388*/
                              /*~+:Kanal 0*/
                              /*~I:389*/
#ifdef CHANNEL_0
                              /*~T*/
                              // Alles okay
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              /*~I:390*/
                              if (Parameter[1].nLong > -1)
                              /*~-1*/
                              {
                              /*~T*/
                              // DAC-Testmode aktiv setzen
                              CurrentInterface_SetManualMode(1,Parameter[1].nLong);
                              /*~A:391*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              lText2Send = TEXT_CURRENT_INTERFACE_MANUAL_MODE_ON_CHANNEL_0;
                              /*~E:A391*/
                              /*~-1*/
                              }
                              /*~O:I390*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              // DAC-Testmode inaktiv setzen
                              CurrentInterface_SetManualMode(0,Parameter[1].nLong);
                              /*~A:392*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              lText2Send = TEXT_CURRENT_INTERFACE_MANUAL_MODE_OFF_CHANNEL_0;
                              /*~E:A392*/
                              /*~-1*/
                              }
                              /*~E:I390*/
                              /*~-1*/
#endif
                              /*~E:I389*/
                              /*~E:A388*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F387*/
                              /*~F:393*/
                              case 1:
                              /*~-1*/
                              {
                              /*~A:394*/
                              /*~+:Kanal 1*/
                              /*~I:395*/
#ifdef CHANNEL_1
                              /*~T*/
                              // Alles okay
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              /*~I:396*/
                              if (Parameter[1].nLong > -1)
                              /*~-1*/
                              {
                              /*~T*/
                              // DAC-Testmode aktiv setzen
                              CurrentInterface_SetManualMode(1,Parameter[1].nLong);
                              /*~A:397*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              lText2Send = TEXT_CURRENT_INTERFACE_MANUAL_MODE_ON_CHANNEL_1;
                              /*~E:A397*/
                              /*~-1*/
                              }
                              /*~O:I396*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              // DAC-Testmode aktiv setzen
                              SET_DAC_TESTMODE(0);
                              /*~A:398*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              lText2Send = TEXT_CURRENT_INTERFACE_MANUAL_MODE_OFF_CHANNEL_1;
                              /*~E:A398*/
                              /*~-1*/
                              }
                              /*~E:I396*/
                              /*~-1*/
#endif
                              /*~E:I395*/
                              /*~E:A394*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F393*/
                              /*~O:C386*/
                              /*~-2*/
                              default:
                              {
                              /*~A:399*/
                              /*~+:Kanal 0*/
                              /*~I:400*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I400*/
                              /*~E:A399*/
                              /*~-1*/
                              }
                           /*~-1*/
                           }
                           /*~E:C386*/
                        /*~-1*/
                        }
                        /*~O:I385*/
                        /*~-2*/
                        else
                        {
                           /*~A:401*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A401*/
                        /*~-1*/
                        }
                        /*~E:I385*/
                     /*~-1*/
                     }
                     /*~E:I384*/
                     /*~E:A383*/
                     /*~A:402*/
                     /*~+:CIO - CurrentInterfacechangeOffset*/
                     /*~I:403*/
                     if (!strcmp(szCommand,"CIO"))
                     /*~-1*/
                     {
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:404*/
                        if (!InstructionDecoder_CheckNbParameters(2,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0);
                           Parameter[1].nLong = Communication_GetLongParameter(1);
                           /*~C:405*/
                           switch (Parameter[0].nLong)
                           /*~-1*/
                           {
                              /*~F:406*/
                              case 0:
                              /*~-1*/
                              {
                              /*~A:407*/
                              /*~+:Kanal 0*/
                              /*~I:408*/
#ifdef CHANNEL_0
                              /*~T*/
                              // Offset in-/dekrementieren
                              ADuC836_DACChangeOffsetbyStep(Parameter[1].nLong);
                              // und neue Einstellungen sichern
                              CurrentInterface_SaveDACSettings(CURRENTINTERFACE_ALL_SETTINGS);
                              /*~A:409*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              lText2Send = TEXT_CURRENT_INTERFACE_OFFSET_CHANGED_CHANNEL_0;
                              /*~E:A409*/
                              /*~-1*/
#endif
                              /*~E:I408*/
                              /*~E:A407*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F406*/
                              /*~F:410*/
                              case 1:
                              /*~-1*/
                              {
                              /*~A:411*/
                              /*~+:Kanal 1*/
                              /*~I:412*/
#ifdef CHANNEL_1
                              /*~T*/
                              // Offset in-/dekrementieren
                              ADuC836_DACChangeOffsetbyStep(Parameter[1].nLong);
                              // und neue Einstellungen sichern
                              CurrentInterface_SaveDACSettings(CURRENTINTERFACE_ALL_SETTINGS);
                              /*~A:413*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              lText2Send = TEXT_CURRENT_INTERFACE_OFFSET_CHANGED_CHANNEL_1;
                              /*~E:A413*/
                              /*~-1*/
#endif
                              /*~E:I412*/
                              /*~E:A411*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F410*/
                              /*~O:C405*/
                              /*~-2*/
                              default:
                              {
                              /*~A:414*/
                              /*~+:Kanal 0*/
                              /*~I:415*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I415*/
                              /*~E:A414*/
                              /*~-1*/
                              }
                           /*~-1*/
                           }
                           /*~E:C405*/
                        /*~-1*/
                        }
                        /*~O:I404*/
                        /*~-2*/
                        else
                        {
                           /*~A:416*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A416*/
                        /*~-1*/
                        }
                        /*~E:I404*/
                     /*~-1*/
                     }
                     /*~E:I403*/
                     /*~E:A402*/
                     /*~I:417*/
#ifndef OHNE_STROMRUECKFUEHRUNG
                     /*~A:418*/
                     /*~+:CIP - CurrentInterfaceProportionalportion*/
                     /*~I:419*/
                     if (!strcmp(szCommand,"CIP"))
                     /*~-1*/
                     {
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:420*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0); 
                           /*~I:421*/
                           if ((Parameter[0].nLong >= 0)&&(Parameter[0].nLong <= 100))
                           /*~-1*/
                           {
                              /*~I:422*/
                              if (!GET_RESPONSE)
                              /*~-1*/
                              {
                              /*~T*/
                              // Kanal best�tigte mit ACKNOWLEDGE
                              /*~T*/
                              CurrentInterface_SetFeedBackProportionalPortion((char)Parameter[0].nLong);
                              /*~A:423*/
                              /*~+:Ausf�hrungsstatus auf 'OKAY' setzen*/
                              /*~+:*/
                              /*~T*/
                              // Ausf�hrungsstatus auf 'OKAY' setzen
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              /*~E:A423*/
                              /*~A:424*/
                              /*~+:Kanal 0 - Textausgabe*/
                              /*~I:425*/
#ifdef CHANNEL_0 
                              /*~A:426*/
                              /*~+:Textausgabe �ber Kanal 0*/
                              /*~I:427*/
#ifdef CHANNEL_0
                              /*~T*/
                              lText2Send = TEXT_FEEDBACK_PROPORTIONAL_PORTION_SET;
                              /*~-1*/
#endif
                              /*~E:I427*/
                              /*~E:A426*/
                              /*~-1*/
#endif
                              /*~E:I425*/
                              /*~E:A424*/
                              /*~-1*/
                              }
                              /*~O:I422*/
                              /*~-2*/
                              else
                              {
                              /*~K*/
                              /*~+:Fehler !!!*/
                              /*~A:428*/
                              /*~+:Ausf�hrungsstatus auf 'E005' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A428*/
                              /*~-1*/
                              }
                              /*~E:I422*/
                           /*~-1*/
                           }
                           /*~O:I421*/
                           /*~-2*/
                           else
                           {
                              /*~K*/
                              /*~+:Fehler - Wert au�erhalb des Bereichs !!!*/
                              /*~A:429*/
                              /*~+:Kanal 0 - Ausf�hrungsstatus auf 'E002' setzen*/
                              /*~I:430*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E002;
                              /*~-1*/
#endif
                              /*~E:I430*/
                              /*~E:A429*/
                           /*~-1*/
                           }
                           /*~E:I421*/
                        /*~-1*/
                        }
                        /*~O:I420*/
                        /*~-2*/
                        else
                        {
                           /*~A:431*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A431*/
                        /*~-1*/
                        }
                        /*~E:I420*/
                     /*~-1*/
                     }
                     /*~E:I419*/
                     /*~E:A418*/
                     /*~-1*/
#endif
                     /*~E:I417*/
                     /*~A:432*/
                     /*~+:CIR - CurrentInterfaceRestorecalibration*/
                     /*~I:433*/
                     if (!strcmp(szCommand,"CIR"))
                     /*~-1*/
                     {
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:434*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0);
                           /*~C:435*/
                           switch (Parameter[0].nLong)
                           /*~-1*/
                           {
                              /*~F:436*/
                              case 0:
                              /*~-1*/
                              {
                              /*~A:437*/
                              /*~+:Kanal 0*/
                              /*~I:438*/
#ifdef CHANNEL_0
                              /*~T*/
                              CurrentInterface_LoadDACSettings(CURRENTINTERFACE_CALIBRATION_BACKUP);
                              /*~A:439*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              lText2Send = TEXT_CURRENT_INTERFACE_SET_2_DEFAULT_CHANNEL_0;
                              /*~E:A439*/
                              /*~-1*/
#endif
                              /*~E:I438*/
                              /*~E:A437*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F436*/
                              /*~F:440*/
                              case 1:
                              /*~-1*/
                              {
                              /*~A:441*/
                              /*~+:Kanal 1*/
                              /*~I:442*/
#ifdef CHANNEL_1
                              /*~T*/
                              CurrentInterface_LoadDACSettings(CURRENTINTERFACE_CALIBRATION_BACKUP);
                              /*~A:443*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              lText2Send = TEXT_CURRENT_INTERFACE_SET_2_DEFAULT_CHANNEL_1;
                              /*~E:A443*/
                              /*~-1*/
#endif
                              /*~E:I442*/
                              /*~E:A441*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F440*/
                              /*~O:C435*/
                              /*~-2*/
                              default:
                              {
                              /*~A:444*/
                              /*~+:Kanal 0*/
                              /*~I:445*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I445*/
                              /*~E:A444*/
                              /*~-1*/
                              }
                           /*~-1*/
                           }
                           /*~E:C435*/
                        /*~-1*/
                        }
                        /*~O:I434*/
                        /*~-2*/
                        else
                        {
                           /*~A:446*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A446*/
                        /*~-1*/
                        }
                        /*~E:I434*/
                     /*~-1*/
                     }
                     /*~E:I433*/
                     /*~E:A432*/
                     /*~A:447*/
                     /*~+:CIV - CurrentInterfaceVariousvalues*/
                     /*~I:448*/
                     if (!strcmp(szCommand,"CIV"))
                     /*~-1*/
                     {
                        /*~T*/
                        DAC_SETTINGS DAC_Settings;
                        /*~T*/
                        DAC_Settings = ADuC836_DACSaveSettings();
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:449*/
                        if (!InstructionDecoder_CheckNbParameters(2,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0);
                           Parameter[1].nLong = Communication_GetLongParameter(1);
                           /*~C:450*/
                           switch (Parameter[0].nLong)
                           /*~-1*/
                           {
                              /*~F:451*/
                              case 0:
                              /*~-1*/
                              {
                              /*~A:452*/
                              /*~+:Kanal 0*/
                              /*~I:453*/
#ifdef CHANNEL_0
                              /*~C:454*/
                              switch (Parameter[1].nLong)
                              /*~-1*/
                              {
                              /*~F:455*/
                              case 0:
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendFloat(COMMUNICATION_RS232,TEXT_CURRENT_INTERFACE_RMV_2_DAC_INPUT_OFFSET_CHANNEL_0,DAC_Settings.fOffset_RMV,-1,1,0);
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F455*/
                              /*~F:456*/
                              case 1:
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendFloat(COMMUNICATION_RS232,TEXT_CURRENT_INTERFACE_RMV_2_DAC_INPUT_GAIN_CHANNEL_0,DAC_Settings.fGain_RMV,-1,1,0);
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F456*/
                              /*~F:457*/
                              case 2:
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendFloat(COMMUNICATION_RS232,TEXT_CURRENT_INTERFACE_DAC_INPUT_2_CURRENT_OFFSET_CHANNEL_0,DAC_Settings.fOffset_Norm,-1,1,0);
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F457*/
                              /*~F:458*/
                              case 3:
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendFloat(COMMUNICATION_RS232,TEXT_CURRENT_INTERFACE_DAC_INPUT_2_CURRENT_GAIN_CHANNEL_0,DAC_Settings.fGain_Norm,-1,1,0);
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F458*/
                              /*~F:459*/
                              case 4:
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_CURRENT_INTERFACE_DAC_INPUT_CHANNEL_0,DACH * 256 + DACL,1,0);
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F459*/
                              /*~O:C454*/
                              /*~-2*/
                              default:
                              {
                              /*~T*/
                              sprintf(szCommand,"Kanal 0: %f;%f;%f;%f;%ld",DAC_Settings.fOffset_RMV,DAC_Settings.fGain_RMV,DAC_Settings.fOffset_Norm,DAC_Settings.fGain_Norm,DACH * 256 + DACL);
                              /*~T*/
                              Communication_SendString(COMMUNICATION_RS232,szCommand,1,0);
                              /*~-1*/
                              }
                              /*~-1*/
                              }
                              /*~E:C454*/
                              /*~-1*/
#endif
                              /*~E:I453*/
                              /*~T*/
                              break;
                              /*~E:A452*/
                              /*~-1*/
                              }
                              /*~E:F451*/
                              /*~F:460*/
                              case 1:
                              /*~-1*/
                              {
                              /*~A:461*/
                              /*~+:Kanal 1*/
                              /*~I:462*/
#ifdef CHANNEL_1
                              /*~T*/
                              // Alles okay
                              byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;

                              /*~C:463*/
                              switch (Parameter[1].nLong)
                              /*~-1*/
                              {
                              /*~F:464*/
                              case 0:
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendFloat(COMMUNICATION_RS232,TEXT_CURRENT_INTERFACE_RMV_2_DAC_INPUT_OFFSET_CHANNEL_1,DAC_Settings.fOffset_RMV,-1,1,0);
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F464*/
                              /*~F:465*/
                              case 1:
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendFloat(COMMUNICATION_RS232,TEXT_CURRENT_INTERFACE_RMV_2_DAC_INPUT_GAIN_CHANNEL_1,DAC_Settings.fGain_RMV,-1,1,0);
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F465*/
                              /*~F:466*/
                              case 2:
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendFloat(COMMUNICATION_RS232,TEXT_CURRENT_INTERFACE_DAC_INPUT_2_CURRENT_OFFSET_CHANNEL_1,DAC_Settings.fOffset_Norm,-1,1,0);
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F466*/
                              /*~F:467*/
                              case 3:
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendFloat(COMMUNICATION_RS232,TEXT_CURRENT_INTERFACE_DAC_INPUT_2_CURRENT_GAIN_CHANNEL_1,DAC_Settings.fGain_Norm,-1,1,0);
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F467*/
                              /*~F:468*/
                              case 4:
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_CURRENT_INTERFACE_DAC_INPUT_CHANNEL_1,DACH * 256 + DACL,1,0);
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F468*/
                              /*~O:C463*/
                              /*~-2*/
                              default:
                              {
                              /*~T*/
                              sprintf(szCommand,"Kanal 1: %f;%f;%f;%f;%ld",DAC_Settings.fOffset_RMV,DAC_Settings.fGain_RMV,DAC_Settings.fOffset_Norm,DAC_Settings.fGain_Norm,DACH * 256 + DACL);
                              /*~T*/
                              Communication_SendString(COMMUNICATION_RS232,szCommand,1,0);
                              /*~-1*/
                              }
                              /*~-1*/
                              }
                              /*~E:C463*/
                              /*~-1*/
#endif
                              /*~E:I462*/
                              /*~T*/
                              break;
                              /*~E:A461*/
                              /*~-1*/
                              }
                              /*~E:F460*/
                              /*~O:C450*/
                              /*~-2*/
                              default:
                              {
                              /*~A:469*/
                              /*~+:Kanal 0*/
                              /*~I:470*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I470*/
                              /*~E:A469*/
                              /*~-1*/
                              }
                           /*~-1*/
                           }
                           /*~E:C450*/
                        /*~-1*/
                        }
                        /*~O:I449*/
                        /*~-2*/
                        else
                        {
                           /*~A:471*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A471*/
                        /*~-1*/
                        }
                        /*~E:I449*/
                     /*~-1*/
                     }
                     /*~E:I448*/
                     /*~E:A447*/
                     /*~A:472*/
                     /*~+:CLI - ClearLImit*/
                     /*~I:473*/
                     if (!strcmp(szCommand,"CLI"))
                     /*~-1*/
                     {
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:474*/
                        if (!InstructionDecoder_CheckNbParameters(0,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~I:475*/
                           if (!GET_RESPONSE)
                           /*~-1*/
                           {
                              /*~T*/
                              CurrentInterface_LoadDACSettings(CURRENTINTERFACE_CALIBRATION_BACKUP);
                              /*~A:476*/
                              /*~+:Ausf�hrungsstatus auf 'OKAY' setzen*/
                              /*~+:*/
                              /*~T*/
                              // Ausf�hrungsstatus auf 'OKAY' setzen
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              /*~E:A476*/
                              /*~A:477*/
                              /*~+:Kanal 0 - Textausgabe*/
                              /*~I:478*/
#ifdef CHANNEL_0 
                              /*~A:479*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              lText2Send = TEXT_LIMITS_SET_2_DEFAULT;
                              /*~E:A479*/
                              /*~-1*/
#endif
                              /*~E:I478*/
                              /*~E:A477*/
                           /*~-1*/
                           }
                           /*~O:I475*/
                           /*~-2*/
                           else
                           {
                              /*~K*/
                              /*~+:Fehler !!!*/
                              /*~A:480*/
                              /*~+:Ausf�hrungsstatus auf 'E005' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A480*/
                           /*~-1*/
                           }
                           /*~E:I475*/
                        /*~-1*/
                        }
                        /*~O:I474*/
                        /*~-2*/
                        else
                        {
                           /*~A:481*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A481*/
                        /*~-1*/
                        }
                        /*~E:I474*/
                     /*~-1*/
                     }
                     /*~E:I473*/
                     /*~E:A472*/
                     /*~A:482*/
                     /*~+:CRC - ClearResetreplyCounter*/
                     /*~I:483*/
                     if (!strcmp(szCommand,"CRC"))
                     /*~-1*/
                     {
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:484*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0);
                           /*~T*/
                           Communication_ClearSPIFaultCounter((unsigned char)Parameter[0].nLong);
                           /*~I:485*/
#ifdef CHANNEL_0
                           /*~A:486*/
                           /*~+:Textausgabe*/
                           /*~T*/
                           byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                           lText2Send = TEXT_RESET_REPLIES_COUNTER_CLEARED;
                           /*~E:A486*/
                           /*~-1*/
#endif
                           /*~E:I485*/
                        /*~-1*/
                        }
                        /*~O:I484*/
                        /*~-2*/
                        else
                        {
                           /*~A:487*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A487*/
                        /*~-1*/
                        }
                        /*~E:I484*/
                     /*~-1*/
                     }
                     /*~E:I483*/
                     /*~E:A482*/
                     /*~A:488*/
                     /*~+:CRE - ClearResetEnableflag*/
                     /*~I:489*/
                     if (!strcmp(szCommand,"CRE"))
                     /*~-1*/
                     {
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:490*/
                        if (!InstructionDecoder_CheckNbParameters(0,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Communication_SetResetInhibitFlag(2);
                           /*~A:491*/
                           /*~+:Kanal 0 - Textausgabe*/
                           /*~I:492*/
#ifdef CHANNEL_0
                           /*~T*/
                           byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                           lText2Send = TEXT_RESET_INHIBIT_FLAG_SET;
                           /*~-1*/
#endif
                           /*~E:I492*/
                           /*~E:A491*/
                        /*~-1*/
                        }
                        /*~O:I490*/
                        /*~-2*/
                        else
                        {
                           /*~A:493*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A493*/
                        /*~-1*/
                        }
                        /*~E:I490*/
                     /*~-1*/
                     }
                     /*~E:I489*/
                     /*~E:A488*/
                     /*~I:494*/
#ifdef MOF
                     /*~A:495*/
                     /*~+:CRS - ClearRs232Statistics*/
                     /*~I:496*/
                     if (!strcmp(szCommand,"CRS"))
                     /*~-1*/
                     {
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:497*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0); 
                           /*~C:498*/
                           switch (Parameter[0].nLong)
                           /*~-1*/
                           {
                              /*~F:499*/
                              case 0:
                              /*~-1*/
                              {
                              /*~A:500*/
                              /*~+:Kanal 0*/
                              /*~I:501*/
#ifdef CHANNEL_0
                              /*~T*/
                              ADuC836_RS232ClearStatistics();
                              /*~A:502*/
                              /*~+:Textausgabe*/
                              /*~T*/
                              // Textausgabe
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              lText2Send = TEXT_RS232_STATISTICS_CLEARED_CHANNEL_0;
                              /*~E:A502*/
                              /*~-1*/
#endif
                              /*~E:I501*/
                              /*~E:A500*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F499*/
                              /*~F:503*/
                              case 1:
                              /*~-1*/
                              {
                              /*~A:504*/
                              /*~+:Kanal 1*/
                              /*~I:505*/
#ifdef CHANNEL_1
                              /*~T*/
                              ADuC836_RS232ClearStatistics();
                              /*~A:506*/
                              /*~+:Textausgabe*/
                              /*~T*/
                              // Textausgabe
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              lText2Send = TEXT_RS232_STATISTICS_CLEARED_CHANNEL_0;
                              /*~E:A506*/
                              /*~-1*/
#endif
                              /*~E:I505*/
                              /*~E:A504*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F503*/
                              /*~O:C498*/
                              /*~-2*/
                              default:
                              {
                              /*~A:507*/
                              /*~+:Kanal 0*/
                              /*~I:508*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I508*/
                              /*~E:A507*/
                              /*~-1*/
                              }
                           /*~-1*/
                           }
                           /*~E:C498*/
                        /*~-1*/
                        }
                        /*~O:I497*/
                        /*~-2*/
                        else
                        {
                           /*~A:509*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A509*/
                        /*~-1*/
                        }
                        /*~E:I497*/
                     /*~-1*/
                     }
                     /*~E:I496*/
                     /*~E:A495*/
                     /*~-1*/
#endif
                     /*~E:I494*/
                     /*~I:510*/
#ifdef DEVELOPMENT_SW
                     /*~A:511*/
                     /*~+:CSC - ClearSpicheckCounter*/
                     /*~I:512*/
                     if (!strcmp(szCommand,"CSC"))
                     /*~-1*/
                     {
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;

                        /*~I:513*/
                        if (!InstructionDecoder_CheckNbParameters(0,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~A:514*/
                           /*~+:Ausf�hrungsstatus auf 'OKAY' setzen*/
                           /*~+:*/
                           /*~I:515*/
#ifdef CHANNEL_0
                           /*~T*/
                           // Ausf�hrungsstatus auf 'OKAY' setzen
                           byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                           /*~-1*/
#endif
                           /*~E:I515*/
                           /*~E:A514*/
                           /*~T*/
                           // SPI-Test Z�hler l�schen
                           CommunicationControl.ulSPICounter = 0;

                           /*~I:516*/
#ifdef CHANNEL_0
                           /*~T*/
                           CommunicationControl.ulSPIE1Counter = 0;
                           CommunicationControl.ulSPIE1CounterLast = -1;
                           /*~-1*/
#endif
                           /*~E:I516*/
                           /*~A:517*/
                           /*~+:Kanal 0 - Textausgabe*/
                           /*~I:518*/
#ifdef CHANNEL_0
                           /*~T*/
                           lText2Send = TEXT_SYSTEM_CLEAR_SPI_CHECK_COUNTERS;
                           /*~-1*/
#endif
                           /*~E:I518*/
                           /*~E:A517*/
                        /*~-1*/
                        }
                        /*~O:I513*/
                        /*~-2*/
                        else
                        {
                           /*~A:519*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A519*/
                        /*~-1*/
                        }
                        /*~E:I513*/
                     /*~-1*/
                     }
                     /*~E:I512*/
                     /*~E:A511*/
                     /*~-1*/
#endif
                     /*~E:I510*/
                     /*~A:520*/
                     /*~+:CSD - ClearStatisticsData*/
                     /*~I:521*/
                     if (!strcmp(szCommand,"CSD"))
                     /*~-1*/
                     {
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:522*/
                        if (!InstructionDecoder_CheckNbParameters(2,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           // Parameter auslesen
                           Parameter[0].nLong = Communication_GetLongParameter(0);
                           Parameter[1].nLong = Communication_GetLongParameter(1);

                           /*~C:523*/
                           switch (Parameter[0].nLong)
                           /*~-1*/
                           {
                              /*~F:524*/
                              case 0:
                              /*~-1*/
                              {
                              /*~A:525*/
                              /*~+:Kanal 0*/
                              /*~I:526*/
#ifdef CHANNEL_0
                              /*~T*/
                              Statistics_Clear((unsigned char)Parameter[1].nLong);
                              /*~T*/
                              // Merker f�r ein interpretierbares Kommando setzen - keine Textausgabe
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              lText2Send = TEXT_STATITISTICS_CLEARED_CHANNEL_0; 
                              /*~-1*/
#endif
                              /*~E:I526*/
                              /*~E:A525*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F524*/
                              /*~F:527*/
                              case 1:
                              /*~-1*/
                              {
                              /*~A:528*/
                              /*~+:Kanal 1*/
                              /*~I:529*/
#ifdef CHANNEL_1
                              /*~T*/
                              Statistics_Clear((unsigned char)Parameter[1].nLong);
                              /*~T*/
                              // Merker f�r ein interpretierbares Kommando setzen - keine Textausgabe
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              lText2Send = TEXT_STATITISTICS_CLEARED_CHANNEL_1; 
                              /*~-1*/
#endif
                              /*~E:I529*/
                              /*~E:A528*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F527*/
                              /*~O:C523*/
                              /*~-2*/
                              default:
                              {
                              /*~A:530*/
                              /*~+:Kanal 0*/
                              /*~I:531*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I531*/
                              /*~E:A530*/
                              /*~-1*/
                              }
                           /*~-1*/
                           }
                           /*~E:C523*/
                        /*~-1*/
                        }
                        /*~O:I522*/
                        /*~-2*/
                        else
                        {
                           /*~A:532*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A532*/
                        /*~-1*/
                        }
                        /*~E:I522*/
                     /*~-1*/
                     }
                     /*~E:I521*/
                     /*~E:A520*/
                     /*~A:533*/
                     /*~+:CTM - ClearTiMer*/
                     /*~I:534*/
                     if (!strcmp(szCommand,"CTM"))
                     /*~-1*/
                     {
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~A:535*/
                        /*~+:Kanal 0*/
                        /*~I:536*/
#ifdef CHANNEL_0
                        /*~I:537*/
                        if (!InstructionDecoder_CheckNbParameters(2,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~I:538*/
                           if ((Communication_GetLongParameter(1) == ADMINCODE)||(Communication_GetLongParameter(0) == 1))
                           /*~-1*/
                           {
                              /*~T*/
                              // Relativen Betriebsstundenz�hler l�schen
                              System_ClearOperatingHours(1);
                              /*~A:539*/
                              /*~+:Eintrag im Diagnosespeicher*/
                              /*~T*/
                              Diagnosis_WriteMessage2Flash(DIAGNOSIS_MESSAGE_OPERATINGHOURS_2_CLEARED);
                              /*~E:A539*/
                              /*~A:540*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~I:541*/
                              if (!SYSTEM_MRW_MANAGER)
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendString(COMMUNICATION_RS232,T_TEXT_OPERATING_HOURS_RELATIVE_CLEARED,1,0);
                              /*~-1*/
                              }
                              /*~O:I541*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              Communication_SendMessage(COMMUNICATION_RS232,COMMUNICATION_OK);
                              /*~-1*/
                              }
                              /*~E:I541*/
                              /*~E:A540*/
                              /*~I:542*/
                              if (Communication_GetLongParameter(0) != 1)
                              /*~-1*/
                              {
                              /*~T*/
                              // Betriebsstundenz�hler l�schen
                              System_ClearOperatingHours(0);
                              /*~A:543*/
                              /*~+:Eintrag im Diagnosespeicher*/
                              /*~T*/
                              Diagnosis_WriteMessage2Flash(DIAGNOSIS_MESSAGE_OPERATINGHOURS_CLEARED);
                              /*~E:A543*/
                              /*~A:544*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              lText2Send = TEXT_OPERATING_HOURS_CLEARED;
                              /*~E:A544*/
                              /*~-1*/
                              }
                              /*~E:I542*/
                           /*~-1*/
                           }
                           /*~O:I538*/
                           /*~-2*/
                           else
                           {
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E002;
                           /*~-1*/
                           }
                           /*~E:I538*/
                        /*~-1*/
                        }
                        /*~O:I537*/
                        /*~-2*/
                        else
                        {
                           /*~A:545*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A545*/
                        /*~-1*/
                        }
                        /*~E:I537*/
                        /*~-1*/
#endif
                        /*~E:I536*/
                        /*~E:A535*/
                     /*~-1*/
                     }
                     /*~E:I534*/
                     /*~E:A533*/
                     /*~A:546*/
                     /*~+:CTR - ClearTaRa*/
                     /*~I:547*/
                     if (!strcmp(szCommand,"CTR"))
                     /*~-1*/
                     {
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;

                        /*~I:548*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           // Parameter auslesen
                           Parameter[0].nLong = Communication_GetLongParameter(0);
                           /*~C:549*/
                           switch (Parameter[0].nLong)
                           /*~-1*/
                           {
                              /*~F:550*/
                              case 0:
                              /*~-1*/
                              {
                              /*~A:551*/
                              /*~+:Kanal 0*/
                              /*~I:552*/
#ifdef CHANNEL_0
                              /*~I:553*/
                              // Tara setzen und speichern
                              if (!Weight_SetTareValue(0,1))
                              /*~-1*/
                              {
                              /*~A:554*/
                              /*~+:Eintrag in Diagnosespeicher vornehmen*/
                              /*~T*/
                              ulDiagnosisEntry2Set = DIAGNOSIS_MESSAGE_TARE_CLEARED;
                              /*~E:A554*/
                              /*~A:555*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              /*~T*/
                              lText2Send = TEXT_MEASUREMENT_TARA_CLEARED_CHANNEL_0;
                              /*~E:A555*/
                              /*~-1*/
                              }
                              /*~O:I553*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~-1*/
                              }
                              /*~E:I553*/
                              /*~-1*/
#endif
                              /*~E:I552*/
                              /*~E:A551*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F550*/
                              /*~F:556*/
                              case 1:
                              /*~-1*/
                              {
                              /*~A:557*/
                              /*~+:Kanal 1*/
                              /*~I:558*/
#ifdef CHANNEL_1
                              /*~I:559*/
                              // Tara setzen und speichern
                              if (!Weight_SetTareValue(0,1))
                              /*~-1*/
                              {
                              /*~A:560*/
                              /*~+:Eintrag in Diagnosespeicher vornehmen*/
                              /*~T*/
                              ulDiagnosisEntry2Set = DIAGNOSIS_MESSAGE_TARE_CLEARED;
                              /*~E:A560*/
                              /*~A:561*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              /*~T*/
                              lText2Send = TEXT_MEASUREMENT_TARA_CLEARED_CHANNEL_1;
                              /*~E:A561*/
                              /*~-1*/
                              }
                              /*~O:I559*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~-1*/
                              }
                              /*~E:I559*/
                              /*~-1*/
#endif
                              /*~E:I558*/
                              /*~E:A557*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F556*/
                              /*~O:C549*/
                              /*~-2*/
                              default:
                              {
                              /*~A:562*/
                              /*~+:Kanal 0*/
                              /*~I:563*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I563*/
                              /*~E:A562*/
                              /*~-1*/
                              }
                           /*~-1*/
                           }
                           /*~E:C549*/
                        /*~-1*/
                        }
                        /*~O:I548*/
                        /*~-2*/
                        else
                        {
                           /*~A:564*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A564*/
                        /*~-1*/
                        }
                        /*~E:I548*/
                     /*~-1*/
                     }
                     /*~E:I547*/
                     /*~E:A546*/
                     /*~A:565*/
                     /*~+:CWD - ClearWatchDogadress*/
                     /*~I:566*/
                     if (!strcmp(szCommand,"CWD"))
                     /*~-1*/
                     {
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:567*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~C:568*/
                           switch (Communication_GetLongParameter(0))
                           /*~-1*/
                           {
                              /*~F:569*/
                              case 0:
                              /*~-1*/
                              {
                              /*~A:570*/
                              /*~+:Kanal 0*/
                              /*~I:571*/
#ifdef CHANNEL_0
                              /*~T*/
                              ADuC836_WatchdogClearAddress();
                              /*~T*/
                              // Merker f�r ein interpretierbares Kommando setzen - keine Textausgabe
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              lText2Send = TEXT_WATCHDOG_ADDRESS_CLEARED_CHANNEL_0; 
                              /*~-1*/
#endif
                              /*~E:I571*/
                              /*~E:A570*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F569*/
                              /*~F:572*/
                              case 1:
                              /*~-1*/
                              {
                              /*~A:573*/
                              /*~+:Kanal 1*/
                              /*~I:574*/
#ifdef CHANNEL_1
                              /*~T*/
                              ADuC836_WatchdogClearAddress();
                              /*~T*/
                              // Merker f�r ein interpretierbares Kommando setzen - keine Textausgabe
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              lText2Send = TEXT_WATCHDOG_ADDRESS_CLEARED_CHANNEL_1; 
                              /*~-1*/
#endif
                              /*~E:I574*/
                              /*~E:A573*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F572*/
                              /*~O:C568*/
                              /*~-2*/
                              default:
                              {
                              /*~A:575*/
                              /*~+:Kanal 0*/
                              /*~I:576*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I576*/
                              /*~E:A575*/
                              /*~-1*/
                              }
                           /*~-1*/
                           }
                           /*~E:C568*/
                        /*~-1*/
                        }
                        /*~O:I567*/
                        /*~-2*/
                        else
                        {
                           /*~A:577*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A577*/
                        /*~-1*/
                        }
                        /*~E:I567*/
                     /*~-1*/
                     }
                     /*~E:I566*/
                     /*~E:A565*/
                     /*~T*/
                     break;
                  /*~-1*/
                  }
                  /*~E:F130*/
                  /*~E:A129*/
                  /*~K*/
                  /*~+:/~* Ge�ndert am 09.02.2022 *~/*/
                  /*~A:578*/
                  /*~+:D*/
                  /*~F:579*/
                  case 'D':
                  /*~-1*/
                  {
                     /*~A:580*/
                     /*~+:DIS - DISable RS232-Kommunikation*/
                     /*~I:581*/
                     if (!strcmp(szCommand,"DIS"))
                     /*~-1*/
                     {
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:582*/
                        if (!InstructionDecoder_CheckNbParameters(2,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0);
                           Parameter[1].nLong = Communication_GetLongParameter(1);
                           /*~C:583*/
                           switch (Parameter[0].nLong)
                           /*~-1*/
                           {
                              /*~F:584*/
                              case 0:
                              /*~-1*/
                              {
                              /*~A:585*/
                              /*~+:Kanal 0*/
                              /*~I:586*/
#ifdef CHANNEL_0
                              /*~I:587*/
                              if (Parameter[1].nLong == COMMUNICATION_DISABLE_CODE)
                              /*~-1*/
                              {
                              /*~T*/
                              byRetVal = Communication_EnableCommunication(0);
                              /*~I:588*/
                              if (byRetVal == 0)
                              /*~-1*/
                              {
                              /*~A:589*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              lText2Send = TEXT_RS232_COMMUNICATION_DISABLED_CHANNEL_0;
                              /*~E:A589*/
                              /*~-1*/
                              }
                              /*~O:I588*/
                              /*~-2*/
                              else
                              {
                              /*~K*/
                              /*~+:Fehler*/
                              /*~A:590*/
                              /*~+:Textausgabe "E005"*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A590*/
                              /*~-1*/
                              }
                              /*~E:I588*/
                              /*~-1*/
                              }
                              /*~O:I587*/
                              /*~-2*/
                              else
                              {
                              /*~K*/
                              /*~+:Fehler*/
                              /*~A:591*/
                              /*~+:Textausgabe "E005"*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A591*/
                              /*~-1*/
                              }
                              /*~E:I587*/
                              /*~-1*/
#endif
                              /*~E:I586*/
                              /*~E:A585*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F584*/
                              /*~F:592*/
                              case 1:
                              /*~-1*/
                              {
                              /*~A:593*/
                              /*~+:Kanal 1*/
                              /*~I:594*/
#ifdef CHANNEL_1
                              /*~I:595*/
                              if (Parameter[1].nLong == COMMUNICATION_DISABLE_CODE)
                              /*~-1*/
                              {
                              /*~T*/
                              byRetVal = Communication_EnableCommunication(0);
                              /*~I:596*/
                              if (byRetVal == 0)
                              /*~-1*/
                              {
                              /*~A:597*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              lText2Send = TEXT_RS232_COMMUNICATION_DISABLED_CHANNEL_1;
                              /*~E:A597*/
                              /*~-1*/
                              }
                              /*~O:I596*/
                              /*~-2*/
                              else
                              {
                              /*~K*/
                              /*~+:Fehler*/
                              /*~A:598*/
                              /*~+:Textausgabe "E005"*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A598*/
                              /*~-1*/
                              }
                              /*~E:I596*/
                              /*~-1*/
                              }
                              /*~O:I595*/
                              /*~-2*/
                              else
                              {
                              /*~K*/
                              /*~+:Fehler*/
                              /*~A:599*/
                              /*~+:Textausgabe "E005"*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A599*/
                              /*~-1*/
                              }
                              /*~E:I595*/
                              /*~-1*/
#endif
                              /*~E:I594*/
                              /*~E:A593*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F592*/
                              /*~O:C583*/
                              /*~-2*/
                              default:
                              {
                              /*~A:600*/
                              /*~+:Kanal 0*/
                              /*~I:601*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I601*/
                              /*~E:A600*/
                              /*~-1*/
                              }
                           /*~-1*/
                           }
                           /*~E:C583*/
                        /*~-1*/
                        }
                        /*~O:I582*/
                        /*~-2*/
                        else
                        {
                           /*~A:602*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A602*/
                        /*~-1*/
                        }
                        /*~E:I582*/
                     /*~-1*/
                     }
                     /*~E:I581*/
                     /*~E:A580*/
                     /*~T*/
                     break;
                  /*~-1*/
                  }
                  /*~E:F579*/
                  /*~E:A578*/
                  /*~A:603*/
                  /*~+:E*/
                  /*~F:604*/
                  case 'E':
                  /*~-1*/
                  {
                     /*~A:605*/
                     /*~+:ENA - ENAble RS232-Kommunikation*/
                     /*~I:606*/
                     if (!strcmp(szCommand,"ENA"))
                     /*~-1*/
                     {
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:607*/
                        if (!InstructionDecoder_CheckNbParameters(2,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0);
                           Parameter[1].nLong = Communication_GetLongParameter(1);
                           /*~C:608*/
                           switch (Parameter[0].nLong)
                           /*~-1*/
                           {
                              /*~F:609*/
                              case 0:
                              /*~-1*/
                              {
                              /*~A:610*/
                              /*~+:Kanal 0*/
                              /*~I:611*/
#ifdef CHANNEL_0
                              /*~I:612*/
                              if (Parameter[1].nLong == COMMUNICATION_DISABLE_CODE)
                              /*~-1*/
                              {
                              /*~T*/
                              byRetVal = Communication_EnableCommunication(1);
                              /*~I:613*/
                              if (byRetVal == 0)
                              /*~-1*/
                              {
                              /*~A:614*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              lText2Send = TEXT_RS232_COMMUNICATION_ENABLED_CHANNEL_0;
                              /*~E:A614*/
                              /*~-1*/
                              }
                              /*~O:I613*/
                              /*~-2*/
                              else
                              {
                              /*~K*/
                              /*~+:Fehler*/
                              /*~A:615*/
                              /*~+:Textausgabe "E005"*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A615*/
                              /*~-1*/
                              }
                              /*~E:I613*/
                              /*~-1*/
                              }
                              /*~O:I612*/
                              /*~-2*/
                              else
                              {
                              /*~K*/
                              /*~+:Fehler*/
                              /*~A:616*/
                              /*~+:Textausgabe "E005"*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A616*/
                              /*~-1*/
                              }
                              /*~E:I612*/
                              /*~-1*/
#endif
                              /*~E:I611*/
                              /*~E:A610*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F609*/
                              /*~F:617*/
                              case 1:
                              /*~-1*/
                              {
                              /*~A:618*/
                              /*~+:Kanal 1*/
                              /*~I:619*/
#ifdef CHANNEL_1
                              /*~I:620*/
                              if (Parameter[1].nLong == COMMUNICATION_DISABLE_CODE)
                              /*~-1*/
                              {
                              /*~T*/
                              byRetVal = Communication_EnableCommunication(1);
                              /*~I:621*/
                              if (byRetVal == 0)
                              /*~-1*/
                              {
                              /*~A:622*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              lText2Send = TEXT_RS232_COMMUNICATION_ENABLED_CHANNEL_1;
                              /*~E:A622*/
                              /*~-1*/
                              }
                              /*~O:I621*/
                              /*~-2*/
                              else
                              {
                              /*~K*/
                              /*~+:Fehler*/
                              /*~A:623*/
                              /*~+:Textausgabe "E005"*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A623*/
                              /*~-1*/
                              }
                              /*~E:I621*/
                              /*~-1*/
                              }
                              /*~O:I620*/
                              /*~-2*/
                              else
                              {
                              /*~K*/
                              /*~+:Fehler*/
                              /*~A:624*/
                              /*~+:Textausgabe "E005"*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A624*/
                              /*~-1*/
                              }
                              /*~E:I620*/
                              /*~-1*/
#endif
                              /*~E:I619*/
                              /*~E:A618*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F617*/
                              /*~O:C608*/
                              /*~-2*/
                              default:
                              {
                              /*~A:625*/
                              /*~+:Kanal 0*/
                              /*~I:626*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I626*/
                              /*~E:A625*/
                              /*~-1*/
                              }
                           /*~-1*/
                           }
                           /*~E:C608*/
                        /*~-1*/
                        }
                        /*~O:I607*/
                        /*~-2*/
                        else
                        {
                           /*~A:627*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A627*/
                        /*~-1*/
                        }
                        /*~E:I607*/
                     /*~-1*/
                     }
                     /*~E:I606*/
                     /*~E:A605*/
                     /*~T*/
                     break;
                  /*~-1*/
                  }
                  /*~E:F604*/
                  /*~E:A603*/
                  /*~K*/
                  /*~+:/~* Ende - Ge�ndert am 09.02.2022 *~/*/
                  /*~A:628*/
                  /*~+:G*/
                  /*~F:629*/
                  case 'G':
                  /*~-1*/
                  {
                     /*~A:630*/
                     /*~+:GAN - GetArticleNumber*/
                     /*~I:631*/
                     if (!strcmp(szCommand,"GAN"))
                     /*~-1*/
                     {
                        /*~T*/
                        // Text wurde bereits gesendet
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~A:632*/
                        /*~+:Kanal 0*/
                        /*~I:633*/
#ifdef CHANNEL_0
                        /*~I:634*/
                        if (!InstructionDecoder_CheckNbParameters(0,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~I:635*/
                           if (!SYSTEM_MRW_MANAGER)
                           /*~-1*/
                           {
                              /*~T*/
                              Communication_SendString(COMMUNICATION_RS232,T_TEXT_ITEM_NUMBER,1,0);

                           /*~-1*/
                           }
                           /*~E:I635*/
                           /*~T*/
                           Communication_SendString(COMMUNICATION_RS232,System_GetItemNumber(),0,0);
                        /*~-1*/
                        }
                        /*~O:I634*/
                        /*~-2*/
                        else
                        {
                           /*~A:636*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A636*/
                        /*~-1*/
                        }
                        /*~E:I634*/
                        /*~-1*/
#endif
                        /*~E:I633*/
                        /*~E:A632*/
                     /*~-1*/
                     }
                     /*~E:I631*/
                     /*~E:A630*/
                     /*~A:637*/
                     /*~+:GAL - GetAlarmLimit*/
                     /*~I:638*/
                     if (!strcmp(szCommand,"GAL"))
                     /*~-1*/
                     {
                        /*~T*/
                        // Text wurde bereits gesendet
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:639*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0);
                           /*~T*/
                           fTemp = Limit_GetAlarmLimit(1);
                           /*~C:640*/
                           switch (Parameter[0].nLong)
                           /*~-1*/
                           {
                              /*~F:641*/
                              case 0:
                              /*~-1*/
                              {
                              /*~A:642*/
                              /*~+:Kanal 0*/
                              /*~I:643*/
#ifdef CHANNEL_0
                              /*~T*/
                              Communication_SendFloat(COMMUNICATION_RS232,TEXT_ALARM_LIMIT_CHANNEL_0,fTemp,2,1,0);
                              /*~-1*/
#endif
                              /*~E:I643*/
                              /*~E:A642*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F641*/
                              /*~F:644*/
                              case 1:
                              /*~-1*/
                              {
                              /*~A:645*/
                              /*~+:Kanal 1*/
                              /*~I:646*/
#ifdef CHANNEL_1
                              /*~T*/
                              Communication_SendFloat(COMMUNICATION_RS232,TEXT_ALARM_LIMIT_CHANNEL_1,fTemp,2,1,0);
                              /*~-1*/
#endif
                              /*~E:I646*/
                              /*~E:A645*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F644*/
                              /*~O:C640*/
                              /*~-2*/
                              default:
                              {
                              /*~A:647*/
                              /*~+:Fehlerausgabe �ber Kanal 1 - E001*/
                              /*~I:648*/
#ifdef CHANNEL_0
                              /*~T*/
                              // Fehler
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I648*/
                              /*~E:A647*/
                              /*~-1*/
                              }
                           /*~-1*/
                           }
                           /*~E:C640*/
                        /*~-1*/
                        }
                        /*~O:I639*/
                        /*~-2*/
                        else
                        {
                           /*~A:649*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A649*/
                        /*~-1*/
                        }
                        /*~E:I639*/
                     /*~-1*/
                     }
                     /*~E:I638*/
                     /*~E:A637*/
                     /*~A:650*/
                     /*~+:GAP - GetAPplication*/
                     /*~I:651*/
                     if (!strcmp(szCommand,"GAP"))
                     /*~-1*/
                     {
                        /*~T*/
                        // Text wurde bereits gesendet
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~A:652*/
                        /*~+:Kanal 0*/
                        /*~I:653*/
#ifdef CHANNEL_0
                        /*~I:654*/
                        if (!InstructionDecoder_CheckNbParameters(0,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~I:655*/
                           if (!SYSTEM_MRW_MANAGER)
                           /*~-1*/
                           {
                              /*~T*/
                              Communication_SendString(COMMUNICATION_RS232,T_TEXT_APPLICATION,1,0);

                           /*~-1*/
                           }
                           /*~E:I655*/
                           /*~T*/
                           Communication_SendString(COMMUNICATION_RS232,TEXT_APPLICATION_TYPE,0,0);
                        /*~-1*/
                        }
                        /*~O:I654*/
                        /*~-2*/
                        else
                        {
                           /*~A:656*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A656*/
                        /*~-1*/
                        }
                        /*~E:I654*/
                        /*~-1*/
#endif
                        /*~E:I653*/
                        /*~E:A652*/
                     /*~-1*/
                     }
                     /*~E:I651*/
                     /*~E:A650*/
                     /*~A:657*/
                     /*~+:GAT - GetActualTemperature*/
                     /*~I:658*/
                     if (!strcmp(szCommand,"GAT"))
                     /*~-1*/
                     {
                        /*~T*/
                        // Text wurde bereits gesendet
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:659*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0); 
                           /*~C:660*/
                           switch (Parameter[0].nLong)
                           /*~-1*/
                           {
                              /*~F:661*/
                              case 0:
                              /*~-1*/
                              {
                              /*~A:662*/
                              /*~+:Kanal 0*/
                              /*~I:663*/
#ifdef CHANNEL_0
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_ACTUAL_TEMPERATURE_CHANNEL_0,Global.byTemperature,1,0);
                              /*~-1*/
#endif
                              /*~E:I663*/
                              /*~E:A662*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F661*/
                              /*~F:664*/
                              case 1:
                              /*~-1*/
                              {
                              /*~A:665*/
                              /*~+:Kanal 1*/
                              /*~I:666*/
#ifdef CHANNEL_1
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_ACTUAL_TEMPERATURE_CHANNEL_1,Global.byTemperature,1,0);
                              /*~-1*/
#endif
                              /*~E:I666*/
                              /*~E:A665*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F664*/
                              /*~O:C660*/
                              /*~-2*/
                              default:
                              {
                              /*~A:667*/
                              /*~+:Fehlerausgabe �ber Kanal 1 - E001*/
                              /*~I:668*/
#ifdef CHANNEL_0
                              /*~T*/
                              // Fehler
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I668*/
                              /*~E:A667*/
                              /*~-1*/
                              }
                           /*~-1*/
                           }
                           /*~E:C660*/
                        /*~-1*/
                        }
                        /*~O:I659*/
                        /*~-2*/
                        else
                        {
                           /*~A:669*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A669*/
                        /*~-1*/
                        }
                        /*~E:I659*/
                     /*~-1*/
                     }
                     /*~E:I658*/
                     /*~E:A657*/
                     /*~I:670*/
#ifdef SYSTEM_CND_VARIABLE_BAUDRATE
                     /*~A:671*/
                     /*~+:GBR - GetBaudRate*/
                     /*~I:672*/
                     if (!strcmp(szCommand,"GBR"))
                     /*~-1*/
                     {
                        /*~A:673*/
                        /*~+:Variablendeklarationen*/
                        /*~T*/
                        unsigned long ulBaudrate;
                        /*~I:674*/
#ifdef CHANNEL_0
                        /*~T*/
                        unsigned long ulBaudratePartner;

                        /*~-1*/
#endif
                        /*~E:I674*/
                        /*~E:A673*/
                        /*~T*/
                        // Text wurde bereits gesendet
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:675*/
                        if (!InstructionDecoder_CheckNbParameters(0,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Load_Parameter(LOAD_SAVE_RS232_BAUDRATE,&ulBaudrate,4);
                           /*~I:676*/
#ifdef CHANNEL_0
                           /*~I:677*/
                           if (!Communication_GetSPIValue(COMMUNICATION_RS232_BAUDRATE,&ulBaudratePartner))
                           /*~-1*/
                           {
                              /*~I:678*/
                              if (ulBaudratePartner == ulBaudrate)
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_RS232_BAUDRATE,ulBaudrate,1,0);
                              /*~-1*/
                              }
                              /*~O:I678*/
                              /*~-2*/
                              else
                              {
                              /*~A:679*/
                              /*~+:Fehler - Werte beider Kan�le sind nicht identisch - E011*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E011;
                              /*~E:A679*/
                              /*~-1*/
                              }
                              /*~E:I678*/
                           /*~-1*/
                           }
                           /*~O:I677*/
                           /*~-2*/
                           else
                           {
                              /*~A:680*/
                              /*~+:Fehler bei der Kommunikation - E005*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A680*/
                           /*~-1*/
                           }
                           /*~E:I677*/
                           /*~O:I676*/
                           /*~-1*/
#else
                           /*~I:681*/
#ifdef CHANNEL_1
                           /*~T*/
                           InstructionDecoder_StoreValue(COMMUNICATION_RS232_BAUDRATE,(GLOBAL_UNIVALUE_SHORT*)&ulBaudrate);
                           /*~-1*/
#endif
                           /*~E:I681*/
                           /*~-1*/
#endif
                           /*~E:I676*/
                        /*~-1*/
                        }
                        /*~O:I675*/
                        /*~-2*/
                        else
                        {
                           /*~A:682*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A682*/
                        /*~-1*/
                        }
                        /*~E:I675*/
                     /*~-1*/
                     }
                     /*~E:I672*/
                     /*~E:A671*/
                     /*~-1*/
#endif
                     /*~E:I670*/
                     /*~A:683*/
                     /*~+:GCD - GetmaxCurrentDeviation*/
                     /*~I:684*/
                     if (!strcmp(szCommand,"GCD"))
                     /*~-1*/
                     {
                        /*~T*/
                        // Text wurde bereits gesendet
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~A:685*/
                        /*~+:Kanal 0*/
                        /*~I:686*/
#ifdef CHANNEL_0
                        /*~I:687*/
                        if (!InstructionDecoder_CheckNbParameters(0,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Communication_SendFloat(COMMUNICATION_RS232,TEXT_CURRENT_INTERFACE_CURRENT_MAXDEVIATION,g_CurrentInterface.FeedBack.fMaxDeviation,3,1,0);
                        /*~-1*/
                        }
                        /*~O:I687*/
                        /*~-2*/
                        else
                        {
                           /*~A:688*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A688*/
                        /*~-1*/
                        }
                        /*~E:I687*/
                        /*~-1*/
#endif
                        /*~E:I686*/
                        /*~E:A685*/
                     /*~-1*/
                     }
                     /*~E:I684*/
                     /*~E:A683*/
                     /*~A:689*/
                     /*~+:GCF - GetCalibrationFactor*/
                     /*~I:690*/
                     if (!strcmp(szCommand,"GCF"))
                     /*~-1*/
                     {
                        /*~T*/
                        // Text wurde bereits gesendet
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:691*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0); 
                           /*~T*/
                           Measurement_GetCalibrationFactor(WEIGHT_WEIGHTCHANNEL,&fTemp);
                           /*~C:692*/
                           switch (Parameter[0].nLong)
                           /*~-1*/
                           {
                              /*~F:693*/
                              case 0:
                              /*~-1*/
                              {
                              /*~A:694*/
                              /*~+:Kanal 0*/
                              /*~I:695*/
#ifdef CHANNEL_0
                              /*~T*/
                              Communication_SendFloat(COMMUNICATION_RS232,TEXT_MEASUREMENT_ACTUAL_GAIN_CHANNEL_0,fTemp,-1,1,0);
                              /*~-1*/
#endif
                              /*~E:I695*/
                              /*~E:A694*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F693*/
                              /*~F:696*/
                              case 1:
                              /*~-1*/
                              {
                              /*~A:697*/
                              /*~+:Kanal 1*/
                              /*~I:698*/
#ifdef CHANNEL_1
                              /*~T*/
                              Communication_SendFloat(COMMUNICATION_RS232,TEXT_MEASUREMENT_ACTUAL_GAIN_CHANNEL_1,fTemp,-1,1,0);
                              /*~-1*/
#endif
                              /*~E:I698*/
                              /*~E:A697*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F696*/
                              /*~O:C692*/
                              /*~-2*/
                              default:
                              {
                              /*~A:699*/
                              /*~+:Kanal 0*/
                              /*~I:700*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I700*/
                              /*~E:A699*/
                              /*~-1*/
                              }
                           /*~-1*/
                           }
                           /*~E:C692*/
                        /*~-1*/
                        }
                        /*~O:I691*/
                        /*~-2*/
                        else
                        {
                           /*~A:701*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A701*/
                        /*~-1*/
                        }
                        /*~E:I691*/
                     /*~-1*/
                     }
                     /*~E:I690*/
                     /*~E:A689*/
                     /*~I:702*/
#ifdef MOF
                     /*~A:703*/
                     /*~+:GCG - GetCurrentinterfaceGain*/
                     /*~I:704*/
                     if (!strcmp(szCommand,"GCG"))
                     /*~-1*/
                     {
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:705*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0);
                           /*~I:706*/
                           if (Parameter[0].nLong < 2)
                           /*~-1*/
                           {
                              /*~C:707*/
                              switch (Parameter[0].nLong)
                              /*~-1*/
                              {
                              /*~F:708*/
                              case 0:
                              /*~-1*/
                              {
                              /*~A:709*/
                              /*~+:Kanal 0*/
                              /*~I:710*/
#ifdef CHANNEL_0
                              /*~T*/
                              Communication_SendFloat(COMMUNICATION_RS232,TEXT_CURRENT_INTERFACE_GAIN_NORM_CHANNEL_0,ADuC836_DACGetGain(0) * ADuC836_DACGetGain(1),-1,1,0);
                              /*~-1*/
#endif
                              /*~E:I710*/
                              /*~E:A709*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F708*/
                              /*~F:711*/
                              case 1:
                              /*~-1*/
                              {
                              /*~A:712*/
                              /*~+:Kanal 1*/
                              /*~I:713*/
#ifdef CHANNEL_1
                              /*~T*/
                              Communication_SendFloat(COMMUNICATION_RS232,TEXT_CURRENT_INTERFACE_GAIN_NORM_CHANNEL_1,ADuC836_DACGetGain(0) * ADuC836_DACGetGain(1),-1,1,0);
                              /*~-1*/
#endif
                              /*~E:I713*/
                              /*~E:A712*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F711*/
                              /*~O:C707*/
                              /*~-2*/
                              default:
                              {
                              /*~A:714*/
                              /*~+:Kanal 0*/
                              /*~I:715*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I715*/
                              /*~E:A714*/
                              /*~-1*/
                              }
                              /*~-1*/
                              }
                              /*~E:C707*/
                           /*~-1*/
                           }
                           /*~O:I706*/
                           /*~-2*/
                           else
                           {
                              /*~A:716*/
                              /*~+:Kanal 0*/
                              /*~I:717*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E002;
                              /*~-1*/
#endif
                              /*~E:I717*/
                              /*~E:A716*/
                           /*~-1*/
                           }
                           /*~E:I706*/
                        /*~-1*/
                        }
                        /*~O:I705*/
                        /*~-2*/
                        else
                        {
                           /*~A:718*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A718*/
                        /*~-1*/
                        }
                        /*~E:I705*/
                     /*~-1*/
                     }
                     /*~E:I704*/
                     /*~E:A703*/
                     /*~-1*/
#endif
                     /*~E:I702*/
                     /*~A:719*/
                     /*~+:GCL - GetCheckLimits*/
                     /*~I:720*/
                     if (!strcmp(szCommand,"GCL"))
                     /*~-1*/
                     {
                        /*~A:721*/
                        /*~+:Variablendeklarationen*/
                        /*~T*/
                        float fMaxDeviation;
                        float fMaxDrift;
                        /*~I:722*/
#ifdef CHANNEL_0
                        /*~T*/
                        float fLimitPartner;

                        /*~-1*/
#endif
                        /*~E:I722*/
                        /*~E:A721*/
                        /*~A:723*/
                        /*~+:Variableninitialisierungen*/
                        /*~T*/

                        /*~E:A723*/
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:724*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0);
                           /*~T*/
                           MRW_Compensation_GetCheckLimits(&fMaxDeviation,&fMaxDrift);
                           /*~C:725*/
                           switch (Parameter[0].nLong)
                           /*~-1*/
                           {
                              /*~F:726*/
                              case 0:		// Nullpunkt�berwachung
                              /*~-1*/
                              {
                              /*~I:727*/
#ifdef CHANNEL_0
                              /*~I:728*/
                              if (!Communication_GetSPIValue(COMMUNICATION_CHECKLIMIT_ZEROPOINTCHECK,&fLimitPartner))
                              /*~-1*/
                              {
                              /*~I:729*/
                              if (fLimitPartner == g_Limit.fLimitZeroPointCheck)
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendFloat(COMMUNICATION_RS232,TEXT_LIMIT_ZEROCHECK,g_Limit.fLimitZeroPointCheck,2,1,0);
                              /*~-1*/
                              }
                              /*~O:I729*/
                              /*~-2*/
                              else
                              {
                              /*~A:730*/
                              /*~+:Fehler - Werte beider Kan�le sind nicht identisch - E011*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E011;
                              /*~E:A730*/
                              /*~-1*/
                              }
                              /*~E:I729*/
                              /*~-1*/
                              }
                              /*~O:I728*/
                              /*~-2*/
                              else
                              {
                              /*~A:731*/
                              /*~+:Fehler bei der Kommunikation - E005*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A731*/
                              /*~-1*/
                              }
                              /*~E:I728*/
                              /*~O:I727*/
                              /*~-1*/
#else
                              /*~I:732*/
#ifdef CHANNEL_1 
                              /*~T*/
                              InstructionDecoder_StoreValue(COMMUNICATION_CHECKLIMIT_ZEROPOINTCHECK,(GLOBAL_UNIVALUE_SHORT*)&g_Limit.fLimitZeroPointCheck);
                              /*~-1*/
#endif
                              /*~E:I732*/
                              /*~-1*/
#endif
                              /*~E:I727*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F726*/
                              /*~F:733*/
                              case 1:
                              /*~-1*/
                              {
                              /*~I:734*/
#ifdef CHANNEL_0
                              /*~I:735*/
                              if (!Communication_GetSPIValue(COMMUNICATION_CHECKLIMIT_MAX_DEVIATION,&fLimitPartner))
                              /*~-1*/
                              {
                              /*~I:736*/
                              if (fLimitPartner == fMaxDeviation)
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendFloat(COMMUNICATION_RS232,TEXT_LIMIT_MAX_DEVIATION,fMaxDeviation,2,1,0);
                              /*~-1*/
                              }
                              /*~O:I736*/
                              /*~-2*/
                              else
                              {
                              /*~A:737*/
                              /*~+:Fehler - Werte beider Kan�le sind nicht identisch - E011*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E011;
                              /*~E:A737*/
                              /*~-1*/
                              }
                              /*~E:I736*/
                              /*~-1*/
                              }
                              /*~O:I735*/
                              /*~-2*/
                              else
                              {
                              /*~A:738*/
                              /*~+:Fehler bei der Kommunikation - E005*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A738*/
                              /*~-1*/
                              }
                              /*~E:I735*/
                              /*~O:I734*/
                              /*~-1*/
#else
                              /*~I:739*/
#ifdef CHANNEL_1 
                              /*~T*/
                              InstructionDecoder_StoreValue(COMMUNICATION_CHECKLIMIT_MAX_DEVIATION,(GLOBAL_UNIVALUE_SHORT*)&fMaxDeviation);
                              /*~-1*/
#endif
                              /*~E:I739*/
                              /*~-1*/
#endif
                              /*~E:I734*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F733*/
                              /*~F:740*/
                              case 2:
                              /*~-1*/
                              {
                              /*~I:741*/
#ifdef CHANNEL_0
                              /*~I:742*/
                              if (!Communication_GetSPIValue(COMMUNICATION_CHECKLIMIT_MAX_DRIFT,&fLimitPartner))
                              /*~-1*/
                              {
                              /*~I:743*/
                              if (fLimitPartner == fMaxDrift)
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendFloat(COMMUNICATION_RS232,TEXT_LIMIT_MAX_DRIFT,fMaxDrift,2,1,0);
                              /*~-1*/
                              }
                              /*~O:I743*/
                              /*~-2*/
                              else
                              {
                              /*~A:744*/
                              /*~+:Fehler - Werte beider Kan�le sind nicht identisch - E011*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E011;
                              /*~E:A744*/
                              /*~-1*/
                              }
                              /*~E:I743*/
                              /*~-1*/
                              }
                              /*~O:I742*/
                              /*~-2*/
                              else
                              {
                              /*~A:745*/
                              /*~+:Fehler bei der Kommunikation - E005*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A745*/
                              /*~-1*/
                              }
                              /*~E:I742*/
                              /*~O:I741*/
                              /*~-1*/
#else
                              /*~I:746*/
#ifdef CHANNEL_1 
                              /*~T*/
                              InstructionDecoder_StoreValue(COMMUNICATION_CHECKLIMIT_MAX_DRIFT,(GLOBAL_UNIVALUE_SHORT*)&fMaxDrift);
                              /*~-1*/
#endif
                              /*~E:I746*/
                              /*~-1*/
#endif
                              /*~E:I741*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F740*/
                              /*~O:C725*/
                              /*~-2*/
                              default:
                              {
                              /*~A:747*/
                              /*~+:Kanal 0*/
                              /*~I:748*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E002;
                              /*~-1*/
#endif
                              /*~E:I748*/
                              /*~E:A747*/
                              /*~-1*/
                              }
                           /*~-1*/
                           }
                           /*~E:C725*/
                        /*~-1*/
                        }
                        /*~O:I724*/
                        /*~-2*/
                        else
                        {
                           /*~A:749*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A749*/
                        /*~-1*/
                        }
                        /*~E:I724*/
                     /*~-1*/
                     }
                     /*~E:I720*/
                     /*~E:A719*/
                     /*~I:750*/
#ifdef MOF
                     /*~A:751*/
                     /*~+:GCO - GetCurrentinterfaceOffset*/
                     /*~I:752*/
                     if (!strcmp(szCommand,"GCO"))
                     /*~-1*/
                     {
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:753*/
                        if (!InstructionDecoder_CheckNbParameters(2,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0);
                           Parameter[1].nLong = Communication_GetLongParameter(1);
                           /*~I:754*/
                           if (Parameter[1].nLong < 2)
                           /*~-1*/
                           {
                              /*~C:755*/
                              switch (Parameter[0].nLong)
                              /*~-1*/
                              {
                              /*~F:756*/
                              case 0:
                              /*~-1*/
                              {
                              /*~A:757*/
                              /*~+:Kanal 0*/
                              /*~I:758*/
#ifdef CHANNEL_0
                              /*~I:759*/
                              if (Parameter[1].nLong)
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_CURRENT_INTERFACE_OFFSET_NORM_CHANNEL_0,ADuC836_DACGetOffset(1),1,0);
                              /*~-1*/
                              }
                              /*~O:I759*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_CURRENT_INTERFACE_OFFSET_RMW_CHANNEL_0,ADuC836_DACGetOffset(0),1,0);
                              /*~-1*/
                              }
                              /*~E:I759*/
                              /*~-1*/
#endif
                              /*~E:I758*/
                              /*~E:A757*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F756*/
                              /*~F:760*/
                              case 1:
                              /*~-1*/
                              {
                              /*~A:761*/
                              /*~+:Kanal 1*/
                              /*~I:762*/
#ifdef CHANNEL_1
                              /*~I:763*/
                              if (Parameter[1].nLong)
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_CURRENT_INTERFACE_OFFSET_NORM_CHANNEL_1,ADuC836_DACGetOffset(1),1,0);
                              /*~-1*/
                              }
                              /*~O:I763*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_CURRENT_INTERFACE_OFFSET_RMW_CHANNEL_1,ADuC836_DACGetOffset(0),1,0);
                              /*~-1*/
                              }
                              /*~E:I763*/
                              /*~-1*/
#endif
                              /*~E:I762*/
                              /*~E:A761*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F760*/
                              /*~O:C755*/
                              /*~-2*/
                              default:
                              {
                              /*~A:764*/
                              /*~+:Kanal 0*/
                              /*~I:765*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I765*/
                              /*~E:A764*/
                              /*~-1*/
                              }
                              /*~-1*/
                              }
                              /*~E:C755*/
                           /*~-1*/
                           }
                           /*~O:I754*/
                           /*~-2*/
                           else
                           {
                              /*~A:766*/
                              /*~+:Kanal 0*/
                              /*~I:767*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E002;
                              /*~-1*/
#endif
                              /*~E:I767*/
                              /*~E:A766*/
                           /*~-1*/
                           }
                           /*~E:I754*/
                        /*~-1*/
                        }
                        /*~O:I753*/
                        /*~-2*/
                        else
                        {
                           /*~A:768*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A768*/
                        /*~-1*/
                        }
                        /*~E:I753*/
                     /*~-1*/
                     }
                     /*~E:I752*/
                     /*~E:A751*/
                     /*~-1*/
#endif
                     /*~E:I750*/
                     /*~I:769*/
#ifdef SYSTEM_CND_ADC_MIT_WANDLERRATENERMITTLUNG
                     /*~A:770*/
                     /*~+:GCR - GetConvertionRate*/
                     /*~+:GCT - GetConversionTime*/
                     /*~I:771*/
                     if (!strcmp(szCommand,"GCT")||!strcmp(szCommand,"GCR"))
                     /*~-1*/
                     {
                        /*~T*/
                        unsigned char byTimeMode;
                        /*~I:772*/
                        if (!strcmp(szCommand,"GCT"))
                        /*~-1*/
                        {
                           /*~T*/
                           byTimeMode = 1;
                        /*~-1*/
                        }
                        /*~O:I772*/
                        /*~-2*/
                        else
                        {
                           /*~T*/
                           byTimeMode = 0;
                        /*~-1*/
                        }
                        /*~E:I772*/
                        /*~T*/
                        // Text wurde bereits gesendet
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:773*/
#ifndef MOF
                        /*~I:774*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0); 
                           /*~C:775*/
                           switch (Parameter[0].nLong)
                           /*~-1*/
                           {
                              /*~F:776*/
                              case 0:
                              /*~-1*/
                              {
                              /*~A:777*/
                              /*~+:Kanal 0*/
                              /*~I:778*/
#ifdef CHANNEL_0
                              /*~T*/
                              unsigned int uConversionTime = ADuC836_ADCGetConversionTime(Parameter[1].nLong);
                              /*~I:779*/
                              if (byTimeMode)
                              /*~-1*/
                              {
                              /*~A:780*/
                              /*~+:Zeitintervall bis zur Wandlung des Gewichts*/
                              /*~T*/
                              // Zeitintervall bis zur Wandlung des Gewichts
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_WEIGHT_CONVERSIONTIME_CHANNEL_0,uConversionTime,1,0);
                              /*~E:A780*/
                              /*~-1*/
                              }
                              /*~O:I779*/
                              /*~-2*/
                              else
                              {
                              /*~A:781*/
                              /*~+:Frequenz der Wandlung des Gewichts*/
                              /*~T*/
                              // Frequenz der Wandlung des Gewichts
                              /*~T*/
                              Communication_SendFloat(COMMUNICATION_RS232,TEXT_WEIGHT_CONVERSIONRATE_CHANNEL_0,1/((float)uConversionTime/1000),2,1,0);
                              /*~E:A781*/
                              /*~-1*/
                              }
                              /*~E:I779*/
                              /*~-1*/
#endif
                              /*~E:I778*/
                              /*~E:A777*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F776*/
                              /*~F:782*/
                              case 1:
                              /*~-1*/
                              {
                              /*~A:783*/
                              /*~+:Kanal 1*/
                              /*~I:784*/
#ifdef CHANNEL_1
                              /*~T*/
                              unsigned int uConversionTime = ADuC836_ADCGetConversionTime(Parameter[1].nLong);
                              /*~I:785*/
                              if (byTimeMode)
                              /*~-1*/
                              {
                              /*~A:786*/
                              /*~+:Zeitintervall bis zur Wandlung des Gewichts*/
                              /*~T*/
                              // Zeitintervall bis zur Wandlung des Gewichts
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_WEIGHT_CONVERSIONTIME_CHANNEL_1,uConversionTime,1,0);
                              /*~E:A786*/
                              /*~-1*/
                              }
                              /*~O:I785*/
                              /*~-2*/
                              else
                              {
                              /*~A:787*/
                              /*~+:Frequenz der Wandlung des Gewichts*/
                              /*~T*/
                              // Frequenz der Wandlung des Gewichts
                              /*~T*/
                              Communication_SendFloat(COMMUNICATION_RS232,TEXT_WEIGHT_CONVERSIONRATE_CHANNEL_1,1/((float)uConversionTime/1000),2,1,0);
                              /*~E:A787*/
                              /*~-1*/
                              }
                              /*~E:I785*/
                              /*~-1*/
#endif
                              /*~E:I784*/
                              /*~E:A783*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F782*/
                              /*~O:C775*/
                              /*~-2*/
                              default:
                              {
                              /*~A:788*/
                              /*~+:Kanal 0*/
                              /*~I:789*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I789*/
                              /*~E:A788*/
                              /*~-1*/
                              }
                           /*~-1*/
                           }
                           /*~E:C775*/
                        /*~-1*/
                        }
                        /*~O:I774*/
                        /*~-2*/
                        else
                        {
                           /*~A:790*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A790*/
                        /*~-1*/
                        }
                        /*~E:I774*/
                        /*~O:I773*/
                        /*~-1*/
#else
                        /*~A:791*/
                        /*~+:f�r sp�tere Verwendung*/
                        /*~I:792*/
                        if (!InstructionDecoder_CheckNbParameters(2,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0);
                           Parameter[1].nLong = Communication_GetLongParameter(1); 
                           /*~I:793*/
#ifndef OHNE_STROMRUECKFUEHRUNG
                           if (Parameter[1].nLong < 4)
#else
                           if ((Parameter[1].nLong < 4)&&(Parameter[1].nLong != 2))
#endif
                           /*~-1*/
                           {
                              /*~C:794*/
                              switch (Parameter[0].nLong)
                              /*~-1*/
                              {
                              /*~F:795*/
                              case 0:
                              /*~-1*/
                              {
                              /*~A:796*/
                              /*~+:Kanal 0*/
                              /*~I:797*/
#ifdef CHANNEL_0
                              /*~T*/
                              unsigned int uConversionTime = ADuC836_ADCGetConversionTime(Parameter[1].nLong);
                              /*~C:798*/
                              switch (Parameter[1].nLong)
                              /*~-1*/
                              {
                              /*~F:799*/
                              case 0:
                              /*~-1*/
                              {
                              /*~I:800*/
                              if (byTimeMode)
                              /*~-1*/
                              {
                              /*~A:801*/
                              /*~+:Zeitintervall bis zur Wandlung des Gewichts*/
                              /*~T*/
                              // Zeitintervall bis zur Wandlung des Gewichts
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_WEIGHT_CONVERSIONTIME_CHANNEL_0,uConversionTime,1,0);
                              /*~E:A801*/
                              /*~-1*/
                              }
                              /*~O:I800*/
                              /*~-2*/
                              else
                              {
                              /*~A:802*/
                              /*~+:Frequenz der Wandlung des Gewichts*/
                              /*~T*/
                              // Frequenz der Wandlung des Gewichts
                              /*~T*/
                              Communication_SendFloat(COMMUNICATION_RS232,TEXT_WEIGHT_CONVERSIONRATE_CHANNEL_0,1/((float)uConversionTime/1000),2,1,0);
                              /*~E:A802*/
                              /*~-1*/
                              }
                              /*~E:I800*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F799*/
                              /*~F:803*/
                              case 1:
                              /*~-1*/
                              {
                              /*~I:804*/
                              if (byTimeMode)
                              /*~-1*/
                              {
                              /*~A:805*/
                              /*~+:Zeitintervall bis zur Wandlung der Temperatur*/
                              /*~T*/
                              // Zeitintervall bis zur Wandlung der Temperatur
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_TEMPERATURE_CONVERSIONTIME_CHANNEL_0,uConversionTime,1,0);
                              /*~E:A805*/
                              /*~-1*/
                              }
                              /*~O:I804*/
                              /*~-2*/
                              else
                              {
                              /*~A:806*/
                              /*~+:Frequenz der Wandlung der Temperatur*/
                              /*~T*/
                              // Frequenz der Wandlung der Temperatur
                              /*~T*/
                              Communication_SendFloat(COMMUNICATION_RS232,TEXT_TEMPERATURE_CONVERSIONRATE_CHANNEL_0,1/((float)uConversionTime/1000),2,1,0);
                              /*~E:A806*/
                              /*~-1*/
                              }
                              /*~E:I804*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F803*/
                              /*~F:807*/
                              case 2:
                              /*~-1*/
                              {
                              /*~I:808*/
                              if (byTimeMode)
                              /*~-1*/
                              {
                              /*~A:809*/
                              /*~+:Zeitintervall bis zur Wandlung des Ausgangsstroms*/
                              /*~T*/
                              // Zeitintervall bis zur Wandlung des Ausgangsstroms
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_FEEDBACK_CONVERSIONTIME_CHANNEL_0,uConversionTime,1,0);
                              /*~E:A809*/
                              /*~-1*/
                              }
                              /*~O:I808*/
                              /*~-2*/
                              else
                              {
                              /*~A:810*/
                              /*~+:Frequenz der Wandlung des Ausgangsstroms*/
                              /*~T*/
                              // Frequenz der Wandlung des Ausgangsstroms
                              /*~T*/
                              Communication_SendFloat(COMMUNICATION_RS232,TEXT_FEEDBACK_CONVERSIONRATE_CHANNEL_0,1/((float)uConversionTime/1000),2,1,0);
                              /*~E:A810*/
                              /*~-1*/
                              }
                              /*~E:I808*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F807*/
                              /*~F:811*/
                              case 3:
                              /*~-1*/
                              {
                              /*~I:812*/
                              if (byTimeMode)
                              /*~-1*/
                              {
                              /*~A:813*/
                              /*~+:Zeitintervall bis zur Wandlung der Netzteilspannung*/
                              /*~T*/
                              // Zeitintervall bis zur Wandlung der Netzteilspannung
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_SUPPLY_CONVERSIONTIME_CHANNEL_0,uConversionTime,1,0);
                              /*~E:A813*/
                              /*~-1*/
                              }
                              /*~O:I812*/
                              /*~-2*/
                              else
                              {
                              /*~A:814*/
                              /*~+:Frequenz der Wandlung der Netzteilspannung*/
                              /*~T*/
                              // Frequenz der Wandlung der Netzteilspannung
                              /*~T*/
                              Communication_SendFloat(COMMUNICATION_RS232,TEXT_SUPPLY_CONVERSIONRATE_CHANNEL_0,1/((float)uConversionTime/1000),2,1,0);
                              /*~E:A814*/
                              /*~-1*/
                              }
                              /*~E:I812*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F811*/
                              /*~-1*/
                              }
                              /*~E:C798*/
                              /*~-1*/
#endif
                              /*~E:I797*/
                              /*~E:A796*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F795*/
                              /*~F:815*/
                              case 1:
                              /*~-1*/
                              {
                              /*~A:816*/
                              /*~+:Kanal 1*/
                              /*~I:817*/
#ifdef CHANNEL_1
                              /*~T*/
                              unsigned int uConversionTime = ADuC836_ADCGetConversionTime(Parameter[1].nLong);
                              /*~C:818*/
                              switch (Parameter[1].nLong)
                              /*~-1*/
                              {
                              /*~F:819*/
                              case 0:
                              /*~-1*/
                              {
                              /*~I:820*/
                              if (byTimeMode)
                              /*~-1*/
                              {
                              /*~A:821*/
                              /*~+:Zeitintervall bis zur Wandlung des Gewichts*/
                              /*~T*/
                              // Zeitintervall bis zur Wandlung des Gewichts
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_WEIGHT_CONVERSIONTIME_CHANNEL_1,uConversionTime,1,0);
                              /*~E:A821*/
                              /*~-1*/
                              }
                              /*~O:I820*/
                              /*~-2*/
                              else
                              {
                              /*~A:822*/
                              /*~+:Frequenz der Wandlung des Gewichts*/
                              /*~T*/
                              // Frequenz der Wandlung des Gewichts
                              /*~T*/
                              Communication_SendFloat(COMMUNICATION_RS232,TEXT_WEIGHT_CONVERSIONRATE_CHANNEL_1,1/((float)uConversionTime/1000),2,1,0);
                              /*~E:A822*/
                              /*~-1*/
                              }
                              /*~E:I820*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F819*/
                              /*~F:823*/
                              case 1:
                              /*~-1*/
                              {
                              /*~I:824*/
                              if (byTimeMode)
                              /*~-1*/
                              {
                              /*~A:825*/
                              /*~+:Zeitintervall bis zur Wandlung der Temperatur*/
                              /*~T*/
                              // Zeitintervall bis zur Wandlung der Temperatur
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_TEMPERATURE_CONVERSIONTIME_CHANNEL_1,uConversionTime,1,0);
                              /*~E:A825*/
                              /*~-1*/
                              }
                              /*~O:I824*/
                              /*~-2*/
                              else
                              {
                              /*~A:826*/
                              /*~+:Frequenz der Wandlung der Temperatur*/
                              /*~T*/
                              // Frequenz der Wandlung der Temperatur
                              /*~T*/
                              Communication_SendFloat(COMMUNICATION_RS232,TEXT_TEMPERATURE_CONVERSIONRATE_CHANNEL_1,1/((float)uConversionTime/1000),2,1,0);
                              /*~E:A826*/
                              /*~-1*/
                              }
                              /*~E:I824*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F823*/
                              /*~F:827*/
                              case 2:
                              /*~-1*/
                              {
                              /*~I:828*/
                              if (byTimeMode)
                              /*~-1*/
                              {
                              /*~A:829*/
                              /*~+:Zeitintervall bis zur Wandlung des Ausgangsstroms*/
                              /*~T*/
                              // Zeitintervall bis zur Wandlung des Ausgangsstroms
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_FEEDBACK_CONVERSIONTIME_CHANNEL_1,uConversionTime,1,0);
                              /*~E:A829*/
                              /*~-1*/
                              }
                              /*~O:I828*/
                              /*~-2*/
                              else
                              {
                              /*~A:830*/
                              /*~+:Frequenz der Wandlung des Ausgangsstroms*/
                              /*~T*/
                              // Frequenz der Wandlung des Ausgangsstroms
                              /*~T*/
                              Communication_SendFloat(COMMUNICATION_RS232,TEXT_FEEDBACK_CONVERSIONRATE_CHANNEL_1,1/((float)uConversionTime/1000),2,1,0);
                              /*~E:A830*/
                              /*~-1*/
                              }
                              /*~E:I828*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F827*/
                              /*~F:831*/
                              case 3:
                              /*~-1*/
                              {
                              /*~I:832*/
                              if (byTimeMode)
                              /*~-1*/
                              {
                              /*~A:833*/
                              /*~+:Zeitintervall bis zur Wandlung der Netzteilspannung*/
                              /*~T*/
                              // Zeitintervall bis zur Wandlung der Netzteilspannung
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_SUPPLY_CONVERSIONTIME_CHANNEL_1,uConversionTime,1,0);
                              /*~E:A833*/
                              /*~-1*/
                              }
                              /*~O:I832*/
                              /*~-2*/
                              else
                              {
                              /*~A:834*/
                              /*~+:Frequenz der Wandlung der Netzteilspannung*/
                              /*~T*/
                              // Frequenz der Wandlung der Netzteilspannung
                              /*~T*/
                              Communication_SendFloat(COMMUNICATION_RS232,TEXT_SUPPLY_CONVERSIONRATE_CHANNEL_1,1/((float)uConversionTime/1000),2,1,0);
                              /*~E:A834*/
                              /*~-1*/
                              }
                              /*~E:I832*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F831*/
                              /*~-1*/
                              }
                              /*~E:C818*/
                              /*~-1*/
#endif
                              /*~E:I817*/
                              /*~E:A816*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F815*/
                              /*~O:C794*/
                              /*~-2*/
                              default:
                              {
                              /*~A:835*/
                              /*~+:Kanal 0*/
                              /*~I:836*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I836*/
                              /*~E:A835*/
                              /*~-1*/
                              }
                              /*~-1*/
                              }
                              /*~E:C794*/
                           /*~-1*/
                           }
                           /*~O:I793*/
                           /*~-2*/
                           else
                           {
                              /*~A:837*/
                              /*~+:Kanal 0*/
                              /*~I:838*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E002;
                              /*~-1*/
#endif
                              /*~E:I838*/
                              /*~E:A837*/
                           /*~-1*/
                           }
                           /*~E:I793*/
                        /*~-1*/
                        }
                        /*~O:I792*/
                        /*~-2*/
                        else
                        {
                           /*~A:839*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A839*/
                        /*~-1*/
                        }
                        /*~E:I792*/
                        /*~E:A791*/
                        /*~-1*/
#endif
                        /*~E:I773*/
                     /*~-1*/
                     }
                     /*~E:I771*/
                     /*~E:A770*/
                     /*~O:I769*/
                     /*~-1*/
#else
                     /*~A:840*/
                     /*~+:GCR - GetConvertionRate*/
                     /*~I:841*/
                     if (!strcmp(szCommand,"GCR"))
                     /*~-1*/
                     {
                        /*~T*/
                        // Text wurde bereits gesendet
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:842*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0); 
                           /*~C:843*/
                           switch (Parameter[0].nLong)
                           /*~-1*/
                           {
                              /*~F:844*/
                              case 0:
                              /*~-1*/
                              {
                              /*~A:845*/
                              /*~+:Kanal 0*/
                              /*~I:846*/
#ifdef CHANNEL_0
                              /*~A:847*/
                              /*~+:Zeitintervall bis zur Wandlung des Gewichts*/
                              /*~T*/
                              // Frequenz der Wandlung des Gewichts
                              /*~T*/
                              Communication_SendFloat(COMMUNICATION_RS232,TEXT_WEIGHT_CONVERSIONRATE_CHANNEL_0,ADuC836_ADCGetConversionRate(ADuC836_ADC_FREQUENCY_32KHZ),2,1,0);
                              /*~E:A847*/
                              /*~-1*/
#endif
                              /*~E:I846*/
                              /*~E:A845*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F844*/
                              /*~F:848*/
                              case 1:
                              /*~-1*/
                              {
                              /*~A:849*/
                              /*~+:Kanal 1*/
                              /*~I:850*/
#ifdef CHANNEL_1
                              /*~A:851*/
                              /*~+:Zeitintervall bis zur Wandlung des Gewichts*/
                              /*~T*/
                              // Frequenz der Wandlung des Gewichts
                              /*~T*/
                              Communication_SendFloat(COMMUNICATION_RS232,TEXT_WEIGHT_CONVERSIONRATE_CHANNEL_1,ADuC836_ADCGetConversionRate(ADuC836_ADC_FREQUENCY_32KHZ),2,1,0);
                              /*~E:A851*/
                              /*~-1*/
#endif
                              /*~E:I850*/
                              /*~E:A849*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F848*/
                              /*~O:C843*/
                              /*~-2*/
                              default:
                              {
                              /*~A:852*/
                              /*~+:Kanal 0*/
                              /*~I:853*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I853*/
                              /*~E:A852*/
                              /*~-1*/
                              }
                           /*~-1*/
                           }
                           /*~E:C843*/
                        /*~-1*/
                        }
                        /*~O:I842*/
                        /*~-2*/
                        else
                        {
                           /*~A:854*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A854*/
                        /*~-1*/
                        }
                        /*~E:I842*/
                     /*~-1*/
                     }
                     /*~E:I841*/
                     /*~E:A840*/
                     /*~-1*/
#endif
                     /*~E:I769*/
                     /*~A:855*/
                     /*~+:GCS - GetCompensationState*/
                     /*~I:856*/
                     if (!strcmp(szCommand,"GCS"))
                     /*~-1*/
                     {
                        /*~A:857*/
                        /*~+:Variablendeklarationen*/
                        /*~I:858*/
#ifdef CHANNEL_0
                        /*~T*/
                        long lTempCompPartnerOn;

                        /*~-1*/
#endif
                        /*~E:I858*/
                        /*~E:A857*/
                        /*~T*/
                        // Text wurde bereits gesendet
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:859*/
                        if (!InstructionDecoder_CheckNbParameters(0,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           byTemp = MRW_Compensation_GetCompensationOnOffStatus();
                           /*~I:860*/
#ifdef CHANNEL_0
                           /*~I:861*/
                           if (!Communication_GetSPIValue(COMMUNICATION_COMPENSATION_STATE,&lTempCompPartnerOn))
                           /*~-1*/
                           {
                              /*~I:862*/
                              if ((char)lTempCompPartnerOn == byTemp)
                              /*~-1*/
                              {
                              /*~I:863*/
                              if (!SYSTEM_MRW_MANAGER)
                              /*~-1*/
                              {
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              /*~I:864*/
                              if (byTemp)
                              /*~-1*/
                              {
                              /*~T*/
                              lText2Send = TEXT_COMPENSATION_SWITCHED_ON;
                              /*~-1*/
                              }
                              /*~O:I864*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              lText2Send = TEXT_COMPENSATION_SWITCHED_OFF;
                              /*~-1*/
                              }
                              /*~E:I864*/
                              /*~-1*/
                              }
                              /*~O:I863*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,0,byTemp,1,0);
                              /*~-1*/
                              }
                              /*~E:I863*/
                              /*~-1*/
                              }
                              /*~O:I862*/
                              /*~-2*/
                              else
                              {
                              /*~A:865*/
                              /*~+:Fehler - Werte beider Kan�le sind nicht identisch - E011*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E011;
                              /*~E:A865*/
                              /*~-1*/
                              }
                              /*~E:I862*/
                           /*~-1*/
                           }
                           /*~O:I861*/
                           /*~-2*/
                           else
                           {
                              /*~A:866*/
                              /*~+:Fehler bei der Kommunikation - E005*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A866*/
                           /*~-1*/
                           }
                           /*~E:I861*/
                           /*~O:I860*/
                           /*~-1*/
#else
                           /*~I:867*/
#ifdef CHANNEL_1
                           /*~T*/
                           InstructionDecoder_StoreValue(COMMUNICATION_COMPENSATION_STATE,(GLOBAL_UNIVALUE_SHORT*)&byTemp);
                           /*~-1*/
#endif
                           /*~E:I867*/
                           /*~-1*/
#endif
                           /*~E:I860*/
                        /*~-1*/
                        }
                        /*~O:I859*/
                        /*~-2*/
                        else
                        {
                           /*~A:868*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A868*/
                        /*~-1*/
                        }
                        /*~E:I859*/
                     /*~-1*/
                     }
                     /*~E:I856*/
                     /*~E:A855*/
                     /*~A:869*/
                     /*~+:GCU - GetCUrrent*/
                     /*~I:870*/
                     if (!strcmp(szCommand,"GCU"))
                     /*~-1*/
                     {
                        /*~T*/
                        // Text wurde bereits gesendet
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:871*/
                        if (!InstructionDecoder_CheckNbParameters(2,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0);
                           Parameter[1].nLong = Communication_GetLongParameter(1);
                           /*~T*/
                           fTemp = CurrentInterface_GetCurrent((unsigned char)Parameter[1].nLong);
                           /*~C:872*/
                           switch (Parameter[0].nLong)
                           /*~-1*/
                           {
                              /*~F:873*/
                              case 0:
                              /*~-1*/
                              {
                              /*~A:874*/
                              /*~+:Kanal 0*/
                              /*~I:875*/
#ifdef CHANNEL_0
                              /*~I:876*/
#ifndef OHNE_STROMRUECKFUEHRUNG
                              /*~C:877*/
                              switch (Parameter[1].nLong)
                              /*~-1*/
                              {
                              /*~F:878*/
                              case 0:
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendFloat(COMMUNICATION_RS232,TEXT_CURRENT_INTERFACE_ACTUAL_CURRENT_CHANNEL_0,fTemp,3,1,0);
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F878*/
                              /*~F:879*/
                              case 1:
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendFloat(COMMUNICATION_RS232,TEXT_CURRENT_INTERFACE_ACTUAL_CURRENT_MEASURED_CHANNEL_0,fTemp,3,1,0);
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F879*/
                              /*~O:C877*/
                              /*~-2*/
                              default:
                              {
                              /*~T*/
                              Communication_SendFloat(COMMUNICATION_RS232,TEXT_CURRENT_INTERFACE_ACTUAL_DEVIATION_CHANNEL_0,g_CurrentInterface.FeedBack.Results.Deviation.fFloat,5,1,0);
                              /*~-1*/
                              }
                              /*~-1*/
                              }
                              /*~E:C877*/
                              /*~O:I876*/
                              /*~-1*/
#else
                              /*~T*/
                              Communication_SendFloat(COMMUNICATION_RS232,TEXT_CURRENT_INTERFACE_ACTUAL_CURRENT_CHANNEL_0,fTemp,3,1,0);
                              /*~-1*/
#endif
                              /*~E:I876*/
                              /*~-1*/
#endif
                              /*~E:I875*/
                              /*~E:A874*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F873*/
                              /*~F:880*/
                              case 1:
                              /*~-1*/
                              {
                              /*~A:881*/
                              /*~+:Kanal 1*/
                              /*~I:882*/
#ifdef CHANNEL_1
                              /*~I:883*/
#ifndef OHNE_STROMRUECKFUEHRUNG 
                              /*~C:884*/
                              switch (Parameter[1].nLong)
                              /*~-1*/
                              {
                              /*~F:885*/
                              case 0:
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendFloat(COMMUNICATION_RS232,TEXT_CURRENT_INTERFACE_ACTUAL_CURRENT_CHANNEL_1,fTemp,3,1,0);
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F885*/
                              /*~F:886*/
                              case 1:
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendFloat(COMMUNICATION_RS232,TEXT_CURRENT_INTERFACE_ACTUAL_CURRENT_MEASURED_CHANNEL_1,fTemp,3,1,0);
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F886*/
                              /*~O:C884*/
                              /*~-2*/
                              default:
                              {
                              /*~T*/
                              Communication_SendFloat(COMMUNICATION_RS232,TEXT_CURRENT_INTERFACE_ACTUAL_DEVIATION_CHANNEL_1,g_CurrentInterface.FeedBack.Results.Deviation.fFloat,5,1,0);
                              /*~-1*/
                              }
                              /*~-1*/
                              }
                              /*~E:C884*/
                              /*~O:I883*/
                              /*~-1*/
#else
                              /*~T*/
                              Communication_SendFloat(COMMUNICATION_RS232,TEXT_CURRENT_INTERFACE_ACTUAL_CURRENT_CHANNEL_1,fTemp,3,1,0);
                              /*~-1*/
#endif
                              /*~E:I883*/
                              /*~-1*/
#endif
                              /*~E:I882*/
                              /*~E:A881*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F880*/
                              /*~O:C872*/
                              /*~-2*/
                              default:
                              {
                              /*~A:887*/
                              /*~+:Kanal 0*/
                              /*~I:888*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I888*/
                              /*~E:A887*/
                              /*~-1*/
                              }
                           /*~-1*/
                           }
                           /*~E:C872*/
                        /*~-1*/
                        }
                        /*~O:I871*/
                        /*~-2*/
                        else
                        {
                           /*~A:889*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A889*/
                        /*~-1*/
                        }
                        /*~E:I871*/
                     /*~-1*/
                     }
                     /*~E:I870*/
                     /*~E:A869*/
                     /*~A:890*/
                     /*~+:GCV - GetCompensationValue*/
                     /*~I:891*/
                     if (!strcmp(szCommand,"GCV"))
                     /*~-1*/
                     {
                        /*~T*/
                        int nCorVal;
                        /*~T*/
                        // Text wurde bereits gesendet
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:892*/
                        if (!InstructionDecoder_CheckNbParameters(2,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0);
                           Parameter[1].nLong = Communication_GetLongParameter(1);
                           /*~C:893*/
                           switch (Parameter[0].nLong)
                           /*~-1*/
                           {
                              /*~F:894*/
                              case 0:
                              /*~-1*/
                              {
                              /*~A:895*/
                              /*~+:Kanal 0*/
                              /*~I:896*/
#ifdef CHANNEL_0
                              /*~T*/
                              nCorVal = Compensation_GetCompensationValue((char)Parameter[1].nLong);
                              /*~I:897*/
                              if ((char)Parameter[1].nLong == 20)
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_COMPENSATION_REFPOINT_OFFSET_CHANNEL_0,nCorVal,1,0);
                              /*~-1*/
                              }
                              /*~O:I897*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_COMPENSATION_REFPOINT_CHANNEL_0,nCorVal,1,0);
                              /*~-1*/
                              }
                              /*~E:I897*/
                              /*~-1*/
#endif
                              /*~E:I896*/
                              /*~E:A895*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F894*/
                              /*~F:898*/
                              case 1:
                              /*~-1*/
                              {
                              /*~A:899*/
                              /*~+:Kanal 1*/
                              /*~I:900*/
#ifdef CHANNEL_1
                              /*~T*/
                              nCorVal = Compensation_GetCompensationValue((char)Parameter[1].nLong);
                              /*~I:901*/
                              if ((char)Parameter[1].nLong == 20)
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_COMPENSATION_REFPOINT_OFFSET_CHANNEL_1,nCorVal,1,0);
                              /*~-1*/
                              }
                              /*~O:I901*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_COMPENSATION_REFPOINT_CHANNEL_1,nCorVal,1,0);
                              /*~-1*/
                              }
                              /*~E:I901*/
                              /*~-1*/
#endif
                              /*~E:I900*/
                              /*~E:A899*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F898*/
                              /*~O:C893*/
                              /*~-2*/
                              default:
                              {
                              /*~A:902*/
                              /*~+:Kanal 0*/
                              /*~I:903*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I903*/
                              /*~E:A902*/
                              /*~-1*/
                              }
                           /*~-1*/
                           }
                           /*~E:C893*/
                        /*~-1*/
                        }
                        /*~O:I892*/
                        /*~-2*/
                        else
                        {
                           /*~A:904*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A904*/
                        /*~-1*/
                        }
                        /*~E:I892*/
                     /*~-1*/
                     }
                     /*~E:I891*/
                     /*~E:A890*/
                     /*~A:905*/
                     /*~+:GDB - GetDeBugvariables*/
                     /*~I:906*/
#ifdef MIT_DEBUG
                     /*~I:907*/
                     if (!strcmp(szCommand,"GDB"))
                     /*~-1*/
                     {
                        /*~A:908*/
                        /*~+:Variablendeklarationen*/
                        /*~T*/
                        char byCounter;
                        /*~I:909*/
#ifdef CHANNEL_0
                        /*~T*/
                        long lDebVar[DEBUG_NB_DEBUGVARIABLES];

                        /*~-1*/
#endif
                        /*~E:I909*/
                        /*~E:A908*/
                        /*~A:910*/
                        /*~+:Variableninitialisierungen*/
                        /*~T*/
                        byCounter = 0;
                        /*~E:A910*/
                        /*~T*/
                        // Text wurde bereits gesendet
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:911*/
                        if (!InstructionDecoder_CheckNbParameters(2,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0);
                           Parameter[1].nLong = Communication_GetLongParameter(1);
                           /*~C:912*/
                           switch (Parameter[0].nLong)
                           /*~-1*/
                           {
                              /*~F:913*/
                              case 0:
                              /*~-1*/
                              {
                              /*~A:914*/
                              /*~+:Kanal 0*/
                              /*~I:915*/
#ifdef CHANNEL_0
                              /*~T*/
                              // Debug-Variablen aus dem Eeprom laden
                              Load_Parameter(LOAD_SAVE_DEBUG_VARIABLES,lDebVar,4*DEBUG_NB_DEBUGVARIABLES);
                              /*~U:916*/
                              /*~-2*/
                              do
                              {
                              /*~I:917*/
                              // Variablenindex ausgeben
                              if (Parameter[1].nLong == 255)
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_CONTENT_DEBUG_VARIABLES_CHANNEL_0,byCounter,1,0);

                              /*~-1*/
                              }
                              /*~O:I917*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_CONTENT_DEBUG_VARIABLES_CHANNEL_0,Parameter[1].nLong,1,0);

                              /*~-1*/
                              }
                              /*~E:I917*/
                              /*~T*/
                              // Doppelpunkt
                              Communication_SendString(COMMUNICATION_RS232," : ",0,0);
                              /*~I:918*/
                              // Variableninhalt ausgeben
                              if (Parameter[1].nLong == 255)
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,0,lDebVar[byCounter++],0,0);
                              /*~-1*/
                              }
                              /*~O:I918*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,0,lDebVar[Parameter[1].nLong],0,0);

                              byCounter = 8;
                              /*~-1*/
                              }
                              /*~E:I918*/
                              /*~-1*/
                              }
                              /*~O:U916*/
                              while (byCounter < 8);
                              /*~E:U916*/
                              /*~-1*/
#endif
                              /*~E:I915*/
                              /*~E:A914*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F913*/
                              /*~F:919*/
                              case 1:
                              /*~-1*/
                              {
                              /*~A:920*/
                              /*~+:Kanal 1*/
                              /*~I:921*/
#ifdef CHANNEL_1
                              /*~T*/
                              // Debug-Variablen aus dem Eeprom laden
                              Load_Parameter(LOAD_SAVE_DEBUG_VARIABLES,lDebVar,4*DEBUG_NB_DEBUGVARIABLES);
                              /*~U:922*/
                              /*~-2*/
                              do
                              {
                              /*~I:923*/
                              // Variablenindex ausgeben
                              if (Parameter[1].nLong == 255)
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_CONTENT_DEBUG_VARIABLES_CHANNEL_1,byCounter,1,0);

                              /*~-1*/
                              }
                              /*~O:I923*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_CONTENT_DEBUG_VARIABLES_CHANNEL_1,Parameter[1].nLong,1,0);

                              /*~-1*/
                              }
                              /*~E:I923*/
                              /*~T*/
                              // Doppelpunkt
                              Communication_SendString(COMMUNICATION_RS232," : ",0,0);
                              /*~I:924*/
                              // Variableninhalt ausgeben
                              if (Parameter[1].nLong == 255)
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,0,lDebVar[byCounter++],0,0);
                              /*~-1*/
                              }
                              /*~O:I924*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,0,lDebVar[Parameter[1].nLong],0,0);

                              byCounter = 8;
                              /*~-1*/
                              }
                              /*~E:I924*/
                              /*~-1*/
                              }
                              /*~O:U922*/
                              while (byCounter < 8);
                              /*~E:U922*/
                              /*~-1*/
#endif
                              /*~E:I921*/
                              /*~E:A920*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F919*/
                              /*~O:C912*/
                              /*~-2*/
                              default:
                              {
                              /*~A:925*/
                              /*~+:Kanal 0*/
                              /*~I:926*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I926*/
                              /*~E:A925*/
                              /*~-1*/
                              }
                           /*~-1*/
                           }
                           /*~E:C912*/
                        /*~-1*/
                        }
                        /*~O:I911*/
                        /*~-2*/
                        else
                        {
                           /*~A:927*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A927*/
                        /*~-1*/
                        }
                        /*~E:I911*/
                     /*~-1*/
                     }
                     /*~E:I907*/
                     /*~-1*/
#endif
                     /*~E:I906*/
                     /*~E:A905*/
                     /*~A:928*/
                     /*~+:GEC - GetE-modulCompensationstate*/
                     /*~I:929*/
                     if (!strcmp(szCommand,"GEC"))
                     /*~-1*/
                     {
                        /*~A:930*/
                        /*~+:Variablendeklarationen*/
                        /*~I:931*/
#ifdef CHANNEL_0
                        /*~T*/
                        long lECompPartnerOn;

                        /*~-1*/
#endif
                        /*~E:I931*/
                        /*~E:A930*/
                        /*~T*/
                        // Text wurde bereits gesendet
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:932*/
                        if (!InstructionDecoder_CheckNbParameters(0,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           byTemp = Weight_GetEModulCompensationOnOff();
                           /*~I:933*/
#ifdef CHANNEL_0
                           /*~I:934*/
                           if (!Communication_GetSPIValue(COMMUNICATION_E_COMPENSATION_STATE,&lECompPartnerOn))
                           /*~-1*/
                           {
                              /*~I:935*/
                              if ((char)lECompPartnerOn == byTemp)
                              /*~-1*/
                              {
                              /*~I:936*/
                              if (!SYSTEM_MRW_MANAGER)
                              /*~-1*/
                              {
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              /*~I:937*/
                              if (byTemp)
                              /*~-1*/
                              {
                              /*~T*/
                              lText2Send = TEXT_E_MODUL_COMPENSATION_SWITCHED_ON;
                              /*~-1*/
                              }
                              /*~O:I937*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              lText2Send = TEXT_E_MODUL_COMPENSATION_SWITCHED_OFF;
                              /*~-1*/
                              }
                              /*~E:I937*/
                              /*~-1*/
                              }
                              /*~O:I936*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,0,byTemp,1,0);
                              /*~-1*/
                              }
                              /*~E:I936*/
                              /*~-1*/
                              }
                              /*~O:I935*/
                              /*~-2*/
                              else
                              {
                              /*~A:938*/
                              /*~+:Fehler - Werte beider Kan�le sind nicht identisch - E011*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E011;
                              /*~E:A938*/
                              /*~-1*/
                              }
                              /*~E:I935*/
                           /*~-1*/
                           }
                           /*~O:I934*/
                           /*~-2*/
                           else
                           {
                              /*~A:939*/
                              /*~+:Fehler bei der Kommunikation - E005*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A939*/
                           /*~-1*/
                           }
                           /*~E:I934*/
                           /*~O:I933*/
                           /*~-1*/
#else
                           /*~I:940*/
#ifdef CHANNEL_1
                           /*~T*/
                           InstructionDecoder_StoreValue(COMMUNICATION_E_COMPENSATION_STATE,(GLOBAL_UNIVALUE_SHORT*)&byTemp);
                           /*~-1*/
#endif
                           /*~E:I940*/
                           /*~-1*/
#endif
                           /*~E:I933*/
                        /*~-1*/
                        }
                        /*~O:I932*/
                        /*~-2*/
                        else
                        {
                           /*~A:941*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A941*/
                        /*~-1*/
                        }
                        /*~E:I932*/
                     /*~-1*/
                     }
                     /*~E:I929*/
                     /*~E:A928*/
                     /*~A:942*/
                     /*~+:GFB - GetFeedBackstate*/
                     /*~I:943*/
                     if (!strcmp(szCommand,"GFB"))
                     /*~-1*/
                     {
                        /*~A:944*/
                        /*~+:Variablendeklarationen*/
                        /*~T*/
                        char byRetVal;

                        /*~I:945*/
#ifdef CHANNEL_0 
                        /*~T*/
                        long lFeedbackStatePartner;
                        /*~-1*/
#endif
                        /*~E:I945*/
                        /*~E:A944*/
                        /*~I:946*/
                        if (!InstructionDecoder_CheckNbParameters(0,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           byRetVal = CurrentInterface_GetFeedBackState();
                           /*~I:947*/
#ifdef CHANNEL_0
                           /*~I:948*/
                           if (!Communication_GetSPIValue(COMMUNICATION_CURRENTINTERFACE_FEEDBACK_STATE,&lFeedbackStatePartner))
                           /*~-1*/
                           {
                              /*~I:949*/
                              if ((char)lFeedbackStatePartner == byRetVal)
                              /*~-1*/
                              {
                              /*~I:950*/
                              if (!SYSTEM_MRW_MANAGER)
                              /*~-1*/
                              {
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              /*~I:951*/
                              if (byRetVal)
                              /*~-1*/
                              {
                              /*~T*/
                              lText2Send = TEXT_FEEDBACK_STATE_ON;
                              /*~-1*/
                              }
                              /*~O:I951*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              lText2Send = TEXT_FEEDBACK_STATE_OFF;
                              /*~-1*/
                              }
                              /*~E:I951*/
                              /*~-1*/
                              }
                              /*~O:I950*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,0,byRetVal,1,0);
                              /*~-1*/
                              }
                              /*~E:I950*/
                              /*~-1*/
                              }
                              /*~O:I949*/
                              /*~-2*/
                              else
                              {
                              /*~A:952*/
                              /*~+:Fehler - Werte beider Kan�le sind nicht identisch - E011*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E011;
                              /*~E:A952*/
                              /*~-1*/
                              }
                              /*~E:I949*/
                           /*~-1*/
                           }
                           /*~O:I948*/
                           /*~-2*/
                           else
                           {
                              /*~A:953*/
                              /*~+:Fehler bei der Kommunikation - E005*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A953*/
                           /*~-1*/
                           }
                           /*~E:I948*/
                           /*~O:I947*/
                           /*~-1*/
#else
                           /*~I:954*/
#ifdef CHANNEL_1 
                           /*~T*/
                           InstructionDecoder_StoreValue(COMMUNICATION_CURRENTINTERFACE_FEEDBACK_STATE,(GLOBAL_UNIVALUE_SHORT*)&byRetVal);
                           /*~-1*/
#endif
                           /*~E:I954*/
                           /*~-1*/
#endif
                           /*~E:I947*/
                        /*~-1*/
                        }
                        /*~O:I946*/
                        /*~-2*/
                        else
                        {
                           /*~A:955*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A955*/
                        /*~-1*/
                        }
                        /*~E:I946*/
                     /*~-1*/
                     }
                     /*~E:I943*/
                     /*~E:A942*/
                     /*~A:956*/
                     /*~+:GFD - GetFilterDepth*/
                     /*~I:957*/
                     if (!strcmp(szCommand,"GFD"))
                     /*~-1*/
                     {
                        /*~A:958*/
                        /*~+:Variablendeklarationen*/
                        /*~I:959*/
#ifdef CHANNEL_0
                        /*~T*/
                        long lFilterdepthPartner;

                        /*~-1*/
#endif
                        /*~E:I959*/
                        /*~E:A958*/
                        /*~T*/
                        // Text wurde bereits gesendet
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:960*/
                        if (!InstructionDecoder_CheckNbParameters(0,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           byTemp = AverageFilter_GetFilterDepth(WEIGHT_WEIGHTCHANNEL);
                           /*~I:961*/
#ifdef CHANNEL_0
                           /*~I:962*/
                           if (!Communication_GetSPIValue(COMMUNICATION_FILTER_DEPTH,&lFilterdepthPartner))
                           /*~-1*/
                           {
                              /*~I:963*/
                              if ((char)lFilterdepthPartner == byTemp)
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_AVERAGE_FILTER_ACTUAL_DEPTH,(char)byTemp,1,0);
                              /*~-1*/
                              }
                              /*~O:I963*/
                              /*~-2*/
                              else
                              {
                              /*~A:964*/
                              /*~+:Fehler - Werte beider Kan�le sind nicht identisch - E011*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E011;
                              /*~E:A964*/
                              /*~-1*/
                              }
                              /*~E:I963*/
                           /*~-1*/
                           }
                           /*~O:I962*/
                           /*~-2*/
                           else
                           {
                              /*~A:965*/
                              /*~+:Fehler bei der Kommunikation - E005*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A965*/
                           /*~-1*/
                           }
                           /*~E:I962*/
                           /*~O:I961*/
                           /*~-1*/
#else
                           /*~I:966*/
#ifdef CHANNEL_1
                           /*~T*/
                           InstructionDecoder_StoreValue(COMMUNICATION_FILTER_DEPTH,(GLOBAL_UNIVALUE_SHORT*)&byTemp);
                           /*~-1*/
#endif
                           /*~E:I966*/
                           /*~-1*/
#endif
                           /*~E:I961*/
                        /*~-1*/
                        }
                        /*~O:I960*/
                        /*~-2*/
                        else
                        {
                           /*~A:967*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A967*/
                        /*~-1*/
                        }
                        /*~E:I960*/
                     /*~-1*/
                     }
                     /*~E:I957*/
                     /*~E:A956*/
                     /*~I:968*/
#ifdef SYSTEM_CND_WITH_DEADBAND_FILTER
                     /*~A:969*/
                     /*~+:GFW - GetFilterWidth*/
                     /*~I:970*/
                     if (!strcmp(szCommand,"GFW"))
                     /*~-1*/
                     {
                        /*~A:971*/
                        /*~+:Variablendeklarationen*/
                        /*~T*/
                        int nFilterBandWidth;

                        /*~I:972*/
#ifdef CHANNEL_0
                        /*~T*/
                        long lFilterBandWidthPartner;
                        /*~-1*/
#endif
                        /*~E:I972*/
                        /*~E:A971*/
                        /*~A:973*/
                        /*~+:Variableninitialsierungen*/
                        /*~T*/

                        /*~E:A973*/
                        /*~T*/
                        // Text wurde bereits gesendet
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:974*/
                        if (!InstructionDecoder_CheckNbParameters(0,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           nFilterBandWidth = (int)DeadBandFilter_GetBandWidth(WEIGHT_WEIGHTCHANNEL); 
                           /*~I:975*/
#ifdef CHANNEL_0
                           /*~I:976*/
                           if (!Communication_GetSPIValue(COMMUNICATION_FILTER_WIDTH,&lFilterBandWidthPartner))

                           /*~-1*/
                           {
                              /*~I:977*/
                              if (lFilterBandWidthPartner == nFilterBandWidth)
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_DEADBAND_FILTER_ACTUAL_WIDTH_CHANNEL_0,(long)nFilterBandWidth,1,0);
                              /*~-1*/
                              }
                              /*~O:I977*/
                              /*~-2*/
                              else
                              {
                              /*~A:978*/
                              /*~+:Fehler - Werte beider Kan�le sind nicht identisch - E011*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E011;
                              /*~E:A978*/
                              /*~-1*/
                              }
                              /*~E:I977*/
                           /*~-1*/
                           }
                           /*~O:I976*/
                           /*~-2*/
                           else
                           {
                              /*~A:979*/
                              /*~+:Fehler bei der Kommunikation - E005*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A979*/
                           /*~-1*/
                           }
                           /*~E:I976*/
                           /*~O:I975*/
                           /*~-1*/
#else
                           /*~I:980*/
#ifdef CHANNEL_1
                           /*~T*/
                           InstructionDecoder_StoreValue(COMMUNICATION_FILTER_WIDTH,(GLOBAL_UNIVALUE_SHORT*)&nFilterBandWidth);
                           /*~-1*/
#endif
                           /*~E:I980*/
                           /*~-1*/
#endif
                           /*~E:I975*/
                        /*~-1*/
                        }
                        /*~O:I974*/
                        /*~-2*/
                        else
                        {
                           /*~A:981*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A981*/
                        /*~-1*/
                        }
                        /*~E:I974*/
                     /*~-1*/
                     }
                     /*~E:I970*/
                     /*~E:A969*/
                     /*~O:I968*/
                     /*~-1*/
#else
                     /*~A:982*/
                     /*~+:GFW - GetFilterWidth*/
                     /*~I:983*/
                     if (!strcmp(szCommand,"GFW"))
                     /*~-1*/
                     {
                        /*~A:984*/
                        /*~+:Variablendeklarationen*/
                        /*~T*/
                        int nFilterBandWidth;

                        /*~I:985*/
#ifdef CHANNEL_0
                        /*~T*/
                        long lFilterBandWidthPartner;
                        /*~-1*/
#endif
                        /*~E:I985*/
                        /*~E:A984*/
                        /*~A:986*/
                        /*~+:Variableninitialsierungen*/
                        /*~T*/

                        /*~E:A986*/
                        /*~T*/
                        // Text wurde bereits gesendet
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:987*/
#ifdef CHANNEL_0
                        /*~T*/
                        Communication_SendLong(COMMUNICATION_RS232,TEXT_DEADBAND_FILTER_ACTUAL_WIDTH_CHANNEL_0,0L,1,0);
                        /*~-1*/
#endif
                        /*~E:I987*/
                     /*~-1*/
                     }
                     /*~E:I983*/
                     /*~E:A982*/
                     /*~-1*/
#endif
                     /*~E:I968*/
                     /*~A:988*/
                     /*~+:GID - GetsystemID*/
                     /*~I:989*/
                     if (!strcmp(szCommand,"GID"))
                     /*~-1*/
                     {
                        /*~T*/
                        // Text wurde bereits gesendet
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:990*/
                        if (!InstructionDecoder_CheckNbParameters(0,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~A:991*/
                           /*~+:Kanal 0*/
                           /*~I:992*/
#ifdef CHANNEL_0
                           /*~A:993*/
                           /*~+:Variablendeklarationen*/
                           /*~T*/

                           /*~E:A993*/
                           /*~T*/
                           Communication_SendLong(COMMUNICATION_RS232,TEXT_SYSTEM_ID,Global.ulSystemID,1,0);
                           /*~-1*/
#endif
                           /*~E:I992*/
                           /*~E:A991*/
                        /*~-1*/
                        }
                        /*~O:I990*/
                        /*~-2*/
                        else
                        {
                           /*~A:994*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A994*/
                        /*~-1*/
                        }
                        /*~E:I990*/
                     /*~-1*/
                     }
                     /*~E:I989*/
                     /*~E:A988*/
                     /*~I:995*/
#ifndef OHNE_STROMRUECKFUEHRUNG
                     /*~A:996*/
                     /*~+:GIP - GetIntegralPortion (of Current Feedback)*/
                     /*~I:997*/
                     if (!strcmp(szCommand,"GIP"))
                     /*~-1*/
                     {
                        /*~T*/
                        // Text wurde bereits gesendet
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:998*/
                        if (!InstructionDecoder_CheckNbParameters(0,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           // Da in beiden Kan�len dieser Wert gleich sein muss, gen�gt die Ausgabe des Kanal 0 
                           /*~A:999*/
                           /*~+:Kanal 0*/
                           /*~I:1000*/
#ifdef CHANNEL_0
                           /*~T*/
                           //Communication_SendLong(COMMUNICATION_RS232,TEXT_FEEDBACK_INTEGRAL_PORTION,100 - CurrentInterface_GetFeedBackIntegralPortion(),1,0);

                           Communication_SendLong(COMMUNICATION_RS232,TEXT_FEEDBACK_INTEGRAL_PORTION,CurrentInterface_GetFeedBackIntegralPortion(),1,0);
                           /*~-1*/
#endif
                           /*~E:I1000*/
                           /*~E:A999*/
                        /*~-1*/
                        }
                        /*~O:I998*/
                        /*~-2*/
                        else
                        {
                           /*~A:1001*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1001*/
                        /*~-1*/
                        }
                        /*~E:I998*/
                     /*~-1*/
                     }
                     /*~E:I997*/
                     /*~E:A996*/
                     /*~-1*/
#endif
                     /*~E:I995*/
                     /*~A:1002*/
                     /*~+:GLC - GetLoadCell*/
                     /*~I:1003*/
                     if (!strcmp(szCommand,"GLC"))
                     /*~-1*/
                     {
                        /*~A:1004*/
                        /*~+:Variablendeklarationen*/
                        /*~I:1005*/
#ifdef CHANNEL_0
                        /*~T*/
                        long lLoadCellTypePartner;
                        /*~-1*/
#endif
                        /*~E:I1005*/
                        /*~E:A1004*/
                        /*~A:1006*/
                        /*~+:Variableninitialisierungen*/
                        /*~T*/

                        /*~E:A1006*/
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:1007*/
                        if (!InstructionDecoder_CheckNbParameters(0,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~I:1008*/
#ifdef CHANNEL_0
                           /*~I:1009*/
                           if (!Communication_GetSPIValue(COMMUNICATION_LOADCELL,&lLoadCellTypePartner))
                           /*~-1*/
                           {
                              /*~I:1010*/
                              if (lLoadCellTypePartner == g_SystemControl.byLoadCellType)
                              /*~-1*/
                              {
                              /*~I:1011*/
                              if (!SYSTEM_MRW_MANAGER)
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendString(COMMUNICATION_RS232,T_TEXT_LOADCELL_TYPE,1,0);

                              /*~C:1012*/
                              switch (g_SystemControl.byLoadCellType)
                              /*~-1*/
                              {
                              /*~F:1013*/
                              case 1:
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendString(COMMUNICATION_RS232,T_TEXT_STANDARD_LOADCELL,0,0);

                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1013*/
                              /*~F:1014*/
                              case 2:
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendString(COMMUNICATION_RS232,T_TEXT_XL_LOADCELL,0,0);

                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1014*/
                              /*~O:C1012*/
                              /*~-2*/
                              default:
                              {
                              /*~T*/
                              Communication_SendString(COMMUNICATION_RS232,T_TEXT_CELLTYPE_NOT_DEFINED,0,0);

                              /*~-1*/
                              }
                              /*~-1*/
                              }
                              /*~E:C1012*/
                              /*~-1*/
                              }
                              /*~O:I1011*/
                              /*~-2*/
                              else
                              {
                              /*~I:1015*/
                              if (g_SystemControl.byLoadCellType < 3)
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_LOADCELL_TYPE,g_SystemControl.byLoadCellType,1,0);
                              /*~-1*/
                              }
                              /*~O:I1015*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_LOADCELL_TYPE,0,1,0);
                              /*~-1*/
                              }
                              /*~E:I1015*/
                              /*~-1*/
                              }
                              /*~E:I1011*/
                              /*~-1*/
                              }
                              /*~O:I1010*/
                              /*~-2*/
                              else
                              {
                              /*~A:1016*/
                              /*~+:Fehler - Wertebeider Kan�le sind nicht identisch - E011*/
                              /*~T*/
                              // Fehler - Wertebeider Kan�le sind nicht identisch
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E011;
                              /*~E:A1016*/
                              /*~-1*/
                              }
                              /*~E:I1010*/
                           /*~-1*/
                           }
                           /*~O:I1009*/
                           /*~-2*/
                           else
                           {
                              /*~A:1017*/
                              /*~+:Fehler bei der Kommunikation - E005*/
                              /*~T*/
                              // Fehler bei der Kommunikation - E005
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A1017*/
                           /*~-1*/
                           }
                           /*~E:I1009*/
                           /*~O:I1008*/
                           /*~-1*/
#else
                           /*~I:1018*/
#ifdef CHANNEL_1 
                           /*~T*/
                           InstructionDecoder_StoreValue(COMMUNICATION_LOADCELL,(GLOBAL_UNIVALUE_SHORT*)&g_SystemControl.byLoadCellType);
                           /*~-1*/
#endif
                           /*~E:I1018*/
                           /*~-1*/
#endif
                           /*~E:I1008*/
                        /*~-1*/
                        }
                        /*~O:I1007*/
                        /*~-2*/
                        else
                        {
                           /*~A:1019*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1019*/
                        /*~-1*/
                        }
                        /*~E:I1007*/
                     /*~-1*/
                     }
                     /*~E:I1003*/
                     /*~E:A1002*/
                     /*~A:1020*/
                     /*~+:GML - GetMaxLoad*/
                     /*~I:1021*/
                     if (!strcmp(szCommand,"GML"))
                     /*~-1*/
                     {
                        /*~T*/
                        // Text wurde bereits gesendet
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~A:1022*/
                        /*~+:Kanal 0*/
                        /*~I:1023*/
#ifdef CHANNEL_0
                        /*~I:1024*/
                        if (!InstructionDecoder_CheckNbParameters(0,1,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~I:1025*/
                           if (!SYSTEM_MRW_MANAGER)
                           /*~-1*/
                           {
                              /*~T*/
                              Communication_SendString(COMMUNICATION_RS232,T_TEXT_MAX_SYSTEMLOAD,1,0);

                           /*~-1*/
                           }
                           /*~E:I1025*/
                           /*~T*/
                           Communication_SendString(COMMUNICATION_RS232,TEXT_MAX_LOAD,0,0);
                        /*~-1*/
                        }
                        /*~O:I1024*/
                        /*~-2*/
                        else
                        {
                           /*~A:1026*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1026*/
                        /*~-1*/
                        }
                        /*~E:I1024*/
                        /*~-1*/
#endif
                        /*~E:I1023*/
                        /*~E:A1022*/
                     /*~-1*/
                     }
                     /*~E:I1021*/
                     /*~E:A1020*/
                     /*~I:1027*/
#ifdef MIT_EINSTELLBARER_MESSWERTTIEFE
                     /*~A:1028*/
                     /*~+:GNM - GetNumberMeasurements*/
                     /*~I:1029*/
                     if (!strcmp(szCommand,"GNM"))
                     /*~-1*/
                     {
                        /*~A:1030*/
                        /*~+:Variablendeklarationen*/
                        /*~I:1031*/
#ifdef CHANNEL_0
                        /*~T*/
                        long lMeasurementDepthPartner;
                        /*~-1*/
#endif
                        /*~E:I1031*/
                        /*~E:A1030*/
                        /*~A:1032*/
                        /*~+:Variableninitialsierungen*/
                        /*~T*/

                        /*~E:A1032*/
                        /*~T*/
                        // Text wurde bereits gesendet
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:1033*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0);
                           /*~K*/
                           /*~+:*/
                           /*~I:1034*/
                           if (Parameter[0].nLong < 2)
                           /*~-1*/
                           {
                              /*~I:1035*/
                              if (!Parameter[0].nLong)
                              /*~-1*/
                              {
                              /*~T*/
                              ADuC836_ADCGetMeasurementDepth(ADuC836_ADC_PRIMARY,&byTemp);
                              /*~-1*/
                              }
                              /*~O:I1035*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              ADuC836_ADCGetMeasurementDepth(ADuC836_ADC_PRIMARY_TOGGLE,&byTemp);
                              /*~-1*/
                              }
                              /*~E:I1035*/
                              /*~I:1036*/
#ifdef CHANNEL_0
                              /*~I:1037*/
                              if (!Communication_GetSPIValue(COMMUNICATION_NUMBER_OF_MEASUREMENTS,&lMeasurementDepthPartner))
                              /*~-1*/
                              {
                              /*~I:1038*/
                              if ((char)lMeasurementDepthPartner == byTemp)
                              /*~-1*/
                              {
                              /*~I:1039*/
                              if (!Parameter[0].nLong)
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_MEASUREMENT_DEPTH_RMW_CHANNEL_0,byTemp,1,0);
                              /*~-1*/
                              }
                              /*~O:I1039*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_MEASUREMENT_DEPTH_FEEDBACK_CHANNEL_0,byTemp,1,0);
                              /*~-1*/
                              }
                              /*~E:I1039*/
                              /*~-1*/
                              }
                              /*~O:I1038*/
                              /*~-2*/
                              else
                              {
                              /*~A:1040*/
                              /*~+:Fehler - Werte beider Kan�le sind nicht identisch - E011*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E011;
                              /*~E:A1040*/
                              /*~-1*/
                              }
                              /*~E:I1038*/
                              /*~-1*/
                              }
                              /*~O:I1037*/
                              /*~-2*/
                              else
                              {
                              /*~A:1041*/
                              /*~+:Fehler bei der Kommunikation - E005*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A1041*/
                              /*~-1*/
                              }
                              /*~E:I1037*/
                              /*~O:I1036*/
                              /*~-1*/
#else
                              /*~I:1042*/
#ifdef CHANNEL_1
                              /*~T*/
                              InstructionDecoder_StoreValue(COMMUNICATION_NUMBER_OF_MEASUREMENTS,(GLOBAL_UNIVALUE_SHORT*)&byTemp);
                              /*~-1*/
#endif
                              /*~E:I1042*/
                              /*~-1*/
#endif
                              /*~E:I1036*/
                           /*~-1*/
                           }
                           /*~O:I1034*/
                           /*~-2*/
                           else
                           {
                              /*~I:1043*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I1043*/
                           /*~-1*/
                           }
                           /*~E:I1034*/
                        /*~-1*/
                        }
                        /*~O:I1033*/
                        /*~-2*/
                        else
                        {
                           /*~A:1044*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1044*/
                        /*~-1*/
                        }
                        /*~E:I1033*/
                     /*~-1*/
                     }
                     /*~E:I1029*/
                     /*~E:A1028*/
                     /*~-1*/
#endif
                     /*~E:I1027*/
                     /*~I:1045*/
#ifndef OHNE_STROMRUECKFUEHRUNG
                     /*~A:1046*/
                     /*~+:GPP - GetProportionalPortion (of Current Feedback)*/
                     /*~I:1047*/
                     if (!strcmp(szCommand,"GPP"))
                     /*~-1*/
                     {
                        /*~T*/
                        // Text wurde bereits gesendet
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:1048*/
                        if (!InstructionDecoder_CheckNbParameters(0,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           // Da in beiden Kan�len dieser Wert gleich sein muss, gen�gt die Ausgabe des Kanal 0 
                           /*~A:1049*/
                           /*~+:Kanal 0*/
                           /*~I:1050*/
#ifdef CHANNEL_0
                           /*~T*/
                           Communication_SendLong(COMMUNICATION_RS232,TEXT_FEEDBACK_PROPORTIONAL_PORTION,100 - CurrentInterface_GetFeedBackProportionalPortion(),1,0);
                           /*~-1*/
#endif
                           /*~E:I1050*/
                           /*~E:A1049*/
                        /*~-1*/
                        }
                        /*~O:I1048*/
                        /*~-2*/
                        else
                        {
                           /*~A:1051*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1051*/
                        /*~-1*/
                        }
                        /*~E:I1048*/
                     /*~-1*/
                     }
                     /*~E:I1047*/
                     /*~E:A1046*/
                     /*~-1*/
#endif
                     /*~E:I1045*/
                     /*~A:1052*/
                     /*~+:GSU - GetpowerSUpply*/
                     /*~I:1053*/
                     if (!strcmp(szCommand,"GSU"))
                     /*~-1*/
                     {
                        /*~T*/
                        // Text wurde bereits gesendet
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:1054*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0);
                           /*~C:1055*/
                           switch (Parameter[0].nLong)
                           /*~-1*/
                           {
                              /*~F:1056*/
                              case 0:
                              /*~-1*/
                              {
                              /*~A:1057*/
                              /*~+:Kanal 0*/
                              /*~I:1058*/
#ifdef CHANNEL_0
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_POWERSUPPLY_CHANNEL_0,Global.lRMW_PowerSupply,1,0);
                              /*~-1*/
#endif
                              /*~E:I1058*/
                              /*~E:A1057*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1056*/
                              /*~I:1059*/
#ifdef VCC_CHECK_ON_BOTH_CHANELS
                              /*~F:1060*/
                              case 1:
                              /*~-1*/
                              {
                              /*~A:1061*/
                              /*~+:Kanal 1*/
                              /*~I:1062*/
#ifdef CHANNEL_1
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_POWERSUPPLY_CHANNEL_1,Global.lRMW_PowerSupply,1,0);
                              /*~-1*/
#endif
                              /*~E:I1062*/
                              /*~E:A1061*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1060*/
                              /*~-1*/
#endif
                              /*~E:I1059*/
                              /*~O:C1055*/
                              /*~-2*/
                              default:
                              {
                              /*~A:1063*/
                              /*~+:Kanal 0*/
                              /*~I:1064*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I1064*/
                              /*~E:A1063*/
                              /*~-1*/
                              }
                           /*~-1*/
                           }
                           /*~E:C1055*/
                        /*~-1*/
                        }
                        /*~O:I1054*/
                        /*~-2*/
                        else
                        {
                           /*~A:1065*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1065*/
                        /*~-1*/
                        }
                        /*~E:I1054*/
                     /*~-1*/
                     }
                     /*~E:I1053*/
                     /*~E:A1052*/
                     /*~A:1066*/
                     /*~+:GSD - GetStatisticsData*/
                     /*~I:1067*/
                     if (!strcmp(szCommand,"GSD"))
                     /*~-1*/
                     {
                        /*~T*/
                        // Text wurde bereits gesendet
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:1068*/
                        if (!InstructionDecoder_CheckNbParameters(2,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0);
                           Parameter[1].nLong = Communication_GetLongParameter(1);
                           /*~C:1069*/
                           switch (Parameter[0].nLong)
                           /*~-1*/
                           {
                              /*~F:1070*/
                              case 0:
                              case 2:
                              /*~-1*/
                              {
                              /*~I:1071*/
#ifdef CHANNEL_0
                              /*~A:1072*/
                              /*~+:Kanal 0 - Absolutstatistik(0) - Relativstatistik(2)*/
                              /*~I:1073*/
                              if (Parameter[0].nLong == 0)
                              /*~-1*/
                              {
                              /*~A:1074*/
                              /*~+:Absolutstatistik*/
                              /*~K*/
                              /*~+:// Absolutstatistik*/
                              /*~T*/
                              Statistics_PrintData(Parameter[1].nLong);
                              /*~E:A1074*/
                              /*~-1*/
                              }
                              /*~O:I1073*/
                              /*~-2*/
                              else
                              {
                              /*~A:1075*/
                              /*~+:Relativstatistik*/
                              /*~K*/
                              /*~+:// Relativstatistik*/
                              /*~T*/
                              Statistics_PrintData(Parameter[1].nLong | 0x40);
                              /*~E:A1075*/
                              /*~-1*/
                              }
                              /*~E:I1073*/
                              /*~E:A1072*/
                              /*~-1*/
#endif
                              /*~E:I1071*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1070*/
                              /*~F:1076*/
                              case 1:
                              case 3:
                              /*~-1*/
                              {
                              /*~I:1077*/
#ifdef CHANNEL_1
                              /*~A:1078*/
                              /*~+:Kanal 1 - Absolutstatistik(1) - Relativstatistik(3)*/
                              /*~I:1079*/
                              if (Parameter[0].nLong == 1)
                              /*~-1*/
                              {
                              /*~A:1080*/
                              /*~+:Absolutstatistik*/
                              /*~T*/
                              Statistics_PrintData(Parameter[1].nLong);
                              /*~E:A1080*/
                              /*~-1*/
                              }
                              /*~O:I1079*/
                              /*~-2*/
                              else
                              {
                              /*~A:1081*/
                              /*~+:Relativstatistik*/
                              /*~T*/
                              Statistics_PrintData((Parameter[1].nLong | 0x40));
                              /*~E:A1081*/
                              /*~-1*/
                              }
                              /*~E:I1079*/
                              /*~E:A1078*/
                              /*~-1*/
#endif
                              /*~E:I1077*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1076*/
                              /*~O:C1069*/
                              /*~-2*/
                              default:
                              {
                              /*~A:1082*/
                              /*~+:Kanal 0*/
                              /*~I:1083*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I1083*/
                              /*~E:A1082*/
                              /*~-1*/
                              }
                           /*~-1*/
                           }
                           /*~E:C1069*/
                        /*~-1*/
                        }
                        /*~O:I1068*/
                        /*~-2*/
                        else
                        {
                           /*~A:1084*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1084*/
                        /*~-1*/
                        }
                        /*~E:I1068*/
                     /*~-1*/
                     }
                     /*~E:I1067*/
                     /*~E:A1066*/
                     /*~A:1085*/
                     /*~+:GSN - GetSerialNumber*/
                     /*~I:1086*/
                     if (!strcmp(szCommand,"GSN"))
                     /*~-1*/
                     {
                        /*~T*/
                        // Text wurde bereits gesendet
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~A:1087*/
                        /*~+:Kanal 0*/
                        /*~I:1088*/
#ifdef CHANNEL_0
                        /*~I:1089*/
                        if (!InstructionDecoder_CheckNbParameters(0,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~I:1090*/
                           if (!SYSTEM_MRW_MANAGER)
                           /*~-1*/
                           {
                              /*~T*/
                              Communication_SendString(COMMUNICATION_RS232,T_TEXT_SERIAL_NUMBER,1,0);

                           /*~-1*/
                           }
                           /*~E:I1090*/
                           /*~T*/
                           Communication_SendString(COMMUNICATION_RS232,System_GetSerialNumber(),0,0);
                        /*~-1*/
                        }
                        /*~O:I1089*/
                        /*~-2*/
                        else
                        {
                           /*~A:1091*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1091*/
                        /*~-1*/
                        }
                        /*~E:I1089*/
                        /*~-1*/
#endif
                        /*~E:I1088*/
                        /*~E:A1087*/
                     /*~-1*/
                     }
                     /*~E:I1086*/
                     /*~E:A1085*/
                     /*~A:1092*/
                     /*~+:GSP - GetStatisticsParameter*/
                     /*~I:1093*/
                     if (!strcmp(szCommand,"GSP"))
                     /*~-1*/
                     {
                        /*~A:1094*/
                        /*~+:Variablendeklarationen*/
                        /*~T*/
                        STATISTICSLIBRARY_SETUP StatisticsSetup;
                        /*~E:A1094*/
                        /*~A:1095*/
                        /*~+:Variableninitialisierungen*/
                        /*~T*/
                        StatisticsSetup = Statistics_GetSetup();
                        /*~E:A1095*/
                        /*~T*/
                        // Text wurde bereits gesendet
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:1096*/
                        if (!InstructionDecoder_CheckNbParameters(2,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0);
                           Parameter[1].nLong = Communication_GetLongParameter(1);

                           /*~C:1097*/
                           switch (Parameter[0].nLong)
                           /*~-1*/
                           {
                              /*~F:1098*/
                              case 0:	// Parameter der Statistik des Kanal 0 lesen
                              /*~-1*/
                              {
                              /*~A:1099*/
                              /*~+:Kanal 0*/
                              /*~I:1100*/
#ifdef CHANNEL_0
                              /*~C:1101*/
                              switch (Parameter[1].nLong)
                              /*~-1*/
                              {
                              /*~F:1102*/
                              case 0:	// Filter Temperatur�berwachung
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_STATISTICS_FILTER_TEMPERATURE_CHANNEL_0,StatisticsSetup.chFilterCheckTemperature,1,0);
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1102*/
                              /*~F:1103*/
                              case 1:	// Filter Gewichts�berwachung
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_STATISTICS_FILTER_WEIGHT_CHANNEL_0,StatisticsSetup.chFilterCheckWeight,1,0);
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1103*/
                              /*~F:1104*/
                              case 2:	// MotionLimit Gewichts�berwachung
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendFloat(COMMUNICATION_RS232,TEXT_STATISTICS_MOTIONLIMIT_WEIGHT_CHANNEL_0,StatisticsSetup.fMotionLimitCheckWeight,2,1,0);
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1104*/
                              /*~F:1105*/
                              case 3:	// Filter Grenzwert�berschreitung und �berlast
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_STATISTICS_FILTER_OVERLIMIT_CHANNEL_0,StatisticsSetup.chFilterOverLimit,1,0);
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1105*/
                              /*~F:1106*/
                              case 4:	// Grenzwert
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendFloat(COMMUNICATION_RS232,TEXT_STATISTICS_LIMIT_OVERLIMIT_CHANNEL_0,StatisticsSetup.fLimitOverLimit,2,1,0);
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1106*/
                              /*~-1*/
                              }
                              /*~E:C1101*/
                              /*~-1*/
#endif
                              /*~E:I1100*/
                              /*~E:A1099*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1098*/
                              /*~F:1107*/
                              case 1:	// Parameter der Statistik des Kanal 1 lesen
                              /*~-1*/
                              {
                              /*~A:1108*/
                              /*~+:Kanal 1*/
                              /*~I:1109*/
#ifdef CHANNEL_1
                              /*~C:1110*/
                              switch (Parameter[1].nLong)
                              /*~-1*/
                              {
                              /*~F:1111*/
                              case 0:	// Filter Temperatur�berwachung
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_STATISTICS_FILTER_TEMPERATURE_CHANNEL_1,StatisticsSetup.chFilterCheckTemperature,1,0);
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1111*/
                              /*~F:1112*/
                              case 1:	// Filter Gewichts�berwachung
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_STATISTICS_FILTER_WEIGHT_CHANNEL_1,StatisticsSetup.chFilterCheckWeight,1,0);
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1112*/
                              /*~F:1113*/
                              case 2:	// MotionLimit Gewichts�berwachung
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_STATISTICS_FILTER_OVERLIMIT_CHANNEL_1,StatisticsSetup.chFilterOverLimit,1,0);
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1113*/
                              /*~F:1114*/
                              case 3:	// Filter Grenzwert�berschreitung und �berlast
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendFloat(COMMUNICATION_RS232,TEXT_STATISTICS_MOTIONLIMIT_WEIGHT_CHANNEL_1,StatisticsSetup.fMotionLimitCheckWeight,2,1,0);
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1114*/
                              /*~F:1115*/
                              case 4:	// Grenzwert
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendFloat(COMMUNICATION_RS232,TEXT_STATISTICS_LIMIT_OVERLIMIT_CHANNEL_1,StatisticsSetup.fLimitOverLimit,2,1,0);
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1115*/
                              /*~-1*/
                              }
                              /*~E:C1110*/
                              /*~-1*/
#endif
                              /*~E:I1109*/
                              /*~E:A1108*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1107*/
                              /*~O:C1097*/
                              /*~-2*/
                              default:
                              {
                              /*~I:1116*/
#ifdef CHANNEL_0
                              /*~T*/
                              // Fehler
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I1116*/
                              /*~-1*/
                              }
                           /*~-1*/
                           }
                           /*~E:C1097*/
                        /*~-1*/
                        }
                        /*~O:I1096*/
                        /*~-2*/
                        else
                        {
                           /*~A:1117*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1117*/
                        /*~-1*/
                        }
                        /*~E:I1096*/
                     /*~-1*/
                     }
                     /*~E:I1093*/
                     /*~E:A1092*/
                     /*~A:1118*/
                     /*~+:GSS - GetSystemState*/
                     /*~I:1119*/
                     if (!strcmp(szCommand,"GSS"))
                     /*~-1*/
                     {
                        /*~T*/
                        // Text wurde bereits gesendet
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:1120*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0); 
                           /*~C:1121*/
                           switch (Parameter[0].nLong)
                           /*~-1*/
                           {
                              /*~F:1122*/
                              case 0:
                              /*~-1*/
                              {
                              /*~A:1123*/
                              /*~+:Kanal 0*/
                              /*~I:1124*/
#ifdef CHANNEL_0
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_ACTUAL_SYSTEMSTATE_CHANNEL_0,(long)SYSTEMSTATE,1,0);
                              /*~-1*/
#endif
                              /*~E:I1124*/
                              /*~E:A1123*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1122*/
                              /*~F:1125*/
                              case 1:
                              /*~-1*/
                              {
                              /*~A:1126*/
                              /*~+:Kanal 1*/
                              /*~I:1127*/
#ifdef CHANNEL_1
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_ACTUAL_SYSTEMSTATE_CHANNEL_1,(long)SYSTEMSTATE,1,0);
                              /*~-1*/
#endif
                              /*~E:I1127*/
                              /*~E:A1126*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1125*/
                              /*~O:C1121*/
                              /*~-2*/
                              default:
                              {
                              /*~A:1128*/
                              /*~+:Kanal 0*/
                              /*~I:1129*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I1129*/
                              /*~E:A1128*/
                              /*~-1*/
                              }
                           /*~-1*/
                           }
                           /*~E:C1121*/
                        /*~-1*/
                        }
                        /*~O:I1120*/
                        /*~-2*/
                        else
                        {
                           /*~A:1130*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1130*/
                        /*~-1*/
                        }
                        /*~E:I1120*/
                     /*~-1*/
                     }
                     /*~E:I1119*/
                     /*~E:A1118*/
                     /*~A:1131*/
                     /*~+:GTH - GetTimeHysteresis*/
                     /*~I:1132*/
                     if (!strcmp(szCommand,"GTH"))
                     /*~-1*/
                     {
                        /*~A:1133*/
                        /*~+:Variablendeklarationen*/
                        /*~T*/
                        unsigned long ulTimeHysteresis;
                        /*~I:1134*/
#ifdef CHANNEL_0
                        /*~T*/
                        unsigned long ulTimeHysteresisPartner;
                        /*~-1*/
#endif
                        /*~E:I1134*/
                        /*~E:A1133*/
                        /*~T*/
                        // Text wurde bereits gesendet
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:1135*/
                        if (!InstructionDecoder_CheckNbParameters(0,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           ulTimeHysteresis = CurrentInterface_GetTimeHysteresis();
                           /*~I:1136*/
#ifdef CHANNEL_0
                           /*~I:1137*/
                           if (!Communication_GetSPIValue(COMMUNICATION_TIME_HYSTERESIS,&ulTimeHysteresisPartner))
                           /*~-1*/
                           {
                              /*~I:1138*/
                              if (ulTimeHysteresisPartner == ulTimeHysteresis)
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_CURRENT_INTERFACE_TIME_HYSTERESIS,ulTimeHysteresis,1,0);
                              /*~-1*/
                              }
                              /*~O:I1138*/
                              /*~-2*/
                              else
                              {
                              /*~A:1139*/
                              /*~+:Fehler - Werte beider Kan�le sind nicht identisch - E011*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E011;
                              /*~E:A1139*/
                              /*~-1*/
                              }
                              /*~E:I1138*/
                           /*~-1*/
                           }
                           /*~O:I1137*/
                           /*~-2*/
                           else
                           {
                              /*~A:1140*/
                              /*~+:Fehler bei der Kommunikation - E005*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A1140*/
                           /*~-1*/
                           }
                           /*~E:I1137*/
                           /*~O:I1136*/
                           /*~-1*/
#else
                           /*~I:1141*/
#ifdef CHANNEL_1
                           /*~T*/
                           InstructionDecoder_StoreValue(COMMUNICATION_TIME_HYSTERESIS,(GLOBAL_UNIVALUE_SHORT*)&ulTimeHysteresis);
                           /*~-1*/
#endif
                           /*~E:I1141*/
                           /*~-1*/
#endif
                           /*~E:I1136*/
                        /*~-1*/
                        }
                        /*~O:I1135*/
                        /*~-2*/
                        else
                        {
                           /*~A:1142*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1142*/
                        /*~-1*/
                        }
                        /*~E:I1135*/
                     /*~-1*/
                     }
                     /*~E:I1132*/
                     /*~E:A1131*/
                     /*~A:1143*/
                     /*~+:GTM - GetTiMer*/
                     /*~I:1144*/
                     if (!strcmp(szCommand,"GTM"))
                     /*~-1*/
                     {
                        /*~A:1145*/
                        /*~+:Variablendeklarationen*/
                        /*~T*/
                        long lTime;
                        /*~E:A1145*/
                        /*~A:1146*/
                        /*~+:Variableninitialisierungen*/
                        /*~T*/
                        lTime = 0;
                        /*~E:A1146*/
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:1147*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~I:1148*/
#ifdef CHANNEL_0
                           /*~I:1149*/
                           if (Communication_GetLongParameter(0) != 1)
                           /*~-1*/
                           {
                              /*~T*/
                              // Absoluter Betriebsstundenz�hler
                              /*~I:1150*/
                              if (!SYSTEM_MRW_MANAGER)
                              /*~-1*/
                              {
                              /*~A:1151*/
                              /*~+:Docklight-Modus : Zeit als String ausgeben*/
                              /*~T*/
                              Communication_SendString(COMMUNICATION_RS232,T_TEXT_OPERATING_HOURS,1,0);

                              /*~T*/
                              Communication_SendString(COMMUNICATION_RS232,System_GetOperatingHoursAsString(0),0,0);
                              /*~E:A1151*/
                              /*~-1*/
                              }
                              /*~O:I1150*/
                              /*~-2*/
                              else
                              {
                              /*~A:1152*/
                              /*~+:MRW-Manager-Mode : Stunden als Long ausgeben*/
                              /*~I:1153*/
                              if (!Communication_GetLongParameter(0))
                              /*~-1*/
                              {
                              /*~T*/
                              lTime = System_GetOperatingHours(0,0);
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_OPERATING_HOURS,lTime,1,0);

                              /*~-1*/
                              }
                              /*~O:I1153*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              Communication_SendString(COMMUNICATION_RS232,System_GetOperatingHoursAsString(0),0,0);
                              /*~-1*/
                              }
                              /*~E:I1153*/
                              /*~E:A1152*/
                              /*~-1*/
                              }
                              /*~E:I1150*/
                              /*~A:1154*/
                              /*~+:Administratorcode bilden*/
                              /*~T*/
                              // Administratorcode bilden
                              Global.ulAdminCode = System_BuildAdminCode();  
                              /*~E:A1154*/
                           /*~-1*/
                           }
                           /*~O:I1149*/
                           /*~-2*/
                           else
                           {
                              /*~T*/
                              // Relativer Betriebsstundenz�hler
                              /*~I:1155*/
                              if (!SYSTEM_MRW_MANAGER)
                              /*~-1*/
                              {
                              /*~A:1156*/
                              /*~+:Docklight-Modus : Zeit als String ausgeben*/
                              /*~T*/
                              Communication_SendString(COMMUNICATION_RS232,T_TEXT_OPERATING_HOURS_RELATIVE,1,0);
                              /*~T*/
                              Communication_SendString(COMMUNICATION_RS232,System_GetOperatingHoursAsString(1),0,0);
                              /*~E:A1156*/
                              /*~-1*/
                              }
                              /*~O:I1155*/
                              /*~-2*/
                              else
                              {
                              /*~A:1157*/
                              /*~+:MRW-Manager-Mode : Stunden als Long ausgeben*/
                              /*~T*/
                              lTime = System_GetOperatingHours(1,0);
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_OPERATING_HOURS_RELATIVE,lTime,1,0);

                              /*~E:A1157*/
                              /*~-1*/
                              }
                              /*~E:I1155*/
                           /*~-1*/
                           }
                           /*~E:I1149*/
                           /*~-1*/
#endif
                           /*~E:I1148*/
                        /*~-1*/
                        }
                        /*~O:I1147*/
                        /*~-2*/
                        else
                        {
                           /*~A:1158*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1158*/
                        /*~-1*/
                        }
                        /*~E:I1147*/
                     /*~-1*/
                     }
                     /*~E:I1144*/
                     /*~E:A1143*/
                     /*~A:1159*/
                     /*~+:GTO - GetTemperatureOffset*/
                     /*~I:1160*/
                     if (!strcmp(szCommand,"GTO"))
                     /*~-1*/
                     {
                        /*~T*/
                        // Text wurde bereits gesendet
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:1161*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0); 
                           /*~T*/
                           (char)byTemp = Analog_GetTemperatureOffset();
                           /*~C:1162*/
                           switch (Parameter[0].nLong)
                           /*~-1*/
                           {
                              /*~F:1163*/
                              case 0:
                              /*~-1*/
                              {
                              /*~A:1164*/
                              /*~+:Kanal 0*/
                              /*~I:1165*/
#ifdef CHANNEL_0
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_ACTUAL_TEMPERATURE_OFFSET_CHANNEL_0,(char)byTemp,1,0);
                              /*~-1*/
#endif
                              /*~E:I1165*/
                              /*~E:A1164*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1163*/
                              /*~F:1166*/
                              case 1:
                              /*~-1*/
                              {
                              /*~A:1167*/
                              /*~+:Kanal 1*/
                              /*~I:1168*/
#ifdef CHANNEL_1
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_ACTUAL_TEMPERATURE_OFFSET_CHANNEL_1,(char)byTemp,1,0);
                              /*~-1*/
#endif
                              /*~E:I1168*/
                              /*~E:A1167*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1166*/
                              /*~O:C1162*/
                              /*~-2*/
                              default:
                              {
                              /*~A:1169*/
                              /*~+:Kanal 0*/
                              /*~I:1170*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I1170*/
                              /*~E:A1169*/
                              /*~-1*/
                              }
                           /*~-1*/
                           }
                           /*~E:C1162*/
                        /*~-1*/
                        }
                        /*~O:I1161*/
                        /*~-2*/
                        else
                        {
                           /*~A:1171*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1171*/
                        /*~-1*/
                        }
                        /*~E:I1161*/
                     /*~-1*/
                     }
                     /*~E:I1160*/
                     /*~E:A1159*/
                     /*~A:1172*/
                     /*~+:GTR - GetTaRa*/
                     /*~I:1173*/
                     if (!strcmp(szCommand,"GTR"))
                     /*~-1*/
                     {
                        /*~T*/
                        // Text wurde bereits gesendet
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:1174*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0); 
                           /*~C:1175*/
                           switch (Parameter[0].nLong)
                           /*~-1*/
                           {
                              /*~F:1176*/
                              case 0:
                              /*~-1*/
                              {
                              /*~A:1177*/
                              /*~+:Kanal 0*/
                              /*~I:1178*/
#ifdef CHANNEL_0
                              /*~T*/
                              Communication_SendFloat(COMMUNICATION_RS232,TEXT_MEASUREMENT_ACTUAL_TARE_CHANNEL_0,Weight_TareWeight.fFloat,2,1,0);
                              /*~-1*/
#endif
                              /*~E:I1178*/
                              /*~E:A1177*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1176*/
                              /*~F:1179*/
                              case 1:
                              /*~-1*/
                              {
                              /*~A:1180*/
                              /*~+:Kanal 1*/
                              /*~I:1181*/
#ifdef CHANNEL_1
                              /*~T*/
                              Communication_SendFloat(COMMUNICATION_RS232,TEXT_MEASUREMENT_ACTUAL_TARE_CHANNEL_1,Weight_TareWeight.fFloat,2,1,0);
                              /*~-1*/
#endif
                              /*~E:I1181*/
                              /*~E:A1180*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1179*/
                              /*~O:C1175*/
                              /*~-2*/
                              default:
                              {
                              /*~A:1182*/
                              /*~+:Kanal 0*/
                              /*~I:1183*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I1183*/
                              /*~E:A1182*/
                              /*~-1*/
                              }
                           /*~-1*/
                           }
                           /*~E:C1175*/
                        /*~-1*/
                        }
                        /*~O:I1174*/
                        /*~-2*/
                        else
                        {
                           /*~A:1184*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1184*/
                        /*~-1*/
                        }
                        /*~E:I1174*/
                     /*~-1*/
                     }
                     /*~E:I1173*/
                     /*~E:A1172*/
                     /*~A:1185*/
                     /*~+:GVR - GetVeRsion*/
                     /*~I:1186*/
                     if (!strcmp(szCommand,"GVR"))
                     /*~-1*/
                     {
                        /*~T*/
                        // Text wurde bereits gesendet
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~A:1187*/
                        /*~+:Kanal 0*/
                        /*~I:1188*/
#ifdef CHANNEL_0
                        /*~I:1189*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0); 
                           /*~C:1190*/
                           switch (Parameter[0].nLong)
                           /*~-1*/
                           {
                              /*~F:1191*/
                              case 0:
                              /*~-1*/
                              {
                              /*~T*/
                              Version_PrintVersions(0);
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1191*/
                              /*~F:1192*/
                              case 1:
                              /*~-1*/
                              {
                              /*~T*/
                              Version_PrintVersions(1);
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1192*/
                              /*~O:C1190*/
                              /*~-2*/
                              default:
                              {
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
                              }
                           /*~-1*/
                           }
                           /*~E:C1190*/
                        /*~-1*/
                        }
                        /*~O:I1189*/
                        /*~-2*/
                        else
                        {
                           /*~A:1193*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1193*/
                        /*~-1*/
                        }
                        /*~E:I1189*/
                        /*~-1*/
#endif
                        /*~E:I1188*/
                        /*~E:A1187*/
                     /*~-1*/
                     }
                     /*~E:I1186*/
                     /*~E:A1185*/
                     /*~A:1194*/
                     /*~+:GWD - GetWatchDogadress*/
                     /*~I:1195*/
                     if (!strcmp(szCommand,"GWD"))
                     /*~-1*/
                     {
                        /*~T*/
                        // Text wurde bereits gesendet
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:1196*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0); 
                           /*~C:1197*/
                           switch (Parameter[0].nLong)
                           /*~-1*/
                           {
                              /*~F:1198*/
                              case 0:
                              /*~-1*/
                              {
                              /*~A:1199*/
                              /*~+:Kanal 0*/
                              /*~I:1200*/
#ifdef CHANNEL_0
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_WATCHDOG_ADDRESS_CHANNEL_0,ADuC836_WatchdogReadAddress(),1,0);
                              /*~-1*/
#endif
                              /*~E:I1200*/
                              /*~E:A1199*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1198*/
                              /*~F:1201*/
                              case 1:
                              /*~-1*/
                              {
                              /*~A:1202*/
                              /*~+:Kanal 1*/
                              /*~I:1203*/
#ifdef CHANNEL_1
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_WATCHDOG_ADDRESS_CHANNEL_1,ADuC836_WatchdogReadAddress(),1,0);
                              /*~-1*/
#endif
                              /*~E:I1203*/
                              /*~E:A1202*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1201*/
                              /*~O:C1197*/
                              /*~-2*/
                              default:
                              {
                              /*~A:1204*/
                              /*~+:Kanal 0*/
                              /*~I:1205*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I1205*/
                              /*~E:A1204*/
                              /*~-1*/
                              }
                           /*~-1*/
                           }
                           /*~E:C1197*/
                        /*~-1*/
                        }
                        /*~O:I1196*/
                        /*~-2*/
                        else
                        {
                           /*~A:1206*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1206*/
                        /*~-1*/
                        }
                        /*~E:I1196*/
                     /*~-1*/
                     }
                     /*~E:I1195*/
                     /*~E:A1194*/
                     /*~A:1207*/
                     /*~+:GZP - GetZeroPoint*/
                     /*~I:1208*/
                     if (!strcmp(szCommand,"GZP"))
                     /*~-1*/
                     {
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:1209*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0); 
                           /*~T*/
                           Measurement_GetZero(WEIGHT_WEIGHTCHANNEL,&MVTemp);
                           /*~C:1210*/
                           switch (Parameter[0].nLong)
                           /*~-1*/
                           {
                              /*~F:1211*/
                              case 0:
                              /*~-1*/
                              {
                              /*~A:1212*/
                              /*~+:Kanal 0*/
                              /*~I:1213*/
#ifdef CHANNEL_0
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_MEASUREMENT_ACTUAL_OFFSET_CHANNEL_0,MVTemp.nLong,1,0);
                              /*~-1*/
#endif
                              /*~E:I1213*/
                              /*~E:A1212*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1211*/
                              /*~F:1214*/
                              case 1:
                              /*~-1*/
                              {
                              /*~A:1215*/
                              /*~+:Kanal 1*/
                              /*~I:1216*/
#ifdef CHANNEL_1
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_MEASUREMENT_ACTUAL_OFFSET_CHANNEL_1,MVTemp.nLong,1,0);
                              /*~-1*/
#endif
                              /*~E:I1216*/
                              /*~E:A1215*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1214*/
                              /*~O:C1210*/
                              /*~-2*/
                              default:
                              {
                              /*~A:1217*/
                              /*~+:Kanal 0*/
                              /*~I:1218*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I1218*/
                              /*~E:A1217*/
                              /*~-1*/
                              }
                           /*~-1*/
                           }
                           /*~E:C1210*/
                        /*~-1*/
                        }
                        /*~O:I1209*/
                        /*~-2*/
                        else
                        {
                           /*~A:1219*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1219*/
                        /*~-1*/
                        }
                        /*~E:I1209*/
                     /*~-1*/
                     }
                     /*~E:I1208*/
                     /*~E:A1207*/
                     /*~T*/
                     break;
                  /*~-1*/
                  }
                  /*~E:F629*/
                  /*~E:A628*/
                  /*~A:1220*/
                  /*~+:I*/
                  /*~F:1221*/
                  case 'I':
                  /*~-1*/
                  {
                     /*~A:1222*/
                     /*~+:INI - INItialize*/
                     /*~I:1223*/
                     if (!strcmp(szCommand,"INI"))
                     /*~-1*/
                     {
                        /*~K*/
                        /*~+:/~**/
                        /*~+:1. 	Alamstatus l�schen*/
                        /*~+:2. 	1.Parameter = 0: Temperaturkompensation ausschalten*/
                        /*~+:	1.Parameter = 1: Temperaturkompensation einschalten*/
                        /*~+:3.	Statistikspeicher l�schen*/
                        /*~+:4.	2.Parameter = 0: kein Reset*/
                        /*~+:	2.Parameter = 1: Reset*/
                        /*~+:*~/*/
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:1224*/
                        if (!InstructionDecoder_CheckNbParameters(2,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0);
                           Parameter[1].nLong = Communication_GetLongParameter(1); 
                           /*~F:1225*/
                           // neu ab Version V1.006
                           /*~-1*/
                           {
                              /*~T*/
                              // Z�hler zur �berpr�fung der SPI-Kommunikation l�schen
                              Communication_ClearSPIFaultCounter(1);
                           /*~-1*/
                           }
                           /*~E:F1225*/
                           /*~T*/
                           Diagnosis_ClearDiagnosis(DIAGNOSIS_CLEAR_ALL_BY_INITITALISATION);
                           /*~A:1226*/
                           /*~+:1.Parameter:	0: Temperaturkompensation ausschalten*/
                           /*~+:				1: Temperaturkompensation einschalten*/
                           /*~C:1227*/
                           switch (Parameter[0].nLong)
                           /*~-1*/
                           {
                              /*~F:1228*/
                              case 0:		// Temperaturkompensation ausschalten
                              /*~-1*/
                              {
                              /*~T*/
                              MRW_Compensation_SetCompensationOn(0);
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1228*/
                              /*~F:1229*/
                              case 1:		// Temperaturkompensation einschalten
                              /*~-1*/
                              {
                              /*~T*/
                              MRW_Compensation_SetCompensationOn(1);
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1229*/
                              /*~O:C1227*/
                              /*~-2*/
                              default:
                              {
                              /*~A:1230*/
                              /*~+:Ausf�hrungsstatus auf 'E002' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E002;
                              /*~E:A1230*/
                              /*~-1*/
                              }
                           /*~-1*/
                           }
                           /*~E:C1227*/
                           /*~E:A1226*/
                           /*~I:1231*/
                           if (byCommandStatus == INSTRUCTIONDECODER_SEND_NOTHING)
                           /*~-1*/
                           {
                              /*~T*/
                              // Statistikspeicher l�schen - Implementierung sp�ter
                              /*~A:1232*/
                              /*~+:2.Parameter:	0: kein Reset*/
                              /*~+:				1: Reset*/
                              /*~C:1233*/
                              switch (Parameter[1].nLong)
                              /*~-1*/
                              {
                              /*~F:1234*/
                              case 0:		// kein Reset
                              /*~-1*/
                              {
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1234*/
                              /*~F:1235*/
                              case 1:		// Reset
                              /*~-1*/
                              {
                              /*~A:1236*/
                              /*~+:Eintrag im Diagnosespeicher*/
                              /*~T*/
                              Diagnosis_WriteMessage2Flash(DIAGNOSIS_MESSAGE_RESET_BY_INI_COMMAND);
                              /*~E:A1236*/
                              /*~T*/
                              System_SystemErrorSetWatchdog();
                              /*~-1*/
                              }
                              /*~E:F1235*/
                              /*~O:C1233*/
                              /*~-2*/
                              default:
                              {
                              /*~A:1237*/
                              /*~+:Ausf�hrungsstatus auf 'E002' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E002;
                              /*~E:A1237*/
                              /*~-1*/
                              }
                              /*~-1*/
                              }
                              /*~E:C1233*/
                              /*~E:A1232*/
                              /*~I:1238*/
                              if (byCommandStatus == INSTRUCTIONDECODER_SEND_NOTHING)
                              /*~-1*/
                              {
                              /*~I:1239*/
                              if (!GET_RESPONSE)
                              /*~-1*/
                              {
                              /*~A:1240*/
                              /*~+:Ausf�hrungsstatus auf 'OKAY' setzen*/
                              /*~+:*/
                              /*~T*/
                              // Ausf�hrungsstatus auf 'OKAY' setzen
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              /*~E:A1240*/
                              /*~A:1241*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~I:1242*/
#ifdef CHANNEL_0
                              /*~T*/
                              lText2Send = TEXT_INITIALIZATION;
                              /*~-1*/
#endif
                              /*~E:I1242*/
                              /*~E:A1241*/
                              /*~-1*/
                              }
                              /*~O:I1239*/
                              /*~-2*/
                              else
                              {
                              /*~K*/
                              /*~+:Fehler !!!*/
                              /*~A:1243*/
                              /*~+:Ausf�hrungsstatus auf 'E005' setzen*/
                              /*~I:1244*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~-1*/
#endif
                              /*~E:I1244*/
                              /*~E:A1243*/
                              /*~-1*/
                              }
                              /*~E:I1239*/
                              /*~-1*/
                              }
                              /*~O:I1238*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              // Fehler bei der Ausf�hrung eines Resets
                              /*~-1*/
                              }
                              /*~E:I1238*/
                           /*~-1*/
                           }
                           /*~O:I1231*/
                           /*~-2*/
                           else
                           {
                              /*~T*/
                              // Fehler beim einschalten der Temperaturkompensation
                           /*~-1*/
                           }
                           /*~E:I1231*/
                        /*~-1*/
                        }
                        /*~O:I1224*/
                        /*~-2*/
                        else
                        {
                           /*~A:1245*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1245*/
                        /*~-1*/
                        }
                        /*~E:I1224*/
                     /*~-1*/
                     }
                     /*~E:I1223*/
                     /*~E:A1222*/
                     /*~T*/
                     break;
                  /*~-1*/
                  }
                  /*~E:F1221*/
                  /*~E:A1220*/
                  /*~A:1246*/
                  /*~+:L*/
                  /*~F:1247*/
                  case 'L':
                  /*~-1*/
                  {
                     /*~A:1248*/
                     /*~+:LED - LED-testmode*/
                     /*~I:1249*/
                     if (!strcmp(szCommand,"LED"))
                     /*~-1*/
                     {
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:1250*/
#ifdef CHANNEL_0
                        /*~I:1251*/
                        if (!InstructionDecoder_CheckNbParameters(2,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~I:1252*/
                           if (!Communication_GetLongParameter(0))
                           /*~-1*/
                           {
                              /*~T*/
                              // Test-Mode f�r LEDs verlassen
                              Digital_ClearLEDTestMode();
                              /*~A:1253*/
                              /*~+:Textausgabe*/
                              /*~T*/
                              // Textausgabe
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              lText2Send = TEXT_LED_TESTMODE_CLEARED;
                              /*~E:A1253*/
                           /*~-1*/
                           }
                           /*~O:I1252*/
                           /*~-2*/
                           else
                           {
                              /*~T*/
                              Parameter[1].nLong = Communication_GetLongParameter(1);

                              // zun�chst alle LEDs l�schen
                              Digital_SetLEDManually(0xFF,FALSE);
                              // gew�nschte LEDs einschalten
                              Digital_SetLEDManually(Parameter[1].nLong,TRUE); 
                              /*~A:1254*/
                              /*~+:Textausgabe*/
                              /*~T*/
                              // Textausgabe
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              lText2Send = TEXT_LED_TESTMODE_SET;
                              /*~E:A1254*/
                           /*~-1*/
                           }
                           /*~E:I1252*/
                        /*~-1*/
                        }
                        /*~E:I1251*/
                        /*~-1*/
#endif
                        /*~E:I1250*/
                     /*~-1*/
                     }
                     /*~E:I1249*/
                     /*~T*/
                     break;
                     /*~E:A1248*/
                  /*~-1*/
                  }
                  /*~E:F1247*/
                  /*~E:A1246*/
                  /*~A:1255*/
                  /*~+:N*/
                  /*~F:1256*/
                  case 'N':
                  /*~-1*/
                  {
                     /*~A:1257*/
                     /*~+:NOP - NoOperation*/
                     /*~I:1258*/
                     if (!strcmp(szCommand,"NOP"))
                     /*~-1*/
                     {
                        /*~A:1259*/
                        /*~+:Kanal 0*/
                        /*~I:1260*/
#ifdef CHANNEL_0
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                        lText2Send = 0;
                        /*~I:1261*/
                        if (!InstructionDecoder_CheckNbParameters(0,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~I:1262*/
                           if (!SYSTEM_MRW_MANAGER)
                           /*~-1*/
                           {
                              /*~T*/
                              Communication_SendString(COMMUNICATION_RS232,"OK",0,0);
                           /*~-1*/
                           }
                           /*~E:I1262*/
                        /*~-1*/
                        }
                        /*~O:I1261*/
                        /*~-2*/
                        else
                        {
                           /*~A:1263*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1263*/
                        /*~-1*/
                        }
                        /*~E:I1261*/
                        /*~-1*/
#endif
                        /*~E:I1260*/
                        /*~E:A1259*/
                        /*~A:1264*/
                        /*~+:Kanal 1*/
                        /*~I:1265*/
#ifdef CHANNEL_1
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~-1*/
#endif
                        /*~E:I1265*/
                        /*~E:A1264*/
                     /*~-1*/
                     }
                     /*~E:I1258*/
                     /*~E:A1257*/
                     /*~T*/
                     break;
                  /*~-1*/
                  }
                  /*~E:F1256*/
                  /*~E:A1255*/
                  /*~A:1266*/
                  /*~+:R*/
                  /*~F:1267*/
                  case 'R':
                  /*~-1*/
                  {
                     /*~A:1268*/
                     /*~+:RCW - ReadChanelWeight*/
                     /*~I:1269*/
                     if ((!strcmp(szCommand,"RCW"))||(!strcmp(szCommand,"RDW")))
                     /*~-1*/
                     {
                        /*~I:1270*/
                        if (g_chRCWLast)
                        /*~-1*/
                        {
                           /*~T*/
                           g_chRCWLast = 0;
                        /*~-1*/
                        }
                        /*~O:I1270*/
                        /*~-2*/
                        else
                        {
                           /*~T*/
                           g_chRCWLast = 1;
                        /*~-1*/
                        }
                        /*~E:I1270*/
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:1271*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0); 
                           /*~C:1272*/
                           switch (Parameter[0].nLong)
                           /*~-1*/
                           {
                              /*~F:1273*/
                              case 0:
                              /*~-1*/
                              {
                              /*~A:1274*/
                              /*~+:Kanal 0*/
                              /*~I:1275*/
#ifdef CHANNEL_0
                              /*~T*/
                              Communication_SendFloat(COMMUNICATION_RS232,TEXT_MEASUREMENT_ACTUAL_WEIGHT_CHANNEL_0,Weight_NetWeight.fFloat,2,1,0);
                              /*~-1*/
#endif
                              /*~E:I1275*/
                              /*~E:A1274*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1273*/
                              /*~F:1276*/
                              case 1:
                              /*~-1*/
                              {
                              /*~A:1277*/
                              /*~+:Kanal 1*/
                              /*~I:1278*/
#ifdef CHANNEL_1
                              /*~T*/
                              Communication_SendFloat(COMMUNICATION_RS232,TEXT_MEASUREMENT_ACTUAL_WEIGHT_CHANNEL_1,Weight_NetWeight.fFloat,2,1,0);
                              /*~-1*/
#endif
                              /*~E:I1278*/
                              /*~E:A1277*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1276*/
                              /*~O:C1272*/
                              /*~-2*/
                              default:
                              {
                              /*~A:1279*/
                              /*~+:Kanal 0*/
                              /*~I:1280*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I1280*/
                              /*~E:A1279*/
                              /*~-1*/
                              }
                           /*~-1*/
                           }
                           /*~E:C1272*/
                        /*~-1*/
                        }
                        /*~O:I1271*/
                        /*~-2*/
                        else
                        {
                           /*~A:1281*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1281*/
                        /*~-1*/
                        }
                        /*~E:I1271*/
                     /*~-1*/
                     }
                     /*~E:I1269*/
                     /*~E:A1268*/
                     /*~I:1282*/
#ifdef MOF
                     /*~A:1283*/
                     /*~+:RCW - ReadChanelWeight*/
                     /*~I:1284*/
                     if (!strcmp(szCommand,"RCW"))
                     /*~-1*/
                     {
                        /*~I:1285*/
                        if (g_chRCWLast)
                        /*~-1*/
                        {
                           /*~T*/
                           g_chRCWLast = 0;
                        /*~-1*/
                        }
                        /*~O:I1285*/
                        /*~-2*/
                        else
                        {
                           /*~T*/
                           g_chRCWLast = 1;
                        /*~-1*/
                        }
                        /*~E:I1285*/
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:1286*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0); 
                           /*~C:1287*/
                           switch (Parameter[0].nLong)
                           /*~-1*/
                           {
                              /*~F:1288*/
                              case 0:
                              /*~-1*/
                              {
                              /*~A:1289*/
                              /*~+:Kanal 0*/
                              /*~I:1290*/
#ifdef CHANNEL_0
                              /*~T*/
                              Communication_SendFloat(COMMUNICATION_RS232,TEXT_MEASUREMENT_ACTUAL_WEIGHT_CHANNEL_0,Weight_NetWeight.fFloat,2,1,0);
                              /*~-1*/
#endif
                              /*~E:I1290*/
                              /*~E:A1289*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1288*/
                              /*~F:1291*/
                              case 1:
                              /*~-1*/
                              {
                              /*~A:1292*/
                              /*~+:Kanal 1*/
                              /*~I:1293*/
#ifdef CHANNEL_1
                              /*~T*/
                              Communication_SendFloat(COMMUNICATION_RS232,TEXT_MEASUREMENT_ACTUAL_WEIGHT_CHANNEL_1,Weight_NetWeight.fFloat,2,1,0);
                              /*~-1*/
#endif
                              /*~E:I1293*/
                              /*~E:A1292*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1291*/
                              /*~O:C1287*/
                              /*~-2*/
                              default:
                              {
                              /*~A:1294*/
                              /*~+:Kanal 0*/
                              /*~I:1295*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I1295*/
                              /*~E:A1294*/
                              /*~-1*/
                              }
                           /*~-1*/
                           }
                           /*~E:C1287*/
                        /*~-1*/
                        }
                        /*~O:I1286*/
                        /*~-2*/
                        else
                        {
                           /*~A:1296*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1296*/
                        /*~-1*/
                        }
                        /*~E:I1286*/
                     /*~-1*/
                     }
                     /*~E:I1284*/
                     /*~E:A1283*/
                     /*~-1*/
#endif
                     /*~E:I1282*/
                     /*~A:1297*/
                     /*~+:RDM - ReaDMeasurement*/
                     /*~I:1298*/
                     if (!strcmp(szCommand,"RDM"))
                     /*~-1*/
                     {
                        /*~T*/
                        g_chRCWLast = 0;
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:1299*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0); 
                           /*~C:1300*/
                           switch (Parameter[0].nLong)
                           /*~-1*/
                           {
                              /*~F:1301*/
                              case 0:
                              /*~-1*/
                              {
                              /*~A:1302*/
                              /*~+:Kanal 0*/
                              /*~I:1303*/
#ifdef CHANNEL_0
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_ACTUAL_MEASUREMENT_CHANNEL_0,Weight_ZeroCorrectedMeasurement.nLong,1,0);

                              /*~-1*/
#endif
                              /*~E:I1303*/
                              /*~E:A1302*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1301*/
                              /*~F:1304*/
                              case 1:
                              /*~-1*/
                              {
                              /*~A:1305*/
                              /*~+:Kanal 1*/
                              /*~I:1306*/
#ifdef CHANNEL_1
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_ACTUAL_MEASUREMENT_CHANNEL_1,Weight_ZeroCorrectedMeasurement.nLong,1,0);
                              /*~-1*/
#endif
                              /*~E:I1306*/
                              /*~E:A1305*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1304*/
                              /*~O:C1300*/
                              /*~-2*/
                              default:
                              {
                              /*~A:1307*/
                              /*~+:Kanal 0*/
                              /*~I:1308*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I1308*/
                              /*~E:A1307*/
                              /*~-1*/
                              }
                           /*~-1*/
                           }
                           /*~E:C1300*/
                        /*~-1*/
                        }
                        /*~O:I1299*/
                        /*~-2*/
                        else
                        {
                           /*~A:1309*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1309*/
                        /*~-1*/
                        }
                        /*~E:I1299*/
                     /*~-1*/
                     }
                     /*~E:I1298*/
                     /*~E:A1297*/
                     /*~A:1310*/
                     /*~+:RDS - ReaDStatus (nur aus Kompatibilit�tsgr�nden zur MRW-Manager-Software)*/
                     /*~I:1311*/
                     if (!strcmp(szCommand,"RDS"))
                     /*~-1*/
                     {
                        /*~A:1312*/
                        /*~+:Variablendeklarationen*/
                        /*~T*/
                        unsigned char byStatus2Set;
                        /*~E:A1312*/
                        /*~A:1313*/
                        /*~+:Variableninitialisierungen*/
                        /*~T*/
                        byStatus2Set = 0;
                        /*~E:A1313*/
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:1314*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~I:1315*/
                           if (SYSTEM_MRW_MANAGER)
                           /*~-1*/
                           {
                              /*~T*/
                              Parameter[0].nLong = Communication_GetLongParameter(0); 
                              /*~C:1316*/
                              switch (Parameter[0].nLong)
                              /*~-1*/
                              {
                              /*~F:1317*/
                              case 0:
                              /*~-1*/
                              {
                              /*~A:1318*/
                              /*~+:Kanal 0*/
                              /*~I:1319*/
#ifdef CHANNEL_0
                              /*~I:1320*/
#ifdef MIT_TARATEACH_VIA_RS232
                              /*~T*/
                              byStatus2Set |= 0x01;
                              /*~-1*/
#endif
                              /*~E:I1320*/
                              /*~I:1321*/
#ifdef MIT_LIMITTEACH_VIA_RS232
                              /*~T*/
                              byStatus2Set |= 0x02;
                              /*~-1*/
#endif
                              /*~E:I1321*/
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,0,byStatus2Set,0,0);

                              /*~-1*/
#endif
                              /*~E:I1319*/
                              /*~E:A1318*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1317*/
                              /*~F:1322*/
                              case 1:
                              /*~-1*/
                              {
                              /*~A:1323*/
                              /*~+:Kanal 1*/
                              /*~I:1324*/
#ifdef CHANNEL_1
                              /*~I:1325*/
#ifdef MIT_TARATEACH_VIA_RS232
                              /*~T*/
                              byStatus2Set |= 0x01;
                              /*~-1*/
#endif
                              /*~E:I1325*/
                              /*~I:1326*/
#ifdef MIT_LIMITTEACH_VIA_RS232
                              /*~T*/
                              byStatus2Set |= 0x02;
                              /*~-1*/
#endif
                              /*~E:I1326*/
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,0,byStatus2Set,0,0);

                              /*~-1*/
#endif
                              /*~E:I1324*/
                              /*~E:A1323*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1322*/
                              /*~O:C1316*/
                              /*~-2*/
                              default:
                              {
                              /*~A:1327*/
                              /*~+:Kanal 0*/
                              /*~I:1328*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I1328*/
                              /*~E:A1327*/
                              /*~-1*/
                              }
                              /*~-1*/
                              }
                              /*~E:C1316*/
                           /*~-1*/
                           }
                           /*~E:I1315*/
                        /*~-1*/
                        }
                        /*~O:I1314*/
                        /*~-2*/
                        else
                        {
                           /*~A:1329*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1329*/
                        /*~-1*/
                        }
                        /*~E:I1314*/
                     /*~-1*/
                     }
                     /*~E:I1311*/
                     /*~E:A1310*/
                     /*~A:1330*/
                     /*~+:RDW - ReaDWeight*/
                     /*~K*/
                     /*~+:RDW -> RCW*/
                     /*~E:A1330*/
                     /*~A:1331*/
                     /*~+:RDI - ReadDacInput*/
                     /*~I:1332*/
                     if (!strcmp(szCommand,"RDI"))
                     /*~-1*/
                     {
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:1333*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0); 
                           /*~C:1334*/
                           switch (Parameter[0].nLong)
                           /*~-1*/
                           {
                              /*~F:1335*/
                              case 0:
                              /*~-1*/
                              {
                              /*~A:1336*/
                              /*~+:Kanal 0*/
                              /*~I:1337*/
#ifdef CHANNEL_0
                              /*~T*/
                              // Communication_SendLong(COMMUNICATION_RS232,TEXT_CURRENT_INTERFACE_ACTUAL_DAC_INPUT_CHANNEL_0,Weight_ZeroCorrectedMeasurementWithTare.nLong  + g_lWeightOffset4Limitest,1,0);

                              Communication_SendLong(COMMUNICATION_RS232,TEXT_CURRENT_INTERFACE_ACTUAL_DAC_INPUT_CHANNEL_0,ADuC836_DACGetValue2Convert(),1,0);
                              /*~-1*/
#endif
                              /*~E:I1337*/
                              /*~E:A1336*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1335*/
                              /*~F:1338*/
                              case 1:
                              /*~-1*/
                              {
                              /*~A:1339*/
                              /*~+:Kanal 1*/
                              /*~I:1340*/
#ifdef CHANNEL_1
                              /*~T*/
                              // Communication_SendLong(COMMUNICATION_RS232,TEXT_CURRENT_INTERFACE_ACTUAL_DAC_INPUT_CHANNEL_1,Weight_ZeroCorrectedMeasurementWithTare.nLong + g_lWeightOffset4Limitest,1,0);

                              Communication_SendLong(COMMUNICATION_RS232,TEXT_CURRENT_INTERFACE_ACTUAL_DAC_INPUT_CHANNEL_1,ADuC836_DACGetValue2Convert(),1,0);
                              /*~-1*/
#endif
                              /*~E:I1340*/
                              /*~E:A1339*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1338*/
                              /*~O:C1334*/
                              /*~-2*/
                              default:
                              {
                              /*~A:1341*/
                              /*~+:Kanal 0*/
                              /*~I:1342*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I1342*/
                              /*~E:A1341*/
                              /*~-1*/
                              }
                           /*~-1*/
                           }
                           /*~E:C1334*/
                        /*~-1*/
                        }
                        /*~O:I1333*/
                        /*~-2*/
                        else
                        {
                           /*~A:1343*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1343*/
                        /*~-1*/
                        }
                        /*~E:I1333*/
                     /*~-1*/
                     }
                     /*~E:I1332*/
                     /*~E:A1331*/
                     /*~A:1344*/
                     /*~+:RMA - ReadMeasurementfromAdc*/
                     /*~I:1345*/
                     if (!strcmp(szCommand,"RMA"))
                     /*~-1*/
                     {
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:1346*/
                        if (!InstructionDecoder_CheckNbParameters(2,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0);
                           Parameter[1].nLong = Communication_GetLongParameter(1); 
                           /*~C:1347*/
                           switch (Parameter[0].nLong)
                           /*~-1*/
                           {
                              /*~F:1348*/
                              case 0:
                              /*~-1*/
                              {
                              /*~A:1349*/
                              /*~+:Kanal 0*/
                              /*~I:1350*/
#ifdef CHANNEL_0
                              /*~C:1351*/
                              switch (Parameter[1].nLong)
                              /*~-1*/
                              {
                              /*~F:1352*/
                              case 0:
                              case 2:
                              /*~-1*/
                              {
                              /*~I:1353*/
                              if (Parameter[1].nLong == 2)
                              /*~-1*/
                              {
                              /*~T*/
                              // aktuellen Rohmesswert vom ADC speichern
                              Save_Parameter(LOAD_SAVE_WEIGHT_MEASUREMENT_FROM_ADC,&Weight_MeasurementFromADC.nLong,4);
                              /*~-1*/
                              }
                              /*~E:I1353*/
                              /*~T*/
                              // und ausgeben
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_ADC_ACTUAL_MEASUREMENT_CHANNEL_0,Weight_MeasurementFromADC.nLong,0,1);

                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1352*/
                              /*~F:1354*/
                              case 1:
                              /*~-1*/
                              {
                              /*~T*/
                              // gespeicherten Rohmesswert vom ADC auslesen
                              /*~T*/
                              Load_Parameter(LOAD_SAVE_WEIGHT_MEASUREMENT_FROM_ADC,&Weight_MeasurementFromADC.nLong,4);
                              /*~T*/
                              // und ausgeben
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_ADC_STORED_MEASUREMENT_CHANNEL_0,Weight_MeasurementFromADC.nLong,0,1);

                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1354*/
                              /*~F:1355*/
                              case 3:
                              /*~-1*/
                              {
                              /*~T*/
                              // und ausgeben
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_ADC_ACTUAL_FB_MEASUREMENT_CHANNEL_0,g_CurrentInterface.FeedBack.Results.FilteredMeasurementFromADC.nLong,0,1);

                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1355*/
                              /*~O:C1351*/
                              /*~-2*/
                              default:
                              {
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E002;
                              /*~-1*/
                              }
                              /*~-1*/
                              }
                              /*~E:C1351*/
                              /*~-1*/
#endif
                              /*~E:I1350*/
                              /*~E:A1349*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1348*/
                              /*~F:1356*/
                              case 1:
                              /*~-1*/
                              {
                              /*~A:1357*/
                              /*~+:Kanal 1*/
                              /*~I:1358*/
#ifdef CHANNEL_1
                              /*~C:1359*/
                              switch (Parameter[1].nLong)
                              /*~-1*/
                              {
                              /*~F:1360*/
                              case 0:
                              case 2:
                              /*~-1*/
                              {
                              /*~I:1361*/
                              if (Parameter[1].nLong == 2)
                              /*~-1*/
                              {
                              /*~T*/
                              // aktuellen Rohmesswert vom ADC speichern
                              Save_Parameter(LOAD_SAVE_WEIGHT_MEASUREMENT_FROM_ADC,&Weight_MeasurementFromADC.nLong,4);
                              /*~-1*/
                              }
                              /*~E:I1361*/
                              /*~T*/
                              // und ausgeben
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_ADC_ACTUAL_MEASUREMENT_CHANNEL_1,Weight_MeasurementFromADC.nLong,0,1);

                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1360*/
                              /*~F:1362*/
                              case 1:
                              /*~-1*/
                              {
                              /*~T*/
                              // gespeicherten Rohmesswert vom ADC auslesen
                              /*~T*/
                              Load_Parameter(LOAD_SAVE_WEIGHT_MEASUREMENT_FROM_ADC,&Weight_MeasurementFromADC.nLong,4);
                              /*~T*/
                              // und ausgeben
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_ADC_STORED_MEASUREMENT_CHANNEL_1,Weight_MeasurementFromADC.nLong,0,1);

                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1362*/
                              /*~F:1363*/
                              case 3:
                              /*~-1*/
                              {
                              /*~T*/
                              // und ausgeben
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_ADC_ACTUAL_FB_MEASUREMENT_CHANNEL_1,g_CurrentInterface.FeedBack.Results.FilteredMeasurementFromADC.nLong,0,1);

                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1363*/
                              /*~O:C1359*/
                              /*~-2*/
                              default:
                              {
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E002;
                              /*~-1*/
                              }
                              /*~-1*/
                              }
                              /*~E:C1359*/
                              /*~-1*/
#endif
                              /*~E:I1358*/
                              /*~E:A1357*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1356*/
                              /*~O:C1347*/
                              /*~-2*/
                              default:
                              {
                              /*~A:1364*/
                              /*~+:Kanal 0*/
                              /*~I:1365*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I1365*/
                              /*~E:A1364*/
                              /*~-1*/
                              }
                           /*~-1*/
                           }
                           /*~E:C1347*/
                        /*~-1*/
                        }
                        /*~O:I1346*/
                        /*~-2*/
                        else
                        {
                           /*~A:1366*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1366*/
                        /*~-1*/
                        }
                        /*~E:I1346*/
                     /*~-1*/
                     }
                     /*~E:I1345*/
                     /*~E:A1344*/
                     /*~I:1367*/
#ifdef MOF
                     /*~A:1368*/
                     /*~+:RMF - ReadMotionFilter*/
                     /*~I:1369*/
                     if (!strcmp(szCommand,"RMF"))
                     /*~-1*/
                     {
                        /*~A:1370*/
                        /*~+:Variablendeklarationen*/
                        /*~T*/
                        MEASUREMENT_MOTIONPARAMETER MotionParameter;

                        /*~I:1371*/
#ifdef CHANNEL_0
                        /*~T*/
                        long lMotionFilterPartner;
                        /*~-1*/
#endif
                        /*~E:I1371*/
                        /*~E:A1370*/
                        /*~A:1372*/
                        /*~+:Variableninitialisierungen*/
                        /*~T*/

                        /*~E:A1372*/
                        /*~T*/
                        // Text wurde bereits gesendet
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:1373*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           // Parameter auslesen
                           Parameter[0].nLong = Communication_GetLongParameter(0);

                           // Motionparameter auslesen
                           Weight_GetMotionParameter(&MotionParameter);
                           /*~I:1374*/
                           if (Parameter[0].nLong <= 1)
                           /*~-1*/
                           {
                              /*~I:1375*/
#ifdef CHANNEL_0
                              /*~I:1376*/
                              if (!Communication_GetSPIValue(COMMUNICATION_MOTION_FILTER,&lMotionFilterPartner))
                              /*~-1*/
                              {
                              /*~C:1377*/
                              switch (Parameter[0].nLong)
                              /*~-1*/
                              {
                              /*~F:1378*/
                              case 0: // Filter f�r Gewichtsbewegung
                              /*~-1*/
                              {
                              /*~I:1379*/
                              if (lMotionFilterPartner == MotionParameter.byMotionFilter)
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_MEASUREMENT_MOTIONFILTER_CHANNEL_0,MotionParameter.byMotionFilter,1,0);
                              /*~-1*/
                              }
                              /*~O:I1379*/
                              /*~-2*/
                              else
                              {
                              /*~A:1380*/
                              /*~+:Fehler - Werte beider Kan�le sind nicht identisch - E011*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E011;
                              /*~E:A1380*/
                              /*~-1*/
                              }
                              /*~E:I1379*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1378*/
                              /*~F:1381*/
                              case 1: // Filter f�r Gewichtsberuhigung
                              /*~-1*/
                              {
                              /*~I:1382*/
                              if (lMotionFilterPartner == MotionParameter.byNoMotionFilter)
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_MEASUREMENT_NOMOTIONFILTER_CHANNEL_0,MotionParameter.byNoMotionFilter,1,0);
                              /*~-1*/
                              }
                              /*~O:I1382*/
                              /*~-2*/
                              else
                              {
                              /*~A:1383*/
                              /*~+:Fehler - Werte beider Kan�le sind nicht identisch - E011*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E011;
                              /*~E:A1383*/
                              /*~-1*/
                              }
                              /*~E:I1382*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1381*/
                              /*~-1*/
                              }
                              /*~E:C1377*/
                              /*~-1*/
                              }
                              /*~O:I1376*/
                              /*~-2*/
                              else
                              {
                              /*~A:1384*/
                              /*~+:Fehler bei der Kommunikation - E005*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A1384*/
                              /*~-1*/
                              }
                              /*~E:I1376*/
                              /*~O:I1375*/
                              /*~-1*/
#else
                              /*~I:1385*/
#ifdef CHANNEL_1
                              /*~C:1386*/
                              switch (Parameter[0].nLong)
                              /*~-1*/
                              {
                              /*~F:1387*/
                              case 0:
                              /*~-1*/
                              {
                              /*~T*/
                              InstructionDecoder_StoreValue(COMMUNICATION_MOTION_FILTER,(GLOBAL_UNIVALUE_SHORT*)&MotionParameter.byMotionFilter);
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1387*/
                              /*~F:1388*/
                              case 1:
                              /*~-1*/
                              {
                              /*~T*/
                              InstructionDecoder_StoreValue(COMMUNICATION_MOTION_FILTER,(GLOBAL_UNIVALUE_SHORT*)&MotionParameter.byNoMotionFilter);
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1388*/
                              /*~-1*/
                              }
                              /*~E:C1386*/
                              /*~-1*/
#endif
                              /*~E:I1385*/
                              /*~-1*/
#endif
                              /*~E:I1375*/
                           /*~-1*/
                           }
                           /*~O:I1374*/
                           /*~-2*/
                           else
                           {
                              /*~I:1389*/
#ifdef CHANNEL_0
                              /*~A:1390*/
                              /*~+:Parameter liegt au�erhalb der Grenzen - E002*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E002;
                              /*~E:A1390*/
                              /*~-1*/
#endif
                              /*~E:I1389*/
                           /*~-1*/
                           }
                           /*~E:I1374*/
                        /*~-1*/
                        }
                        /*~O:I1373*/
                        /*~-2*/
                        else
                        {
                           /*~A:1391*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1391*/
                        /*~-1*/
                        }
                        /*~E:I1373*/
                     /*~-1*/
                     }
                     /*~E:I1369*/
                     /*~E:A1368*/
                     /*~-1*/
#endif
                     /*~E:I1367*/
                     /*~A:1392*/
                     /*~+:RML - ReadMotionLimit*/
                     /*~I:1393*/
                     if (!strcmp(szCommand,"RML"))
                     /*~-1*/
                     {
                        /*~A:1394*/
                        /*~+:Variablendeklarationen*/
                        /*~T*/
                        MEASUREMENT_MOTIONPARAMETER MotionParameter;

                        /*~I:1395*/
#ifdef CHANNEL_0
                        /*~T*/
                        float fMotionLimitPartner;
                        /*~-1*/
#endif
                        /*~E:I1395*/
                        /*~E:A1394*/
                        /*~A:1396*/
                        /*~+:Variableninitialisierungen*/
                        /*~T*/

                        /*~E:A1396*/
                        /*~T*/
                        // Text wurde bereits gesendet
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:1397*/
                        if (!InstructionDecoder_CheckNbParameters(0,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           // Motionparameter auslesen
                           Weight_GetMotionParameter(&MotionParameter);
                           /*~I:1398*/
#ifdef CHANNEL_0
                           /*~I:1399*/
                           if (!Communication_GetSPIValue(COMMUNICATION_MOTION_LIMIT,&fMotionLimitPartner))
                           /*~-1*/
                           {
                              /*~I:1400*/
                              if (fMotionLimitPartner == MotionParameter.fMotionLimit)
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendFloat(COMMUNICATION_RS232,TEXT_MEASUREMENT_MOTIONLIMIT_CHANNEL_0,MotionParameter.fMotionLimit,2,1,0);
                              /*~-1*/
                              }
                              /*~O:I1400*/
                              /*~-2*/
                              else
                              {
                              /*~A:1401*/
                              /*~+:Fehler - Werte beider Kan�le sind nicht identisch - E011*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E011;
                              /*~E:A1401*/
                              /*~-1*/
                              }
                              /*~E:I1400*/
                           /*~-1*/
                           }
                           /*~O:I1399*/
                           /*~-2*/
                           else
                           {
                              /*~A:1402*/
                              /*~+:Fehler bei der Kommunikation - E005*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A1402*/
                           /*~-1*/
                           }
                           /*~E:I1399*/
                           /*~O:I1398*/
                           /*~-1*/
#else
                           /*~I:1403*/
#ifdef CHANNEL_1
                           /*~T*/
                           InstructionDecoder_StoreValue(COMMUNICATION_MOTION_LIMIT,(GLOBAL_UNIVALUE_SHORT*)&MotionParameter.fMotionLimit);
                           /*~-1*/
#endif
                           /*~E:I1403*/
                           /*~-1*/
#endif
                           /*~E:I1398*/
                        /*~-1*/
                        }
                        /*~O:I1397*/
                        /*~-2*/
                        else
                        {
                           /*~A:1404*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1404*/
                        /*~-1*/
                        }
                        /*~E:I1397*/
                     /*~-1*/
                     }
                     /*~E:I1393*/
                     /*~E:A1392*/
                     /*~A:1405*/
                     /*~+:RMT - ReadMotionTimer*/
                     /*~I:1406*/
                     if (!strcmp(szCommand,"RMT"))
                     /*~-1*/
                     {
                        /*~A:1407*/
                        /*~+:Variablendeklarationen*/
                        /*~T*/
                        MEASUREMENT_MOTIONPARAMETER MotionParameter;

                        /*~I:1408*/
#ifdef CHANNEL_0
                        /*~T*/
                        long lMotionFilterPartner;
                        /*~-1*/
#endif
                        /*~E:I1408*/
                        /*~E:A1407*/
                        /*~A:1409*/
                        /*~+:Variableninitialisierungen*/
                        /*~T*/

                        /*~E:A1409*/
                        /*~T*/
                        // Text wurde bereits gesendet
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:1410*/
                        if (!InstructionDecoder_CheckNbParameters(0,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           // Motionparameter auslesen
                           Weight_GetMotionParameter(&MotionParameter);
                           /*~I:1411*/
#ifdef CHANNEL_0
                           /*~I:1412*/
                           if (!Communication_GetSPIValue(COMMUNICATION_MOTION_FILTER,&lMotionFilterPartner))
                           /*~-1*/
                           {
                              /*~I:1413*/
                              if (lMotionFilterPartner == MotionParameter.byMotionFilter)
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_MEASUREMENT_MOTIONFILTER_CHANNEL_0,MotionParameter.byMotionFilter,1,0);
                              /*~-1*/
                              }
                              /*~O:I1413*/
                              /*~-2*/
                              else
                              {
                              /*~A:1414*/
                              /*~+:Fehler - Werte beider Kan�le sind nicht identisch - E011*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E011;
                              /*~E:A1414*/
                              /*~-1*/
                              }
                              /*~E:I1413*/
                           /*~-1*/
                           }
                           /*~O:I1412*/
                           /*~-2*/
                           else
                           {
                              /*~A:1415*/
                              /*~+:Fehler bei der Kommunikation - E005*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A1415*/
                           /*~-1*/
                           }
                           /*~E:I1412*/
                           /*~O:I1411*/
                           /*~-1*/
#else
                           /*~I:1416*/
#ifdef CHANNEL_1
                           /*~T*/
                           InstructionDecoder_StoreValue(COMMUNICATION_MOTION_FILTER,(GLOBAL_UNIVALUE_SHORT*)&MotionParameter.byMotionFilter);
                           /*~-1*/
#endif
                           /*~E:I1416*/
                           /*~-1*/
#endif
                           /*~E:I1411*/
                        /*~-1*/
                        }
                        /*~O:I1410*/
                        /*~-2*/
                        else
                        {
                           /*~A:1417*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1417*/
                        /*~-1*/
                        }
                        /*~E:I1410*/
                     /*~-1*/
                     }
                     /*~E:I1406*/
                     /*~E:A1405*/
                     /*~I:1418*/
#ifdef MOF
                     /*~A:1419*/
                     /*~+:RSS - ReaDrS232Statistics*/
                     /*~I:1420*/
                     if (!strcmp(szCommand,"RSS"))
                     /*~-1*/
                     {
                        /*~A:1421*/
                        /*~+:Variablendeklarationen*/
                        /*~T*/
                        RS232_STATISTICS_T Statistics;
                        unsigned char szString[32];
                        /*~E:A1421*/
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:1422*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0); 
                           /*~C:1423*/
                           switch (Parameter[0].nLong)
                           /*~-1*/
                           {
                              /*~F:1424*/
                              case 0:
                              /*~-1*/
                              {
                              /*~A:1425*/
                              /*~+:Kanal 0*/
                              /*~I:1426*/
#ifdef CHANNEL_0
                              /*~T*/
                              Statistics = ADuC836_RS232GetStatistics();
                              /*~I:1427*/
                              if (!SYSTEM_MRW_MANAGER)
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_RS232_STATISTICS_FRAMES_RECEIVED_CHANNEL_0,Statistics.ulETXCount,1,0);

                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_RS232_STATISTICS_ERRONEOUS_FRAMES_CHANNEL_0,Statistics.ulSTXCount - Statistics.ulETXCount,1,0);

                              /*~-1*/
                              }
                              /*~O:I1427*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              sprintf(szString,"%ld,%ld", Statistics.ulETXCount, Statistics.ulSTXCount - Statistics.ulETXCount);

                              Communication_SendString(COMMUNICATION_RS232,szString,0,0);
                              /*~-1*/
                              }
                              /*~E:I1427*/
                              /*~-1*/
#endif
                              /*~E:I1426*/
                              /*~E:A1425*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1424*/
                              /*~F:1428*/
                              case 1:
                              /*~-1*/
                              {
                              /*~A:1429*/
                              /*~+:Kanal 1*/
                              /*~I:1430*/
#ifdef CHANNEL_1
                              /*~T*/
                              Statistics = ADuC836_RS232GetStatistics();
                              /*~I:1431*/
                              if (!SYSTEM_MRW_MANAGER)
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_RS232_STATISTICS_FRAMES_RECEIVED_CHANNEL_1,Statistics.ulETXCount,1,0);

                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_RS232_STATISTICS_ERRONEOUS_FRAMES_CHANNEL_1,Statistics.ulSTXCount - Statistics.ulETXCount,1,0);

                              /*~-1*/
                              }
                              /*~O:I1431*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              sprintf(szString,"%ld,%ld", Statistics.ulETXCount, Statistics.ulSTXCount - Statistics.ulETXCount);

                              Communication_SendString(COMMUNICATION_RS232,szString,0,0);
                              /*~-1*/
                              }
                              /*~E:I1431*/
                              /*~-1*/
#endif
                              /*~E:I1430*/
                              /*~E:A1429*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1428*/
                              /*~O:C1423*/
                              /*~-2*/
                              default:
                              {
                              /*~A:1432*/
                              /*~+:Kanal 0*/
                              /*~I:1433*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I1433*/
                              /*~E:A1432*/
                              /*~-1*/
                              }
                           /*~-1*/
                           }
                           /*~E:C1423*/
                        /*~-1*/
                        }
                        /*~O:I1422*/
                        /*~-2*/
                        else
                        {
                           /*~A:1434*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1434*/
                        /*~-1*/
                        }
                        /*~E:I1422*/
                     /*~-1*/
                     }
                     /*~E:I1420*/
                     /*~E:A1419*/
                     /*~-1*/
#endif
                     /*~E:I1418*/
                     /*~A:1435*/
                     /*~+:RST - ReSeT*/
                     /*~I:1436*/
                     if (!strcmp(szCommand,"RST"))
                     /*~-1*/
                     {
                        /*~T*/
                        // Text wurde bereits gesendet
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:1437*/
                        if (!InstructionDecoder_CheckNbParameters(0,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           System_Reset();
                        /*~-1*/
                        }
                        /*~O:I1437*/
                        /*~-2*/
                        else
                        {
                           /*~A:1438*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1438*/
                        /*~-1*/
                        }
                        /*~E:I1437*/
                     /*~-1*/
                     }
                     /*~E:I1436*/
                     /*~E:A1435*/
                     /*~T*/
                     break;
                  /*~-1*/
                  }
                  /*~E:F1267*/
                  /*~E:A1266*/
                  /*~A:1439*/
                  /*~+:S*/
                  /*~F:1440*/
                  case 'S':
                  /*~-1*/
                  {
                     /*~A:1441*/
                     /*~+:SAL - SetAlarmLimit*/
                     /*~I:1442*/
                     if (!strcmp(szCommand,"SAL"))
                     /*~-1*/
                     {
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;

                        /*~I:1443*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           // Parameter auslesen
                           Parameter[0].fFloat = Communication_GetFloatParameter(0);
                           /*~I:1444*/
                           if (!GET_RESPONSE)
                           /*~-1*/
                           {
                              /*~T*/
                              // Alles okay
                              // Alarmgrenzwert setzen
                              /*~I:1445*/
                              if (!Limit_SetAlarmLimitByWeight(0,Parameter[0].fFloat))
                              /*~-1*/
                              {
                              /*~A:1446*/
                              /*~+:Ausf�hrungsstatus auf 'OKAY' setzen*/
                              /*~+:*/
                              /*~T*/
                              // Ausf�hrungsstatus auf 'OKAY' setzen
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              /*~E:A1446*/
                              /*~A:1447*/
                              /*~+:Kanal 0 - Textausgabe*/
                              /*~I:1448*/
#ifdef CHANNEL_0
                              /*~T*/
                              // Textausgabe vornehmen
                              lText2Send = TEXT_LIMIT_TEACHED;
                              /*~-1*/
#endif
                              /*~E:I1448*/
                              /*~E:A1447*/
                              /*~-1*/
                              }
                              /*~O:I1445*/
                              /*~-2*/
                              else
                              {
                              /*~K*/
                              /*~+:Fehler !!!*/
                              /*~A:1449*/
                              /*~+:Ausf�hrungsstatus auf 'E005' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A1449*/
                              /*~-1*/
                              }
                              /*~E:I1445*/
                           /*~-1*/
                           }
                           /*~O:I1444*/
                           /*~-2*/
                           else
                           {
                              /*~K*/
                              /*~+:Fehler !!!*/
                              /*~A:1450*/
                              /*~+:Ausf�hrungsstatus auf 'E005' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A1450*/
                           /*~-1*/
                           }
                           /*~E:I1444*/
                        /*~-1*/
                        }
                        /*~O:I1443*/
                        /*~-2*/
                        else
                        {
                           /*~A:1451*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1451*/
                        /*~-1*/
                        }
                        /*~E:I1443*/
                     /*~-1*/
                     }
                     /*~E:I1442*/
                     /*~E:A1441*/
                     /*~A:1452*/
                     /*~+:SAN - SetAritcleNumber*/
                     /*~I:1453*/
                     if (!strcmp(szCommand,"SAN"))
                     /*~-1*/
                     {
                        /*~A:1454*/
                        /*~+:Variablendeklarationen*/
                        /*~T*/
                        char *szItemNumber;
                        /*~E:A1454*/
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:1455*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           szItemNumber = Communication_GetStringParameter(0);

                           /*~I:1456*/
                           if (!System_SetItemNumber(szItemNumber))
                           /*~-1*/
                           {
                              /*~A:1457*/
                              /*~+:Kanal 0 - Textausgabe*/
                              /*~I:1458*/
#ifdef CHANNEL_0 
                              /*~A:1459*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              lText2Send = TEXT_ITEM_NUMBER_SET;
                              /*~E:A1459*/
                              /*~-1*/
#endif
                              /*~E:I1458*/
                              /*~E:A1457*/
                           /*~-1*/
                           }
                           /*~O:I1456*/
                           /*~-2*/
                           else
                           {
                              /*~K*/
                              /*~+:Fehler !!!*/
                              /*~I:1460*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~-1*/
#endif
                              /*~E:I1460*/
                           /*~-1*/
                           }
                           /*~E:I1456*/
                        /*~-1*/
                        }
                        /*~O:I1455*/
                        /*~-2*/
                        else
                        {
                           /*~A:1461*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1461*/
                        /*~-1*/
                        }
                        /*~E:I1455*/
                     /*~-1*/
                     }
                     /*~E:I1453*/
                     /*~E:A1452*/
                     /*~I:1462*/
                     /* ab Version V1.008 v. 11.08.2015 */
#ifdef MIT_ADC_BURNOUT_TEST
                     /*~A:1463*/
                     /*~+:SBO - SetBurnOut_onoff*/
                     /*~I:1464*/
                     if (!strcmp(szCommand,"SBO"))
                     /*~-1*/
                     {
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;

                        /*~I:1465*/
                        if (!InstructionDecoder_CheckNbParameters(2,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           // Parameter auslesen
                           Parameter[0].nLong = Communication_GetLongParameter(0);
                           Parameter[1].nLong = Communication_GetLongParameter(1);
                           /*~C:1466*/
                           switch (Parameter[0].nLong)
                           /*~-1*/
                           {
                              /*~F:1467*/
                              case 0:
                              /*~-1*/
                              {
                              /*~A:1468*/
                              /*~+:Kanal 0*/
                              /*~I:1469*/
#ifdef CHANNEL_0
                              /*~T*/
                              // Current burnout mode setzen
                              byRetVal = ADuC836_ADCSetBurnOutMode((unsigned char)Parameter[1].nLong);
                              /*~I:1470*/
                              if (byRetVal != (unsigned char)Parameter[1].nLong)
                              /*~-1*/
                              {
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~-1*/
                              }
                              /*~O:I1470*/
                              /*~-2*/
                              else
                              {
                              /*~A:1471*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              /*~I:1472*/
                              if (byRetVal)
                              /*~-1*/
                              {
                              /*~T*/
                              lText2Send = TEXT_ADC_BURNOUTMODE_SET_CHANEL_0;
                              /*~-1*/
                              }
                              /*~O:I1472*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              lText2Send = TEXT_ADC_BURNOUTMODE_CLEARED_CHANEL_0;
                              /*~-1*/
                              }
                              /*~E:I1472*/
                              /*~E:A1471*/
                              /*~-1*/
                              }
                              /*~E:I1470*/
                              /*~-1*/
#endif
                              /*~E:I1469*/
                              /*~E:A1468*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1467*/
                              /*~F:1473*/
                              case 1:
                              /*~-1*/
                              {
                              /*~A:1474*/
                              /*~+:Kanal 1*/
                              /*~I:1475*/
#ifdef CHANNEL_1
                              /*~T*/
                              // Current burnout mode setzen
                              byRetVal = ADuC836_ADCSetBurnOutMode((unsigned char)Parameter[1].nLong);
                              /*~I:1476*/
                              if (byRetVal != (unsigned char)Parameter[1].nLong)
                              /*~-1*/
                              {
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~-1*/
                              }
                              /*~O:I1476*/
                              /*~-2*/
                              else
                              {
                              /*~A:1477*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              /*~I:1478*/
                              if (byRetVal)
                              /*~-1*/
                              {
                              /*~T*/
                              lText2Send = TEXT_ADC_BURNOUTMODE_SET_CHANEL_1;
                              /*~-1*/
                              }
                              /*~O:I1478*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              lText2Send = TEXT_ADC_BURNOUTMODE_CLEARED_CHANEL_1;
                              /*~-1*/
                              }
                              /*~E:I1478*/
                              /*~E:A1477*/
                              /*~-1*/
                              }
                              /*~E:I1476*/
                              /*~-1*/
#endif
                              /*~E:I1475*/
                              /*~E:A1474*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1473*/
                              /*~O:C1466*/
                              /*~-2*/
                              default:
                              {
                              /*~A:1479*/
                              /*~+:Kanal 0*/
                              /*~I:1480*/
#ifdef CHANEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I1480*/
                              /*~E:A1479*/
                              /*~-1*/
                              }
                           /*~-1*/
                           }
                           /*~E:C1466*/
                        /*~-1*/
                        }
                        /*~O:I1465*/
                        /*~-2*/
                        else
                        {
                           /*~A:1481*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1481*/
                        /*~-1*/
                        }
                        /*~E:I1465*/
                     /*~-1*/
                     }
                     /*~E:I1464*/
                     /*~E:A1463*/
                     /*~-1*/
#endif
                     /*~E:I1462*/
                     /*~I:1482*/
#ifdef SYSTEM_CND_VARIABLE_BAUDRATE
                     /*~A:1483*/
                     /*~+:SBR - SetBaudRate*/
                     /*~I:1484*/
                     if (!strcmp(szCommand,"SBR"))
                     /*~-1*/
                     {
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;

                        /*~I:1485*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0);

                           /*~I:1486*/
                           if ((Parameter[0].nLong == 9600)||(Parameter[0].nLong == 19200)||(Parameter[0].nLong == 38400)||(Parameter[0].nLong == 57600))
                           /*~-1*/
                           {
                              /*~I:1487*/
                              if (!GET_RESPONSE)
                              /*~-1*/
                              {
                              /*~T*/
                              // Alles okay
                              /*~K*/
                              /*~+:*/
                              /*~T*/
                              ADuC836_RS232SetBaudrate(Parameter[0].nLong);
                              /*~T*/
                              // Alles okay
                              // und Wert abspeichern
                              Save_Parameter(LOAD_SAVE_RS232_BAUDRATE,&Parameter[0].nLong,0);
                              /*~A:1488*/
                              /*~+:Ausf�hrungsstatus auf 'OKAY' setzen*/
                              /*~+:*/
                              /*~T*/
                              // Ausf�hrungsstatus auf 'OKAY' setzen
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              /*~E:A1488*/
                              /*~A:1489*/
                              /*~+:Kanal 0 - Textausgabe*/
                              /*~I:1490*/
#ifdef CHANNEL_0 
                              /*~A:1491*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              lText2Send = TEXT_RS232_BAUDRATE_SET;
                              /*~E:A1491*/
                              /*~-1*/
#endif
                              /*~E:I1490*/
                              /*~E:A1489*/
                              /*~-1*/
                              }
                              /*~O:I1487*/
                              /*~-2*/
                              else
                              {
                              /*~K*/
                              /*~+:Fehler !!!*/
                              /*~A:1492*/
                              /*~+:Ausf�hrungsstatus auf 'E005' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A1492*/
                              /*~-1*/
                              }
                              /*~E:I1487*/
                           /*~-1*/
                           }
                           /*~O:I1486*/
                           /*~-2*/
                           else
                           {
                              /*~K*/
                              /*~+:Fehler !!!*/
                              /*~A:1493*/
                              /*~+:Ausf�hrungsstatus auf 'E002' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E002;
                              /*~E:A1493*/
                           /*~-1*/
                           }
                           /*~E:I1486*/
                        /*~-1*/
                        }
                        /*~O:I1485*/
                        /*~-2*/
                        else
                        {
                           /*~A:1494*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1494*/
                        /*~-1*/
                        }
                        /*~E:I1485*/
                     /*~-1*/
                     }
                     /*~E:I1484*/
                     /*~E:A1483*/
                     /*~-1*/
#endif
                     /*~E:I1482*/
                     /*~I:1495*/
#ifndef MIT_KANALTEILUNG
                     /*~A:1496*/
                     /*~+:SCA - SetCalibrationfactortoActualweight*/
                     /*~I:1497*/
                     if (!strcmp(szCommand,"SCA"))
                     /*~-1*/
                     {
                        /*~A:1498*/
                        /*~+:Variablendeklarationen*/
                        /*~T*/
                        unsigned long ulRetVal;
                        /*~E:A1498*/
                        /*~A:1499*/
                        /*~+:Variableninitialisierungen*/
                        /*~T*/

                        /*~E:A1499*/
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;

                        /*~I:1500*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           // Parameter auslesen
                           Parameter[0].fFloat = Communication_GetFloatParameter(0);

                           /*~T*/
                           ulRetVal = Weight_SetCalibrationRegardingActualWeight(Parameter[0].fFloat);
                           /*~I:1501*/
                           if (!GET_RESPONSE)
                           /*~-1*/
                           {
                              /*~I:1502*/
                              if (!ulRetVal)
                              /*~-1*/
                              {
                              /*~T*/
                              // Alles okay
                              /*~A:1503*/
                              /*~+:Ausf�hrungsstatus auf 'OKAY' setzen*/
                              /*~+:*/
                              /*~T*/
                              // Ausf�hrungsstatus auf 'OKAY' setzen
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              /*~E:A1503*/
                              /*~A:1504*/
                              /*~+:Eintrag in Diagnosespeicher vornehmen*/
                              /*~T*/
                              ulDiagnosisEntry2Set = DIAGNOSIS_MESSAGE_CALIBRATION;
                              /*~E:A1504*/
                              /*~A:1505*/
                              /*~+:Kanal 0 - Textausgabe*/
                              /*~I:1506*/
#ifdef CHANNEL_0
                              /*~T*/
                              lText2Send = TEXT_MEASUREMENT_CALIBRATION_SET;
                              /*~-1*/
#endif
                              /*~E:I1506*/
                              /*~E:A1505*/
                              /*~-1*/
                              }
                              /*~O:I1502*/
                              /*~-2*/
                              else
                              {
                              /*~K*/
                              /*~+:Fehler !!!*/
                              /*~A:1507*/
                              /*~+:Ausf�hrungsstatus auf 'E005' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A1507*/
                              /*~-1*/
                              }
                              /*~E:I1502*/
                           /*~-1*/
                           }
                           /*~O:I1501*/
                           /*~-2*/
                           else
                           {
                              /*~K*/
                              /*~+:Fehler !!!*/
                              /*~A:1508*/
                              /*~+:Ausf�hrungsstatus auf 'E005' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A1508*/
                           /*~-1*/
                           }
                           /*~E:I1501*/
                        /*~-1*/
                        }
                        /*~O:I1500*/
                        /*~-2*/
                        else
                        {
                           /*~A:1509*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1509*/
                        /*~-1*/
                        }
                        /*~E:I1500*/
                     /*~-1*/
                     }
                     /*~E:I1497*/
                     /*~E:A1496*/
                     /*~O:I1495*/
                     /*~-1*/
#else
                     /*~A:1510*/
                     /*~+:SCA - SetCalibrationfactortoActualweight*/
                     /*~I:1511*/
                     if (!strcmp(szCommand,"SCA"))
                     /*~-1*/
                     {
                        /*~A:1512*/
                        /*~+:Variablendeklarationen*/
                        /*~T*/
                        char byRetVal;
                        /*~E:A1512*/
                        /*~A:1513*/
                        /*~+:Variableninitialisierungen*/
                        /*~T*/

                        /*~E:A1513*/
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:1514*/
                        if (!InstructionDecoder_CheckNbParameters(2,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           // Parameter auslesen
                           Parameter[0].nLong = Communication_GetLongParameter(0);
                           Parameter[1].fFloat = Communication_GetFloatParameter(1);
                           /*~C:1515*/
                           switch (Parameter[0].nLong)
                           /*~-1*/
                           {
                              /*~F:1516*/
                              case 0:
                              /*~-1*/
                              {
                              /*~A:1517*/
                              /*~+:Kanal 0*/
                              /*~I:1518*/
#ifdef CHANNEL_0
                              /*~T*/
                              byRetVal = Weight_SetCalibrationRegardingActualWeight(Parameter[1].fFloat);
                              /*~I:1519*/
                              if (!byRetVal)
                              /*~-1*/
                              {
                              /*~A:1520*/
                              /*~+:Eintrag in Diagnosespeicher vornehmen*/
                              /*~T*/
                              ulDiagnosisEntry2Set = DIAGNOSIS_MESSAGE_CALIBRATION;
                              /*~E:A1520*/
                              /*~A:1521*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              lText2Send = TEXT_MEASUREMENT_GAIN_SET_CHANNEL_0;
                              /*~E:A1521*/
                              /*~-1*/
                              }
                              /*~O:I1519*/
                              /*~-2*/
                              else
                              {
                              /*~K*/
                              /*~+:Fehler*/
                              /*~A:1522*/
                              /*~+:Textausgabe "E005"*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~I:1523*/
                              if (byRetVal == 2)
                              /*~-1*/
                              {
                              /*~T*/
                              lText2Send = TEXT_ERROR_WEIGHT_INSTABILE;
                              /*~-1*/
                              }
                              /*~E:I1523*/
                              /*~E:A1522*/
                              /*~-1*/
                              }
                              /*~E:I1519*/
                              /*~-1*/
#endif
                              /*~E:I1518*/
                              /*~E:A1517*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1516*/
                              /*~F:1524*/
                              case 1:
                              /*~-1*/
                              {
                              /*~A:1525*/
                              /*~+:Kanal 1*/
                              /*~I:1526*/
#ifdef CHANNEL_1
                              /*~T*/
                              byRetVal = Weight_SetCalibrationRegardingActualWeight(Parameter[1].fFloat);
                              /*~I:1527*/
                              if (!byRetVal)
                              /*~-1*/
                              {
                              /*~A:1528*/
                              /*~+:Eintrag in Diagnosespeicher vornehmen*/
                              /*~T*/
                              ulDiagnosisEntry2Set = DIAGNOSIS_MESSAGE_CALIBRATION;
                              /*~E:A1528*/
                              /*~A:1529*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              lText2Send = TEXT_MEASUREMENT_GAIN_SET_CHANNEL_1;
                              /*~E:A1529*/
                              /*~-1*/
                              }
                              /*~O:I1527*/
                              /*~-2*/
                              else
                              {
                              /*~K*/
                              /*~+:Fehler*/
                              /*~A:1530*/
                              /*~+:Textausgabe "E005"*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~I:1531*/
                              if (byRetVal == 2)
                              /*~-1*/
                              {
                              /*~T*/
                              lText2Send = TEXT_ERROR_WEIGHT_INSTABILE;
                              /*~-1*/
                              }
                              /*~E:I1531*/
                              /*~E:A1530*/
                              /*~-1*/
                              }
                              /*~E:I1527*/
                              /*~-1*/
#endif
                              /*~E:I1526*/
                              /*~E:A1525*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1524*/
                              /*~O:C1515*/
                              /*~-2*/
                              default:
                              {
                              /*~I:1532*/
#ifdef CHANNEL_0
                              /*~T*/
                              // Fehler
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I1532*/
                              /*~-1*/
                              }
                           /*~-1*/
                           }
                           /*~E:C1515*/
                        /*~-1*/
                        }
                        /*~O:I1514*/
                        /*~-2*/
                        else
                        {
                           /*~A:1533*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1533*/
                        /*~-1*/
                        }
                        /*~E:I1514*/
                     /*~-1*/
                     }
                     /*~E:I1511*/
                     /*~E:A1510*/
                     /*~-1*/
#endif
                     /*~E:I1495*/
                     /*~A:1534*/
                     /*~+:SCD - SetmaxCurrentDeviation*/
                     /*~I:1535*/
                     if (!strcmp(szCommand,"SCD"))	// SetmaxCurrentDeviation
                     /*~-1*/
                     {
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;

                        /*~I:1536*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].fFloat = Communication_GetFloatParameter(0);

                           /*~I:1537*/
                           if (!GET_RESPONSE)
                           /*~-1*/
                           {
                              /*~T*/
                              g_CurrentInterface.FeedBack.fMaxDeviation = Parameter[0].fFloat;
                              // und speichern
                              CurrentInterface_SaveDACSettings(CURRENTINTERFACE_MAXDEVIATION_FEEDBACK);

                              /*~A:1538*/
                              /*~+:Ausf�hrungsstatus auf 'OKAY' setzen*/
                              /*~+:*/
                              /*~T*/
                              // Ausf�hrungsstatus auf 'OKAY' setzen
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              /*~E:A1538*/
                              /*~A:1539*/
                              /*~+:Kanal 0 - Textausgabe*/
                              /*~I:1540*/
#ifdef CHANNEL_0
                              /*~A:1541*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              lText2Send = TEXT_MAX_CURRENT_DEVIATION_SET;
                              /*~E:A1541*/
                              /*~-1*/
#endif
                              /*~E:I1540*/
                              /*~E:A1539*/
                           /*~-1*/
                           }
                           /*~O:I1537*/
                           /*~-2*/
                           else
                           {
                              /*~K*/
                              /*~+:Fehler !!!*/
                              /*~A:1542*/
                              /*~+:Ausf�hrungsstatus auf 'E005' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A1542*/
                           /*~-1*/
                           }
                           /*~E:I1537*/
                        /*~-1*/
                        }
                        /*~O:I1536*/
                        /*~-2*/
                        else
                        {
                           /*~A:1543*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1543*/
                        /*~-1*/
                        }
                        /*~E:I1536*/
                     /*~-1*/
                     }
                     /*~E:I1535*/
                     /*~E:A1534*/
                     /*~A:1544*/
                     /*~+:SCF - SetCalibrationFactor*/
                     /*~I:1545*/
                     if (!strcmp(szCommand,"SCF"))
                     /*~-1*/
                     {
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;

                        /*~I:1546*/
                        if (!InstructionDecoder_CheckNbParameters(2,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           // Parameter auslesen
                           Parameter[0].nLong = Communication_GetLongParameter(0);
                           Parameter[1].fFloat = Communication_GetFloatParameter(1);
                           /*~C:1547*/
                           switch (Parameter[0].nLong)
                           /*~-1*/
                           {
                              /*~F:1548*/
                              case 0:
                              /*~-1*/
                              {
                              /*~A:1549*/
                              /*~+:Kanal 0*/
                              /*~I:1550*/
#ifdef CHANNEL_0
                              /*~T*/
                              // Kalibrierfaktor setzen
                              byRetVal = Weight_SetCalibrationFactor(Parameter[1].fFloat);
                              /*~I:1551*/
                              if (byRetVal)
                              /*~-1*/
                              {
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~-1*/
                              }
                              /*~O:I1551*/
                              /*~-2*/
                              else
                              {
                              /*~A:1552*/
                              /*~+:Eintrag in Diagnosespeicher vornehmen*/
                              /*~T*/
                              ulDiagnosisEntry2Set = DIAGNOSIS_MESSAGE_CALIBRATION_TO_VALUE;
                              /*~E:A1552*/
                              /*~A:1553*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              lText2Send = TEXT_MEASUREMENT_GAIN_SET_2_FIX_VALUE_CHANNEL_0;
                              /*~E:A1553*/
                              /*~-1*/
                              }
                              /*~E:I1551*/
                              /*~-1*/
#endif
                              /*~E:I1550*/
                              /*~E:A1549*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1548*/
                              /*~F:1554*/
                              case 1:
                              /*~-1*/
                              {
                              /*~A:1555*/
                              /*~+:Kanal 1*/
                              /*~I:1556*/
#ifdef CHANNEL_1
                              /*~T*/
                              // Kalibrierfaktor setzen
                              byRetVal = Weight_SetCalibrationFactor(Parameter[1].fFloat);
                              /*~I:1557*/
                              if (byRetVal)
                              /*~-1*/
                              {
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~-1*/
                              }
                              /*~O:I1557*/
                              /*~-2*/
                              else
                              {
                              /*~A:1558*/
                              /*~+:Eintrag in Diagnosespeicher vornehmen*/
                              /*~T*/
                              ulDiagnosisEntry2Set = DIAGNOSIS_MESSAGE_CALIBRATION_TO_VALUE;
                              /*~E:A1558*/
                              /*~A:1559*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              lText2Send = TEXT_MEASUREMENT_GAIN_SET_2_FIX_VALUE_CHANNEL_1;
                              /*~E:A1559*/
                              /*~-1*/
                              }
                              /*~E:I1557*/
                              /*~-1*/
#endif
                              /*~E:I1556*/
                              /*~E:A1555*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1554*/
                              /*~O:C1547*/
                              /*~-2*/
                              default:
                              {
                              /*~A:1560*/
                              /*~+:Kanal 0*/
                              /*~I:1561*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I1561*/
                              /*~E:A1560*/
                              /*~-1*/
                              }
                           /*~-1*/
                           }
                           /*~E:C1547*/
                        /*~-1*/
                        }
                        /*~O:I1546*/
                        /*~-2*/
                        else
                        {
                           /*~A:1562*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1562*/
                        /*~-1*/
                        }
                        /*~E:I1546*/
                     /*~-1*/
                     }
                     /*~E:I1545*/
                     /*~E:A1544*/
                     /*~A:1563*/
                     /*~+:SCL - SetCheckLimits*/
                     /*~I:1564*/
                     if (!strcmp(szCommand,"SCL"))
                     /*~-1*/
                     {
                        /*~A:1565*/
                        /*~+:Variablendeklarationen*/
                        /*~T*/
                        float fMaxDeviation;
                        float fMaxDrift;
                        /*~E:A1565*/
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;

                        /*~I:1566*/
                        if (!InstructionDecoder_CheckNbParameters(2,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0);
                           Parameter[1].fFloat = Communication_GetFloatParameter(1);

                           /*~I:1567*/
                           if (!GET_RESPONSE)
                           /*~-1*/
                           {
                              /*~T*/
                              // Alles okay
                              /*~C:1568*/
                              switch (Parameter[0].nLong)
                              /*~-1*/
                              {
                              /*~F:1569*/
                              case 0:	// Grenzwert 'Nullpunkt�berpr�fung' setzen
                              /*~-1*/
                              {
                              /*~T*/
                              g_Limit.fLimitZeroPointCheck = Parameter[1].fFloat;
                              // speichern
                              Save_Parameter(LOAD_SAVE_LIMIT_ZEROPOINTCHECK,&g_Limit.fLimitZeroPointCheck,4);
                              /*~A:1570*/
                              /*~+:Ausf�hrungsstatus auf 'OKAY' setzen*/
                              /*~+:*/
                              /*~T*/
                              // Ausf�hrungsstatus auf 'OKAY' setzen
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              /*~E:A1570*/
                              /*~A:1571*/
                              /*~+:Kanal 0 - Textausgabe*/
                              /*~I:1572*/
#ifdef CHANNEL_0 
                              /*~A:1573*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              lText2Send = TEXT_CHECKLIMIT_ZEROPOINTCHECK_SET;
                              /*~E:A1573*/
                              /*~-1*/
#endif
                              /*~E:I1572*/
                              /*~E:A1571*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1569*/
                              /*~F:1574*/
                              case 1:	// Grenzwert 'Temperaturgang' setzen
                              /*~-1*/
                              {
                              /*~T*/
                              MRW_Compensation_GetCheckLimits(&fMaxDeviation,&fMaxDrift);
                              MRW_Compensation_SetCheckLimits(Parameter[1].fFloat,fMaxDrift);
                              /*~A:1575*/
                              /*~+:Ausf�hrungsstatus auf 'OKAY' setzen*/
                              /*~+:*/
                              /*~T*/
                              // Ausf�hrungsstatus auf 'OKAY' setzen
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              /*~E:A1575*/
                              /*~A:1576*/
                              /*~+:Kanal 0 - Textausgabe*/
                              /*~I:1577*/
#ifdef CHANNEL_0 
                              /*~A:1578*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              lText2Send = TEXT_CHECKLIMIT_MAXDEVIATION_SET;
                              /*~E:A1578*/
                              /*~-1*/
#endif
                              /*~E:I1577*/
                              /*~E:A1576*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1574*/
                              /*~F:1579*/
                              case 2:	// Grenzwert 'Drift' setzen
                              /*~-1*/
                              {
                              /*~T*/
                              MRW_Compensation_GetCheckLimits(&fMaxDeviation,&fMaxDrift);
                              MRW_Compensation_SetCheckLimits(fMaxDeviation,Parameter[1].fFloat);
                              /*~A:1580*/
                              /*~+:Ausf�hrungsstatus auf 'OKAY' setzen*/
                              /*~+:*/
                              /*~T*/
                              // Ausf�hrungsstatus auf 'OKAY' setzen
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              /*~E:A1580*/
                              /*~A:1581*/
                              /*~+:Kanal 0 - Textausgabe*/
                              /*~I:1582*/
#ifdef CHANNEL_0 
                              /*~A:1583*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              lText2Send = TEXT_CHECKLIMIT_MAXDRIFT_SET;
                              /*~E:A1583*/
                              /*~-1*/
#endif
                              /*~E:I1582*/
                              /*~E:A1581*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1579*/
                              /*~O:C1568*/
                              /*~-2*/
                              default:
                              {
                              /*~K*/
                              /*~+:Fehler !!!*/
                              /*~A:1584*/
                              /*~+:Ausf�hrungsstatus auf 'E002' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E002;
                              /*~E:A1584*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~-1*/
                              }
                              /*~E:C1568*/
                           /*~-1*/
                           }
                           /*~O:I1567*/
                           /*~-2*/
                           else
                           {
                              /*~K*/
                              /*~+:Fehler !!!*/
                              /*~A:1585*/
                              /*~+:Ausf�hrungsstatus auf 'E005' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A1585*/
                           /*~-1*/
                           }
                           /*~E:I1567*/
                        /*~-1*/
                        }
                        /*~O:I1566*/
                        /*~-2*/
                        else
                        {
                           /*~A:1586*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1586*/
                        /*~-1*/
                        }
                        /*~E:I1566*/
                     /*~-1*/
                     }
                     /*~E:I1564*/
                     /*~E:A1563*/
                     /*~A:1587*/
                     /*~+:SCO - SetCompensationOnoff*/
                     /*~I:1588*/
                     if ((!strcmp(szCommand,"SCO")) || (!strcmp(szCommand,"SCE")))
                     /*~-1*/
                     {
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;

                        /*~I:1589*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~I:1590*/
                           if (!strcmp(szCommand,"SCO"))
                           /*~-1*/
                           {
                              /*~T*/
                              // Parameter auslesen
                              Parameter[0].nLong = Communication_GetLongParameter(0);
                           /*~-1*/
                           }
                           /*~O:I1590*/
                           /*~-2*/
                           else
                           {
                              /*~T*/
                              Parameter[0].nLong = 1;
                           /*~-1*/
                           }
                           /*~E:I1590*/
                           /*~I:1591*/
                           if (!GET_RESPONSE)
                           /*~-1*/
                           {
                              /*~I:1592*/
                              if (Parameter[0].nLong == 0)
                              /*~-1*/
                              {
                              /*~T*/
                              // Temperaturkompensation ausschalten
                              MRW_Compensation_SetCompensationOn(0);

                              /*~A:1593*/
                              /*~+:Eintrag im Diagnosespeicher vornehmen*/
                              /*~T*/
                              ulDiagnosisEntry2Set = DIAGNOSIS_WARNING_TEMPCOMP_OFF;
                              /*~E:A1593*/
                              /*~A:1594*/
                              /*~+:Kanal 0 - Textausgabe*/
                              /*~I:1595*/
#ifdef CHANNEL_0 
                              /*~I:1596*/
                              if (!SYSTEM_MRW_MANAGER)
                              /*~-1*/
                              {
                              /*~A:1597*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              lText2Send = TEXT_COMPENSATION_SWITCHED_OFF;
                              /*~E:A1597*/
                              /*~-1*/
                              }
                              /*~E:I1596*/
                              /*~-1*/
#endif
                              /*~E:I1595*/
                              /*~E:A1594*/
                              /*~-1*/
                              }
                              /*~O:I1592*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              // Temperaturkompensation einschalten
                              MRW_Compensation_SetCompensationOn(1);

                              /*~A:1598*/
                              /*~+:Eintrag im Diagnosespeicher vornehmen*/
                              /*~T*/
                              ulDiagnosisEntry2Set = DIAGNOSIS_WARNING_TEMPCOMP_ON;
                              /*~E:A1598*/
                              /*~A:1599*/
                              /*~+:Kanal 0 - Textausgabe*/
                              /*~I:1600*/
#ifdef CHANNEL_0 
                              /*~A:1601*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              lText2Send = TEXT_COMPENSATION_SWITCHED_ON;
                              /*~E:A1601*/
                              /*~-1*/
#endif
                              /*~E:I1600*/
                              /*~E:A1599*/
                              /*~-1*/
                              }
                              /*~E:I1592*/
                              /*~A:1602*/
                              /*~+:Ausf�hrungsstatus auf 'OKAY' setzen*/
                              /*~+:*/
                              /*~T*/
                              // Ausf�hrungsstatus auf 'OKAY' setzen
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              /*~E:A1602*/
                           /*~-1*/
                           }
                           /*~O:I1591*/
                           /*~-2*/
                           else
                           {
                              /*~K*/
                              /*~+:Fehler !!!*/
                              /*~A:1603*/
                              /*~+:Ausf�hrungsstatus auf 'E005' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A1603*/
                           /*~-1*/
                           }
                           /*~E:I1591*/
                        /*~-1*/
                        }
                        /*~O:I1589*/
                        /*~-2*/
                        else
                        {
                           /*~A:1604*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1604*/
                        /*~-1*/
                        }
                        /*~E:I1589*/
                     /*~-1*/
                     }
                     /*~E:I1588*/
                     /*~E:A1587*/
                     /*~A:1605*/
                     /*~+:SCR - SetConvertingRate*/
                     /*~A:1606*/
                     /*~+:Doxygen-Dokumentation*/
                     /*~T*/
                     /* Doxygen-Dokumentation */
                     /*~T*/
                     /*!
                     \page SUBPAGE_COMMANDS_SCR SCR
                     
                     
                     
                     
                     <table width=95% rules=all bgcolor="#E0E0F0">
                     \TABLE_COMMAND{1.,SCR,<Char><Float>,Wandlungsrate zur Gewichtsermittlung setzen, set the conversionrate of the weight-evaluation}
                     \TABLE_PARAMETER{2.,1,0\,1,Kanal,channel}
                     \TABLE_PARAMETER{2,,Wandlungsrate,conversionrate}
                     \TABLE_RETURN{3.,Text,text,OK / Mitteilung\, dass die Wandlungsrate gesetzt wurde,OK / message that the conversionrate was set}
                     \TABLE_RETURN_ADD{E002,Parameterfehler,parameterfault}
                     \TABLE_RETURN_ADD{E005,Ausf�hrungsfehler,execution-error}
                     \TABLE_RETURN_ADD{E007,Zuwenige Parameter,too less parameters}
                     \TABLE_RETURN_ADD{E008,Zuviele Parameter,too much parameters}
                     \TABLE_INTERFACE{4.,RS232}
                     \TABLE_CLOSE
                     \ref SUBPAGE_COMMANDS  \~german ">>> Befehls�bersicht " \~english ">>> Command-overview" \~ \n
                     
                     @cond FOR_PROGRAMMING_DOCS \ref SUBPAGE_SOFTWARE_CODESEGMENTS_COMMANDS_SCR \~german ">>> Code" \~english ">>> code" \~ @endcond
                     */
                     /*~T*/
                     /*!
                     \page SUBPAGE_COMMANDS_TABLE
                     \TABLE_COMMANDS{SUBPAGE_COMMANDS_SCR,<Char><Float>,Wandlungsrate zur Gewichtsermittlung setzen, set the conversionrate of the weight-evaluation}
                     */
                     /*~E:A1606*/
                     /*~A:1607*/
                     /*~+:Doxygen-Dokumentation - Codeausschnitt (Teil 1)*/
                     /*~T*/
                     /* Doxygen-Dokumentation - Codeausschnitt (Teil 1) */

                     /*~T*/
                     /*!
                     @cond FOR_PROGRAMMING_DOCS
                     \page SUBPAGE_SOFTWARE_CODESEGMENTS_COMMANDS_SCR SCR 
                     \code
                     @endcond
                     */

                     /*~E:A1607*/
                     /*~I:1608*/
                     if (!strcmp(szCommand,"SCR"))
                     /*~-1*/
                     {
                        /*~A:1609*/
                        /*~+:Variablendeklarationen*/
                        /*~T*/

                        /*~E:A1609*/
                        /*~A:1610*/
                        /*~+:Variableninitialisierungen*/
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;


                        /*~E:A1610*/
                        /*~I:1611*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           /* Parameter einlesen */
                           /* Wandlungsrate */
                           Parameter[0].fFloat = Communication_GetFloatParameter(0);
                           /*~I:1612*/
#ifdef MOF
                           /*~T*/
                           /* Parameter einlesen */
                           /* Wandlungsrate */
                           Parameter[0].fFloat = 4*Communication_GetFloatParameter(0);
                           /*~T*/
                           /* Die Wandlungsrate muss mal vier genommen werden, da der ADC im Togglebetrieb l�uft. D.h. es wird nur mit bei jeder zweiten Wandlung der DMS-Messwert ermittelt - bei der anderen Messung der Rohmesswert der Stromr�ckf�hrung. Zudem wird bei jeder Umschaltung ein Reset der ADCs ausgef�hrt, was zur Folge hat, dass der Messwert erst nach zweiten Wandlung zur Verf�gung steht.*/
                           /*~-1*/
#endif
                           /*~E:I1612*/
                           /*~I:1613*/
                           if ((Parameter[0].fFloat <= 105.3)&&(Parameter[0].fFloat >= 5.35))
                           /*~-1*/
                           {
                              /*~T*/
                              /* AD-Wandler initialisieren */
                              byRetVal = ADuC836_ADCSetSincFilter(Parameter[0].fFloat,ADuC836_ADC_FREQUENCY_32KHZ);
                              /*~I:1614*/
                              if (!GET_RESPONSE)
                              /*~-1*/
                              {
                              /*~I:1615*/
                              if (byRetVal == 0)
                              /*~-1*/
                              {
                              /*~T*/
                              // Alles okay
                              /*~A:1616*/
                              /*~+:Ausf�hrungsstatus auf 'OKAY' setzen*/
                              /*~+:*/
                              /*~T*/
                              // Ausf�hrungsstatus auf 'OKAY' setzen
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              /*~E:A1616*/
                              /*~A:1617*/
                              /*~+:Wandlungsrate abspeichern*/
                              /*~T*/
                              /* Wandlungsrate abspeichern */
                              Save_Parameter(LOAD_SAVE_MEASUREMENT_CONVERSIONRATE,&Parameter[0].fFloat,4);
                              /*~E:A1617*/
                              /*~A:1618*/
                              /*~+:Eintrag in Diagnosespeicher vornehmen*/
                              /*~T*/
                              ulDiagnosisEntry2Set = DIAGNOSIS_MESSAGE_WEIGHT_CONVERSIONRATE_CHANGED;
                              /*~E:A1618*/
                              /*~A:1619*/
                              /*~+:Textausgabe*/
                              /*~I:1620*/
#ifdef CHANNEL_0
                              /*~T*/
                              lText2Send = TEXT_MEASUREMENT_CONVERSIONRATE_CHANGED;
                              /*~-1*/
#endif
                              /*~E:I1620*/
                              /*~E:A1619*/
                              /*~-1*/
                              }
                              /*~O:I1615*/
                              /*~-2*/
                              else
                              {
                              /*~A:1621*/
                              /*~+:Ausf�hrungsfehler - E005*/
                              /*~T*/
                              /* Ausf�hrungsfehler - E005 */
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A1621*/
                              /*~-1*/
                              }
                              /*~E:I1615*/
                              /*~-1*/
                              }
                              /*~O:I1614*/
                              /*~-2*/
                              else
                              {
                              /*~K*/
                              /*~+:Fehler !!!*/
                              /*~A:1622*/
                              /*~+:Ausf�hrungsstatus auf 'E005' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A1622*/
                              /*~-1*/
                              }
                              /*~E:I1614*/
                           /*~-1*/
                           }
                           /*~O:I1613*/
                           /*~-2*/
                           else
                           {
                              /*~A:1623*/
                              /*~+:Parameterfehler - E002*/
                              /*~T*/
                              /* Parameterfehler - E002 */
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E002;
                              /*~E:A1623*/
                           /*~-1*/
                           }
                           /*~E:I1613*/
                        /*~-1*/
                        }
                        /*~O:I1611*/
                        /*~-2*/
                        else
                        {
                           /*~A:1624*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1624*/
                        /*~-1*/
                        }
                        /*~E:I1611*/
                     /*~-1*/
                     }
                     /*~E:I1608*/
                     /*~A:1625*/
                     /*~+:Doxygen-Dokumentation - Codeausschnitt (Teil 2)*/
                     /*~T*/
                     /* Doxygen-Dokumentation - Codeausschnitt (Teil 2) */

                     /*~T*/
                     /*!
                     @cond FOR_PROGRAMMING_DOCS
                     \page SUBPAGE_SOFTWARE_CODESEGMENTS_COMMANDS_SCR
                     \endcode 
                     \ref SUBPAGE_SOFTWARE_CODESEGMENTS_COMMANDS  \~german ">>> zur�ck" \~english ">>> back" \~
                     @endcond
                     */

                     /*~E:A1625*/
                     /*~E:A1605*/
                     /*~I:1626*/
#ifdef SPEZIALVERSION_FUER_TESTSYSTEME 
                     /*~A:1627*/
                     /*~+:SCU - SetCUrrent*/
                     /*~I:1628*/
                     if (!strcmp(szCommand,"SCU"))
                     /*~-1*/
                     {
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:1629*/
                        if (!InstructionDecoder_CheckNbParameters(2,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~C:1630*/
                           switch (Communication_GetLongParameter(0))
                           /*~-1*/
                           {
                              /*~F:1631*/
                              case 0:
                              /*~-1*/
                              {
                              /*~I:1632*/
#ifdef CHANNEL_0
                              /*~I:1633*/
                              if ((Communication_GetFloatParameter(1) >=  3)&&(Communication_GetFloatParameter(1) < 21))
                              /*~-1*/
                              {
                              /*~T*/
                              g_Weight_lSimulatedRMW = (long)(Communication_GetFloatParameter(1)* 1000);
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              /*~-1*/
                              }
                              /*~O:I1633*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_NOK;
                              /*~-1*/
                              }
                              /*~E:I1633*/
                              /*~-1*/
#endif
                              /*~E:I1632*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1631*/
                              /*~F:1634*/
                              case 1:
                              /*~-1*/
                              {
                              /*~I:1635*/
#ifdef CHANNEL_1
                              /*~I:1636*/
                              if ((Communication_GetFloatParameter(1) >=  3)&&(Communication_GetFloatParameter(1) < 21))
                              /*~-1*/
                              {
                              /*~T*/
                              g_Weight_lSimulatedRMW = (long)(Communication_GetFloatParameter(1)* 1000);
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK; 
                              /*~-1*/
                              }
                              /*~O:I1636*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_NOK;
                              /*~-1*/
                              }
                              /*~E:I1636*/
                              /*~-1*/
#endif
                              /*~E:I1635*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1634*/
                           /*~-1*/
                           }
                           /*~E:C1630*/
                        /*~-1*/
                        }
                        /*~O:I1629*/
                        /*~-2*/
                        else
                        {
                           /*~A:1637*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1637*/
                        /*~-1*/
                        }
                        /*~E:I1629*/
                     /*~-1*/
                     }
                     /*~E:I1628*/
                     /*~E:A1627*/
                     /*~-1*/
#endif
                     /*~E:I1626*/
                     /*~A:1638*/
                     /*~+:SCV - SetCompensationValues*/
                     /*~I:1639*/
                     if (!strcmp(szCommand,"SCV"))
                     /*~-1*/
                     {
                        /*~A:1640*/
                        /*~+:Variablendeklarationen*/
                        /*~T*/
                        unsigned char byChannel;
                        char chTemperature;
                        int nValue2Set;
                        /*~E:A1640*/
                        /*~A:1641*/
                        /*~+:Variableninitialisierungen*/
                        /*~T*/
                        byChannel = (char)Communication_GetLongParameter(0);
                        chTemperature = (char)Communication_GetLongParameter(1);
                        nValue2Set = (int)Communication_GetLongParameter(2);
                        /*~E:A1641*/
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:1642*/
                        if (!InstructionDecoder_CheckNbParameters(3,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~C:1643*/
                           switch (byChannel)
                           /*~-1*/
                           {
                              /*~F:1644*/
                              case 0:
                              /*~-1*/
                              {
                              /*~A:1645*/
                              /*~+:Kanal 0*/
                              /*~I:1646*/
#ifdef CHANNEL_0
                              /*~I:1647*/
                              if (!Compensation_SetCompensationValues(chTemperature,nValue2Set))
                              /*~-1*/
                              {
                              /*~A:1648*/
                              /*~+:Eintrag in Diagnosespeicher vornehmen*/
                              /*~T*/
                              ulDiagnosisEntry2Set = DIAGNOSIS_WARNING_COMPENSATION_VALUE_SET_MANUALLY;
                              /*~E:A1648*/
                              /*~A:1649*/
                              /*~+:Textausgabe f�r Terminalbetrieb*/
                              /*~T*/
                              lText2Send = TEXT_COMPENSATION_REFPOINT_MANUALLY_SET_CHANNEL_0;
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              /*~E:A1649*/
                              /*~-1*/
                              }
                              /*~O:I1647*/
                              /*~-2*/
                              else
                              {
                              /*~A:1650*/
                              /*~+:Fehler - E002 senden*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E002;
                              /*~E:A1650*/
                              /*~-1*/
                              }
                              /*~E:I1647*/
                              /*~-1*/
#endif
                              /*~E:I1646*/
                              /*~E:A1645*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1644*/
                              /*~F:1651*/
                              case 1:
                              /*~-1*/
                              {
                              /*~A:1652*/
                              /*~+:Kanal 1*/
                              /*~I:1653*/
#ifdef CHANNEL_1
                              /*~I:1654*/
                              if (!Compensation_SetCompensationValues(chTemperature,nValue2Set))
                              /*~-1*/
                              {
                              /*~A:1655*/
                              /*~+:Eintrag in Diagnosespeicher vornehmen*/
                              /*~T*/
                              ulDiagnosisEntry2Set = DIAGNOSIS_WARNING_COMPENSATION_VALUE_SET_MANUALLY;
                              /*~E:A1655*/
                              /*~A:1656*/
                              /*~+:Textausgabe f�r Terminalbetrieb*/
                              /*~T*/
                              lText2Send = TEXT_COMPENSATION_REFPOINT_MANUALLY_SET_CHANNEL_1;
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              /*~E:A1656*/
                              /*~-1*/
                              }
                              /*~O:I1654*/
                              /*~-2*/
                              else
                              {
                              /*~A:1657*/
                              /*~+:Fehler - E002 senden*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E002;
                              /*~E:A1657*/
                              /*~-1*/
                              }
                              /*~E:I1654*/
                              /*~-1*/
#endif
                              /*~E:I1653*/
                              /*~E:A1652*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1651*/
                              /*~O:C1643*/
                              /*~-2*/
                              default:
                              {
                              /*~A:1658*/
                              /*~+:Fehler - E001 senden*/
                              /*~I:1659*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I1659*/
                              /*~E:A1658*/
                              /*~-1*/
                              }
                           /*~-1*/
                           }
                           /*~E:C1643*/
                        /*~-1*/
                        }
                        /*~O:I1642*/
                        /*~-2*/
                        else
                        {
                           /*~A:1660*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1660*/
                        /*~-1*/
                        }
                        /*~E:I1642*/
                     /*~-1*/
                     }
                     /*~E:I1639*/
                     /*~E:A1638*/
                     /*~A:1661*/
                     /*~+:SEC - SetEmodulCompensation_onoff*/
                     /*~I:1662*/
                     if (!strcmp(szCommand,"SEC"))
                     /*~-1*/
                     {
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;

                        /*~I:1663*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           // Parameter auslesen
                           Parameter[0].nLong = Communication_GetLongParameter(0);
                           /*~I:1664*/
                           if (!GET_RESPONSE)
                           /*~-1*/
                           {
                              /*~I:1665*/
                              if (Parameter[0].nLong == 0)
                              /*~-1*/
                              {
                              /*~T*/
                              // E-Modul-Kompensation ausschalten
                              Weight_SetEModulCompensationOn(0);


                              /*~A:1666*/
                              /*~+:Eintrag im Diagnosespeicher vornehmen*/
                              /*~T*/
                              ulDiagnosisEntry2Set = DIAGNOSIS_WARNING_EMODULCOMP_OFF;
                              /*~E:A1666*/
                              /*~A:1667*/
                              /*~+:Kanal 0 - Textausgabe*/
                              /*~I:1668*/
#ifdef CHANNEL_0 
                              /*~A:1669*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              lText2Send = TEXT_E_MODUL_COMPENSATION_SWITCHED_OFF;
                              /*~E:A1669*/
                              /*~-1*/
#endif
                              /*~E:I1668*/
                              /*~E:A1667*/
                              /*~-1*/
                              }
                              /*~O:I1665*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              // E-Modul-Kompensation einschalten
                              Weight_SetEModulCompensationOn(1);


                              /*~A:1670*/
                              /*~+:Eintrag im Diagnosespeicher vornehmen*/
                              /*~T*/
                              ulDiagnosisEntry2Set = DIAGNOSIS_WARNING_EMODULCOMP_ON;
                              /*~E:A1670*/
                              /*~A:1671*/
                              /*~+:Kanal 0 - Textausgabe*/
                              /*~I:1672*/
#ifdef CHANNEL_0 
                              /*~A:1673*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              lText2Send = TEXT_E_MODUL_COMPENSATION_SWITCHED_ON;
                              /*~E:A1673*/
                              /*~-1*/
#endif
                              /*~E:I1672*/
                              /*~E:A1671*/
                              /*~-1*/
                              }
                              /*~E:I1665*/
                              /*~A:1674*/
                              /*~+:Ausf�hrungsstatus auf 'OKAY' setzen*/
                              /*~+:*/
                              /*~T*/
                              // Ausf�hrungsstatus auf 'OKAY' setzen
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              /*~E:A1674*/
                           /*~-1*/
                           }
                           /*~O:I1664*/
                           /*~-2*/
                           else
                           {
                              /*~K*/
                              /*~+:Fehler !!!*/
                              /*~A:1675*/
                              /*~+:Ausf�hrungsstatus auf 'E005' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A1675*/
                           /*~-1*/
                           }
                           /*~E:I1664*/
                        /*~-1*/
                        }
                        /*~O:I1663*/
                        /*~-2*/
                        else
                        {
                           /*~A:1676*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1676*/
                        /*~-1*/
                        }
                        /*~E:I1663*/
                     /*~-1*/
                     }
                     /*~E:I1662*/
                     /*~E:A1661*/
                     /*~A:1677*/
                     /*~+:SFD - SetFilterDepth*/
                     /*~I:1678*/
                     if (!strcmp(szCommand,"SFD"))
                     /*~-1*/
                     {
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;

                        /*~I:1679*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0);

                           /*~I:1680*/
                           if (!GET_RESPONSE)
                           /*~-1*/
                           {
                              /*~T*/
                              // Alles okay
                              /*~T*/
                              byTemp = Parameter[0].nLong;
                              /*~C:1681*/
                              switch (AverageFilter_SetFilterDepth(WEIGHT_WEIGHTCHANNEL,byTemp))
                              /*~-1*/
                              {
                              /*~F:1682*/
                              case 0:
                              /*~-1*/
                              {
                              /*~T*/
                              // Alles okay
                              // und Wert abspeichern
                              Save_Parameter(LOAD_SAVE_FILTER_DEPTH_WEIGHT,&byTemp,0);
                              /*~A:1683*/
                              /*~+:Ausf�hrungsstatus auf 'OKAY' setzen*/
                              /*~+:*/
                              /*~T*/
                              // Ausf�hrungsstatus auf 'OKAY' setzen
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              /*~E:A1683*/
                              /*~A:1684*/
                              /*~+:Kanal 0 - Textausgabe*/
                              /*~I:1685*/
#ifdef CHANNEL_0 
                              /*~A:1686*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              lText2Send = TEXT_AVERAGE_FILTER_FILTERDEPTH_SET;
                              /*~E:A1686*/
                              /*~-1*/
#endif
                              /*~E:I1685*/
                              /*~E:A1684*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1682*/
                              /*~F:1687*/
                              case 5:
                              /*~-1*/
                              {
                              /*~T*/
                              // Parameter au�erhalb der Grenzwerte
                              /*~T*/
                              // den gesetzen Wert abfragen
                              byTemp = AverageFilter_GetFilterDepth(WEIGHT_WEIGHTCHANNEL);
                              // und abspeichern
                              Save_Parameter(LOAD_SAVE_FILTER_DEPTH_WEIGHT,&byTemp,0);
                              /*~A:1688*/
                              /*~+:Ausf�hrungsstatus auf 'E002' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E002;
                              /*~E:A1688*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1687*/
                              /*~O:C1681*/
                              /*~-2*/
                              default:
                              {
                              /*~K*/
                              /*~+:Fehler !!!*/
                              /*~A:1689*/
                              /*~+:Ausf�hrungsstatus auf 'E005' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A1689*/
                              /*~-1*/
                              }
                              /*~-1*/
                              }
                              /*~E:C1681*/
                           /*~-1*/
                           }
                           /*~O:I1680*/
                           /*~-2*/
                           else
                           {
                              /*~K*/
                              /*~+:Fehler !!!*/
                              /*~A:1690*/
                              /*~+:Ausf�hrungsstatus auf 'E005' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A1690*/
                           /*~-1*/
                           }
                           /*~E:I1680*/
                        /*~-1*/
                        }
                        /*~O:I1679*/
                        /*~-2*/
                        else
                        {
                           /*~A:1691*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1691*/
                        /*~-1*/
                        }
                        /*~E:I1679*/
                     /*~-1*/
                     }
                     /*~E:I1678*/
                     /*~E:A1677*/
                     /*~A:1692*/
                     /*~+:SFE - SetFeedbackError*/
                     /*~I:1693*/
#ifdef MIT_STROM_ABWEICHUNGSSIMULATION
                     /*~I:1694*/
                     if (!strcmp(szCommand,"SFE"))	// SetFeedbackError
                     /*~-1*/
                     {
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;

                        /*~I:1695*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].fFloat = Communication_GetFloatParameter(0);

                           /*~I:1696*/
                           if (!GET_RESPONSE)
                           /*~-1*/
                           {
                              /*~T*/
                              g_CurrentInterface.FeedBack.fSimulatedDerivation = Parameter[0].fFloat;
                              /*~A:1697*/
                              /*~+:Ausf�hrungsstatus auf 'OKAY' setzen*/
                              /*~+:*/
                              /*~T*/
                              // Ausf�hrungsstatus auf 'OKAY' setzen
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              /*~E:A1697*/
                              /*~A:1698*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~I:1699*/
#ifdef CHANNEL_0
                              /*~T*/
                              lText2Send = TEXT_CURRENT_DEVIATION_SET;
                              /*~-1*/
#endif
                              /*~E:I1699*/
                              /*~E:A1698*/
                           /*~-1*/
                           }
                           /*~O:I1696*/
                           /*~-2*/
                           else
                           {
                              /*~K*/
                              /*~+:Fehler !!!*/
                              /*~A:1700*/
                              /*~+:Ausf�hrungsstatus auf 'E005' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A1700*/
                           /*~-1*/
                           }
                           /*~E:I1696*/
                        /*~-1*/
                        }
                        /*~O:I1695*/
                        /*~-2*/
                        else
                        {
                           /*~A:1701*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1701*/
                        /*~-1*/
                        }
                        /*~E:I1695*/
                     /*~-1*/
                     }
                     /*~E:I1694*/
                     /*~-1*/
#endif
                     /*~E:I1693*/
                     /*~E:A1692*/
                     /*~I:1702*/
#ifdef SYSTEM_CND_WITH_DEADBAND_FILTER
                     /*~A:1703*/
                     /*~+:SFW - SetFilterWidth*/
                     /*~I:1704*/
                     if (!strcmp(szCommand,"SFW"))
                     /*~-1*/
                     {
                        /*~A:1705*/
                        /*~+:Variablendeklarationen*/
                        /*~T*/
                        int nFilterBandWidth;
                        /*~E:A1705*/
                        /*~A:1706*/
                        /*~+:Variableninitialisierungen*/
                        /*~T*/

                        /*~E:A1706*/
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:1707*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           nFilterBandWidth = Communication_GetLongParameter(0);
                           /*~I:1708*/
                           if (!GET_RESPONSE)
                           /*~-1*/
                           {
                              /*~T*/
                              // Alles okay
                              /*~T*/
                              // Totbandfilter-Bandbreite setzen
                              DeadBandFilter_SetBandWidth(WEIGHT_WEIGHTCHANNEL,(float)nFilterBandWidth);

                              // und Wert abspeichern
                              Save_Parameter(LOAD_SAVE_FILTER_BANDWIDTH_WEIGHT,&nFilterBandWidth,0);
                              /*~A:1709*/
                              /*~+:Ausf�hrungsstatus auf 'OKAY' setzen*/
                              /*~+:*/
                              /*~T*/
                              // Ausf�hrungsstatus auf 'OKAY' setzen
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              /*~E:A1709*/
                              /*~A:1710*/
                              /*~+:Kanal 0 - Textausgabe*/
                              /*~I:1711*/
#ifdef CHANNEL_0
                              /*~A:1712*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              lText2Send = TEXT_DEADBAND_FILTER_FILTERWIDTH_SET;
                              /*~E:A1712*/
                              /*~-1*/
#endif
                              /*~E:I1711*/
                              /*~E:A1710*/
                           /*~-1*/
                           }
                           /*~O:I1708*/
                           /*~-2*/
                           else
                           {
                              /*~K*/
                              /*~+:Fehler !!!*/
                              /*~A:1713*/
                              /*~+:Ausf�hrungsstatus auf 'E005' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A1713*/
                           /*~-1*/
                           }
                           /*~E:I1708*/
                        /*~-1*/
                        }
                        /*~O:I1707*/
                        /*~-2*/
                        else
                        {
                           /*~A:1714*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1714*/
                        /*~-1*/
                        }
                        /*~E:I1707*/
                     /*~-1*/
                     }
                     /*~E:I1704*/
                     /*~E:A1703*/
                     /*~O:I1702*/
                     /*~-1*/
#else
                     /*~A:1715*/
                     /*~+:SFW - SetFilterWidth (Dummy)*/
                     /*~I:1716*/
                     if (!strcmp(szCommand,"SFW"))
                     /*~-1*/
                     {
                        /*~A:1717*/
                        /*~+:Variablendeklarationen*/
                        /*~T*/

                        /*~E:A1717*/
                        /*~A:1718*/
                        /*~+:Variableninitialisierungen*/
                        /*~T*/

                        /*~E:A1718*/
                        /*~A:1719*/
                        /*~+:Ausf�hrungsstatus auf 'OKAY' setzen*/
                        /*~+:*/
                        /*~T*/
                        // Ausf�hrungsstatus auf 'OKAY' setzen
                        byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                        /*~E:A1719*/
                        /*~A:1720*/
                        /*~+:Kanal 0 - Textausgabe*/
                        /*~I:1721*/
#ifdef CHANNEL_0
                        /*~A:1722*/
                        /*~+:Text f�r Terminalbetrieb*/
                        /*~T*/
                        lText2Send = TEXT_DEADBAND_FILTER_FILTERWIDTH_SET;
                        /*~E:A1722*/
                        /*~-1*/
#endif
                        /*~E:I1721*/
                        /*~E:A1720*/
                     /*~-1*/
                     }
                     /*~E:I1716*/
                     /*~E:A1715*/
                     /*~-1*/
#endif
                     /*~E:I1702*/
                     /*~A:1723*/
                     /*~+:SID - SetsystemID*/
                     /*~I:1724*/
                     if (!strcmp(szCommand,"SID"))
                     /*~-1*/
                     {
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:1725*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~I:1726*/
#ifdef CHANNEL_0
                           /*~I:1727*/
                           if (!Global.ulSystemID)
                           /*~-1*/
                           {
                              /*~T*/
                              Global.ulSystemID = Communication_GetLongParameter(0);

                              Save_Parameter(LOAD_SAVE_SYSTEM_ID,&Global.ulSystemID,4);
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              lText2Send = TEXT_ID_SET; 
                           /*~-1*/
                           }
                           /*~O:I1727*/
                           /*~-2*/
                           else
                           {
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;

                              lText2Send = TEXT_SYSTEM_ID_ALREADY_SET;
                           /*~-1*/
                           }
                           /*~E:I1727*/
                           /*~-1*/
#endif
                           /*~E:I1726*/
                        /*~-1*/
                        }
                        /*~O:I1725*/
                        /*~-2*/
                        else
                        {
                           /*~A:1728*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1728*/
                        /*~-1*/
                        }
                        /*~E:I1725*/
                     /*~-1*/
                     }
                     /*~E:I1724*/
                     /*~E:A1723*/
                     /*~I:1729*/
#ifdef MIT_GEWICHTSSIMULATION 
                     /*~A:1730*/
                     /*~+:SIW - SImulateWeight*/
                     /*~I:1731*/
                     if (!strcmp(szCommand,"SIW"))
                     /*~-1*/
                     {
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:1732*/
                        if (!InstructionDecoder_CheckNbParameters(2,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~C:1733*/
                           switch (Communication_GetLongParameter(0))
                           /*~-1*/
                           {
                              /*~F:1734*/
                              case 0:
                              /*~-1*/
                              {
                              /*~I:1735*/
#ifdef CHANNEL_0
                              /*~I:1736*/
                              if (Communication_GetLongParameter(1) < 65000)
                              /*~-1*/
                              {
                              /*~T*/
                              g_Weight_lSimulatedRMW = Communication_GetLongParameter(1);
                              /*~T*/
                              g_SystemControl.bySimulate |= 0x01;
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              lText2Send = TEXT_SIMULATED_RMW_SET_CH0; 
                              /*~-1*/
                              }
                              /*~O:I1736*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              g_SystemControl.bySimulate &= 0xFE;
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              lText2Send = TEXT_RMW_SIMULATION_STOPPED_CH0; 
                              /*~-1*/
                              }
                              /*~E:I1736*/
                              /*~-1*/
#endif
                              /*~E:I1735*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1734*/
                              /*~F:1737*/
                              case 1:
                              /*~-1*/
                              {
                              /*~I:1738*/
#ifdef CHANNEL_1
                              /*~I:1739*/
                              if (Communication_GetLongParameter(1) < 65000)
                              /*~-1*/
                              {
                              /*~T*/
                              g_Weight_lSimulatedRMW = Communication_GetLongParameter(1);
                              /*~T*/
                              g_SystemControl.bySimulate |= 0x01;
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              lText2Send = TEXT_SIMULATED_RMW_SET_CH1; 
                              /*~-1*/
                              }
                              /*~O:I1739*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              g_SystemControl.bySimulate &= 0xFE;
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              lText2Send = TEXT_RMW_SIMULATION_STOPPED_CH1; 
                              /*~-1*/
                              }
                              /*~E:I1739*/
                              /*~-1*/
#endif
                              /*~E:I1738*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1737*/
                           /*~-1*/
                           }
                           /*~E:C1733*/
                        /*~-1*/
                        }
                        /*~O:I1732*/
                        /*~-2*/
                        else
                        {
                           /*~A:1740*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1740*/
                        /*~-1*/
                        }
                        /*~E:I1732*/
                     /*~-1*/
                     }
                     /*~E:I1731*/
                     /*~E:A1730*/
                     /*~-1*/
#endif
                     /*~E:I1729*/
                     /*~A:1741*/
                     /*~+:SLC - SetLoadCelltype*/
                     /*~I:1742*/
                     if (!strcmp(szCommand,"SLC"))
                     /*~-1*/
                     {
                        /*~A:1743*/
                        /*~+:Variablendeklarationen*/
                        /*~T*/
                        BYTE byError;
                        /*~E:A1743*/
                        /*~A:1744*/
                        /*~+:Variableninitialisierungen*/
                        /*~T*/
                        byError = 0;
                        /*~E:A1744*/
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;

                        /*~I:1745*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0);
                           /*~I:1746*/
                           if (!GET_RESPONSE)
                           /*~-1*/
                           {
                              /*~T*/
                              // Alles okay
                              /*~C:1747*/
                              switch ((unsigned char)Parameter[0].nLong)
                              /*~-1*/
                              {
                              /*~F:1748*/
                              case 1:
                              /*~-1*/
                              {
                              /*~T*/
                              // Defaultparameter 'Standard-Zelle'
                              /*~I:1749*/
                              if ((g_SystemControl.byLoadCellType)&&(g_SystemControl.byLoadCellType != 1))
                              /*~-1*/
                              {
                              /*~T*/
                              // Zellentyp hat sich ge�ndert

                              // Kalibrierfaktor �ndern
                              Measurement_GetCalibrationFactor(WEIGHT_WEIGHTCHANNEL,&fTemp);
                              Weight_SetCalibrationFactor(fTemp / 5);

                              // Filtertiefe halbieren
                              byTemp = AverageFilter_GetFilterDepth(WEIGHT_WEIGHTCHANNEL) / 2;
                              AverageFilter_SetFilterDepth(WEIGHT_WEIGHTCHANNEL,byTemp);
                              // und speichern
                              Save_Parameter(LOAD_SAVE_FILTER_DEPTH_WEIGHT,&byTemp,0);


                              // Verst�rkungsfaktoren der Stromschnittstelle anpassen
                              fTemp = ADuC836_DACGetGain(0);
                              ADuC836_DACSetGain(fTemp / 5);

                              fTemp = ADuC836_DACGetGain(1);
                              ADuC836_DACSetGainNorm(fTemp / 5);

                              // und neue Einstellungen sichern
                              CurrentInterface_SaveDACSettings(CURRENTINTERFACE_ALL_SETTINGS);
                              /*~-1*/
                              }
                              /*~E:I1749*/
                              /*~T*/
                              g_Limit.fLimitZeroPointCheck = LIMIT_ZERODRIFT_DETECTION;
                              // speichern
                              Save_Parameter(LOAD_SAVE_LIMIT_ZEROPOINTCHECK,&g_Limit.fLimitZeroPointCheck,4);
                              /*~T*/
                              MRW_Compensation_SetCheckLimits(MRW_COMPENSATION_LIMIT_DEVIATIONS,MRW_COMPENSATION_LIMIT_DRIFT);
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1748*/
                              /*~F:1750*/
                              case 2:
                              /*~-1*/
                              {
                              /*~T*/
                              // Defaultparameter 'XL-Zelle'
                              /*~I:1751*/
                              if (g_SystemControl.byLoadCellType != 2)
                              /*~-1*/
                              {
                              /*~T*/
                              // Zellentyp hat sich ge�ndert

                              // Kalibrierfaktor �ndern
                              Measurement_GetCalibrationFactor(WEIGHT_WEIGHTCHANNEL,&fTemp);
                              Weight_SetCalibrationFactor(fTemp * 5);

                              // Filtertiefe verdoppeln
                              byTemp = AverageFilter_GetFilterDepth(WEIGHT_WEIGHTCHANNEL) * 2;
                              AverageFilter_SetFilterDepth(WEIGHT_WEIGHTCHANNEL,byTemp);
                              // und speichern
                              Save_Parameter(LOAD_SAVE_FILTER_DEPTH_WEIGHT,&byTemp,0);

                              // Verst�rkungsfaktoren der Stromschnittstelle anpassen
                              fTemp = ADuC836_DACGetGain(0);
                              ADuC836_DACSetGain(fTemp * 5);

                              fTemp = ADuC836_DACGetGain(1);
                              ADuC836_DACSetGainNorm(fTemp * 5);

                              // und neue Einstellungen sichern
                              CurrentInterface_SaveDACSettings(CURRENTINTERFACE_ALL_SETTINGS);
                              /*~-1*/
                              }
                              /*~E:I1751*/
                              /*~T*/
                              g_Limit.fLimitZeroPointCheck = LIMIT_ZERODRIFT_DETECTION_XL;
                              // speichern
                              Save_Parameter(LOAD_SAVE_LIMIT_ZEROPOINTCHECK,&g_Limit.fLimitZeroPointCheck,4);
                              /*~T*/
                              MRW_Compensation_SetCheckLimits(MRW_COMPENSATION_LIMIT_DEVIATIONS_XL,MRW_COMPENSATION_LIMIT_DRIFT_XL);
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1750*/
                              /*~O:C1747*/
                              /*~-2*/
                              default:
                              {
                              /*~T*/
                              byError = 1;
                              /*~A:1752*/
                              /*~+:Ausf�hrungsstatus auf 'E002' setzen*/
                              /*~K*/
                              /*~+:Parameter au�erhalb der Grenzen !!!*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E002;
                              /*~E:A1752*/
                              /*~-1*/
                              }
                              /*~-1*/
                              }
                              /*~E:C1747*/
                              /*~I:1753*/
                              if (!byError)
                              /*~-1*/
                              {
                              /*~T*/
                              // Wert setzen
                              g_SystemControl.byLoadCellType = (unsigned char)Parameter[0].nLong;
                              // und abspeichern
                              Save_Parameter(LOAD_SAVE_CELLTYPE,&g_SystemControl.byLoadCellType,0);
                              /*~A:1754*/
                              /*~+:Ausf�hrungsstatus auf 'OKAY' setzen*/
                              /*~+:*/
                              /*~T*/
                              // Ausf�hrungsstatus auf 'OKAY' setzen
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              /*~E:A1754*/
                              /*~A:1755*/
                              /*~+:Kanal 0 - Textausgabe*/
                              /*~I:1756*/
#ifdef CHANNEL_0 
                              /*~A:1757*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              lText2Send = TEXT_LOADCELL_TYPE_SET;
                              /*~E:A1757*/
                              /*~-1*/
#endif
                              /*~E:I1756*/
                              /*~E:A1755*/
                              /*~-1*/
                              }
                              /*~E:I1753*/
                           /*~-1*/
                           }
                           /*~O:I1746*/
                           /*~-2*/
                           else
                           {
                              /*~A:1758*/
                              /*~+:Ausf�hrungsstatus auf 'E005' setzen*/
                              /*~K*/
                              /*~+:Fehler !!!*/
                              /*~I:1759*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~-1*/
#endif
                              /*~E:I1759*/
                              /*~E:A1758*/
                           /*~-1*/
                           }
                           /*~E:I1746*/
                        /*~-1*/
                        }
                        /*~O:I1745*/
                        /*~-2*/
                        else
                        {
                           /*~A:1760*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1760*/
                        /*~-1*/
                        }
                        /*~E:I1745*/
                     /*~-1*/
                     }
                     /*~E:I1742*/
                     /*~E:A1741*/
                     /*~A:1761*/
                     /*~+:SLS - SetdacLimitStatus*/
                     /*~I:1762*/
                     if (!strcmp(szCommand,"SLS"))
                     /*~-1*/
                     {
                        /*~A:1763*/
                        /*~+:Variablendeklarationen*/
                        /*~T*/
                        unsigned long ulEepromClearID;
                        bit bOnOff;
                        /*~E:A1763*/
                        /*~A:1764*/
                        /*~+:Variableninitialisierungen*/
                        /*~T*/
                        ulEepromClearID = 0L;
                        /*~E:A1764*/
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:1765*/
                        if (!InstructionDecoder_CheckNbParameters(2,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           // Parameter auslesen
                           Parameter[0].nLong = Communication_GetLongParameter(0);
                           Parameter[1].nLong = Communication_GetLongParameter(1);
                           bOnOff = (bit) Communication_GetLongParameter(2); 
                           /*~C:1766*/
                           switch (Parameter[0].nLong)
                           /*~-1*/
                           {
                              /*~F:1767*/
                              case 0:
                              /*~-1*/
                              {
                              /*~A:1768*/
                              /*~+:Kanal 0*/
                              /*~I:1769*/
#ifdef CHANNEL_0
                              /*~T*/
                              ADuC836_DACEnableLimit(Parameter[1].nLong,bOnOff);
                              /*~A:1770*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              lText2Send = TEXT_LIMIT_STATE_CLEARED_CHANNEL_0;
                              /*~E:A1770*/
                              /*~-1*/
#endif
                              /*~E:I1769*/
                              /*~E:A1768*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1767*/
                              /*~F:1771*/
                              case 1:
                              /*~-1*/
                              {
                              /*~A:1772*/
                              /*~+:Kanal 1*/
                              /*~I:1773*/
#ifdef CHANNEL_1
                              /*~T*/
                              ADuC836_DACEnableLimit(Parameter[1].nLong,bOnOff);
                              /*~A:1774*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              lText2Send = TEXT_LIMIT_STATE_CLEARED_CHANNEL_1;
                              /*~E:A1774*/
                              /*~-1*/
#endif
                              /*~E:I1773*/
                              /*~E:A1772*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1771*/
                              /*~O:C1766*/
                              /*~-2*/
                              default:
                              {
                              /*~A:1775*/
                              /*~+:Kanal 0*/
                              /*~I:1776*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I1776*/
                              /*~E:A1775*/
                              /*~-1*/
                              }
                           /*~-1*/
                           }
                           /*~E:C1766*/
                        /*~-1*/
                        }
                        /*~O:I1765*/
                        /*~-2*/
                        else
                        {
                           /*~A:1777*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1777*/
                        /*~-1*/
                        }
                        /*~E:I1765*/
                     /*~-1*/
                     }
                     /*~E:I1762*/
                     /*~E:A1761*/
                     /*~I:1778*/
#ifdef MOF
                     /*~A:1779*/
                     /*~+:SMF - SetMotionFilter*/
                     /*~I:1780*/
                     if ((!strcmp(szCommand,"SMF"))||(!strcmp(szCommand,"SMT")))
                     /*~-1*/
                     {
                        /*~A:1781*/
                        /*~+:Variablendeklarationen*/
                        /*~T*/
                        MEASUREMENT_MOTIONPARAMETER MotionParameter;
                        /*~E:A1781*/
                        /*~A:1782*/
                        /*~+:Variableninitialisierungen*/
                        /*~T*/

                        /*~E:A1782*/
                        /*~T*/
                        // Text wurde bereits gesendet
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;

                        /*~I:1783*/
                        if (!InstructionDecoder_CheckNbParameters(2,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           // Parameter auslesen
                           Parameter[0].nLong = Communication_GetLongParameter(0);
                           Parameter[1].nLong = Communication_GetLongParameter(1);

                           // Motionparameter auslesen
                           Weight_GetMotionParameter(&MotionParameter);
                           /*~I:1784*/
                           if (!GET_RESPONSE)
                           /*~-1*/
                           {
                              /*~T*/
                              // Alles okay
                              /*~I:1785*/
                              if (!Parameter[0].nLong)
                              /*~-1*/
                              {
                              /*~T*/
                              // Motion-Parameter setzen
                              MotionParameter.byMotionFilter = (unsigned char)Parameter[1].nLong;
                              /*~A:1786*/
                              /*~+:Kanal 0 - Textausgabe*/
                              /*~I:1787*/
#ifdef CHANNEL_0
                              /*~A:1788*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              lText2Send = TEXT_MEASUREMENT_MOTIONFILTER_SET;
                              /*~E:A1788*/
                              /*~-1*/
#endif
                              /*~E:I1787*/
                              /*~E:A1786*/
                              /*~-1*/
                              }
                              /*~O:I1785*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              // No-Motion-Parameter setzen
                              MotionParameter.byNoMotionFilter = (unsigned char)Parameter[1].nLong;
                              /*~A:1789*/
                              /*~+:Kanal 0 - Textausgabe*/
                              /*~I:1790*/
#ifdef CHANNEL_0
                              /*~A:1791*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              lText2Send = TEXT_MEASUREMENT_NOMOTIONFILTER_SET;
                              /*~E:A1791*/
                              /*~-1*/
#endif
                              /*~E:I1790*/
                              /*~E:A1789*/
                              /*~-1*/
                              }
                              /*~E:I1785*/
                              /*~A:1792*/
                              /*~+:Ausf�hrungsstatus auf 'OKAY' setzen*/
                              /*~+:*/
                              /*~T*/
                              // Ausf�hrungsstatus auf 'OKAY' setzen
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              /*~E:A1792*/
                              /*~T*/
                              Weight_SetMotionParameter(MotionParameter,1);

                           /*~-1*/
                           }
                           /*~O:I1784*/
                           /*~-2*/
                           else
                           {
                              /*~K*/
                              /*~+:Fehler !!!*/
                              /*~A:1793*/
                              /*~+:Ausf�hrungsstatus auf 'E005' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A1793*/
                           /*~-1*/
                           }
                           /*~E:I1784*/
                        /*~-1*/
                        }
                        /*~O:I1783*/
                        /*~-2*/
                        else
                        {
                           /*~A:1794*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1794*/
                        /*~-1*/
                        }
                        /*~E:I1783*/
                     /*~-1*/
                     }
                     /*~E:I1780*/
                     /*~E:A1779*/
                     /*~-1*/
#endif
                     /*~E:I1778*/
                     /*~A:1795*/
                     /*~+:SML - SetMotionLimit*/
                     /*~I:1796*/
                     if (!strcmp(szCommand,"SML"))
                     /*~-1*/
                     {
                        /*~A:1797*/
                        /*~+:Variablendeklarationen*/
                        /*~T*/
                        MEASUREMENT_MOTIONPARAMETER MotionParameter;
                        /*~E:A1797*/
                        /*~A:1798*/
                        /*~+:Variableninitialisierungen*/
                        /*~T*/

                        /*~E:A1798*/
                        /*~T*/
                        // Text wurde bereits gesendet
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;

                        /*~I:1799*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           // Parameter auslesen
                           Parameter[0].fFloat = Communication_GetFloatParameter(0);

                           // Motionparameter auslesen
                           Weight_GetMotionParameter(&MotionParameter);
                           /*~I:1800*/
                           if (!GET_RESPONSE)
                           /*~-1*/
                           {
                              /*~T*/
                              // Alles okay
                              /*~T*/
                              // Motion-Parameter setzen
                              MotionParameter.fMotionLimit = Parameter[0].fFloat;

                              Weight_SetMotionParameter(MotionParameter,1);

                              /*~A:1801*/
                              /*~+:Ausf�hrungsstatus auf 'OKAY' setzen*/
                              /*~+:*/
                              /*~T*/
                              // Ausf�hrungsstatus auf 'OKAY' setzen
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              /*~E:A1801*/
                              /*~A:1802*/
                              /*~+:Kanal 0 - Textausgabe*/
                              /*~I:1803*/
#ifdef CHANNEL_0
                              /*~A:1804*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              lText2Send = TEXT_MEASUREMENT_MOTIONFILTER_SET;
                              /*~E:A1804*/
                              /*~-1*/
#endif
                              /*~E:I1803*/
                              /*~E:A1802*/
                           /*~-1*/
                           }
                           /*~O:I1800*/
                           /*~-2*/
                           else
                           {
                              /*~K*/
                              /*~+:Fehler !!!*/
                              /*~A:1805*/
                              /*~+:Ausf�hrungsstatus auf 'E005' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A1805*/
                           /*~-1*/
                           }
                           /*~E:I1800*/
                        /*~-1*/
                        }
                        /*~O:I1799*/
                        /*~-2*/
                        else
                        {
                           /*~A:1806*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1806*/
                        /*~-1*/
                        }
                        /*~E:I1799*/
                     /*~-1*/
                     }
                     /*~E:I1796*/
                     /*~E:A1795*/
                     /*~A:1807*/
                     /*~+:SMT - SetMotionTimer*/
                     /*~I:1808*/
                     if (!strcmp(szCommand,"SMT"))
                     /*~-1*/
                     {
                        /*~A:1809*/
                        /*~+:Variablendeklarationen*/
                        /*~T*/
                        MEASUREMENT_MOTIONPARAMETER MotionParameter;
                        /*~E:A1809*/
                        /*~A:1810*/
                        /*~+:Variableninitialisierungen*/
                        /*~T*/

                        /*~E:A1810*/
                        /*~T*/
                        // Text wurde bereits gesendet
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;

                        /*~I:1811*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           // Parameter auslesen
                           Parameter[0].nLong = Communication_GetLongParameter(0);

                           // Motionparameter auslesen
                           Weight_GetMotionParameter(&MotionParameter);
                           /*~I:1812*/
                           if (!GET_RESPONSE)
                           /*~-1*/
                           {
                              /*~T*/
                              // Alles okay
                              /*~T*/
                              // Motion-Parameter setzen
                              MotionParameter.byMotionFilter = (unsigned char)Parameter[0].nLong;
                              /*~A:1813*/
                              /*~+:Kanal 0 - Textausgabe*/
                              /*~I:1814*/
#ifdef CHANNEL_0
                              /*~A:1815*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              lText2Send = TEXT_MEASUREMENT_MOTIONTIMER_SET;
                              /*~E:A1815*/
                              /*~-1*/
#endif
                              /*~E:I1814*/
                              /*~E:A1813*/
                              /*~A:1816*/
                              /*~+:Ausf�hrungsstatus auf 'OKAY' setzen*/
                              /*~+:*/
                              /*~T*/
                              // Ausf�hrungsstatus auf 'OKAY' setzen
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              /*~E:A1816*/
                              /*~T*/
                              Weight_SetMotionParameter(MotionParameter,1);

                           /*~-1*/
                           }
                           /*~O:I1812*/
                           /*~-2*/
                           else
                           {
                              /*~K*/
                              /*~+:Fehler !!!*/
                              /*~A:1817*/
                              /*~+:Ausf�hrungsstatus auf 'E005' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A1817*/
                           /*~-1*/
                           }
                           /*~E:I1812*/
                        /*~-1*/
                        }
                        /*~O:I1811*/
                        /*~-2*/
                        else
                        {
                           /*~A:1818*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1818*/
                        /*~-1*/
                        }
                        /*~E:I1811*/
                     /*~-1*/
                     }
                     /*~E:I1808*/
                     /*~E:A1807*/
                     /*~I:1819*/
#ifdef MIT_EINSTELLBARER_MESSWERTTIEFE
                     /*~A:1820*/
                     /*~+:SNM - SetNumberofMeasurements*/
                     /*~I:1821*/
                     if (!strcmp(szCommand,"SNM"))
                     /*~-1*/
                     {
                        /*~A:1822*/
                        /*~+:Variablendeklarationen*/
                        /*~T*/
                        unsigned char byMeasurementDepth;
                        /*~E:A1822*/
                        /*~A:1823*/
                        /*~+:Variableninitialisierungen*/
                        /*~T*/

                        /*~E:A1823*/
                        /*~T*/
                        // Text wurde bereits gesendet
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;

                        /*~I:1824*/
                        if (!InstructionDecoder_CheckNbParameters(2,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           // Parameter auslesen
                           Parameter[0].nLong = Communication_GetLongParameter(0);
                           Parameter[1].nLong = Communication_GetLongParameter(1);

                           byMeasurementDepth = (unsigned char)Parameter[1].nLong;
                           /*~I:1825*/
                           if (!GET_RESPONSE)
                           /*~-1*/
                           {
                              /*~T*/
                              // Alles okay
                              /*~I:1826*/
                              if (byMeasurementDepth)
                              /*~-1*/
                              {
                              /*~C:1827*/
                              switch (Parameter[0].nLong)
                              /*~-1*/
                              {
                              /*~F:1828*/
                              case 0: // Messwerttiefe f�r Gewichtswert
                              /*~-1*/
                              {
                              /*~I:1829*/
                              if (byMeasurementDepth > 0)
                              /*~-1*/
                              {
                              /*~A:1830*/
                              /*~+:Messwerttiefe setzen*/
                              /*~T*/
                              // Messwerttiefe setzen
                              ADuC836_ADCSetMeasurementDepth(ADuC836_ADC_PRIMARY,byMeasurementDepth);
                              /*~E:A1830*/
                              /*~A:1831*/
                              /*~+:und speichern*/
                              /*~T*/
                              // und speichern
                              Save_Parameter(LOAD_SAVE_WEIGHT_MEASUREMENT_DEPTH,&byMeasurementDepth,1);
                              /*~E:A1831*/
                              /*~A:1832*/
                              /*~+:Eintrag in Diagnosespeicher vornehmen*/
                              /*~T*/
                              ulDiagnosisEntry2Set = DIAGNOSIS_MESSAGE_MEASUREMENT_DEPTH_RMW_SET;
                              /*~E:A1832*/
                              /*~A:1833*/
                              /*~+:Ausf�hrungsstatus auf 'OKAY' setzen*/
                              /*~+:*/
                              /*~T*/
                              // Ausf�hrungsstatus auf 'OKAY' setzen
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              /*~E:A1833*/
                              /*~A:1834*/
                              /*~+:Kanal 0 - Textausgabe*/
                              /*~I:1835*/
#ifdef CHANNEL_0
                              /*~A:1836*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              lText2Send = TEXT_MEASUREMENT_DEPTH_RMW_SET;
                              /*~E:A1836*/
                              /*~-1*/
#endif
                              /*~E:I1835*/
                              /*~E:A1834*/
                              /*~-1*/
                              }
                              /*~O:I1829*/
                              /*~-2*/
                              else
                              {
                              /*~A:1837*/
                              /*~+:Ausf�hrungsstatus auf 'E002' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E002;
                              /*~E:A1837*/
                              /*~-1*/
                              }
                              /*~E:I1829*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1828*/
                              /*~I:1838*/
#ifndef OHNE_STROMRUECKFUEHRUNG 
                              /*~F:1839*/
                              case 1:	// Messwerttiefe f�r Stromr�ckf�hrung
                              /*~-1*/
                              {
                              /*~I:1840*/
                              if (byMeasurementDepth > 0)
                              /*~-1*/
                              {
                              /*~A:1841*/
                              /*~+:Messwerttiefe setzen*/
                              /*~T*/
                              // Messwerttiefe setzen
                              ADuC836_ADCSetMeasurementDepth(ADuC836_ADC_PRIMARY_TOGGLE,byMeasurementDepth);

                              /*~E:A1841*/
                              /*~A:1842*/
                              /*~+:und speichern*/
                              /*~T*/
                              // und speichern
                              Save_Parameter(LOAD_SAVE_MEASUREMENT_DEPTH_FEEDBACK,&byMeasurementDepth,1);
                              /*~E:A1842*/
                              /*~A:1843*/
                              /*~+:Eintrag in Diagnosespeicher vornehmen*/
                              /*~T*/
                              ulDiagnosisEntry2Set = DIAGNOSIS_MESSAGE_MEASUREMENT_DEPTH_CURRENT_SET;
                              /*~E:A1843*/
                              /*~A:1844*/
                              /*~+:Ausf�hrungsstatus auf 'OKAY' setzen*/
                              /*~+:*/
                              /*~T*/
                              // Ausf�hrungsstatus auf 'OKAY' setzen
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              /*~E:A1844*/
                              /*~A:1845*/
                              /*~+:Kanal 0 - Textausgabe*/
                              /*~I:1846*/
#ifdef CHANNEL_0
                              /*~A:1847*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              lText2Send = TEXT_MEASUREMENT_DEPTH_FEEDBACK_SET;
                              /*~E:A1847*/
                              /*~-1*/
#endif
                              /*~E:I1846*/
                              /*~E:A1845*/
                              /*~-1*/
                              }
                              /*~O:I1840*/
                              /*~-2*/
                              else
                              {
                              /*~A:1848*/
                              /*~+:Ausf�hrungsstatus auf 'E002' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E002;
                              /*~E:A1848*/
                              /*~-1*/
                              }
                              /*~E:I1840*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1839*/
                              /*~-1*/
#endif
                              /*~E:I1838*/
                              /*~O:C1827*/
                              /*~-2*/
                              default:
                              {
                              /*~A:1849*/
                              /*~+:Ausf�hrungsstatus auf 'E002' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E002;
                              /*~E:A1849*/
                              /*~-1*/
                              }
                              /*~-1*/
                              }
                              /*~E:C1827*/
                              /*~-1*/
                              }
                              /*~O:I1826*/
                              /*~-2*/
                              else
                              {
                              /*~A:1850*/
                              /*~+:Ausf�hrungsstatus auf 'E002' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E002;
                              /*~E:A1850*/
                              /*~-1*/
                              }
                              /*~E:I1826*/
                           /*~-1*/
                           }
                           /*~O:I1825*/
                           /*~-2*/
                           else
                           {
                              /*~K*/
                              /*~+:Fehler !!!*/
                              /*~A:1851*/
                              /*~+:Ausf�hrungsstatus auf 'E005' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A1851*/
                           /*~-1*/
                           }
                           /*~E:I1825*/
                        /*~-1*/
                        }
                        /*~O:I1824*/
                        /*~-2*/
                        else
                        {
                           /*~A:1852*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1852*/
                        /*~-1*/
                        }
                        /*~E:I1824*/
                     /*~-1*/
                     }
                     /*~E:I1821*/
                     /*~E:A1820*/
                     /*~-1*/
#endif
                     /*~E:I1819*/
                     /*~I:1853*/
#ifdef DEVELOPMENT_SW
                     /*~A:1854*/
                     /*~+:SSC - SetSpiCheck*/
                     /*~I:1855*/
                     if (!strcmp(szCommand,"SSC"))
                     /*~-1*/
                     {
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;

                        /*~I:1856*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           // Parameter auslesen
                           Parameter[0].nLong = Communication_GetLongParameter(0);
                           /*~I:1857*/
                           if (Parameter[0].nLong)
                           /*~-1*/
                           {
                              /*~T*/
                              // SPI-Test einschalten
                              CommunicationControl.bTestSPI = 1;


                              /*~I:1858*/
#ifdef CHANNEL_0
                              /*~T*/
                              CommunicationControl.ulSPIE1CounterLast = -1; 
                              /*~-1*/
#endif
                              /*~E:I1858*/
                              /*~A:1859*/
                              /*~+:Kanal 0 - Textausgabe*/
                              /*~I:1860*/
#ifdef CHANNEL_0
                              /*~A:1861*/
                              /*~+:Ausf�hrungsstatus auf 'OKAY' setzen*/
                              /*~T*/
                              // Ausf�hrungsstatus auf 'OKAY' setzen
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              /*~E:A1861*/
                              /*~T*/
                              lText2Send = TEXT_SYSTEM_SPI_CHECK_ON;
                              /*~-1*/
#endif
                              /*~E:I1860*/
                              /*~E:A1859*/
                           /*~-1*/
                           }
                           /*~O:I1857*/
                           /*~-2*/
                           else
                           {
                              /*~T*/
                              // SPI-Test einschalten
                              CommunicationControl.bTestSPI = 0; 
                              /*~A:1862*/
                              /*~+:Kanal 0 - Textausgabe*/
                              /*~I:1863*/
#ifdef CHANNEL_0
                              /*~A:1864*/
                              /*~+:Ausf�hrungsstatus auf 'OKAY' setzen*/
                              /*~T*/
                              // Ausf�hrungsstatus auf 'OKAY' setzen
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              /*~E:A1864*/
                              /*~T*/
                              lText2Send = TEXT_SYSTEM_SPI_CHECK_OFF;
                              /*~-1*/
#endif
                              /*~E:I1863*/
                              /*~E:A1862*/
                           /*~-1*/
                           }
                           /*~E:I1857*/
                        /*~-1*/
                        }
                        /*~O:I1856*/
                        /*~-2*/
                        else
                        {
                           /*~A:1865*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1865*/
                        /*~-1*/
                        }
                        /*~E:I1856*/
                     /*~-1*/
                     }
                     /*~E:I1855*/
                     /*~E:A1854*/
                     /*~-1*/
#endif
                     /*~E:I1853*/
                     /*~A:1866*/
                     /*~+:SSN - SetSerialNumber*/
                     /*~I:1867*/
                     if (!strcmp(szCommand,"SSN"))
                     /*~-1*/
                     {
                        /*~A:1868*/
                        /*~+:Variablendeklarationen*/
                        /*~T*/
                        char *szSerialNumber;
                        /*~E:A1868*/
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;

                        /*~I:1869*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           szSerialNumber = Communication_GetStringParameter(0);

                           /*~I:1870*/
                           if (!System_SetSerialNumber(szSerialNumber))
                           /*~-1*/
                           {
                              /*~A:1871*/
                              /*~+:Kanal 0 - Textausgabe*/
                              /*~I:1872*/
#ifdef CHANNEL_0 
                              /*~A:1873*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              lText2Send = TEXT_SERAIL_NUMBER_SET;
                              /*~E:A1873*/
                              /*~-1*/
#endif
                              /*~E:I1872*/
                              /*~E:A1871*/
                           /*~-1*/
                           }
                           /*~O:I1870*/
                           /*~-2*/
                           else
                           {
                              /*~K*/
                              /*~+:Fehler !!!*/
                              /*~I:1874*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~-1*/
#endif
                              /*~E:I1874*/
                           /*~-1*/
                           }
                           /*~E:I1870*/
                        /*~-1*/
                        }
                        /*~O:I1869*/
                        /*~-2*/
                        else
                        {
                           /*~A:1875*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1875*/
                        /*~-1*/
                        }
                        /*~E:I1869*/
                     /*~-1*/
                     }
                     /*~E:I1867*/
                     /*~E:A1866*/
                     /*~A:1876*/
                     /*~+:SSP - SetStatisticsdataParameter*/
                     /*~I:1877*/
                     if (!strcmp(szCommand,"SSP"))
                     /*~-1*/
                     {
                        /*~A:1878*/
                        /*~+:Variablendeklarationen*/
                        /*~T*/
                        STATISTICSLIBRARY_SETUP StatisticsSetup;
                        float fLimit;
                        /*~E:A1878*/
                        /*~A:1879*/
                        /*~+:Variableninitialisierungen*/
                        /*~T*/

                        /*~E:A1879*/
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;

                        /*~I:1880*/
                        if (!InstructionDecoder_CheckNbParameters(2,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           // Parameter auslesen
                           Parameter[0].nLong = Communication_GetLongParameter(0);
                           Parameter[1].nLong = Communication_GetLongParameter(1);
                           fLimit = Communication_GetFloatParameter(1); 
                           /*~I:1881*/
                           if (!GET_RESPONSE)
                           /*~-1*/
                           {
                              /*~K*/
                              /*~+:// Alles okay*/
                              /*~T*/
                              // die aktuellen Parameter einlesen
                              StatisticsSetup = Statistics_GetSetup();
                              /*~A:1882*/
                              /*~+:Ausf�hrungsstatus auf 'OKAY' setzen*/
                              /*~+:*/
                              /*~T*/
                              // Ausf�hrungsstatus auf 'OKAY' setzen
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              /*~E:A1882*/
                              /*~C:1883*/
                              switch (Parameter[0].nLong)
                              /*~-1*/
                              {
                              /*~F:1884*/
                              case 0:	// Filter Temperatur�berwachung
                              /*~-1*/
                              {
                              /*~T*/
                              StatisticsSetup.chFilterCheckTemperature = (unsigned char)Parameter[1].nLong;
                              /*~A:1885*/
                              /*~+:Text f�r Terminalbetrieb - 2.Teil*/
                              /*~I:1886*/
#ifdef CHANNEL_0
                              /*~T*/
                              lText2Send = TEXT_STATISTICS_FILTER_TEMPERATURE_SET;
                              /*~-1*/
#endif
                              /*~E:I1886*/
                              /*~E:A1885*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1884*/
                              /*~F:1887*/
                              case 1:	// Filter Gewichts�berwachung
                              /*~-1*/
                              {
                              /*~T*/
                              StatisticsSetup.chFilterCheckWeight = (unsigned char)Parameter[1].nLong;
                              /*~A:1888*/
                              /*~+:Text f�r Terminalbetrieb - 2.Teil*/
                              /*~I:1889*/
#ifdef CHANNEL_0
                              /*~T*/
                              lText2Send = TEXT_STATISTICS_FILTER_WEIGHT_SET;
                              /*~-1*/
#endif
                              /*~E:I1889*/
                              /*~E:A1888*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1887*/
                              /*~F:1890*/
                              case 2:	// MotionLimit Gewichts�berwachung
                              /*~-1*/
                              {
                              /*~T*/
                              // StatisticsSetup.fMotionLimitCheckWeight = Parameter[2].fFloat;
                              StatisticsSetup.fMotionLimitCheckWeight = fLimit;
                              /*~A:1891*/
                              /*~+:Text f�r Terminalbetrieb - 2.Teil*/
                              /*~I:1892*/
#ifdef CHANNEL_0
                              /*~T*/
                              lText2Send = TEXT_STATISTICS_MOTIONLIMIT_WEIGHT_SET;
                              /*~-1*/
#endif
                              /*~E:I1892*/
                              /*~E:A1891*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1890*/
                              /*~F:1893*/
                              case 3:	// Filter Grenzwert�berschreitung und �berlast
                              /*~-1*/
                              {
                              /*~T*/
                              StatisticsSetup.chFilterOverLimit = (unsigned char)Parameter[1].nLong;
                              /*~A:1894*/
                              /*~+:Text f�r Terminalbetrieb - 2.Teil*/
                              /*~I:1895*/
#ifdef CHANNEL_0
                              /*~T*/
                              lText2Send = TEXT_STATISTICS_FILTER_OVERLIMIT_SET;
                              /*~-1*/
#endif
                              /*~E:I1895*/
                              /*~E:A1894*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1893*/
                              /*~F:1896*/
                              case 4:	// Grenzwert
                              /*~-1*/
                              {
                              /*~T*/
                              StatisticsSetup.fLimitOverLimit = fLimit;
                              /*~A:1897*/
                              /*~+: Text f�r Terminalbetrieb - 2.Teil*/
                              /*~I:1898*/
#ifdef CHANNEL_0
                              /*~T*/
                              lText2Send = TEXT_STATISTICS_LIMIT_OVERLIMIT_SET;
                              /*~-1*/
#endif
                              /*~E:I1898*/
                              /*~E:A1897*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1896*/
                              /*~O:C1883*/
                              /*~-2*/
                              default:
                              {
                              /*~K*/
                              /*~+:Fehler !!!*/
                              /*~A:1899*/
                              /*~+:Ausf�hrungsstatus auf 'E001' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~E:A1899*/
                              /*~-1*/
                              }
                              /*~-1*/
                              }
                              /*~E:C1883*/
                              /*~T*/
                              // Werte �bertragen
                              Statistics_SetSetup(StatisticsSetup);
                           /*~-1*/
                           }
                           /*~O:I1881*/
                           /*~-2*/
                           else
                           {
                              /*~K*/
                              /*~+:Fehler !!!*/
                              /*~A:1900*/
                              /*~+:Ausf�hrungsstatus auf 'E005' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A1900*/
                           /*~-1*/
                           }
                           /*~E:I1881*/
                        /*~-1*/
                        }
                        /*~O:I1880*/
                        /*~-2*/
                        else
                        {
                           /*~A:1901*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1901*/
                        /*~-1*/
                        }
                        /*~E:I1880*/
                     /*~-1*/
                     }
                     /*~E:I1877*/
                     /*~E:A1876*/
                     /*~A:1902*/
                     /*~+:SSS - SetSystemState*/
                     /*~I:1903*/
                     if (!strcmp(szCommand,"SSS"))
                     /*~-1*/
                     {
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;

                        /*~I:1904*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           // Parameter auslesen
                           Parameter[0].nLong = Communication_GetLongParameter(0);
                           /*~I:1905*/
                           if (!GET_RESPONSE)
                           /*~-1*/
                           {
                              /*~K*/
                              /*~+:// Acknowledge empfangen - Alles okay*/
                              /*~I:1906*/
                              if (Parameter[0].nLong)
                              /*~-1*/
                              {
                              /*~T*/
                              // Betriebszustand manuell setzen
                              System_SetSystemState(Parameter[0].nLong);

                              Global.Mode.bySetStateManualy = 1; 
                              /*~-1*/
                              }
                              /*~O:I1906*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              // Wieder zum normalen Betrieb �bergehen
                              System_SetSystemState(SYSTEM_RUNNING);

                              Global.Mode.bySetStateManualy = 0; 
                              /*~-1*/
                              }
                              /*~E:I1906*/
                              /*~A:1907*/
                              /*~+:Ausf�hrungsstatus auf 'OKAY' setzen*/
                              /*~+:*/
                              /*~T*/
                              // Ausf�hrungsstatus auf 'OKAY' setzen
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              /*~E:A1907*/
                              /*~A:1908*/
                              /*~+:Kanal 0 - Textausgabe*/
                              /*~I:1909*/
#ifdef CHANNEL_0
                              /*~C:1910*/
                              switch (Parameter[0].nLong)
                              /*~-1*/
                              {
                              /*~A:1911*/
                              /*~+:SYSTEM_RUNNING*/
                              /*~F:1912*/
                              case 0:
                              case SYSTEM_RUNNING:
                              /*~-1*/
                              {
                              /*~T*/
                              lText2Send = TEXT_SYSTEM_STATE_SET_2_RUNNING;
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1912*/
                              /*~E:A1911*/
                              /*~A:1913*/
                              /*~+:SYSTEM_REC_CHARACTERISTICS_ON*/
                              /*~F:1914*/
                              case SYSTEM_REC_CHARACTERISTICS_ON:
                              /*~-1*/
                              {
                              /*~T*/
                              lText2Send = TEXT_SYSTEM_STATE_SET_2_REC_CHARACTERISTICS;
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1914*/
                              /*~E:A1913*/
                              /*~A:1915*/
                              /*~+:SYSTEM_REC_CHARACTERISTICS_1ST_DRIFT*/
                              /*~F:1916*/
                              case SYSTEM_REC_CHARACTERISTICS_1ST_DRIFT:
                              /*~-1*/
                              {
                              /*~T*/
                              lText2Send = TEXT_SYSTEM_STATE_SET_2_FIRST_DRIFT_VALUE_DETERMINED;
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1916*/
                              /*~E:A1915*/
                              /*~A:1917*/
                              /*~+:SYSTEM_REC_CHARACTERISTICS_OKAY*/
                              /*~F:1918*/
                              case SYSTEM_REC_CHARACTERISTICS_OKAY:
                              /*~-1*/
                              {
                              /*~T*/
                              lText2Send = TEXT_SYSTEM_STATE_SET_2_REC_CHARACTERISTICS_FINISHED_SUCCESSFUL;
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1918*/
                              /*~E:A1917*/
                              /*~A:1919*/
                              /*~+:SYSTEM_REC_CHARACTERISTICS_ERROR*/
                              /*~F:1920*/
                              case SYSTEM_REC_CHARACTERISTICS_ERROR:
                              /*~-1*/
                              {
                              /*~T*/
                              lText2Send = TEXT_SYSTEM_STATE_SET_2_REC_CHARACTERISTICS_FINISHED_WITH_ERROR;
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1920*/
                              /*~E:A1919*/
                              /*~A:1921*/
                              /*~+:SYSTEM_ERROR*/
                              /*~F:1922*/
                              case SYSTEM_ERROR:
                              /*~-1*/
                              {
                              /*~T*/
                              lText2Send = TEXT_SYSTEM_STATE_SET_2_SYSTEM_ERROR;
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1922*/
                              /*~E:A1921*/
                              /*~O:C1910*/
                              /*~-2*/
                              default:
                              {
                              /*~K*/
                              /*~+:Fehler !!!*/
                              /*~I:1923*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E002;
                              /*~-1*/
#endif
                              /*~E:I1923*/
                              /*~-1*/
                              }
                              /*~-1*/
                              }
                              /*~E:C1910*/
                              /*~-1*/
#endif
                              /*~E:I1909*/
                              /*~E:A1908*/
                           /*~-1*/
                           }
                           /*~O:I1905*/
                           /*~-2*/
                           else
                           {
                              /*~K*/
                              /*~+:Fehler !!!*/
                              /*~A:1924*/
                              /*~+:Ausf�hrungsstatus auf 'E005' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A1924*/
                           /*~-1*/
                           }
                           /*~E:I1905*/
                        /*~-1*/
                        }
                        /*~O:I1904*/
                        /*~-2*/
                        else
                        {
                           /*~A:1925*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1925*/
                        /*~-1*/
                        }
                        /*~E:I1904*/
                     /*~-1*/
                     }
                     /*~E:I1903*/
                     /*~E:A1902*/
                     /*~A:1926*/
                     /*~+:SST - SetSimulatedTemperature*/
                     /*~I:1927*/
                     if (!strcmp(szCommand,"SST"))
                     /*~-1*/
                     {
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;

                        /*~I:1928*/
                        if (!InstructionDecoder_CheckNbParameters(2,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           // Parameter auslesen
                           Parameter[0].nLong = Communication_GetLongParameter(0);
                           Parameter[1].fFloat = Communication_GetFloatParameter(1);
                           /*~C:1929*/
                           switch (Parameter[0].nLong)
                           /*~-1*/
                           {
                              /*~F:1930*/
                              case 0:
                              /*~-1*/
                              {
                              /*~A:1931*/
                              /*~+:Kanal 0*/
                              /*~I:1932*/
#ifdef CHANNEL_0
                              /*~I:1933*/
                              if ((Parameter[1].fFloat >= -100)&&(Parameter[1].fFloat <= 100))
                              /*~-1*/
                              {
                              /*~T*/
                              g_SystemControl.bySimulate |= 0x02;
                              /*~T*/
                              // simulierte Temperatur setzen
                              Global.bySimulatedTemperature = (char)Parameter[1].fFloat;
                              /*~A:1934*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              lText2Send = TEXT_SIMULATED_TEMPERATURE_SET_CHANNEL_0;
                              /*~E:A1934*/
                              /*~-1*/
                              }
                              /*~O:I1933*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              g_SystemControl.bySimulate &= 0xFD;
                              /*~A:1935*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              lText2Send = lText2Send = TEXT_TEMPERATURE_SIMULATION_CHANCELD_CHANNEL_0;
                              /*~E:A1935*/
                              /*~-1*/
                              }
                              /*~E:I1933*/
                              /*~-1*/
#endif
                              /*~E:I1932*/
                              /*~E:A1931*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1930*/
                              /*~F:1936*/
                              case 1:
                              /*~-1*/
                              {
                              /*~A:1937*/
                              /*~+:Kanal 1*/
                              /*~I:1938*/
#ifdef CHANNEL_1
                              /*~I:1939*/
                              if ((Parameter[1].fFloat >= -100)&&(Parameter[1].fFloat <= 100))
                              /*~-1*/
                              {
                              /*~T*/
                              g_SystemControl.bySimulate |= 0x02;
                              /*~T*/
                              // simulierte Temperatur setzen
                              Global.bySimulatedTemperature = (char)Parameter[1].fFloat;
                              /*~A:1940*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              lText2Send = TEXT_SIMULATED_TEMPERATURE_SET_CHANNEL_1;
                              /*~E:A1940*/
                              /*~-1*/
                              }
                              /*~O:I1939*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              g_SystemControl.bySimulate &= 0xFD;
                              /*~A:1941*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              lText2Send = lText2Send = TEXT_TEMPERATURE_SIMULATION_CHANCELD_CHANNEL_1;
                              /*~E:A1941*/
                              /*~-1*/
                              }
                              /*~E:I1939*/
                              /*~-1*/
#endif
                              /*~E:I1938*/
                              /*~E:A1937*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1936*/
                              /*~O:C1929*/
                              /*~-2*/
                              default:
                              {
                              /*~A:1942*/
                              /*~+:Kanal 0*/
                              /*~I:1943*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I1943*/
                              /*~E:A1942*/
                              /*~-1*/
                              }
                           /*~-1*/
                           }
                           /*~E:C1929*/
                        /*~-1*/
                        }
                        /*~O:I1928*/
                        /*~-2*/
                        else
                        {
                           /*~A:1944*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1944*/
                        /*~-1*/
                        }
                        /*~E:I1928*/
                     /*~-1*/
                     }
                     /*~E:I1927*/
                     /*~E:A1926*/
                     /*~A:1945*/
                     /*~+:STA - SetTaretoActualweight*/
                     /*~K*/
                     /*~+:STA - identisch mit TET (TEachTare)*/
                     /*~E:A1945*/
                     /*~A:1946*/
                     /*~+:STH - SetTimeHysteresis*/
                     /*~I:1947*/
                     if (!strcmp(szCommand,"STH"))
                     /*~-1*/
                     {
                        /*~T*/
                        // Text wurde bereits gesendet
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;

                        /*~I:1948*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~I:1949*/
                           if (!GET_RESPONSE)
                           /*~-1*/
                           {
                              /*~T*/
                              // Parameter auslesen
                              Parameter[0].nLong = Communication_GetLongParameter(0);

                              /*~I:1950*/
                              if (Parameter[0].nLong <= 30)	// maximal 30 Sekunden
                              /*~-1*/
                              {
                              /*~T*/
                              CurrentInterface_SetTimeHysteresis(Parameter[0].nLong);
                              /*~A:1951*/
                              /*~+:Ausf�hrungsstatus auf 'OKAY' setzen*/
                              /*~+:*/
                              /*~T*/
                              // Ausf�hrungsstatus auf 'OKAY' setzen
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              /*~E:A1951*/
                              /*~A:1952*/
                              /*~+:Kanal 0 - Textausgabe*/
                              /*~I:1953*/
#ifdef CHANNEL_0
                              /*~A:1954*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              lText2Send = TEXT_CURRENT_INTERFACE_SET_TIME_HYSTERESIS;
                              /*~E:A1954*/
                              /*~-1*/
#endif
                              /*~E:I1953*/
                              /*~E:A1952*/
                              /*~-1*/
                              }
                              /*~O:I1950*/
                              /*~-2*/
                              else
                              {
                              /*~K*/
                              /*~+:Fehler !!!*/
                              /*~A:1955*/
                              /*~+:Ausf�hrungsstatus auf 'E002' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E002;
                              /*~E:A1955*/
                              /*~-1*/
                              }
                              /*~E:I1950*/
                           /*~-1*/
                           }
                           /*~O:I1949*/
                           /*~-2*/
                           else
                           {
                              /*~K*/
                              /*~+:Fehler !!!*/
                              /*~A:1956*/
                              /*~+:Ausf�hrungsstatus auf 'E005' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A1956*/
                           /*~-1*/
                           }
                           /*~E:I1949*/
                        /*~-1*/
                        }
                        /*~O:I1948*/
                        /*~-2*/
                        else
                        {
                           /*~A:1957*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1957*/
                        /*~-1*/
                        }
                        /*~E:I1948*/
                     /*~-1*/
                     }
                     /*~E:I1947*/
                     /*~E:A1946*/
                     /*~A:1958*/
                     /*~+:STO - SetTemperatureOffset*/
                     /*~I:1959*/
                     if (!strcmp(szCommand,"STO"))
                     /*~-1*/
                     {
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;

                        /*~I:1960*/
                        if (!InstructionDecoder_CheckNbParameters(2,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           // Parameter auslesen
                           Parameter[0].nLong = Communication_GetLongParameter(0);
                           Parameter[1].nLong = Communication_GetLongParameter(1);
                           /*~C:1961*/
                           switch (Parameter[0].nLong)
                           /*~-1*/
                           {
                              /*~F:1962*/
                              case 0:	// Temperaturoffset des Kanal 0 setzen
                              /*~-1*/
                              {
                              /*~A:1963*/
                              /*~+:Kanal 0*/
                              /*~I:1964*/
#ifdef CHANNEL_0
                              /*~T*/
                              // Temperaturoffset setzen und speichern
                              Analog_SetTemperatureOffset((char)Parameter[1].nLong,ANALOG_TEMPERATURE_CALIBRATION_SET_OFFSET_MANUALY); 
                              /*~A:1965*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              lText2Send = TEXT_TEMPERATURE_OFFSET_SET_CHANNEL_0;
                              /*~E:A1965*/
                              /*~-1*/
#endif
                              /*~E:I1964*/
                              /*~E:A1963*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1962*/
                              /*~F:1966*/
                              case 1:	// Temperaturoffset des Kanal 1 setzen
                              /*~-1*/
                              {
                              /*~A:1967*/
                              /*~+:Kanal 1*/
                              /*~I:1968*/
#ifdef CHANNEL_1
                              /*~T*/
                              // Temperaturoffset setzen und speichern
                              Analog_SetTemperatureOffset((char)Parameter[1].nLong,ANALOG_TEMPERATURE_CALIBRATION_SET_OFFSET_MANUALY); 
                              /*~A:1969*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              lText2Send = TEXT_TEMPERATURE_OFFSET_SET_CHANNEL_1;
                              /*~E:A1969*/
                              /*~-1*/
#endif
                              /*~E:I1968*/
                              /*~E:A1967*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1966*/
                              /*~F:1970*/
                              case 255: // Temperaturoffset berechnen
                              /*~-1*/
                              {
                              /*~I:1971*/
                              if (!GET_RESPONSE)
                              /*~-1*/
                              {
                              /*~K*/
                              /*~+:// Acknowledge empfangen - Alles okay*/
                              /*~T*/
                              Analog_SetTemperatureOffset((char)Parameter[1].nLong,ANALOG_TEMPERATURE_CALIBRATION_SET_OFFSET_AUTOMATICLY);
                              /*~A:1972*/
                              /*~+:Ausf�hrungsstatus auf 'OKAY' setzen*/
                              /*~+:*/
                              /*~T*/
                              // Ausf�hrungsstatus auf 'OKAY' setzen
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              /*~E:A1972*/
                              /*~A:1973*/
                              /*~+:Kanal 0 - Textausgabe*/
                              /*~I:1974*/
#ifdef CHANNEL_0
                              /*~A:1975*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              lText2Send = TEXT_TEMPERATURE_SENSOR_CALIBRATED;
                              /*~E:A1975*/
                              /*~-1*/
#endif
                              /*~E:I1974*/
                              /*~E:A1973*/
                              /*~-1*/
                              }
                              /*~O:I1971*/
                              /*~-2*/
                              else
                              {
                              /*~K*/
                              /*~+:Fehler !!!*/
                              /*~A:1976*/
                              /*~+:Ausf�hrungsstatus auf 'E005' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A1976*/
                              /*~-1*/
                              }
                              /*~E:I1971*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1970*/
                              /*~O:C1961*/
                              /*~-2*/
                              default:
                              {
                              /*~I:1977*/
#ifdef CHANNEL_0
                              /*~T*/
                              // Fehler
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I1977*/
                              /*~-1*/
                              }
                           /*~-1*/
                           }
                           /*~E:C1961*/
                        /*~-1*/
                        }
                        /*~O:I1960*/
                        /*~-2*/
                        else
                        {
                           /*~A:1978*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1978*/
                        /*~-1*/
                        }
                        /*~E:I1960*/
                     /*~-1*/
                     }
                     /*~E:I1959*/
                     /*~E:A1958*/
                     /*~A:1979*/
                     /*~+:STR - SetTaRa*/
                     /*~I:1980*/
                     if (!strcmp(szCommand,"STR"))
                     /*~-1*/
                     {
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;

                        /*~I:1981*/
                        if (!InstructionDecoder_CheckNbParameters(2,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           // Parameter auslesen
                           Parameter[0].nLong = Communication_GetLongParameter(0);
                           Parameter[1].fFloat = Communication_GetFloatParameter(1);
                           /*~C:1982*/
                           switch (Parameter[0].nLong)
                           /*~-1*/
                           {
                              /*~F:1983*/
                              case 0:
                              /*~-1*/
                              {
                              /*~A:1984*/
                              /*~+:Kanal 0*/
                              /*~I:1985*/
#ifdef CHANNEL_0
                              /*~I:1986*/
                              // Tara setzen und speichern
                              if (!Weight_SetTareValue(Parameter[1].fFloat,1))
                              /*~-1*/
                              {
                              /*~A:1987*/
                              /*~+:Eintrag in Diagnosespeicher vornehmen*/
                              /*~T*/
                              ulDiagnosisEntry2Set = DIAGNOSIS_MESSAGE_TARE_MANUAL;
                              /*~E:A1987*/
                              /*~A:1988*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              /*~I:1989*/
                              if (Parameter[1].fFloat)
                              /*~-1*/
                              {
                              /*~T*/
                              lText2Send = TEXT_MEASUREMENT_TARA_SET_2_FIX_VALUE_CHANNEL_0;
                              /*~-1*/
                              }
                              /*~O:I1989*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              lText2Send = TEXT_MEASUREMENT_TARA_CLEARED_CHANNEL_0;
                              /*~-1*/
                              }
                              /*~E:I1989*/
                              /*~E:A1988*/
                              /*~-1*/
                              }
                              /*~O:I1986*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~-1*/
                              }
                              /*~E:I1986*/
                              /*~-1*/
#endif
                              /*~E:I1985*/
                              /*~E:A1984*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1983*/
                              /*~F:1990*/
                              case 1:
                              /*~-1*/
                              {
                              /*~A:1991*/
                              /*~+:Kanal 1*/
                              /*~I:1992*/
#ifdef CHANNEL_1
                              /*~I:1993*/
                              // Tara setzen und speichern
                              if (!Weight_SetTareValue(Parameter[1].fFloat,1))
                              /*~-1*/
                              {
                              /*~A:1994*/
                              /*~+:Eintrag in Diagnosespeicher vornehmen*/
                              /*~T*/
                              ulDiagnosisEntry2Set = DIAGNOSIS_MESSAGE_TARE_MANUAL;
                              /*~E:A1994*/
                              /*~A:1995*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              /*~I:1996*/
                              if (Parameter[1].fFloat)
                              /*~-1*/
                              {
                              /*~T*/
                              lText2Send = TEXT_MEASUREMENT_TARA_SET_2_FIX_VALUE_CHANNEL_1;
                              /*~-1*/
                              }
                              /*~O:I1996*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              lText2Send = TEXT_MEASUREMENT_TARA_CLEARED_CHANNEL_1;
                              /*~-1*/
                              }
                              /*~E:I1996*/
                              /*~E:A1995*/
                              /*~-1*/
                              }
                              /*~O:I1993*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~-1*/
                              }
                              /*~E:I1993*/
                              /*~-1*/
#endif
                              /*~E:I1992*/
                              /*~E:A1991*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1990*/
                              /*~O:C1982*/
                              /*~-2*/
                              default:
                              {
                              /*~A:1997*/
                              /*~+:Kanal 0*/
                              /*~I:1998*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I1998*/
                              /*~E:A1997*/
                              /*~-1*/
                              }
                           /*~-1*/
                           }
                           /*~E:C1982*/
                        /*~-1*/
                        }
                        /*~O:I1981*/
                        /*~-2*/
                        else
                        {
                           /*~A:1999*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1999*/
                        /*~-1*/
                        }
                        /*~E:I1981*/
                     /*~-1*/
                     }
                     /*~E:I1980*/
                     /*~E:A1979*/
                     /*~A:2000*/
                     /*~+:SZA - SetZeroActualweight*/
                     /*~I:2001*/
                     if (!strcmp(szCommand,"SZA"))
                     /*~-1*/
                     {
                        /*~A:2002*/
                        /*~+:Variablendeklarationen*/
                        /*~T*/
                        char byRetVal;
                        /*~E:A2002*/
                        /*~A:2003*/
                        /*~+:Variableninitialisierungen*/
                        /*~T*/

                        /*~E:A2003*/
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:2004*/
                        if (!InstructionDecoder_CheckNbParameters(0,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           byRetVal = Weight_SetZeroRegardingActualWeight();
                           //byRetVal = 0;
                           /*~I:2005*/
                           if (!GET_RESPONSE)
                           /*~-1*/
                           {
                              /*~I:2006*/
                              if (!byRetVal)
                              /*~-1*/
                              {
                              /*~T*/
                              // Alles okay
                              /*~A:2007*/
                              /*~+:Ausf�hrungsstatus auf 'OKAY' setzen*/
                              /*~+:*/
                              /*~T*/
                              // Ausf�hrungsstatus auf 'OKAY' setzen
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              /*~E:A2007*/
                              /*~A:2008*/
                              /*~+:Eintrag in Diagnosespeicher vornehmen*/
                              /*~T*/
                              ulDiagnosisEntry2Set = DIAGNOSIS_MESSAGE_ZERO;
                              /*~E:A2008*/
                              /*~A:2009*/
                              /*~+:Kanal 0 - Text f�r Terminalbetrieb*/
                              /*~I:2010*/
#ifdef CHANNEL_0
                              /*~T*/
                              lText2Send = TEXT_MEASUREMENT_OFFSET_SET_2_ACTUAL;
                              /*~-1*/
#endif
                              /*~E:I2010*/
                              /*~E:A2009*/
                              /*~-1*/
                              }
                              /*~O:I2006*/
                              /*~-2*/
                              else
                              {
                              /*~K*/
                              /*~+:Fehler !!!*/
                              /*~A:2011*/
                              /*~+:Ausf�hrungsstatus auf 'E005' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A2011*/
                              /*~I:2012*/
#ifdef MOF
                              /*~A:2013*/
                              /*~+:diverse Ausgaben zur genaueren Aufschl�sselung des Fehlers*/
                              /*~C:2014*/
                              switch (byRetVal)
                              /*~-1*/
                              {
                              /*~F:2015*/
                              case 1:
                              /*~-1*/
                              {
                              /*~A:2016*/
                              /*~+:Ausf�hrungsstatus auf 'E105' setzen*/
                              /*~T*/
                              Communication_SendString(COMMUNICATION_RS232,"E105",1,0);
                              /*~E:A2016*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F2015*/
                              /*~F:2017*/
                              case 2:
                              /*~-1*/
                              {
                              /*~A:2018*/
                              /*~+:Ausf�hrungsstatus auf 'E205' setzen*/
                              /*~T*/
                              Communication_SendString(COMMUNICATION_RS232,"E205",1,0);
                              /*~E:A2018*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F2017*/
                              /*~O:C2014*/
                              /*~-2*/
                              default:
                              {
                              /*~A:2019*/
                              /*~+:Ausf�hrungsstatus auf 'E305' setzen*/
                              /*~T*/
                              Communication_SendString(COMMUNICATION_RS232,"E305",1,0);
                              /*~E:A2019*/
                              /*~-1*/
                              }
                              /*~-1*/
                              }
                              /*~E:C2014*/
                              /*~E:A2013*/
                              /*~-1*/
#endif
                              /*~E:I2012*/
                              /*~-1*/
                              }
                              /*~E:I2006*/
                           /*~-1*/
                           }
                           /*~O:I2005*/
                           /*~-2*/
                           else
                           {
                              /*~K*/
                              /*~+:Fehler !!!*/
                              /*~A:2020*/
                              /*~+:Ausf�hrungsstatus auf 'E005' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A2020*/
                           /*~-1*/
                           }
                           /*~E:I2005*/
                        /*~-1*/
                        }
                        /*~O:I2004*/
                        /*~-2*/
                        else
                        {
                           /*~A:2021*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A2021*/
                        /*~-1*/
                        }
                        /*~E:I2004*/
                     /*~-1*/
                     }
                     /*~E:I2001*/
                     /*~E:A2000*/
                     /*~A:2022*/
                     /*~+:SZP - SetZeroPoint*/
                     /*~I:2023*/
                     if (!strcmp(szCommand,"SZP"))
                     /*~-1*/
                     {
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;

                        /*~I:2024*/
                        if (!InstructionDecoder_CheckNbParameters(2,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           // Parameter auslesen
                           Parameter[0].nLong = Communication_GetLongParameter(0);
                           Parameter[1].nLong = Communication_GetLongParameter(1);
                           /*~C:2025*/
                           switch (Parameter[0].nLong)
                           /*~-1*/
                           {
                              /*~F:2026*/
                              case 0:
                              /*~-1*/
                              {
                              /*~A:2027*/
                              /*~+:Kanal 0*/
                              /*~I:2028*/
#ifdef CHANNEL_0
                              /*~I:2029*/
                              if (!Weight_SetZero(Parameter[1].nLong))
                              /*~-1*/
                              {
                              /*~A:2030*/
                              /*~+:Eintrag in Diagnosespeicher vornehmen*/
                              /*~T*/
                              ulDiagnosisEntry2Set = DIAGNOSIS_MESSAGE_ZERO_TO_VALUE;
                              /*~E:A2030*/
                              /*~A:2031*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              lText2Send = TEXT_MEASUREMENT_OFFSET_SET_2_VALUE_CHANNEL_0;
                              /*~E:A2031*/
                              /*~-1*/
                              }
                              /*~O:I2029*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~-1*/
                              }
                              /*~E:I2029*/
                              /*~-1*/
#endif
                              /*~E:I2028*/
                              /*~E:A2027*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F2026*/
                              /*~F:2032*/
                              case 1:
                              /*~-1*/
                              {
                              /*~A:2033*/
                              /*~+:Kanal 1*/
                              /*~I:2034*/
#ifdef CHANNEL_1
                              /*~I:2035*/
                              if (!Weight_SetZero(Parameter[1].nLong))
                              /*~-1*/
                              {
                              /*~A:2036*/
                              /*~+:Eintrag in Diagnosespeicher vornehmen*/
                              /*~T*/
                              ulDiagnosisEntry2Set = DIAGNOSIS_MESSAGE_ZERO_TO_VALUE;
                              /*~E:A2036*/
                              /*~A:2037*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              lText2Send = TEXT_MEASUREMENT_OFFSET_SET_2_VALUE_CHANNEL_1;
                              /*~E:A2037*/
                              /*~-1*/
                              }
                              /*~O:I2035*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~-1*/
                              }
                              /*~E:I2035*/
                              /*~-1*/
#endif
                              /*~E:I2034*/
                              /*~E:A2033*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F2032*/
                              /*~O:C2025*/
                              /*~-2*/
                              default:
                              {
                              /*~A:2038*/
                              /*~+:Kanal 0*/
                              /*~I:2039*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I2039*/
                              /*~E:A2038*/
                              /*~-1*/
                              }
                           /*~-1*/
                           }
                           /*~E:C2025*/
                        /*~-1*/
                        }
                        /*~O:I2024*/
                        /*~-2*/
                        else
                        {
                           /*~A:2040*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A2040*/
                        /*~-1*/
                        }
                        /*~E:I2024*/
                     /*~-1*/
                     }
                     /*~E:I2023*/
                     /*~E:A2022*/
                     /*~T*/
                     break;
                  /*~-1*/
                  }
                  /*~E:F1440*/
                  /*~E:A1439*/
                  /*~A:2041*/
                  /*~+:T*/
                  /*~F:2042*/
                  case 'T':
                  /*~-1*/
                  {
                     /*~I:2043*/
#ifdef MIT_LIMITTEACH_VIA_RS232
                     /*~A:2044*/
                     /*~+:TEC - TEaCh*/
                     /*~I:2045*/
                     if (!strcmp(szCommand,"TEC"))
                     /*~-1*/
                     {
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:2046*/
                        if (!InstructionDecoder_CheckNbParameters(0,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~I:2047*/
                           if (!GET_RESPONSE)
                           /*~-1*/
                           {
                              /*~K*/
                              /*~+:// Alles okay*/
                              /*~I:2048*/
                              if (!Limit_SetAlarmLimitByWeight(1,0))
                              /*~-1*/
                              {
                              /*~A:2049*/
                              /*~+:Ausf�hrungsstatus auf 'OKAY' setzen*/
                              /*~+:*/
                              /*~T*/
                              // Ausf�hrungsstatus auf 'OKAY' setzen
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              /*~E:A2049*/
                              /*~A:2050*/
                              /*~+:Kanal 0 - Textausgabe*/
                              /*~I:2051*/
#ifdef CHANNEL_0
                              /*~T*/
                              lText2Send = TEXT_LIMIT_TEACHED;
                              /*~-1*/
#endif
                              /*~E:I2051*/
                              /*~E:A2050*/
                              /*~-1*/
                              }
                              /*~O:I2048*/
                              /*~-2*/
                              else
                              {
                              /*~K*/
                              /*~+:Fehler !!!*/
                              /*~A:2052*/
                              /*~+:Ausf�hrungsstatus auf 'E005' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A2052*/
                              /*~-1*/
                              }
                              /*~E:I2048*/
                           /*~-1*/
                           }
                           /*~O:I2047*/
                           /*~-2*/
                           else
                           {
                              /*~K*/
                              /*~+:Fehler !!!*/
                              /*~A:2053*/
                              /*~+:Ausf�hrungsstatus auf 'E005' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A2053*/
                           /*~-1*/
                           }
                           /*~E:I2047*/
                        /*~-1*/
                        }
                        /*~O:I2046*/
                        /*~-2*/
                        else
                        {
                           /*~A:2054*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A2054*/
                        /*~-1*/
                        }
                        /*~E:I2046*/
                     /*~-1*/
                     }
                     /*~E:I2045*/
                     /*~E:A2044*/
                     /*~-1*/
#endif
                     /*~E:I2043*/
                     /*~I:2055*/
#ifdef MIT_TARATEACH_VIA_RS232
                     /*~A:2056*/
                     /*~+:TET - TEachTare*/
                     /*~I:2057*/
                     if (!strcmp(szCommand,"TET"))
                     /*~-1*/
                     {
                        /*~A:2058*/
                        /*~+:Variablendeklarationen*/
                        /*~T*/

                        /*~E:A2058*/
                        /*~A:2059*/
                        /*~+:Variableninitialisierungen*/
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~E:A2059*/
                        /*~A:2060*/
                        /*~+:Kanal 0*/
                        /*~I:2061*/
#ifdef CHANNEL_0
                        /*~I:2062*/
                        if (!InstructionDecoder_CheckNbParameters(0,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~I:2063*/
                           if (!GET_RESPONSE)
                           /*~-1*/
                           {
                              /*~I:2064*/
                              if (!Limit_TeachTara())
                              /*~-1*/
                              {
                              /*~K*/
                              /*~+:Tarierung erfolgreich*/
                              /*~T*/
                              // Tara �bernehmen
                              Weight_TareWeight = Measurement_GetResult(WEIGHT_WEIGHTCHANNEL,MEASUREMENT_GET_TARE);
                              /*~A:2065*/
                              /*~+:Ausf�hrungsstatus auf 'OKAY' setzen*/
                              /*~+:*/
                              /*~T*/
                              // Ausf�hrungsstatus auf 'OKAY' setzen
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              /*~E:A2065*/
                              /*~A:2066*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              lText2Send = TEXT_TARE_TEACHED;
                              /*~E:A2066*/
                              /*~-1*/
                              }
                              /*~O:I2064*/
                              /*~-2*/
                              else
                              {
                              /*~K*/
                              /*~+:Fehler beim Teachen Kanal 0*/
                              /*~A:2067*/
                              /*~+:Ausf�hrungsstatus auf 'E005' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A2067*/
                              /*~-1*/
                              }
                              /*~E:I2064*/
                           /*~-1*/
                           }
                           /*~O:I2063*/
                           /*~-2*/
                           else
                           {
                              /*~K*/
                              /*~+:Fehler beim Teachen Kanal 1*/
                              /*~A:2068*/
                              /*~+:Ausf�hrungsstatus auf 'E005' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A2068*/
                           /*~-1*/
                           }
                           /*~E:I2063*/
                        /*~-1*/
                        }
                        /*~O:I2062*/
                        /*~-2*/
                        else
                        {
                           /*~A:2069*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A2069*/
                        /*~-1*/
                        }
                        /*~E:I2062*/
                        /*~-1*/
#endif
                        /*~E:I2061*/
                        /*~E:A2060*/
                        /*~A:2070*/
                        /*~+:Kanal 1*/
                        /*~I:2071*/
#ifdef CHANNEL_1
                        /*~I:2072*/
                        if (!InstructionDecoder_CheckNbParameters(0,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~I:2073*/
                           if (!Limit_TeachTara())
                           /*~-1*/
                           {
                              /*~T*/
                              // Tara �bernehmen
                              Weight_TareWeight = Measurement_GetResult(WEIGHT_WEIGHTCHANNEL,MEASUREMENT_GET_TARE);
                              /*~T*/
                              Communication_SendMessage(COMMUNICATION_SPI,COMMUNICATION_SHORT_ACK);
                           /*~-1*/
                           }
                           /*~O:I2073*/
                           /*~-2*/
                           else
                           {
                              /*~T*/
                              Communication_SendMessage(COMMUNICATION_SPI,COMMUNICATION_NOK);
                           /*~-1*/
                           }
                           /*~E:I2073*/
                        /*~-1*/
                        }
                        /*~O:I2072*/
                        /*~-2*/
                        else
                        {
                           /*~A:2074*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A2074*/
                        /*~-1*/
                        }
                        /*~E:I2072*/
                        /*~-1*/
#endif
                        /*~E:I2071*/
                        /*~E:A2070*/
                     /*~-1*/
                     }
                     /*~E:I2057*/
                     /*~E:A2056*/
                     /*~-1*/
#endif
                     /*~E:I2055*/
                     /*~A:2075*/
                     /*~+:TSL - TeStLimits*/
                     /*~I:2076*/
                     if (!strcmp(szCommand,"TSL"))
                     /*~-1*/
                     {
                        /*~A:2077*/
                        /*~+:Variablendeklarationen*/
                        /*~T*/

                        /*~E:A2077*/
                        /*~A:2078*/
                        /*~+:Variableninitialisierungen*/
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~E:A2078*/
                        /*~T*/
                        Parameter[0].nLong = Communication_GetLongParameter(0);
                        /*~A:2079*/
                        /*~+:Kanal 0*/
                        /*~I:2080*/
#ifdef CHANNEL_0
                        /*~I:2081*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~I:2082*/
                           if (!GET_RESPONSE)
                           /*~-1*/
                           {
                              /*~C:2083*/
                              switch (Parameter[0].nLong)
                              /*~-1*/
                              {
                              /*~F:2084*/
                              case 0:
                              /*~-1*/
                              {
                              /*~T*/
                              Limit_SetLimitCheckFlag(0x55);
                              /*~A:2085*/
                              /*~+:Ausf�hrungsstatus auf 'OKAY' setzen*/
                              /*~+:*/
                              /*~T*/
                              // Ausf�hrungsstatus auf 'OKAY' setzen
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              /*~E:A2085*/
                              /*~A:2086*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              lText2Send = TEXT_LOWER_LIMIT_TEST_STARTED;
                              /*~E:A2086*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F2084*/
                              /*~F:2087*/
                              case 1:
                              /*~-1*/
                              {
                              /*~T*/
                              Limit_SetLimitCheckFlag(0xAA);
                              /*~A:2088*/
                              /*~+:Ausf�hrungsstatus auf 'OKAY' setzen*/
                              /*~+:*/
                              /*~T*/
                              // Ausf�hrungsstatus auf 'OKAY' setzen
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              /*~E:A2088*/
                              /*~A:2089*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              lText2Send = TEXT_UPPER_LIMIT_TEST_STARTED;
                              /*~E:A2089*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F2087*/
                              /*~O:C2083*/
                              /*~-2*/
                              default:
                              {
                              /*~A:2090*/
                              /*~+:Ausf�hrungsstatus auf 'E002' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E002;
                              /*~E:A2090*/
                              /*~-1*/
                              }
                              /*~-1*/
                              }
                              /*~E:C2083*/
                           /*~-1*/
                           }
                           /*~O:I2082*/
                           /*~-2*/
                           else
                           {
                              /*~K*/
                              /*~+:Kanal 1 sendete keine Best�tigung*/
                              /*~A:2091*/
                              /*~+:Ausf�hrungsstatus auf 'E005' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A2091*/
                           /*~-1*/
                           }
                           /*~E:I2082*/
                        /*~-1*/
                        }
                        /*~O:I2081*/
                        /*~-2*/
                        else
                        {
                           /*~A:2092*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A2092*/
                        /*~-1*/
                        }
                        /*~E:I2081*/
                        /*~-1*/
#endif
                        /*~E:I2080*/
                        /*~E:A2079*/
                        /*~A:2093*/
                        /*~+:Kanal 1*/
                        /*~I:2094*/
#ifdef CHANNEL_1
                        /*~I:2095*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~I:2096*/
                           if (!GET_RESPONSE)
                           /*~-1*/
                           {
                              /*~C:2097*/
                              switch (Parameter[0].nLong)
                              /*~-1*/
                              {
                              /*~F:2098*/
                              case 0:
                              /*~-1*/
                              {
                              /*~A:2099*/
                              /*~+:Ausf�hrungsstatus auf 'OKAY' setzen*/
                              /*~+:*/
                              /*~T*/
                              // Ausf�hrungsstatus auf 'OKAY' setzen
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              /*~E:A2099*/
                              /*~T*/
                              Limit_SetLimitCheckFlag(0x55);
                              /*~T*/
                              Communication_SendMessage(COMMUNICATION_SPI,COMMUNICATION_SHORT_ACK);
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F2098*/
                              /*~F:2100*/
                              case 1:
                              /*~-1*/
                              {
                              /*~A:2101*/
                              /*~+:Ausf�hrungsstatus auf 'OKAY' setzen*/
                              /*~+:*/
                              /*~T*/
                              // Ausf�hrungsstatus auf 'OKAY' setzen
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              /*~E:A2101*/
                              /*~T*/
                              Limit_SetLimitCheckFlag(0xAA);
                              /*~T*/
                              Communication_SendMessage(COMMUNICATION_SPI,COMMUNICATION_SHORT_ACK);
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F2100*/
                              /*~O:C2097*/
                              /*~-2*/
                              default:
                              {
                              /*~A:2102*/
                              /*~+:Ausf�hrungsstatus auf 'E002' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E002;
                              /*~E:A2102*/
                              /*~-1*/
                              }
                              /*~-1*/
                              }
                              /*~E:C2097*/
                           /*~-1*/
                           }
                           /*~O:I2096*/
                           /*~-2*/
                           else
                           {
                              /*~A:2103*/
                              /*~+:Ausf�hrungsstatus auf 'E005' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A2103*/
                           /*~-1*/
                           }
                           /*~E:I2096*/
                        /*~-1*/
                        }
                        /*~O:I2095*/
                        /*~-2*/
                        else
                        {
                           /*~A:2104*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A2104*/
                        /*~-1*/
                        }
                        /*~E:I2095*/
                        /*~-1*/
#endif
                        /*~E:I2094*/
                        /*~E:A2093*/
                     /*~-1*/
                     }
                     /*~E:I2076*/
                     /*~E:A2075*/
                     /*~T*/
                     break;
                  /*~-1*/
                  }
                  /*~E:F2042*/
                  /*~E:A2041*/
                  /*~A:2105*/
                  /*~+:V*/
                  /*~F:2106*/
                  case 'V':
                  /*~-1*/
                  {
                     /*~A:2107*/
                     /*~+:VAS - ViewAlarmStatus*/
                     /*~K*/
                     /*~+:*/
                     /*~+:=> VDG*/
                     /*~E:A2107*/
                     /*~A:2108*/
                     /*~+:VDG - ViewDiaGnosis*/
                     /*~I:2109*/
                     // if ((!strcmp(szCommand,"VAS"))||(!strcmp(szCommand,"VDG")))
                     if (!strcmp(szCommand,"VAS"))

                     /*~-1*/
                     {
                        /*~A:2110*/
                        /*~+:Variablendeklarationen*/
                        /*~T*/
                        unsigned char byCounter;
                        /*~E:A2110*/
                        /*~A:2111*/
                        /*~+:Variableninitialisierungen*/
                        /*~T*/
                        byCounter = 3;
                        /*~E:A2111*/
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:2112*/
                        if (!SYSTEM_MRW_MANAGER)
                        /*~-1*/
                        {
                           /*~I:2113*/
                           if (!InstructionDecoder_CheckNbParameters(0,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                           /*~-1*/
                           {
                              /*~I:2114*/
#ifdef CHANNEL_0
                              /*~T*/
                              //  Wg. der langen Dauer der Ausgabe die Synchronisationspr�fung ausschalten
                              Communication_SendSPICommand("iSCS 0");
                              /*~I:2115*/
                              if (Communication_IsOK())
                              /*~-1*/
                              {
                              /*~T*/
                              Diagnosis_PrintMemory();
                              /*~T*/
                              Communication_SendSPICommand("iVDG");
                              /*~I:2116*/
                              if (Communication_IsOK())
                              /*~-1*/
                              {
                              /*~T*/
                              // Wg. der langen Dauer der Ausgabe die Synchronisationspr�fung ausschalten
                              System_SetCheckSynchronisation(0);
                              /*~-1*/
                              }
                              /*~E:I2116*/
                              /*~-1*/
                              }
                              /*~E:I2115*/
                              /*~-1*/
#endif
                              /*~E:I2114*/
                              /*~A:2117*/
                              /*~+:ausgeklammert*/
                              /*~I:2118*/
#ifdef MOF
                              /*~I:2119*/
#ifdef CHANNEL_0
                              /*~U:2120*/
                              /*~-2*/
                              do
                              {
                              /*~T*/
                              Communication_SendSPICommand("iSCS 0");
                              /*~-1*/
                              }
                              /*~O:U2120*/
                              while (!Communication_IsOK() && --byCounter);
                              /*~E:U2120*/
                              /*~T*/
                              Diagnosis_PrintMemory();
                              /*~T*/
                              byCounter = 3;
                              /*~U:2121*/
                              /*~-2*/
                              do
                              {
                              /*~T*/
                              Communication_SendSPICommand("iVDG");
                              /*~-1*/
                              }
                              /*~O:U2121*/
                              while (!Communication_IsOK() && --byCounter);
                              /*~E:U2121*/
                              /*~I:2122*/
                              if (byCounter)
                              /*~-1*/
                              {
                              /*~T*/
                              // Wg. der langen Dauer der Ausgabe die Synchronisationspr�fung ausschalten
                              System_SetCheckSynchronisation(0);
                              /*~-1*/
                              }
                              /*~E:I2122*/
                              /*~-1*/
#endif
                              /*~E:I2119*/
                              /*~-1*/
#endif
                              /*~E:I2118*/
                              /*~E:A2117*/
                           /*~-1*/
                           }
                           /*~O:I2113*/
                           /*~-2*/
                           else
                           {
                              /*~A:2123*/
                              /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                              /*~T*/

                              /*~E:A2123*/
                           /*~-1*/
                           }
                           /*~E:I2113*/
                        /*~-1*/
                        }
                        /*~O:I2112*/
                        /*~-2*/
                        else
                        {
                           /*~I:2124*/
                           if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                           /*~-1*/
                           {
                              /*~T*/
                              Parameter[0].nLong = Communication_GetLongParameter(0); 
                              /*~C:2125*/
                              switch (Parameter[0].nLong)
                              /*~-1*/
                              {
                              /*~F:2126*/
                              case 0:
                              /*~-1*/
                              {
                              /*~T*/
                              // Kanal 0

                              /*~I:2127*/
#ifdef CHANNEL_0
                              /*~T*/
                              //  Wg. der langen Dauer der Ausgabe die Synchronisationspr�fung ausschalten
                              Communication_SendSPICommand("iSCS 0");
                              /*~I:2128*/
                              if (Communication_IsOK())
                              /*~-1*/
                              {
                              /*~T*/
                              Diagnosis_PrintMemory();
                              /*~T*/
                              Communication_SendSPICommand("iSCS 1");
                              /*~-1*/
                              }
                              /*~E:I2128*/
                              /*~-1*/
#endif
                              /*~E:I2127*/
                              /*~A:2129*/
                              /*~+:ausgeklammert*/
                              /*~I:2130*/
#ifdef MOF
                              /*~I:2131*/
#ifdef CHANNEL_0
                              /*~U:2132*/
                              /*~-2*/
                              do
                              {
                              /*~T*/
                              Communication_SendSPICommand("iSCS 0");
                              /*~-1*/
                              }
                              /*~O:U2132*/
                              while (!Communication_IsOK() && --byCounter);
                              /*~E:U2132*/
                              /*~T*/
                              Diagnosis_PrintMemory();
                              /*~T*/
                              byCounter = 3;
                              /*~U:2133*/
                              /*~-2*/
                              do
                              {
                              /*~T*/
                              Communication_SendSPICommand("iSCS 1");
                              /*~-1*/
                              }
                              /*~O:U2133*/
                              while (!Communication_IsOK() && --byCounter);
                              /*~E:U2133*/
                              /*~-1*/
#endif
                              /*~E:I2131*/
                              /*~-1*/
#endif
                              /*~E:I2130*/
                              /*~E:A2129*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F2126*/
                              /*~F:2134*/
                              case 1:
                              /*~-1*/
                              {
                              /*~T*/
                              // Kanal 1
                              /*~I:2135*/
#ifdef CHANNEL_0
                              /*~T*/
                              Communication_SendSPICommand("iVDG");
                              /*~I:2136*/
                              if (Communication_IsOK())
                              /*~-1*/
                              {
                              /*~T*/
                              // Wg. der langen Dauer der Ausgabe die Synchronisationspr�fung ausschalten
                              System_SetCheckSynchronisation(0);
                              /*~-1*/
                              }
                              /*~E:I2136*/
                              /*~-1*/
#endif
                              /*~E:I2135*/
                              /*~A:2137*/
                              /*~+:ausgeklammert*/
                              /*~I:2138*/
#ifdef MOF
                              /*~I:2139*/
#ifdef CHANNEL_0
                              /*~U:2140*/
                              /*~-2*/
                              do
                              {
                              /*~T*/
                              Communication_SendSPICommand("iVDG");
                              /*~-1*/
                              }
                              /*~O:U2140*/
                              while (!Communication_IsOK() && --byCounter);
                              /*~E:U2140*/
                              /*~I:2141*/
                              if (byCounter)
                              /*~-1*/
                              {
                              /*~T*/
                              // Wg. der langen Dauer der Ausgabe die Synchronisationspr�fung ausschalten
                              System_SetCheckSynchronisation(0);
                              /*~-1*/
                              }
                              /*~E:I2141*/
                              /*~-1*/
#endif
                              /*~E:I2139*/
                              /*~-1*/
#endif
                              /*~E:I2138*/
                              /*~E:A2137*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F2134*/
                              /*~F:2142*/
                              case 2:
                              /*~-1*/
                              {
                              /*~T*/
                              // Freier Speicher Kanal 0
                              /*~I:2143*/
#ifdef CHANNEL_0
                              /*~T*/
                              Diagnosis_PrintFreeMemory();
                              /*~-1*/
#endif
                              /*~E:I2143*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F2142*/
                              /*~F:2144*/
                              case 3:
                              /*~-1*/
                              {
                              /*~T*/
                              // Freier Speicher Kanal 1
                              /*~I:2145*/
#ifdef CHANNEL_1
                              /*~T*/
                              Diagnosis_PrintFreeMemory();
                              /*~-1*/
#endif
                              /*~E:I2145*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F2144*/
                              /*~O:C2125*/
                              /*~-2*/
                              default:
                              {
                              /*~T*/
                              // Zur�cksetzen der Lese-Prozedur

                              Diagnosis_InitReadProcedure();
                              /*~-1*/
                              }
                              /*~-1*/
                              }
                              /*~E:C2125*/
                           /*~-1*/
                           }
                           /*~O:I2124*/
                           /*~-2*/
                           else
                           {
                              /*~A:2146*/
                              /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                              /*~T*/

                              /*~E:A2146*/
                           /*~-1*/
                           }
                           /*~E:I2124*/
                        /*~-1*/
                        }
                        /*~E:I2112*/
                     /*~-1*/
                     }
                     /*~E:I2109*/
                     /*~E:A2108*/
                     /*~T*/
                     break;
                  /*~-1*/
                  }
                  /*~E:F2106*/
                  /*~E:A2105*/
                  /*~K*/
                  /*~+:// interne Befehle (iXXX)*/
                  /*~A:2147*/
                  /*~+:i*/
                  /*~F:2148*/
                  case 'i':
                  /*~-1*/
                  {
                     /*~I:2149*/
#ifdef CHANNEL_0
                     /*~T*/
                     // Text wurde bereits gesendet
                     byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                     /*~-1*/
#endif
                     /*~E:I2149*/
                     /*~I:2150*/
#ifdef CHANNEL_1
                     /*~A:2151*/
                     /*~+:iACR - internal Command - AutomaticCompensationResults */
                     /*~I:2152*/
                     if (!strcmp(szCommand,"iACR"))
                     /*~-1*/
                     {
                        /*~A:2153*/
                        /*~+:SPI-Debugging - nur zu Testzwecken*/
                        /*~I:2154*/
#ifdef DEVELOPMENT_SW
                        /*~T*/
                        CommunicationControl.ulSPICounter++;
                        /*~-1*/
#endif
                        /*~E:I2154*/
                        /*~E:A2153*/
                        /*~T*/
                        Parameter[0].nLong = Communication_GetLongParameter(0);
                        Parameter[1].nLong = Communication_GetLongParameter(1);
                        /*~T*/
                        // Befehlsbest�tigung senden
                        Communication_SendSPICommand("OK");
                        /*~T*/
                        Compensation_PrintCompensationValues(1,Parameter[0].nLong,Parameter[1].nLong,0);
                     /*~-1*/
                     }
                     /*~E:I2152*/
                     /*~E:A2151*/
                     /*~A:2155*/
                     /*~+:iACS - internal Command - AutomaticCompensationStatus */
                     /*~I:2156*/
                     if (!strcmp(szCommand,"iACS"))
                     /*~-1*/
                     {
                        /*~A:2157*/
                        /*~+:Variablendeklarationen*/
                        /*~T*/
                        char byRecCharacteristicsOn;
                        /*~E:A2157*/
                        /*~A:2158*/
                        /*~+:Variableninitialisierungen*/
                        /*~T*/

                        /*~E:A2158*/
                        /*~A:2159*/
                        /*~+:SPI-Debugging - nur zu Testzwecken*/
                        /*~I:2160*/
#ifdef DEVELOPMENT_SW
                        /*~T*/
                        CommunicationControl.ulSPICounter++;
                        /*~-1*/
#endif
                        /*~E:I2160*/
                        /*~E:A2159*/
                        /*~T*/
                        MRW_Compensation_GetData(MRW_COMPENSATION_GET_REC_CHARACTERISTICS_ONOFF,0,&byRecCharacteristicsOn); 
                        /*~I:2161*/
                        if (byRecCharacteristicsOn)
                        /*~-1*/
                        {
                           /*~T*/
                           // Ausgabe Kanal 1
                           Compensation_PrintCompensationValues(0,0xFF,0,1);
                           /*~T*/
                           byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                        /*~-1*/
                        }
                        /*~E:I2161*/
                        /*~T*/
                        bDoNotWriteResult2Buffer = 0;
                     /*~-1*/
                     }
                     /*~E:I2156*/
                     /*~E:A2155*/
                     /*~A:2162*/
                     /*~+:iART - internal Command - AutomaticRecordTemperaturecompensation stoppen */
                     /*~I:2163*/
                     if (!strcmp(szCommand,"iART"))
                     /*~-1*/
                     {
                        /*~A:2164*/
                        /*~+:SPI-Debugging - nur zu Testzwecken*/
                        /*~I:2165*/
#ifdef DEVELOPMENT_SW
                        /*~T*/
                        CommunicationControl.ulSPICounter++;
                        /*~-1*/
#endif
                        /*~E:I2165*/
                        /*~E:A2164*/
                        /*~T*/
                        // Kennlinienaufnahme stoppen
                        MRW_Compensation_SetRecCharacteristicsOn(0);

                        System_SetSystemState(SYSTEM_RUNNING);
                        /*~A:2166*/
                        /*~+:Eintrag in Diagnosespeicher vornehmen*/
                        /*~T*/
                        ulDiagnosisEntry2Set = DIAGNOSIS_MESSAGE_TEMPCOMPENSATION_STOPPED;
                        /*~E:A2166*/
                        /*~T*/
                        // Best�tigung
                        byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                     /*~-1*/
                     }
                     /*~E:I2163*/
                     /*~E:A2162*/
                     /*~A:2167*/
                     /*~+:iCDL - internal Command - Connect2Docklight*/
                     /*~I:2168*/
                     if (!strcmp(szCommand,"iCDL"))
                     /*~-1*/
                     {
                        /*~A:2169*/
                        /*~+:SPI-Debugging - nur zu Testzwecken*/
                        /*~I:2170*/
#ifdef DEVELOPMENT_SW
                        /*~T*/
                        CommunicationControl.ulSPICounter++;
                        /*~-1*/
#endif
                        /*~E:I2170*/
                        /*~E:A2169*/
                        /*~T*/
                        // Docklightmodus setzen
                        System_Connect2MRW_Manager(0);

                        byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                     /*~-1*/
                     }
                     /*~E:I2168*/
                     /*~E:A2167*/
                     /*~A:2171*/
                     /*~+:iGDG - internal Command - GetDiaGnosis*/
                     /*~I:2172*/
                     if (!strcmp(szCommand,"iGDG"))
                     /*~-1*/
                     {
                        /*~A:2173*/
                        /*~+:Variablendeklarationen*/
                        /*~T*/
                        unsigned long 	ulMessage;
                        unsigned long 	ulTime;
                        /*~E:A2173*/
                        /*~A:2174*/
                        /*~+:SPI-Debugging - nur zu Testzwecken*/
                        /*~I:2175*/
#ifdef DEVELOPMENT_SW
                        /*~T*/
                        CommunicationControl.ulSPICounter++;
                        /*~-1*/
#endif
                        /*~E:I2175*/
                        /*~E:A2174*/
                        /*~T*/
                        byRetVal = Diagnosis_ReadMessageFromFlash(&ulTime,&ulMessage);
                        /*~T*/
                        Communication_SendLong(COMMUNICATION_SPI,0,ulTime,0,0);
                        Communication_SendLong(COMMUNICATION_SPI,0,ulMessage,0,0);
                        Communication_SendLong(COMMUNICATION_SPI,0,byRetVal,0,0);
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                     /*~-1*/
                     }
                     /*~E:I2172*/
                     /*~E:A2171*/
                     /*~A:2176*/
                     /*~+:iGLP - internal Command - GetLimitstatePartner*/
                     /*~I:2177*/
                     if (!strcmp(szCommand,"iGLP"))
                     /*~-1*/
                     {
                        /*~A:2178*/
                        /*~+:SPI-Debugging - nur zu Testzwecken*/
                        /*~I:2179*/
#ifdef DEVELOPMENT_SW
                        /*~T*/
                        CommunicationControl.ulSPICounter++;
                        /*~-1*/
#endif
                        /*~E:I2179*/
                        /*~E:A2178*/
                        /*~T*/
                        // Limitstatus des Partners auslesen
                        Global.chLimitStatus_Partner = (char)Communication_GetLongParameter(1);
                        /*~I:2180*/
                        if (!Communication_SendLong(COMMUNICATION_SPI,0,Limit_GetLimitState(),0,1))
                        /*~-1*/
                        {
                           /*~A:2181*/
                           /*~+:jetzt noch Ma�nahmen zur �berpr�fung der Gegenstelle treffen */
                           /*~T*/
                           System_IncCheckSynchronisationCounter();
                           /*~E:A2181*/
                        /*~-1*/
                        }
                        /*~E:I2180*/
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                     /*~-1*/
                     }
                     /*~E:I2177*/
                     /*~E:A2176*/
                     /*~A:2182*/
                     /*~+:iGPS - internal Command - GetPartnerState*/
                     /*~I:2183*/
                     if (!strcmp(szCommand,"iGPS"))
                     /*~-1*/
                     {
                        /*~A:2184*/
                        /*~+:Variablendeklarationen*/
                        /*~T*/
                        long lSystemStatePartner;

                        /*~E:A2184*/
                        /*~A:2185*/
                        /*~+:SPI-Debugging - nur zu Testzwecken*/
                        /*~I:2186*/
#ifdef DEVELOPMENT_SW
                        /*~T*/
                        CommunicationControl.ulSPICounter++;
                        /*~-1*/
#endif
                        /*~E:I2186*/
                        /*~E:A2185*/
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~C:2187*/
                        switch (Communication_GetLongParameter(0))
                        /*~-1*/
                        {
                           /*~F:2188*/
                           case 0:
                           /*~-1*/
                           {
                              /*~T*/
                              lSystemStatePartner = Communication_GetLongParameter(1);
                              /*~I:2189*/
                              // Partner-Systemstatus kann nur gesetzt werden, wenn das System nicht im Fehlerzustand ist !
                              if (SYSTEMSTATE != SYSTEM_ERROR)
                              /*~-1*/
                              {
                              /*~T*/
                              // Systemstatus des Partners auslesen
                              SYSTEMSTATE_PARTNER = lSystemStatePartner;
                              /*~-1*/
                              }
                              /*~E:I2189*/
                              /*~I:2190*/
#ifdef MIT_SYSTEMFEHLER_BEI_PARTNER_SYSTEMFEHLER
                              /*~I:2191*/
                              if (SYSTEMSTATE_PARTNER == SYSTEM_ERROR)
                              /*~-1*/
                              {
                              /*~A:2192*/
                              /*~+:Sicherheitsfunktion aufrufen*/
                              /*~T*/
                              // Sicherheitsfunktion aufrufen
                              Diagnosis_SecurityPartnerSystemError(SYSTEM_PARTNER_IN_SYSTEMERROR);
                              /*~E:A2192*/
                              /*~-1*/
                              }
                              /*~E:I2191*/
                              /*~-1*/
#endif
                              /*~E:I2190*/
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_SPI,0,SYSTEMSTATE,0,1);
                              /*~T*/
                              break;
                           /*~-1*/
                           }
                           /*~E:F2188*/
                           /*~F:2193*/
                           case 1:
                           /*~-1*/
                           {
                              /*~T*/
                              // Limitstatus des Partners auslesen
                              Global.chLimitStatus_Partner = (char)Communication_GetLongParameter(1);
                              /*~I:2194*/
                              if (!Communication_SendLong(COMMUNICATION_SPI,0,Limit_GetLimitState(),0,1))
                              /*~-1*/
                              {
                              /*~A:2195*/
                              /*~+:jetzt noch Ma�nahmen zur �berpr�fung der Gegenstelle treffen */
                              /*~T*/
                              System_IncCheckSynchronisationCounter();
                              /*~E:A2195*/
                              /*~-1*/
                              }
                              /*~E:I2194*/
                              /*~T*/
                              break;
                           /*~-1*/
                           }
                           /*~E:F2193*/
                        /*~-1*/
                        }
                        /*~E:C2187*/
                     /*~-1*/
                     }
                     /*~E:I2183*/
                     /*~E:A2182*/
                     /*~A:2196*/
                     /*~+:iGRS - internal Command - GetlastcommadexecutionReSult*/
                     /*~I:2197*/
                     if (!strcmp(szCommand,"iGRS"))
                     /*~-1*/
                     {
                        /*~A:2198*/
                        /*~+:SPI-Debugging - nur zu Testzwecken*/
                        /*~I:2199*/
#ifdef DEVELOPMENT_SW
                        /*~T*/
                        CommunicationControl.ulSPICounter++;
                        /*~-1*/
#endif
                        /*~E:I2199*/
                        /*~E:A2198*/
                        /*~A:2200*/
                        /*~+:Eintrag in Diagnosespeicher vornehmen*/
                        /*~I:2201*/
                        if (ulDiagnosisEntry2SetAtiGRS)
                        /*~-1*/
                        {
                           /*~T*/
                           Diagnosis_WriteMessage2Flash(ulDiagnosisEntry2SetAtiGRS);

                           ulDiagnosisEntry2SetAtiGRS = 0;
                        /*~-1*/
                        }
                        /*~E:I2201*/
                        /*~E:A2200*/
                        /*~I:2202*/
                        if (!Communication_SendLong(COMMUNICATION_SPI,0,g_byLastCommandExecutionResult,0,1))
                        /*~-1*/
                        {
                           /*~T*/
                           // Inhalt wieder l�schen
                           g_byLastCommandExecutionResult = 0xA5;
                        /*~-1*/
                        }
                        /*~E:I2202*/
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                     /*~-1*/
                     }
                     /*~E:I2197*/
                     /*~E:A2196*/
                     /*~A:2203*/
                     /*~+:iGSV - internal Command - GetStoredValue */
                     /*~I:2204*/
                     if (!strcmp(szCommand,"iGSV"))
                     /*~-1*/
                     {
                        /*~A:2205*/
                        /*~+:Variablendeklarationen*/
                        /*~T*/
                        unsigned char byValue2Get;
                        /*~E:A2205*/
                        /*~A:2206*/
                        /*~+:Variableninitialisierungen*/
                        /*~T*/

                        /*~E:A2206*/
                        /*~A:2207*/
                        /*~+:SPI-Debugging - nur zu Testzwecken*/
                        /*~I:2208*/
#ifdef DEVELOPMENT_SW
                        /*~T*/
                        CommunicationControl.ulSPICounter++;
                        /*~-1*/
#endif
                        /*~E:I2208*/
                        /*~E:A2207*/
                        /*~T*/
                        byValue2Get = (unsigned char)Communication_GetLongParameter(0);
                        /*~I:2209*/
                        if (g_ulTimeoutValue < SYSTEMTIME)
                        /*~-1*/
                        {
                           /*~T*/
                           // Timeout

                           // Inhalt wieder l�schen

                           /*~T*/
                           g_byValueStored = 0;
                        /*~-1*/
                        }
                        /*~O:I2209*/
                        /*~-2*/
                        else
                        {
                           /*~I:2210*/
                           if (!g_byValueStored)
                           /*~-1*/
                           {
                              /*~T*/
                              // Es liegt z.Z. kein Wert vor
                           /*~-1*/
                           }
                           /*~O:I2210*/
                           /*~-2*/
                           else
                           {
                              /*~I:2211*/
                              if (g_byValueStored == byValue2Get)
                              /*~-1*/
                              {
                              /*~T*/
                              // Der zu holende Wert entspricht dem abgespeicherten
                              /*~T*/
                              g_byValueStored = 0;
                              /*~C:2212*/
                              switch (byValue2Get)
                              /*~-1*/
                              {
                              /*~F:2213*/
                              case COMMUNICATION_NUMBER_OF_MEASUREMENTS:
                              case COMMUNICATION_FILTER_DEPTH:
                              case COMMUNICATION_LOADCELL:
                              case COMMUNICATION_MOTION_FILTER:
                              case COMMUNICATION_COMPENSATION_STATE:
                              case COMMUNICATION_E_COMPENSATION_STATE:
                              case COMMUNICATION_CURRENTINTERFACE_FEEDBACK_STATE:

                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_SPI,0,g_Value.byChar,0,0);
                              /*~T*/
                              return;
                              /*~-1*/
                              }
                              /*~E:F2213*/
                              /*~F:2214*/
                              case COMMUNICATION_FILTER_WIDTH:
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_SPI,0,g_Value.nInt,0,0);
                              /*~T*/
                              return;
                              /*~-1*/
                              }
                              /*~E:F2214*/
                              /*~F:2215*/
                              case COMMUNICATION_TIME_HYSTERESIS:
                              case COMMUNICATION_RS232_BAUDRATE:
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_SPI,0,g_Value.nLong,0,0);
                              /*~T*/
                              return;
                              /*~-1*/
                              }
                              /*~E:F2215*/
                              /*~F:2216*/
                              case COMMUNICATION_CHECKLIMIT_ZEROPOINTCHECK:
                              case COMMUNICATION_CHECKLIMIT_MAX_DEVIATION:
                              case COMMUNICATION_CHECKLIMIT_MAX_DRIFT:
                              case COMMUNICATION_MOTION_LIMIT:
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendFloat(COMMUNICATION_SPI,0,g_Value.fFloat,2,0,0);
                              /*~T*/
                              return;
                              /*~-1*/
                              }
                              /*~E:F2216*/
                              /*~-1*/
                              }
                              /*~E:C2212*/
                              /*~-1*/
                              }
                              /*~E:I2211*/
                           /*~-1*/
                           }
                           /*~E:I2210*/
                        /*~-1*/
                        }
                        /*~E:I2209*/
                        /*~T*/
                        Communication_SendString(COMMUNICATION_SPI,"NAV",0,0);
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                     /*~-1*/
                     }
                     /*~E:I2204*/
                     /*~E:A2203*/
                     /*~A:2217*/
                     /*~+:iGVR - internal Command - GetVeRsion */
                     /*~I:2218*/
                     if (!strcmp(szCommand,"iGVR"))
                     /*~-1*/
                     {
                        /*~A:2219*/
                        /*~+:SPI-Debugging - nur zu Testzwecken*/
                        /*~I:2220*/
#ifdef DEVELOPMENT_SW
                        /*~T*/
                        CommunicationControl.ulSPICounter++;
                        /*~-1*/
#endif
                        /*~E:I2220*/
                        /*~E:A2219*/
                        /*~T*/
                        Parameter[0].nLong = Communication_GetLongParameter(0); 
                        /*~C:2221*/
                        switch (Parameter[0].nLong)
                        /*~-1*/
                        {
                           /*~F:2222*/
                           case 0:		// Hardware-Version
                           /*~-1*/
                           {
                              /*~T*/
                              Communication_SendString(COMMUNICATION_SPI,TEXT_HARDWARE_VERSION,0,0);
                              /*~T*/
                              break;
                           /*~-1*/
                           }
                           /*~E:F2222*/
                           /*~F:2223*/
                           case 1:		// Software-Version
                           /*~-1*/
                           {
                              /*~T*/
                              Communication_SendString(COMMUNICATION_SPI,TEXT_SOFTWARE_VERSION,0,0);
                              /*~T*/
                              break;
                           /*~-1*/
                           }
                           /*~E:F2223*/
                        /*~-1*/
                        }
                        /*~E:C2221*/
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                     /*~-1*/
                     }
                     /*~E:I2218*/
                     /*~E:A2217*/
                     /*~A:2224*/
                     /*~+:iLED - internal Command - LEDset*/
                     /*~I:2225*/
                     if (!strcmp(szCommand,"iLED"))
                     /*~-1*/
                     {
                        /*~A:2226*/
                        /*~+:SPI-Debugging - nur zu Testzwecken*/
                        /*~I:2227*/
#ifdef DEVELOPMENT_SW
                        /*~T*/
                        CommunicationControl.ulSPICounter++;
                        /*~-1*/
#endif
                        /*~E:I2227*/
                        /*~E:A2226*/
                        /*~I:2228*/
                        if (Communication_GetLongParameter(0))
                        /*~-1*/
                        {
                           /*~I:2229*/
#ifndef SYSTEM_CND_LEDS_4_DEBUG
                           /*~T*/
                           // Platinen-LED einschalten
                           P06 = 0;

                           /*~-1*/
#endif
                           /*~E:I2229*/
                        /*~-1*/
                        }
                        /*~O:I2228*/
                        /*~-2*/
                        else
                        {
                           /*~I:2230*/
#ifndef SYSTEM_CND_LEDS_4_DEBUG 
                           /*~T*/
                           // Platinen-LED ausschalten
                           P06 = 1;

                           /*~-1*/
#endif
                           /*~E:I2230*/
                        /*~-1*/
                        }
                        /*~E:I2228*/
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                        // byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                     /*~-1*/
                     }
                     /*~E:I2225*/
                     /*~E:A2224*/
                     /*~A:2231*/
                     /*~+:iSCS - internal Command - SetCheckSysnchronisation onoff */
                     /*~I:2232*/
                     if (!strcmp(szCommand,"iSCS"))
                     /*~-1*/
                     {
                        /*~A:2233*/
                        /*~+:SPI-Debugging - nur zu Testzwecken*/
                        /*~I:2234*/
#ifdef DEVELOPMENT_SW
                        /*~T*/
                        CommunicationControl.ulSPICounter++;
                        /*~-1*/
#endif
                        /*~E:I2234*/
                        /*~E:A2233*/
                        /*~I:2235*/
                        if (Communication_GetLongParameter(0))
                        /*~-1*/
                        {
                           /*~T*/
                           // Synchronisationspr�fung ausschalten
                           System_SetCheckSynchronisation(1);
                        /*~-1*/
                        }
                        /*~O:I2235*/
                        /*~-2*/
                        else
                        {
                           /*~T*/
                           // Synchronisationspr�fung einschalten
                           System_SetCheckSynchronisation(0);
                        /*~-1*/
                        }
                        /*~E:I2235*/
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                        // byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                     /*~-1*/
                     }
                     /*~E:I2232*/
                     /*~E:A2231*/
                     /*~I:2236*/
#ifdef MIT_TEACHIN_FUNKTION
                     /*~A:2237*/
                     /*~+:iTIS - internal Command - TeachInStatus*/
                     /*~I:2238*/
                     if (!strcmp(szCommand,"iTIS"))
                     /*~-1*/
                     {
                        /*~A:2239*/
                        /*~+:SPI-Debugging - nur zu Testzwecken*/
                        /*~I:2240*/
#ifdef DEVELOPMENT_SW
                        /*~T*/
                        CommunicationControl.ulSPICounter++;
                        /*~-1*/
#endif
                        /*~E:I2240*/
                        /*~E:A2239*/
                        /*~T*/
                        Communication_SendLong(COMMUNICATION_SPI,0,(long)Global.chTeachInStatus,0,1);

                        // TeachIn-Interface aufrufen
                        TeachIn_Interface((char)Communication_GetLongParameter(0));

                        /*~T*/
                        // Merker f�r ein interpretierbares Kommando setzen
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                     /*~-1*/
                     }
                     /*~E:I2238*/
                     /*~E:A2237*/
                     /*~-1*/
#endif
                     /*~E:I2236*/
                     /*~I:2241*/
#ifdef DEVELOPMENT_SW
                     /*~I:2242*/
#ifdef DEVELOPMENT_SW_TEST_SPI_IRQ
                     /*~A:2243*/
                     /*~+:iTST - internal Command - TeST SPI*/
                     /*~I:2244*/
                     if (!strcmp(szCommand,"iTST"))
                     /*~-1*/
                     {
                        /*~A:2245*/
                        /*~+:Variablendeklarationen*/
                        /*~T*/
                        unsigned char szTest[] = {0x55, 0x55, 0x55, 0x55, 0x55, 0x55, 0x55, 0x55, 0x55, 0x55, 0x55, 0x55, 0x55, 0x55, 0x55, 0x55, 0x55, 0x55, 0x55, 0x55, 0x55, 0x55, 0x55, 0x55, 0x55, 0x55, 0x55, 0x55, 0x55, 0x55, 0x55, 0x55, 0x55, 0x55, 0x55, 0x55, 0x55, 0x55, 0x55, 0x55};
                        /*~E:A2245*/
                        /*~I:2246*/
                        if (Communication_GetLongParameter(0) == 1)
                        /*~-1*/
                        {
                           /*~T*/
                           // String von maximaler Puffergr��e senden 
                           szTest[27] = 0;
                        /*~-1*/
                        }
                        /*~E:I2246*/
                        /*~T*/
                        Communication_SendString(COMMUNICATION_SPI,szTest,0,0);
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                     /*~-1*/
                     }
                     /*~E:I2244*/
                     /*~E:A2243*/
                     /*~-1*/
#endif
                     /*~E:I2242*/
                     /*~-1*/
#endif
                     /*~E:I2241*/
                     /*~A:2247*/
                     /*~+:iTSY - internal Command - TimerSYnchronize*/
                     /*~I:2248*/
                     if (!strcmp(szCommand,"iTSY"))
                     /*~-1*/
                     {
                        /*~A:2249*/
                        /*~+:Variablendeklartionen*/
                        /*~T*/
                        long lTimerDeviation;
                        unsigned long ulOperatingTimePartner;
                        /*~E:A2249*/
                        /*~A:2250*/
                        /*~+:SPI-Debugging - nur zu Testzwecken*/
                        /*~I:2251*/
#ifdef DEVELOPMENT_SW
                        /*~T*/
                        CommunicationControl.ulSPICounter++;
                        /*~-1*/
#endif
                        /*~E:I2251*/
                        /*~E:A2250*/
                        /*~T*/
                        // Differenz der beiden Zeitgeber errechnen
                        ulOperatingTimePartner = (unsigned long)Communication_GetLongParameter(0);
                        lTimerDeviation = (long)OPERATINGHOURS - (long)ulOperatingTimePartner;

                        // Timerstand korrigieren
                        OPERATINGHOURS -= lTimerDeviation;
                        CUSTOMTIMER -= lTimerDeviation;

                        byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                     /*~-1*/
                     }
                     /*~E:I2248*/
                     /*~E:A2247*/
                     /*~A:2252*/
                     /*~+:iVDG - internal Command - ViewDiaGnosis*/
                     /*~I:2253*/
                     if (!strcmp(szCommand,"iVDG"))
                     /*~-1*/
                     {
                        /*~A:2254*/
                        /*~+:SPI-Debugging - nur zu Testzwecken*/
                        /*~I:2255*/
#ifdef DEVELOPMENT_SW
                        /*~T*/
                        CommunicationControl.ulSPICounter++;
                        /*~-1*/
#endif
                        /*~E:I2255*/
                        /*~E:A2254*/
                        /*~T*/
                        // Befehlsbest�tigung senden
                        Communication_SendSPICommand("OK");
                        /*~T*/
                        Diagnosis_PrintMemory();
                     /*~-1*/
                     }
                     /*~O:I2253*/
                     /*~-2*/
                     else
                     {
                        /*~T*/
                        //                     byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                     /*~-1*/
                     }
                     /*~E:I2253*/
                     /*~E:A2252*/
                     /*~K*/
                     /*~+:*/
                     /*~A:2256*/
                     /*~+:SPI-Debugging - nur zu Testzwecken*/
                     /*~I:2257*/
#ifdef DEVELOPMENT_SW
                     /*~I:2258*/
#ifdef SYSTEM_CND_ENABLE_SPI_DEBUGGING
                     /*~I:2259*/
                     if (CommunicationControl.bTestSPI == 1)
                     /*~-1*/
                     {
                        /*~I:2260*/
#ifdef SYSTEM_CND_ALL_SPI_COMMUNICATIONS
                        /*~T*/
                        // Nur zu Debugzwecken
                        sprintf(achString,"%s - S:%ld",szCommand,CommunicationControl.ulSPICounter);
                        Communication_SendString(COMMUNICATION_RS232,achString,0,1);
                        /*~O:I2260*/
                        /*~-1*/
#else
                        /*~I:2261*/
                        if (strlen(szCommand) != 4)
                        /*~-1*/
                        {
                           /*~T*/
                           // Nur zu Debugzwecken
                           sprintf(achString,"%s - S:%ld",szCommand,CommunicationControl.ulSPICounter);
                           Communication_SendString(COMMUNICATION_RS232,achString,0,1);
                        /*~-1*/
                        }
                        /*~E:I2261*/
                        /*~-1*/
#endif
                        /*~E:I2260*/
                     /*~-1*/
                     }
                     /*~E:I2259*/
                     /*~-1*/
#endif
                     /*~E:I2258*/
                     /*~-1*/
#endif
                     /*~E:I2257*/
                     /*~E:A2256*/
                     /*~-1*/
#endif
                     /*~E:I2150*/
                     /*~T*/
                     break;
                  /*~-1*/
                  }
                  /*~E:F2148*/
                  /*~E:A2147*/
               /*~-1*/
               }
               /*~E:C61*/
            /*~-1*/
            }
            /*~O:I60*/
            /*~-2*/
            else
            {
               /*~K*/
               /*~+:/~* Ge�ndert am 09.02.2022 *~/*/
               /*~T*/
               /* Else-Zweig von 'if ((Communication_IsCommunicationEnabled() != 0)||(strcmp(szCommand,"ENA") == 0)||(strcmp(szCommand,"CDL") == 0)||(CommunicationControl.chLine2Interprete != COMMUNICATION_RS232))' */

               byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
               /*~K*/
               /*~+:/~* Ende - Ge�ndert am 09.02.2022 *~/*/
            /*~-1*/
            }
            /*~E:I60*/
         /*~-1*/
         }
         /*~O:I59*/
         /*~-2*/
         else
         {
            /*~T*/
            /* Else-Zweig von 'if ((byChecksumError == FALSE)||(strcmp(szCommand,"CDL") == 0))' */
            byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
         /*~-1*/
         }
         /*~E:I59*/
         /*~I:2262*/
#ifdef OLD
         /*~A:2263*/
         /*~+:Eintrag in Diagnosespeicher vornehmen*/
         /*~I:2264*/
         if (ulDiagnosisEntry2Set)
         /*~-1*/
         {
            /*~T*/
            Diagnosis_WriteMessage2Flash(ulDiagnosisEntry2Set);
         /*~-1*/
         }
         /*~E:I2264*/
         /*~E:A2263*/
         /*~A:2265*/
         /*~+:Kommandostatus auswerten*/
         /*~C:2266*/
         switch (byCommandStatus)
         /*~-1*/
         {
            /*~F:2267*/
            case INSTRUCTIONDECODER_SEND_OK:	// Kommando wurde ordnungsgem�� interpretiert
            //case INSTRUCTIONDECODER_SEND_TEXT	// Beide Bedingungen identisch
            /*~-1*/
            {
               /*~A:2268*/
               /*~+:INSTRUCTIONDECODER_SEND_OK*/
               /*~I:2269*/
               if (CommunicationControl.chLine2Interprete == COMMUNICATION_RS232)
               /*~-1*/
               {
                  /*~I:2270*/
                  if (!SYSTEM_MRW_MANAGER)
                  /*~-1*/
                  {
                     /*~I:2271*/
#ifdef CHANNEL_0
                     /*~I:2272*/
                     if (lText2Send)
                     /*~-1*/
                     {
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                     /*~-1*/
                     }
                     /*~E:I2272*/
                     /*~-1*/
#endif
                     /*~E:I2271*/
                     /*~I:2273*/
#ifdef CHANNEL_1
                     /*~I:2274*/
                     if (bDoNotWriteResult2Buffer)
                     /*~-1*/
                     {
                        /*~I:2275*/
                        if (lText2Send)
                        /*~-1*/
                        {
                           /*~T*/
                           sprintf(szString2Send,"T%04ld",lText2Send);
                           /*~T*/
                           Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~-1*/
                        }
                        /*~O:I2275*/
                        /*~-2*/
                        else
                        {
                           /*~T*/
                           Communication_SendMessage(COMMUNICATION_RS232,COMMUNICATION_OK);
                        /*~-1*/
                        }
                        /*~E:I2275*/
                     /*~-1*/
                     }
                     /*~E:I2274*/
                     /*~-1*/
#endif
                     /*~E:I2273*/
                  /*~-1*/
                  }
                  /*~O:I2270*/
                  /*~-2*/
                  else
                  {
                     /*~I:2276*/
#ifdef CHANNEL_0
                     /*~T*/
                     Communication_SendMessage(COMMUNICATION_RS232,COMMUNICATION_OK);
                     /*~-1*/
#endif
                     /*~E:I2276*/
                     /*~I:2277*/
#ifdef CHANNEL_1
                     /*~I:2278*/
                     if (bDoNotWriteResult2Buffer)
                     /*~-1*/
                     {
                        /*~T*/
                        Communication_SendMessage(COMMUNICATION_RS232,COMMUNICATION_OK);
                     /*~-1*/
                     }
                     /*~E:I2278*/
                     /*~-1*/
#endif
                     /*~E:I2277*/
                  /*~-1*/
                  }
                  /*~E:I2270*/
               /*~-1*/
               }
               /*~O:I2269*/
               /*~-2*/
               else
               {
                  /*~I:2279*/
                  if (CommunicationControl.chLine2Interprete == COMMUNICATION_SPI)
                  /*~-1*/
                  {
                     /*~T*/
                     // Befehlsbest�tigung senden
                     Communication_SendSPICommand("OK");
                  /*~-1*/
                  }
                  /*~E:I2279*/
               /*~-1*/
               }
               /*~E:I2269*/
               /*~T*/
               break;
               /*~E:A2268*/
            /*~-1*/
            }
            /*~E:F2267*/
            /*~F:2280*/
            case INSTRUCTIONDECODER_SEND_E001:			// Kanal existiert nicht
            /*~-1*/
            {
               /*~A:2281*/
               /*~+:INSTRUCTIONDECODER_SEND_E001*/
               /*~I:2282*/
               if (CommunicationControl.chLine2Interprete == COMMUNICATION_RS232)
               /*~-1*/
               {
                  /*~I:2283*/
                  if (!SYSTEM_MRW_MANAGER)
                  /*~-1*/
                  {
                     /*~I:2284*/
                     if (lText2Send)
                     /*~-1*/
                     {
                        /*~I:2285*/
#ifdef CHANNEL_0
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~-1*/
#endif
                        /*~E:I2285*/
                        /*~I:2286*/
#ifdef CHANNEL_1
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~-1*/
#endif
                        /*~E:I2286*/
                        /*~T*/
                        break;
                     /*~-1*/
                     }
                     /*~E:I2284*/
                  /*~-1*/
                  }
                  /*~E:I2283*/
                  /*~I:2287*/
#ifdef CHANNEL_0
                  /*~T*/
                  Communication_SendString(COMMUNICATION_RS232,TEXT_E001,1,0);
                  /*~-1*/
#endif
                  /*~E:I2287*/
                  /*~I:2288*/
#ifdef CHANNEL_1
                  /*~I:2289*/
                  if (bDoNotWriteResult2Buffer)
                  /*~-1*/
                  {
                     /*~T*/
                     Communication_SendString(COMMUNICATION_RS232,TEXT_E001,1,0);
                  /*~-1*/
                  }
                  /*~E:I2289*/
                  /*~-1*/
#endif
                  /*~E:I2288*/
               /*~-1*/
               }
               /*~O:I2282*/
               /*~-2*/
               else
               {
                  /*~T*/
                  // NotAcknowledge senden
                  byRetVal = ADuC836_SPISendChar(NAK);
               /*~-1*/
               }
               /*~E:I2282*/
               /*~T*/
               break;
               /*~E:A2281*/
            /*~-1*/
            }
            /*~E:F2280*/
            /*~F:2290*/
            case INSTRUCTIONDECODER_SEND_E002:			// Fehler in Parameterlist
            /*~-1*/
            {
               /*~A:2291*/
               /*~+:INSTRUCTIONDECODER_SEND_E002*/
               /*~I:2292*/
               if (CommunicationControl.chLine2Interprete == COMMUNICATION_RS232)
               /*~-1*/
               {
                  /*~I:2293*/
                  if (!SYSTEM_MRW_MANAGER)
                  /*~-1*/
                  {
                     /*~I:2294*/
                     if (lText2Send)
                     /*~-1*/
                     {
                        /*~I:2295*/
#ifdef CHANNEL_0
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~-1*/
#endif
                        /*~E:I2295*/
                        /*~I:2296*/
#ifdef CHANNEL_1
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~-1*/
#endif
                        /*~E:I2296*/
                        /*~T*/
                        break;
                     /*~-1*/
                     }
                     /*~E:I2294*/
                  /*~-1*/
                  }
                  /*~E:I2293*/
                  /*~I:2297*/
#ifdef CHANNEL_0
                  /*~T*/
                  Communication_SendString(COMMUNICATION_RS232,TEXT_E002,1,0);
                  /*~-1*/
#endif
                  /*~E:I2297*/
                  /*~I:2298*/
#ifdef CHANNEL_1
                  /*~I:2299*/
                  if (bDoNotWriteResult2Buffer)
                  /*~-1*/
                  {
                     /*~T*/
                     Communication_SendString(COMMUNICATION_RS232,TEXT_E002,1,0);
                  /*~-1*/
                  }
                  /*~E:I2299*/
                  /*~-1*/
#endif
                  /*~E:I2298*/
               /*~-1*/
               }
               /*~O:I2292*/
               /*~-2*/
               else
               {
                  /*~T*/
                  // NotAcknowledge senden
                  byRetVal = ADuC836_SPISendChar(NAK);
               /*~-1*/
               }
               /*~E:I2292*/
               /*~T*/
               break;
               /*~E:A2291*/
            /*~-1*/
            }
            /*~E:F2290*/
            /*~F:2300*/
            case INSTRUCTIONDECODER_SEND_E003:			// ReadOnly-Fehler
            /*~-1*/
            {
               /*~A:2301*/
               /*~+:INSTRUCTIONDECODER_SEND_E003*/
               /*~I:2302*/
               if (CommunicationControl.chLine2Interprete == COMMUNICATION_RS232)
               /*~-1*/
               {
                  /*~I:2303*/
                  if (!SYSTEM_MRW_MANAGER)
                  /*~-1*/
                  {
                     /*~I:2304*/
                     if (lText2Send)
                     /*~-1*/
                     {
                        /*~I:2305*/
#ifdef CHANNEL_0
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~-1*/
#endif
                        /*~E:I2305*/
                        /*~I:2306*/
#ifdef CHANNEL_1
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~-1*/
#endif
                        /*~E:I2306*/
                        /*~T*/
                        break;
                     /*~-1*/
                     }
                     /*~E:I2304*/
                  /*~-1*/
                  }
                  /*~E:I2303*/
                  /*~I:2307*/
#ifdef CHANNEL_0
                  /*~T*/
                  Communication_SendString(COMMUNICATION_RS232,TEXT_E003,1,0);
                  /*~-1*/
#endif
                  /*~E:I2307*/
                  /*~I:2308*/
#ifdef CHANNEL_1
                  /*~I:2309*/
                  if (bDoNotWriteResult2Buffer)
                  /*~-1*/
                  {
                     /*~T*/
                     Communication_SendString(COMMUNICATION_RS232,TEXT_E003,1,0);
                  /*~-1*/
                  }
                  /*~E:I2309*/
                  /*~-1*/
#endif
                  /*~E:I2308*/
               /*~-1*/
               }
               /*~O:I2302*/
               /*~-2*/
               else
               {
                  /*~T*/
                  // NotAcknowledge senden
                  byRetVal = ADuC836_SPISendChar(NAK);
               /*~-1*/
               }
               /*~E:I2302*/
               /*~T*/
               break;
               /*~E:A2301*/
            /*~-1*/
            }
            /*~E:F2300*/
            /*~F:2310*/
            case INSTRUCTIONDECODER_SEND_E004:			// Kommando konnte nicht interpretiert werden
            /*~-1*/
            {
               /*~A:2311*/
               /*~+:INSTRUCTIONDECODER_SEND_E004*/
               /*~I:2312*/
               if (CommunicationControl.chLine2Interprete == COMMUNICATION_RS232)
               /*~-1*/
               {
                  /*~I:2313*/
                  if (!SYSTEM_MRW_MANAGER)
                  /*~-1*/
                  {
                     /*~I:2314*/
                     if (lText2Send)
                     /*~-1*/
                     {
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~T*/
                        break;
                     /*~-1*/
                     }
                     /*~E:I2314*/
                  /*~-1*/
                  }
                  /*~E:I2313*/
                  /*~I:2315*/
#ifdef CHANNEL_0
                  /*~T*/
                  Communication_SendString(COMMUNICATION_RS232,TEXT_E004,1,0);
                  /*~-1*/
#endif
                  /*~E:I2315*/
               /*~-1*/
               }
               /*~O:I2312*/
               /*~-2*/
               else
               {
                  /*~T*/
                  // NotAcknowledge senden
                  byRetVal = ADuC836_SPISendChar(NAK);
               /*~-1*/
               }
               /*~E:I2312*/
               /*~T*/
               break;
               /*~E:A2311*/
            /*~-1*/
            }
            /*~E:F2310*/
            /*~F:2316*/
            case INSTRUCTIONDECODER_SEND_E005:			// Kommunikationsfehler mit dem Partner
            /*~-1*/
            {
               /*~A:2317*/
               /*~+:INSTRUCTIONDECODER_SEND_E005*/
               /*~I:2318*/
               if (CommunicationControl.chLine2Interprete == COMMUNICATION_RS232)
               /*~-1*/
               {
                  /*~I:2319*/
                  if (!SYSTEM_MRW_MANAGER)
                  /*~-1*/
                  {
                     /*~I:2320*/
                     if (lText2Send)
                     /*~-1*/
                     {
                        /*~I:2321*/
#ifdef CHANNEL_0
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~-1*/
#endif
                        /*~E:I2321*/
                        /*~I:2322*/
#ifdef CHANNEL_1
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~-1*/
#endif
                        /*~E:I2322*/
                        /*~T*/
                        break;
                     /*~-1*/
                     }
                     /*~E:I2320*/
                  /*~-1*/
                  }
                  /*~E:I2319*/
                  /*~I:2323*/
#ifdef CHANNEL_0
                  /*~T*/
                  Communication_SendString(COMMUNICATION_RS232,TEXT_E005,1,0);
                  /*~-1*/
#endif
                  /*~E:I2323*/
                  /*~I:2324*/
#ifdef CHANNEL_1
                  /*~I:2325*/
                  if (bDoNotWriteResult2Buffer)
                  /*~-1*/
                  {
                     /*~T*/
                     Communication_SendString(COMMUNICATION_RS232,TEXT_E005,1,0);
                  /*~-1*/
                  }
                  /*~E:I2325*/
                  /*~-1*/
#endif
                  /*~E:I2324*/
               /*~-1*/
               }
               /*~O:I2318*/
               /*~-2*/
               else
               {
                  /*~T*/
                  // NotAcknowledge senden
                  byRetVal = ADuC836_SPISendChar(NAK);
               /*~-1*/
               }
               /*~E:I2318*/
               /*~T*/
               break;
               /*~E:A2317*/
            /*~-1*/
            }
            /*~E:F2316*/
            /*~F:2326*/
            case INSTRUCTIONDECODER_SEND_E006:			// Kommando noch nicht implementiert
            /*~-1*/
            {
               /*~A:2327*/
               /*~+:INSTRUCTIONDECODER_SEND_E006*/
               /*~I:2328*/
               if (CommunicationControl.chLine2Interprete == COMMUNICATION_RS232)
               /*~-1*/
               {
                  /*~I:2329*/
                  if (!SYSTEM_MRW_MANAGER)
                  /*~-1*/
                  {
                     /*~I:2330*/
                     if (lText2Send)
                     /*~-1*/
                     {
                        /*~I:2331*/
#ifdef CHANNEL_0
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~-1*/
#endif
                        /*~E:I2331*/
                        /*~I:2332*/
#ifdef CHANNEL_1
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~-1*/
#endif
                        /*~E:I2332*/
                        /*~T*/
                        break;
                     /*~-1*/
                     }
                     /*~E:I2330*/
                  /*~-1*/
                  }
                  /*~E:I2329*/
                  /*~I:2333*/
#ifdef CHANNEL_0
                  /*~T*/
                  Communication_SendString(COMMUNICATION_RS232,TEXT_E006,1,0);
                  /*~-1*/
#endif
                  /*~E:I2333*/
                  /*~I:2334*/
#ifdef CHANNEL_1
                  /*~I:2335*/
                  if (bDoNotWriteResult2Buffer)
                  /*~-1*/
                  {
                     /*~T*/
                     Communication_SendString(COMMUNICATION_RS232,TEXT_E006,1,0);
                  /*~-1*/
                  }
                  /*~E:I2335*/
                  /*~-1*/
#endif
                  /*~E:I2334*/
               /*~-1*/
               }
               /*~O:I2328*/
               /*~-2*/
               else
               {
                  /*~T*/
                  // NotAcknowledge senden
                  byRetVal = ADuC836_SPISendChar(NAK);
               /*~-1*/
               }
               /*~E:I2328*/
               /*~T*/
               break;
               /*~E:A2327*/
            /*~-1*/
            }
            /*~E:F2326*/
            /*~F:2336*/
            case INSTRUCTIONDECODER_SEND_E007:			// Parameter fehlt 
            /*~-1*/
            {
               /*~A:2337*/
               /*~+:INSTRUCTIONDECODER_SEND_E007*/
               /*~I:2338*/
               if (CommunicationControl.chLine2Interprete == COMMUNICATION_RS232)
               /*~-1*/
               {
                  /*~I:2339*/
                  if (!SYSTEM_MRW_MANAGER)
                  /*~-1*/
                  {
                     /*~I:2340*/
                     if (lText2Send)
                     /*~-1*/
                     {
                        /*~I:2341*/
#ifdef CHANNEL_0
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~-1*/
#endif
                        /*~E:I2341*/
                        /*~I:2342*/
#ifdef CHANNEL_1
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~-1*/
#endif
                        /*~E:I2342*/
                        /*~T*/
                        break;
                     /*~-1*/
                     }
                     /*~E:I2340*/
                  /*~-1*/
                  }
                  /*~E:I2339*/
                  /*~I:2343*/
#ifdef CHANNEL_0
                  /*~T*/
                  Communication_SendString(COMMUNICATION_RS232,TEXT_E007,1,0);
                  /*~-1*/
#endif
                  /*~E:I2343*/
                  /*~I:2344*/
#ifdef CHANNEL_1
                  /*~I:2345*/
                  if (bDoNotWriteResult2Buffer)
                  /*~-1*/
                  {
                     /*~T*/
                     Communication_SendString(COMMUNICATION_RS232,TEXT_E007,1,0);
                  /*~-1*/
                  }
                  /*~E:I2345*/
                  /*~-1*/
#endif
                  /*~E:I2344*/
               /*~-1*/
               }
               /*~O:I2338*/
               /*~-2*/
               else
               {
                  /*~T*/
                  // NotAcknowledge senden
                  byRetVal = ADuC836_SPISendChar(NAK);
               /*~-1*/
               }
               /*~E:I2338*/
               /*~T*/
               break;
               /*~E:A2337*/
            /*~-1*/
            }
            /*~E:F2336*/
            /*~F:2346*/
            case INSTRUCTIONDECODER_SEND_E008:			// Unerwartetes Zeichen im Kommandostring 
            /*~-1*/
            {
               /*~A:2347*/
               /*~+:INSTRUCTIONDECODER_SEND_E008*/
               /*~I:2348*/
               if (CommunicationControl.chLine2Interprete == COMMUNICATION_RS232)
               /*~-1*/
               {
                  /*~I:2349*/
                  if (!SYSTEM_MRW_MANAGER)
                  /*~-1*/
                  {
                     /*~I:2350*/
                     if (lText2Send)
                     /*~-1*/
                     {
                        /*~I:2351*/
#ifdef CHANNEL_0
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~-1*/
#endif
                        /*~E:I2351*/
                        /*~I:2352*/
#ifdef CHANNEL_1
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~-1*/
#endif
                        /*~E:I2352*/
                        /*~T*/
                        break;
                     /*~-1*/
                     }
                     /*~E:I2350*/
                  /*~-1*/
                  }
                  /*~E:I2349*/
                  /*~I:2353*/
#ifdef CHANNEL_0
                  /*~T*/
                  Communication_SendString(COMMUNICATION_RS232,TEXT_E008,1,0);
                  /*~-1*/
#endif
                  /*~E:I2353*/
                  /*~I:2354*/
#ifdef CHANNEL_1
                  /*~I:2355*/
                  if (bDoNotWriteResult2Buffer)
                  /*~-1*/
                  {
                     /*~T*/
                     Communication_SendString(COMMUNICATION_RS232,TEXT_E008,1,0);
                  /*~-1*/
                  }
                  /*~E:I2355*/
                  /*~-1*/
#endif
                  /*~E:I2354*/
               /*~-1*/
               }
               /*~O:I2348*/
               /*~-2*/
               else
               {
                  /*~T*/
                  // NotAcknowledge senden
                  byRetVal = ADuC836_SPISendChar(NAK);
               /*~-1*/
               }
               /*~E:I2348*/
               /*~T*/
               break;
               /*~E:A2347*/
            /*~-1*/
            }
            /*~E:F2346*/
            /*~F:2356*/
            case INSTRUCTIONDECODER_SEND_E009:			// Wert au�erhalb des Grenzwertes

            /*~-1*/
            {
               /*~A:2357*/
               /*~+:INSTRUCTIONDECODER_SEND_E009*/
               /*~I:2358*/
               if (CommunicationControl.chLine2Interprete == COMMUNICATION_RS232)
               /*~-1*/
               {
                  /*~I:2359*/
                  if (!SYSTEM_MRW_MANAGER)
                  /*~-1*/
                  {
                     /*~I:2360*/
                     if (lText2Send)
                     /*~-1*/
                     {
                        /*~I:2361*/
#ifdef CHANNEL_0
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~-1*/
#endif
                        /*~E:I2361*/
                        /*~I:2362*/
#ifdef CHANNEL_1
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~-1*/
#endif
                        /*~E:I2362*/
                        /*~T*/
                        break;
                     /*~-1*/
                     }
                     /*~E:I2360*/
                  /*~-1*/
                  }
                  /*~E:I2359*/
                  /*~I:2363*/
#ifdef CHANNEL_0
                  /*~T*/
                  Communication_SendString(COMMUNICATION_RS232,TEXT_E009,1,0);
                  /*~-1*/
#endif
                  /*~E:I2363*/
                  /*~I:2364*/
#ifdef CHANNEL_1
                  /*~I:2365*/
                  if (bDoNotWriteResult2Buffer)
                  /*~-1*/
                  {
                     /*~T*/
                     Communication_SendString(COMMUNICATION_RS232,TEXT_E009,1,0);
                  /*~-1*/
                  }
                  /*~E:I2365*/
                  /*~-1*/
#endif
                  /*~E:I2364*/
               /*~-1*/
               }
               /*~O:I2358*/
               /*~-2*/
               else
               {
                  /*~T*/
                  // NotAcknowledge senden
                  byRetVal = ADuC836_SPISendChar(NAK);
               /*~-1*/
               }
               /*~E:I2358*/
               /*~T*/
               break;
               /*~E:A2357*/
            /*~-1*/
            }
            /*~E:F2356*/
            /*~F:2366*/
            case INSTRUCTIONDECODER_SEND_E010:			// Drifterkennung l�uft (nur SLC)

            /*~-1*/
            {
               /*~A:2367*/
               /*~+:INSTRUCTIONDECODER_SEND_E010*/
               /*~I:2368*/
               if (CommunicationControl.chLine2Interprete == COMMUNICATION_RS232)
               /*~-1*/
               {
                  /*~I:2369*/
                  if (!SYSTEM_MRW_MANAGER)
                  /*~-1*/
                  {
                     /*~I:2370*/
                     if (lText2Send)
                     /*~-1*/
                     {
                        /*~I:2371*/
#ifdef CHANNEL_0
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~-1*/
#endif
                        /*~E:I2371*/
                        /*~I:2372*/
#ifdef CHANNEL_1
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~-1*/
#endif
                        /*~E:I2372*/
                        /*~T*/
                        break;
                     /*~-1*/
                     }
                     /*~E:I2370*/
                     /*~I:2373*/
#ifdef CHANNEL_0
                     /*~T*/
                     Communication_SendString(COMMUNICATION_RS232,TEXT_E010,1,0);
                     /*~-1*/
#endif
                     /*~E:I2373*/
                     /*~I:2374*/
#ifdef CHANNEL_1 
                     /*~I:2375*/
                     if (bDoNotWriteResult2Buffer)
                     /*~-1*/
                     {
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,TEXT_E010,1,0);
                     /*~-1*/
                     }
                     /*~E:I2375*/
                     /*~-1*/
#endif
                     /*~E:I2374*/
                  /*~-1*/
                  }
                  /*~E:I2369*/
               /*~-1*/
               }
               /*~O:I2368*/
               /*~-2*/
               else
               {
                  /*~T*/
                  // NotAcknowledge senden
                  byRetVal = ADuC836_SPISendChar(NAK);
               /*~-1*/
               }
               /*~E:I2368*/
               /*~T*/
               break;
               /*~E:A2367*/
            /*~-1*/
            }
            /*~E:F2366*/
            /*~F:2376*/
            case INSTRUCTIONDECODER_SEND_E011:			// Parameter der Partner sind unterschiedlich 
            /*~-1*/
            {
               /*~A:2377*/
               /*~+:INSTRUCTIONDECODER_SEND_E011*/
               /*~I:2378*/
               if (CommunicationControl.chLine2Interprete == COMMUNICATION_RS232)
               /*~-1*/
               {
                  /*~I:2379*/
                  if (!SYSTEM_MRW_MANAGER)
                  /*~-1*/
                  {
                     /*~I:2380*/
                     if (lText2Send)
                     /*~-1*/
                     {
                        /*~I:2381*/
#ifdef CHANNEL_0
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~-1*/
#endif
                        /*~E:I2381*/
                        /*~I:2382*/
#ifdef CHANNEL_1
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~-1*/
#endif
                        /*~E:I2382*/
                        /*~T*/
                        break;
                     /*~-1*/
                     }
                     /*~E:I2380*/
                  /*~-1*/
                  }
                  /*~E:I2379*/
                  /*~I:2383*/
#ifdef CHANNEL_0
                  /*~T*/
                  Communication_SendString(COMMUNICATION_RS232,TEXT_E011,1,0);
                  /*~-1*/
#endif
                  /*~E:I2383*/
                  /*~I:2384*/
#ifdef CHANNEL_1 
                  /*~I:2385*/
                  if (bDoNotWriteResult2Buffer)
                  /*~-1*/
                  {
                     /*~T*/
                     Communication_SendString(COMMUNICATION_RS232,TEXT_E011,1,0);
                  /*~-1*/
                  }
                  /*~E:I2385*/
                  /*~-1*/
#endif
                  /*~E:I2384*/
               /*~-1*/
               }
               /*~O:I2378*/
               /*~-2*/
               else
               {
                  /*~T*/
                  // NotAcknowledge senden
                  byRetVal = ADuC836_SPISendChar(NAK);
               /*~-1*/
               }
               /*~E:I2378*/
               /*~T*/
               break;
               /*~E:A2377*/
            /*~-1*/
            }
            /*~E:F2376*/
            /*~F:2386*/
            case INSTRUCTIONDECODER_SEND_E012:			// Checksummenfehler
            /*~-1*/
            {
               /*~A:2387*/
               /*~+:INSTRUCTIONDECODER_SEND_E012*/
               /*~I:2388*/
               if (CommunicationControl.chLine2Interprete == COMMUNICATION_RS232)
               /*~-1*/
               {
                  /*~I:2389*/
                  if (!SYSTEM_MRW_MANAGER)
                  /*~-1*/
                  {
                     /*~I:2390*/
                     if (lText2Send)
                     /*~-1*/
                     {
                        /*~I:2391*/
#ifdef CHANNEL_0
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~-1*/
#endif
                        /*~E:I2391*/
                        /*~I:2392*/
#ifdef CHANNEL_1
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~-1*/
#endif
                        /*~E:I2392*/
                        /*~T*/
                        break;
                     /*~-1*/
                     }
                     /*~E:I2390*/
                  /*~-1*/
                  }
                  /*~E:I2389*/
                  /*~T*/
                  Communication_SendString(COMMUNICATION_RS232,TEXT_E012,1,0);
               /*~-1*/
               }
               /*~O:I2388*/
               /*~-2*/
               else
               {
                  /*~T*/
                  // NotAcknowledge senden
                  byRetVal = ADuC836_SPISendChar(NAK);
               /*~-1*/
               }
               /*~E:I2388*/
               /*~T*/
               break;
               /*~E:A2387*/
            /*~-1*/
            }
            /*~E:F2386*/
            /*~F:2393*/
            case INSTRUCTIONDECODER_SEND_NOK:			// NOK senden
            /*~-1*/
            {
               /*~A:2394*/
               /*~+:INSTRUCTIONDECODER_SEND_NOK*/
               /*~I:2395*/
               if (CommunicationControl.chLine2Interprete == COMMUNICATION_RS232)
               /*~-1*/
               {
                  /*~I:2396*/
                  if (!SYSTEM_MRW_MANAGER)
                  /*~-1*/
                  {
                     /*~I:2397*/
                     if (lText2Send)
                     /*~-1*/
                     {
                        /*~A:2398*/
                        /*~+:RS232-Ausgabe*/
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~E:A2398*/
                        /*~T*/
                        break;
                     /*~-1*/
                     }
                     /*~E:I2397*/
                  /*~-1*/
                  }
                  /*~E:I2396*/
                  /*~A:2399*/
                  /*~+:RS232-Ausgabe*/
                  /*~T*/
                  Communication_SendMessage(COMMUNICATION_RS232,COMMUNICATION_NOK);
                  /*~E:A2399*/
               /*~-1*/
               }
               /*~E:I2395*/
               /*~T*/
               break;
               /*~E:A2394*/
            /*~-1*/
            }
            /*~E:F2393*/
            /*~F:2400*/
            case INSTRUCTIONDECODER_SEND_NOTHING:
            /*~-1*/
            {
               /*~T*/
               break;
            /*~-1*/
            }
            /*~E:F2400*/
         /*~-1*/
         }
         /*~E:C2266*/
         /*~I:2401*/
#ifdef CHANNEL_1
         /*~I:2402*/
         if (!bDoNotWriteResult2Buffer)
         /*~-1*/
         {
            /*~T*/
            bDoNotWriteResult2Buffer = 1;

            g_byLastCommandExecutionResult = byCommandStatus;
         /*~-1*/
         }
         /*~E:I2402*/
         /*~-1*/
#endif
         /*~E:I2401*/
         /*~E:A2265*/
         /*~-1*/
#endif
         /*~E:I2262*/
         /*~A:2403*/
         /*~+:Eintrag in Diagnosespeicher vornehmen*/
         /*~I:2404*/
#ifdef CHANNEL_0
         /*~A:2405*/
         /*~+:Kanal 0*/
         /*~I:2406*/
         if (ulDiagnosisEntry2Set)
         /*~-1*/
         {
            /*~T*/
            Diagnosis_WriteMessage2Flash(ulDiagnosisEntry2Set);
         /*~-1*/
         }
         /*~E:I2406*/
         /*~E:A2405*/
         /*~-1*/
#endif
         /*~E:I2404*/
         /*~I:2407*/
#ifdef CHANNEL_1
         /*~A:2408*/
         /*~+:Kanal 1*/
         /*~I:2409*/
         if (ulDiagnosisEntry2Set)
         /*~-1*/
         {
            /*~I:2410*/
            if (bDoNotWriteResult2Buffer)
            /*~-1*/
            {
               /*~T*/
               Diagnosis_WriteMessage2Flash(ulDiagnosisEntry2Set);
            /*~-1*/
            }
            /*~O:I2410*/
            /*~-2*/
            else
            {
               /*~T*/
               ulDiagnosisEntry2SetAtiGRS = ulDiagnosisEntry2Set;
            /*~-1*/
            }
            /*~E:I2410*/
         /*~-1*/
         }
         /*~E:I2409*/
         /*~E:A2408*/
         /*~-1*/
#endif
         /*~E:I2407*/
         /*~E:A2403*/
         /*~A:2411*/
         /*~+:Kommandostatus auswerten*/
         /*~C:2412*/
         switch (byCommandStatus)
         /*~-1*/
         {
            /*~F:2413*/
            case INSTRUCTIONDECODER_SEND_OK:	// Kommando wurde ordnungsgem�� interpretiert
            //case INSTRUCTIONDECODER_SEND_TEXT	// Beide Bedingungen identisch
            /*~-1*/
            {
               /*~A:2414*/
               /*~+:INSTRUCTIONDECODER_SEND_OK*/
               /*~I:2415*/
               if (CommunicationControl.chLine2Interprete == COMMUNICATION_RS232)
               /*~-1*/
               {
                  /*~I:2416*/
                  if (!SYSTEM_MRW_MANAGER)
                  /*~-1*/
                  {
                     /*~I:2417*/
#ifdef CHANNEL_0
                     /*~I:2418*/
                     if (lText2Send)
                     /*~-1*/
                     {
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                     /*~-1*/
                     }
                     /*~E:I2418*/
                     /*~-1*/
#endif
                     /*~E:I2417*/
                     /*~I:2419*/
#ifdef CHANNEL_1
                     /*~I:2420*/
                     if (bDoNotWriteResult2Buffer)
                     /*~-1*/
                     {
                        /*~I:2421*/
                        if (lText2Send)
                        /*~-1*/
                        {
                           /*~T*/
                           sprintf(szString2Send,"T%04ld",lText2Send);
                           /*~T*/
                           Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~-1*/
                        }
                        /*~O:I2421*/
                        /*~-2*/
                        else
                        {
                           /*~T*/
                           Communication_SendMessage(COMMUNICATION_RS232,COMMUNICATION_OK);
                        /*~-1*/
                        }
                        /*~E:I2421*/
                     /*~-1*/
                     }
                     /*~E:I2420*/
                     /*~-1*/
#endif
                     /*~E:I2419*/
                  /*~-1*/
                  }
                  /*~O:I2416*/
                  /*~-2*/
                  else
                  {
                     /*~I:2422*/
#ifdef CHANNEL_0
                     /*~T*/
                     Communication_SendMessage(COMMUNICATION_RS232,COMMUNICATION_OK);
                     /*~-1*/
#endif
                     /*~E:I2422*/
                     /*~I:2423*/
#ifdef CHANNEL_1
                     /*~I:2424*/
                     if (bDoNotWriteResult2Buffer)
                     /*~-1*/
                     {
                        /*~T*/
                        Communication_SendMessage(COMMUNICATION_RS232,COMMUNICATION_OK);
                     /*~-1*/
                     }
                     /*~E:I2424*/
                     /*~-1*/
#endif
                     /*~E:I2423*/
                  /*~-1*/
                  }
                  /*~E:I2416*/
                  /*~K*/
                  /*~+:/~* Hinzugef�gt am 09.02.2022 *~/*/
                  /*~I:2425*/
#ifdef CHANNEL_0 
                  /*~I:2426*/
                  if (lText2Send == TEXT_RETAIN_VARIABLES_REORGANIZED)
                  /*~-1*/
                  {
                     /*~T*/
                     // Reset nach der Reorganisation der Retain-Variablen ausf�hren
                     /*~I:2427*/
#ifndef DEVELOPMENT_SW	/* Nur definiert in der Debug-Version */ 
                     /*~T*/
                     System_Reset();
                     /*~-1*/
#endif
                     /*~E:I2427*/
                  /*~-1*/
                  }
                  /*~E:I2426*/
                  /*~-1*/
#endif
                  /*~E:I2425*/
                  /*~K*/
                  /*~+:/~* Ende - Hinzugef�gt am 09.02.2022 *~/*/
               /*~-1*/
               }
               /*~O:I2415*/
               /*~-2*/
               else
               {
                  /*~I:2428*/
                  if (CommunicationControl.chLine2Interprete == COMMUNICATION_SPI)
                  /*~-1*/
                  {
                     /*~T*/
                     // Befehlsbest�tigung senden
                     Communication_SendSPICommand("OK");
                  /*~-1*/
                  }
                  /*~E:I2428*/
               /*~-1*/
               }
               /*~E:I2415*/
               /*~T*/
               break;
               /*~E:A2414*/
            /*~-1*/
            }
            /*~E:F2413*/
            /*~F:2429*/
            case INSTRUCTIONDECODER_SEND_E001:			// Kanal existiert nicht
            /*~-1*/
            {
               /*~A:2430*/
               /*~+:INSTRUCTIONDECODER_SEND_E001*/
               /*~I:2431*/
               if (CommunicationControl.chLine2Interprete == COMMUNICATION_RS232)
               /*~-1*/
               {
                  /*~I:2432*/
                  if (!SYSTEM_MRW_MANAGER)
                  /*~-1*/
                  {
                     /*~I:2433*/
                     if (lText2Send)
                     /*~-1*/
                     {
                        /*~I:2434*/
#ifdef CHANNEL_0
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~-1*/
#endif
                        /*~E:I2434*/
                        /*~I:2435*/
#ifdef CHANNEL_1
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~-1*/
#endif
                        /*~E:I2435*/
                        /*~T*/
                        break;
                     /*~-1*/
                     }
                     /*~E:I2433*/
                  /*~-1*/
                  }
                  /*~E:I2432*/
                  /*~I:2436*/
#ifdef CHANNEL_0
                  /*~T*/
                  Communication_SendString(COMMUNICATION_RS232,TEXT_E001,1,0);
                  /*~-1*/
#endif
                  /*~E:I2436*/
                  /*~I:2437*/
#ifdef CHANNEL_1
                  /*~I:2438*/
                  if (bDoNotWriteResult2Buffer)
                  /*~-1*/
                  {
                     /*~T*/
                     Communication_SendString(COMMUNICATION_RS232,TEXT_E001,1,0);
                  /*~-1*/
                  }
                  /*~E:I2438*/
                  /*~-1*/
#endif
                  /*~E:I2437*/
               /*~-1*/
               }
               /*~O:I2431*/
               /*~-2*/
               else
               {
                  /*~T*/
                  // NotAcknowledge senden
                  byRetVal = ADuC836_SPISendChar(NAK);
               /*~-1*/
               }
               /*~E:I2431*/
               /*~T*/
               break;
               /*~E:A2430*/
            /*~-1*/
            }
            /*~E:F2429*/
            /*~F:2439*/
            case INSTRUCTIONDECODER_SEND_E002:			// Fehler in Parameterlist
            /*~-1*/
            {
               /*~A:2440*/
               /*~+:INSTRUCTIONDECODER_SEND_E002*/
               /*~I:2441*/
               if (CommunicationControl.chLine2Interprete == COMMUNICATION_RS232)
               /*~-1*/
               {
                  /*~I:2442*/
                  if (!SYSTEM_MRW_MANAGER)
                  /*~-1*/
                  {
                     /*~I:2443*/
                     if (lText2Send)
                     /*~-1*/
                     {
                        /*~I:2444*/
#ifdef CHANNEL_0
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~-1*/
#endif
                        /*~E:I2444*/
                        /*~I:2445*/
#ifdef CHANNEL_1
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~-1*/
#endif
                        /*~E:I2445*/
                        /*~T*/
                        break;
                     /*~-1*/
                     }
                     /*~E:I2443*/
                  /*~-1*/
                  }
                  /*~E:I2442*/
                  /*~I:2446*/
#ifdef CHANNEL_0
                  /*~T*/
                  Communication_SendString(COMMUNICATION_RS232,TEXT_E002,1,0);
                  /*~-1*/
#endif
                  /*~E:I2446*/
                  /*~I:2447*/
#ifdef CHANNEL_1
                  /*~I:2448*/
                  if (bDoNotWriteResult2Buffer)
                  /*~-1*/
                  {
                     /*~T*/
                     Communication_SendString(COMMUNICATION_RS232,TEXT_E002,1,0);
                  /*~-1*/
                  }
                  /*~E:I2448*/
                  /*~-1*/
#endif
                  /*~E:I2447*/
               /*~-1*/
               }
               /*~O:I2441*/
               /*~-2*/
               else
               {
                  /*~T*/
                  // NotAcknowledge senden
                  byRetVal = ADuC836_SPISendChar(NAK);
               /*~-1*/
               }
               /*~E:I2441*/
               /*~T*/
               break;
               /*~E:A2440*/
            /*~-1*/
            }
            /*~E:F2439*/
            /*~F:2449*/
            case INSTRUCTIONDECODER_SEND_E003:			// ReadOnly-Fehler
            /*~-1*/
            {
               /*~A:2450*/
               /*~+:INSTRUCTIONDECODER_SEND_E003*/
               /*~I:2451*/
               if (CommunicationControl.chLine2Interprete == COMMUNICATION_RS232)
               /*~-1*/
               {
                  /*~I:2452*/
                  if (!SYSTEM_MRW_MANAGER)
                  /*~-1*/
                  {
                     /*~I:2453*/
                     if (lText2Send)
                     /*~-1*/
                     {
                        /*~I:2454*/
#ifdef CHANNEL_0
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~-1*/
#endif
                        /*~E:I2454*/
                        /*~I:2455*/
#ifdef CHANNEL_1
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~-1*/
#endif
                        /*~E:I2455*/
                        /*~T*/
                        break;
                     /*~-1*/
                     }
                     /*~E:I2453*/
                  /*~-1*/
                  }
                  /*~E:I2452*/
                  /*~I:2456*/
#ifdef CHANNEL_0
                  /*~T*/
                  Communication_SendString(COMMUNICATION_RS232,TEXT_E003,1,0);
                  /*~-1*/
#endif
                  /*~E:I2456*/
                  /*~I:2457*/
#ifdef CHANNEL_1
                  /*~I:2458*/
                  if (bDoNotWriteResult2Buffer)
                  /*~-1*/
                  {
                     /*~T*/
                     Communication_SendString(COMMUNICATION_RS232,TEXT_E003,1,0);
                  /*~-1*/
                  }
                  /*~E:I2458*/
                  /*~-1*/
#endif
                  /*~E:I2457*/
               /*~-1*/
               }
               /*~O:I2451*/
               /*~-2*/
               else
               {
                  /*~T*/
                  // NotAcknowledge senden
                  byRetVal = ADuC836_SPISendChar(NAK);
               /*~-1*/
               }
               /*~E:I2451*/
               /*~T*/
               break;
               /*~E:A2450*/
            /*~-1*/
            }
            /*~E:F2449*/
            /*~F:2459*/
            case INSTRUCTIONDECODER_SEND_E004:			// Kommando konnte nicht interpretiert werden
            /*~-1*/
            {
               /*~A:2460*/
               /*~+:INSTRUCTIONDECODER_SEND_E004*/
               /*~I:2461*/
               if (CommunicationControl.chLine2Interprete == COMMUNICATION_RS232)
               /*~-1*/
               {
                  /*~I:2462*/
                  if (!SYSTEM_MRW_MANAGER)
                  /*~-1*/
                  {
                     /*~I:2463*/
                     if (lText2Send)
                     /*~-1*/
                     {
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~T*/
                        break;
                     /*~-1*/
                     }
                     /*~E:I2463*/
                  /*~-1*/
                  }
                  /*~E:I2462*/
                  /*~I:2464*/
#ifdef CHANNEL_0
                  /*~T*/
                  Communication_SendString(COMMUNICATION_RS232,TEXT_E004,1,0);
                  /*~-1*/
#endif
                  /*~E:I2464*/
               /*~-1*/
               }
               /*~O:I2461*/
               /*~-2*/
               else
               {
                  /*~T*/
                  // NotAcknowledge senden
                  byRetVal = ADuC836_SPISendChar(NAK);
               /*~-1*/
               }
               /*~E:I2461*/
               /*~T*/
               break;
               /*~E:A2460*/
            /*~-1*/
            }
            /*~E:F2459*/
            /*~F:2465*/
            case INSTRUCTIONDECODER_SEND_E005:			// Kommunikationsfehler mit dem Partner
            /*~-1*/
            {
               /*~A:2466*/
               /*~+:INSTRUCTIONDECODER_SEND_E005*/
               /*~I:2467*/
               if (CommunicationControl.chLine2Interprete == COMMUNICATION_RS232)
               /*~-1*/
               {
                  /*~I:2468*/
                  if (!SYSTEM_MRW_MANAGER)
                  /*~-1*/
                  {
                     /*~I:2469*/
                     if (lText2Send)
                     /*~-1*/
                     {
                        /*~I:2470*/
#ifdef CHANNEL_0
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~-1*/
#endif
                        /*~E:I2470*/
                        /*~I:2471*/
#ifdef CHANNEL_1
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~-1*/
#endif
                        /*~E:I2471*/
                        /*~T*/
                        break;
                     /*~-1*/
                     }
                     /*~E:I2469*/
                  /*~-1*/
                  }
                  /*~E:I2468*/
                  /*~I:2472*/
#ifdef CHANNEL_0
                  /*~T*/
                  Communication_SendString(COMMUNICATION_RS232,TEXT_E005,1,0);
                  /*~-1*/
#endif
                  /*~E:I2472*/
                  /*~I:2473*/
#ifdef CHANNEL_1
                  /*~I:2474*/
                  if (bDoNotWriteResult2Buffer)
                  /*~-1*/
                  {
                     /*~T*/
                     Communication_SendString(COMMUNICATION_RS232,TEXT_E005,1,0);
                  /*~-1*/
                  }
                  /*~E:I2474*/
                  /*~-1*/
#endif
                  /*~E:I2473*/
               /*~-1*/
               }
               /*~O:I2467*/
               /*~-2*/
               else
               {
                  /*~T*/
                  // NotAcknowledge senden
                  byRetVal = ADuC836_SPISendChar(NAK);
               /*~-1*/
               }
               /*~E:I2467*/
               /*~T*/
               break;
               /*~E:A2466*/
            /*~-1*/
            }
            /*~E:F2465*/
            /*~F:2475*/
            case INSTRUCTIONDECODER_SEND_E006:			// Kommando noch nicht implementiert
            /*~-1*/
            {
               /*~A:2476*/
               /*~+:INSTRUCTIONDECODER_SEND_E006*/
               /*~I:2477*/
               if (CommunicationControl.chLine2Interprete == COMMUNICATION_RS232)
               /*~-1*/
               {
                  /*~I:2478*/
                  if (!SYSTEM_MRW_MANAGER)
                  /*~-1*/
                  {
                     /*~I:2479*/
                     if (lText2Send)
                     /*~-1*/
                     {
                        /*~I:2480*/
#ifdef CHANNEL_0
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~-1*/
#endif
                        /*~E:I2480*/
                        /*~I:2481*/
#ifdef CHANNEL_1
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~-1*/
#endif
                        /*~E:I2481*/
                        /*~T*/
                        break;
                     /*~-1*/
                     }
                     /*~E:I2479*/
                  /*~-1*/
                  }
                  /*~E:I2478*/
                  /*~I:2482*/
#ifdef CHANNEL_0
                  /*~T*/
                  Communication_SendString(COMMUNICATION_RS232,TEXT_E006,1,0);
                  /*~-1*/
#endif
                  /*~E:I2482*/
                  /*~I:2483*/
#ifdef CHANNEL_1
                  /*~I:2484*/
                  if (bDoNotWriteResult2Buffer)
                  /*~-1*/
                  {
                     /*~T*/
                     Communication_SendString(COMMUNICATION_RS232,TEXT_E006,1,0);
                  /*~-1*/
                  }
                  /*~E:I2484*/
                  /*~-1*/
#endif
                  /*~E:I2483*/
               /*~-1*/
               }
               /*~O:I2477*/
               /*~-2*/
               else
               {
                  /*~T*/
                  // NotAcknowledge senden
                  byRetVal = ADuC836_SPISendChar(NAK);
               /*~-1*/
               }
               /*~E:I2477*/
               /*~T*/
               break;
               /*~E:A2476*/
            /*~-1*/
            }
            /*~E:F2475*/
            /*~F:2485*/
            case INSTRUCTIONDECODER_SEND_E007:			// Parameter fehlt 
            /*~-1*/
            {
               /*~A:2486*/
               /*~+:INSTRUCTIONDECODER_SEND_E007*/
               /*~I:2487*/
               if (CommunicationControl.chLine2Interprete == COMMUNICATION_RS232)
               /*~-1*/
               {
                  /*~I:2488*/
                  if (!SYSTEM_MRW_MANAGER)
                  /*~-1*/
                  {
                     /*~I:2489*/
                     if (lText2Send)
                     /*~-1*/
                     {
                        /*~I:2490*/
#ifdef CHANNEL_0
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~-1*/
#endif
                        /*~E:I2490*/
                        /*~I:2491*/
#ifdef CHANNEL_1
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~-1*/
#endif
                        /*~E:I2491*/
                        /*~T*/
                        break;
                     /*~-1*/
                     }
                     /*~E:I2489*/
                  /*~-1*/
                  }
                  /*~E:I2488*/
                  /*~I:2492*/
#ifdef CHANNEL_0
                  /*~T*/
                  Communication_SendString(COMMUNICATION_RS232,TEXT_E007,1,0);
                  /*~-1*/
#endif
                  /*~E:I2492*/
                  /*~I:2493*/
#ifdef CHANNEL_1
                  /*~I:2494*/
                  if (bDoNotWriteResult2Buffer)
                  /*~-1*/
                  {
                     /*~T*/
                     Communication_SendString(COMMUNICATION_RS232,TEXT_E007,1,0);
                  /*~-1*/
                  }
                  /*~E:I2494*/
                  /*~-1*/
#endif
                  /*~E:I2493*/
               /*~-1*/
               }
               /*~O:I2487*/
               /*~-2*/
               else
               {
                  /*~T*/
                  // NotAcknowledge senden
                  byRetVal = ADuC836_SPISendChar(NAK);
               /*~-1*/
               }
               /*~E:I2487*/
               /*~T*/
               break;
               /*~E:A2486*/
            /*~-1*/
            }
            /*~E:F2485*/
            /*~F:2495*/
            case INSTRUCTIONDECODER_SEND_E008:			// Unerwartetes Zeichen im Kommandostring 
            /*~-1*/
            {
               /*~A:2496*/
               /*~+:INSTRUCTIONDECODER_SEND_E008*/
               /*~I:2497*/
               if (CommunicationControl.chLine2Interprete == COMMUNICATION_RS232)
               /*~-1*/
               {
                  /*~I:2498*/
                  if (!SYSTEM_MRW_MANAGER)
                  /*~-1*/
                  {
                     /*~I:2499*/
                     if (lText2Send)
                     /*~-1*/
                     {
                        /*~I:2500*/
#ifdef CHANNEL_0
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~-1*/
#endif
                        /*~E:I2500*/
                        /*~I:2501*/
#ifdef CHANNEL_1
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~-1*/
#endif
                        /*~E:I2501*/
                        /*~T*/
                        break;
                     /*~-1*/
                     }
                     /*~E:I2499*/
                  /*~-1*/
                  }
                  /*~E:I2498*/
                  /*~I:2502*/
#ifdef CHANNEL_0
                  /*~T*/
                  Communication_SendString(COMMUNICATION_RS232,TEXT_E008,1,0);
                  /*~-1*/
#endif
                  /*~E:I2502*/
                  /*~I:2503*/
#ifdef CHANNEL_1
                  /*~I:2504*/
                  if (bDoNotWriteResult2Buffer)
                  /*~-1*/
                  {
                     /*~T*/
                     Communication_SendString(COMMUNICATION_RS232,TEXT_E008,1,0);
                  /*~-1*/
                  }
                  /*~E:I2504*/
                  /*~-1*/
#endif
                  /*~E:I2503*/
               /*~-1*/
               }
               /*~O:I2497*/
               /*~-2*/
               else
               {
                  /*~T*/
                  // NotAcknowledge senden
                  byRetVal = ADuC836_SPISendChar(NAK);
               /*~-1*/
               }
               /*~E:I2497*/
               /*~T*/
               break;
               /*~E:A2496*/
            /*~-1*/
            }
            /*~E:F2495*/
            /*~F:2505*/
            case INSTRUCTIONDECODER_SEND_E009:			// Wert au�erhalb des Grenzwertes

            /*~-1*/
            {
               /*~A:2506*/
               /*~+:INSTRUCTIONDECODER_SEND_E009*/
               /*~I:2507*/
               if (CommunicationControl.chLine2Interprete == COMMUNICATION_RS232)
               /*~-1*/
               {
                  /*~I:2508*/
                  if (!SYSTEM_MRW_MANAGER)
                  /*~-1*/
                  {
                     /*~I:2509*/
                     if (lText2Send)
                     /*~-1*/
                     {
                        /*~I:2510*/
#ifdef CHANNEL_0
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~-1*/
#endif
                        /*~E:I2510*/
                        /*~I:2511*/
#ifdef CHANNEL_1
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~-1*/
#endif
                        /*~E:I2511*/
                        /*~T*/
                        break;
                     /*~-1*/
                     }
                     /*~E:I2509*/
                  /*~-1*/
                  }
                  /*~E:I2508*/
                  /*~I:2512*/
#ifdef CHANNEL_0
                  /*~T*/
                  Communication_SendString(COMMUNICATION_RS232,TEXT_E009,1,0);
                  /*~-1*/
#endif
                  /*~E:I2512*/
                  /*~I:2513*/
#ifdef CHANNEL_1
                  /*~I:2514*/
                  if (bDoNotWriteResult2Buffer)
                  /*~-1*/
                  {
                     /*~T*/
                     Communication_SendString(COMMUNICATION_RS232,TEXT_E009,1,0);
                  /*~-1*/
                  }
                  /*~E:I2514*/
                  /*~-1*/
#endif
                  /*~E:I2513*/
               /*~-1*/
               }
               /*~O:I2507*/
               /*~-2*/
               else
               {
                  /*~T*/
                  // NotAcknowledge senden
                  byRetVal = ADuC836_SPISendChar(NAK);
               /*~-1*/
               }
               /*~E:I2507*/
               /*~T*/
               break;
               /*~E:A2506*/
            /*~-1*/
            }
            /*~E:F2505*/
            /*~F:2515*/
            case INSTRUCTIONDECODER_SEND_E010:			// Drifterkennung l�uft (nur SLC)

            /*~-1*/
            {
               /*~A:2516*/
               /*~+:INSTRUCTIONDECODER_SEND_E010*/
               /*~I:2517*/
               if (CommunicationControl.chLine2Interprete == COMMUNICATION_RS232)
               /*~-1*/
               {
                  /*~I:2518*/
                  if (!SYSTEM_MRW_MANAGER)
                  /*~-1*/
                  {
                     /*~I:2519*/
                     if (lText2Send)
                     /*~-1*/
                     {
                        /*~I:2520*/
#ifdef CHANNEL_0
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~-1*/
#endif
                        /*~E:I2520*/
                        /*~I:2521*/
#ifdef CHANNEL_1
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~-1*/
#endif
                        /*~E:I2521*/
                        /*~T*/
                        break;
                     /*~-1*/
                     }
                     /*~E:I2519*/
                     /*~I:2522*/
#ifdef CHANNEL_0
                     /*~T*/
                     Communication_SendString(COMMUNICATION_RS232,TEXT_E010,1,0);
                     /*~-1*/
#endif
                     /*~E:I2522*/
                     /*~I:2523*/
#ifdef CHANNEL_1 
                     /*~I:2524*/
                     if (bDoNotWriteResult2Buffer)
                     /*~-1*/
                     {
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,TEXT_E010,1,0);
                     /*~-1*/
                     }
                     /*~E:I2524*/
                     /*~-1*/
#endif
                     /*~E:I2523*/
                  /*~-1*/
                  }
                  /*~E:I2518*/
               /*~-1*/
               }
               /*~O:I2517*/
               /*~-2*/
               else
               {
                  /*~T*/
                  // NotAcknowledge senden
                  byRetVal = ADuC836_SPISendChar(NAK);
               /*~-1*/
               }
               /*~E:I2517*/
               /*~T*/
               break;
               /*~E:A2516*/
            /*~-1*/
            }
            /*~E:F2515*/
            /*~F:2525*/
            case INSTRUCTIONDECODER_SEND_E011:			// Parameter der Partner sind unterschiedlich 
            /*~-1*/
            {
               /*~A:2526*/
               /*~+:INSTRUCTIONDECODER_SEND_E011*/
               /*~I:2527*/
               if (CommunicationControl.chLine2Interprete == COMMUNICATION_RS232)
               /*~-1*/
               {
                  /*~I:2528*/
                  if (!SYSTEM_MRW_MANAGER)
                  /*~-1*/
                  {
                     /*~I:2529*/
                     if (lText2Send)
                     /*~-1*/
                     {
                        /*~I:2530*/
#ifdef CHANNEL_0
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~-1*/
#endif
                        /*~E:I2530*/
                        /*~I:2531*/
#ifdef CHANNEL_1
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~-1*/
#endif
                        /*~E:I2531*/
                        /*~T*/
                        break;
                     /*~-1*/
                     }
                     /*~E:I2529*/
                  /*~-1*/
                  }
                  /*~E:I2528*/
                  /*~I:2532*/
#ifdef CHANNEL_0
                  /*~T*/
                  Communication_SendString(COMMUNICATION_RS232,TEXT_E011,1,0);
                  /*~-1*/
#endif
                  /*~E:I2532*/
                  /*~I:2533*/
#ifdef CHANNEL_1 
                  /*~I:2534*/
                  if (bDoNotWriteResult2Buffer)
                  /*~-1*/
                  {
                     /*~T*/
                     Communication_SendString(COMMUNICATION_RS232,TEXT_E011,1,0);
                  /*~-1*/
                  }
                  /*~E:I2534*/
                  /*~-1*/
#endif
                  /*~E:I2533*/
               /*~-1*/
               }
               /*~O:I2527*/
               /*~-2*/
               else
               {
                  /*~T*/
                  // NotAcknowledge senden
                  byRetVal = ADuC836_SPISendChar(NAK);
               /*~-1*/
               }
               /*~E:I2527*/
               /*~T*/
               break;
               /*~E:A2526*/
            /*~-1*/
            }
            /*~E:F2525*/
            /*~F:2535*/
            case INSTRUCTIONDECODER_SEND_E012:			// Checksummenfehler
            /*~-1*/
            {
               /*~A:2536*/
               /*~+:INSTRUCTIONDECODER_SEND_E012*/
               /*~I:2537*/
               if (CommunicationControl.chLine2Interprete == COMMUNICATION_RS232)
               /*~-1*/
               {
                  /*~I:2538*/
                  if (!SYSTEM_MRW_MANAGER)
                  /*~-1*/
                  {
                     /*~I:2539*/
                     if (lText2Send)
                     /*~-1*/
                     {
                        /*~I:2540*/
#ifdef CHANNEL_0
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~-1*/
#endif
                        /*~E:I2540*/
                        /*~I:2541*/
#ifdef CHANNEL_1
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~-1*/
#endif
                        /*~E:I2541*/
                        /*~T*/
                        break;
                     /*~-1*/
                     }
                     /*~E:I2539*/
                  /*~-1*/
                  }
                  /*~E:I2538*/
                  /*~T*/
                  Communication_SendString(COMMUNICATION_RS232,TEXT_E012,1,0);
               /*~-1*/
               }
               /*~O:I2537*/
               /*~-2*/
               else
               {
                  /*~T*/
                  // NotAcknowledge senden
                  byRetVal = ADuC836_SPISendChar(NAK);
               /*~-1*/
               }
               /*~E:I2537*/
               /*~T*/
               break;
               /*~E:A2536*/
            /*~-1*/
            }
            /*~E:F2535*/
            /*~F:2542*/
            case INSTRUCTIONDECODER_SEND_NOK:			// NOK senden
            /*~-1*/
            {
               /*~A:2543*/
               /*~+:INSTRUCTIONDECODER_SEND_NOK*/
               /*~I:2544*/
               if (CommunicationControl.chLine2Interprete == COMMUNICATION_RS232)
               /*~-1*/
               {
                  /*~I:2545*/
                  if (!SYSTEM_MRW_MANAGER)
                  /*~-1*/
                  {
                     /*~I:2546*/
                     if (lText2Send)
                     /*~-1*/
                     {
                        /*~A:2547*/
                        /*~+:RS232-Ausgabe*/
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~E:A2547*/
                        /*~T*/
                        break;
                     /*~-1*/
                     }
                     /*~E:I2546*/
                  /*~-1*/
                  }
                  /*~E:I2545*/
                  /*~A:2548*/
                  /*~+:RS232-Ausgabe*/
                  /*~T*/
                  Communication_SendMessage(COMMUNICATION_RS232,COMMUNICATION_NOK);
                  /*~E:A2548*/
               /*~-1*/
               }
               /*~E:I2544*/
               /*~T*/
               break;
               /*~E:A2543*/
            /*~-1*/
            }
            /*~E:F2542*/
            /*~F:2549*/
            case INSTRUCTIONDECODER_SEND_NOTHING:
            /*~-1*/
            {
               /*~T*/
               break;
            /*~-1*/
            }
            /*~E:F2549*/
         /*~-1*/
         }
         /*~E:C2412*/
         /*~I:2550*/
#ifdef CHANNEL_1
         /*~I:2551*/
         if (!bDoNotWriteResult2Buffer)
         /*~-1*/
         {
            /*~T*/
            bDoNotWriteResult2Buffer = 1;

            g_byLastCommandExecutionResult = byCommandStatus;
         /*~-1*/
         }
         /*~E:I2551*/
         /*~-1*/
#endif
         /*~E:I2550*/
         /*~E:A2411*/
      /*~-1*/
      }
      /*~E:I58*/
   /*~-1*/
   }
   /*~E:I57*/
   /*~I:2552*/
#ifdef MOF
   /*~I:2553*/
   if (CommunicationControl.chLine2Interprete == COMMUNICATION_RS232)
   /*~-1*/
   {
      /*~A:2554*/
      /*~+:Kanal 0 - Freigabesteuerung*/
      /*~I:2555*/
#ifdef CHANNEL_0
      /*~T*/
      ulTimeout = SYSTEMTIME + HANDSHAKING_TIMEOUT; 
      /*~L:2556*/
      while ((byStatelineStatus == COMMUNICATION_INSTUCTIONDECODER_STATE_LINE)&&(ulTimeout >= SYSTEMTIME))
      /*~-1*/
      {
         /*~T*/

      /*~-1*/
      }
      /*~E:L2556*/
      /*~T*/
      // Freigabeleitung f�r Start des Instruction-Dekoders auf Partner-Seite wieder l�schen
      COMMUNICATION_INSTUCTIONDECODER_RELEASE_LINE = 0;	
      /*~-1*/
#endif
      /*~E:I2555*/
      /*~E:A2554*/
      /*~A:2557*/
      /*~+:Kanal 1 - Freigabesteuerung*/
      /*~I:2558*/
#ifdef CHANNEL_1
      /*~T*/
      ulTimeout = SYSTEMTIME + HANDSHAKING_TIMEOUT; 
      /*~L:2559*/
      while ((ADuC836_RS232IsTransmissionReady() == FALSE)&&(ulTimeout >= SYSTEMTIME))
      /*~-1*/
      {
         /*~T*/

      /*~-1*/
      }
      /*~E:L2559*/
      /*~T*/
      ulTimeout = SYSTEMTIME + HANDSHAKING_TIMEOUT; 
      /*~T*/
      COMMUNICATION_INSTUCTIONDECODER_RELEASE_LINE = !COMMUNICATION_INSTUCTIONDECODER_RELEASE_LINE;
      /*~L:2560*/
      while ((COMMUNICATION_INSTUCTIONDECODER_STATE_LINE == TRUE)&&(ulTimeout >= SYSTEMTIME))
      /*~-1*/
      {
         /*~T*/

      /*~-1*/
      }
      /*~E:L2560*/
      /*~L:2561*/
      while ((COMMUNICATION_INSTUCTIONDECODER_STATE_LINE == FALSE)&&(ulTimeout >= SYSTEMTIME))
      /*~-1*/
      {
         /*~T*/

      /*~-1*/
      }
      /*~E:L2561*/
      /*~-1*/
#endif
      /*~E:I2558*/
      /*~E:A2557*/
   /*~-1*/
   }
   /*~E:I2553*/
   /*~-1*/
#endif
   /*~E:I2552*/
   /*~E:A20*/
   /*~A:2562*/
   /*~+:Letzes Kommando f�r immer l�schen*/
   /*~T*/
   // letzes Kommando f�r immer l�schen
   memset(pCommunicationCommand,0,sizeof(COMMUNICATION_COMMAND));
   /*~E:A2562*/
/*~-1*/
}
/*~E:F10*/
/*~E:A9*/
/*~A:2563*/
/*~+:char 			InstructionDecoder_CheckLimits(void *pParameter2Check, void *pLimitLow, void *pLimitHigh, unsigned char chDataType)*/
/*~F:2564*/
char InstructionDecoder_CheckLimits(void *pParameter2Check, void *pLimitLow, void *pLimitHigh, unsigned char chDataType)
/*~-1*/
{
   /*~A:2565*/
   /*~+:Variablendeklarationen*/
   /*~T*/
   char byRetVal;
   /*~E:A2565*/
   /*~A:2566*/
   /*~+:Variableninitialisierungen*/
   /*~T*/

   /*~E:A2566*/
   /*~C:2567*/
   switch (chDataType)
   /*~-1*/
   {
      /*~F:2568*/
      case DATATYPE_CHAR:
      /*~-1*/
      {
         /*~A:2569*/
         /*~+:Variablendeklarationen*/
         /*~T*/
         char byTempLimit;
         /*~E:A2569*/
         /*~A:2570*/
         /*~+:Variableninitialisierungen*/
         /*~T*/

         /*~E:A2570*/
         /*~I:2571*/
         if (*(char*)pLimitLow > *(char*)pLimitHigh)
         /*~-1*/
         {
            /*~T*/
            // unterer und oberer Grenzwert vertauscht

            byTempLimit = *(char*)pLimitLow;

            *(char*)pLimitLow = *(char*)pLimitHigh;
            *(char*)pLimitHigh = byTempLimit;
         /*~-1*/
         }
         /*~E:I2571*/
         /*~I:2572*/
         if (*(char*)pParameter2Check < *(char*)pLimitLow)
         /*~-1*/
         {
            /*~T*/
            // Parameter liegt unterhalb des unteren Grenzwertes
            *(char*)pParameter2Check = *(char*)pLimitLow;

            // 1 zur�ckliefern
            byRetVal = 1;
         /*~-1*/
         }
         /*~O:I2572*/
         /*~-2*/
         else
         {
            /*~I:2573*/
            if (*(char*)pParameter2Check > *(char*)pLimitHigh)
            /*~-1*/
            {
               /*~T*/
               // Parameter liegt oberhalb des oberen Grenzwertes
               *(char*)pParameter2Check = *(char*)pLimitHigh;

               // 2 zur�ckliefern
               byRetVal = 2;
            /*~-1*/
            }
            /*~O:I2573*/
            /*~-2*/
            else
            {
               /*~T*/
               // Grenzwert innerhalb der Grenzen - R�ckgabe von 0 und Ausstieg

               return 0;
            /*~-1*/
            }
            /*~E:I2573*/
         /*~-1*/
         }
         /*~E:I2572*/
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F2568*/
      /*~F:2574*/
      case DATATYPE_INT:
      /*~-1*/
      {
         /*~A:2575*/
         /*~+:Variablendeklarationen*/
         /*~T*/
         int nTempLimit;
         /*~E:A2575*/
         /*~A:2576*/
         /*~+:Variableninitialisierungen*/
         /*~T*/

         /*~E:A2576*/
         /*~I:2577*/
         if (*(int*)pLimitLow > *(int*)pLimitHigh)
         /*~-1*/
         {
            /*~T*/
            // unterer und oberer Grenzwert vertauscht

            nTempLimit = *(int*)pLimitLow;

            *(int*)pLimitLow = *(int*)pLimitHigh;
            *(int*)pLimitHigh = nTempLimit;
         /*~-1*/
         }
         /*~E:I2577*/
         /*~I:2578*/
         if (*(int*)pParameter2Check < *(int*)pLimitLow)
         /*~-1*/
         {
            /*~T*/
            // Parameter liegt unterhalb des unteren Grenzwertes
            *(int*)pParameter2Check = *(int*)pLimitLow;

            // 1 zur�ckliefern
            byRetVal = 1;
         /*~-1*/
         }
         /*~O:I2578*/
         /*~-2*/
         else
         {
            /*~I:2579*/
            if (*(int*)pParameter2Check > *(int*)pLimitHigh)
            /*~-1*/
            {
               /*~T*/
               // Parameter liegt oberhalb des oberen Grenzwertes
               *(int*)pParameter2Check = *(int*)pLimitHigh;

               // 2 zur�ckliefern
               byRetVal = 2;
            /*~-1*/
            }
            /*~O:I2579*/
            /*~-2*/
            else
            {
               /*~T*/
               // Grenzwert innerhalb der Grenzen - R�ckgabe von 0 und Ausstieg

               return 0;
            /*~-1*/
            }
            /*~E:I2579*/
         /*~-1*/
         }
         /*~E:I2578*/
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F2574*/
      /*~F:2580*/
      case DATATYPE_LONG:
      /*~-1*/
      {
         /*~A:2581*/
         /*~+:Variablendeklarationen*/
         /*~T*/
         long lTempLimit;
         /*~E:A2581*/
         /*~A:2582*/
         /*~+:Variableninitialisierungen*/
         /*~T*/

         /*~E:A2582*/
         /*~I:2583*/
         if (*(long*)pLimitLow > *(long*)pLimitHigh)
         /*~-1*/
         {
            /*~T*/
            // unterer und oberer Grenzwert vertauscht

            lTempLimit = *(long*)pLimitLow;

            *(long*)pLimitLow = *(long*)pLimitHigh;
            *(long*)pLimitHigh = lTempLimit;
         /*~-1*/
         }
         /*~E:I2583*/
         /*~I:2584*/
         if (*(long*)pParameter2Check < *(long*)pLimitLow)
         /*~-1*/
         {
            /*~T*/
            // Parameter liegt unterhalb des unteren Grenzwertes
            *(long*)pParameter2Check = *(long*)pLimitLow;

            // 1 zur�ckliefern
            byRetVal = 1;
         /*~-1*/
         }
         /*~O:I2584*/
         /*~-2*/
         else
         {
            /*~I:2585*/
            if (*(long*)pParameter2Check > *(long*)pLimitHigh)
            /*~-1*/
            {
               /*~T*/
               // Parameter liegt oberhalb des oberen Grenzwertes
               *(long*)pParameter2Check = *(long*)pLimitHigh;

               // 2 zur�ckliefern
               byRetVal = 2;
            /*~-1*/
            }
            /*~O:I2585*/
            /*~-2*/
            else
            {
               /*~T*/
               // Grenzwert innerhalb der Grenzen - R�ckgabe von 0 und Ausstieg

               return 0;
            /*~-1*/
            }
            /*~E:I2585*/
         /*~-1*/
         }
         /*~E:I2584*/
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F2580*/
      /*~F:2586*/
      case DATATYPE_FLOAT:
      /*~-1*/
      {
         /*~A:2587*/
         /*~+:Variablendeklarationen*/
         /*~T*/
         float fTempLimit;
         /*~E:A2587*/
         /*~A:2588*/
         /*~+:Variableninitialisierungen*/
         /*~T*/

         /*~E:A2588*/
         /*~I:2589*/
         if (*(float*)pLimitLow > *(float*)pLimitHigh)
         /*~-1*/
         {
            /*~T*/
            // unterer und oberer Grenzwert vertauscht

            fTempLimit = *(float*)pLimitLow;

            *(float*)pLimitLow = *(float*)pLimitHigh;
            *(float*)pLimitHigh = fTempLimit;
         /*~-1*/
         }
         /*~E:I2589*/
         /*~I:2590*/
         if (*(float*)pParameter2Check < *(float*)pLimitLow)
         /*~-1*/
         {
            /*~T*/
            // Parameter liegt unterhalb des unteren Grenzwertes
            *(float*)pParameter2Check = *(float*)pLimitLow;

            // 1 zur�ckliefern
            byRetVal = 1;
         /*~-1*/
         }
         /*~O:I2590*/
         /*~-2*/
         else
         {
            /*~I:2591*/
            if (*(float*)pParameter2Check > *(float*)pLimitHigh)
            /*~-1*/
            {
               /*~T*/
               // Parameter liegt oberhalb des oberen Grenzwertes
               *(float*)pParameter2Check = *(float*)pLimitHigh;

               // 2 zur�ckliefern
               byRetVal = 2;
            /*~-1*/
            }
            /*~O:I2591*/
            /*~-2*/
            else
            {
               /*~T*/
               // Grenzwert innerhalb der Grenzen - R�ckgabe von 0 und Ausstieg

               return 0;
            /*~-1*/
            }
            /*~E:I2591*/
         /*~-1*/
         }
         /*~E:I2590*/
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F2586*/
   /*~-1*/
   }
   /*~E:C2567*/
   /*~T*/
   // Meldung ausgeben
   Communication_SendString(COMMUNICATION_RS232,TEXT_E002,0,0);
   /*~T*/
   return byRetVal;
/*~-1*/
}
/*~E:F2564*/
/*~E:A2563*/
/*~A:2592*/
/*~+:char 			InstructionDecoder_CheckNbParameters(unsigned char byNbParametersExpected,char byShowErrorsBy,unsigned char *pStatus)*/
/*~F:2593*/
char InstructionDecoder_CheckNbParameters(unsigned char byNbParametersExpected,char byShowErrorsBy,unsigned char *pStatus)
/*~-1*/
{
   /*~A:2594*/
   /*~+:Variablendeklarationen*/
   /*~T*/
   // Variablendeklarationen
   unsigned char byNumberOfParameters;
   /*~E:A2594*/
   /*~A:2595*/
   /*~+:Variableninitialisierungen*/
   /*~T*/
   // Variableninitialisierungen
   /*~E:A2595*/
   /*~T*/
   byNumberOfParameters = Communication_GetNumberOfParameters();
   /*~I:2596*/
   if (byNumberOfParameters == byNbParametersExpected)
   /*~-1*/
   {
      /*~T*/
      // Anzahl der Parameter stimmt
      /*~T*/
      return 0;
   /*~-1*/
   }
   /*~O:I2596*/
   /*~-2*/
   else
   {
      /*~I:2597*/
      if (byNbParametersExpected > byNumberOfParameters)
      /*~-1*/
      {
         /*~T*/
         // Anzahl der �bergebenen Parameter zu klein
         /*~I:2598*/
#ifdef CHANNEL_0
         /*~I:2599*/
         if (byShowErrorsBy & 0x01)
         /*~-1*/
         {
            /*~A:2600*/
            /*~+:E007*/
            /*~T*/
            Communication_SendString(COMMUNICATION_RS232,TEXT_E007,1,0);
            /*~E:A2600*/
         /*~-1*/
         }
         /*~E:I2599*/
         /*~-1*/
#endif
         /*~E:I2598*/
         /*~I:2601*/
#ifdef CHANNEL_1
         /*~I:2602*/
         if (byShowErrorsBy & 0x02)
         /*~-1*/
         {
            /*~A:2603*/
            /*~+:E007*/
            /*~T*/
            *pStatus = INSTRUCTIONDECODER_SEND_E007; 
            /*~E:A2603*/
         /*~-1*/
         }
         /*~E:I2602*/
         /*~-1*/
#endif
         /*~E:I2601*/
         /*~T*/
         return 1;
      /*~-1*/
      }
      /*~O:I2597*/
      /*~-2*/
      else
      {
         /*~T*/
         // Anzahl der �bergebenen Parameter zu gro�
         /*~I:2604*/
#ifdef CHANNEL_0
         /*~I:2605*/
         if (byShowErrorsBy & 0x01)
         /*~-1*/
         {
            /*~A:2606*/
            /*~+:E008*/
            /*~T*/
            Communication_SendString(COMMUNICATION_RS232,TEXT_E008,1,0);
            /*~E:A2606*/
         /*~-1*/
         }
         /*~E:I2605*/
         /*~-1*/
#endif
         /*~E:I2604*/
         /*~I:2607*/
#ifdef CHANNEL_1
         /*~I:2608*/
         if (byShowErrorsBy & 0x02)
         /*~-1*/
         {
            /*~A:2609*/
            /*~+:E008*/
            /*~T*/
            *pStatus = INSTRUCTIONDECODER_SEND_E008; 
            /*~E:A2609*/
         /*~-1*/
         }
         /*~E:I2608*/
         /*~-1*/
#endif
         /*~E:I2607*/
         /*~T*/
         return 2;
      /*~-1*/
      }
      /*~E:I2597*/
   /*~-1*/
   }
   /*~E:I2596*/
/*~-1*/
}
/*~E:F2593*/
/*~E:A2592*/
/*~I:2610*/
#ifdef CHANNEL_1
/*~A:2611*/
/*~+:void 			InstructionDecoder_StoreValue(unsigned char byValue2Store,GLOBAL_UNIVALUE Value)*/
/*~F:2612*/
void InstructionDecoder_StoreValue(unsigned char byValue2Store,GLOBAL_UNIVALUE_SHORT* pValue)
/*~-1*/
{
   /*~T*/
   g_byValueStored = byValue2Store;
   g_Value = *pValue;
   g_ulTimeoutValue = SYSTEMTIME + 500;
/*~-1*/
}
/*~E:F2612*/
/*~E:A2611*/
/*~-1*/
#endif
/*~E:I2610*/
