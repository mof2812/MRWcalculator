/*~-1*/
/*~XSF_LANGUAGE: C/C++*/
/*~K*/
/*~+:File :        InstuctionDecoder.c*/
/*~+:*/
/*~+:Version :     V1.002*/
/*~+:*/
/*~+:Date :        21.11.2021*/
/*~+:*/
/*~+:Time :        10:23*/
/*~+:*/
/*~+:Author :      MOF*/
/*~+:*/
/*~+:Hardware :*/
/*~+:*/
/*~+:Description :*/
/*~+:*/
/*~+:*/
/*~A:1*/
/*~+:Includes*/
/*~T*/
#include "global.h"
#include "InstructionDecoder.h"
#include "ADuc836Driver.h"
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
/*~E:A1*/
/*~A:2*/
/*~+:Funktionseigene Definitionen und Makros*/
/*~T*/
#define DATATYPE_CHAR									0
#define DATATYPE_UNSIGNED_CHAR							1
#define DATATYPE_INT									2
#define DATATYPE_UNSIGNED_INT							3
#define DATATYPE_LONG									4
#define DATATYPE_UNSIGNED_LONG							5
#define DATATYPE_FLOAT									6
/*~T*/
#define SHOW_ERRORS_BY_NONE								0x00
#define SHOW_ERRORS_BY_CH0								0x01
#define SHOW_ERRORS_BY_CH1								0x02
#define SHOW_ERRORS_BY_ALL								0x03
/*~T*/
#define HANDSHAKING_TIMEOUT								500
/*~I:3*/
#ifdef CHANNEL_0
/*~T*/
#define GET_RESPONSE				Communication_GetSPIResponse()
#define RELEASE_INSTRUCTIONDECODER	System_ReleaseExternalInterrupt()
/*~-1*/
#endif
/*~E:I3*/
/*~I:4*/
#ifdef CHANNEL_1
/*~T*/
#define GET_RESPONSE		(bDoNotWriteResult2Buffer = 0)
/*~-1*/
#endif
/*~E:I4*/
/*~E:A2*/
/*~A:5*/
/*~+:Funktionseigene Struktur-Definitionen*/
/*~T*/

/*~E:A5*/
/*~A:6*/
/*~+:Funktionsprototypen*/
/*~T*/
void 			InstructionDecoder(void);
char 			InstructionDecoder_CheckLimits(void *pParameter2Check, void *pLimitLow, void *pLimitHigh,unsigned char chDataType);

char 			InstructionDecoder_CheckNbParameters(unsigned char byNbParametersExpected,char byShowErrorsBy,unsigned char *pStatus);

void 			InstructionDecoder_SendStoredValue(unsigned char byValue2Get);

void 			InstructionDecoder_StoreValue(unsigned char byValue2Store,GLOBAL_UNIVALUE_SHORT* pValue);

/*~E:A6*/
/*~A:7*/
/*~+:Globale Variablen*/
/*~T*/
unsigned char g_chRCWLast;
/*~I:8*/
#ifdef CHANNEL_1
/*~T*/
unsigned char g_byLastCommandExecutionResult = 0xA5;		///< Letztes Ergebnis einer Funktionsausf�hrung. Es ist noch nichts eingetragen
/*~T*/
unsigned char 			g_byValueStored = 0;		///< Angabe zum gespeicherten Wert
GLOBAL_UNIVALUE_SHORT 	g_Value;					///< zu �bergebender Wert
unsigned long 			g_ulTimeoutValue;			///< Zeit, zu der der Wert sp�testens gel�scht wird
/*~-1*/
#endif
/*~E:I8*/
/*~E:A7*/
/*~A:9*/
/*~+:void 			InstructionDecoder(void)*/
/*~F:10*/
void InstructionDecoder(void)
/*~-1*/
{
   /*~A:11*/
   /*~+:Variablendeklarationen*/
   /*~T*/
   unsigned char 		szCommand[80];
   unsigned char 		byChecksumError = FALSE;
   unsigned char 		byCommandStatus;
   unsigned long 		lText2Send;
   unsigned long		ulDiagnosisEntry2Set;

   /*~I:12*/
#ifdef CHANNEL_1
   /*~T*/
   static unsigned long		ulDiagnosisEntry2SetAtiGRS = 0;

   /*~-1*/
#endif
   /*~E:I12*/
   /*~T*/
   GLOBAL_UNIVALUE 	Parameter[4];
   unsigned char 		byTemp;
   float fTemp;
   unsigned char 		byRetVal;
   MEASUREMENT_VALUE 	MVTemp;
   unsigned char 		byLoopCounter;
   char 				szString2Send[24];

   /*~I:13*/
#ifdef CHANNEL_0
   /*~T*/
   unsigned char 		byStartPartnerInstructionDecoder;
   unsigned char		byStatelineStatus;
   /*~-1*/
#endif
   /*~E:I13*/
   /*~I:14*/
#ifdef CHANNEL_1
   /*~T*/
   // GLOBAL_UNIVALUE 	ParameterRead;
   unsigned char 		bDoNotWriteResult2Buffer;
   /*~I:15*/
#ifdef SYSTEM_CND_ENABLE_SPI_DEBUGGING
   /*~T*/
   // Nur zu Testzwecken
   char achString[24];
   /*~-1*/
#endif
   /*~E:I15*/
   /*~-1*/
#endif
   /*~E:I14*/
   /*~E:A11*/
   /*~A:16*/
   /*~+:Variableninitialisierungen*/
   /*~I:17*/
#ifdef CHANNEL_0
   /*~T*/
   byCommandStatus = INSTRUCTIONDECODER_SEND_E004;

   /*~-1*/
#endif
   /*~E:I17*/
   /*~I:18*/
#ifdef CHANNEL_1
   /*~T*/
   byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
   bDoNotWriteResult2Buffer = 1;

   /*~-1*/
#endif
   /*~E:I18*/
   /*~T*/
   ulDiagnosisEntry2Set = 0;
   lText2Send = 0;
   byRetVal = 0;
   byLoopCounter = 5;
   byChecksumError = FALSE;

   /*~I:19*/
#ifdef CHANNEL_0
   /*~T*/
   byStartPartnerInstructionDecoder = 0;
   /*~-1*/
#endif
   /*~E:I19*/
   /*~E:A16*/
   /*~A:20*/
   /*~+:Befehlsauswertung und -ausf�hrung*/
   /*~A:21*/
   /*~+:Kanal 0 - Zugangssteuerung*/
   /*~I:22*/
#ifdef CHANNEL_0
   /*~I:23*/
   if (ADuC836_RS232IsNewCommand())
   /*~-1*/
   {
      /*~K*/
      /*~+:// �ber die RS232 kam ein Kommando rein */
      /*~T*/
      CommunicationControl.chLine2Interprete = COMMUNICATION_RS232;
      /*~T*/
      // R�ckleitung des Handshakings auf HIGH legen
      COMMUNICATION_INSTUCTIONDECODER_STATE_LINE = TRUE;
      /*~T*/
      // Status der Instuction-Decoder - Leitung abfragen und den Status zwischenspeichern

      byStatelineStatus = COMMUNICATION_INSTUCTIONDECODER_STATE_LINE;
      /*~T*/
      // Freigabeleitung f�r Start des Instruction-Decoders auf Partner-Seite setzen

      COMMUNICATION_INSTUCTIONDECODER_RELEASE_LINE = 1;	
   /*~-1*/
   }
   /*~O:I23*/
   /*~-2*/
   else
   {
      /*~K*/
      /*~+:// Es gibt nichts zu tun*/
      /*~T*/
      return;
   /*~-1*/
   }
   /*~E:I23*/
   /*~-1*/
#endif
   /*~E:I22*/
   /*~E:A21*/
   /*~A:24*/
   /*~+:Kanal 1 - Zugangssteuerung*/
   /*~I:25*/
#ifdef CHANNEL_1
   /*~I:26*/
   if (ADuC836_SPIIsNewCommand())
   /*~-1*/
   {
      /*~K*/
      /*~+:// �ber die SPI kam ein Kommando rein */
      /*~T*/
      CommunicationControl.chLine2Interprete = COMMUNICATION_SPI;
   /*~-1*/
   }
   /*~O:I26*/
   /*~-2*/
   else
   {
      /*~I:27*/
      if (COMMUNICATION_INSTUCTIONDECODER_STATE_LINE)
      /*~-1*/
      {
         /*~T*/
         // Partner hat die RS232-Abarbeitung des Instruction-Decoders freigegeben
         /*~I:28*/
         if (ADuC836_RS232IsNewCommand())
         /*~-1*/
         {
            /*~T*/
            // R�ckleitung des Handshakings auf HIGH legen
            COMMUNICATION_INSTUCTIONDECODER_STATE_LINE = TRUE;
            /*~K*/
            /*~+:// �ber die RS232 kam ein Kommando rein */
            /*~T*/
            CommunicationControl.chLine2Interprete = COMMUNICATION_RS232;
            /*~A:29*/
            /*~+:Das Ergebnis der letzten Ausf�hrung zur�cksetzen*/
            /*~T*/
            // Das Ergebnis der letzten Ausf�hrung zur�cksetzen

            g_byLastCommandExecutionResult = 0xA5;
            /*~E:A29*/
         /*~-1*/
         }
         /*~O:I28*/
         /*~-2*/
         else
         {
            /*~K*/
            /*~+:// Es gibt nichts zu tun*/
            /*~T*/
            return;
         /*~-1*/
         }
         /*~E:I28*/
      /*~-1*/
      }
      /*~O:I27*/
      /*~-2*/
      else
      {
         /*~T*/
         return;
      /*~-1*/
      }
      /*~E:I27*/
   /*~-1*/
   }
   /*~E:I26*/
   /*~-1*/
#endif
   /*~E:I25*/
   /*~E:A24*/
   /*~A:30*/
   /*~+:Befehl holen, auswerten und ggf. Pr�fsumme bilden*/
   /*~T*/
   Communication_GetRecBuffer(CommunicationControl.chLine2Interprete,szCommand);
   /*~I:31*/
#ifdef MIT_CRC16
   /*~I:32*/
   if ((CommunicationControl.chLine2Interprete == COMMUNICATION_RS232)&&(strncmp(szCommand,"CDL",3) != 0))
   /*~-1*/
   {
      /*~T*/
      byChecksumError = Communication_CheckReceiveFrame(szCommand);

   /*~-1*/
   }
   /*~E:I32*/
   /*~-1*/
#endif
   /*~E:I31*/
   /*~T*/
   strcpy(szCommand,Communication_Interpret(szCommand));
   /*~E:A30*/
   /*~I:33*/
#ifdef MIT_CRC16
   /*~A:34*/
   /*~+:Nur bei CRC16-Pr�fung*/
   /*~I:35*/
#ifdef CHANNEL_0
   /*~I:36*/
   if (CommunicationControl.chLine2Interprete == COMMUNICATION_RS232)
   /*~-1*/
   {
      /*~A:37*/
      /*~+:Ausgabe Teil 1 - Fehlermeldung wg. fehlerhafter CRC*/
      /*~A:38*/
      /*~+:Warte bis Kanal 1 die Freigabe wieder zur�ckgibt*/
      /*~F:39*/
      // Warte bis Kanal 1 die Freigabe wieder zur�ckgibt
      /*~-1*/
      {
         /*~T*/
         ulTimeout = SYSTEMTIME + HANDSHAKING_TIMEOUT; 
         /*~L:40*/
         while ((byStatelineStatus == COMMUNICATION_INSTUCTIONDECODER_STATE_LINE)&&(ulTimeout >= SYSTEMTIME))
         /*~-1*/
         {
            /*~T*/

         /*~-1*/
         }
         /*~E:L40*/
      /*~-1*/
      }
      /*~E:F39*/
      /*~E:A38*/
      /*~A:41*/
      /*~+:Kanal 1 hat die Freigabe wieder zur�ckgegeben. jetzt kann eine CRC16-Fehlermeldung erfolgen*/
      /*~T*/
      // Kanal 1 hat die Freigabe wieder zur�ckgegeben. jetzt kann eine CRC16-Fehlermeldung erfolgen
      COMMUNICATION_INSTUCTIONDECODER_RELEASE_LINE = FALSE;	
      /*~A:42*/
      /*~+:Im Fehlerfall eine Fehlermeldung (E012) ausgeben - ansonsten 1ms warten*/
      /*~I:43*/
      if (byChecksumError)
      /*~-1*/
      {
         /*~T*/
         Communication_SendString(COMMUNICATION_RS232,TEXT_E012,1,0);
         /*~T*/
         ulTimeout = SYSTEMTIME + HANDSHAKING_TIMEOUT; 
         /*~L:44*/
         while ((ADuC836_RS232IsTransmissionReady() == FALSE)&&(ulTimeout >= SYSTEMTIME))
         /*~-1*/
         {
            /*~T*/

         /*~-1*/
         }
         /*~E:L44*/
      /*~-1*/
      }
      /*~O:I43*/
      /*~-2*/
      else
      {
         /*~T*/
         System_Wait(1);
      /*~-1*/
      }
      /*~E:I43*/
      /*~E:A42*/
      /*~E:A41*/
      /*~A:45*/
      /*~+:Kanal 1 wieder die Freigabe zur Datanausgabe �bergeben*/
      /*~T*/
      // Status der Instuction-Decoder - Leitung abfragen und den umgekehrten Status zwischenspeichern
      byStatelineStatus = COMMUNICATION_INSTUCTIONDECODER_STATE_LINE;
      /*~T*/
      // Kanal 1 wieder die Freigabe zur Datanausgabe �bergeben
      COMMUNICATION_INSTUCTIONDECODER_RELEASE_LINE = TRUE;
      /*~E:A45*/
      /*~E:A37*/
   /*~-1*/
   }
   /*~E:I36*/
   /*~-1*/
#endif
   /*~E:I35*/
   /*~I:46*/
#ifdef CHANNEL_1
   /*~I:47*/
   if (CommunicationControl.chLine2Interprete == COMMUNICATION_RS232)
   /*~-1*/
   {
      /*~A:48*/
      /*~+:Ausgabe Teil 1 - Fehlermeldung wg. fehlerhafter CRC*/
      /*~A:49*/
      /*~+:Im Fehlerfall eine Fehlermeldung (E012) ausgeben*/
      /*~I:50*/
      if (byChecksumError)
      /*~-1*/
      {
         /*~T*/
         Communication_SendString(COMMUNICATION_RS232,TEXT_E012,1,0);
         /*~T*/
         ulTimeout = SYSTEMTIME + HANDSHAKING_TIMEOUT; 
         /*~L:51*/
         while ((ADuC836_RS232IsTransmissionReady() == FALSE)&&(ulTimeout >= SYSTEMTIME))
         /*~-1*/
         {
            /*~T*/

         /*~-1*/
         }
         /*~E:L51*/
      /*~-1*/
      }
      /*~E:I50*/
      /*~E:A49*/
      /*~T*/
      ulTimeout = SYSTEMTIME + HANDSHAKING_TIMEOUT; 
      /*~A:52*/
      /*~+:Fehlerausgabe erfolgt - Handshakeleitung umschalten*/
      /*~T*/
      // Fehlerausgabe erfolgt - Handshakeleitung umschalten
      COMMUNICATION_INSTUCTIONDECODER_RELEASE_LINE = !COMMUNICATION_INSTUCTIONDECODER_RELEASE_LINE;
      /*~E:A52*/
      /*~A:53*/
      /*~+:Warte auf einen Pegelwechsel von LOW nach HIGH. Wenn dieser erfolgt ist, kann Kanal 1 beginnen, das Datum zu senden*/
      /*~F:54*/
      // Warte auf einen Pegelwechsel von LOW nach HIGH. Wenn dieser erfolgt ist, kann Kanal 1 beginnen, das Datum zu senden
      /*~-1*/
      {
         /*~L:55*/
         while ((COMMUNICATION_INSTUCTIONDECODER_STATE_LINE)&&(ulTimeout >= SYSTEMTIME))
         /*~-1*/
         {
            /*~T*/

         /*~-1*/
         }
         /*~E:L55*/
         /*~L:56*/
         while ((!COMMUNICATION_INSTUCTIONDECODER_STATE_LINE)&&(ulTimeout >= SYSTEMTIME))
         /*~-1*/
         {
            /*~T*/

         /*~-1*/
         }
         /*~E:L56*/
      /*~-1*/
      }
      /*~E:F54*/
      /*~E:A53*/
      /*~E:A48*/
   /*~-1*/
   }
   /*~E:I47*/
   /*~-1*/
#endif
   /*~E:I46*/
   /*~E:A34*/
   /*~-1*/
#endif
   /*~E:I33*/
   /*~I:57*/
   if (szCommand[0])

   /*~-1*/
   {
      /*~I:58*/
#ifdef CHANNEL_1
      	if (strcmp(szCommand,"GPA"))
#endif
      /*~-1*/
      {
         /*~I:59*/
         if ((byChecksumError == FALSE)||(strcmp(szCommand,"CDL") == 0)) 
         /*~-1*/
         {
            /*~K*/
            /*~+:/~* Ge�ndert am 09.02.2022 *~/*/
            /*~I:60*/
            if ((Communication_IsCommunicationEnabled() != 0)||(strcmp(szCommand,"ENA") == 0)||(strcmp(szCommand,"CDL") == 0)||(CommunicationControl.chLine2Interprete != COMMUNICATION_RS232))
            /*~-1*/
            {
               /*~K*/
               /*~+:/~* Ende - Ge�ndert am 09.02.2022 *~/*/
               /*~C:61*/
               // switch (*(char*)szCommand)
               switch (szCommand[0])
               /*~-1*/
               {
                  /*~A:62*/
                  /*~+:A*/
                  /*~F:63*/
                  case 'A':
                  /*~-1*/
                  {
                     /*~A:64*/
                     /*~+:ACR - AutomaticCompensationResults*/
                     /*~I:65*/
                     if (!strcmp(szCommand,"ACR"))
                     /*~-1*/
                     {
                        /*~A:66*/
                        /*~+:Variablendeklarationen*/
                        /*~T*/
                        unsigned char byCounter;
                        /*~E:A66*/
                        /*~A:67*/
                        /*~+:Variableninitialisierungen*/
                        /*~T*/
                        byCounter = 3;
                        /*~E:A67*/
                        /*~T*/
                        // Text wurde bereits gesendet
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:68*/
#ifdef CHANNEL_0
                        /*~I:69*/
                        if (!InstructionDecoder_CheckNbParameters(3,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           // Parameter einlesen
                           // Kanal
                           Parameter[0].nLong = Communication_GetLongParameter(0);
                           // Welche Ausgabe
                           Parameter[1].nLong = Communication_GetLongParameter(1);
                           // zus�tzliche Angabe
                           Parameter[2].nLong = Communication_GetLongParameter(2);

                           /*~I:70*/
                           if (((Parameter[1].nLong > 7)&&(Parameter[1].nLong != 255))||(Parameter[0].nLong > 1))
                           /*~-1*/
                           {
                              /*~A:71*/
                              /*~+:Parameter au�erhalb des Bereichs*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~E:A71*/
                           /*~-1*/
                           }
                           /*~O:I70*/
                           /*~-2*/
                           else
                           {
                              /*~I:72*/
                              if ((!SYSTEM_MRW_MANAGER)||(Parameter[0].nLong == 0))
                              /*~-1*/
                              {
                              /*~A:73*/
                              /*~+:Ausgabe 'Kanal 0'*/
                              /*~T*/
                              // Synchronisationspr�fung wg. der langen Ausf�hrungsdauer abschalten
                              /*~A:74*/
                              /*~+:ausgeklammert*/
                              /*~I:75*/
#ifdef MOF
                              /*~U:76*/
                              /*~-2*/
                              do
                              {
                              /*~T*/
                              Communication_SendSPICommand("iSCS 0");
                              /*~-1*/
                              }
                              /*~O:U76*/
                              while (!Communication_IsOK() && --byCounter);
                              /*~E:U76*/
                              /*~-1*/
#endif
                              /*~E:I75*/
                              /*~E:A74*/
                              /*~I:77*/
#ifdef MOF
                              /*~T*/
                              Communication_SendSPICommand("iSCS 0");
                              /*~I:78*/
                              if (Communication_IsOK())
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendSPICommand("iSCS 1");
                              /*~-1*/
                              }
                              /*~E:I78*/
                              /*~-1*/
#endif
                              /*~E:I77*/
                              /*~T*/
                              Compensation_PrintCompensationValues(1,Parameter[1].nLong,(char)Parameter[2].nLong,0);
                              /*~E:A73*/
                              /*~-1*/
                              }
                              /*~E:I72*/
                           /*~-1*/
                           }
                           /*~E:I70*/
                           /*~I:79*/
                           if ((!SYSTEM_MRW_MANAGER)||(Parameter[0].nLong == 1))
                           /*~-1*/
                           {
                              /*~A:80*/
                              /*~+:Ausgabe Kanal '1' veranlassen*/
                              /*~T*/
                              // Frame zusammensetzen
                              sprintf(szString2Send,"iACR %ld %ld",Parameter[1].nLong,Parameter[2].nLong);
                              /*~I:81*/
                              if (!Communication_SendSPICommand(szString2Send))
                              /*~-1*/
                              {
                              /*~I:82*/
                              if (Communication_IsOK())
                              /*~-1*/
                              {
                              /*~T*/
                              // Alles okay

                              // Wg. der langen Dauer der Ausgabe die Synchronisationspr�fung ausschalten
                              System_SetCheckSynchronisation(0);
                              /*~-1*/
                              }
                              /*~O:I82*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~-1*/
                              }
                              /*~E:I82*/
                              /*~-1*/
                              }
                              /*~O:I81*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~-1*/
                              }
                              /*~E:I81*/
                              /*~E:A80*/
                           /*~-1*/
                           }
                           /*~E:I79*/
                        /*~-1*/
                        }
                        /*~O:I69*/
                        /*~-2*/
                        else
                        {
                           /*~A:83*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A83*/
                        /*~-1*/
                        }
                        /*~E:I69*/
                        /*~-1*/
#endif
                        /*~E:I68*/
                     /*~-1*/
                     }
                     /*~E:I65*/
                     /*~E:A64*/
                     /*~A:84*/
                     /*~+:ACV - AutomaticCompensationValues*/
                     /*~I:85*/
                     if (!strcmp(szCommand,"ACV"))
                     /*~-1*/
                     {
                        /*~T*/
                        // Text wurde bereits gesendet
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:86*/
                        if (!InstructionDecoder_CheckNbParameters(2,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           // Parameter einlesen
                           // Kanal
                           Parameter[0].nLong = Communication_GetLongParameter(0);
                           // Welche Ausgabe
                           Parameter[1].nLong = Communication_GetLongParameter(1);

                           /*~I:87*/
                           if (Parameter[0].nLong < 2)
                           /*~-1*/
                           {
                              /*~I:88*/
                              if (!Parameter[0].nLong)
                              /*~-1*/
                              {
                              /*~I:89*/
#ifdef CHANNEL_1
                              /*~T*/
                              return;
                              /*~-1*/
#endif
                              /*~E:I89*/
                              /*~-1*/
                              }
                              /*~O:I88*/
                              /*~-2*/
                              else
                              {
                              /*~I:90*/
#ifdef CHANNEL_0
                              /*~T*/
                              return;
                              /*~-1*/
#endif
                              /*~E:I90*/
                              /*~-1*/
                              }
                              /*~E:I88*/
                              /*~T*/
                              // Zyklische Ausgabe unterdr�cken
                              Compensation_SuppressOutput(1);
                              /*~T*/
                              // Wert ausgeben
                              Compensation_PrintCompensationValues(0,Parameter[1].nLong,0,0);
                           /*~-1*/
                           }
                           /*~O:I87*/
                           /*~-2*/
                           else
                           {
                              /*~A:91*/
                              /*~+:Parameter au�erhalb des Bereichs*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~E:A91*/
                           /*~-1*/
                           }
                           /*~E:I87*/
                        /*~-1*/
                        }
                        /*~O:I86*/
                        /*~-2*/
                        else
                        {
                           /*~A:92*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A92*/
                        /*~-1*/
                        }
                        /*~E:I86*/
                     /*~-1*/
                     }
                     /*~E:I85*/
                     /*~E:A84*/
                     /*~A:93*/
                     /*~+:ART - AutomaticRecordTemperaturecompensation*/
                     /*~I:94*/
                     if (!strcmp(szCommand,"ART"))
                     /*~-1*/
                     {
                        /*~A:95*/
                        /*~+:Variablendeklarationen*/
                        /*~T*/
                        float fCalibrationFactor;
                        unsigned char chError;
                        unsigned char byCounter;
                        /*~E:A95*/
                        /*~A:96*/
                        /*~+:Variableninitialisierungen*/
                        /*~T*/
                        chError = 0;
                        byCounter = 3;

                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~E:A96*/
                        /*~I:97*/
                        if (!InstructionDecoder_CheckNbParameters(2,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0);
                           Parameter[1].nLong = Communication_GetLongParameter(1);
                           /*~I:98*/
                           if (Parameter[0].nLong < 6)
                           /*~-1*/
                           {
                              /*~A:99*/
                              /*~+:Kalibrierfaktor auslesen*/
                              /*~T*/
                              // Kalibrierfaktor auslesen
                              Measurement_GetCalibrationFactor(WEIGHT_WEIGHTCHANNEL,&fCalibrationFactor);
                              /*~E:A99*/
                              /*~C:100*/
                              switch (Parameter[0].nLong)
                              /*~-1*/
                              {
                              /*~A:101*/
                              /*~+:Kennlinienaufnahme stoppen*/
                              /*~F:102*/
                              case 0x00:
                              /*~-1*/
                              {
                              /*~T*/
                              // Synchronistaionspr�fung einschalten
                              System_SetCheckSynchronisation(TRUE);
                              /*~T*/
                              Digital_Init();
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F102*/
                              /*~E:A101*/
                              /*~A:103*/
                              /*~+:komplette Kennlinienaufnahme*/
                              /*~F:104*/
                              case 0x01:	// komplette Kennlinienaufnahme
                              /*~-1*/
                              {
                              /*~T*/
                              // Synchronistaionspr�fung ausschalten
                              System_SetCheckSynchronisation(FALSE);
                              /*~T*/
                              MRW_Compensation_InitRecCharacteristics(fCalibrationFactor,MRW_COMPENSATION_MODE_REC_DRIFT|MRW_COMPENSATION_MODE_REC_CHARACTERISTICS|MRW_COMPENSATION_MODE_TEST_COMPENSATION);
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F104*/
                              /*~E:A103*/
                              /*~A:105*/
                              /*~+:komplette Kennlinienaufnahme ohne �berpr�fung*/
                              /*~F:106*/
                              case 0x02:	// komplette Kennlinienaufnahme ohne �berpr�fung
                              /*~-1*/
                              {
                              /*~T*/
                              // Synchronistaionspr�fung ausschalten
                              System_SetCheckSynchronisation(FALSE);
                              /*~T*/
                              MRW_Compensation_InitRecCharacteristics(fCalibrationFactor,MRW_COMPENSATION_MODE_REC_DRIFT|MRW_COMPENSATION_MODE_REC_CHARACTERISTICS);
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F106*/
                              /*~E:A105*/
                              /*~A:107*/
                              /*~+:Kennlinienaufnahme ohne Drift und ohne �berpr�fung*/
                              /*~F:108*/
                              case 0x03:	// Kennlinienaufnahme ohne Drift und ohne �berpr�fung
                              /*~-1*/
                              {
                              /*~T*/
                              // Synchronistaionspr�fung ausschalten
                              System_SetCheckSynchronisation(FALSE);
                              /*~T*/
                              MRW_Compensation_InitRecCharacteristics(fCalibrationFactor,MRW_COMPENSATION_MODE_REC_CHARACTERISTICS);
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F108*/
                              /*~E:A107*/
                              /*~A:109*/
                              /*~+:�berpr�fung der Temperaturkompensation*/
                              /*~F:110*/
                              case 4:
                              /*~-1*/
                              {
                              /*~T*/
                              // Synchronistaionspr�fung ausschalten
                              System_SetCheckSynchronisation(FALSE);
                              /*~T*/
                              MRW_Compensation_InitRecCharacteristics(fCalibrationFactor,MRW_COMPENSATION_MODE_TEST_COMPENSATION);
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F110*/
                              /*~E:A109*/
                              /*~A:111*/
                              /*~+:�berpr�fung der Temperaturkompensation - nur f�r SW-Entwicklung*/
                              /*~F:112*/
                              case 5:
                              /*~-1*/
                              {
                              /*~T*/
                              // Synchronistaionspr�fung ausschalten
                              System_SetCheckSynchronisation(FALSE);
                              /*~T*/
                              MRW_Compensation_InitRecCharacteristics(fCalibrationFactor,MRW_COMPENSATION_TEST_1);
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F112*/
                              /*~E:A111*/
                              /*~-1*/
                              }
                              /*~E:C100*/
                              /*~I:113*/
                              if (Parameter[1].nLong)
                              /*~-1*/
                              {
                              /*~T*/
                              // mit zyklischer Ausgabe
                              Compensation_SuppressOutput(0);
                              /*~-1*/
                              }
                              /*~O:I113*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              // Zyklische Ausgabe unterdr�cken
                              Compensation_SuppressOutput(1);
                              /*~-1*/
                              }
                              /*~E:I113*/
                              /*~I:114*/
                              if (!GET_RESPONSE)
                              /*~-1*/
                              {
                              /*~I:115*/
                              if (!Parameter[0].nLong)
                              /*~-1*/
                              {
                              /*~T*/
                              // Kennlinienaufnahme stoppen
                              MRW_Compensation_SetRecCharacteristicsOn(0);

                              System_SetSystemState(SYSTEM_RUNNING);
                              /*~A:116*/
                              /*~+:Eintrag in Diagnosespeicher vornehmen*/
                              /*~T*/
                              ulDiagnosisEntry2Set = DIAGNOSIS_MESSAGE_TEMPCOMPENSATION_STOPPED;
                              /*~E:A116*/
                              /*~-1*/
                              }
                              /*~O:I115*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              // Kennlinienaufnahme starten
                              MRW_Compensation_SetRecCharacteristicsOn(1);

                              System_SetSystemState(SYSTEM_REC_CHARACTERISTICS_ON);

                              /*~A:117*/
                              /*~+:Eintrag in Diagnosespeicher vornehmen*/
                              /*~T*/
                              ulDiagnosisEntry2Set = DIAGNOSIS_MESSAGE_TEMPCOMPENSATION_STARTED;
                              /*~E:A117*/
                              /*~-1*/
                              }
                              /*~E:I115*/
                              /*~A:118*/
                              /*~+:Ausf�hrungsstatus auf 'OKAY' setzen*/
                              /*~+:*/
                              /*~T*/
                              // Ausf�hrungsstatus auf 'OKAY' setzen
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              /*~E:A118*/
                              /*~A:119*/
                              /*~+:Kanal 0*/
                              /*~I:120*/
#ifdef CHANNEL_0
                              /*~I:121*/
                              if (!Parameter[0].nLong)
                              /*~-1*/
                              {
                              /*~T*/
                              // Textausgabe vornehmen
                              lText2Send = TEXT_STOP_REC_CHARACTERISTICS;
                              /*~-1*/
                              }
                              /*~O:I121*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              // Textausgabe vornehmen
                              lText2Send = TEXT_START_REC_CHARACTERISTICS;
                              /*~-1*/
                              }
                              /*~E:I121*/
                              /*~-1*/
#endif
                              /*~E:I120*/
                              /*~E:A119*/
                              /*~-1*/
                              }
                              /*~O:I114*/
                              /*~-2*/
                              else
                              {
                              /*~K*/
                              /*~+:Fehler !!!*/
                              /*~I:122*/
#ifdef CHANNEL_0
                              /*~A:123*/
                              /*~+:Kennlinienaufnahme im Kanal 1 zus�tzlich stoppen*/
                              /*~U:124*/
                              /*~-2*/
                              do
                              {
                              /*~T*/
                              Communication_SendSPICommand("iART");
                              /*~-1*/
                              }
                              /*~O:U124*/
                              while (!Communication_IsOK() && --byCounter);
                              /*~E:U124*/
                              /*~E:A123*/
                              /*~A:125*/
                              /*~+:Ausf�hrungsstatus auf 'E005' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A125*/
                              /*~-1*/
#endif
                              /*~E:I122*/
                              /*~-1*/
                              }
                              /*~E:I114*/
                           /*~-1*/
                           }
                           /*~O:I98*/
                           /*~-2*/
                           else
                           {
                              /*~A:126*/
                              /*~+:Kanal 0*/
                              /*~I:127*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I127*/
                              /*~E:A126*/
                           /*~-1*/
                           }
                           /*~E:I98*/
                        /*~-1*/
                        }
                        /*~O:I97*/
                        /*~-2*/
                        else
                        {
                           /*~A:128*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A128*/
                        /*~-1*/
                        }
                        /*~E:I97*/
                     /*~-1*/
                     }
                     /*~E:I94*/
                     /*~E:A93*/
                     /*~T*/
                     break;
                  /*~-1*/
                  }
                  /*~E:F63*/
                  /*~E:A62*/
                  /*~A:129*/
                  /*~+:C*/
                  /*~F:130*/
                  case 'C':
                  /*~-1*/
                  {
                     /*~A:131*/
                     /*~+:CAA - ClearActualAlarmstatus*/
                     /*~I:132*/
                     if (!strcmp(szCommand,"CAA"))
                     /*~-1*/
                     {
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:133*/
                        if (!InstructionDecoder_CheckNbParameters(0,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~I:134*/
                           if (!GET_RESPONSE)
                           /*~-1*/
                           {
                              /*~T*/
                              // System in den normalen Betriebsmodus versetzen
                              System_ClearSystemError();
                              /*~A:135*/
                              /*~+:Ausf�hrungsstatus auf 'OKAY' setzen*/
                              /*~+:*/
                              /*~T*/
                              // Ausf�hrungsstatus auf 'OKAY' setzen
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              /*~E:A135*/
                              /*~A:136*/
                              /*~+:Kanal 0*/
                              /*~I:137*/
#ifdef CHANNEL_0
                              /*~A:138*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              lText2Send = TEXT_ALARM_STATUS_CLEARED;
                              /*~E:A138*/
                              /*~-1*/
#endif
                              /*~E:I137*/
                              /*~E:A136*/
                           /*~-1*/
                           }
                           /*~O:I134*/
                           /*~-2*/
                           else
                           {
                              /*~K*/
                              /*~+:Fehler !!!*/
                              /*~A:139*/
                              /*~+:Ausf�hrungsstatus auf 'E005' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A139*/
                           /*~-1*/
                           }
                           /*~E:I134*/
                        /*~-1*/
                        }
                        /*~O:I133*/
                        /*~-2*/
                        else
                        {
                           /*~A:140*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A140*/
                        /*~-1*/
                        }
                        /*~E:I133*/
                     /*~-1*/
                     }
                     /*~E:I132*/
                     /*~E:A131*/
                     /*~A:141*/
                     /*~+:CAS - ClearAlarmStatus*/
                     /*~I:142*/
                     if (!strcmp(szCommand,"CAS"))
                     /*~-1*/
                     {
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:143*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0);
                           /*~A:144*/
                           /*~+:Kanal 1 - ADMINCODE automatisch vorgeben*/
                           /*~I:145*/
#ifdef CHANNEL_1
                           /*~T*/
                           Parameter[0].nLong = ADMINCODE;
                           /*~-1*/
#endif
                           /*~E:I145*/
                           /*~E:A144*/
                           /*~I:146*/
                           if (
                           	(Parameter[0].nLong == ADMINCODE)			// Passwort
                           	||
                           	(Parameter[0].nLong = 1399)
                           )
                           /*~-1*/
                           {
                              /*~I:147*/
                              if (!GET_RESPONSE)
                              /*~-1*/
                              {
                              /*~T*/
                              Diagnosis_ClearDiagnosis(DIAGNOSIS_CLEAR_ALL);
                              /*~T*/
                              // System in den normalen Betriebsmodus versetzen
                              System_ClearSystemError();
                              /*~A:148*/
                              /*~+:Ausf�hrungsstatus auf 'OKAY' setzen*/
                              /*~+:*/
                              /*~T*/
                              // Ausf�hrungsstatus auf 'OKAY' setzen
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              /*~E:A148*/
                              /*~A:149*/
                              /*~+:Kanal 0 - Textausgabe*/
                              /*~I:150*/
#ifdef CHANNEL_0 
                              /*~A:151*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              lText2Send = TEXT_DIAGNOSIS_MEMORY_CLEARED;
                              /*~E:A151*/
                              /*~-1*/
#endif
                              /*~E:I150*/
                              /*~E:A149*/
                              /*~-1*/
                              }
                              /*~O:I147*/
                              /*~-2*/
                              else
                              {
                              /*~K*/
                              /*~+:Fehler !!!*/
                              /*~A:152*/
                              /*~+:Ausf�hrungsstatus auf 'E005' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A152*/
                              /*~-1*/
                              }
                              /*~E:I147*/
                           /*~-1*/
                           }
                           /*~O:I146*/
                           /*~-2*/
                           else
                           {
                              /*~K*/
                              /*~+:// Parameterfehler*/
                              /*~A:153*/
                              /*~+:Kanal 0*/
                              /*~I:154*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E002;
                              /*~-1*/
#endif
                              /*~E:I154*/
                              /*~E:A153*/
                              /*~A:155*/
                              /*~+:Kanal 1 - NAK ausgeben*/
                              /*~I:156*/
#ifdef CHANNEL_1
                              /*~T*/
                              Communication_SendMessage(COMMUNICATION_SPI,COMMUNICATION_NAK);
                              /*~-1*/
#endif
                              /*~E:I156*/
                              /*~E:A155*/
                           /*~-1*/
                           }
                           /*~E:I146*/
                        /*~-1*/
                        }
                        /*~O:I143*/
                        /*~-2*/
                        else
                        {
                           /*~A:157*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A157*/
                        /*~-1*/
                        }
                        /*~E:I143*/
                     /*~-1*/
                     }
                     /*~E:I142*/
                     /*~E:A141*/
                     /*~A:158*/
                     /*~+:CDB - ClearDeBug*/
                     /*~I:159*/
#ifdef MIT_DEBUG
                     /*~I:160*/
                     if (!strcmp(szCommand,"CDB"))
                     /*~-1*/
                     {
                        /*~A:161*/
                        /*~+:Variablendeklarationen*/
                        /*~T*/
                        long lDebVar[DEBUG_NB_DEBUGVARIABLES];
                        /*~E:A161*/
                        /*~A:162*/
                        /*~+:Variableninitialisierungen*/
                        /*~T*/

                        /*~E:A162*/
                        /*~T*/
                        // Text wurde bereits gesendet
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:163*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0);
                           Parameter[1].nLong = Communication_GetLongParameter(1);
                           /*~C:164*/
                           switch (Parameter[0].nLong)
                           /*~-1*/
                           {
                              /*~F:165*/
                              case 0:
                              /*~-1*/
                              {
                              /*~A:166*/
                              /*~+:Kanal 0*/
                              /*~I:167*/
#ifdef CHANNEL_0
                              /*~I:168*/
                              if (Parameter[1].nLong == 255)
                              /*~-1*/
                              {
                              /*~T*/
                              memset(lDebVar,0,32);
                              /*~T*/
                              Communication_SendString(COMMUNICATION_RS232,T_TEXT_CONTENT_DEBUG_VARIABLES_CLEARED_ALL_CHANNEL_0,1,0);
                              /*~-1*/
                              }
                              /*~O:I168*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              // Debug-Variablen aus dem Eeprom laden
                              Load_Parameter(LOAD_SAVE_DEBUG_VARIABLES,lDebVar,4*DEBUG_NB_DEBUGVARIABLES);
                              /*~T*/
                              lDebVar[Parameter[1].nLong] = 0;
                              /*~T*/
                              // Text
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_CONFIRMATION_DEBUG_VARIABLES_CLEARED_CHANNEL_0,Parameter[1].nLong,1,0);
                              /*~-1*/
                              }
                              /*~E:I168*/
                              /*~T*/
                              // Debug-Variablen in das Eeprom schreiben
                              Save_Parameter(LOAD_SAVE_DEBUG_VARIABLES,lDebVar,4*DEBUG_NB_DEBUGVARIABLES);
                              /*~-1*/
#endif
                              /*~E:I167*/
                              /*~E:A166*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F165*/
                              /*~F:169*/
                              case 1:
                              /*~-1*/
                              {
                              /*~A:170*/
                              /*~+:Kanal 1*/
                              /*~I:171*/
#ifdef CHANNEL_1
                              /*~I:172*/
                              if (Parameter[1].nLong == 255)
                              /*~-1*/
                              {
                              /*~T*/
                              memset(lDebVar,0,32);
                              /*~T*/
                              Communication_SendString(COMMUNICATION_RS232,T_TEXT_CONTENT_DEBUG_VARIABLES_CLEARED_ALL_CHANNEL_1,1,0);
                              /*~-1*/
                              }
                              /*~O:I172*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              // Debug-Variablen aus dem Eeprom laden
                              Load_Parameter(LOAD_SAVE_DEBUG_VARIABLES,lDebVar,4*DEBUG_NB_DEBUGVARIABLES);
                              /*~T*/
                              lDebVar[Parameter[1].nLong] = 0;
                              /*~T*/
                              // Text
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_CONFIRMATION_DEBUG_VARIABLES_CLEARED_CHANNEL_1,Parameter[1].nLong,1,0);
                              /*~-1*/
                              }
                              /*~E:I172*/
                              /*~T*/
                              // Debug-Variablen in das Eeprom schreiben
                              Save_Parameter(LOAD_SAVE_DEBUG_VARIABLES,lDebVar,4*DEBUG_NB_DEBUGVARIABLES);
                              /*~-1*/
#endif
                              /*~E:I171*/
                              /*~E:A170*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F169*/
                              /*~O:C164*/
                              /*~-2*/
                              default:
                              {
                              /*~A:173*/
                              /*~+:Kanal 0*/
                              /*~I:174*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I174*/
                              /*~E:A173*/
                              /*~-1*/
                              }
                           /*~-1*/
                           }
                           /*~E:C164*/
                        /*~-1*/
                        }
                        /*~O:I163*/
                        /*~-2*/
                        else
                        {
                           /*~A:175*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A175*/
                        /*~-1*/
                        }
                        /*~E:I163*/
                     /*~-1*/
                     }
                     /*~E:I160*/
                     /*~-1*/
#endif
                     /*~E:I159*/
                     /*~E:A158*/
                     /*~I:176*/
#ifdef MOF
                     /*~A:177*/
                     /*~+:CDG - ClearDiaGnosis*/
                     /*~I:178*/
                     if ((!strcmp(szCommand,"CAS"))||(!strcmp(szCommand,"CDG")))
                     /*~-1*/
                     {
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:179*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0);
                           /*~A:180*/
                           /*~+:Kanal 1 - ADMINCODE automatisch vorgeben*/
                           /*~I:181*/
#ifdef CHANNEL_1
                           /*~T*/
                           Parameter[0].nLong = ADMINCODE;
                           /*~-1*/
#endif
                           /*~E:I181*/
                           /*~E:A180*/
                           /*~I:182*/
                           if (
                           	(Parameter[0].nLong == ADMINCODE)			// Passwort
                           	||
                           	(Parameter[0].nLong = 1399)
                           )
                           /*~-1*/
                           {
                              /*~I:183*/
                              if (!GET_RESPONSE)
                              /*~-1*/
                              {
                              /*~T*/
                              Diagnosis_ClearDiagnosis(DIAGNOSIS_CLEAR_ALL);
                              /*~T*/
                              // System in den normalen Betriebsmodus versetzen
                              System_ClearSystemError();
                              /*~A:184*/
                              /*~+:Ausf�hrungsstatus auf 'OKAY' setzen*/
                              /*~+:*/
                              /*~T*/
                              // Ausf�hrungsstatus auf 'OKAY' setzen
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              /*~E:A184*/
                              /*~A:185*/
                              /*~+:Kanal 0 - Textausgabe*/
                              /*~I:186*/
#ifdef CHANNEL_0 
                              /*~A:187*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              lText2Send = TEXT_DIAGNOSIS_MEMORY_CLEARED;
                              /*~E:A187*/
                              /*~-1*/
#endif
                              /*~E:I186*/
                              /*~E:A185*/
                              /*~-1*/
                              }
                              /*~O:I183*/
                              /*~-2*/
                              else
                              {
                              /*~K*/
                              /*~+:Fehler !!!*/
                              /*~A:188*/
                              /*~+:Ausf�hrungsstatus auf 'E005' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A188*/
                              /*~-1*/
                              }
                              /*~E:I183*/
                           /*~-1*/
                           }
                           /*~O:I182*/
                           /*~-2*/
                           else
                           {
                              /*~K*/
                              /*~+:// Parameterfehler*/
                              /*~A:189*/
                              /*~+:Kanal 0*/
                              /*~I:190*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E002;
                              /*~-1*/
#endif
                              /*~E:I190*/
                              /*~E:A189*/
                              /*~A:191*/
                              /*~+:Kanal 1 - NAK ausgeben*/
                              /*~I:192*/
#ifdef CHANNEL_1
                              /*~T*/
                              Communication_SendMessage(COMMUNICATION_SPI,COMMUNICATION_NAK);
                              /*~-1*/
#endif
                              /*~E:I192*/
                              /*~E:A191*/
                           /*~-1*/
                           }
                           /*~E:I182*/
                        /*~-1*/
                        }
                        /*~O:I179*/
                        /*~-2*/
                        else
                        {
                           /*~A:193*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A193*/
                        /*~-1*/
                        }
                        /*~E:I179*/
                     /*~-1*/
                     }
                     /*~E:I178*/
                     /*~E:A177*/
                     /*~-1*/
#endif
                     /*~E:I176*/
                     /*~A:194*/
                     /*~+:CDL - Connect2DockLight*/
                     /*~I:195*/
                     if (!strcmp(szCommand,"CDL"))
                     /*~-1*/
                     {
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:196*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0);
                           /*~I:197*/
                           if (!Parameter[0].nLong)
                           /*~-1*/
                           {
                              /*~K*/
                              /*~+:// Docklight-Modus ausschalten*/
                              /*~T*/
                              System_Connect2MRW_Manager(1);
                              /*~A:198*/
                              /*~+:Textausgabe �ber Kanal 0*/
                              /*~I:199*/
#ifdef CHANNEL_0
                              /*~T*/
                              // Communication_SendString(COMMUNICATION_RS232,TEXT_DOCKLIGHT_MODE_CLEARED,0,1);
                              Communication_SendString(COMMUNICATION_RS232,T_TEXT_3_OKAY,0,1);
                              /*~-1*/
#endif
                              /*~E:I199*/
                              /*~E:A198*/
                           /*~-1*/
                           }
                           /*~O:I197*/
                           /*~-2*/
                           else
                           {
                              /*~K*/
                              /*~+:// Docklight-Modus einschalten*/
                              /*~T*/
                              System_Connect2MRW_Manager(0);
                              /*~A:200*/
                              /*~+:Textausgabe �ber Kanal 0*/
                              /*~I:201*/
#ifdef CHANNEL_0
                              /*~T*/
                              Communication_SendString(COMMUNICATION_RS232,T_TEXT_DOCKLIGHT_MODE_SET,1,1);
                              /*~-1*/
#endif
                              /*~E:I201*/
                              /*~E:A200*/
                           /*~-1*/
                           }
                           /*~E:I197*/
                        /*~-1*/
                        }
                        /*~O:I196*/
                        /*~-2*/
                        else
                        {
                           /*~A:202*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A202*/
                        /*~-1*/
                        }
                        /*~E:I196*/
                     /*~-1*/
                     }
                     /*~E:I195*/
                     /*~E:A194*/
                     /*~I:203*/
#ifdef MOF
                     /*~A:204*/
                     /*~+:CEI,CEK,CRI - ClearEepromId*/
                     /*~I:205*/
                     if ((!strcmp(szCommand,"CEI"))||(!strcmp(szCommand,"CEK"))||(!strcmp(szCommand,"CRI")))
                     /*~-1*/
                     {
                        /*~A:206*/
                        /*~+:Variablendeklarationen*/
                        /*~T*/
                        unsigned long ulID;
                        /*~E:A206*/
                        /*~A:207*/
                        /*~+:Variableninitialisierungen*/
                        /*~T*/
                        ulID = 0L;

                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~E:A207*/
                        /*~I:208*/
                        if (!InstructionDecoder_CheckNbParameters(0,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~I:209*/
                           if (!GET_RESPONSE)
                           /*~-1*/
                           {
                              /*~A:210*/
                              /*~+:ausgeklammert - hier besteht die M�glichkeit, das Eeprom als jungfr�ulich zu deklarieren - es wird auch die ID gel�scht !!!*/
                              /*~I:211*/
#ifdef MOF
                              /*~I:212*/
                              if (!strcmp(szCommand,"CRI"))
                              /*~-1*/
                              {
                              /*~T*/
                              // Kennung zur Neuinitialisierung setzen
                              ulID = 0xAAAA5555;
                              /*~-1*/
                              }
                              /*~O:I212*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              // Kennung l�schen - System jungfr�ulich
                              ulID = 0;
                              /*~-1*/
                              }
                              /*~E:I212*/
                              /*~-1*/
#endif
                              /*~E:I211*/
                              /*~E:A210*/
                              /*~T*/
                              Save_Parameter(LOAD_SAVE_INITIALIZE_IDENTIFICATION,&ulID,0);
                              /*~A:213*/
                              /*~+:Ausf�hrungsstatus auf 'OKAY' setzen*/
                              /*~+:*/
                              /*~T*/
                              // Ausf�hrungsstatus auf 'OKAY' setzen
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              /*~E:A213*/
                              /*~A:214*/
                              /*~+:Kanal 0 - Textausgabe*/
                              /*~I:215*/
#ifdef CHANNEL_0
                              /*~A:216*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              lText2Send = TEXT_RESTART_HARDWARE;
                              /*~E:A216*/
                              /*~-1*/
#endif
                              /*~E:I215*/
                              /*~E:A214*/
                           /*~-1*/
                           }
                           /*~O:I209*/
                           /*~-2*/
                           else
                           {
                              /*~K*/
                              /*~+:Fehler !!!*/
                              /*~A:217*/
                              /*~+:Ausf�hrungsstatus auf 'E005' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A217*/
                           /*~-1*/
                           }
                           /*~E:I209*/
                        /*~-1*/
                        }
                        /*~O:I208*/
                        /*~-2*/
                        else
                        {
                           /*~A:218*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A218*/
                        /*~-1*/
                        }
                        /*~E:I208*/
                     /*~-1*/
                     }
                     /*~E:I205*/
                     /*~E:A204*/
                     /*~-1*/
#endif
                     /*~E:I203*/
                     /*~A:219*/
                     /*~+:CEK - ClearEepromKennung*/
                     /*~I:220*/
                     if (!strcmp(szCommand,"CEK"))
                     /*~-1*/
                     {
                        /*~A:221*/
                        /*~+:Variablendeklarationen*/
                        /*~T*/
                        unsigned long ulID;
                        /*~E:A221*/
                        /*~A:222*/
                        /*~+:Variableninitialisierungen*/
                        /*~T*/
                        ulID = 0L;

                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~E:A222*/
                        /*~I:223*/
                        if (!InstructionDecoder_CheckNbParameters(0,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~I:224*/
                           if (!GET_RESPONSE)
                           /*~-1*/
                           {
                              /*~A:225*/
                              /*~+:ausgeklammert - hier besteht die M�glichkeit, das Eeprom als jungfr�ulich zu deklarieren - es wird auch die ID gel�scht !!!*/
                              /*~I:226*/
#ifdef MOF
                              /*~I:227*/
                              if (!strcmp(szCommand,"CRI"))
                              /*~-1*/
                              {
                              /*~T*/
                              // Kennung zur Neuinitialisierung setzen
                              ulID = 0xAAAA5555;
                              /*~-1*/
                              }
                              /*~O:I227*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              // Kennung l�schen - System jungfr�ulich
                              ulID = 0;
                              /*~-1*/
                              }
                              /*~E:I227*/
                              /*~-1*/
#endif
                              /*~E:I226*/
                              /*~E:A225*/
                              /*~T*/
                              Save_Parameter(LOAD_SAVE_INITIALIZE_IDENTIFICATION,&ulID,0);
                              /*~A:228*/
                              /*~+:Ausf�hrungsstatus auf 'OKAY' setzen*/
                              /*~+:*/
                              /*~T*/
                              // Ausf�hrungsstatus auf 'OKAY' setzen
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              /*~E:A228*/
                              /*~A:229*/
                              /*~+:Kanal 0 - Textausgabe*/
                              /*~I:230*/
#ifdef CHANNEL_0
                              /*~A:231*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              lText2Send = TEXT_RESTART_HARDWARE;
                              /*~E:A231*/
                              /*~-1*/
#endif
                              /*~E:I230*/
                              /*~E:A229*/
                           /*~-1*/
                           }
                           /*~O:I224*/
                           /*~-2*/
                           else
                           {
                              /*~K*/
                              /*~+:Fehler !!!*/
                              /*~A:232*/
                              /*~+:Ausf�hrungsstatus auf 'E005' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A232*/
                           /*~-1*/
                           }
                           /*~E:I224*/
                        /*~-1*/
                        }
                        /*~O:I223*/
                        /*~-2*/
                        else
                        {
                           /*~A:233*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A233*/
                        /*~-1*/
                        }
                        /*~E:I223*/
                     /*~-1*/
                     }
                     /*~E:I220*/
                     /*~E:A219*/
                     /*~A:234*/
                     /*~+:CIC - CurrentInterfaceCalibration*/
                     /*~I:235*/
                     if (!strcmp(szCommand,"CIC"))
                     /*~-1*/
                     {
                        /*~A:236*/
                        /*~+:Variablendeklarationen*/
                        /*~I:237*/
#ifdef SYSTEM_CND_WITH_DEADBAND_FILTER
                        /*~T*/
                        int nBandWidth;
                        /*~-1*/
#endif
                        /*~E:I237*/
                        /*~E:A236*/
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:238*/
                        if (!InstructionDecoder_CheckNbParameters(3,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           // Parameter einlesen
                           Parameter[0].nLong = Communication_GetLongParameter(0);
                           Parameter[1].nLong = Communication_GetLongParameter(1);

                           /*~T*/
                           Parameter[2].fFloat = Communication_GetFloatParameter(2);
                           /*~C:239*/
                           switch (Parameter[0].nLong)
                           /*~-1*/
                           {
                              /*~F:240*/
                              case 0:
                              /*~-1*/
                              {
                              /*~A:241*/
                              /*~+:Kanal 0*/
                              /*~I:242*/
#ifdef CHANNEL_0
                              /*~C:243*/
                              switch (Parameter[1].nLong)
                              /*~-1*/
                              {
                              /*~A:244*/
                              /*~+:Initialisierung */
                              /*~F:245*/
                              case 0:		// Initialisierung
                              /*~-1*/
                              {
                              /*~I:246*/
#ifndef OHNE_STROMRUECKFUEHRUNG 
                              /*~A:247*/
                              /*~+:Mitteilung, dass die Stromr�ckf�hrung ausgeschaltet wurde*/
                              /*~I:248*/
                              if (!SYSTEM_MRW_MANAGER)
                              /*~-1*/
                              {
                              /*~T*/
                              // Mitteilung, dass die Stromr�ckf�hrung ausgeschaltet wurde
                              Communication_SendString(COMMUNICATION_RS232,T_TEXT_FEEDBACK_STATE_OFF,1,0);

                              /*~-1*/
                              }
                              /*~E:I248*/
                              /*~E:A247*/
                              /*~T*/
                              // Stromr�ckf�hrung ausschalten
                              CurrentInterface_SetFeedBackOnOff(0,0);
                              /*~-1*/
#endif
                              /*~E:I246*/
                              /*~I:249*/
#ifdef SYSTEM_CND_WITH_DEADBAND_FILTER
                              /*~A:250*/
                              /*~+:Totbandfilter-Bandbreite f�r die Gewichtsermittlung ausschalten*/
                              /*~T*/
                              // Totbandfilter-Bandbreite f�r die Gewichtsermittlung ausschalten
                              DeadBandFilter_Setup(0,0,DEADBANDFILTER_LONGDATA);

                              /*~E:A250*/
                              /*~-1*/
#endif
                              /*~E:I249*/
                              /*~T*/
                              CurrentInterface_Ini(0);
                              /*~T*/
                              ulDiagnosisEntry2Set = DIAGNOSIS_MESSAGE_DAC_CALIBRATION_CLEARED;
                              /*~A:251*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              lText2Send = TEXT_CURRENT_INTERFACE_INITIALIZED_CHANNEL_0;
                              /*~E:A251*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F245*/
                              /*~E:A244*/
                              /*~A:252*/
                              /*~+:Vorbereitung f�r 1.Referenzpunkt*/
                              /*~F:253*/
                              case 1:		// Vorbereitung f�r 1.Referenzpunkt
                              /*~-1*/
                              {
                              /*~T*/
                              CurrentInterface_PrepareCalibration(1,Parameter[2].fFloat);
                              /*~A:254*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              lText2Send = TEXT_CURRENT_INTERFACE_PREPARE_4_CAL_1ST_POINT_CHANNEL_0;
                              /*~E:A254*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F253*/
                              /*~E:A252*/
                              /*~A:255*/
                              /*~+:Ersten Referenzpunkt setzen*/
                              /*~F:256*/
                              case 2:		// Ersten Referenzpunkt setzen
                              /*~-1*/
                              {
                              /*~T*/
                              CurrentInterface_Calibration(0,Parameter[2].fFloat);
                              /*~A:257*/
                              /*~+:Eintrag in Diagnosespeicher vornehmen*/
                              /*~T*/
                              ulDiagnosisEntry2Set = DIAGNOSIS_MESSAGE_DAC_1ST_POINT_CALIBRATION_SET;
                              /*~E:A257*/
                              /*~A:258*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              lText2Send = TEXT_CURRENT_INTERFACE_1ST_CAL_POINT_SET_CHANNEL_0;
                              /*~E:A258*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F256*/
                              /*~E:A255*/
                              /*~A:259*/
                              /*~+:Vorbereitung f�r 2.Referenzpunkt*/
                              /*~F:260*/
                              case 3:		// Vorbereitung f�r 2.Referenzpunkt
                              /*~-1*/
                              {
                              /*~T*/
                              CurrentInterface_PrepareCalibration(2,Parameter[2].fFloat);
                              /*~A:261*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              lText2Send = TEXT_CURRENT_INTERFACE_PREPARE_4_CAL_2ND_POINT_CHANNEL_0;
                              /*~E:A261*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F260*/
                              /*~E:A259*/
                              /*~A:262*/
                              /*~+:Zweiten Referenzpunkt setzen*/
                              /*~F:263*/
                              case 4:		// Zweiten Referenzpunkt setzen
                              /*~-1*/
                              {
                              /*~I:264*/
                              if(!CurrentInterface_Calibration(1,Parameter[2].fFloat))
                              /*~-1*/
                              {
                              /*~A:265*/
                              /*~+:Eintrag in Diagnosespeicher vornehmen*/
                              /*~T*/
                              ulDiagnosisEntry2Set = DIAGNOSIS_MESSAGE_DAC_2ND_POINT_CALIBRATION_SET;
                              /*~E:A265*/
                              /*~A:266*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              lText2Send = TEXT_CURRENT_INTERFACE_2ND_CAL_POINT_SET_CHANNEL_0;
                              /*~E:A266*/
                              /*~-1*/
                              }
                              /*~O:I264*/
                              /*~-2*/
                              else
                              {
                              /*~K*/
                              /*~+:Fehler*/
                              /*~A:267*/
                              /*~+:Text f�r Terminalbetrieb "E005"*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              lText2Send = TEXT_ERROR_1ST_REFPOINT_MISSING;
                              /*~E:A267*/
                              /*~-1*/
                              }
                              /*~E:I264*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F263*/
                              /*~E:A262*/
                              /*~A:268*/
                              /*~+:Kalibrierung speichern*/
                              /*~F:269*/
                              case 5:		// Kalibrierung speichern
                              /*~-1*/
                              {
                              /*~A:270*/
                              /*~+:Grenzwerte setzen*/
                              /*~T*/
                              // Grenzwerte setzen
                              Limit_SetAlarmLimits();
                              /*~E:A270*/
                              /*~I:271*/
#ifndef OHNE_STROMRUECKFUEHRUNG 
                              /*~A:272*/
                              /*~+:Strom-R�ckf�hrung aktivieren*/
                              /*~T*/
                              // Strom-R�ckf�hrung aktivieren
                              CurrentInterface_SetFeedBackOnOff(1,0);
                              /*~E:A272*/
                              /*~A:273*/
                              /*~+:Mitteilung, dass die Stromr�ckf�hrung eingeschaltet wurde*/
                              /*~I:274*/
                              if (!SYSTEM_MRW_MANAGER)
                              /*~-1*/
                              {
                              /*~T*/
                              // Mitteilung, dass die Stromr�ckf�hrung eingeschaltet wurde
                              Communication_SendString(COMMUNICATION_RS232,T_TEXT_FEEDBACK_STATE_ON,1,0);

                              /*~-1*/
                              }
                              /*~E:I274*/
                              /*~E:A273*/
                              /*~-1*/
#endif
                              /*~E:I271*/
                              /*~I:275*/
#ifdef SYSTEM_CND_WITH_DEADBAND_FILTER 
                              /*~A:276*/
                              /*~+:Totbandfilter-Bandbreite f�r die Gewichtsermittlung wieder in Ursprungszustand versetzen*/
                              /*~T*/
                              // Totbandfilter-Bandbreite f�r die Gewichtsermittlung laden
                              Load_Parameter(LOAD_SAVE_FILTER_BANDWIDTH_WEIGHT,&nBandWidth,0);

                              DeadBandFilter_Setup(0,(float)nBandWidth,DEADBANDFILTER_LONGDATA);

                              /*~E:A276*/
                              /*~-1*/
#endif
                              /*~E:I275*/
                              /*~A:277*/
                              /*~+:Eintrag in Diagnosespeicher vornehmen*/
                              /*~T*/
                              ulDiagnosisEntry2Set = DIAGNOSIS_MESSAGE_DAC_CALIBRATION_FINISHED;
                              /*~E:A277*/
                              /*~T*/
                              CurrentInterface_SaveDACSettings(CURRENTINTERFACE_ALL_SETTINGS);
                              /*~T*/
                              // Simulation des Rohmesswerts ausschalten
                              CurrentInterface_PrepareCalibration(0,0);
                              /*~A:278*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              /*~T*/
                              lText2Send = TEXT_CURRENT_INTERFACE_CALIBRATION_FINISHED_CHANNEL_0;
                              /*~E:A278*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F269*/
                              /*~E:A268*/
                              /*~O:C243*/
                              /*~-2*/
                              default:
                              {
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E002;
                              /*~-1*/
                              }
                              /*~-1*/
                              }
                              /*~E:C243*/
                              /*~-1*/
#endif
                              /*~E:I242*/
                              /*~T*/
                              break;
                              /*~E:A241*/
                              /*~-1*/
                              }
                              /*~E:F240*/
                              /*~F:279*/
                              case 1:
                              /*~-1*/
                              {
                              /*~A:280*/
                              /*~+:Kanal 1*/
                              /*~I:281*/
#ifdef CHANNEL_1 
                              /*~C:282*/
                              switch (Parameter[1].nLong)
                              /*~-1*/
                              {
                              /*~A:283*/
                              /*~+:Initialisierung*/
                              /*~F:284*/
                              case 0:		// Initialisierung
                              /*~-1*/
                              {
                              /*~I:285*/
#ifndef OHNE_STROMRUECKFUEHRUNG 
                              /*~A:286*/
                              /*~+:Mitteilung, dass die Stromr�ckf�hrung ausgeschaltet wurde*/
                              /*~I:287*/
                              if (!SYSTEM_MRW_MANAGER)
                              /*~-1*/
                              {
                              /*~T*/
                              // Mitteilung, dass die Stromr�ckf�hrung ausgeschaltet wurde
                              Communication_SendString(COMMUNICATION_RS232,T_TEXT_FEEDBACK_STATE_OFF,1,0);

                              /*~-1*/
                              }
                              /*~E:I287*/
                              /*~E:A286*/
                              /*~T*/
                              // Stromr�ckf�hrung ausschalten
                              CurrentInterface_SetFeedBackOnOff(0,0);
                              /*~-1*/
#endif
                              /*~E:I285*/
                              /*~I:288*/
#ifdef SYSTEM_CND_WITH_DEADBAND_FILTER
                              /*~A:289*/
                              /*~+:Totbandfilter-Bandbreite f�r die Gewichtsermittlung ausschalten*/
                              /*~T*/
                              // Totbandfilter-Bandbreite f�r die Gewichtsermittlung ausschalten
                              DeadBandFilter_Setup(0,0,DEADBANDFILTER_LONGDATA);

                              /*~E:A289*/
                              /*~-1*/
#endif
                              /*~E:I288*/
                              /*~T*/
                              CurrentInterface_Ini(0);
                              /*~A:290*/
                              /*~+:Eintrag in Diagnosespeicher vornehmen*/
                              /*~T*/
                              ulDiagnosisEntry2Set = DIAGNOSIS_MESSAGE_DAC_CALIBRATION_CLEARED;
                              /*~E:A290*/
                              /*~A:291*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              lText2Send = TEXT_CURRENT_INTERFACE_INITIALIZED_CHANNEL_1;
                              /*~E:A291*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F284*/
                              /*~E:A283*/
                              /*~A:292*/
                              /*~+:Vorbereitung f�r 1.Referenzpunkt*/
                              /*~F:293*/
                              case 1:		// Vorbereitung f�r 1.Referenzpunkt
                              /*~-1*/
                              {
                              /*~T*/
                              CurrentInterface_PrepareCalibration(1,Parameter[2].fFloat);
                              /*~A:294*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              lText2Send = TEXT_CURRENT_INTERFACE_PREPARE_4_CAL_1ST_POINT_CHANNEL_1;
                              /*~E:A294*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F293*/
                              /*~E:A292*/
                              /*~A:295*/
                              /*~+:Ersten Referenzpunkt setzen*/
                              /*~F:296*/
                              case 2:		// Ersten Referenzpunkt setzen
                              /*~-1*/
                              {
                              /*~I:297*/
                              if(!CurrentInterface_Calibration(0,Parameter[2].fFloat))
                              /*~-1*/
                              {
                              /*~A:298*/
                              /*~+:Eintrag in Diagnosespeicher vornehmen*/
                              /*~T*/
                              ulDiagnosisEntry2Set = DIAGNOSIS_MESSAGE_DAC_1ST_POINT_CALIBRATION_SET;
                              /*~E:A298*/
                              /*~A:299*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              lText2Send = TEXT_CURRENT_INTERFACE_1ST_CAL_POINT_SET_CHANNEL_1;
                              /*~E:A299*/
                              /*~-1*/
                              }
                              /*~O:I297*/
                              /*~-2*/
                              else
                              {
                              /*~K*/
                              /*~+:Fehler*/
                              /*~A:300*/
                              /*~+:Text f�r Terminalbetrieb "E005"*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              lText2Send = TEXT_ERROR_WEIGHT_INSTABILE;
                              /*~E:A300*/
                              /*~-1*/
                              }
                              /*~E:I297*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F296*/
                              /*~E:A295*/
                              /*~A:301*/
                              /*~+:Vorbereitung f�r 2.Referenzpunkt*/
                              /*~F:302*/
                              case 3:		// Vorbereitung f�r 2.Referenzpunkt
                              /*~-1*/
                              {
                              /*~T*/
                              CurrentInterface_PrepareCalibration(2,Parameter[2].fFloat);
                              /*~A:303*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              lText2Send = TEXT_CURRENT_INTERFACE_PREPARE_4_CAL_2ND_POINT_CHANNEL_1;
                              /*~E:A303*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F302*/
                              /*~E:A301*/
                              /*~A:304*/
                              /*~+:Zweiten Referenzpunkt setzen*/
                              /*~F:305*/
                              case 4:		// Zweiten Referenzpunkt setzen
                              /*~-1*/
                              {
                              /*~I:306*/
                              if(!CurrentInterface_Calibration(1,Parameter[2].fFloat))
                              /*~-1*/
                              {
                              /*~A:307*/
                              /*~+:Eintrag in Diagnosespeicher vornehmen*/
                              /*~T*/
                              ulDiagnosisEntry2Set = DIAGNOSIS_MESSAGE_DAC_2ND_POINT_CALIBRATION_SET;
                              /*~E:A307*/
                              /*~A:308*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              lText2Send = TEXT_CURRENT_INTERFACE_2ND_CAL_POINT_SET_CHANNEL_1;
                              /*~E:A308*/
                              /*~-1*/
                              }
                              /*~O:I306*/
                              /*~-2*/
                              else
                              {
                              /*~K*/
                              /*~+:Fehler*/
                              /*~A:309*/
                              /*~+:Text f�r Terminalbetrieb "E005"*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              lText2Send = TEXT_ERROR_WEIGHT_INSTABILE;
                              /*~E:A309*/
                              /*~-1*/
                              }
                              /*~E:I306*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F305*/
                              /*~E:A304*/
                              /*~A:310*/
                              /*~+:Kalibrierung speichern*/
                              /*~F:311*/
                              case 5:		// Kalibrierung speichern
                              /*~-1*/
                              {
                              /*~A:312*/
                              /*~+:Grenzwerte setzen*/
                              /*~T*/
                              // Grenzwerte setzen
                              Limit_SetAlarmLimits();
                              /*~E:A312*/
                              /*~I:313*/
#ifndef OHNE_STROMRUECKFUEHRUNG 
                              /*~A:314*/
                              /*~+:Stromr�ckf�hrung einschalten*/
                              /*~T*/
                              // Stromr�ckf�hrung einschalten
                              CurrentInterface_SetFeedBackOnOff(1,0);
                              /*~E:A314*/
                              /*~A:315*/
                              /*~+:Mitteilung, dass die Stromr�ckf�hrung eingeschaltet wurde*/
                              /*~I:316*/
                              if (!SYSTEM_MRW_MANAGER)
                              /*~-1*/
                              {
                              /*~T*/
                              // Mitteilung, dass die Stromr�ckf�hrung eingeschaltet wurde
                              Communication_SendString(COMMUNICATION_RS232,T_TEXT_FEEDBACK_STATE_ON,1,0);

                              /*~-1*/
                              }
                              /*~E:I316*/
                              /*~E:A315*/
                              /*~-1*/
#endif
                              /*~E:I313*/
                              /*~I:317*/
#ifdef SYSTEM_CND_WITH_DEADBAND_FILTER
                              /*~A:318*/
                              /*~+:Totbandfilter-Bandbreite f�r die Gewichtsermittlung wieder in Ursprungszustand versetzen*/
                              /*~T*/
                              // Totbandfilter-Bandbreite f�r die Gewichtsermittlung laden
                              Load_Parameter(LOAD_SAVE_FILTER_BANDWIDTH_WEIGHT,&nBandWidth,0);

                              DeadBandFilter_Setup(0,(float)nBandWidth,DEADBANDFILTER_LONGDATA);

                              /*~E:A318*/
                              /*~-1*/
#endif
                              /*~E:I317*/
                              /*~A:319*/
                              /*~+:Eintrag in Diagnosespeicher vornehmen*/
                              /*~T*/
                              ulDiagnosisEntry2Set = DIAGNOSIS_MESSAGE_DAC_CALIBRATION_FINISHED;
                              /*~E:A319*/
                              /*~T*/
                              CurrentInterface_SaveDACSettings(CURRENTINTERFACE_ALL_SETTINGS);
                              /*~T*/
                              // Simulation des Rohmesswerts ausschalten
                              CurrentInterface_PrepareCalibration(0,0);
                              /*~A:320*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              /*~T*/
                              lText2Send = TEXT_CURRENT_INTERFACE_CALIBRATION_FINISHED_CHANNEL_1;
                              /*~E:A320*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F311*/
                              /*~E:A310*/
                              /*~O:C282*/
                              /*~-2*/
                              default:
                              {
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E002;
                              /*~-1*/
                              }
                              /*~-1*/
                              }
                              /*~E:C282*/
                              /*~-1*/
#endif
                              /*~E:I281*/
                              /*~T*/
                              break;
                              /*~E:A280*/
                              /*~-1*/
                              }
                              /*~E:F279*/
                              /*~O:C239*/
                              /*~-2*/
                              default:
                              {
                              /*~A:321*/
                              /*~+:Kanal 0*/
                              /*~I:322*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I322*/
                              /*~E:A321*/
                              /*~-1*/
                              }
                           /*~-1*/
                           }
                           /*~E:C239*/
                        /*~-1*/
                        }
                        /*~O:I238*/
                        /*~-2*/
                        else
                        {
                           /*~A:323*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A323*/
                        /*~-1*/
                        }
                        /*~E:I238*/
                     /*~-1*/
                     }
                     /*~E:I235*/
                     /*~E:A234*/
                     /*~A:324*/
                     /*~+:CID - ClearsystemID*/
                     /*~I:325*/
                     if (!strcmp(szCommand,"CID"))
                     /*~-1*/
                     {
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~A:326*/
                        /*~+:Kanal 0*/
                        /*~I:327*/
#ifdef CHANNEL_0
                        /*~A:328*/
                        /*~+:Variablendeklarationen*/
                        /*~T*/

                        /*~E:A328*/
                        /*~I:329*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~I:330*/
                           if (Communication_GetLongParameter(0) == ADMINCODE)
                           /*~-1*/
                           {
                              /*~T*/
                              Global.ulSystemID = 0;

                              Save_Parameter(LOAD_SAVE_SYSTEM_ID,&Global.ulSystemID,4);
                              /*~A:331*/
                              /*~+:Eintrag im Diagnosespeicher vornehmen*/
                              /*~T*/
                              ulDiagnosisEntry2Set = DIAGNOSIS_WARNING_ID_CLEARED;
                              /*~E:A331*/
                              /*~A:332*/
                              /*~+:Textausgabe*/
                              /*~T*/
                              // Textausgabe
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              lText2Send = TEXT_ID_CLEARED;
                              /*~E:A332*/
                           /*~-1*/
                           }
                           /*~O:I330*/
                           /*~-2*/
                           else
                           {
                              /*~T*/
                              // Textausgabe
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;

                              lText2Send = TEXT_SYSTEM_CLEAR_ID_FAULT;
                           /*~-1*/
                           }
                           /*~E:I330*/
                        /*~-1*/
                        }
                        /*~O:I329*/
                        /*~-2*/
                        else
                        {
                           /*~A:333*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A333*/
                        /*~-1*/
                        }
                        /*~E:I329*/
                        /*~-1*/
#endif
                        /*~E:I327*/
                        /*~E:A326*/
                     /*~-1*/
                     }
                     /*~E:I325*/
                     /*~E:A324*/
                     /*~I:334*/
#ifndef SYSTEM_CND_UNITTEST_WEIGHT 
                     /*~A:335*/
                     /*~+:CIF - CurrentInterfaceFeedback onoff*/
                     /*~I:336*/
                     if (!strcmp(szCommand,"CIF"))
                     /*~-1*/
                     {
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:337*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0); 
                           /*~I:338*/
                           if (!GET_RESPONSE)
                           /*~-1*/
                           {
                              /*~T*/
                              // Kanal best�tigte mit ACKNOWLEDGE
                              /*~I:339*/
                              if (Parameter[0].nLong)
                              /*~-1*/
                              {
                              /*~T*/
                              CurrentInterface_SetFeedBackOnOff(1,1);
                              /*~A:340*/
                              /*~+:Eintrag in Diagnosespeicher vornehmen*/
                              /*~T*/
                              ulDiagnosisEntry2Set = DIAGNOSIS_WARNING_DAC_FEEDBACK_SWITCHED_ON;
                              /*~E:A340*/
                              /*~A:341*/
                              /*~+:Ausf�hrungsstatus auf 'OKAY' setzen*/
                              /*~+:*/
                              /*~T*/
                              // Ausf�hrungsstatus auf 'OKAY' setzen
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              /*~E:A341*/
                              /*~A:342*/
                              /*~+:Kanal 0 - Textausgabe*/
                              /*~I:343*/
#ifdef CHANNEL_0 
                              /*~A:344*/
                              /*~+:Textausgabe �ber Kanal 0*/
                              /*~I:345*/
#ifdef CHANNEL_0
                              /*~T*/
                              lText2Send = TEXT_FEEDBACK_SWITCHED_ON;
                              /*~-1*/
#endif
                              /*~E:I345*/
                              /*~E:A344*/
                              /*~-1*/
#endif
                              /*~E:I343*/
                              /*~E:A342*/
                              /*~-1*/
                              }
                              /*~O:I339*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              CurrentInterface_SetFeedBackOnOff(0,1);
                              /*~A:346*/
                              /*~+:Eintrag in Diagnosespeicher vornehmen*/
                              /*~T*/
                              ulDiagnosisEntry2Set = DIAGNOSIS_WARNING_DAC_FEEDBACK_SWITCHED_OFF;
                              /*~E:A346*/
                              /*~A:347*/
                              /*~+:Ausf�hrungsstatus auf 'OKAY' setzen*/
                              /*~+:*/
                              /*~T*/
                              // Ausf�hrungsstatus auf 'OKAY' setzen
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              /*~E:A347*/
                              /*~A:348*/
                              /*~+:Kanal 0 - Textausgabe*/
                              /*~I:349*/
#ifdef CHANNEL_0 
                              /*~A:350*/
                              /*~+:Textausgabe �ber Kanal 0*/
                              /*~I:351*/
#ifdef CHANNEL_0
                              /*~T*/
                              lText2Send = TEXT_FEEDBACK_SWITCHED_OFF;
                              /*~-1*/
#endif
                              /*~E:I351*/
                              /*~E:A350*/
                              /*~-1*/
#endif
                              /*~E:I349*/
                              /*~E:A348*/
                              /*~-1*/
                              }
                              /*~E:I339*/
                           /*~-1*/
                           }
                           /*~O:I338*/
                           /*~-2*/
                           else
                           {
                              /*~K*/
                              /*~+:Fehler !!!*/
                              /*~A:352*/
                              /*~+:Ausf�hrungsstatus auf 'E005' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A352*/
                           /*~-1*/
                           }
                           /*~E:I338*/
                        /*~-1*/
                        }
                        /*~O:I337*/
                        /*~-2*/
                        else
                        {
                           /*~A:353*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A353*/
                        /*~-1*/
                        }
                        /*~E:I337*/
                     /*~-1*/
                     }
                     /*~E:I336*/
                     /*~E:A335*/
                     /*~A:354*/
                     /*~+:CIG - CurrentInterfacechangeGain*/
                     /*~I:355*/
                     if (!strcmp(szCommand,"CIG"))
                     /*~-1*/
                     {
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:356*/
                        if (!InstructionDecoder_CheckNbParameters(2,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0);
                           Parameter[1].fFloat = Communication_GetFloatParameter(1);
                           /*~C:357*/
                           switch (Parameter[0].nLong)
                           /*~-1*/
                           {
                              /*~F:358*/
                              case 0:
                              /*~-1*/
                              {
                              /*~A:359*/
                              /*~+:Kanal 0*/
                              /*~I:360*/
#ifdef CHANNEL_0
                              /*~T*/
                              // Offset in-/dekrementieren
                              ADuC836_DACChangeGainbyStep(Parameter[1].fFloat);
                              // und neue Einstellungen sichern
                              CurrentInterface_SaveDACSettings(CURRENTINTERFACE_ALL_SETTINGS);
                              /*~A:361*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              lText2Send = TEXT_CURRENT_INTERFACE_GAIN_CHANGED_CHANNEL_0;
                              /*~E:A361*/
                              /*~-1*/
#endif
                              /*~E:I360*/
                              /*~E:A359*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F358*/
                              /*~F:362*/
                              case 1:
                              /*~-1*/
                              {
                              /*~A:363*/
                              /*~+:Kanal 1*/
                              /*~I:364*/
#ifdef CHANNEL_1
                              /*~T*/
                              // Offset in-/dekrementieren
                              ADuC836_DACChangeGainbyStep(Parameter[1].fFloat);
                              // und neue Einstellungen sichern
                              CurrentInterface_SaveDACSettings(CURRENTINTERFACE_ALL_SETTINGS);
                              /*~A:365*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              lText2Send = TEXT_CURRENT_INTERFACE_GAIN_CHANGED_CHANNEL_1;
                              /*~E:A365*/
                              /*~-1*/
#endif
                              /*~E:I364*/
                              /*~E:A363*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F362*/
                              /*~O:C357*/
                              /*~-2*/
                              default:
                              {
                              /*~K*/
                              /*~+:// Parameterfehler*/
                              /*~A:366*/
                              /*~+:Kanal 0*/
                              /*~I:367*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I367*/
                              /*~E:A366*/
                              /*~-1*/
                              }
                           /*~-1*/
                           }
                           /*~E:C357*/
                        /*~-1*/
                        }
                        /*~O:I356*/
                        /*~-2*/
                        else
                        {
                           /*~A:368*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A368*/
                        /*~-1*/
                        }
                        /*~E:I356*/
                     /*~-1*/
                     }
                     /*~E:I355*/
                     /*~E:A354*/
                     /*~I:369*/
#ifndef OHNE_STROMRUECKFUEHRUNG
                     /*~A:370*/
                     /*~+:CII - CurrentInterfaceIntegralportion*/
                     /*~I:371*/
                     if (!strcmp(szCommand,"CII"))
                     /*~-1*/
                     {
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:372*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0); 
                           /*~I:373*/
                           if ((Parameter[0].nLong >= 0)&&(Parameter[0].nLong <= 100))
                           /*~-1*/
                           {
                              /*~T*/
                              // Parameter[0].nLong = 100 - Parameter[0].nLong;
                              /*~I:374*/
                              if (!GET_RESPONSE)
                              /*~-1*/
                              {
                              /*~T*/
                              // Kanal best�tigte mit ACKNOWLEDGE
                              /*~T*/
                              CurrentInterface_SetFeedBackIntegralPortion((char)Parameter[0].nLong);
                              /*~A:375*/
                              /*~+:Ausf�hrungsstatus auf 'OKAY' setzen*/
                              /*~+:*/
                              /*~T*/
                              // Ausf�hrungsstatus auf 'OKAY' setzen
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              /*~E:A375*/
                              /*~A:376*/
                              /*~+:Kanal 0 - Textausgabe*/
                              /*~I:377*/
#ifdef CHANNEL_0 
                              /*~A:378*/
                              /*~+:Textausgabe �ber Kanal 0*/
                              /*~I:379*/
#ifdef CHANNEL_0
                              /*~T*/
                              lText2Send = TEXT_FEEDBACK_INTEGRAL_PORTION_SET;
                              /*~-1*/
#endif
                              /*~E:I379*/
                              /*~E:A378*/
                              /*~-1*/
#endif
                              /*~E:I377*/
                              /*~E:A376*/
                              /*~-1*/
                              }
                              /*~O:I374*/
                              /*~-2*/
                              else
                              {
                              /*~K*/
                              /*~+:Fehler !!!*/
                              /*~A:380*/
                              /*~+:Ausf�hrungsstatus auf 'E005' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A380*/
                              /*~-1*/
                              }
                              /*~E:I374*/
                           /*~-1*/
                           }
                           /*~O:I373*/
                           /*~-2*/
                           else
                           {
                              /*~K*/
                              /*~+:Fehler - Wert au�erhalb des Bereichs !!!*/
                              /*~A:381*/
                              /*~+:Kanal 0 - Ausf�hrungsstatus auf 'E002' setzen*/
                              /*~I:382*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E002;
                              /*~-1*/
#endif
                              /*~E:I382*/
                              /*~E:A381*/
                           /*~-1*/
                           }
                           /*~E:I373*/
                        /*~-1*/
                        }
                        /*~O:I372*/
                        /*~-2*/
                        else
                        {
                           /*~A:383*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A383*/
                        /*~-1*/
                        }
                        /*~E:I372*/
                     /*~-1*/
                     }
                     /*~E:I371*/
                     /*~E:A370*/
                     /*~-1*/
#endif
                     /*~E:I369*/
                     /*~A:384*/
                     /*~+:CIM - CurrentInterfaceManualmode*/
                     /*~I:385*/
                     if (!strcmp(szCommand,"CIM"))
                     /*~-1*/
                     {
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:386*/
                        if (!InstructionDecoder_CheckNbParameters(2,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0);
                           Parameter[1].nLong = Communication_GetLongParameter(1);
                           /*~C:387*/
                           switch (Parameter[0].nLong)
                           /*~-1*/
                           {
                              /*~F:388*/
                              case 0:
                              /*~-1*/
                              {
                              /*~A:389*/
                              /*~+:Kanal 0*/
                              /*~I:390*/
#ifdef CHANNEL_0
                              /*~T*/
                              // Alles okay
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              /*~I:391*/
                              if (Parameter[1].nLong > -1)
                              /*~-1*/
                              {
                              /*~T*/
                              // DAC-Testmode aktiv setzen
                              CurrentInterface_SetManualMode(1,Parameter[1].nLong);
                              /*~A:392*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              lText2Send = TEXT_CURRENT_INTERFACE_MANUAL_MODE_ON_CHANNEL_0;
                              /*~E:A392*/
                              /*~-1*/
                              }
                              /*~O:I391*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              // DAC-Testmode inaktiv setzen
                              CurrentInterface_SetManualMode(0,Parameter[1].nLong);
                              /*~A:393*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              lText2Send = TEXT_CURRENT_INTERFACE_MANUAL_MODE_OFF_CHANNEL_0;
                              /*~E:A393*/
                              /*~-1*/
                              }
                              /*~E:I391*/
                              /*~-1*/
#endif
                              /*~E:I390*/
                              /*~E:A389*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F388*/
                              /*~F:394*/
                              case 1:
                              /*~-1*/
                              {
                              /*~A:395*/
                              /*~+:Kanal 1*/
                              /*~I:396*/
#ifdef CHANNEL_1
                              /*~T*/
                              // Alles okay
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              /*~I:397*/
                              if (Parameter[1].nLong > -1)
                              /*~-1*/
                              {
                              /*~T*/
                              // DAC-Testmode aktiv setzen
                              CurrentInterface_SetManualMode(1,Parameter[1].nLong);
                              /*~A:398*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              lText2Send = TEXT_CURRENT_INTERFACE_MANUAL_MODE_ON_CHANNEL_1;
                              /*~E:A398*/
                              /*~-1*/
                              }
                              /*~O:I397*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              // DAC-Testmode aktiv setzen
                              SET_DAC_TESTMODE(0);
                              /*~A:399*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              lText2Send = TEXT_CURRENT_INTERFACE_MANUAL_MODE_OFF_CHANNEL_1;
                              /*~E:A399*/
                              /*~-1*/
                              }
                              /*~E:I397*/
                              /*~-1*/
#endif
                              /*~E:I396*/
                              /*~E:A395*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F394*/
                              /*~O:C387*/
                              /*~-2*/
                              default:
                              {
                              /*~A:400*/
                              /*~+:Kanal 0*/
                              /*~I:401*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I401*/
                              /*~E:A400*/
                              /*~-1*/
                              }
                           /*~-1*/
                           }
                           /*~E:C387*/
                        /*~-1*/
                        }
                        /*~O:I386*/
                        /*~-2*/
                        else
                        {
                           /*~A:402*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A402*/
                        /*~-1*/
                        }
                        /*~E:I386*/
                     /*~-1*/
                     }
                     /*~E:I385*/
                     /*~E:A384*/
                     /*~A:403*/
                     /*~+:CIO - CurrentInterfacechangeOffset*/
                     /*~I:404*/
                     if (!strcmp(szCommand,"CIO"))
                     /*~-1*/
                     {
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:405*/
                        if (!InstructionDecoder_CheckNbParameters(2,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0);
                           Parameter[1].nLong = Communication_GetLongParameter(1);
                           /*~C:406*/
                           switch (Parameter[0].nLong)
                           /*~-1*/
                           {
                              /*~F:407*/
                              case 0:
                              /*~-1*/
                              {
                              /*~A:408*/
                              /*~+:Kanal 0*/
                              /*~I:409*/
#ifdef CHANNEL_0
                              /*~T*/
                              // Offset in-/dekrementieren
                              ADuC836_DACChangeOffsetbyStep(Parameter[1].nLong);
                              // und neue Einstellungen sichern
                              CurrentInterface_SaveDACSettings(CURRENTINTERFACE_ALL_SETTINGS);
                              /*~A:410*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              lText2Send = TEXT_CURRENT_INTERFACE_OFFSET_CHANGED_CHANNEL_0;
                              /*~E:A410*/
                              /*~-1*/
#endif
                              /*~E:I409*/
                              /*~E:A408*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F407*/
                              /*~F:411*/
                              case 1:
                              /*~-1*/
                              {
                              /*~A:412*/
                              /*~+:Kanal 1*/
                              /*~I:413*/
#ifdef CHANNEL_1
                              /*~T*/
                              // Offset in-/dekrementieren
                              ADuC836_DACChangeOffsetbyStep(Parameter[1].nLong);
                              // und neue Einstellungen sichern
                              CurrentInterface_SaveDACSettings(CURRENTINTERFACE_ALL_SETTINGS);
                              /*~A:414*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              lText2Send = TEXT_CURRENT_INTERFACE_OFFSET_CHANGED_CHANNEL_1;
                              /*~E:A414*/
                              /*~-1*/
#endif
                              /*~E:I413*/
                              /*~E:A412*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F411*/
                              /*~O:C406*/
                              /*~-2*/
                              default:
                              {
                              /*~A:415*/
                              /*~+:Kanal 0*/
                              /*~I:416*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I416*/
                              /*~E:A415*/
                              /*~-1*/
                              }
                           /*~-1*/
                           }
                           /*~E:C406*/
                        /*~-1*/
                        }
                        /*~O:I405*/
                        /*~-2*/
                        else
                        {
                           /*~A:417*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A417*/
                        /*~-1*/
                        }
                        /*~E:I405*/
                     /*~-1*/
                     }
                     /*~E:I404*/
                     /*~E:A403*/
                     /*~I:418*/
#ifndef OHNE_STROMRUECKFUEHRUNG
                     /*~A:419*/
                     /*~+:CIP - CurrentInterfaceProportionalportion*/
                     /*~I:420*/
                     if (!strcmp(szCommand,"CIP"))
                     /*~-1*/
                     {
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:421*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0); 
                           /*~I:422*/
                           if ((Parameter[0].nLong >= 0)&&(Parameter[0].nLong <= 100))
                           /*~-1*/
                           {
                              /*~I:423*/
                              if (!GET_RESPONSE)
                              /*~-1*/
                              {
                              /*~T*/
                              // Kanal best�tigte mit ACKNOWLEDGE
                              /*~T*/
                              CurrentInterface_SetFeedBackProportionalPortion((char)Parameter[0].nLong);
                              /*~A:424*/
                              /*~+:Ausf�hrungsstatus auf 'OKAY' setzen*/
                              /*~+:*/
                              /*~T*/
                              // Ausf�hrungsstatus auf 'OKAY' setzen
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              /*~E:A424*/
                              /*~A:425*/
                              /*~+:Kanal 0 - Textausgabe*/
                              /*~I:426*/
#ifdef CHANNEL_0 
                              /*~A:427*/
                              /*~+:Textausgabe �ber Kanal 0*/
                              /*~I:428*/
#ifdef CHANNEL_0
                              /*~T*/
                              lText2Send = TEXT_FEEDBACK_PROPORTIONAL_PORTION_SET;
                              /*~-1*/
#endif
                              /*~E:I428*/
                              /*~E:A427*/
                              /*~-1*/
#endif
                              /*~E:I426*/
                              /*~E:A425*/
                              /*~-1*/
                              }
                              /*~O:I423*/
                              /*~-2*/
                              else
                              {
                              /*~K*/
                              /*~+:Fehler !!!*/
                              /*~A:429*/
                              /*~+:Ausf�hrungsstatus auf 'E005' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A429*/
                              /*~-1*/
                              }
                              /*~E:I423*/
                           /*~-1*/
                           }
                           /*~O:I422*/
                           /*~-2*/
                           else
                           {
                              /*~K*/
                              /*~+:Fehler - Wert au�erhalb des Bereichs !!!*/
                              /*~A:430*/
                              /*~+:Kanal 0 - Ausf�hrungsstatus auf 'E002' setzen*/
                              /*~I:431*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E002;
                              /*~-1*/
#endif
                              /*~E:I431*/
                              /*~E:A430*/
                           /*~-1*/
                           }
                           /*~E:I422*/
                        /*~-1*/
                        }
                        /*~O:I421*/
                        /*~-2*/
                        else
                        {
                           /*~A:432*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A432*/
                        /*~-1*/
                        }
                        /*~E:I421*/
                     /*~-1*/
                     }
                     /*~E:I420*/
                     /*~E:A419*/
                     /*~-1*/
#endif
                     /*~E:I418*/
                     /*~A:433*/
                     /*~+:CIR - CurrentInterfaceRestorecalibration*/
                     /*~I:434*/
                     if (!strcmp(szCommand,"CIR"))
                     /*~-1*/
                     {
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:435*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0);
                           /*~C:436*/
                           switch (Parameter[0].nLong)
                           /*~-1*/
                           {
                              /*~F:437*/
                              case 0:
                              /*~-1*/
                              {
                              /*~A:438*/
                              /*~+:Kanal 0*/
                              /*~I:439*/
#ifdef CHANNEL_0
                              /*~T*/
                              CurrentInterface_LoadDACSettings(CURRENTINTERFACE_CALIBRATION_BACKUP);
                              /*~A:440*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              lText2Send = TEXT_CURRENT_INTERFACE_SET_2_DEFAULT_CHANNEL_0;
                              /*~E:A440*/
                              /*~-1*/
#endif
                              /*~E:I439*/
                              /*~E:A438*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F437*/
                              /*~F:441*/
                              case 1:
                              /*~-1*/
                              {
                              /*~A:442*/
                              /*~+:Kanal 1*/
                              /*~I:443*/
#ifdef CHANNEL_1
                              /*~T*/
                              CurrentInterface_LoadDACSettings(CURRENTINTERFACE_CALIBRATION_BACKUP);
                              /*~A:444*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              lText2Send = TEXT_CURRENT_INTERFACE_SET_2_DEFAULT_CHANNEL_1;
                              /*~E:A444*/
                              /*~-1*/
#endif
                              /*~E:I443*/
                              /*~E:A442*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F441*/
                              /*~O:C436*/
                              /*~-2*/
                              default:
                              {
                              /*~A:445*/
                              /*~+:Kanal 0*/
                              /*~I:446*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I446*/
                              /*~E:A445*/
                              /*~-1*/
                              }
                           /*~-1*/
                           }
                           /*~E:C436*/
                        /*~-1*/
                        }
                        /*~O:I435*/
                        /*~-2*/
                        else
                        {
                           /*~A:447*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A447*/
                        /*~-1*/
                        }
                        /*~E:I435*/
                     /*~-1*/
                     }
                     /*~E:I434*/
                     /*~E:A433*/
                     /*~A:448*/
                     /*~+:CIV - CurrentInterfaceVariousvalues*/
                     /*~I:449*/
                     if (!strcmp(szCommand,"CIV"))
                     /*~-1*/
                     {
                        /*~T*/
                        DAC_SETTINGS DAC_Settings;
                        /*~T*/
                        DAC_Settings = ADuC836_DACSaveSettings();
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:450*/
                        if (!InstructionDecoder_CheckNbParameters(2,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0);
                           Parameter[1].nLong = Communication_GetLongParameter(1);
                           /*~C:451*/
                           switch (Parameter[0].nLong)
                           /*~-1*/
                           {
                              /*~F:452*/
                              case 0:
                              /*~-1*/
                              {
                              /*~A:453*/
                              /*~+:Kanal 0*/
                              /*~I:454*/
#ifdef CHANNEL_0
                              /*~C:455*/
                              switch (Parameter[1].nLong)
                              /*~-1*/
                              {
                              /*~F:456*/
                              case 0:
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendFloat(COMMUNICATION_RS232,TEXT_CURRENT_INTERFACE_RMV_2_DAC_INPUT_OFFSET_CHANNEL_0,DAC_Settings.fOffset_RMV,-1,1,0);
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F456*/
                              /*~F:457*/
                              case 1:
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendFloat(COMMUNICATION_RS232,TEXT_CURRENT_INTERFACE_RMV_2_DAC_INPUT_GAIN_CHANNEL_0,DAC_Settings.fGain_RMV,-1,1,0);
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F457*/
                              /*~F:458*/
                              case 2:
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendFloat(COMMUNICATION_RS232,TEXT_CURRENT_INTERFACE_DAC_INPUT_2_CURRENT_OFFSET_CHANNEL_0,DAC_Settings.fOffset_Norm,-1,1,0);
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F458*/
                              /*~F:459*/
                              case 3:
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendFloat(COMMUNICATION_RS232,TEXT_CURRENT_INTERFACE_DAC_INPUT_2_CURRENT_GAIN_CHANNEL_0,DAC_Settings.fGain_Norm,-1,1,0);
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F459*/
                              /*~F:460*/
                              case 4:
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_CURRENT_INTERFACE_DAC_INPUT_CHANNEL_0,DACH * 256 + DACL,1,0);
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F460*/
                              /*~O:C455*/
                              /*~-2*/
                              default:
                              {
                              /*~T*/
                              sprintf(szCommand,"Kanal 0: %f;%f;%f;%f;%ld",DAC_Settings.fOffset_RMV,DAC_Settings.fGain_RMV,DAC_Settings.fOffset_Norm,DAC_Settings.fGain_Norm,DACH * 256 + DACL);
                              /*~T*/
                              Communication_SendString(COMMUNICATION_RS232,szCommand,1,0);
                              /*~-1*/
                              }
                              /*~-1*/
                              }
                              /*~E:C455*/
                              /*~-1*/
#endif
                              /*~E:I454*/
                              /*~T*/
                              break;
                              /*~E:A453*/
                              /*~-1*/
                              }
                              /*~E:F452*/
                              /*~F:461*/
                              case 1:
                              /*~-1*/
                              {
                              /*~A:462*/
                              /*~+:Kanal 1*/
                              /*~I:463*/
#ifdef CHANNEL_1
                              /*~T*/
                              // Alles okay
                              byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;

                              /*~C:464*/
                              switch (Parameter[1].nLong)
                              /*~-1*/
                              {
                              /*~F:465*/
                              case 0:
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendFloat(COMMUNICATION_RS232,TEXT_CURRENT_INTERFACE_RMV_2_DAC_INPUT_OFFSET_CHANNEL_1,DAC_Settings.fOffset_RMV,-1,1,0);
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F465*/
                              /*~F:466*/
                              case 1:
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendFloat(COMMUNICATION_RS232,TEXT_CURRENT_INTERFACE_RMV_2_DAC_INPUT_GAIN_CHANNEL_1,DAC_Settings.fGain_RMV,-1,1,0);
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F466*/
                              /*~F:467*/
                              case 2:
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendFloat(COMMUNICATION_RS232,TEXT_CURRENT_INTERFACE_DAC_INPUT_2_CURRENT_OFFSET_CHANNEL_1,DAC_Settings.fOffset_Norm,-1,1,0);
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F467*/
                              /*~F:468*/
                              case 3:
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendFloat(COMMUNICATION_RS232,TEXT_CURRENT_INTERFACE_DAC_INPUT_2_CURRENT_GAIN_CHANNEL_1,DAC_Settings.fGain_Norm,-1,1,0);
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F468*/
                              /*~F:469*/
                              case 4:
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_CURRENT_INTERFACE_DAC_INPUT_CHANNEL_1,DACH * 256 + DACL,1,0);
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F469*/
                              /*~O:C464*/
                              /*~-2*/
                              default:
                              {
                              /*~T*/
                              sprintf(szCommand,"Kanal 1: %f;%f;%f;%f;%ld",DAC_Settings.fOffset_RMV,DAC_Settings.fGain_RMV,DAC_Settings.fOffset_Norm,DAC_Settings.fGain_Norm,DACH * 256 + DACL);
                              /*~T*/
                              Communication_SendString(COMMUNICATION_RS232,szCommand,1,0);
                              /*~-1*/
                              }
                              /*~-1*/
                              }
                              /*~E:C464*/
                              /*~-1*/
#endif
                              /*~E:I463*/
                              /*~T*/
                              break;
                              /*~E:A462*/
                              /*~-1*/
                              }
                              /*~E:F461*/
                              /*~O:C451*/
                              /*~-2*/
                              default:
                              {
                              /*~A:470*/
                              /*~+:Kanal 0*/
                              /*~I:471*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I471*/
                              /*~E:A470*/
                              /*~-1*/
                              }
                           /*~-1*/
                           }
                           /*~E:C451*/
                        /*~-1*/
                        }
                        /*~O:I450*/
                        /*~-2*/
                        else
                        {
                           /*~A:472*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A472*/
                        /*~-1*/
                        }
                        /*~E:I450*/
                     /*~-1*/
                     }
                     /*~E:I449*/
                     /*~E:A448*/
                     /*~-1*/
#endif
                     /*~E:I334*/
                     /*~A:473*/
                     /*~+:CLI - ClearLImit*/
                     /*~I:474*/
                     if (!strcmp(szCommand,"CLI"))
                     /*~-1*/
                     {
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:475*/
                        if (!InstructionDecoder_CheckNbParameters(0,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~I:476*/
                           if (!GET_RESPONSE)
                           /*~-1*/
                           {
                              /*~T*/
                              CurrentInterface_LoadDACSettings(CURRENTINTERFACE_CALIBRATION_BACKUP);
                              /*~A:477*/
                              /*~+:Ausf�hrungsstatus auf 'OKAY' setzen*/
                              /*~+:*/
                              /*~T*/
                              // Ausf�hrungsstatus auf 'OKAY' setzen
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              /*~E:A477*/
                              /*~A:478*/
                              /*~+:Kanal 0 - Textausgabe*/
                              /*~I:479*/
#ifdef CHANNEL_0 
                              /*~A:480*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              lText2Send = TEXT_LIMITS_SET_2_DEFAULT;
                              /*~E:A480*/
                              /*~-1*/
#endif
                              /*~E:I479*/
                              /*~E:A478*/
                           /*~-1*/
                           }
                           /*~O:I476*/
                           /*~-2*/
                           else
                           {
                              /*~K*/
                              /*~+:Fehler !!!*/
                              /*~A:481*/
                              /*~+:Ausf�hrungsstatus auf 'E005' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A481*/
                           /*~-1*/
                           }
                           /*~E:I476*/
                        /*~-1*/
                        }
                        /*~O:I475*/
                        /*~-2*/
                        else
                        {
                           /*~A:482*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A482*/
                        /*~-1*/
                        }
                        /*~E:I475*/
                     /*~-1*/
                     }
                     /*~E:I474*/
                     /*~E:A473*/
                     /*~A:483*/
                     /*~+:CRC - ClearResetreplyCounter*/
                     /*~I:484*/
                     if (!strcmp(szCommand,"CRC"))
                     /*~-1*/
                     {
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:485*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0);
                           /*~T*/
                           Communication_ClearSPIFaultCounter((unsigned char)Parameter[0].nLong);
                           /*~I:486*/
#ifdef CHANNEL_0
                           /*~A:487*/
                           /*~+:Textausgabe*/
                           /*~T*/
                           byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                           lText2Send = TEXT_RESET_REPLIES_COUNTER_CLEARED;
                           /*~E:A487*/
                           /*~-1*/
#endif
                           /*~E:I486*/
                        /*~-1*/
                        }
                        /*~O:I485*/
                        /*~-2*/
                        else
                        {
                           /*~A:488*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A488*/
                        /*~-1*/
                        }
                        /*~E:I485*/
                     /*~-1*/
                     }
                     /*~E:I484*/
                     /*~E:A483*/
                     /*~A:489*/
                     /*~+:CRE - ClearResetEnableflag*/
                     /*~I:490*/
                     if (!strcmp(szCommand,"CRE"))
                     /*~-1*/
                     {
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:491*/
                        if (!InstructionDecoder_CheckNbParameters(0,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Communication_SetResetInhibitFlag(2);
                           /*~A:492*/
                           /*~+:Kanal 0 - Textausgabe*/
                           /*~I:493*/
#ifdef CHANNEL_0
                           /*~T*/
                           byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                           lText2Send = TEXT_RESET_INHIBIT_FLAG_SET;
                           /*~-1*/
#endif
                           /*~E:I493*/
                           /*~E:A492*/
                        /*~-1*/
                        }
                        /*~O:I491*/
                        /*~-2*/
                        else
                        {
                           /*~A:494*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A494*/
                        /*~-1*/
                        }
                        /*~E:I491*/
                     /*~-1*/
                     }
                     /*~E:I490*/
                     /*~E:A489*/
                     /*~I:495*/
#ifdef MOF
                     /*~A:496*/
                     /*~+:CRS - ClearRs232Statistics*/
                     /*~I:497*/
                     if (!strcmp(szCommand,"CRS"))
                     /*~-1*/
                     {
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:498*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0); 
                           /*~C:499*/
                           switch (Parameter[0].nLong)
                           /*~-1*/
                           {
                              /*~F:500*/
                              case 0:
                              /*~-1*/
                              {
                              /*~A:501*/
                              /*~+:Kanal 0*/
                              /*~I:502*/
#ifdef CHANNEL_0
                              /*~T*/
                              ADuC836_RS232ClearStatistics();
                              /*~A:503*/
                              /*~+:Textausgabe*/
                              /*~T*/
                              // Textausgabe
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              lText2Send = TEXT_RS232_STATISTICS_CLEARED_CHANNEL_0;
                              /*~E:A503*/
                              /*~-1*/
#endif
                              /*~E:I502*/
                              /*~E:A501*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F500*/
                              /*~F:504*/
                              case 1:
                              /*~-1*/
                              {
                              /*~A:505*/
                              /*~+:Kanal 1*/
                              /*~I:506*/
#ifdef CHANNEL_1
                              /*~T*/
                              ADuC836_RS232ClearStatistics();
                              /*~A:507*/
                              /*~+:Textausgabe*/
                              /*~T*/
                              // Textausgabe
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              lText2Send = TEXT_RS232_STATISTICS_CLEARED_CHANNEL_0;
                              /*~E:A507*/
                              /*~-1*/
#endif
                              /*~E:I506*/
                              /*~E:A505*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F504*/
                              /*~O:C499*/
                              /*~-2*/
                              default:
                              {
                              /*~A:508*/
                              /*~+:Kanal 0*/
                              /*~I:509*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I509*/
                              /*~E:A508*/
                              /*~-1*/
                              }
                           /*~-1*/
                           }
                           /*~E:C499*/
                        /*~-1*/
                        }
                        /*~O:I498*/
                        /*~-2*/
                        else
                        {
                           /*~A:510*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A510*/
                        /*~-1*/
                        }
                        /*~E:I498*/
                     /*~-1*/
                     }
                     /*~E:I497*/
                     /*~E:A496*/
                     /*~-1*/
#endif
                     /*~E:I495*/
                     /*~I:511*/
#ifdef DEVELOPMENT_SW
                     /*~A:512*/
                     /*~+:CSC - ClearSpicheckCounter*/
                     /*~I:513*/
                     if (!strcmp(szCommand,"CSC"))
                     /*~-1*/
                     {
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;

                        /*~I:514*/
                        if (!InstructionDecoder_CheckNbParameters(0,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~A:515*/
                           /*~+:Ausf�hrungsstatus auf 'OKAY' setzen*/
                           /*~+:*/
                           /*~I:516*/
#ifdef CHANNEL_0
                           /*~T*/
                           // Ausf�hrungsstatus auf 'OKAY' setzen
                           byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                           /*~-1*/
#endif
                           /*~E:I516*/
                           /*~E:A515*/
                           /*~T*/
                           // SPI-Test Z�hler l�schen
                           CommunicationControl.ulSPICounter = 0;

                           /*~I:517*/
#ifdef CHANNEL_0
                           /*~T*/
                           CommunicationControl.ulSPIE1Counter = 0;
                           CommunicationControl.ulSPIE1CounterLast = -1;
                           /*~-1*/
#endif
                           /*~E:I517*/
                           /*~A:518*/
                           /*~+:Kanal 0 - Textausgabe*/
                           /*~I:519*/
#ifdef CHANNEL_0
                           /*~T*/
                           lText2Send = TEXT_SYSTEM_CLEAR_SPI_CHECK_COUNTERS;
                           /*~-1*/
#endif
                           /*~E:I519*/
                           /*~E:A518*/
                        /*~-1*/
                        }
                        /*~O:I514*/
                        /*~-2*/
                        else
                        {
                           /*~A:520*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A520*/
                        /*~-1*/
                        }
                        /*~E:I514*/
                     /*~-1*/
                     }
                     /*~E:I513*/
                     /*~E:A512*/
                     /*~-1*/
#endif
                     /*~E:I511*/
                     /*~A:521*/
                     /*~+:CSD - ClearStatisticsData*/
                     /*~I:522*/
                     if (!strcmp(szCommand,"CSD"))
                     /*~-1*/
                     {
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:523*/
                        if (!InstructionDecoder_CheckNbParameters(2,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           // Parameter auslesen
                           Parameter[0].nLong = Communication_GetLongParameter(0);
                           Parameter[1].nLong = Communication_GetLongParameter(1);

                           /*~C:524*/
                           switch (Parameter[0].nLong)
                           /*~-1*/
                           {
                              /*~F:525*/
                              case 0:
                              /*~-1*/
                              {
                              /*~A:526*/
                              /*~+:Kanal 0*/
                              /*~I:527*/
#ifdef CHANNEL_0
                              /*~T*/
                              Statistics_Clear((unsigned char)Parameter[1].nLong);
                              /*~T*/
                              // Merker f�r ein interpretierbares Kommando setzen - keine Textausgabe
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              lText2Send = TEXT_STATITISTICS_CLEARED_CHANNEL_0; 
                              /*~-1*/
#endif
                              /*~E:I527*/
                              /*~E:A526*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F525*/
                              /*~F:528*/
                              case 1:
                              /*~-1*/
                              {
                              /*~A:529*/
                              /*~+:Kanal 1*/
                              /*~I:530*/
#ifdef CHANNEL_1
                              /*~T*/
                              Statistics_Clear((unsigned char)Parameter[1].nLong);
                              /*~T*/
                              // Merker f�r ein interpretierbares Kommando setzen - keine Textausgabe
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              lText2Send = TEXT_STATITISTICS_CLEARED_CHANNEL_1; 
                              /*~-1*/
#endif
                              /*~E:I530*/
                              /*~E:A529*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F528*/
                              /*~O:C524*/
                              /*~-2*/
                              default:
                              {
                              /*~A:531*/
                              /*~+:Kanal 0*/
                              /*~I:532*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I532*/
                              /*~E:A531*/
                              /*~-1*/
                              }
                           /*~-1*/
                           }
                           /*~E:C524*/
                        /*~-1*/
                        }
                        /*~O:I523*/
                        /*~-2*/
                        else
                        {
                           /*~A:533*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A533*/
                        /*~-1*/
                        }
                        /*~E:I523*/
                     /*~-1*/
                     }
                     /*~E:I522*/
                     /*~E:A521*/
                     /*~A:534*/
                     /*~+:CTM - ClearTiMer*/
                     /*~I:535*/
                     if (!strcmp(szCommand,"CTM"))
                     /*~-1*/
                     {
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~A:536*/
                        /*~+:Kanal 0*/
                        /*~I:537*/
#ifdef CHANNEL_0
                        /*~I:538*/
                        if (!InstructionDecoder_CheckNbParameters(2,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~I:539*/
                           if ((Communication_GetLongParameter(1) == ADMINCODE)||(Communication_GetLongParameter(0) == 1))
                           /*~-1*/
                           {
                              /*~T*/
                              // Relativen Betriebsstundenz�hler l�schen
                              System_ClearOperatingHours(1);
                              /*~A:540*/
                              /*~+:Eintrag im Diagnosespeicher*/
                              /*~T*/
                              Diagnosis_WriteMessage2Flash(DIAGNOSIS_MESSAGE_OPERATINGHOURS_2_CLEARED);
                              /*~E:A540*/
                              /*~A:541*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~I:542*/
                              if (!SYSTEM_MRW_MANAGER)
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendString(COMMUNICATION_RS232,T_TEXT_OPERATING_HOURS_RELATIVE_CLEARED,1,0);
                              /*~-1*/
                              }
                              /*~O:I542*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              Communication_SendMessage(COMMUNICATION_RS232,COMMUNICATION_OK);
                              /*~-1*/
                              }
                              /*~E:I542*/
                              /*~E:A541*/
                              /*~I:543*/
                              if (Communication_GetLongParameter(0) != 1)
                              /*~-1*/
                              {
                              /*~T*/
                              // Betriebsstundenz�hler l�schen
                              System_ClearOperatingHours(0);
                              /*~A:544*/
                              /*~+:Eintrag im Diagnosespeicher*/
                              /*~T*/
                              Diagnosis_WriteMessage2Flash(DIAGNOSIS_MESSAGE_OPERATINGHOURS_CLEARED);
                              /*~E:A544*/
                              /*~A:545*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              lText2Send = TEXT_OPERATING_HOURS_CLEARED;
                              /*~E:A545*/
                              /*~-1*/
                              }
                              /*~E:I543*/
                           /*~-1*/
                           }
                           /*~O:I539*/
                           /*~-2*/
                           else
                           {
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E002;
                           /*~-1*/
                           }
                           /*~E:I539*/
                        /*~-1*/
                        }
                        /*~O:I538*/
                        /*~-2*/
                        else
                        {
                           /*~A:546*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A546*/
                        /*~-1*/
                        }
                        /*~E:I538*/
                        /*~-1*/
#endif
                        /*~E:I537*/
                        /*~E:A536*/
                     /*~-1*/
                     }
                     /*~E:I535*/
                     /*~E:A534*/
                     /*~A:547*/
                     /*~+:CTR - ClearTaRa*/
                     /*~I:548*/
                     if (!strcmp(szCommand,"CTR"))
                     /*~-1*/
                     {
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;

                        /*~I:549*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           // Parameter auslesen
                           Parameter[0].nLong = Communication_GetLongParameter(0);
                           /*~C:550*/
                           switch (Parameter[0].nLong)
                           /*~-1*/
                           {
                              /*~F:551*/
                              case 0:
                              /*~-1*/
                              {
                              /*~A:552*/
                              /*~+:Kanal 0*/
                              /*~I:553*/
#ifdef CHANNEL_0
                              /*~I:554*/
                              // Tara setzen und speichern
                              if (!Weight_SetTareValue(0,1))
                              /*~-1*/
                              {
                              /*~A:555*/
                              /*~+:Eintrag in Diagnosespeicher vornehmen*/
                              /*~T*/
                              ulDiagnosisEntry2Set = DIAGNOSIS_MESSAGE_TARE_CLEARED;
                              /*~E:A555*/
                              /*~A:556*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              /*~T*/
                              lText2Send = TEXT_MEASUREMENT_TARA_CLEARED_CHANNEL_0;
                              /*~E:A556*/
                              /*~-1*/
                              }
                              /*~O:I554*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~-1*/
                              }
                              /*~E:I554*/
                              /*~-1*/
#endif
                              /*~E:I553*/
                              /*~E:A552*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F551*/
                              /*~F:557*/
                              case 1:
                              /*~-1*/
                              {
                              /*~A:558*/
                              /*~+:Kanal 1*/
                              /*~I:559*/
#ifdef CHANNEL_1
                              /*~I:560*/
                              // Tara setzen und speichern
                              if (!Weight_SetTareValue(0,1))
                              /*~-1*/
                              {
                              /*~A:561*/
                              /*~+:Eintrag in Diagnosespeicher vornehmen*/
                              /*~T*/
                              ulDiagnosisEntry2Set = DIAGNOSIS_MESSAGE_TARE_CLEARED;
                              /*~E:A561*/
                              /*~A:562*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              /*~T*/
                              lText2Send = TEXT_MEASUREMENT_TARA_CLEARED_CHANNEL_1;
                              /*~E:A562*/
                              /*~-1*/
                              }
                              /*~O:I560*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~-1*/
                              }
                              /*~E:I560*/
                              /*~-1*/
#endif
                              /*~E:I559*/
                              /*~E:A558*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F557*/
                              /*~O:C550*/
                              /*~-2*/
                              default:
                              {
                              /*~A:563*/
                              /*~+:Kanal 0*/
                              /*~I:564*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I564*/
                              /*~E:A563*/
                              /*~-1*/
                              }
                           /*~-1*/
                           }
                           /*~E:C550*/
                        /*~-1*/
                        }
                        /*~O:I549*/
                        /*~-2*/
                        else
                        {
                           /*~A:565*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A565*/
                        /*~-1*/
                        }
                        /*~E:I549*/
                     /*~-1*/
                     }
                     /*~E:I548*/
                     /*~E:A547*/
                     /*~A:566*/
                     /*~+:CWD - ClearWatchDogadress*/
                     /*~I:567*/
                     if (!strcmp(szCommand,"CWD"))
                     /*~-1*/
                     {
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:568*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~C:569*/
                           switch (Communication_GetLongParameter(0))
                           /*~-1*/
                           {
                              /*~F:570*/
                              case 0:
                              /*~-1*/
                              {
                              /*~A:571*/
                              /*~+:Kanal 0*/
                              /*~I:572*/
#ifdef CHANNEL_0
                              /*~T*/
                              ADuC836_WatchdogClearAddress();
                              /*~T*/
                              // Merker f�r ein interpretierbares Kommando setzen - keine Textausgabe
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              lText2Send = TEXT_WATCHDOG_ADDRESS_CLEARED_CHANNEL_0; 
                              /*~-1*/
#endif
                              /*~E:I572*/
                              /*~E:A571*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F570*/
                              /*~F:573*/
                              case 1:
                              /*~-1*/
                              {
                              /*~A:574*/
                              /*~+:Kanal 1*/
                              /*~I:575*/
#ifdef CHANNEL_1
                              /*~T*/
                              ADuC836_WatchdogClearAddress();
                              /*~T*/
                              // Merker f�r ein interpretierbares Kommando setzen - keine Textausgabe
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              lText2Send = TEXT_WATCHDOG_ADDRESS_CLEARED_CHANNEL_1; 
                              /*~-1*/
#endif
                              /*~E:I575*/
                              /*~E:A574*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F573*/
                              /*~O:C569*/
                              /*~-2*/
                              default:
                              {
                              /*~A:576*/
                              /*~+:Kanal 0*/
                              /*~I:577*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I577*/
                              /*~E:A576*/
                              /*~-1*/
                              }
                           /*~-1*/
                           }
                           /*~E:C569*/
                        /*~-1*/
                        }
                        /*~O:I568*/
                        /*~-2*/
                        else
                        {
                           /*~A:578*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A578*/
                        /*~-1*/
                        }
                        /*~E:I568*/
                     /*~-1*/
                     }
                     /*~E:I567*/
                     /*~E:A566*/
                     /*~T*/
                     break;
                  /*~-1*/
                  }
                  /*~E:F130*/
                  /*~E:A129*/
                  /*~K*/
                  /*~+:/~* Ge�ndert am 09.02.2022 *~/*/
                  /*~A:579*/
                  /*~+:D*/
                  /*~F:580*/
                  case 'D':
                  /*~-1*/
                  {
                     /*~A:581*/
                     /*~+:DIS - DISable RS232-Kommunikation*/
                     /*~I:582*/
                     if (!strcmp(szCommand,"DIS"))
                     /*~-1*/
                     {
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:583*/
                        if (!InstructionDecoder_CheckNbParameters(2,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0);
                           Parameter[1].nLong = Communication_GetLongParameter(1);
                           /*~C:584*/
                           switch (Parameter[0].nLong)
                           /*~-1*/
                           {
                              /*~F:585*/
                              case 0:
                              /*~-1*/
                              {
                              /*~A:586*/
                              /*~+:Kanal 0*/
                              /*~I:587*/
#ifdef CHANNEL_0
                              /*~I:588*/
                              if (Parameter[1].nLong == COMMUNICATION_DISABLE_CODE)
                              /*~-1*/
                              {
                              /*~T*/
                              byRetVal = Communication_EnableCommunication(0);
                              /*~I:589*/
                              if (byRetVal == 0)
                              /*~-1*/
                              {
                              /*~A:590*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              lText2Send = TEXT_RS232_COMMUNICATION_DISABLED_CHANNEL_0;
                              /*~E:A590*/
                              /*~-1*/
                              }
                              /*~O:I589*/
                              /*~-2*/
                              else
                              {
                              /*~K*/
                              /*~+:Fehler*/
                              /*~A:591*/
                              /*~+:Textausgabe "E005"*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A591*/
                              /*~-1*/
                              }
                              /*~E:I589*/
                              /*~-1*/
                              }
                              /*~O:I588*/
                              /*~-2*/
                              else
                              {
                              /*~K*/
                              /*~+:Fehler*/
                              /*~A:592*/
                              /*~+:Textausgabe "E005"*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A592*/
                              /*~-1*/
                              }
                              /*~E:I588*/
                              /*~-1*/
#endif
                              /*~E:I587*/
                              /*~E:A586*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F585*/
                              /*~F:593*/
                              case 1:
                              /*~-1*/
                              {
                              /*~A:594*/
                              /*~+:Kanal 1*/
                              /*~I:595*/
#ifdef CHANNEL_1
                              /*~I:596*/
                              if (Parameter[1].nLong == COMMUNICATION_DISABLE_CODE)
                              /*~-1*/
                              {
                              /*~T*/
                              byRetVal = Communication_EnableCommunication(0);
                              /*~I:597*/
                              if (byRetVal == 0)
                              /*~-1*/
                              {
                              /*~A:598*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              lText2Send = TEXT_RS232_COMMUNICATION_DISABLED_CHANNEL_1;
                              /*~E:A598*/
                              /*~-1*/
                              }
                              /*~O:I597*/
                              /*~-2*/
                              else
                              {
                              /*~K*/
                              /*~+:Fehler*/
                              /*~A:599*/
                              /*~+:Textausgabe "E005"*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A599*/
                              /*~-1*/
                              }
                              /*~E:I597*/
                              /*~-1*/
                              }
                              /*~O:I596*/
                              /*~-2*/
                              else
                              {
                              /*~K*/
                              /*~+:Fehler*/
                              /*~A:600*/
                              /*~+:Textausgabe "E005"*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A600*/
                              /*~-1*/
                              }
                              /*~E:I596*/
                              /*~-1*/
#endif
                              /*~E:I595*/
                              /*~E:A594*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F593*/
                              /*~O:C584*/
                              /*~-2*/
                              default:
                              {
                              /*~A:601*/
                              /*~+:Kanal 0*/
                              /*~I:602*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I602*/
                              /*~E:A601*/
                              /*~-1*/
                              }
                           /*~-1*/
                           }
                           /*~E:C584*/
                        /*~-1*/
                        }
                        /*~O:I583*/
                        /*~-2*/
                        else
                        {
                           /*~A:603*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A603*/
                        /*~-1*/
                        }
                        /*~E:I583*/
                     /*~-1*/
                     }
                     /*~E:I582*/
                     /*~E:A581*/
                     /*~T*/
                     break;
                  /*~-1*/
                  }
                  /*~E:F580*/
                  /*~E:A579*/
                  /*~A:604*/
                  /*~+:E*/
                  /*~F:605*/
                  case 'E':
                  /*~-1*/
                  {
                     /*~A:606*/
                     /*~+:ENA - ENAble RS232-Kommunikation*/
                     /*~I:607*/
                     if (!strcmp(szCommand,"ENA"))
                     /*~-1*/
                     {
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:608*/
                        if (!InstructionDecoder_CheckNbParameters(2,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0);
                           Parameter[1].nLong = Communication_GetLongParameter(1);
                           /*~C:609*/
                           switch (Parameter[0].nLong)
                           /*~-1*/
                           {
                              /*~F:610*/
                              case 0:
                              /*~-1*/
                              {
                              /*~A:611*/
                              /*~+:Kanal 0*/
                              /*~I:612*/
#ifdef CHANNEL_0
                              /*~I:613*/
                              if (Parameter[1].nLong == COMMUNICATION_DISABLE_CODE)
                              /*~-1*/
                              {
                              /*~T*/
                              byRetVal = Communication_EnableCommunication(1);
                              /*~I:614*/
                              if (byRetVal == 0)
                              /*~-1*/
                              {
                              /*~A:615*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              lText2Send = TEXT_RS232_COMMUNICATION_ENABLED_CHANNEL_0;
                              /*~E:A615*/
                              /*~-1*/
                              }
                              /*~O:I614*/
                              /*~-2*/
                              else
                              {
                              /*~K*/
                              /*~+:Fehler*/
                              /*~A:616*/
                              /*~+:Textausgabe "E005"*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A616*/
                              /*~-1*/
                              }
                              /*~E:I614*/
                              /*~-1*/
                              }
                              /*~O:I613*/
                              /*~-2*/
                              else
                              {
                              /*~K*/
                              /*~+:Fehler*/
                              /*~A:617*/
                              /*~+:Textausgabe "E005"*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A617*/
                              /*~-1*/
                              }
                              /*~E:I613*/
                              /*~-1*/
#endif
                              /*~E:I612*/
                              /*~E:A611*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F610*/
                              /*~F:618*/
                              case 1:
                              /*~-1*/
                              {
                              /*~A:619*/
                              /*~+:Kanal 1*/
                              /*~I:620*/
#ifdef CHANNEL_1
                              /*~I:621*/
                              if (Parameter[1].nLong == COMMUNICATION_DISABLE_CODE)
                              /*~-1*/
                              {
                              /*~T*/
                              byRetVal = Communication_EnableCommunication(1);
                              /*~I:622*/
                              if (byRetVal == 0)
                              /*~-1*/
                              {
                              /*~A:623*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              lText2Send = TEXT_RS232_COMMUNICATION_ENABLED_CHANNEL_1;
                              /*~E:A623*/
                              /*~-1*/
                              }
                              /*~O:I622*/
                              /*~-2*/
                              else
                              {
                              /*~K*/
                              /*~+:Fehler*/
                              /*~A:624*/
                              /*~+:Textausgabe "E005"*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A624*/
                              /*~-1*/
                              }
                              /*~E:I622*/
                              /*~-1*/
                              }
                              /*~O:I621*/
                              /*~-2*/
                              else
                              {
                              /*~K*/
                              /*~+:Fehler*/
                              /*~A:625*/
                              /*~+:Textausgabe "E005"*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A625*/
                              /*~-1*/
                              }
                              /*~E:I621*/
                              /*~-1*/
#endif
                              /*~E:I620*/
                              /*~E:A619*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F618*/
                              /*~O:C609*/
                              /*~-2*/
                              default:
                              {
                              /*~A:626*/
                              /*~+:Kanal 0*/
                              /*~I:627*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I627*/
                              /*~E:A626*/
                              /*~-1*/
                              }
                           /*~-1*/
                           }
                           /*~E:C609*/
                        /*~-1*/
                        }
                        /*~O:I608*/
                        /*~-2*/
                        else
                        {
                           /*~A:628*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A628*/
                        /*~-1*/
                        }
                        /*~E:I608*/
                     /*~-1*/
                     }
                     /*~E:I607*/
                     /*~E:A606*/
                     /*~T*/
                     break;
                  /*~-1*/
                  }
                  /*~E:F605*/
                  /*~E:A604*/
                  /*~K*/
                  /*~+:/~* Ende - Ge�ndert am 09.02.2022 *~/*/
                  /*~A:629*/
                  /*~+:G*/
                  /*~F:630*/
                  case 'G':
                  /*~-1*/
                  {
                     /*~A:631*/
                     /*~+:GAN - GetArticleNumber*/
                     /*~I:632*/
                     if (!strcmp(szCommand,"GAN"))
                     /*~-1*/
                     {
                        /*~T*/
                        // Text wurde bereits gesendet
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~A:633*/
                        /*~+:Kanal 0*/
                        /*~I:634*/
#ifdef CHANNEL_0
                        /*~I:635*/
                        if (!InstructionDecoder_CheckNbParameters(0,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~I:636*/
                           if (!SYSTEM_MRW_MANAGER)
                           /*~-1*/
                           {
                              /*~T*/
                              Communication_SendString(COMMUNICATION_RS232,T_TEXT_ITEM_NUMBER,1,0);

                           /*~-1*/
                           }
                           /*~E:I636*/
                           /*~T*/
                           Communication_SendString(COMMUNICATION_RS232,System_GetItemNumber(),0,0);
                        /*~-1*/
                        }
                        /*~O:I635*/
                        /*~-2*/
                        else
                        {
                           /*~A:637*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A637*/
                        /*~-1*/
                        }
                        /*~E:I635*/
                        /*~-1*/
#endif
                        /*~E:I634*/
                        /*~E:A633*/
                     /*~-1*/
                     }
                     /*~E:I632*/
                     /*~E:A631*/
                     /*~A:638*/
                     /*~+:GAL - GetAlarmLimit*/
                     /*~I:639*/
                     if (!strcmp(szCommand,"GAL"))
                     /*~-1*/
                     {
                        /*~T*/
                        // Text wurde bereits gesendet
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:640*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0);
                           /*~T*/
                           fTemp = Limit_GetAlarmLimit(1);
                           /*~C:641*/
                           switch (Parameter[0].nLong)
                           /*~-1*/
                           {
                              /*~F:642*/
                              case 0:
                              /*~-1*/
                              {
                              /*~A:643*/
                              /*~+:Kanal 0*/
                              /*~I:644*/
#ifdef CHANNEL_0
                              /*~T*/
                              Communication_SendFloat(COMMUNICATION_RS232,TEXT_ALARM_LIMIT_CHANNEL_0,fTemp,2,1,0);
                              /*~-1*/
#endif
                              /*~E:I644*/
                              /*~E:A643*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F642*/
                              /*~F:645*/
                              case 1:
                              /*~-1*/
                              {
                              /*~A:646*/
                              /*~+:Kanal 1*/
                              /*~I:647*/
#ifdef CHANNEL_1
                              /*~T*/
                              Communication_SendFloat(COMMUNICATION_RS232,TEXT_ALARM_LIMIT_CHANNEL_1,fTemp,2,1,0);
                              /*~-1*/
#endif
                              /*~E:I647*/
                              /*~E:A646*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F645*/
                              /*~O:C641*/
                              /*~-2*/
                              default:
                              {
                              /*~A:648*/
                              /*~+:Fehlerausgabe �ber Kanal 1 - E001*/
                              /*~I:649*/
#ifdef CHANNEL_0
                              /*~T*/
                              // Fehler
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I649*/
                              /*~E:A648*/
                              /*~-1*/
                              }
                           /*~-1*/
                           }
                           /*~E:C641*/
                        /*~-1*/
                        }
                        /*~O:I640*/
                        /*~-2*/
                        else
                        {
                           /*~A:650*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A650*/
                        /*~-1*/
                        }
                        /*~E:I640*/
                     /*~-1*/
                     }
                     /*~E:I639*/
                     /*~E:A638*/
                     /*~A:651*/
                     /*~+:GAP - GetAPplication*/
                     /*~I:652*/
                     if (!strcmp(szCommand,"GAP"))
                     /*~-1*/
                     {
                        /*~T*/
                        // Text wurde bereits gesendet
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~A:653*/
                        /*~+:Kanal 0*/
                        /*~I:654*/
#ifdef CHANNEL_0
                        /*~I:655*/
                        if (!InstructionDecoder_CheckNbParameters(0,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~I:656*/
                           if (!SYSTEM_MRW_MANAGER)
                           /*~-1*/
                           {
                              /*~T*/
                              Communication_SendString(COMMUNICATION_RS232,T_TEXT_APPLICATION,1,0);

                           /*~-1*/
                           }
                           /*~E:I656*/
                           /*~T*/
                           Communication_SendString(COMMUNICATION_RS232,TEXT_APPLICATION_TYPE,0,0);
                        /*~-1*/
                        }
                        /*~O:I655*/
                        /*~-2*/
                        else
                        {
                           /*~A:657*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A657*/
                        /*~-1*/
                        }
                        /*~E:I655*/
                        /*~-1*/
#endif
                        /*~E:I654*/
                        /*~E:A653*/
                     /*~-1*/
                     }
                     /*~E:I652*/
                     /*~E:A651*/
                     /*~A:658*/
                     /*~+:GAT - GetActualTemperature*/
                     /*~I:659*/
                     if (!strcmp(szCommand,"GAT"))
                     /*~-1*/
                     {
                        /*~T*/
                        // Text wurde bereits gesendet
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:660*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0); 
                           /*~C:661*/
                           switch (Parameter[0].nLong)
                           /*~-1*/
                           {
                              /*~F:662*/
                              case 0:
                              /*~-1*/
                              {
                              /*~A:663*/
                              /*~+:Kanal 0*/
                              /*~I:664*/
#ifdef CHANNEL_0
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_ACTUAL_TEMPERATURE_CHANNEL_0,Global.byTemperature,1,0);
                              /*~-1*/
#endif
                              /*~E:I664*/
                              /*~E:A663*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F662*/
                              /*~F:665*/
                              case 1:
                              /*~-1*/
                              {
                              /*~A:666*/
                              /*~+:Kanal 1*/
                              /*~I:667*/
#ifdef CHANNEL_1
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_ACTUAL_TEMPERATURE_CHANNEL_1,Global.byTemperature,1,0);
                              /*~-1*/
#endif
                              /*~E:I667*/
                              /*~E:A666*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F665*/
                              /*~O:C661*/
                              /*~-2*/
                              default:
                              {
                              /*~A:668*/
                              /*~+:Fehlerausgabe �ber Kanal 1 - E001*/
                              /*~I:669*/
#ifdef CHANNEL_0
                              /*~T*/
                              // Fehler
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I669*/
                              /*~E:A668*/
                              /*~-1*/
                              }
                           /*~-1*/
                           }
                           /*~E:C661*/
                        /*~-1*/
                        }
                        /*~O:I660*/
                        /*~-2*/
                        else
                        {
                           /*~A:670*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A670*/
                        /*~-1*/
                        }
                        /*~E:I660*/
                     /*~-1*/
                     }
                     /*~E:I659*/
                     /*~E:A658*/
                     /*~I:671*/
#ifdef SYSTEM_CND_VARIABLE_BAUDRATE
                     /*~A:672*/
                     /*~+:GBR - GetBaudRate*/
                     /*~I:673*/
                     if (!strcmp(szCommand,"GBR"))
                     /*~-1*/
                     {
                        /*~A:674*/
                        /*~+:Variablendeklarationen*/
                        /*~T*/
                        unsigned long ulBaudrate;
                        /*~I:675*/
#ifdef CHANNEL_0
                        /*~T*/
                        unsigned long ulBaudratePartner;

                        /*~-1*/
#endif
                        /*~E:I675*/
                        /*~E:A674*/
                        /*~T*/
                        // Text wurde bereits gesendet
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:676*/
                        if (!InstructionDecoder_CheckNbParameters(0,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Load_Parameter(LOAD_SAVE_RS232_BAUDRATE,&ulBaudrate,4);
                           /*~I:677*/
#ifdef CHANNEL_0
                           /*~I:678*/
                           if (!Communication_GetSPIValue(COMMUNICATION_RS232_BAUDRATE,&ulBaudratePartner))
                           /*~-1*/
                           {
                              /*~I:679*/
                              if (ulBaudratePartner == ulBaudrate)
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_RS232_BAUDRATE,ulBaudrate,1,0);
                              /*~-1*/
                              }
                              /*~O:I679*/
                              /*~-2*/
                              else
                              {
                              /*~A:680*/
                              /*~+:Fehler - Werte beider Kan�le sind nicht identisch - E011*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E011;
                              /*~E:A680*/
                              /*~-1*/
                              }
                              /*~E:I679*/
                           /*~-1*/
                           }
                           /*~O:I678*/
                           /*~-2*/
                           else
                           {
                              /*~A:681*/
                              /*~+:Fehler bei der Kommunikation - E005*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A681*/
                           /*~-1*/
                           }
                           /*~E:I678*/
                           /*~O:I677*/
                           /*~-1*/
#else
                           /*~I:682*/
#ifdef CHANNEL_1
                           /*~T*/
                           InstructionDecoder_StoreValue(COMMUNICATION_RS232_BAUDRATE,(GLOBAL_UNIVALUE_SHORT*)&ulBaudrate);
                           /*~-1*/
#endif
                           /*~E:I682*/
                           /*~-1*/
#endif
                           /*~E:I677*/
                        /*~-1*/
                        }
                        /*~O:I676*/
                        /*~-2*/
                        else
                        {
                           /*~A:683*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A683*/
                        /*~-1*/
                        }
                        /*~E:I676*/
                     /*~-1*/
                     }
                     /*~E:I673*/
                     /*~E:A672*/
                     /*~-1*/
#endif
                     /*~E:I671*/
                     /*~A:684*/
                     /*~+:GCD - GetmaxCurrentDeviation*/
                     /*~I:685*/
                     if (!strcmp(szCommand,"GCD"))
                     /*~-1*/
                     {
                        /*~T*/
                        // Text wurde bereits gesendet
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~A:686*/
                        /*~+:Kanal 0*/
                        /*~I:687*/
#ifdef CHANNEL_0
                        /*~I:688*/
                        if (!InstructionDecoder_CheckNbParameters(0,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Communication_SendFloat(COMMUNICATION_RS232,TEXT_CURRENT_INTERFACE_CURRENT_MAXDEVIATION,g_CurrentInterface.FeedBack.fMaxDeviation,3,1,0);
                        /*~-1*/
                        }
                        /*~O:I688*/
                        /*~-2*/
                        else
                        {
                           /*~A:689*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A689*/
                        /*~-1*/
                        }
                        /*~E:I688*/
                        /*~-1*/
#endif
                        /*~E:I687*/
                        /*~E:A686*/
                     /*~-1*/
                     }
                     /*~E:I685*/
                     /*~E:A684*/
                     /*~A:690*/
                     /*~+:GCF - GetCalibrationFactor*/
                     /*~I:691*/
                     if (!strcmp(szCommand,"GCF"))
                     /*~-1*/
                     {
                        /*~T*/
                        // Text wurde bereits gesendet
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:692*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0); 
                           /*~T*/
                           Measurement_GetCalibrationFactor(WEIGHT_WEIGHTCHANNEL,&fTemp);
                           /*~C:693*/
                           switch (Parameter[0].nLong)
                           /*~-1*/
                           {
                              /*~F:694*/
                              case 0:
                              /*~-1*/
                              {
                              /*~A:695*/
                              /*~+:Kanal 0*/
                              /*~I:696*/
#ifdef CHANNEL_0
                              /*~T*/
                              Communication_SendFloat(COMMUNICATION_RS232,TEXT_MEASUREMENT_ACTUAL_GAIN_CHANNEL_0,fTemp,-1,1,0);
                              /*~-1*/
#endif
                              /*~E:I696*/
                              /*~E:A695*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F694*/
                              /*~F:697*/
                              case 1:
                              /*~-1*/
                              {
                              /*~A:698*/
                              /*~+:Kanal 1*/
                              /*~I:699*/
#ifdef CHANNEL_1
                              /*~T*/
                              Communication_SendFloat(COMMUNICATION_RS232,TEXT_MEASUREMENT_ACTUAL_GAIN_CHANNEL_1,fTemp,-1,1,0);
                              /*~-1*/
#endif
                              /*~E:I699*/
                              /*~E:A698*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F697*/
                              /*~O:C693*/
                              /*~-2*/
                              default:
                              {
                              /*~A:700*/
                              /*~+:Kanal 0*/
                              /*~I:701*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I701*/
                              /*~E:A700*/
                              /*~-1*/
                              }
                           /*~-1*/
                           }
                           /*~E:C693*/
                        /*~-1*/
                        }
                        /*~O:I692*/
                        /*~-2*/
                        else
                        {
                           /*~A:702*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A702*/
                        /*~-1*/
                        }
                        /*~E:I692*/
                     /*~-1*/
                     }
                     /*~E:I691*/
                     /*~E:A690*/
                     /*~I:703*/
#ifdef MOF
                     /*~A:704*/
                     /*~+:GCG - GetCurrentinterfaceGain*/
                     /*~I:705*/
                     if (!strcmp(szCommand,"GCG"))
                     /*~-1*/
                     {
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:706*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0);
                           /*~I:707*/
                           if (Parameter[0].nLong < 2)
                           /*~-1*/
                           {
                              /*~C:708*/
                              switch (Parameter[0].nLong)
                              /*~-1*/
                              {
                              /*~F:709*/
                              case 0:
                              /*~-1*/
                              {
                              /*~A:710*/
                              /*~+:Kanal 0*/
                              /*~I:711*/
#ifdef CHANNEL_0
                              /*~T*/
                              Communication_SendFloat(COMMUNICATION_RS232,TEXT_CURRENT_INTERFACE_GAIN_NORM_CHANNEL_0,ADuC836_DACGetGain(0) * ADuC836_DACGetGain(1),-1,1,0);
                              /*~-1*/
#endif
                              /*~E:I711*/
                              /*~E:A710*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F709*/
                              /*~F:712*/
                              case 1:
                              /*~-1*/
                              {
                              /*~A:713*/
                              /*~+:Kanal 1*/
                              /*~I:714*/
#ifdef CHANNEL_1
                              /*~T*/
                              Communication_SendFloat(COMMUNICATION_RS232,TEXT_CURRENT_INTERFACE_GAIN_NORM_CHANNEL_1,ADuC836_DACGetGain(0) * ADuC836_DACGetGain(1),-1,1,0);
                              /*~-1*/
#endif
                              /*~E:I714*/
                              /*~E:A713*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F712*/
                              /*~O:C708*/
                              /*~-2*/
                              default:
                              {
                              /*~A:715*/
                              /*~+:Kanal 0*/
                              /*~I:716*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I716*/
                              /*~E:A715*/
                              /*~-1*/
                              }
                              /*~-1*/
                              }
                              /*~E:C708*/
                           /*~-1*/
                           }
                           /*~O:I707*/
                           /*~-2*/
                           else
                           {
                              /*~A:717*/
                              /*~+:Kanal 0*/
                              /*~I:718*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E002;
                              /*~-1*/
#endif
                              /*~E:I718*/
                              /*~E:A717*/
                           /*~-1*/
                           }
                           /*~E:I707*/
                        /*~-1*/
                        }
                        /*~O:I706*/
                        /*~-2*/
                        else
                        {
                           /*~A:719*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A719*/
                        /*~-1*/
                        }
                        /*~E:I706*/
                     /*~-1*/
                     }
                     /*~E:I705*/
                     /*~E:A704*/
                     /*~-1*/
#endif
                     /*~E:I703*/
                     /*~A:720*/
                     /*~+:GCL - GetCheckLimits*/
                     /*~I:721*/
                     if (!strcmp(szCommand,"GCL"))
                     /*~-1*/
                     {
                        /*~A:722*/
                        /*~+:Variablendeklarationen*/
                        /*~T*/
                        float fMaxDeviation;
                        float fMaxDrift;
                        /*~I:723*/
#ifdef CHANNEL_0
                        /*~T*/
                        float fLimitPartner;

                        /*~-1*/
#endif
                        /*~E:I723*/
                        /*~E:A722*/
                        /*~A:724*/
                        /*~+:Variableninitialisierungen*/
                        /*~T*/

                        /*~E:A724*/
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:725*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0);
                           /*~T*/
                           MRW_Compensation_GetCheckLimits(&fMaxDeviation,&fMaxDrift);
                           /*~C:726*/
                           switch (Parameter[0].nLong)
                           /*~-1*/
                           {
                              /*~F:727*/
                              case 0:		// Nullpunkt�berwachung
                              /*~-1*/
                              {
                              /*~I:728*/
#ifdef CHANNEL_0
                              /*~I:729*/
                              if (!Communication_GetSPIValue(COMMUNICATION_CHECKLIMIT_ZEROPOINTCHECK,&fLimitPartner))
                              /*~-1*/
                              {
                              /*~I:730*/
                              if (fLimitPartner == g_Limit.fLimitZeroPointCheck)
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendFloat(COMMUNICATION_RS232,TEXT_LIMIT_ZEROCHECK,g_Limit.fLimitZeroPointCheck,2,1,0);
                              /*~-1*/
                              }
                              /*~O:I730*/
                              /*~-2*/
                              else
                              {
                              /*~A:731*/
                              /*~+:Fehler - Werte beider Kan�le sind nicht identisch - E011*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E011;
                              /*~E:A731*/
                              /*~-1*/
                              }
                              /*~E:I730*/
                              /*~-1*/
                              }
                              /*~O:I729*/
                              /*~-2*/
                              else
                              {
                              /*~A:732*/
                              /*~+:Fehler bei der Kommunikation - E005*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A732*/
                              /*~-1*/
                              }
                              /*~E:I729*/
                              /*~O:I728*/
                              /*~-1*/
#else
                              /*~I:733*/
#ifdef CHANNEL_1 
                              /*~T*/
                              InstructionDecoder_StoreValue(COMMUNICATION_CHECKLIMIT_ZEROPOINTCHECK,(GLOBAL_UNIVALUE_SHORT*)&g_Limit.fLimitZeroPointCheck);
                              /*~-1*/
#endif
                              /*~E:I733*/
                              /*~-1*/
#endif
                              /*~E:I728*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F727*/
                              /*~F:734*/
                              case 1:
                              /*~-1*/
                              {
                              /*~I:735*/
#ifdef CHANNEL_0
                              /*~I:736*/
                              if (!Communication_GetSPIValue(COMMUNICATION_CHECKLIMIT_MAX_DEVIATION,&fLimitPartner))
                              /*~-1*/
                              {
                              /*~I:737*/
                              if (fLimitPartner == fMaxDeviation)
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendFloat(COMMUNICATION_RS232,TEXT_LIMIT_MAX_DEVIATION,fMaxDeviation,2,1,0);
                              /*~-1*/
                              }
                              /*~O:I737*/
                              /*~-2*/
                              else
                              {
                              /*~A:738*/
                              /*~+:Fehler - Werte beider Kan�le sind nicht identisch - E011*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E011;
                              /*~E:A738*/
                              /*~-1*/
                              }
                              /*~E:I737*/
                              /*~-1*/
                              }
                              /*~O:I736*/
                              /*~-2*/
                              else
                              {
                              /*~A:739*/
                              /*~+:Fehler bei der Kommunikation - E005*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A739*/
                              /*~-1*/
                              }
                              /*~E:I736*/
                              /*~O:I735*/
                              /*~-1*/
#else
                              /*~I:740*/
#ifdef CHANNEL_1 
                              /*~T*/
                              InstructionDecoder_StoreValue(COMMUNICATION_CHECKLIMIT_MAX_DEVIATION,(GLOBAL_UNIVALUE_SHORT*)&fMaxDeviation);
                              /*~-1*/
#endif
                              /*~E:I740*/
                              /*~-1*/
#endif
                              /*~E:I735*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F734*/
                              /*~F:741*/
                              case 2:
                              /*~-1*/
                              {
                              /*~I:742*/
#ifdef CHANNEL_0
                              /*~I:743*/
                              if (!Communication_GetSPIValue(COMMUNICATION_CHECKLIMIT_MAX_DRIFT,&fLimitPartner))
                              /*~-1*/
                              {
                              /*~I:744*/
                              if (fLimitPartner == fMaxDrift)
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendFloat(COMMUNICATION_RS232,TEXT_LIMIT_MAX_DRIFT,fMaxDrift,2,1,0);
                              /*~-1*/
                              }
                              /*~O:I744*/
                              /*~-2*/
                              else
                              {
                              /*~A:745*/
                              /*~+:Fehler - Werte beider Kan�le sind nicht identisch - E011*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E011;
                              /*~E:A745*/
                              /*~-1*/
                              }
                              /*~E:I744*/
                              /*~-1*/
                              }
                              /*~O:I743*/
                              /*~-2*/
                              else
                              {
                              /*~A:746*/
                              /*~+:Fehler bei der Kommunikation - E005*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A746*/
                              /*~-1*/
                              }
                              /*~E:I743*/
                              /*~O:I742*/
                              /*~-1*/
#else
                              /*~I:747*/
#ifdef CHANNEL_1 
                              /*~T*/
                              InstructionDecoder_StoreValue(COMMUNICATION_CHECKLIMIT_MAX_DRIFT,(GLOBAL_UNIVALUE_SHORT*)&fMaxDrift);
                              /*~-1*/
#endif
                              /*~E:I747*/
                              /*~-1*/
#endif
                              /*~E:I742*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F741*/
                              /*~O:C726*/
                              /*~-2*/
                              default:
                              {
                              /*~A:748*/
                              /*~+:Kanal 0*/
                              /*~I:749*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E002;
                              /*~-1*/
#endif
                              /*~E:I749*/
                              /*~E:A748*/
                              /*~-1*/
                              }
                           /*~-1*/
                           }
                           /*~E:C726*/
                        /*~-1*/
                        }
                        /*~O:I725*/
                        /*~-2*/
                        else
                        {
                           /*~A:750*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A750*/
                        /*~-1*/
                        }
                        /*~E:I725*/
                     /*~-1*/
                     }
                     /*~E:I721*/
                     /*~E:A720*/
                     /*~I:751*/
#ifdef MOF
                     /*~A:752*/
                     /*~+:GCO - GetCurrentinterfaceOffset*/
                     /*~I:753*/
                     if (!strcmp(szCommand,"GCO"))
                     /*~-1*/
                     {
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:754*/
                        if (!InstructionDecoder_CheckNbParameters(2,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0);
                           Parameter[1].nLong = Communication_GetLongParameter(1);
                           /*~I:755*/
                           if (Parameter[1].nLong < 2)
                           /*~-1*/
                           {
                              /*~C:756*/
                              switch (Parameter[0].nLong)
                              /*~-1*/
                              {
                              /*~F:757*/
                              case 0:
                              /*~-1*/
                              {
                              /*~A:758*/
                              /*~+:Kanal 0*/
                              /*~I:759*/
#ifdef CHANNEL_0
                              /*~I:760*/
                              if (Parameter[1].nLong)
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_CURRENT_INTERFACE_OFFSET_NORM_CHANNEL_0,ADuC836_DACGetOffset(1),1,0);
                              /*~-1*/
                              }
                              /*~O:I760*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_CURRENT_INTERFACE_OFFSET_RMW_CHANNEL_0,ADuC836_DACGetOffset(0),1,0);
                              /*~-1*/
                              }
                              /*~E:I760*/
                              /*~-1*/
#endif
                              /*~E:I759*/
                              /*~E:A758*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F757*/
                              /*~F:761*/
                              case 1:
                              /*~-1*/
                              {
                              /*~A:762*/
                              /*~+:Kanal 1*/
                              /*~I:763*/
#ifdef CHANNEL_1
                              /*~I:764*/
                              if (Parameter[1].nLong)
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_CURRENT_INTERFACE_OFFSET_NORM_CHANNEL_1,ADuC836_DACGetOffset(1),1,0);
                              /*~-1*/
                              }
                              /*~O:I764*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_CURRENT_INTERFACE_OFFSET_RMW_CHANNEL_1,ADuC836_DACGetOffset(0),1,0);
                              /*~-1*/
                              }
                              /*~E:I764*/
                              /*~-1*/
#endif
                              /*~E:I763*/
                              /*~E:A762*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F761*/
                              /*~O:C756*/
                              /*~-2*/
                              default:
                              {
                              /*~A:765*/
                              /*~+:Kanal 0*/
                              /*~I:766*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I766*/
                              /*~E:A765*/
                              /*~-1*/
                              }
                              /*~-1*/
                              }
                              /*~E:C756*/
                           /*~-1*/
                           }
                           /*~O:I755*/
                           /*~-2*/
                           else
                           {
                              /*~A:767*/
                              /*~+:Kanal 0*/
                              /*~I:768*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E002;
                              /*~-1*/
#endif
                              /*~E:I768*/
                              /*~E:A767*/
                           /*~-1*/
                           }
                           /*~E:I755*/
                        /*~-1*/
                        }
                        /*~O:I754*/
                        /*~-2*/
                        else
                        {
                           /*~A:769*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A769*/
                        /*~-1*/
                        }
                        /*~E:I754*/
                     /*~-1*/
                     }
                     /*~E:I753*/
                     /*~E:A752*/
                     /*~-1*/
#endif
                     /*~E:I751*/
                     /*~I:770*/
#ifdef SYSTEM_CND_ADC_MIT_WANDLERRATENERMITTLUNG
                     /*~A:771*/
                     /*~+:GCR - GetConvertionRate*/
                     /*~+:GCT - GetConversionTime*/
                     /*~I:772*/
                     if (!strcmp(szCommand,"GCT")||!strcmp(szCommand,"GCR"))
                     /*~-1*/
                     {
                        /*~T*/
                        unsigned char byTimeMode;
                        /*~I:773*/
                        if (!strcmp(szCommand,"GCT"))
                        /*~-1*/
                        {
                           /*~T*/
                           byTimeMode = 1;
                        /*~-1*/
                        }
                        /*~O:I773*/
                        /*~-2*/
                        else
                        {
                           /*~T*/
                           byTimeMode = 0;
                        /*~-1*/
                        }
                        /*~E:I773*/
                        /*~T*/
                        // Text wurde bereits gesendet
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:774*/
#ifndef MOF
                        /*~I:775*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0); 
                           /*~C:776*/
                           switch (Parameter[0].nLong)
                           /*~-1*/
                           {
                              /*~F:777*/
                              case 0:
                              /*~-1*/
                              {
                              /*~A:778*/
                              /*~+:Kanal 0*/
                              /*~I:779*/
#ifdef CHANNEL_0
                              /*~T*/
                              unsigned int uConversionTime = ADuC836_ADCGetConversionTime(Parameter[1].nLong);
                              /*~I:780*/
                              if (byTimeMode)
                              /*~-1*/
                              {
                              /*~A:781*/
                              /*~+:Zeitintervall bis zur Wandlung des Gewichts*/
                              /*~T*/
                              // Zeitintervall bis zur Wandlung des Gewichts
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_WEIGHT_CONVERSIONTIME_CHANNEL_0,uConversionTime,1,0);
                              /*~E:A781*/
                              /*~-1*/
                              }
                              /*~O:I780*/
                              /*~-2*/
                              else
                              {
                              /*~A:782*/
                              /*~+:Frequenz der Wandlung des Gewichts*/
                              /*~T*/
                              // Frequenz der Wandlung des Gewichts
                              /*~T*/
                              Communication_SendFloat(COMMUNICATION_RS232,TEXT_WEIGHT_CONVERSIONRATE_CHANNEL_0,1/((float)uConversionTime/1000),2,1,0);
                              /*~E:A782*/
                              /*~-1*/
                              }
                              /*~E:I780*/
                              /*~-1*/
#endif
                              /*~E:I779*/
                              /*~E:A778*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F777*/
                              /*~F:783*/
                              case 1:
                              /*~-1*/
                              {
                              /*~A:784*/
                              /*~+:Kanal 1*/
                              /*~I:785*/
#ifdef CHANNEL_1
                              /*~T*/
                              unsigned int uConversionTime = ADuC836_ADCGetConversionTime(Parameter[1].nLong);
                              /*~I:786*/
                              if (byTimeMode)
                              /*~-1*/
                              {
                              /*~A:787*/
                              /*~+:Zeitintervall bis zur Wandlung des Gewichts*/
                              /*~T*/
                              // Zeitintervall bis zur Wandlung des Gewichts
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_WEIGHT_CONVERSIONTIME_CHANNEL_1,uConversionTime,1,0);
                              /*~E:A787*/
                              /*~-1*/
                              }
                              /*~O:I786*/
                              /*~-2*/
                              else
                              {
                              /*~A:788*/
                              /*~+:Frequenz der Wandlung des Gewichts*/
                              /*~T*/
                              // Frequenz der Wandlung des Gewichts
                              /*~T*/
                              Communication_SendFloat(COMMUNICATION_RS232,TEXT_WEIGHT_CONVERSIONRATE_CHANNEL_1,1/((float)uConversionTime/1000),2,1,0);
                              /*~E:A788*/
                              /*~-1*/
                              }
                              /*~E:I786*/
                              /*~-1*/
#endif
                              /*~E:I785*/
                              /*~E:A784*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F783*/
                              /*~O:C776*/
                              /*~-2*/
                              default:
                              {
                              /*~A:789*/
                              /*~+:Kanal 0*/
                              /*~I:790*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I790*/
                              /*~E:A789*/
                              /*~-1*/
                              }
                           /*~-1*/
                           }
                           /*~E:C776*/
                        /*~-1*/
                        }
                        /*~O:I775*/
                        /*~-2*/
                        else
                        {
                           /*~A:791*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A791*/
                        /*~-1*/
                        }
                        /*~E:I775*/
                        /*~O:I774*/
                        /*~-1*/
#else
                        /*~A:792*/
                        /*~+:f�r sp�tere Verwendung*/
                        /*~I:793*/
                        if (!InstructionDecoder_CheckNbParameters(2,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0);
                           Parameter[1].nLong = Communication_GetLongParameter(1); 
                           /*~I:794*/
#ifndef OHNE_STROMRUECKFUEHRUNG
                           if (Parameter[1].nLong < 4)
#else
                           if ((Parameter[1].nLong < 4)&&(Parameter[1].nLong != 2))
#endif
                           /*~-1*/
                           {
                              /*~C:795*/
                              switch (Parameter[0].nLong)
                              /*~-1*/
                              {
                              /*~F:796*/
                              case 0:
                              /*~-1*/
                              {
                              /*~A:797*/
                              /*~+:Kanal 0*/
                              /*~I:798*/
#ifdef CHANNEL_0
                              /*~T*/
                              unsigned int uConversionTime = ADuC836_ADCGetConversionTime(Parameter[1].nLong);
                              /*~C:799*/
                              switch (Parameter[1].nLong)
                              /*~-1*/
                              {
                              /*~F:800*/
                              case 0:
                              /*~-1*/
                              {
                              /*~I:801*/
                              if (byTimeMode)
                              /*~-1*/
                              {
                              /*~A:802*/
                              /*~+:Zeitintervall bis zur Wandlung des Gewichts*/
                              /*~T*/
                              // Zeitintervall bis zur Wandlung des Gewichts
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_WEIGHT_CONVERSIONTIME_CHANNEL_0,uConversionTime,1,0);
                              /*~E:A802*/
                              /*~-1*/
                              }
                              /*~O:I801*/
                              /*~-2*/
                              else
                              {
                              /*~A:803*/
                              /*~+:Frequenz der Wandlung des Gewichts*/
                              /*~T*/
                              // Frequenz der Wandlung des Gewichts
                              /*~T*/
                              Communication_SendFloat(COMMUNICATION_RS232,TEXT_WEIGHT_CONVERSIONRATE_CHANNEL_0,1/((float)uConversionTime/1000),2,1,0);
                              /*~E:A803*/
                              /*~-1*/
                              }
                              /*~E:I801*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F800*/
                              /*~F:804*/
                              case 1:
                              /*~-1*/
                              {
                              /*~I:805*/
                              if (byTimeMode)
                              /*~-1*/
                              {
                              /*~A:806*/
                              /*~+:Zeitintervall bis zur Wandlung der Temperatur*/
                              /*~T*/
                              // Zeitintervall bis zur Wandlung der Temperatur
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_TEMPERATURE_CONVERSIONTIME_CHANNEL_0,uConversionTime,1,0);
                              /*~E:A806*/
                              /*~-1*/
                              }
                              /*~O:I805*/
                              /*~-2*/
                              else
                              {
                              /*~A:807*/
                              /*~+:Frequenz der Wandlung der Temperatur*/
                              /*~T*/
                              // Frequenz der Wandlung der Temperatur
                              /*~T*/
                              Communication_SendFloat(COMMUNICATION_RS232,TEXT_TEMPERATURE_CONVERSIONRATE_CHANNEL_0,1/((float)uConversionTime/1000),2,1,0);
                              /*~E:A807*/
                              /*~-1*/
                              }
                              /*~E:I805*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F804*/
                              /*~F:808*/
                              case 2:
                              /*~-1*/
                              {
                              /*~I:809*/
                              if (byTimeMode)
                              /*~-1*/
                              {
                              /*~A:810*/
                              /*~+:Zeitintervall bis zur Wandlung des Ausgangsstroms*/
                              /*~T*/
                              // Zeitintervall bis zur Wandlung des Ausgangsstroms
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_FEEDBACK_CONVERSIONTIME_CHANNEL_0,uConversionTime,1,0);
                              /*~E:A810*/
                              /*~-1*/
                              }
                              /*~O:I809*/
                              /*~-2*/
                              else
                              {
                              /*~A:811*/
                              /*~+:Frequenz der Wandlung des Ausgangsstroms*/
                              /*~T*/
                              // Frequenz der Wandlung des Ausgangsstroms
                              /*~T*/
                              Communication_SendFloat(COMMUNICATION_RS232,TEXT_FEEDBACK_CONVERSIONRATE_CHANNEL_0,1/((float)uConversionTime/1000),2,1,0);
                              /*~E:A811*/
                              /*~-1*/
                              }
                              /*~E:I809*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F808*/
                              /*~F:812*/
                              case 3:
                              /*~-1*/
                              {
                              /*~I:813*/
                              if (byTimeMode)
                              /*~-1*/
                              {
                              /*~A:814*/
                              /*~+:Zeitintervall bis zur Wandlung der Netzteilspannung*/
                              /*~T*/
                              // Zeitintervall bis zur Wandlung der Netzteilspannung
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_SUPPLY_CONVERSIONTIME_CHANNEL_0,uConversionTime,1,0);
                              /*~E:A814*/
                              /*~-1*/
                              }
                              /*~O:I813*/
                              /*~-2*/
                              else
                              {
                              /*~A:815*/
                              /*~+:Frequenz der Wandlung der Netzteilspannung*/
                              /*~T*/
                              // Frequenz der Wandlung der Netzteilspannung
                              /*~T*/
                              Communication_SendFloat(COMMUNICATION_RS232,TEXT_SUPPLY_CONVERSIONRATE_CHANNEL_0,1/((float)uConversionTime/1000),2,1,0);
                              /*~E:A815*/
                              /*~-1*/
                              }
                              /*~E:I813*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F812*/
                              /*~-1*/
                              }
                              /*~E:C799*/
                              /*~-1*/
#endif
                              /*~E:I798*/
                              /*~E:A797*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F796*/
                              /*~F:816*/
                              case 1:
                              /*~-1*/
                              {
                              /*~A:817*/
                              /*~+:Kanal 1*/
                              /*~I:818*/
#ifdef CHANNEL_1
                              /*~T*/
                              unsigned int uConversionTime = ADuC836_ADCGetConversionTime(Parameter[1].nLong);
                              /*~C:819*/
                              switch (Parameter[1].nLong)
                              /*~-1*/
                              {
                              /*~F:820*/
                              case 0:
                              /*~-1*/
                              {
                              /*~I:821*/
                              if (byTimeMode)
                              /*~-1*/
                              {
                              /*~A:822*/
                              /*~+:Zeitintervall bis zur Wandlung des Gewichts*/
                              /*~T*/
                              // Zeitintervall bis zur Wandlung des Gewichts
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_WEIGHT_CONVERSIONTIME_CHANNEL_1,uConversionTime,1,0);
                              /*~E:A822*/
                              /*~-1*/
                              }
                              /*~O:I821*/
                              /*~-2*/
                              else
                              {
                              /*~A:823*/
                              /*~+:Frequenz der Wandlung des Gewichts*/
                              /*~T*/
                              // Frequenz der Wandlung des Gewichts
                              /*~T*/
                              Communication_SendFloat(COMMUNICATION_RS232,TEXT_WEIGHT_CONVERSIONRATE_CHANNEL_1,1/((float)uConversionTime/1000),2,1,0);
                              /*~E:A823*/
                              /*~-1*/
                              }
                              /*~E:I821*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F820*/
                              /*~F:824*/
                              case 1:
                              /*~-1*/
                              {
                              /*~I:825*/
                              if (byTimeMode)
                              /*~-1*/
                              {
                              /*~A:826*/
                              /*~+:Zeitintervall bis zur Wandlung der Temperatur*/
                              /*~T*/
                              // Zeitintervall bis zur Wandlung der Temperatur
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_TEMPERATURE_CONVERSIONTIME_CHANNEL_1,uConversionTime,1,0);
                              /*~E:A826*/
                              /*~-1*/
                              }
                              /*~O:I825*/
                              /*~-2*/
                              else
                              {
                              /*~A:827*/
                              /*~+:Frequenz der Wandlung der Temperatur*/
                              /*~T*/
                              // Frequenz der Wandlung der Temperatur
                              /*~T*/
                              Communication_SendFloat(COMMUNICATION_RS232,TEXT_TEMPERATURE_CONVERSIONRATE_CHANNEL_1,1/((float)uConversionTime/1000),2,1,0);
                              /*~E:A827*/
                              /*~-1*/
                              }
                              /*~E:I825*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F824*/
                              /*~F:828*/
                              case 2:
                              /*~-1*/
                              {
                              /*~I:829*/
                              if (byTimeMode)
                              /*~-1*/
                              {
                              /*~A:830*/
                              /*~+:Zeitintervall bis zur Wandlung des Ausgangsstroms*/
                              /*~T*/
                              // Zeitintervall bis zur Wandlung des Ausgangsstroms
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_FEEDBACK_CONVERSIONTIME_CHANNEL_1,uConversionTime,1,0);
                              /*~E:A830*/
                              /*~-1*/
                              }
                              /*~O:I829*/
                              /*~-2*/
                              else
                              {
                              /*~A:831*/
                              /*~+:Frequenz der Wandlung des Ausgangsstroms*/
                              /*~T*/
                              // Frequenz der Wandlung des Ausgangsstroms
                              /*~T*/
                              Communication_SendFloat(COMMUNICATION_RS232,TEXT_FEEDBACK_CONVERSIONRATE_CHANNEL_1,1/((float)uConversionTime/1000),2,1,0);
                              /*~E:A831*/
                              /*~-1*/
                              }
                              /*~E:I829*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F828*/
                              /*~F:832*/
                              case 3:
                              /*~-1*/
                              {
                              /*~I:833*/
                              if (byTimeMode)
                              /*~-1*/
                              {
                              /*~A:834*/
                              /*~+:Zeitintervall bis zur Wandlung der Netzteilspannung*/
                              /*~T*/
                              // Zeitintervall bis zur Wandlung der Netzteilspannung
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_SUPPLY_CONVERSIONTIME_CHANNEL_1,uConversionTime,1,0);
                              /*~E:A834*/
                              /*~-1*/
                              }
                              /*~O:I833*/
                              /*~-2*/
                              else
                              {
                              /*~A:835*/
                              /*~+:Frequenz der Wandlung der Netzteilspannung*/
                              /*~T*/
                              // Frequenz der Wandlung der Netzteilspannung
                              /*~T*/
                              Communication_SendFloat(COMMUNICATION_RS232,TEXT_SUPPLY_CONVERSIONRATE_CHANNEL_1,1/((float)uConversionTime/1000),2,1,0);
                              /*~E:A835*/
                              /*~-1*/
                              }
                              /*~E:I833*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F832*/
                              /*~-1*/
                              }
                              /*~E:C819*/
                              /*~-1*/
#endif
                              /*~E:I818*/
                              /*~E:A817*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F816*/
                              /*~O:C795*/
                              /*~-2*/
                              default:
                              {
                              /*~A:836*/
                              /*~+:Kanal 0*/
                              /*~I:837*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I837*/
                              /*~E:A836*/
                              /*~-1*/
                              }
                              /*~-1*/
                              }
                              /*~E:C795*/
                           /*~-1*/
                           }
                           /*~O:I794*/
                           /*~-2*/
                           else
                           {
                              /*~A:838*/
                              /*~+:Kanal 0*/
                              /*~I:839*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E002;
                              /*~-1*/
#endif
                              /*~E:I839*/
                              /*~E:A838*/
                           /*~-1*/
                           }
                           /*~E:I794*/
                        /*~-1*/
                        }
                        /*~O:I793*/
                        /*~-2*/
                        else
                        {
                           /*~A:840*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A840*/
                        /*~-1*/
                        }
                        /*~E:I793*/
                        /*~E:A792*/
                        /*~-1*/
#endif
                        /*~E:I774*/
                     /*~-1*/
                     }
                     /*~E:I772*/
                     /*~E:A771*/
                     /*~O:I770*/
                     /*~-1*/
#else
                     /*~A:841*/
                     /*~+:GCR - GetConvertionRate*/
                     /*~I:842*/
                     if (!strcmp(szCommand,"GCR"))
                     /*~-1*/
                     {
                        /*~T*/
                        // Text wurde bereits gesendet
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:843*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0); 
                           /*~C:844*/
                           switch (Parameter[0].nLong)
                           /*~-1*/
                           {
                              /*~F:845*/
                              case 0:
                              /*~-1*/
                              {
                              /*~A:846*/
                              /*~+:Kanal 0*/
                              /*~I:847*/
#ifdef CHANNEL_0
                              /*~A:848*/
                              /*~+:Zeitintervall bis zur Wandlung des Gewichts*/
                              /*~T*/
                              // Frequenz der Wandlung des Gewichts
                              /*~T*/
                              Communication_SendFloat(COMMUNICATION_RS232,TEXT_WEIGHT_CONVERSIONRATE_CHANNEL_0,ADuC836_ADCGetConversionRate(ADuC836_ADC_FREQUENCY_32KHZ),2,1,0);
                              /*~E:A848*/
                              /*~-1*/
#endif
                              /*~E:I847*/
                              /*~E:A846*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F845*/
                              /*~F:849*/
                              case 1:
                              /*~-1*/
                              {
                              /*~A:850*/
                              /*~+:Kanal 1*/
                              /*~I:851*/
#ifdef CHANNEL_1
                              /*~A:852*/
                              /*~+:Zeitintervall bis zur Wandlung des Gewichts*/
                              /*~T*/
                              // Frequenz der Wandlung des Gewichts
                              /*~T*/
                              Communication_SendFloat(COMMUNICATION_RS232,TEXT_WEIGHT_CONVERSIONRATE_CHANNEL_1,ADuC836_ADCGetConversionRate(ADuC836_ADC_FREQUENCY_32KHZ),2,1,0);
                              /*~E:A852*/
                              /*~-1*/
#endif
                              /*~E:I851*/
                              /*~E:A850*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F849*/
                              /*~O:C844*/
                              /*~-2*/
                              default:
                              {
                              /*~A:853*/
                              /*~+:Kanal 0*/
                              /*~I:854*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I854*/
                              /*~E:A853*/
                              /*~-1*/
                              }
                           /*~-1*/
                           }
                           /*~E:C844*/
                        /*~-1*/
                        }
                        /*~O:I843*/
                        /*~-2*/
                        else
                        {
                           /*~A:855*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A855*/
                        /*~-1*/
                        }
                        /*~E:I843*/
                     /*~-1*/
                     }
                     /*~E:I842*/
                     /*~E:A841*/
                     /*~-1*/
#endif
                     /*~E:I770*/
                     /*~A:856*/
                     /*~+:GCS - GetCompensationState*/
                     /*~I:857*/
                     if (!strcmp(szCommand,"GCS"))
                     /*~-1*/
                     {
                        /*~A:858*/
                        /*~+:Variablendeklarationen*/
                        /*~I:859*/
#ifdef CHANNEL_0
                        /*~T*/
                        long lTempCompPartnerOn;

                        /*~-1*/
#endif
                        /*~E:I859*/
                        /*~E:A858*/
                        /*~T*/
                        // Text wurde bereits gesendet
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:860*/
                        if (!InstructionDecoder_CheckNbParameters(0,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           byTemp = MRW_Compensation_GetCompensationOnOffStatus();
                           /*~I:861*/
#ifdef CHANNEL_0
                           /*~I:862*/
                           if (!Communication_GetSPIValue(COMMUNICATION_COMPENSATION_STATE,&lTempCompPartnerOn))
                           /*~-1*/
                           {
                              /*~I:863*/
                              if ((char)lTempCompPartnerOn == byTemp)
                              /*~-1*/
                              {
                              /*~I:864*/
                              if (!SYSTEM_MRW_MANAGER)
                              /*~-1*/
                              {
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              /*~I:865*/
                              if (byTemp)
                              /*~-1*/
                              {
                              /*~T*/
                              lText2Send = TEXT_COMPENSATION_SWITCHED_ON;
                              /*~-1*/
                              }
                              /*~O:I865*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              lText2Send = TEXT_COMPENSATION_SWITCHED_OFF;
                              /*~-1*/
                              }
                              /*~E:I865*/
                              /*~-1*/
                              }
                              /*~O:I864*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,0,byTemp,1,0);
                              /*~-1*/
                              }
                              /*~E:I864*/
                              /*~-1*/
                              }
                              /*~O:I863*/
                              /*~-2*/
                              else
                              {
                              /*~A:866*/
                              /*~+:Fehler - Werte beider Kan�le sind nicht identisch - E011*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E011;
                              /*~E:A866*/
                              /*~-1*/
                              }
                              /*~E:I863*/
                           /*~-1*/
                           }
                           /*~O:I862*/
                           /*~-2*/
                           else
                           {
                              /*~A:867*/
                              /*~+:Fehler bei der Kommunikation - E005*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A867*/
                           /*~-1*/
                           }
                           /*~E:I862*/
                           /*~O:I861*/
                           /*~-1*/
#else
                           /*~I:868*/
#ifdef CHANNEL_1
                           /*~T*/
                           InstructionDecoder_StoreValue(COMMUNICATION_COMPENSATION_STATE,(GLOBAL_UNIVALUE_SHORT*)&byTemp);
                           /*~-1*/
#endif
                           /*~E:I868*/
                           /*~-1*/
#endif
                           /*~E:I861*/
                        /*~-1*/
                        }
                        /*~O:I860*/
                        /*~-2*/
                        else
                        {
                           /*~A:869*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A869*/
                        /*~-1*/
                        }
                        /*~E:I860*/
                     /*~-1*/
                     }
                     /*~E:I857*/
                     /*~E:A856*/
                     /*~A:870*/
                     /*~+:GCU - GetCUrrent*/
                     /*~I:871*/
                     if (!strcmp(szCommand,"GCU"))
                     /*~-1*/
                     {
                        /*~T*/
                        // Text wurde bereits gesendet
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:872*/
                        if (!InstructionDecoder_CheckNbParameters(2,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0);
                           Parameter[1].nLong = Communication_GetLongParameter(1);
                           /*~T*/
                           fTemp = CurrentInterface_GetCurrent((unsigned char)Parameter[1].nLong);
                           /*~C:873*/
                           switch (Parameter[0].nLong)
                           /*~-1*/
                           {
                              /*~F:874*/
                              case 0:
                              /*~-1*/
                              {
                              /*~A:875*/
                              /*~+:Kanal 0*/
                              /*~I:876*/
#ifdef CHANNEL_0
                              /*~I:877*/
#ifndef OHNE_STROMRUECKFUEHRUNG
                              /*~C:878*/
                              switch (Parameter[1].nLong)
                              /*~-1*/
                              {
                              /*~F:879*/
                              case 0:
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendFloat(COMMUNICATION_RS232,TEXT_CURRENT_INTERFACE_ACTUAL_CURRENT_CHANNEL_0,fTemp,3,1,0);
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F879*/
                              /*~F:880*/
                              case 1:
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendFloat(COMMUNICATION_RS232,TEXT_CURRENT_INTERFACE_ACTUAL_CURRENT_MEASURED_CHANNEL_0,fTemp,3,1,0);
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F880*/
                              /*~O:C878*/
                              /*~-2*/
                              default:
                              {
                              /*~T*/
                              Communication_SendFloat(COMMUNICATION_RS232,TEXT_CURRENT_INTERFACE_ACTUAL_DEVIATION_CHANNEL_0,g_CurrentInterface.FeedBack.Results.Deviation.fFloat,5,1,0);
                              /*~-1*/
                              }
                              /*~-1*/
                              }
                              /*~E:C878*/
                              /*~O:I877*/
                              /*~-1*/
#else
                              /*~T*/
                              Communication_SendFloat(COMMUNICATION_RS232,TEXT_CURRENT_INTERFACE_ACTUAL_CURRENT_CHANNEL_0,fTemp,3,1,0);
                              /*~-1*/
#endif
                              /*~E:I877*/
                              /*~-1*/
#endif
                              /*~E:I876*/
                              /*~E:A875*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F874*/
                              /*~F:881*/
                              case 1:
                              /*~-1*/
                              {
                              /*~A:882*/
                              /*~+:Kanal 1*/
                              /*~I:883*/
#ifdef CHANNEL_1
                              /*~I:884*/
#ifndef OHNE_STROMRUECKFUEHRUNG 
                              /*~C:885*/
                              switch (Parameter[1].nLong)
                              /*~-1*/
                              {
                              /*~F:886*/
                              case 0:
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendFloat(COMMUNICATION_RS232,TEXT_CURRENT_INTERFACE_ACTUAL_CURRENT_CHANNEL_1,fTemp,3,1,0);
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F886*/
                              /*~F:887*/
                              case 1:
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendFloat(COMMUNICATION_RS232,TEXT_CURRENT_INTERFACE_ACTUAL_CURRENT_MEASURED_CHANNEL_1,fTemp,3,1,0);
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F887*/
                              /*~O:C885*/
                              /*~-2*/
                              default:
                              {
                              /*~T*/
                              Communication_SendFloat(COMMUNICATION_RS232,TEXT_CURRENT_INTERFACE_ACTUAL_DEVIATION_CHANNEL_1,g_CurrentInterface.FeedBack.Results.Deviation.fFloat,5,1,0);
                              /*~-1*/
                              }
                              /*~-1*/
                              }
                              /*~E:C885*/
                              /*~O:I884*/
                              /*~-1*/
#else
                              /*~T*/
                              Communication_SendFloat(COMMUNICATION_RS232,TEXT_CURRENT_INTERFACE_ACTUAL_CURRENT_CHANNEL_1,fTemp,3,1,0);
                              /*~-1*/
#endif
                              /*~E:I884*/
                              /*~-1*/
#endif
                              /*~E:I883*/
                              /*~E:A882*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F881*/
                              /*~O:C873*/
                              /*~-2*/
                              default:
                              {
                              /*~A:888*/
                              /*~+:Kanal 0*/
                              /*~I:889*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I889*/
                              /*~E:A888*/
                              /*~-1*/
                              }
                           /*~-1*/
                           }
                           /*~E:C873*/
                        /*~-1*/
                        }
                        /*~O:I872*/
                        /*~-2*/
                        else
                        {
                           /*~A:890*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A890*/
                        /*~-1*/
                        }
                        /*~E:I872*/
                     /*~-1*/
                     }
                     /*~E:I871*/
                     /*~E:A870*/
                     /*~A:891*/
                     /*~+:GCV - GetCompensationValue*/
                     /*~I:892*/
                     if (!strcmp(szCommand,"GCV"))
                     /*~-1*/
                     {
                        /*~T*/
                        int nCorVal;
                        /*~T*/
                        // Text wurde bereits gesendet
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:893*/
                        if (!InstructionDecoder_CheckNbParameters(2,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0);
                           Parameter[1].nLong = Communication_GetLongParameter(1);
                           /*~C:894*/
                           switch (Parameter[0].nLong)
                           /*~-1*/
                           {
                              /*~F:895*/
                              case 0:
                              /*~-1*/
                              {
                              /*~A:896*/
                              /*~+:Kanal 0*/
                              /*~I:897*/
#ifdef CHANNEL_0
                              /*~T*/
                              nCorVal = Compensation_GetCompensationValue((char)Parameter[1].nLong);
                              /*~I:898*/
                              if ((char)Parameter[1].nLong == 20)
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_COMPENSATION_REFPOINT_OFFSET_CHANNEL_0,nCorVal,1,0);
                              /*~-1*/
                              }
                              /*~O:I898*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_COMPENSATION_REFPOINT_CHANNEL_0,nCorVal,1,0);
                              /*~-1*/
                              }
                              /*~E:I898*/
                              /*~-1*/
#endif
                              /*~E:I897*/
                              /*~E:A896*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F895*/
                              /*~F:899*/
                              case 1:
                              /*~-1*/
                              {
                              /*~A:900*/
                              /*~+:Kanal 1*/
                              /*~I:901*/
#ifdef CHANNEL_1
                              /*~T*/
                              nCorVal = Compensation_GetCompensationValue((char)Parameter[1].nLong);
                              /*~I:902*/
                              if ((char)Parameter[1].nLong == 20)
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_COMPENSATION_REFPOINT_OFFSET_CHANNEL_1,nCorVal,1,0);
                              /*~-1*/
                              }
                              /*~O:I902*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_COMPENSATION_REFPOINT_CHANNEL_1,nCorVal,1,0);
                              /*~-1*/
                              }
                              /*~E:I902*/
                              /*~-1*/
#endif
                              /*~E:I901*/
                              /*~E:A900*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F899*/
                              /*~O:C894*/
                              /*~-2*/
                              default:
                              {
                              /*~A:903*/
                              /*~+:Kanal 0*/
                              /*~I:904*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I904*/
                              /*~E:A903*/
                              /*~-1*/
                              }
                           /*~-1*/
                           }
                           /*~E:C894*/
                        /*~-1*/
                        }
                        /*~O:I893*/
                        /*~-2*/
                        else
                        {
                           /*~A:905*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A905*/
                        /*~-1*/
                        }
                        /*~E:I893*/
                     /*~-1*/
                     }
                     /*~E:I892*/
                     /*~E:A891*/
                     /*~A:906*/
                     /*~+:GDB - GetDeBugvariables*/
                     /*~I:907*/
#ifdef MIT_DEBUG
                     /*~I:908*/
                     if (!strcmp(szCommand,"GDB"))
                     /*~-1*/
                     {
                        /*~A:909*/
                        /*~+:Variablendeklarationen*/
                        /*~T*/
                        char byCounter;
                        /*~I:910*/
#ifdef CHANNEL_0
                        /*~T*/
                        long lDebVar[DEBUG_NB_DEBUGVARIABLES];

                        /*~-1*/
#endif
                        /*~E:I910*/
                        /*~E:A909*/
                        /*~A:911*/
                        /*~+:Variableninitialisierungen*/
                        /*~T*/
                        byCounter = 0;
                        /*~E:A911*/
                        /*~T*/
                        // Text wurde bereits gesendet
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:912*/
                        if (!InstructionDecoder_CheckNbParameters(2,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0);
                           Parameter[1].nLong = Communication_GetLongParameter(1);
                           /*~C:913*/
                           switch (Parameter[0].nLong)
                           /*~-1*/
                           {
                              /*~F:914*/
                              case 0:
                              /*~-1*/
                              {
                              /*~A:915*/
                              /*~+:Kanal 0*/
                              /*~I:916*/
#ifdef CHANNEL_0
                              /*~T*/
                              // Debug-Variablen aus dem Eeprom laden
                              Load_Parameter(LOAD_SAVE_DEBUG_VARIABLES,lDebVar,4*DEBUG_NB_DEBUGVARIABLES);
                              /*~U:917*/
                              /*~-2*/
                              do
                              {
                              /*~I:918*/
                              // Variablenindex ausgeben
                              if (Parameter[1].nLong == 255)
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_CONTENT_DEBUG_VARIABLES_CHANNEL_0,byCounter,1,0);

                              /*~-1*/
                              }
                              /*~O:I918*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_CONTENT_DEBUG_VARIABLES_CHANNEL_0,Parameter[1].nLong,1,0);

                              /*~-1*/
                              }
                              /*~E:I918*/
                              /*~T*/
                              // Doppelpunkt
                              Communication_SendString(COMMUNICATION_RS232," : ",0,0);
                              /*~I:919*/
                              // Variableninhalt ausgeben
                              if (Parameter[1].nLong == 255)
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,0,lDebVar[byCounter++],0,0);
                              /*~-1*/
                              }
                              /*~O:I919*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,0,lDebVar[Parameter[1].nLong],0,0);

                              byCounter = 8;
                              /*~-1*/
                              }
                              /*~E:I919*/
                              /*~-1*/
                              }
                              /*~O:U917*/
                              while (byCounter < 8);
                              /*~E:U917*/
                              /*~-1*/
#endif
                              /*~E:I916*/
                              /*~E:A915*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F914*/
                              /*~F:920*/
                              case 1:
                              /*~-1*/
                              {
                              /*~A:921*/
                              /*~+:Kanal 1*/
                              /*~I:922*/
#ifdef CHANNEL_1
                              /*~T*/
                              // Debug-Variablen aus dem Eeprom laden
                              Load_Parameter(LOAD_SAVE_DEBUG_VARIABLES,lDebVar,4*DEBUG_NB_DEBUGVARIABLES);
                              /*~U:923*/
                              /*~-2*/
                              do
                              {
                              /*~I:924*/
                              // Variablenindex ausgeben
                              if (Parameter[1].nLong == 255)
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_CONTENT_DEBUG_VARIABLES_CHANNEL_1,byCounter,1,0);

                              /*~-1*/
                              }
                              /*~O:I924*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_CONTENT_DEBUG_VARIABLES_CHANNEL_1,Parameter[1].nLong,1,0);

                              /*~-1*/
                              }
                              /*~E:I924*/
                              /*~T*/
                              // Doppelpunkt
                              Communication_SendString(COMMUNICATION_RS232," : ",0,0);
                              /*~I:925*/
                              // Variableninhalt ausgeben
                              if (Parameter[1].nLong == 255)
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,0,lDebVar[byCounter++],0,0);
                              /*~-1*/
                              }
                              /*~O:I925*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,0,lDebVar[Parameter[1].nLong],0,0);

                              byCounter = 8;
                              /*~-1*/
                              }
                              /*~E:I925*/
                              /*~-1*/
                              }
                              /*~O:U923*/
                              while (byCounter < 8);
                              /*~E:U923*/
                              /*~-1*/
#endif
                              /*~E:I922*/
                              /*~E:A921*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F920*/
                              /*~O:C913*/
                              /*~-2*/
                              default:
                              {
                              /*~A:926*/
                              /*~+:Kanal 0*/
                              /*~I:927*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I927*/
                              /*~E:A926*/
                              /*~-1*/
                              }
                           /*~-1*/
                           }
                           /*~E:C913*/
                        /*~-1*/
                        }
                        /*~O:I912*/
                        /*~-2*/
                        else
                        {
                           /*~A:928*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A928*/
                        /*~-1*/
                        }
                        /*~E:I912*/
                     /*~-1*/
                     }
                     /*~E:I908*/
                     /*~-1*/
#endif
                     /*~E:I907*/
                     /*~E:A906*/
                     /*~A:929*/
                     /*~+:GEC - GetE-modulCompensationstate*/
                     /*~I:930*/
                     if (!strcmp(szCommand,"GEC"))
                     /*~-1*/
                     {
                        /*~A:931*/
                        /*~+:Variablendeklarationen*/
                        /*~I:932*/
#ifdef CHANNEL_0
                        /*~T*/
                        long lECompPartnerOn;

                        /*~-1*/
#endif
                        /*~E:I932*/
                        /*~E:A931*/
                        /*~T*/
                        // Text wurde bereits gesendet
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:933*/
                        if (!InstructionDecoder_CheckNbParameters(0,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           byTemp = Weight_GetEModulCompensationOnOff();
                           /*~I:934*/
#ifdef CHANNEL_0
                           /*~I:935*/
                           if (!Communication_GetSPIValue(COMMUNICATION_E_COMPENSATION_STATE,&lECompPartnerOn))
                           /*~-1*/
                           {
                              /*~I:936*/
                              if ((char)lECompPartnerOn == byTemp)
                              /*~-1*/
                              {
                              /*~I:937*/
                              if (!SYSTEM_MRW_MANAGER)
                              /*~-1*/
                              {
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              /*~I:938*/
                              if (byTemp)
                              /*~-1*/
                              {
                              /*~T*/
                              lText2Send = TEXT_E_MODUL_COMPENSATION_SWITCHED_ON;
                              /*~-1*/
                              }
                              /*~O:I938*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              lText2Send = TEXT_E_MODUL_COMPENSATION_SWITCHED_OFF;
                              /*~-1*/
                              }
                              /*~E:I938*/
                              /*~-1*/
                              }
                              /*~O:I937*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,0,byTemp,1,0);
                              /*~-1*/
                              }
                              /*~E:I937*/
                              /*~-1*/
                              }
                              /*~O:I936*/
                              /*~-2*/
                              else
                              {
                              /*~A:939*/
                              /*~+:Fehler - Werte beider Kan�le sind nicht identisch - E011*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E011;
                              /*~E:A939*/
                              /*~-1*/
                              }
                              /*~E:I936*/
                           /*~-1*/
                           }
                           /*~O:I935*/
                           /*~-2*/
                           else
                           {
                              /*~A:940*/
                              /*~+:Fehler bei der Kommunikation - E005*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A940*/
                           /*~-1*/
                           }
                           /*~E:I935*/
                           /*~O:I934*/
                           /*~-1*/
#else
                           /*~I:941*/
#ifdef CHANNEL_1
                           /*~T*/
                           InstructionDecoder_StoreValue(COMMUNICATION_E_COMPENSATION_STATE,(GLOBAL_UNIVALUE_SHORT*)&byTemp);
                           /*~-1*/
#endif
                           /*~E:I941*/
                           /*~-1*/
#endif
                           /*~E:I934*/
                        /*~-1*/
                        }
                        /*~O:I933*/
                        /*~-2*/
                        else
                        {
                           /*~A:942*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A942*/
                        /*~-1*/
                        }
                        /*~E:I933*/
                     /*~-1*/
                     }
                     /*~E:I930*/
                     /*~E:A929*/
                     /*~A:943*/
                     /*~+:GFB - GetFeedBackstate*/
                     /*~I:944*/
                     if (!strcmp(szCommand,"GFB"))
                     /*~-1*/
                     {
                        /*~A:945*/
                        /*~+:Variablendeklarationen*/
                        /*~T*/
                        char byRetVal;

                        /*~I:946*/
#ifdef CHANNEL_0 
                        /*~T*/
                        long lFeedbackStatePartner;
                        /*~-1*/
#endif
                        /*~E:I946*/
                        /*~E:A945*/
                        /*~I:947*/
                        if (!InstructionDecoder_CheckNbParameters(0,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           byRetVal = CurrentInterface_GetFeedBackState();
                           /*~I:948*/
#ifdef CHANNEL_0
                           /*~I:949*/
                           if (!Communication_GetSPIValue(COMMUNICATION_CURRENTINTERFACE_FEEDBACK_STATE,&lFeedbackStatePartner))
                           /*~-1*/
                           {
                              /*~I:950*/
                              if ((char)lFeedbackStatePartner == byRetVal)
                              /*~-1*/
                              {
                              /*~I:951*/
                              if (!SYSTEM_MRW_MANAGER)
                              /*~-1*/
                              {
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              /*~I:952*/
                              if (byRetVal)
                              /*~-1*/
                              {
                              /*~T*/
                              lText2Send = TEXT_FEEDBACK_STATE_ON;
                              /*~-1*/
                              }
                              /*~O:I952*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              lText2Send = TEXT_FEEDBACK_STATE_OFF;
                              /*~-1*/
                              }
                              /*~E:I952*/
                              /*~-1*/
                              }
                              /*~O:I951*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,0,byRetVal,1,0);
                              /*~-1*/
                              }
                              /*~E:I951*/
                              /*~-1*/
                              }
                              /*~O:I950*/
                              /*~-2*/
                              else
                              {
                              /*~A:953*/
                              /*~+:Fehler - Werte beider Kan�le sind nicht identisch - E011*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E011;
                              /*~E:A953*/
                              /*~-1*/
                              }
                              /*~E:I950*/
                           /*~-1*/
                           }
                           /*~O:I949*/
                           /*~-2*/
                           else
                           {
                              /*~A:954*/
                              /*~+:Fehler bei der Kommunikation - E005*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A954*/
                           /*~-1*/
                           }
                           /*~E:I949*/
                           /*~O:I948*/
                           /*~-1*/
#else
                           /*~I:955*/
#ifdef CHANNEL_1 
                           /*~T*/
                           InstructionDecoder_StoreValue(COMMUNICATION_CURRENTINTERFACE_FEEDBACK_STATE,(GLOBAL_UNIVALUE_SHORT*)&byRetVal);
                           /*~-1*/
#endif
                           /*~E:I955*/
                           /*~-1*/
#endif
                           /*~E:I948*/
                        /*~-1*/
                        }
                        /*~O:I947*/
                        /*~-2*/
                        else
                        {
                           /*~A:956*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A956*/
                        /*~-1*/
                        }
                        /*~E:I947*/
                     /*~-1*/
                     }
                     /*~E:I944*/
                     /*~E:A943*/
                     /*~A:957*/
                     /*~+:GFD - GetFilterDepth*/
                     /*~I:958*/
                     if (!strcmp(szCommand,"GFD"))
                     /*~-1*/
                     {
                        /*~A:959*/
                        /*~+:Variablendeklarationen*/
                        /*~I:960*/
#ifdef CHANNEL_0
                        /*~T*/
                        long lFilterdepthPartner;

                        /*~-1*/
#endif
                        /*~E:I960*/
                        /*~E:A959*/
                        /*~T*/
                        // Text wurde bereits gesendet
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:961*/
                        if (!InstructionDecoder_CheckNbParameters(0,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           byTemp = AverageFilter_GetFilterDepth(WEIGHT_WEIGHTCHANNEL);
                           /*~I:962*/
#ifdef CHANNEL_0
                           /*~I:963*/
                           if (!Communication_GetSPIValue(COMMUNICATION_FILTER_DEPTH,&lFilterdepthPartner))
                           /*~-1*/
                           {
                              /*~I:964*/
                              if ((char)lFilterdepthPartner == byTemp)
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_AVERAGE_FILTER_ACTUAL_DEPTH,(char)byTemp,1,0);
                              /*~-1*/
                              }
                              /*~O:I964*/
                              /*~-2*/
                              else
                              {
                              /*~A:965*/
                              /*~+:Fehler - Werte beider Kan�le sind nicht identisch - E011*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E011;
                              /*~E:A965*/
                              /*~-1*/
                              }
                              /*~E:I964*/
                           /*~-1*/
                           }
                           /*~O:I963*/
                           /*~-2*/
                           else
                           {
                              /*~A:966*/
                              /*~+:Fehler bei der Kommunikation - E005*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A966*/
                           /*~-1*/
                           }
                           /*~E:I963*/
                           /*~O:I962*/
                           /*~-1*/
#else
                           /*~I:967*/
#ifdef CHANNEL_1
                           /*~T*/
                           InstructionDecoder_StoreValue(COMMUNICATION_FILTER_DEPTH,(GLOBAL_UNIVALUE_SHORT*)&byTemp);
                           /*~-1*/
#endif
                           /*~E:I967*/
                           /*~-1*/
#endif
                           /*~E:I962*/
                        /*~-1*/
                        }
                        /*~O:I961*/
                        /*~-2*/
                        else
                        {
                           /*~A:968*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A968*/
                        /*~-1*/
                        }
                        /*~E:I961*/
                     /*~-1*/
                     }
                     /*~E:I958*/
                     /*~E:A957*/
                     /*~I:969*/
#ifdef SYSTEM_CND_WITH_DEADBAND_FILTER
                     /*~A:970*/
                     /*~+:GFW - GetFilterWidth*/
                     /*~I:971*/
                     if (!strcmp(szCommand,"GFW"))
                     /*~-1*/
                     {
                        /*~A:972*/
                        /*~+:Variablendeklarationen*/
                        /*~T*/
                        int nFilterBandWidth;

                        /*~I:973*/
#ifdef CHANNEL_0
                        /*~T*/
                        long lFilterBandWidthPartner;
                        /*~-1*/
#endif
                        /*~E:I973*/
                        /*~E:A972*/
                        /*~A:974*/
                        /*~+:Variableninitialsierungen*/
                        /*~T*/

                        /*~E:A974*/
                        /*~T*/
                        // Text wurde bereits gesendet
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:975*/
                        if (!InstructionDecoder_CheckNbParameters(0,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           nFilterBandWidth = (int)DeadBandFilter_GetBandWidth(WEIGHT_WEIGHTCHANNEL); 
                           /*~I:976*/
#ifdef CHANNEL_0
                           /*~I:977*/
                           if (!Communication_GetSPIValue(COMMUNICATION_FILTER_WIDTH,&lFilterBandWidthPartner))

                           /*~-1*/
                           {
                              /*~I:978*/
                              if (lFilterBandWidthPartner == nFilterBandWidth)
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_DEADBAND_FILTER_ACTUAL_WIDTH_CHANNEL_0,(long)nFilterBandWidth,1,0);
                              /*~-1*/
                              }
                              /*~O:I978*/
                              /*~-2*/
                              else
                              {
                              /*~A:979*/
                              /*~+:Fehler - Werte beider Kan�le sind nicht identisch - E011*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E011;
                              /*~E:A979*/
                              /*~-1*/
                              }
                              /*~E:I978*/
                           /*~-1*/
                           }
                           /*~O:I977*/
                           /*~-2*/
                           else
                           {
                              /*~A:980*/
                              /*~+:Fehler bei der Kommunikation - E005*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A980*/
                           /*~-1*/
                           }
                           /*~E:I977*/
                           /*~O:I976*/
                           /*~-1*/
#else
                           /*~I:981*/
#ifdef CHANNEL_1
                           /*~T*/
                           InstructionDecoder_StoreValue(COMMUNICATION_FILTER_WIDTH,(GLOBAL_UNIVALUE_SHORT*)&nFilterBandWidth);
                           /*~-1*/
#endif
                           /*~E:I981*/
                           /*~-1*/
#endif
                           /*~E:I976*/
                        /*~-1*/
                        }
                        /*~O:I975*/
                        /*~-2*/
                        else
                        {
                           /*~A:982*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A982*/
                        /*~-1*/
                        }
                        /*~E:I975*/
                     /*~-1*/
                     }
                     /*~E:I971*/
                     /*~E:A970*/
                     /*~O:I969*/
                     /*~-1*/
#else
                     /*~A:983*/
                     /*~+:GFW - GetFilterWidth*/
                     /*~I:984*/
                     if (!strcmp(szCommand,"GFW"))
                     /*~-1*/
                     {
                        /*~A:985*/
                        /*~+:Variablendeklarationen*/
                        /*~T*/
                        int nFilterBandWidth;

                        /*~I:986*/
#ifdef CHANNEL_0
                        /*~T*/
                        long lFilterBandWidthPartner;
                        /*~-1*/
#endif
                        /*~E:I986*/
                        /*~E:A985*/
                        /*~A:987*/
                        /*~+:Variableninitialsierungen*/
                        /*~T*/

                        /*~E:A987*/
                        /*~T*/
                        // Text wurde bereits gesendet
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:988*/
#ifdef CHANNEL_0
                        /*~T*/
                        Communication_SendLong(COMMUNICATION_RS232,TEXT_DEADBAND_FILTER_ACTUAL_WIDTH_CHANNEL_0,0L,1,0);
                        /*~-1*/
#endif
                        /*~E:I988*/
                     /*~-1*/
                     }
                     /*~E:I984*/
                     /*~E:A983*/
                     /*~-1*/
#endif
                     /*~E:I969*/
                     /*~A:989*/
                     /*~+:GID - GetsystemID*/
                     /*~I:990*/
                     if (!strcmp(szCommand,"GID"))
                     /*~-1*/
                     {
                        /*~T*/
                        // Text wurde bereits gesendet
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:991*/
                        if (!InstructionDecoder_CheckNbParameters(0,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~A:992*/
                           /*~+:Kanal 0*/
                           /*~I:993*/
#ifdef CHANNEL_0
                           /*~A:994*/
                           /*~+:Variablendeklarationen*/
                           /*~T*/

                           /*~E:A994*/
                           /*~T*/
                           Communication_SendLong(COMMUNICATION_RS232,TEXT_SYSTEM_ID,Global.ulSystemID,1,0);
                           /*~-1*/
#endif
                           /*~E:I993*/
                           /*~E:A992*/
                        /*~-1*/
                        }
                        /*~O:I991*/
                        /*~-2*/
                        else
                        {
                           /*~A:995*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A995*/
                        /*~-1*/
                        }
                        /*~E:I991*/
                     /*~-1*/
                     }
                     /*~E:I990*/
                     /*~E:A989*/
                     /*~I:996*/
#ifndef OHNE_STROMRUECKFUEHRUNG
                     /*~A:997*/
                     /*~+:GIP - GetIntegralPortion (of Current Feedback)*/
                     /*~I:998*/
                     if (!strcmp(szCommand,"GIP"))
                     /*~-1*/
                     {
                        /*~T*/
                        // Text wurde bereits gesendet
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:999*/
                        if (!InstructionDecoder_CheckNbParameters(0,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           // Da in beiden Kan�len dieser Wert gleich sein muss, gen�gt die Ausgabe des Kanal 0 
                           /*~A:1000*/
                           /*~+:Kanal 0*/
                           /*~I:1001*/
#ifdef CHANNEL_0
                           /*~T*/
                           //Communication_SendLong(COMMUNICATION_RS232,TEXT_FEEDBACK_INTEGRAL_PORTION,100 - CurrentInterface_GetFeedBackIntegralPortion(),1,0);

                           Communication_SendLong(COMMUNICATION_RS232,TEXT_FEEDBACK_INTEGRAL_PORTION,CurrentInterface_GetFeedBackIntegralPortion(),1,0);
                           /*~-1*/
#endif
                           /*~E:I1001*/
                           /*~E:A1000*/
                        /*~-1*/
                        }
                        /*~O:I999*/
                        /*~-2*/
                        else
                        {
                           /*~A:1002*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1002*/
                        /*~-1*/
                        }
                        /*~E:I999*/
                     /*~-1*/
                     }
                     /*~E:I998*/
                     /*~E:A997*/
                     /*~-1*/
#endif
                     /*~E:I996*/
                     /*~A:1003*/
                     /*~+:GLC - GetLoadCell*/
                     /*~I:1004*/
                     if (!strcmp(szCommand,"GLC"))
                     /*~-1*/
                     {
                        /*~A:1005*/
                        /*~+:Variablendeklarationen*/
                        /*~I:1006*/
#ifdef CHANNEL_0
                        /*~T*/
                        long lLoadCellTypePartner;
                        /*~-1*/
#endif
                        /*~E:I1006*/
                        /*~E:A1005*/
                        /*~A:1007*/
                        /*~+:Variableninitialisierungen*/
                        /*~T*/

                        /*~E:A1007*/
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:1008*/
                        if (!InstructionDecoder_CheckNbParameters(0,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~I:1009*/
#ifdef CHANNEL_0
                           /*~I:1010*/
                           if (!Communication_GetSPIValue(COMMUNICATION_LOADCELL,&lLoadCellTypePartner))
                           /*~-1*/
                           {
                              /*~I:1011*/
                              if (lLoadCellTypePartner == g_SystemControl.byLoadCellType)
                              /*~-1*/
                              {
                              /*~I:1012*/
                              if (!SYSTEM_MRW_MANAGER)
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendString(COMMUNICATION_RS232,T_TEXT_LOADCELL_TYPE,1,0);

                              /*~C:1013*/
                              switch (g_SystemControl.byLoadCellType)
                              /*~-1*/
                              {
                              /*~F:1014*/
                              case 1:
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendString(COMMUNICATION_RS232,T_TEXT_STANDARD_LOADCELL,0,0);

                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1014*/
                              /*~F:1015*/
                              case 2:
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendString(COMMUNICATION_RS232,T_TEXT_XL_LOADCELL,0,0);

                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1015*/
                              /*~O:C1013*/
                              /*~-2*/
                              default:
                              {
                              /*~T*/
                              Communication_SendString(COMMUNICATION_RS232,T_TEXT_CELLTYPE_NOT_DEFINED,0,0);

                              /*~-1*/
                              }
                              /*~-1*/
                              }
                              /*~E:C1013*/
                              /*~-1*/
                              }
                              /*~O:I1012*/
                              /*~-2*/
                              else
                              {
                              /*~I:1016*/
                              if (g_SystemControl.byLoadCellType < 3)
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_LOADCELL_TYPE,g_SystemControl.byLoadCellType,1,0);
                              /*~-1*/
                              }
                              /*~O:I1016*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_LOADCELL_TYPE,0,1,0);
                              /*~-1*/
                              }
                              /*~E:I1016*/
                              /*~-1*/
                              }
                              /*~E:I1012*/
                              /*~-1*/
                              }
                              /*~O:I1011*/
                              /*~-2*/
                              else
                              {
                              /*~A:1017*/
                              /*~+:Fehler - Wertebeider Kan�le sind nicht identisch - E011*/
                              /*~T*/
                              // Fehler - Wertebeider Kan�le sind nicht identisch
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E011;
                              /*~E:A1017*/
                              /*~-1*/
                              }
                              /*~E:I1011*/
                           /*~-1*/
                           }
                           /*~O:I1010*/
                           /*~-2*/
                           else
                           {
                              /*~A:1018*/
                              /*~+:Fehler bei der Kommunikation - E005*/
                              /*~T*/
                              // Fehler bei der Kommunikation - E005
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A1018*/
                           /*~-1*/
                           }
                           /*~E:I1010*/
                           /*~O:I1009*/
                           /*~-1*/
#else
                           /*~I:1019*/
#ifdef CHANNEL_1 
                           /*~T*/
                           InstructionDecoder_StoreValue(COMMUNICATION_LOADCELL,(GLOBAL_UNIVALUE_SHORT*)&g_SystemControl.byLoadCellType);
                           /*~-1*/
#endif
                           /*~E:I1019*/
                           /*~-1*/
#endif
                           /*~E:I1009*/
                        /*~-1*/
                        }
                        /*~O:I1008*/
                        /*~-2*/
                        else
                        {
                           /*~A:1020*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1020*/
                        /*~-1*/
                        }
                        /*~E:I1008*/
                     /*~-1*/
                     }
                     /*~E:I1004*/
                     /*~E:A1003*/
                     /*~A:1021*/
                     /*~+:GML - GetMaxLoad*/
                     /*~I:1022*/
                     if (!strcmp(szCommand,"GML"))
                     /*~-1*/
                     {
                        /*~T*/
                        // Text wurde bereits gesendet
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~A:1023*/
                        /*~+:Kanal 0*/
                        /*~I:1024*/
#ifdef CHANNEL_0
                        /*~I:1025*/
                        if (!InstructionDecoder_CheckNbParameters(0,1,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~I:1026*/
                           if (!SYSTEM_MRW_MANAGER)
                           /*~-1*/
                           {
                              /*~T*/
                              Communication_SendString(COMMUNICATION_RS232,T_TEXT_MAX_SYSTEMLOAD,1,0);

                           /*~-1*/
                           }
                           /*~E:I1026*/
                           /*~T*/
                           Communication_SendString(COMMUNICATION_RS232,TEXT_MAX_LOAD,0,0);
                        /*~-1*/
                        }
                        /*~O:I1025*/
                        /*~-2*/
                        else
                        {
                           /*~A:1027*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1027*/
                        /*~-1*/
                        }
                        /*~E:I1025*/
                        /*~-1*/
#endif
                        /*~E:I1024*/
                        /*~E:A1023*/
                     /*~-1*/
                     }
                     /*~E:I1022*/
                     /*~E:A1021*/
                     /*~I:1028*/
#ifdef MIT_EINSTELLBARER_MESSWERTTIEFE
                     /*~A:1029*/
                     /*~+:GNM - GetNumberMeasurements*/
                     /*~I:1030*/
                     if (!strcmp(szCommand,"GNM"))
                     /*~-1*/
                     {
                        /*~A:1031*/
                        /*~+:Variablendeklarationen*/
                        /*~I:1032*/
#ifdef CHANNEL_0
                        /*~T*/
                        long lMeasurementDepthPartner;
                        /*~-1*/
#endif
                        /*~E:I1032*/
                        /*~E:A1031*/
                        /*~A:1033*/
                        /*~+:Variableninitialsierungen*/
                        /*~T*/

                        /*~E:A1033*/
                        /*~T*/
                        // Text wurde bereits gesendet
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:1034*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0);
                           /*~K*/
                           /*~+:*/
                           /*~I:1035*/
                           if (Parameter[0].nLong < 2)
                           /*~-1*/
                           {
                              /*~I:1036*/
                              if (!Parameter[0].nLong)
                              /*~-1*/
                              {
                              /*~T*/
                              ADuC836_ADCGetMeasurementDepth(ADuC836_ADC_PRIMARY,&byTemp);
                              /*~-1*/
                              }
                              /*~O:I1036*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              ADuC836_ADCGetMeasurementDepth(ADuC836_ADC_PRIMARY_TOGGLE,&byTemp);
                              /*~-1*/
                              }
                              /*~E:I1036*/
                              /*~I:1037*/
#ifdef CHANNEL_0
                              /*~I:1038*/
                              if (!Communication_GetSPIValue(COMMUNICATION_NUMBER_OF_MEASUREMENTS,&lMeasurementDepthPartner))
                              /*~-1*/
                              {
                              /*~I:1039*/
                              if ((char)lMeasurementDepthPartner == byTemp)
                              /*~-1*/
                              {
                              /*~I:1040*/
                              if (!Parameter[0].nLong)
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_MEASUREMENT_DEPTH_RMW_CHANNEL_0,byTemp,1,0);
                              /*~-1*/
                              }
                              /*~O:I1040*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_MEASUREMENT_DEPTH_FEEDBACK_CHANNEL_0,byTemp,1,0);
                              /*~-1*/
                              }
                              /*~E:I1040*/
                              /*~-1*/
                              }
                              /*~O:I1039*/
                              /*~-2*/
                              else
                              {
                              /*~A:1041*/
                              /*~+:Fehler - Werte beider Kan�le sind nicht identisch - E011*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E011;
                              /*~E:A1041*/
                              /*~-1*/
                              }
                              /*~E:I1039*/
                              /*~-1*/
                              }
                              /*~O:I1038*/
                              /*~-2*/
                              else
                              {
                              /*~A:1042*/
                              /*~+:Fehler bei der Kommunikation - E005*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A1042*/
                              /*~-1*/
                              }
                              /*~E:I1038*/
                              /*~O:I1037*/
                              /*~-1*/
#else
                              /*~I:1043*/
#ifdef CHANNEL_1
                              /*~T*/
                              InstructionDecoder_StoreValue(COMMUNICATION_NUMBER_OF_MEASUREMENTS,(GLOBAL_UNIVALUE_SHORT*)&byTemp);
                              /*~-1*/
#endif
                              /*~E:I1043*/
                              /*~-1*/
#endif
                              /*~E:I1037*/
                           /*~-1*/
                           }
                           /*~O:I1035*/
                           /*~-2*/
                           else
                           {
                              /*~I:1044*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I1044*/
                           /*~-1*/
                           }
                           /*~E:I1035*/
                        /*~-1*/
                        }
                        /*~O:I1034*/
                        /*~-2*/
                        else
                        {
                           /*~A:1045*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1045*/
                        /*~-1*/
                        }
                        /*~E:I1034*/
                     /*~-1*/
                     }
                     /*~E:I1030*/
                     /*~E:A1029*/
                     /*~-1*/
#endif
                     /*~E:I1028*/
                     /*~I:1046*/
#ifndef OHNE_STROMRUECKFUEHRUNG
                     /*~A:1047*/
                     /*~+:GPP - GetProportionalPortion (of Current Feedback)*/
                     /*~I:1048*/
                     if (!strcmp(szCommand,"GPP"))
                     /*~-1*/
                     {
                        /*~T*/
                        // Text wurde bereits gesendet
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:1049*/
                        if (!InstructionDecoder_CheckNbParameters(0,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           // Da in beiden Kan�len dieser Wert gleich sein muss, gen�gt die Ausgabe des Kanal 0 
                           /*~A:1050*/
                           /*~+:Kanal 0*/
                           /*~I:1051*/
#ifdef CHANNEL_0
                           /*~T*/
                           Communication_SendLong(COMMUNICATION_RS232,TEXT_FEEDBACK_PROPORTIONAL_PORTION,100 - CurrentInterface_GetFeedBackProportionalPortion(),1,0);
                           /*~-1*/
#endif
                           /*~E:I1051*/
                           /*~E:A1050*/
                        /*~-1*/
                        }
                        /*~O:I1049*/
                        /*~-2*/
                        else
                        {
                           /*~A:1052*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1052*/
                        /*~-1*/
                        }
                        /*~E:I1049*/
                     /*~-1*/
                     }
                     /*~E:I1048*/
                     /*~E:A1047*/
                     /*~-1*/
#endif
                     /*~E:I1046*/
                     /*~A:1053*/
                     /*~+:GSU - GetpowerSUpply*/
                     /*~I:1054*/
                     if (!strcmp(szCommand,"GSU"))
                     /*~-1*/
                     {
                        /*~T*/
                        // Text wurde bereits gesendet
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:1055*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0);
                           /*~C:1056*/
                           switch (Parameter[0].nLong)
                           /*~-1*/
                           {
                              /*~F:1057*/
                              case 0:
                              /*~-1*/
                              {
                              /*~A:1058*/
                              /*~+:Kanal 0*/
                              /*~I:1059*/
#ifdef CHANNEL_0
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_POWERSUPPLY_CHANNEL_0,Global.lRMW_PowerSupply,1,0);
                              /*~-1*/
#endif
                              /*~E:I1059*/
                              /*~E:A1058*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1057*/
                              /*~I:1060*/
#ifdef VCC_CHECK_ON_BOTH_CHANELS
                              /*~F:1061*/
                              case 1:
                              /*~-1*/
                              {
                              /*~A:1062*/
                              /*~+:Kanal 1*/
                              /*~I:1063*/
#ifdef CHANNEL_1
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_POWERSUPPLY_CHANNEL_1,Global.lRMW_PowerSupply,1,0);
                              /*~-1*/
#endif
                              /*~E:I1063*/
                              /*~E:A1062*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1061*/
                              /*~-1*/
#endif
                              /*~E:I1060*/
                              /*~O:C1056*/
                              /*~-2*/
                              default:
                              {
                              /*~A:1064*/
                              /*~+:Kanal 0*/
                              /*~I:1065*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I1065*/
                              /*~E:A1064*/
                              /*~-1*/
                              }
                           /*~-1*/
                           }
                           /*~E:C1056*/
                        /*~-1*/
                        }
                        /*~O:I1055*/
                        /*~-2*/
                        else
                        {
                           /*~A:1066*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1066*/
                        /*~-1*/
                        }
                        /*~E:I1055*/
                     /*~-1*/
                     }
                     /*~E:I1054*/
                     /*~E:A1053*/
                     /*~A:1067*/
                     /*~+:GSD - GetStatisticsData*/
                     /*~I:1068*/
                     if (!strcmp(szCommand,"GSD"))
                     /*~-1*/
                     {
                        /*~T*/
                        // Text wurde bereits gesendet
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:1069*/
                        if (!InstructionDecoder_CheckNbParameters(2,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0);
                           Parameter[1].nLong = Communication_GetLongParameter(1);
                           /*~C:1070*/
                           switch (Parameter[0].nLong)
                           /*~-1*/
                           {
                              /*~F:1071*/
                              case 0:
                              case 2:
                              /*~-1*/
                              {
                              /*~I:1072*/
#ifdef CHANNEL_0
                              /*~A:1073*/
                              /*~+:Kanal 0 - Absolutstatistik(0) - Relativstatistik(2)*/
                              /*~I:1074*/
                              if (Parameter[0].nLong == 0)
                              /*~-1*/
                              {
                              /*~A:1075*/
                              /*~+:Absolutstatistik*/
                              /*~K*/
                              /*~+:// Absolutstatistik*/
                              /*~T*/
                              Statistics_PrintData(Parameter[1].nLong);
                              /*~E:A1075*/
                              /*~-1*/
                              }
                              /*~O:I1074*/
                              /*~-2*/
                              else
                              {
                              /*~A:1076*/
                              /*~+:Relativstatistik*/
                              /*~K*/
                              /*~+:// Relativstatistik*/
                              /*~T*/
                              Statistics_PrintData(Parameter[1].nLong | 0x40);
                              /*~E:A1076*/
                              /*~-1*/
                              }
                              /*~E:I1074*/
                              /*~E:A1073*/
                              /*~-1*/
#endif
                              /*~E:I1072*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1071*/
                              /*~F:1077*/
                              case 1:
                              case 3:
                              /*~-1*/
                              {
                              /*~I:1078*/
#ifdef CHANNEL_1
                              /*~A:1079*/
                              /*~+:Kanal 1 - Absolutstatistik(1) - Relativstatistik(3)*/
                              /*~I:1080*/
                              if (Parameter[0].nLong == 1)
                              /*~-1*/
                              {
                              /*~A:1081*/
                              /*~+:Absolutstatistik*/
                              /*~T*/
                              Statistics_PrintData(Parameter[1].nLong);
                              /*~E:A1081*/
                              /*~-1*/
                              }
                              /*~O:I1080*/
                              /*~-2*/
                              else
                              {
                              /*~A:1082*/
                              /*~+:Relativstatistik*/
                              /*~T*/
                              Statistics_PrintData((Parameter[1].nLong | 0x40));
                              /*~E:A1082*/
                              /*~-1*/
                              }
                              /*~E:I1080*/
                              /*~E:A1079*/
                              /*~-1*/
#endif
                              /*~E:I1078*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1077*/
                              /*~O:C1070*/
                              /*~-2*/
                              default:
                              {
                              /*~A:1083*/
                              /*~+:Kanal 0*/
                              /*~I:1084*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I1084*/
                              /*~E:A1083*/
                              /*~-1*/
                              }
                           /*~-1*/
                           }
                           /*~E:C1070*/
                        /*~-1*/
                        }
                        /*~O:I1069*/
                        /*~-2*/
                        else
                        {
                           /*~A:1085*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1085*/
                        /*~-1*/
                        }
                        /*~E:I1069*/
                     /*~-1*/
                     }
                     /*~E:I1068*/
                     /*~E:A1067*/
                     /*~A:1086*/
                     /*~+:GSN - GetSerialNumber*/
                     /*~I:1087*/
                     if (!strcmp(szCommand,"GSN"))
                     /*~-1*/
                     {
                        /*~T*/
                        // Text wurde bereits gesendet
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~A:1088*/
                        /*~+:Kanal 0*/
                        /*~I:1089*/
#ifdef CHANNEL_0
                        /*~I:1090*/
                        if (!InstructionDecoder_CheckNbParameters(0,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~I:1091*/
                           if (!SYSTEM_MRW_MANAGER)
                           /*~-1*/
                           {
                              /*~T*/
                              Communication_SendString(COMMUNICATION_RS232,T_TEXT_SERIAL_NUMBER,1,0);

                           /*~-1*/
                           }
                           /*~E:I1091*/
                           /*~T*/
                           Communication_SendString(COMMUNICATION_RS232,System_GetSerialNumber(),0,0);
                        /*~-1*/
                        }
                        /*~O:I1090*/
                        /*~-2*/
                        else
                        {
                           /*~A:1092*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1092*/
                        /*~-1*/
                        }
                        /*~E:I1090*/
                        /*~-1*/
#endif
                        /*~E:I1089*/
                        /*~E:A1088*/
                     /*~-1*/
                     }
                     /*~E:I1087*/
                     /*~E:A1086*/
                     /*~A:1093*/
                     /*~+:GSP - GetStatisticsParameter*/
                     /*~I:1094*/
                     if (!strcmp(szCommand,"GSP"))
                     /*~-1*/
                     {
                        /*~A:1095*/
                        /*~+:Variablendeklarationen*/
                        /*~T*/
                        STATISTICSLIBRARY_SETUP StatisticsSetup;
                        /*~E:A1095*/
                        /*~A:1096*/
                        /*~+:Variableninitialisierungen*/
                        /*~T*/
                        StatisticsSetup = Statistics_GetSetup();
                        /*~E:A1096*/
                        /*~T*/
                        // Text wurde bereits gesendet
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:1097*/
                        if (!InstructionDecoder_CheckNbParameters(2,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0);
                           Parameter[1].nLong = Communication_GetLongParameter(1);

                           /*~C:1098*/
                           switch (Parameter[0].nLong)
                           /*~-1*/
                           {
                              /*~F:1099*/
                              case 0:	// Parameter der Statistik des Kanal 0 lesen
                              /*~-1*/
                              {
                              /*~A:1100*/
                              /*~+:Kanal 0*/
                              /*~I:1101*/
#ifdef CHANNEL_0
                              /*~C:1102*/
                              switch (Parameter[1].nLong)
                              /*~-1*/
                              {
                              /*~F:1103*/
                              case 0:	// Filter Temperatur�berwachung
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_STATISTICS_FILTER_TEMPERATURE_CHANNEL_0,StatisticsSetup.chFilterCheckTemperature,1,0);
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1103*/
                              /*~F:1104*/
                              case 1:	// Filter Gewichts�berwachung
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_STATISTICS_FILTER_WEIGHT_CHANNEL_0,StatisticsSetup.chFilterCheckWeight,1,0);
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1104*/
                              /*~F:1105*/
                              case 2:	// MotionLimit Gewichts�berwachung
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendFloat(COMMUNICATION_RS232,TEXT_STATISTICS_MOTIONLIMIT_WEIGHT_CHANNEL_0,StatisticsSetup.fMotionLimitCheckWeight,2,1,0);
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1105*/
                              /*~F:1106*/
                              case 3:	// Filter Grenzwert�berschreitung und �berlast
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_STATISTICS_FILTER_OVERLIMIT_CHANNEL_0,StatisticsSetup.chFilterOverLimit,1,0);
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1106*/
                              /*~F:1107*/
                              case 4:	// Grenzwert
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendFloat(COMMUNICATION_RS232,TEXT_STATISTICS_LIMIT_OVERLIMIT_CHANNEL_0,StatisticsSetup.fLimitOverLimit,2,1,0);
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1107*/
                              /*~-1*/
                              }
                              /*~E:C1102*/
                              /*~-1*/
#endif
                              /*~E:I1101*/
                              /*~E:A1100*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1099*/
                              /*~F:1108*/
                              case 1:	// Parameter der Statistik des Kanal 1 lesen
                              /*~-1*/
                              {
                              /*~A:1109*/
                              /*~+:Kanal 1*/
                              /*~I:1110*/
#ifdef CHANNEL_1
                              /*~C:1111*/
                              switch (Parameter[1].nLong)
                              /*~-1*/
                              {
                              /*~F:1112*/
                              case 0:	// Filter Temperatur�berwachung
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_STATISTICS_FILTER_TEMPERATURE_CHANNEL_1,StatisticsSetup.chFilterCheckTemperature,1,0);
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1112*/
                              /*~F:1113*/
                              case 1:	// Filter Gewichts�berwachung
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_STATISTICS_FILTER_WEIGHT_CHANNEL_1,StatisticsSetup.chFilterCheckWeight,1,0);
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1113*/
                              /*~F:1114*/
                              case 2:	// MotionLimit Gewichts�berwachung
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_STATISTICS_FILTER_OVERLIMIT_CHANNEL_1,StatisticsSetup.chFilterOverLimit,1,0);
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1114*/
                              /*~F:1115*/
                              case 3:	// Filter Grenzwert�berschreitung und �berlast
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendFloat(COMMUNICATION_RS232,TEXT_STATISTICS_MOTIONLIMIT_WEIGHT_CHANNEL_1,StatisticsSetup.fMotionLimitCheckWeight,2,1,0);
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1115*/
                              /*~F:1116*/
                              case 4:	// Grenzwert
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendFloat(COMMUNICATION_RS232,TEXT_STATISTICS_LIMIT_OVERLIMIT_CHANNEL_1,StatisticsSetup.fLimitOverLimit,2,1,0);
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1116*/
                              /*~-1*/
                              }
                              /*~E:C1111*/
                              /*~-1*/
#endif
                              /*~E:I1110*/
                              /*~E:A1109*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1108*/
                              /*~O:C1098*/
                              /*~-2*/
                              default:
                              {
                              /*~I:1117*/
#ifdef CHANNEL_0
                              /*~T*/
                              // Fehler
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I1117*/
                              /*~-1*/
                              }
                           /*~-1*/
                           }
                           /*~E:C1098*/
                        /*~-1*/
                        }
                        /*~O:I1097*/
                        /*~-2*/
                        else
                        {
                           /*~A:1118*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1118*/
                        /*~-1*/
                        }
                        /*~E:I1097*/
                     /*~-1*/
                     }
                     /*~E:I1094*/
                     /*~E:A1093*/
                     /*~A:1119*/
                     /*~+:GSS - GetSystemState*/
                     /*~I:1120*/
                     if (!strcmp(szCommand,"GSS"))
                     /*~-1*/
                     {
                        /*~T*/
                        // Text wurde bereits gesendet
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:1121*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0); 
                           /*~C:1122*/
                           switch (Parameter[0].nLong)
                           /*~-1*/
                           {
                              /*~F:1123*/
                              case 0:
                              /*~-1*/
                              {
                              /*~A:1124*/
                              /*~+:Kanal 0*/
                              /*~I:1125*/
#ifdef CHANNEL_0
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_ACTUAL_SYSTEMSTATE_CHANNEL_0,(long)SYSTEMSTATE,1,0);
                              /*~-1*/
#endif
                              /*~E:I1125*/
                              /*~E:A1124*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1123*/
                              /*~F:1126*/
                              case 1:
                              /*~-1*/
                              {
                              /*~A:1127*/
                              /*~+:Kanal 1*/
                              /*~I:1128*/
#ifdef CHANNEL_1
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_ACTUAL_SYSTEMSTATE_CHANNEL_1,(long)SYSTEMSTATE,1,0);
                              /*~-1*/
#endif
                              /*~E:I1128*/
                              /*~E:A1127*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1126*/
                              /*~O:C1122*/
                              /*~-2*/
                              default:
                              {
                              /*~A:1129*/
                              /*~+:Kanal 0*/
                              /*~I:1130*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I1130*/
                              /*~E:A1129*/
                              /*~-1*/
                              }
                           /*~-1*/
                           }
                           /*~E:C1122*/
                        /*~-1*/
                        }
                        /*~O:I1121*/
                        /*~-2*/
                        else
                        {
                           /*~A:1131*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1131*/
                        /*~-1*/
                        }
                        /*~E:I1121*/
                     /*~-1*/
                     }
                     /*~E:I1120*/
                     /*~E:A1119*/
                     /*~A:1132*/
                     /*~+:GTH - GetTimeHysteresis*/
                     /*~I:1133*/
                     if (!strcmp(szCommand,"GTH"))
                     /*~-1*/
                     {
                        /*~A:1134*/
                        /*~+:Variablendeklarationen*/
                        /*~T*/
                        unsigned long ulTimeHysteresis;
                        /*~I:1135*/
#ifdef CHANNEL_0
                        /*~T*/
                        unsigned long ulTimeHysteresisPartner;
                        /*~-1*/
#endif
                        /*~E:I1135*/
                        /*~E:A1134*/
                        /*~T*/
                        // Text wurde bereits gesendet
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:1136*/
                        if (!InstructionDecoder_CheckNbParameters(0,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           ulTimeHysteresis = CurrentInterface_GetTimeHysteresis();
                           /*~I:1137*/
#ifdef CHANNEL_0
                           /*~I:1138*/
                           if (!Communication_GetSPIValue(COMMUNICATION_TIME_HYSTERESIS,&ulTimeHysteresisPartner))
                           /*~-1*/
                           {
                              /*~I:1139*/
                              if (ulTimeHysteresisPartner == ulTimeHysteresis)
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_CURRENT_INTERFACE_TIME_HYSTERESIS,ulTimeHysteresis,1,0);
                              /*~-1*/
                              }
                              /*~O:I1139*/
                              /*~-2*/
                              else
                              {
                              /*~A:1140*/
                              /*~+:Fehler - Werte beider Kan�le sind nicht identisch - E011*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E011;
                              /*~E:A1140*/
                              /*~-1*/
                              }
                              /*~E:I1139*/
                           /*~-1*/
                           }
                           /*~O:I1138*/
                           /*~-2*/
                           else
                           {
                              /*~A:1141*/
                              /*~+:Fehler bei der Kommunikation - E005*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A1141*/
                           /*~-1*/
                           }
                           /*~E:I1138*/
                           /*~O:I1137*/
                           /*~-1*/
#else
                           /*~I:1142*/
#ifdef CHANNEL_1
                           /*~T*/
                           InstructionDecoder_StoreValue(COMMUNICATION_TIME_HYSTERESIS,(GLOBAL_UNIVALUE_SHORT*)&ulTimeHysteresis);
                           /*~-1*/
#endif
                           /*~E:I1142*/
                           /*~-1*/
#endif
                           /*~E:I1137*/
                        /*~-1*/
                        }
                        /*~O:I1136*/
                        /*~-2*/
                        else
                        {
                           /*~A:1143*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1143*/
                        /*~-1*/
                        }
                        /*~E:I1136*/
                     /*~-1*/
                     }
                     /*~E:I1133*/
                     /*~E:A1132*/
                     /*~A:1144*/
                     /*~+:GTM - GetTiMer*/
                     /*~I:1145*/
                     if (!strcmp(szCommand,"GTM"))
                     /*~-1*/
                     {
                        /*~A:1146*/
                        /*~+:Variablendeklarationen*/
                        /*~T*/
                        long lTime;
                        /*~E:A1146*/
                        /*~A:1147*/
                        /*~+:Variableninitialisierungen*/
                        /*~T*/
                        lTime = 0;
                        /*~E:A1147*/
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:1148*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~I:1149*/
#ifdef CHANNEL_0
                           /*~I:1150*/
                           if (Communication_GetLongParameter(0) != 1)
                           /*~-1*/
                           {
                              /*~T*/
                              // Absoluter Betriebsstundenz�hler
                              /*~I:1151*/
                              if (!SYSTEM_MRW_MANAGER)
                              /*~-1*/
                              {
                              /*~A:1152*/
                              /*~+:Docklight-Modus : Zeit als String ausgeben*/
                              /*~T*/
                              Communication_SendString(COMMUNICATION_RS232,T_TEXT_OPERATING_HOURS,1,0);

                              /*~T*/
                              Communication_SendString(COMMUNICATION_RS232,System_GetOperatingHoursAsString(0),0,0);
                              /*~E:A1152*/
                              /*~-1*/
                              }
                              /*~O:I1151*/
                              /*~-2*/
                              else
                              {
                              /*~A:1153*/
                              /*~+:MRW-Manager-Mode : Stunden als Long ausgeben*/
                              /*~I:1154*/
                              if (!Communication_GetLongParameter(0))
                              /*~-1*/
                              {
                              /*~T*/
                              lTime = System_GetOperatingHours(0,0);
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_OPERATING_HOURS,lTime,1,0);

                              /*~-1*/
                              }
                              /*~O:I1154*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              Communication_SendString(COMMUNICATION_RS232,System_GetOperatingHoursAsString(0),0,0);
                              /*~-1*/
                              }
                              /*~E:I1154*/
                              /*~E:A1153*/
                              /*~-1*/
                              }
                              /*~E:I1151*/
                              /*~A:1155*/
                              /*~+:Administratorcode bilden*/
                              /*~T*/
                              // Administratorcode bilden
                              Global.ulAdminCode = System_BuildAdminCode();  
                              /*~E:A1155*/
                           /*~-1*/
                           }
                           /*~O:I1150*/
                           /*~-2*/
                           else
                           {
                              /*~T*/
                              // Relativer Betriebsstundenz�hler
                              /*~I:1156*/
                              if (!SYSTEM_MRW_MANAGER)
                              /*~-1*/
                              {
                              /*~A:1157*/
                              /*~+:Docklight-Modus : Zeit als String ausgeben*/
                              /*~T*/
                              Communication_SendString(COMMUNICATION_RS232,T_TEXT_OPERATING_HOURS_RELATIVE,1,0);
                              /*~T*/
                              Communication_SendString(COMMUNICATION_RS232,System_GetOperatingHoursAsString(1),0,0);
                              /*~E:A1157*/
                              /*~-1*/
                              }
                              /*~O:I1156*/
                              /*~-2*/
                              else
                              {
                              /*~A:1158*/
                              /*~+:MRW-Manager-Mode : Stunden als Long ausgeben*/
                              /*~T*/
                              lTime = System_GetOperatingHours(1,0);
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_OPERATING_HOURS_RELATIVE,lTime,1,0);

                              /*~E:A1158*/
                              /*~-1*/
                              }
                              /*~E:I1156*/
                           /*~-1*/
                           }
                           /*~E:I1150*/
                           /*~-1*/
#endif
                           /*~E:I1149*/
                        /*~-1*/
                        }
                        /*~O:I1148*/
                        /*~-2*/
                        else
                        {
                           /*~A:1159*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1159*/
                        /*~-1*/
                        }
                        /*~E:I1148*/
                     /*~-1*/
                     }
                     /*~E:I1145*/
                     /*~E:A1144*/
                     /*~A:1160*/
                     /*~+:GTO - GetTemperatureOffset*/
                     /*~I:1161*/
                     if (!strcmp(szCommand,"GTO"))
                     /*~-1*/
                     {
                        /*~T*/
                        // Text wurde bereits gesendet
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:1162*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0); 
                           /*~T*/
                           (char)byTemp = Analog_GetTemperatureOffset();
                           /*~C:1163*/
                           switch (Parameter[0].nLong)
                           /*~-1*/
                           {
                              /*~F:1164*/
                              case 0:
                              /*~-1*/
                              {
                              /*~A:1165*/
                              /*~+:Kanal 0*/
                              /*~I:1166*/
#ifdef CHANNEL_0
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_ACTUAL_TEMPERATURE_OFFSET_CHANNEL_0,(char)byTemp,1,0);
                              /*~-1*/
#endif
                              /*~E:I1166*/
                              /*~E:A1165*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1164*/
                              /*~F:1167*/
                              case 1:
                              /*~-1*/
                              {
                              /*~A:1168*/
                              /*~+:Kanal 1*/
                              /*~I:1169*/
#ifdef CHANNEL_1
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_ACTUAL_TEMPERATURE_OFFSET_CHANNEL_1,(char)byTemp,1,0);
                              /*~-1*/
#endif
                              /*~E:I1169*/
                              /*~E:A1168*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1167*/
                              /*~O:C1163*/
                              /*~-2*/
                              default:
                              {
                              /*~A:1170*/
                              /*~+:Kanal 0*/
                              /*~I:1171*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I1171*/
                              /*~E:A1170*/
                              /*~-1*/
                              }
                           /*~-1*/
                           }
                           /*~E:C1163*/
                        /*~-1*/
                        }
                        /*~O:I1162*/
                        /*~-2*/
                        else
                        {
                           /*~A:1172*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1172*/
                        /*~-1*/
                        }
                        /*~E:I1162*/
                     /*~-1*/
                     }
                     /*~E:I1161*/
                     /*~E:A1160*/
                     /*~A:1173*/
                     /*~+:GTR - GetTaRa*/
                     /*~I:1174*/
                     if (!strcmp(szCommand,"GTR"))
                     /*~-1*/
                     {
                        /*~T*/
                        // Text wurde bereits gesendet
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:1175*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0); 
                           /*~C:1176*/
                           switch (Parameter[0].nLong)
                           /*~-1*/
                           {
                              /*~F:1177*/
                              case 0:
                              /*~-1*/
                              {
                              /*~A:1178*/
                              /*~+:Kanal 0*/
                              /*~I:1179*/
#ifdef CHANNEL_0
                              /*~T*/
                              Communication_SendFloat(COMMUNICATION_RS232,TEXT_MEASUREMENT_ACTUAL_TARE_CHANNEL_0,Weight_TareWeight.fFloat,2,1,0);
                              /*~-1*/
#endif
                              /*~E:I1179*/
                              /*~E:A1178*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1177*/
                              /*~F:1180*/
                              case 1:
                              /*~-1*/
                              {
                              /*~A:1181*/
                              /*~+:Kanal 1*/
                              /*~I:1182*/
#ifdef CHANNEL_1
                              /*~T*/
                              Communication_SendFloat(COMMUNICATION_RS232,TEXT_MEASUREMENT_ACTUAL_TARE_CHANNEL_1,Weight_TareWeight.fFloat,2,1,0);
                              /*~-1*/
#endif
                              /*~E:I1182*/
                              /*~E:A1181*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1180*/
                              /*~O:C1176*/
                              /*~-2*/
                              default:
                              {
                              /*~A:1183*/
                              /*~+:Kanal 0*/
                              /*~I:1184*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I1184*/
                              /*~E:A1183*/
                              /*~-1*/
                              }
                           /*~-1*/
                           }
                           /*~E:C1176*/
                        /*~-1*/
                        }
                        /*~O:I1175*/
                        /*~-2*/
                        else
                        {
                           /*~A:1185*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1185*/
                        /*~-1*/
                        }
                        /*~E:I1175*/
                     /*~-1*/
                     }
                     /*~E:I1174*/
                     /*~E:A1173*/
                     /*~A:1186*/
                     /*~+:GVR - GetVeRsion*/
                     /*~I:1187*/
                     if (!strcmp(szCommand,"GVR"))
                     /*~-1*/
                     {
                        /*~T*/
                        // Text wurde bereits gesendet
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~A:1188*/
                        /*~+:Kanal 0*/
                        /*~I:1189*/
#ifdef CHANNEL_0
                        /*~I:1190*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0); 
                           /*~C:1191*/
                           switch (Parameter[0].nLong)
                           /*~-1*/
                           {
                              /*~F:1192*/
                              case 0:
                              /*~-1*/
                              {
                              /*~T*/
                              Version_PrintVersions(0);
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1192*/
                              /*~F:1193*/
                              case 1:
                              /*~-1*/
                              {
                              /*~T*/
                              Version_PrintVersions(1);
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1193*/
                              /*~O:C1191*/
                              /*~-2*/
                              default:
                              {
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
                              }
                           /*~-1*/
                           }
                           /*~E:C1191*/
                        /*~-1*/
                        }
                        /*~O:I1190*/
                        /*~-2*/
                        else
                        {
                           /*~A:1194*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1194*/
                        /*~-1*/
                        }
                        /*~E:I1190*/
                        /*~-1*/
#endif
                        /*~E:I1189*/
                        /*~E:A1188*/
                     /*~-1*/
                     }
                     /*~E:I1187*/
                     /*~E:A1186*/
                     /*~A:1195*/
                     /*~+:GWD - GetWatchDogadress*/
                     /*~I:1196*/
                     if (!strcmp(szCommand,"GWD"))
                     /*~-1*/
                     {
                        /*~T*/
                        // Text wurde bereits gesendet
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:1197*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0); 
                           /*~C:1198*/
                           switch (Parameter[0].nLong)
                           /*~-1*/
                           {
                              /*~F:1199*/
                              case 0:
                              /*~-1*/
                              {
                              /*~A:1200*/
                              /*~+:Kanal 0*/
                              /*~I:1201*/
#ifdef CHANNEL_0
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_WATCHDOG_ADDRESS_CHANNEL_0,ADuC836_WatchdogReadAddress(),1,0);
                              /*~-1*/
#endif
                              /*~E:I1201*/
                              /*~E:A1200*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1199*/
                              /*~F:1202*/
                              case 1:
                              /*~-1*/
                              {
                              /*~A:1203*/
                              /*~+:Kanal 1*/
                              /*~I:1204*/
#ifdef CHANNEL_1
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_WATCHDOG_ADDRESS_CHANNEL_1,ADuC836_WatchdogReadAddress(),1,0);
                              /*~-1*/
#endif
                              /*~E:I1204*/
                              /*~E:A1203*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1202*/
                              /*~O:C1198*/
                              /*~-2*/
                              default:
                              {
                              /*~A:1205*/
                              /*~+:Kanal 0*/
                              /*~I:1206*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I1206*/
                              /*~E:A1205*/
                              /*~-1*/
                              }
                           /*~-1*/
                           }
                           /*~E:C1198*/
                        /*~-1*/
                        }
                        /*~O:I1197*/
                        /*~-2*/
                        else
                        {
                           /*~A:1207*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1207*/
                        /*~-1*/
                        }
                        /*~E:I1197*/
                     /*~-1*/
                     }
                     /*~E:I1196*/
                     /*~E:A1195*/
                     /*~A:1208*/
                     /*~+:GZP - GetZeroPoint*/
                     /*~I:1209*/
                     if (!strcmp(szCommand,"GZP"))
                     /*~-1*/
                     {
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:1210*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0); 
                           /*~T*/
                           Measurement_GetZero(WEIGHT_WEIGHTCHANNEL,&MVTemp);
                           /*~C:1211*/
                           switch (Parameter[0].nLong)
                           /*~-1*/
                           {
                              /*~F:1212*/
                              case 0:
                              /*~-1*/
                              {
                              /*~A:1213*/
                              /*~+:Kanal 0*/
                              /*~I:1214*/
#ifdef CHANNEL_0
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_MEASUREMENT_ACTUAL_OFFSET_CHANNEL_0,MVTemp.nLong,1,0);
                              /*~-1*/
#endif
                              /*~E:I1214*/
                              /*~E:A1213*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1212*/
                              /*~F:1215*/
                              case 1:
                              /*~-1*/
                              {
                              /*~A:1216*/
                              /*~+:Kanal 1*/
                              /*~I:1217*/
#ifdef CHANNEL_1
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_MEASUREMENT_ACTUAL_OFFSET_CHANNEL_1,MVTemp.nLong,1,0);
                              /*~-1*/
#endif
                              /*~E:I1217*/
                              /*~E:A1216*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1215*/
                              /*~O:C1211*/
                              /*~-2*/
                              default:
                              {
                              /*~A:1218*/
                              /*~+:Kanal 0*/
                              /*~I:1219*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I1219*/
                              /*~E:A1218*/
                              /*~-1*/
                              }
                           /*~-1*/
                           }
                           /*~E:C1211*/
                        /*~-1*/
                        }
                        /*~O:I1210*/
                        /*~-2*/
                        else
                        {
                           /*~A:1220*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1220*/
                        /*~-1*/
                        }
                        /*~E:I1210*/
                     /*~-1*/
                     }
                     /*~E:I1209*/
                     /*~E:A1208*/
                     /*~T*/
                     break;
                  /*~-1*/
                  }
                  /*~E:F630*/
                  /*~E:A629*/
                  /*~A:1221*/
                  /*~+:I*/
                  /*~F:1222*/
                  case 'I':
                  /*~-1*/
                  {
                     /*~A:1223*/
                     /*~+:INI - INItialize*/
                     /*~I:1224*/
                     if (!strcmp(szCommand,"INI"))
                     /*~-1*/
                     {
                        /*~K*/
                        /*~+:/~**/
                        /*~+:1. 	Alamstatus l�schen*/
                        /*~+:2. 	1.Parameter = 0: Temperaturkompensation ausschalten*/
                        /*~+:	1.Parameter = 1: Temperaturkompensation einschalten*/
                        /*~+:3.	Statistikspeicher l�schen*/
                        /*~+:4.	2.Parameter = 0: kein Reset*/
                        /*~+:	2.Parameter = 1: Reset*/
                        /*~+:*~/*/
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:1225*/
                        if (!InstructionDecoder_CheckNbParameters(2,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0);
                           Parameter[1].nLong = Communication_GetLongParameter(1); 
                           /*~F:1226*/
                           // neu ab Version V1.006
                           /*~-1*/
                           {
                              /*~T*/
                              // Z�hler zur �berpr�fung der SPI-Kommunikation l�schen
                              Communication_ClearSPIFaultCounter(1);
                           /*~-1*/
                           }
                           /*~E:F1226*/
                           /*~T*/
                           Diagnosis_ClearDiagnosis(DIAGNOSIS_CLEAR_ALL_BY_INITITALISATION);
                           /*~A:1227*/
                           /*~+:1.Parameter:	0: Temperaturkompensation ausschalten*/
                           /*~+:				1: Temperaturkompensation einschalten*/
                           /*~C:1228*/
                           switch (Parameter[0].nLong)
                           /*~-1*/
                           {
                              /*~F:1229*/
                              case 0:		// Temperaturkompensation ausschalten
                              /*~-1*/
                              {
                              /*~T*/
                              MRW_Compensation_SetCompensationOn(0);
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1229*/
                              /*~F:1230*/
                              case 1:		// Temperaturkompensation einschalten
                              /*~-1*/
                              {
                              /*~T*/
                              MRW_Compensation_SetCompensationOn(1);
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1230*/
                              /*~O:C1228*/
                              /*~-2*/
                              default:
                              {
                              /*~A:1231*/
                              /*~+:Ausf�hrungsstatus auf 'E002' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E002;
                              /*~E:A1231*/
                              /*~-1*/
                              }
                           /*~-1*/
                           }
                           /*~E:C1228*/
                           /*~E:A1227*/
                           /*~I:1232*/
                           if (byCommandStatus == INSTRUCTIONDECODER_SEND_NOTHING)
                           /*~-1*/
                           {
                              /*~T*/
                              // Statistikspeicher l�schen - Implementierung sp�ter
                              /*~A:1233*/
                              /*~+:2.Parameter:	0: kein Reset*/
                              /*~+:				1: Reset*/
                              /*~C:1234*/
                              switch (Parameter[1].nLong)
                              /*~-1*/
                              {
                              /*~F:1235*/
                              case 0:		// kein Reset
                              /*~-1*/
                              {
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1235*/
                              /*~F:1236*/
                              case 1:		// Reset
                              /*~-1*/
                              {
                              /*~A:1237*/
                              /*~+:Eintrag im Diagnosespeicher*/
                              /*~T*/
                              Diagnosis_WriteMessage2Flash(DIAGNOSIS_MESSAGE_RESET_BY_INI_COMMAND);
                              /*~E:A1237*/
                              /*~T*/
                              System_SystemErrorSetWatchdog();
                              /*~-1*/
                              }
                              /*~E:F1236*/
                              /*~O:C1234*/
                              /*~-2*/
                              default:
                              {
                              /*~A:1238*/
                              /*~+:Ausf�hrungsstatus auf 'E002' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E002;
                              /*~E:A1238*/
                              /*~-1*/
                              }
                              /*~-1*/
                              }
                              /*~E:C1234*/
                              /*~E:A1233*/
                              /*~I:1239*/
                              if (byCommandStatus == INSTRUCTIONDECODER_SEND_NOTHING)
                              /*~-1*/
                              {
                              /*~I:1240*/
                              if (!GET_RESPONSE)
                              /*~-1*/
                              {
                              /*~A:1241*/
                              /*~+:Ausf�hrungsstatus auf 'OKAY' setzen*/
                              /*~+:*/
                              /*~T*/
                              // Ausf�hrungsstatus auf 'OKAY' setzen
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              /*~E:A1241*/
                              /*~A:1242*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~I:1243*/
#ifdef CHANNEL_0
                              /*~T*/
                              lText2Send = TEXT_INITIALIZATION;
                              /*~-1*/
#endif
                              /*~E:I1243*/
                              /*~E:A1242*/
                              /*~-1*/
                              }
                              /*~O:I1240*/
                              /*~-2*/
                              else
                              {
                              /*~K*/
                              /*~+:Fehler !!!*/
                              /*~A:1244*/
                              /*~+:Ausf�hrungsstatus auf 'E005' setzen*/
                              /*~I:1245*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~-1*/
#endif
                              /*~E:I1245*/
                              /*~E:A1244*/
                              /*~-1*/
                              }
                              /*~E:I1240*/
                              /*~-1*/
                              }
                              /*~O:I1239*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              // Fehler bei der Ausf�hrung eines Resets
                              /*~-1*/
                              }
                              /*~E:I1239*/
                           /*~-1*/
                           }
                           /*~O:I1232*/
                           /*~-2*/
                           else
                           {
                              /*~T*/
                              // Fehler beim einschalten der Temperaturkompensation
                           /*~-1*/
                           }
                           /*~E:I1232*/
                        /*~-1*/
                        }
                        /*~O:I1225*/
                        /*~-2*/
                        else
                        {
                           /*~A:1246*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1246*/
                        /*~-1*/
                        }
                        /*~E:I1225*/
                     /*~-1*/
                     }
                     /*~E:I1224*/
                     /*~E:A1223*/
                     /*~T*/
                     break;
                  /*~-1*/
                  }
                  /*~E:F1222*/
                  /*~E:A1221*/
                  /*~A:1247*/
                  /*~+:L*/
                  /*~F:1248*/
                  case 'L':
                  /*~-1*/
                  {
                     /*~A:1249*/
                     /*~+:LED - LED-testmode*/
                     /*~I:1250*/
                     if (!strcmp(szCommand,"LED"))
                     /*~-1*/
                     {
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:1251*/
#ifdef CHANNEL_0
                        /*~I:1252*/
                        if (!InstructionDecoder_CheckNbParameters(2,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~I:1253*/
                           if (!Communication_GetLongParameter(0))
                           /*~-1*/
                           {
                              /*~T*/
                              // Test-Mode f�r LEDs verlassen
                              Digital_ClearLEDTestMode();
                              /*~A:1254*/
                              /*~+:Textausgabe*/
                              /*~T*/
                              // Textausgabe
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              lText2Send = TEXT_LED_TESTMODE_CLEARED;
                              /*~E:A1254*/
                           /*~-1*/
                           }
                           /*~O:I1253*/
                           /*~-2*/
                           else
                           {
                              /*~T*/
                              Parameter[1].nLong = Communication_GetLongParameter(1);

                              // zun�chst alle LEDs l�schen
                              Digital_SetLEDManually(0xFF,FALSE);
                              // gew�nschte LEDs einschalten
                              Digital_SetLEDManually(Parameter[1].nLong,TRUE); 
                              /*~A:1255*/
                              /*~+:Textausgabe*/
                              /*~T*/
                              // Textausgabe
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              lText2Send = TEXT_LED_TESTMODE_SET;
                              /*~E:A1255*/
                           /*~-1*/
                           }
                           /*~E:I1253*/
                        /*~-1*/
                        }
                        /*~E:I1252*/
                        /*~-1*/
#endif
                        /*~E:I1251*/
                     /*~-1*/
                     }
                     /*~E:I1250*/
                     /*~T*/
                     break;
                     /*~E:A1249*/
                  /*~-1*/
                  }
                  /*~E:F1248*/
                  /*~E:A1247*/
                  /*~A:1256*/
                  /*~+:N*/
                  /*~F:1257*/
                  case 'N':
                  /*~-1*/
                  {
                     /*~A:1258*/
                     /*~+:NOP - NoOperation*/
                     /*~I:1259*/
                     if (!strcmp(szCommand,"NOP"))
                     /*~-1*/
                     {
                        /*~A:1260*/
                        /*~+:Kanal 0*/
                        /*~I:1261*/
#ifdef CHANNEL_0
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                        lText2Send = 0;
                        /*~I:1262*/
                        if (!InstructionDecoder_CheckNbParameters(0,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~I:1263*/
                           if (!SYSTEM_MRW_MANAGER)
                           /*~-1*/
                           {
                              /*~T*/
                              Communication_SendString(COMMUNICATION_RS232,"OK",0,0);
                           /*~-1*/
                           }
                           /*~E:I1263*/
                        /*~-1*/
                        }
                        /*~O:I1262*/
                        /*~-2*/
                        else
                        {
                           /*~A:1264*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1264*/
                        /*~-1*/
                        }
                        /*~E:I1262*/
                        /*~-1*/
#endif
                        /*~E:I1261*/
                        /*~E:A1260*/
                        /*~A:1265*/
                        /*~+:Kanal 1*/
                        /*~I:1266*/
#ifdef CHANNEL_1
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~-1*/
#endif
                        /*~E:I1266*/
                        /*~E:A1265*/
                     /*~-1*/
                     }
                     /*~E:I1259*/
                     /*~E:A1258*/
                     /*~T*/
                     break;
                  /*~-1*/
                  }
                  /*~E:F1257*/
                  /*~E:A1256*/
                  /*~A:1267*/
                  /*~+:R*/
                  /*~F:1268*/
                  case 'R':
                  /*~-1*/
                  {
                     /*~A:1269*/
                     /*~+:RCW - ReadChanelWeight*/
                     /*~I:1270*/
                     if ((!strcmp(szCommand,"RCW"))||(!strcmp(szCommand,"RDW")))
                     /*~-1*/
                     {
                        /*~I:1271*/
                        if (g_chRCWLast)
                        /*~-1*/
                        {
                           /*~T*/
                           g_chRCWLast = 0;
                        /*~-1*/
                        }
                        /*~O:I1271*/
                        /*~-2*/
                        else
                        {
                           /*~T*/
                           g_chRCWLast = 1;
                        /*~-1*/
                        }
                        /*~E:I1271*/
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:1272*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0); 
                           /*~C:1273*/
                           switch (Parameter[0].nLong)
                           /*~-1*/
                           {
                              /*~F:1274*/
                              case 0:
                              /*~-1*/
                              {
                              /*~A:1275*/
                              /*~+:Kanal 0*/
                              /*~I:1276*/
#ifdef CHANNEL_0
                              /*~T*/
                              Communication_SendFloat(COMMUNICATION_RS232,TEXT_MEASUREMENT_ACTUAL_WEIGHT_CHANNEL_0,Weight_NetWeight.fFloat,2,1,0);
                              /*~-1*/
#endif
                              /*~E:I1276*/
                              /*~E:A1275*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1274*/
                              /*~F:1277*/
                              case 1:
                              /*~-1*/
                              {
                              /*~A:1278*/
                              /*~+:Kanal 1*/
                              /*~I:1279*/
#ifdef CHANNEL_1
                              /*~T*/
                              Communication_SendFloat(COMMUNICATION_RS232,TEXT_MEASUREMENT_ACTUAL_WEIGHT_CHANNEL_1,Weight_NetWeight.fFloat,2,1,0);
                              /*~-1*/
#endif
                              /*~E:I1279*/
                              /*~E:A1278*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1277*/
                              /*~O:C1273*/
                              /*~-2*/
                              default:
                              {
                              /*~A:1280*/
                              /*~+:Kanal 0*/
                              /*~I:1281*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I1281*/
                              /*~E:A1280*/
                              /*~-1*/
                              }
                           /*~-1*/
                           }
                           /*~E:C1273*/
                        /*~-1*/
                        }
                        /*~O:I1272*/
                        /*~-2*/
                        else
                        {
                           /*~A:1282*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1282*/
                        /*~-1*/
                        }
                        /*~E:I1272*/
                     /*~-1*/
                     }
                     /*~E:I1270*/
                     /*~E:A1269*/
                     /*~I:1283*/
#ifdef MOF
                     /*~A:1284*/
                     /*~+:RCW - ReadChanelWeight*/
                     /*~I:1285*/
                     if (!strcmp(szCommand,"RCW"))
                     /*~-1*/
                     {
                        /*~I:1286*/
                        if (g_chRCWLast)
                        /*~-1*/
                        {
                           /*~T*/
                           g_chRCWLast = 0;
                        /*~-1*/
                        }
                        /*~O:I1286*/
                        /*~-2*/
                        else
                        {
                           /*~T*/
                           g_chRCWLast = 1;
                        /*~-1*/
                        }
                        /*~E:I1286*/
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:1287*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0); 
                           /*~C:1288*/
                           switch (Parameter[0].nLong)
                           /*~-1*/
                           {
                              /*~F:1289*/
                              case 0:
                              /*~-1*/
                              {
                              /*~A:1290*/
                              /*~+:Kanal 0*/
                              /*~I:1291*/
#ifdef CHANNEL_0
                              /*~T*/
                              Communication_SendFloat(COMMUNICATION_RS232,TEXT_MEASUREMENT_ACTUAL_WEIGHT_CHANNEL_0,Weight_NetWeight.fFloat,2,1,0);
                              /*~-1*/
#endif
                              /*~E:I1291*/
                              /*~E:A1290*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1289*/
                              /*~F:1292*/
                              case 1:
                              /*~-1*/
                              {
                              /*~A:1293*/
                              /*~+:Kanal 1*/
                              /*~I:1294*/
#ifdef CHANNEL_1
                              /*~T*/
                              Communication_SendFloat(COMMUNICATION_RS232,TEXT_MEASUREMENT_ACTUAL_WEIGHT_CHANNEL_1,Weight_NetWeight.fFloat,2,1,0);
                              /*~-1*/
#endif
                              /*~E:I1294*/
                              /*~E:A1293*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1292*/
                              /*~O:C1288*/
                              /*~-2*/
                              default:
                              {
                              /*~A:1295*/
                              /*~+:Kanal 0*/
                              /*~I:1296*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I1296*/
                              /*~E:A1295*/
                              /*~-1*/
                              }
                           /*~-1*/
                           }
                           /*~E:C1288*/
                        /*~-1*/
                        }
                        /*~O:I1287*/
                        /*~-2*/
                        else
                        {
                           /*~A:1297*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1297*/
                        /*~-1*/
                        }
                        /*~E:I1287*/
                     /*~-1*/
                     }
                     /*~E:I1285*/
                     /*~E:A1284*/
                     /*~-1*/
#endif
                     /*~E:I1283*/
                     /*~A:1298*/
                     /*~+:RDM - ReaDMeasurement*/
                     /*~I:1299*/
                     if (!strcmp(szCommand,"RDM"))
                     /*~-1*/
                     {
                        /*~T*/
                        g_chRCWLast = 0;
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:1300*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0); 
                           /*~C:1301*/
                           switch (Parameter[0].nLong)
                           /*~-1*/
                           {
                              /*~F:1302*/
                              case 0:
                              /*~-1*/
                              {
                              /*~A:1303*/
                              /*~+:Kanal 0*/
                              /*~I:1304*/
#ifdef CHANNEL_0
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_ACTUAL_MEASUREMENT_CHANNEL_0,Weight_ZeroCorrectedMeasurement.nLong,1,0);

                              /*~-1*/
#endif
                              /*~E:I1304*/
                              /*~E:A1303*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1302*/
                              /*~F:1305*/
                              case 1:
                              /*~-1*/
                              {
                              /*~A:1306*/
                              /*~+:Kanal 1*/
                              /*~I:1307*/
#ifdef CHANNEL_1
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_ACTUAL_MEASUREMENT_CHANNEL_1,Weight_ZeroCorrectedMeasurement.nLong,1,0);
                              /*~-1*/
#endif
                              /*~E:I1307*/
                              /*~E:A1306*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1305*/
                              /*~O:C1301*/
                              /*~-2*/
                              default:
                              {
                              /*~A:1308*/
                              /*~+:Kanal 0*/
                              /*~I:1309*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I1309*/
                              /*~E:A1308*/
                              /*~-1*/
                              }
                           /*~-1*/
                           }
                           /*~E:C1301*/
                        /*~-1*/
                        }
                        /*~O:I1300*/
                        /*~-2*/
                        else
                        {
                           /*~A:1310*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1310*/
                        /*~-1*/
                        }
                        /*~E:I1300*/
                     /*~-1*/
                     }
                     /*~E:I1299*/
                     /*~E:A1298*/
                     /*~A:1311*/
                     /*~+:RDS - ReaDStatus (nur aus Kompatibilit�tsgr�nden zur MRW-Manager-Software)*/
                     /*~I:1312*/
                     if (!strcmp(szCommand,"RDS"))
                     /*~-1*/
                     {
                        /*~A:1313*/
                        /*~+:Variablendeklarationen*/
                        /*~T*/
                        unsigned char byStatus2Set;
                        /*~E:A1313*/
                        /*~A:1314*/
                        /*~+:Variableninitialisierungen*/
                        /*~T*/
                        byStatus2Set = 0;
                        /*~E:A1314*/
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:1315*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~I:1316*/
                           if (SYSTEM_MRW_MANAGER)
                           /*~-1*/
                           {
                              /*~T*/
                              Parameter[0].nLong = Communication_GetLongParameter(0); 
                              /*~C:1317*/
                              switch (Parameter[0].nLong)
                              /*~-1*/
                              {
                              /*~F:1318*/
                              case 0:
                              /*~-1*/
                              {
                              /*~A:1319*/
                              /*~+:Kanal 0*/
                              /*~I:1320*/
#ifdef CHANNEL_0
                              /*~I:1321*/
#ifdef MIT_TARATEACH_VIA_RS232
                              /*~T*/
                              byStatus2Set |= 0x01;
                              /*~-1*/
#endif
                              /*~E:I1321*/
                              /*~I:1322*/
#ifdef MIT_LIMITTEACH_VIA_RS232
                              /*~T*/
                              byStatus2Set |= 0x02;
                              /*~-1*/
#endif
                              /*~E:I1322*/
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,0,byStatus2Set,0,0);

                              /*~-1*/
#endif
                              /*~E:I1320*/
                              /*~E:A1319*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1318*/
                              /*~F:1323*/
                              case 1:
                              /*~-1*/
                              {
                              /*~A:1324*/
                              /*~+:Kanal 1*/
                              /*~I:1325*/
#ifdef CHANNEL_1
                              /*~I:1326*/
#ifdef MIT_TARATEACH_VIA_RS232
                              /*~T*/
                              byStatus2Set |= 0x01;
                              /*~-1*/
#endif
                              /*~E:I1326*/
                              /*~I:1327*/
#ifdef MIT_LIMITTEACH_VIA_RS232
                              /*~T*/
                              byStatus2Set |= 0x02;
                              /*~-1*/
#endif
                              /*~E:I1327*/
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,0,byStatus2Set,0,0);

                              /*~-1*/
#endif
                              /*~E:I1325*/
                              /*~E:A1324*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1323*/
                              /*~O:C1317*/
                              /*~-2*/
                              default:
                              {
                              /*~A:1328*/
                              /*~+:Kanal 0*/
                              /*~I:1329*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I1329*/
                              /*~E:A1328*/
                              /*~-1*/
                              }
                              /*~-1*/
                              }
                              /*~E:C1317*/
                           /*~-1*/
                           }
                           /*~E:I1316*/
                        /*~-1*/
                        }
                        /*~O:I1315*/
                        /*~-2*/
                        else
                        {
                           /*~A:1330*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1330*/
                        /*~-1*/
                        }
                        /*~E:I1315*/
                     /*~-1*/
                     }
                     /*~E:I1312*/
                     /*~E:A1311*/
                     /*~A:1331*/
                     /*~+:RDW - ReaDWeight*/
                     /*~K*/
                     /*~+:RDW -> RCW*/
                     /*~E:A1331*/
                     /*~A:1332*/
                     /*~+:RDI - ReadDacInput*/
                     /*~I:1333*/
                     if (!strcmp(szCommand,"RDI"))
                     /*~-1*/
                     {
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:1334*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0); 
                           /*~C:1335*/
                           switch (Parameter[0].nLong)
                           /*~-1*/
                           {
                              /*~F:1336*/
                              case 0:
                              /*~-1*/
                              {
                              /*~A:1337*/
                              /*~+:Kanal 0*/
                              /*~I:1338*/
#ifdef CHANNEL_0
                              /*~T*/
                              // Communication_SendLong(COMMUNICATION_RS232,TEXT_CURRENT_INTERFACE_ACTUAL_DAC_INPUT_CHANNEL_0,Weight_ZeroCorrectedMeasurementWithTare.nLong  + g_lWeightOffset4Limitest,1,0);

                              Communication_SendLong(COMMUNICATION_RS232,TEXT_CURRENT_INTERFACE_ACTUAL_DAC_INPUT_CHANNEL_0,ADuC836_DACGetValue2Convert(),1,0);
                              /*~-1*/
#endif
                              /*~E:I1338*/
                              /*~E:A1337*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1336*/
                              /*~F:1339*/
                              case 1:
                              /*~-1*/
                              {
                              /*~A:1340*/
                              /*~+:Kanal 1*/
                              /*~I:1341*/
#ifdef CHANNEL_1
                              /*~T*/
                              // Communication_SendLong(COMMUNICATION_RS232,TEXT_CURRENT_INTERFACE_ACTUAL_DAC_INPUT_CHANNEL_1,Weight_ZeroCorrectedMeasurementWithTare.nLong + g_lWeightOffset4Limitest,1,0);

                              Communication_SendLong(COMMUNICATION_RS232,TEXT_CURRENT_INTERFACE_ACTUAL_DAC_INPUT_CHANNEL_1,ADuC836_DACGetValue2Convert(),1,0);
                              /*~-1*/
#endif
                              /*~E:I1341*/
                              /*~E:A1340*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1339*/
                              /*~O:C1335*/
                              /*~-2*/
                              default:
                              {
                              /*~A:1342*/
                              /*~+:Kanal 0*/
                              /*~I:1343*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I1343*/
                              /*~E:A1342*/
                              /*~-1*/
                              }
                           /*~-1*/
                           }
                           /*~E:C1335*/
                        /*~-1*/
                        }
                        /*~O:I1334*/
                        /*~-2*/
                        else
                        {
                           /*~A:1344*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1344*/
                        /*~-1*/
                        }
                        /*~E:I1334*/
                     /*~-1*/
                     }
                     /*~E:I1333*/
                     /*~E:A1332*/
                     /*~A:1345*/
                     /*~+:RMA - ReadMeasurementfromAdc*/
                     /*~I:1346*/
                     if (!strcmp(szCommand,"RMA"))
                     /*~-1*/
                     {
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:1347*/
                        if (!InstructionDecoder_CheckNbParameters(2,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0);
                           Parameter[1].nLong = Communication_GetLongParameter(1); 
                           /*~C:1348*/
                           switch (Parameter[0].nLong)
                           /*~-1*/
                           {
                              /*~F:1349*/
                              case 0:
                              /*~-1*/
                              {
                              /*~A:1350*/
                              /*~+:Kanal 0*/
                              /*~I:1351*/
#ifdef CHANNEL_0
                              /*~C:1352*/
                              switch (Parameter[1].nLong)
                              /*~-1*/
                              {
                              /*~F:1353*/
                              case 0:
                              case 2:
                              /*~-1*/
                              {
                              /*~I:1354*/
                              if (Parameter[1].nLong == 2)
                              /*~-1*/
                              {
                              /*~T*/
                              // aktuellen Rohmesswert vom ADC speichern
                              Save_Parameter(LOAD_SAVE_WEIGHT_MEASUREMENT_FROM_ADC,&Weight_MeasurementFromADC.nLong,4);
                              /*~-1*/
                              }
                              /*~E:I1354*/
                              /*~T*/
                              // und ausgeben
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_ADC_ACTUAL_MEASUREMENT_CHANNEL_0,Weight_MeasurementFromADC.nLong,0,1);

                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1353*/
                              /*~F:1355*/
                              case 1:
                              /*~-1*/
                              {
                              /*~T*/
                              // gespeicherten Rohmesswert vom ADC auslesen
                              /*~T*/
                              Load_Parameter(LOAD_SAVE_WEIGHT_MEASUREMENT_FROM_ADC,&Weight_MeasurementFromADC.nLong,4);
                              /*~T*/
                              // und ausgeben
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_ADC_STORED_MEASUREMENT_CHANNEL_0,Weight_MeasurementFromADC.nLong,0,1);

                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1355*/
                              /*~F:1356*/
                              case 3:
                              /*~-1*/
                              {
                              /*~T*/
                              // und ausgeben
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_ADC_ACTUAL_FB_MEASUREMENT_CHANNEL_0,g_CurrentInterface.FeedBack.Results.FilteredMeasurementFromADC.nLong,0,1);

                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1356*/
                              /*~O:C1352*/
                              /*~-2*/
                              default:
                              {
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E002;
                              /*~-1*/
                              }
                              /*~-1*/
                              }
                              /*~E:C1352*/
                              /*~-1*/
#endif
                              /*~E:I1351*/
                              /*~E:A1350*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1349*/
                              /*~F:1357*/
                              case 1:
                              /*~-1*/
                              {
                              /*~A:1358*/
                              /*~+:Kanal 1*/
                              /*~I:1359*/
#ifdef CHANNEL_1
                              /*~C:1360*/
                              switch (Parameter[1].nLong)
                              /*~-1*/
                              {
                              /*~F:1361*/
                              case 0:
                              case 2:
                              /*~-1*/
                              {
                              /*~I:1362*/
                              if (Parameter[1].nLong == 2)
                              /*~-1*/
                              {
                              /*~T*/
                              // aktuellen Rohmesswert vom ADC speichern
                              Save_Parameter(LOAD_SAVE_WEIGHT_MEASUREMENT_FROM_ADC,&Weight_MeasurementFromADC.nLong,4);
                              /*~-1*/
                              }
                              /*~E:I1362*/
                              /*~T*/
                              // und ausgeben
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_ADC_ACTUAL_MEASUREMENT_CHANNEL_1,Weight_MeasurementFromADC.nLong,0,1);

                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1361*/
                              /*~F:1363*/
                              case 1:
                              /*~-1*/
                              {
                              /*~T*/
                              // gespeicherten Rohmesswert vom ADC auslesen
                              /*~T*/
                              Load_Parameter(LOAD_SAVE_WEIGHT_MEASUREMENT_FROM_ADC,&Weight_MeasurementFromADC.nLong,4);
                              /*~T*/
                              // und ausgeben
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_ADC_STORED_MEASUREMENT_CHANNEL_1,Weight_MeasurementFromADC.nLong,0,1);

                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1363*/
                              /*~F:1364*/
                              case 3:
                              /*~-1*/
                              {
                              /*~T*/
                              // und ausgeben
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_ADC_ACTUAL_FB_MEASUREMENT_CHANNEL_1,g_CurrentInterface.FeedBack.Results.FilteredMeasurementFromADC.nLong,0,1);

                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1364*/
                              /*~O:C1360*/
                              /*~-2*/
                              default:
                              {
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E002;
                              /*~-1*/
                              }
                              /*~-1*/
                              }
                              /*~E:C1360*/
                              /*~-1*/
#endif
                              /*~E:I1359*/
                              /*~E:A1358*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1357*/
                              /*~O:C1348*/
                              /*~-2*/
                              default:
                              {
                              /*~A:1365*/
                              /*~+:Kanal 0*/
                              /*~I:1366*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I1366*/
                              /*~E:A1365*/
                              /*~-1*/
                              }
                           /*~-1*/
                           }
                           /*~E:C1348*/
                        /*~-1*/
                        }
                        /*~O:I1347*/
                        /*~-2*/
                        else
                        {
                           /*~A:1367*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1367*/
                        /*~-1*/
                        }
                        /*~E:I1347*/
                     /*~-1*/
                     }
                     /*~E:I1346*/
                     /*~E:A1345*/
                     /*~I:1368*/
#ifdef MOF
                     /*~A:1369*/
                     /*~+:RMF - ReadMotionFilter*/
                     /*~I:1370*/
                     if (!strcmp(szCommand,"RMF"))
                     /*~-1*/
                     {
                        /*~A:1371*/
                        /*~+:Variablendeklarationen*/
                        /*~T*/
                        MEASUREMENT_MOTIONPARAMETER MotionParameter;

                        /*~I:1372*/
#ifdef CHANNEL_0
                        /*~T*/
                        long lMotionFilterPartner;
                        /*~-1*/
#endif
                        /*~E:I1372*/
                        /*~E:A1371*/
                        /*~A:1373*/
                        /*~+:Variableninitialisierungen*/
                        /*~T*/

                        /*~E:A1373*/
                        /*~T*/
                        // Text wurde bereits gesendet
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:1374*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           // Parameter auslesen
                           Parameter[0].nLong = Communication_GetLongParameter(0);

                           // Motionparameter auslesen
                           Weight_GetMotionParameter(&MotionParameter);
                           /*~I:1375*/
                           if (Parameter[0].nLong <= 1)
                           /*~-1*/
                           {
                              /*~I:1376*/
#ifdef CHANNEL_0
                              /*~I:1377*/
                              if (!Communication_GetSPIValue(COMMUNICATION_MOTION_FILTER,&lMotionFilterPartner))
                              /*~-1*/
                              {
                              /*~C:1378*/
                              switch (Parameter[0].nLong)
                              /*~-1*/
                              {
                              /*~F:1379*/
                              case 0: // Filter f�r Gewichtsbewegung
                              /*~-1*/
                              {
                              /*~I:1380*/
                              if (lMotionFilterPartner == MotionParameter.byMotionFilter)
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_MEASUREMENT_MOTIONFILTER_CHANNEL_0,MotionParameter.byMotionFilter,1,0);
                              /*~-1*/
                              }
                              /*~O:I1380*/
                              /*~-2*/
                              else
                              {
                              /*~A:1381*/
                              /*~+:Fehler - Werte beider Kan�le sind nicht identisch - E011*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E011;
                              /*~E:A1381*/
                              /*~-1*/
                              }
                              /*~E:I1380*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1379*/
                              /*~F:1382*/
                              case 1: // Filter f�r Gewichtsberuhigung
                              /*~-1*/
                              {
                              /*~I:1383*/
                              if (lMotionFilterPartner == MotionParameter.byNoMotionFilter)
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_MEASUREMENT_NOMOTIONFILTER_CHANNEL_0,MotionParameter.byNoMotionFilter,1,0);
                              /*~-1*/
                              }
                              /*~O:I1383*/
                              /*~-2*/
                              else
                              {
                              /*~A:1384*/
                              /*~+:Fehler - Werte beider Kan�le sind nicht identisch - E011*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E011;
                              /*~E:A1384*/
                              /*~-1*/
                              }
                              /*~E:I1383*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1382*/
                              /*~-1*/
                              }
                              /*~E:C1378*/
                              /*~-1*/
                              }
                              /*~O:I1377*/
                              /*~-2*/
                              else
                              {
                              /*~A:1385*/
                              /*~+:Fehler bei der Kommunikation - E005*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A1385*/
                              /*~-1*/
                              }
                              /*~E:I1377*/
                              /*~O:I1376*/
                              /*~-1*/
#else
                              /*~I:1386*/
#ifdef CHANNEL_1
                              /*~C:1387*/
                              switch (Parameter[0].nLong)
                              /*~-1*/
                              {
                              /*~F:1388*/
                              case 0:
                              /*~-1*/
                              {
                              /*~T*/
                              InstructionDecoder_StoreValue(COMMUNICATION_MOTION_FILTER,(GLOBAL_UNIVALUE_SHORT*)&MotionParameter.byMotionFilter);
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1388*/
                              /*~F:1389*/
                              case 1:
                              /*~-1*/
                              {
                              /*~T*/
                              InstructionDecoder_StoreValue(COMMUNICATION_MOTION_FILTER,(GLOBAL_UNIVALUE_SHORT*)&MotionParameter.byNoMotionFilter);
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1389*/
                              /*~-1*/
                              }
                              /*~E:C1387*/
                              /*~-1*/
#endif
                              /*~E:I1386*/
                              /*~-1*/
#endif
                              /*~E:I1376*/
                           /*~-1*/
                           }
                           /*~O:I1375*/
                           /*~-2*/
                           else
                           {
                              /*~I:1390*/
#ifdef CHANNEL_0
                              /*~A:1391*/
                              /*~+:Parameter liegt au�erhalb der Grenzen - E002*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E002;
                              /*~E:A1391*/
                              /*~-1*/
#endif
                              /*~E:I1390*/
                           /*~-1*/
                           }
                           /*~E:I1375*/
                        /*~-1*/
                        }
                        /*~O:I1374*/
                        /*~-2*/
                        else
                        {
                           /*~A:1392*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1392*/
                        /*~-1*/
                        }
                        /*~E:I1374*/
                     /*~-1*/
                     }
                     /*~E:I1370*/
                     /*~E:A1369*/
                     /*~-1*/
#endif
                     /*~E:I1368*/
                     /*~A:1393*/
                     /*~+:RML - ReadMotionLimit*/
                     /*~I:1394*/
                     if (!strcmp(szCommand,"RML"))
                     /*~-1*/
                     {
                        /*~A:1395*/
                        /*~+:Variablendeklarationen*/
                        /*~T*/
                        MEASUREMENT_MOTIONPARAMETER MotionParameter;

                        /*~I:1396*/
#ifdef CHANNEL_0
                        /*~T*/
                        float fMotionLimitPartner;
                        /*~-1*/
#endif
                        /*~E:I1396*/
                        /*~E:A1395*/
                        /*~A:1397*/
                        /*~+:Variableninitialisierungen*/
                        /*~T*/

                        /*~E:A1397*/
                        /*~T*/
                        // Text wurde bereits gesendet
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:1398*/
                        if (!InstructionDecoder_CheckNbParameters(0,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           // Motionparameter auslesen
                           Weight_GetMotionParameter(&MotionParameter);
                           /*~I:1399*/
#ifdef CHANNEL_0
                           /*~I:1400*/
                           if (!Communication_GetSPIValue(COMMUNICATION_MOTION_LIMIT,&fMotionLimitPartner))
                           /*~-1*/
                           {
                              /*~I:1401*/
                              if (fMotionLimitPartner == MotionParameter.fMotionLimit)
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendFloat(COMMUNICATION_RS232,TEXT_MEASUREMENT_MOTIONLIMIT_CHANNEL_0,MotionParameter.fMotionLimit,2,1,0);
                              /*~-1*/
                              }
                              /*~O:I1401*/
                              /*~-2*/
                              else
                              {
                              /*~A:1402*/
                              /*~+:Fehler - Werte beider Kan�le sind nicht identisch - E011*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E011;
                              /*~E:A1402*/
                              /*~-1*/
                              }
                              /*~E:I1401*/
                           /*~-1*/
                           }
                           /*~O:I1400*/
                           /*~-2*/
                           else
                           {
                              /*~A:1403*/
                              /*~+:Fehler bei der Kommunikation - E005*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A1403*/
                           /*~-1*/
                           }
                           /*~E:I1400*/
                           /*~O:I1399*/
                           /*~-1*/
#else
                           /*~I:1404*/
#ifdef CHANNEL_1
                           /*~T*/
                           InstructionDecoder_StoreValue(COMMUNICATION_MOTION_LIMIT,(GLOBAL_UNIVALUE_SHORT*)&MotionParameter.fMotionLimit);
                           /*~-1*/
#endif
                           /*~E:I1404*/
                           /*~-1*/
#endif
                           /*~E:I1399*/
                        /*~-1*/
                        }
                        /*~O:I1398*/
                        /*~-2*/
                        else
                        {
                           /*~A:1405*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1405*/
                        /*~-1*/
                        }
                        /*~E:I1398*/
                     /*~-1*/
                     }
                     /*~E:I1394*/
                     /*~E:A1393*/
                     /*~A:1406*/
                     /*~+:RMT - ReadMotionTimer*/
                     /*~I:1407*/
                     if (!strcmp(szCommand,"RMT"))
                     /*~-1*/
                     {
                        /*~A:1408*/
                        /*~+:Variablendeklarationen*/
                        /*~T*/
                        MEASUREMENT_MOTIONPARAMETER MotionParameter;

                        /*~I:1409*/
#ifdef CHANNEL_0
                        /*~T*/
                        long lMotionFilterPartner;
                        /*~-1*/
#endif
                        /*~E:I1409*/
                        /*~E:A1408*/
                        /*~A:1410*/
                        /*~+:Variableninitialisierungen*/
                        /*~T*/

                        /*~E:A1410*/
                        /*~T*/
                        // Text wurde bereits gesendet
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:1411*/
                        if (!InstructionDecoder_CheckNbParameters(0,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           // Motionparameter auslesen
                           Weight_GetMotionParameter(&MotionParameter);
                           /*~I:1412*/
#ifdef CHANNEL_0
                           /*~I:1413*/
                           if (!Communication_GetSPIValue(COMMUNICATION_MOTION_FILTER,&lMotionFilterPartner))
                           /*~-1*/
                           {
                              /*~I:1414*/
                              if (lMotionFilterPartner == MotionParameter.byMotionFilter)
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_MEASUREMENT_MOTIONFILTER_CHANNEL_0,MotionParameter.byMotionFilter,1,0);
                              /*~-1*/
                              }
                              /*~O:I1414*/
                              /*~-2*/
                              else
                              {
                              /*~A:1415*/
                              /*~+:Fehler - Werte beider Kan�le sind nicht identisch - E011*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E011;
                              /*~E:A1415*/
                              /*~-1*/
                              }
                              /*~E:I1414*/
                           /*~-1*/
                           }
                           /*~O:I1413*/
                           /*~-2*/
                           else
                           {
                              /*~A:1416*/
                              /*~+:Fehler bei der Kommunikation - E005*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A1416*/
                           /*~-1*/
                           }
                           /*~E:I1413*/
                           /*~O:I1412*/
                           /*~-1*/
#else
                           /*~I:1417*/
#ifdef CHANNEL_1
                           /*~T*/
                           InstructionDecoder_StoreValue(COMMUNICATION_MOTION_FILTER,(GLOBAL_UNIVALUE_SHORT*)&MotionParameter.byMotionFilter);
                           /*~-1*/
#endif
                           /*~E:I1417*/
                           /*~-1*/
#endif
                           /*~E:I1412*/
                        /*~-1*/
                        }
                        /*~O:I1411*/
                        /*~-2*/
                        else
                        {
                           /*~A:1418*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1418*/
                        /*~-1*/
                        }
                        /*~E:I1411*/
                     /*~-1*/
                     }
                     /*~E:I1407*/
                     /*~E:A1406*/
                     /*~I:1419*/
#ifdef MOF
                     /*~A:1420*/
                     /*~+:RSS - ReaDrS232Statistics*/
                     /*~I:1421*/
                     if (!strcmp(szCommand,"RSS"))
                     /*~-1*/
                     {
                        /*~A:1422*/
                        /*~+:Variablendeklarationen*/
                        /*~T*/
                        RS232_STATISTICS_T Statistics;
                        unsigned char szString[32];
                        /*~E:A1422*/
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:1423*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0); 
                           /*~C:1424*/
                           switch (Parameter[0].nLong)
                           /*~-1*/
                           {
                              /*~F:1425*/
                              case 0:
                              /*~-1*/
                              {
                              /*~A:1426*/
                              /*~+:Kanal 0*/
                              /*~I:1427*/
#ifdef CHANNEL_0
                              /*~T*/
                              Statistics = ADuC836_RS232GetStatistics();
                              /*~I:1428*/
                              if (!SYSTEM_MRW_MANAGER)
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_RS232_STATISTICS_FRAMES_RECEIVED_CHANNEL_0,Statistics.ulETXCount,1,0);

                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_RS232_STATISTICS_ERRONEOUS_FRAMES_CHANNEL_0,Statistics.ulSTXCount - Statistics.ulETXCount,1,0);

                              /*~-1*/
                              }
                              /*~O:I1428*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              sprintf(szString,"%ld,%ld", Statistics.ulETXCount, Statistics.ulSTXCount - Statistics.ulETXCount);

                              Communication_SendString(COMMUNICATION_RS232,szString,0,0);
                              /*~-1*/
                              }
                              /*~E:I1428*/
                              /*~-1*/
#endif
                              /*~E:I1427*/
                              /*~E:A1426*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1425*/
                              /*~F:1429*/
                              case 1:
                              /*~-1*/
                              {
                              /*~A:1430*/
                              /*~+:Kanal 1*/
                              /*~I:1431*/
#ifdef CHANNEL_1
                              /*~T*/
                              Statistics = ADuC836_RS232GetStatistics();
                              /*~I:1432*/
                              if (!SYSTEM_MRW_MANAGER)
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_RS232_STATISTICS_FRAMES_RECEIVED_CHANNEL_1,Statistics.ulETXCount,1,0);

                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_RS232_STATISTICS_ERRONEOUS_FRAMES_CHANNEL_1,Statistics.ulSTXCount - Statistics.ulETXCount,1,0);

                              /*~-1*/
                              }
                              /*~O:I1432*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              sprintf(szString,"%ld,%ld", Statistics.ulETXCount, Statistics.ulSTXCount - Statistics.ulETXCount);

                              Communication_SendString(COMMUNICATION_RS232,szString,0,0);
                              /*~-1*/
                              }
                              /*~E:I1432*/
                              /*~-1*/
#endif
                              /*~E:I1431*/
                              /*~E:A1430*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1429*/
                              /*~O:C1424*/
                              /*~-2*/
                              default:
                              {
                              /*~A:1433*/
                              /*~+:Kanal 0*/
                              /*~I:1434*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I1434*/
                              /*~E:A1433*/
                              /*~-1*/
                              }
                           /*~-1*/
                           }
                           /*~E:C1424*/
                        /*~-1*/
                        }
                        /*~O:I1423*/
                        /*~-2*/
                        else
                        {
                           /*~A:1435*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1435*/
                        /*~-1*/
                        }
                        /*~E:I1423*/
                     /*~-1*/
                     }
                     /*~E:I1421*/
                     /*~E:A1420*/
                     /*~-1*/
#endif
                     /*~E:I1419*/
                     /*~A:1436*/
                     /*~+:RST - ReSeT*/
                     /*~I:1437*/
                     if (!strcmp(szCommand,"RST"))
                     /*~-1*/
                     {
                        /*~T*/
                        // Text wurde bereits gesendet
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:1438*/
                        if (!InstructionDecoder_CheckNbParameters(0,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           System_Reset();
                        /*~-1*/
                        }
                        /*~O:I1438*/
                        /*~-2*/
                        else
                        {
                           /*~A:1439*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1439*/
                        /*~-1*/
                        }
                        /*~E:I1438*/
                     /*~-1*/
                     }
                     /*~E:I1437*/
                     /*~E:A1436*/
                     /*~T*/
                     break;
                  /*~-1*/
                  }
                  /*~E:F1268*/
                  /*~E:A1267*/
                  /*~A:1440*/
                  /*~+:S*/
                  /*~F:1441*/
                  case 'S':
                  /*~-1*/
                  {
                     /*~A:1442*/
                     /*~+:SAL - SetAlarmLimit*/
                     /*~I:1443*/
                     if (!strcmp(szCommand,"SAL"))
                     /*~-1*/
                     {
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;

                        /*~I:1444*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           // Parameter auslesen
                           Parameter[0].fFloat = Communication_GetFloatParameter(0);
                           /*~I:1445*/
                           if (!GET_RESPONSE)
                           /*~-1*/
                           {
                              /*~T*/
                              // Alles okay
                              // Alarmgrenzwert setzen
                              /*~I:1446*/
                              if (!Limit_SetAlarmLimitByWeight(0,Parameter[0].fFloat))
                              /*~-1*/
                              {
                              /*~A:1447*/
                              /*~+:Ausf�hrungsstatus auf 'OKAY' setzen*/
                              /*~+:*/
                              /*~T*/
                              // Ausf�hrungsstatus auf 'OKAY' setzen
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              /*~E:A1447*/
                              /*~A:1448*/
                              /*~+:Kanal 0 - Textausgabe*/
                              /*~I:1449*/
#ifdef CHANNEL_0
                              /*~T*/
                              // Textausgabe vornehmen
                              lText2Send = TEXT_LIMIT_TEACHED;
                              /*~-1*/
#endif
                              /*~E:I1449*/
                              /*~E:A1448*/
                              /*~-1*/
                              }
                              /*~O:I1446*/
                              /*~-2*/
                              else
                              {
                              /*~K*/
                              /*~+:Fehler !!!*/
                              /*~A:1450*/
                              /*~+:Ausf�hrungsstatus auf 'E005' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A1450*/
                              /*~-1*/
                              }
                              /*~E:I1446*/
                           /*~-1*/
                           }
                           /*~O:I1445*/
                           /*~-2*/
                           else
                           {
                              /*~K*/
                              /*~+:Fehler !!!*/
                              /*~A:1451*/
                              /*~+:Ausf�hrungsstatus auf 'E005' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A1451*/
                           /*~-1*/
                           }
                           /*~E:I1445*/
                        /*~-1*/
                        }
                        /*~O:I1444*/
                        /*~-2*/
                        else
                        {
                           /*~A:1452*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1452*/
                        /*~-1*/
                        }
                        /*~E:I1444*/
                     /*~-1*/
                     }
                     /*~E:I1443*/
                     /*~E:A1442*/
                     /*~A:1453*/
                     /*~+:SAN - SetAritcleNumber*/
                     /*~I:1454*/
                     if (!strcmp(szCommand,"SAN"))
                     /*~-1*/
                     {
                        /*~A:1455*/
                        /*~+:Variablendeklarationen*/
                        /*~T*/
                        char *szItemNumber;
                        /*~E:A1455*/
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:1456*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           szItemNumber = Communication_GetStringParameter(0);

                           /*~I:1457*/
                           if (!System_SetItemNumber(szItemNumber))
                           /*~-1*/
                           {
                              /*~A:1458*/
                              /*~+:Kanal 0 - Textausgabe*/
                              /*~I:1459*/
#ifdef CHANNEL_0 
                              /*~A:1460*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              lText2Send = TEXT_ITEM_NUMBER_SET;
                              /*~E:A1460*/
                              /*~-1*/
#endif
                              /*~E:I1459*/
                              /*~E:A1458*/
                           /*~-1*/
                           }
                           /*~O:I1457*/
                           /*~-2*/
                           else
                           {
                              /*~K*/
                              /*~+:Fehler !!!*/
                              /*~I:1461*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~-1*/
#endif
                              /*~E:I1461*/
                           /*~-1*/
                           }
                           /*~E:I1457*/
                        /*~-1*/
                        }
                        /*~O:I1456*/
                        /*~-2*/
                        else
                        {
                           /*~A:1462*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1462*/
                        /*~-1*/
                        }
                        /*~E:I1456*/
                     /*~-1*/
                     }
                     /*~E:I1454*/
                     /*~E:A1453*/
                     /*~I:1463*/
                     /* ab Version V1.008 v. 11.08.2015 */
#ifdef MIT_ADC_BURNOUT_TEST
                     /*~A:1464*/
                     /*~+:SBO - SetBurnOut_onoff*/
                     /*~I:1465*/
                     if (!strcmp(szCommand,"SBO"))
                     /*~-1*/
                     {
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;

                        /*~I:1466*/
                        if (!InstructionDecoder_CheckNbParameters(2,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           // Parameter auslesen
                           Parameter[0].nLong = Communication_GetLongParameter(0);
                           Parameter[1].nLong = Communication_GetLongParameter(1);
                           /*~C:1467*/
                           switch (Parameter[0].nLong)
                           /*~-1*/
                           {
                              /*~F:1468*/
                              case 0:
                              /*~-1*/
                              {
                              /*~A:1469*/
                              /*~+:Kanal 0*/
                              /*~I:1470*/
#ifdef CHANNEL_0
                              /*~T*/
                              // Current burnout mode setzen
                              byRetVal = ADuC836_ADCSetBurnOutMode((unsigned char)Parameter[1].nLong);
                              /*~I:1471*/
                              if (byRetVal != (unsigned char)Parameter[1].nLong)
                              /*~-1*/
                              {
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~-1*/
                              }
                              /*~O:I1471*/
                              /*~-2*/
                              else
                              {
                              /*~A:1472*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              /*~I:1473*/
                              if (byRetVal)
                              /*~-1*/
                              {
                              /*~T*/
                              lText2Send = TEXT_ADC_BURNOUTMODE_SET_CHANEL_0;
                              /*~-1*/
                              }
                              /*~O:I1473*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              lText2Send = TEXT_ADC_BURNOUTMODE_CLEARED_CHANEL_0;
                              /*~-1*/
                              }
                              /*~E:I1473*/
                              /*~E:A1472*/
                              /*~-1*/
                              }
                              /*~E:I1471*/
                              /*~-1*/
#endif
                              /*~E:I1470*/
                              /*~E:A1469*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1468*/
                              /*~F:1474*/
                              case 1:
                              /*~-1*/
                              {
                              /*~A:1475*/
                              /*~+:Kanal 1*/
                              /*~I:1476*/
#ifdef CHANNEL_1
                              /*~T*/
                              // Current burnout mode setzen
                              byRetVal = ADuC836_ADCSetBurnOutMode((unsigned char)Parameter[1].nLong);
                              /*~I:1477*/
                              if (byRetVal != (unsigned char)Parameter[1].nLong)
                              /*~-1*/
                              {
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~-1*/
                              }
                              /*~O:I1477*/
                              /*~-2*/
                              else
                              {
                              /*~A:1478*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              /*~I:1479*/
                              if (byRetVal)
                              /*~-1*/
                              {
                              /*~T*/
                              lText2Send = TEXT_ADC_BURNOUTMODE_SET_CHANEL_1;
                              /*~-1*/
                              }
                              /*~O:I1479*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              lText2Send = TEXT_ADC_BURNOUTMODE_CLEARED_CHANEL_1;
                              /*~-1*/
                              }
                              /*~E:I1479*/
                              /*~E:A1478*/
                              /*~-1*/
                              }
                              /*~E:I1477*/
                              /*~-1*/
#endif
                              /*~E:I1476*/
                              /*~E:A1475*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1474*/
                              /*~O:C1467*/
                              /*~-2*/
                              default:
                              {
                              /*~A:1480*/
                              /*~+:Kanal 0*/
                              /*~I:1481*/
#ifdef CHANEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I1481*/
                              /*~E:A1480*/
                              /*~-1*/
                              }
                           /*~-1*/
                           }
                           /*~E:C1467*/
                        /*~-1*/
                        }
                        /*~O:I1466*/
                        /*~-2*/
                        else
                        {
                           /*~A:1482*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1482*/
                        /*~-1*/
                        }
                        /*~E:I1466*/
                     /*~-1*/
                     }
                     /*~E:I1465*/
                     /*~E:A1464*/
                     /*~-1*/
#endif
                     /*~E:I1463*/
                     /*~I:1483*/
#ifdef SYSTEM_CND_VARIABLE_BAUDRATE
                     /*~A:1484*/
                     /*~+:SBR - SetBaudRate*/
                     /*~I:1485*/
                     if (!strcmp(szCommand,"SBR"))
                     /*~-1*/
                     {
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;

                        /*~I:1486*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0);

                           /*~I:1487*/
                           if ((Parameter[0].nLong == 9600)||(Parameter[0].nLong == 19200)||(Parameter[0].nLong == 38400)||(Parameter[0].nLong == 57600))
                           /*~-1*/
                           {
                              /*~I:1488*/
                              if (!GET_RESPONSE)
                              /*~-1*/
                              {
                              /*~T*/
                              // Alles okay
                              /*~K*/
                              /*~+:*/
                              /*~T*/
                              ADuC836_RS232SetBaudrate(Parameter[0].nLong);
                              /*~T*/
                              // Alles okay
                              // und Wert abspeichern
                              Save_Parameter(LOAD_SAVE_RS232_BAUDRATE,&Parameter[0].nLong,0);
                              /*~A:1489*/
                              /*~+:Ausf�hrungsstatus auf 'OKAY' setzen*/
                              /*~+:*/
                              /*~T*/
                              // Ausf�hrungsstatus auf 'OKAY' setzen
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              /*~E:A1489*/
                              /*~A:1490*/
                              /*~+:Kanal 0 - Textausgabe*/
                              /*~I:1491*/
#ifdef CHANNEL_0 
                              /*~A:1492*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              lText2Send = TEXT_RS232_BAUDRATE_SET;
                              /*~E:A1492*/
                              /*~-1*/
#endif
                              /*~E:I1491*/
                              /*~E:A1490*/
                              /*~-1*/
                              }
                              /*~O:I1488*/
                              /*~-2*/
                              else
                              {
                              /*~K*/
                              /*~+:Fehler !!!*/
                              /*~A:1493*/
                              /*~+:Ausf�hrungsstatus auf 'E005' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A1493*/
                              /*~-1*/
                              }
                              /*~E:I1488*/
                           /*~-1*/
                           }
                           /*~O:I1487*/
                           /*~-2*/
                           else
                           {
                              /*~K*/
                              /*~+:Fehler !!!*/
                              /*~A:1494*/
                              /*~+:Ausf�hrungsstatus auf 'E002' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E002;
                              /*~E:A1494*/
                           /*~-1*/
                           }
                           /*~E:I1487*/
                        /*~-1*/
                        }
                        /*~O:I1486*/
                        /*~-2*/
                        else
                        {
                           /*~A:1495*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1495*/
                        /*~-1*/
                        }
                        /*~E:I1486*/
                     /*~-1*/
                     }
                     /*~E:I1485*/
                     /*~E:A1484*/
                     /*~-1*/
#endif
                     /*~E:I1483*/
                     /*~I:1496*/
#ifndef MIT_KANALTEILUNG
                     /*~A:1497*/
                     /*~+:SCA - SetCalibrationfactortoActualweight*/
                     /*~I:1498*/
                     if (!strcmp(szCommand,"SCA"))
                     /*~-1*/
                     {
                        /*~A:1499*/
                        /*~+:Variablendeklarationen*/
                        /*~T*/
                        unsigned long ulRetVal;
                        /*~E:A1499*/
                        /*~A:1500*/
                        /*~+:Variableninitialisierungen*/
                        /*~T*/

                        /*~E:A1500*/
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;

                        /*~I:1501*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           // Parameter auslesen
                           Parameter[0].fFloat = Communication_GetFloatParameter(0);

                           /*~T*/
                           ulRetVal = Weight_SetCalibrationRegardingActualWeight(Parameter[0].fFloat);
                           /*~I:1502*/
                           if (!GET_RESPONSE)
                           /*~-1*/
                           {
                              /*~I:1503*/
                              if (!ulRetVal)
                              /*~-1*/
                              {
                              /*~T*/
                              // Alles okay
                              /*~A:1504*/
                              /*~+:Ausf�hrungsstatus auf 'OKAY' setzen*/
                              /*~+:*/
                              /*~T*/
                              // Ausf�hrungsstatus auf 'OKAY' setzen
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              /*~E:A1504*/
                              /*~A:1505*/
                              /*~+:Eintrag in Diagnosespeicher vornehmen*/
                              /*~T*/
                              ulDiagnosisEntry2Set = DIAGNOSIS_MESSAGE_CALIBRATION;
                              /*~E:A1505*/
                              /*~A:1506*/
                              /*~+:Kanal 0 - Textausgabe*/
                              /*~I:1507*/
#ifdef CHANNEL_0
                              /*~T*/
                              lText2Send = TEXT_MEASUREMENT_CALIBRATION_SET;
                              /*~-1*/
#endif
                              /*~E:I1507*/
                              /*~E:A1506*/
                              /*~-1*/
                              }
                              /*~O:I1503*/
                              /*~-2*/
                              else
                              {
                              /*~K*/
                              /*~+:Fehler !!!*/
                              /*~A:1508*/
                              /*~+:Ausf�hrungsstatus auf 'E005' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A1508*/
                              /*~-1*/
                              }
                              /*~E:I1503*/
                           /*~-1*/
                           }
                           /*~O:I1502*/
                           /*~-2*/
                           else
                           {
                              /*~K*/
                              /*~+:Fehler !!!*/
                              /*~A:1509*/
                              /*~+:Ausf�hrungsstatus auf 'E005' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A1509*/
                           /*~-1*/
                           }
                           /*~E:I1502*/
                        /*~-1*/
                        }
                        /*~O:I1501*/
                        /*~-2*/
                        else
                        {
                           /*~A:1510*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1510*/
                        /*~-1*/
                        }
                        /*~E:I1501*/
                     /*~-1*/
                     }
                     /*~E:I1498*/
                     /*~E:A1497*/
                     /*~O:I1496*/
                     /*~-1*/
#else
                     /*~A:1511*/
                     /*~+:SCA - SetCalibrationfactortoActualweight*/
                     /*~I:1512*/
                     if (!strcmp(szCommand,"SCA"))
                     /*~-1*/
                     {
                        /*~A:1513*/
                        /*~+:Variablendeklarationen*/
                        /*~T*/
                        char byRetVal;
                        /*~E:A1513*/
                        /*~A:1514*/
                        /*~+:Variableninitialisierungen*/
                        /*~T*/

                        /*~E:A1514*/
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:1515*/
                        if (!InstructionDecoder_CheckNbParameters(2,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           // Parameter auslesen
                           Parameter[0].nLong = Communication_GetLongParameter(0);
                           Parameter[1].fFloat = Communication_GetFloatParameter(1);
                           /*~C:1516*/
                           switch (Parameter[0].nLong)
                           /*~-1*/
                           {
                              /*~F:1517*/
                              case 0:
                              /*~-1*/
                              {
                              /*~A:1518*/
                              /*~+:Kanal 0*/
                              /*~I:1519*/
#ifdef CHANNEL_0
                              /*~T*/
                              byRetVal = Weight_SetCalibrationRegardingActualWeight(Parameter[1].fFloat);
                              /*~I:1520*/
                              if (!byRetVal)
                              /*~-1*/
                              {
                              /*~A:1521*/
                              /*~+:Eintrag in Diagnosespeicher vornehmen*/
                              /*~T*/
                              ulDiagnosisEntry2Set = DIAGNOSIS_MESSAGE_CALIBRATION;
                              /*~E:A1521*/
                              /*~A:1522*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              lText2Send = TEXT_MEASUREMENT_GAIN_SET_CHANNEL_0;
                              /*~E:A1522*/
                              /*~-1*/
                              }
                              /*~O:I1520*/
                              /*~-2*/
                              else
                              {
                              /*~K*/
                              /*~+:Fehler*/
                              /*~A:1523*/
                              /*~+:Textausgabe "E005"*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~I:1524*/
                              if (byRetVal == 2)
                              /*~-1*/
                              {
                              /*~T*/
                              lText2Send = TEXT_ERROR_WEIGHT_INSTABILE;
                              /*~-1*/
                              }
                              /*~E:I1524*/
                              /*~E:A1523*/
                              /*~-1*/
                              }
                              /*~E:I1520*/
                              /*~-1*/
#endif
                              /*~E:I1519*/
                              /*~E:A1518*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1517*/
                              /*~F:1525*/
                              case 1:
                              /*~-1*/
                              {
                              /*~A:1526*/
                              /*~+:Kanal 1*/
                              /*~I:1527*/
#ifdef CHANNEL_1
                              /*~T*/
                              byRetVal = Weight_SetCalibrationRegardingActualWeight(Parameter[1].fFloat);
                              /*~I:1528*/
                              if (!byRetVal)
                              /*~-1*/
                              {
                              /*~A:1529*/
                              /*~+:Eintrag in Diagnosespeicher vornehmen*/
                              /*~T*/
                              ulDiagnosisEntry2Set = DIAGNOSIS_MESSAGE_CALIBRATION;
                              /*~E:A1529*/
                              /*~A:1530*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              lText2Send = TEXT_MEASUREMENT_GAIN_SET_CHANNEL_1;
                              /*~E:A1530*/
                              /*~-1*/
                              }
                              /*~O:I1528*/
                              /*~-2*/
                              else
                              {
                              /*~K*/
                              /*~+:Fehler*/
                              /*~A:1531*/
                              /*~+:Textausgabe "E005"*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~I:1532*/
                              if (byRetVal == 2)
                              /*~-1*/
                              {
                              /*~T*/
                              lText2Send = TEXT_ERROR_WEIGHT_INSTABILE;
                              /*~-1*/
                              }
                              /*~E:I1532*/
                              /*~E:A1531*/
                              /*~-1*/
                              }
                              /*~E:I1528*/
                              /*~-1*/
#endif
                              /*~E:I1527*/
                              /*~E:A1526*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1525*/
                              /*~O:C1516*/
                              /*~-2*/
                              default:
                              {
                              /*~I:1533*/
#ifdef CHANNEL_0
                              /*~T*/
                              // Fehler
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I1533*/
                              /*~-1*/
                              }
                           /*~-1*/
                           }
                           /*~E:C1516*/
                        /*~-1*/
                        }
                        /*~O:I1515*/
                        /*~-2*/
                        else
                        {
                           /*~A:1534*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1534*/
                        /*~-1*/
                        }
                        /*~E:I1515*/
                     /*~-1*/
                     }
                     /*~E:I1512*/
                     /*~E:A1511*/
                     /*~-1*/
#endif
                     /*~E:I1496*/
                     /*~A:1535*/
                     /*~+:SCD - SetmaxCurrentDeviation*/
                     /*~I:1536*/
                     if (!strcmp(szCommand,"SCD"))	// SetmaxCurrentDeviation
                     /*~-1*/
                     {
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;

                        /*~I:1537*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].fFloat = Communication_GetFloatParameter(0);

                           /*~I:1538*/
                           if (!GET_RESPONSE)
                           /*~-1*/
                           {
                              /*~T*/
                              g_CurrentInterface.FeedBack.fMaxDeviation = Parameter[0].fFloat;
                              // und speichern
                              CurrentInterface_SaveDACSettings(CURRENTINTERFACE_MAXDEVIATION_FEEDBACK);

                              /*~A:1539*/
                              /*~+:Ausf�hrungsstatus auf 'OKAY' setzen*/
                              /*~+:*/
                              /*~T*/
                              // Ausf�hrungsstatus auf 'OKAY' setzen
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              /*~E:A1539*/
                              /*~A:1540*/
                              /*~+:Kanal 0 - Textausgabe*/
                              /*~I:1541*/
#ifdef CHANNEL_0
                              /*~A:1542*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              lText2Send = TEXT_MAX_CURRENT_DEVIATION_SET;
                              /*~E:A1542*/
                              /*~-1*/
#endif
                              /*~E:I1541*/
                              /*~E:A1540*/
                           /*~-1*/
                           }
                           /*~O:I1538*/
                           /*~-2*/
                           else
                           {
                              /*~K*/
                              /*~+:Fehler !!!*/
                              /*~A:1543*/
                              /*~+:Ausf�hrungsstatus auf 'E005' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A1543*/
                           /*~-1*/
                           }
                           /*~E:I1538*/
                        /*~-1*/
                        }
                        /*~O:I1537*/
                        /*~-2*/
                        else
                        {
                           /*~A:1544*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1544*/
                        /*~-1*/
                        }
                        /*~E:I1537*/
                     /*~-1*/
                     }
                     /*~E:I1536*/
                     /*~E:A1535*/
                     /*~A:1545*/
                     /*~+:SCF - SetCalibrationFactor*/
                     /*~I:1546*/
                     if (!strcmp(szCommand,"SCF"))
                     /*~-1*/
                     {
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;

                        /*~I:1547*/
                        if (!InstructionDecoder_CheckNbParameters(2,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           // Parameter auslesen
                           Parameter[0].nLong = Communication_GetLongParameter(0);
                           Parameter[1].fFloat = Communication_GetFloatParameter(1);
                           /*~C:1548*/
                           switch (Parameter[0].nLong)
                           /*~-1*/
                           {
                              /*~F:1549*/
                              case 0:
                              /*~-1*/
                              {
                              /*~A:1550*/
                              /*~+:Kanal 0*/
                              /*~I:1551*/
#ifdef CHANNEL_0
                              /*~T*/
                              // Kalibrierfaktor setzen
                              byRetVal = Weight_SetCalibrationFactor(Parameter[1].fFloat);
                              /*~I:1552*/
                              if (byRetVal)
                              /*~-1*/
                              {
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~-1*/
                              }
                              /*~O:I1552*/
                              /*~-2*/
                              else
                              {
                              /*~A:1553*/
                              /*~+:Eintrag in Diagnosespeicher vornehmen*/
                              /*~T*/
                              ulDiagnosisEntry2Set = DIAGNOSIS_MESSAGE_CALIBRATION_TO_VALUE;
                              /*~E:A1553*/
                              /*~A:1554*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              lText2Send = TEXT_MEASUREMENT_GAIN_SET_2_FIX_VALUE_CHANNEL_0;
                              /*~E:A1554*/
                              /*~-1*/
                              }
                              /*~E:I1552*/
                              /*~-1*/
#endif
                              /*~E:I1551*/
                              /*~E:A1550*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1549*/
                              /*~F:1555*/
                              case 1:
                              /*~-1*/
                              {
                              /*~A:1556*/
                              /*~+:Kanal 1*/
                              /*~I:1557*/
#ifdef CHANNEL_1
                              /*~T*/
                              // Kalibrierfaktor setzen
                              byRetVal = Weight_SetCalibrationFactor(Parameter[1].fFloat);
                              /*~I:1558*/
                              if (byRetVal)
                              /*~-1*/
                              {
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~-1*/
                              }
                              /*~O:I1558*/
                              /*~-2*/
                              else
                              {
                              /*~A:1559*/
                              /*~+:Eintrag in Diagnosespeicher vornehmen*/
                              /*~T*/
                              ulDiagnosisEntry2Set = DIAGNOSIS_MESSAGE_CALIBRATION_TO_VALUE;
                              /*~E:A1559*/
                              /*~A:1560*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              lText2Send = TEXT_MEASUREMENT_GAIN_SET_2_FIX_VALUE_CHANNEL_1;
                              /*~E:A1560*/
                              /*~-1*/
                              }
                              /*~E:I1558*/
                              /*~-1*/
#endif
                              /*~E:I1557*/
                              /*~E:A1556*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1555*/
                              /*~O:C1548*/
                              /*~-2*/
                              default:
                              {
                              /*~A:1561*/
                              /*~+:Kanal 0*/
                              /*~I:1562*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I1562*/
                              /*~E:A1561*/
                              /*~-1*/
                              }
                           /*~-1*/
                           }
                           /*~E:C1548*/
                        /*~-1*/
                        }
                        /*~O:I1547*/
                        /*~-2*/
                        else
                        {
                           /*~A:1563*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1563*/
                        /*~-1*/
                        }
                        /*~E:I1547*/
                     /*~-1*/
                     }
                     /*~E:I1546*/
                     /*~E:A1545*/
                     /*~A:1564*/
                     /*~+:SCL - SetCheckLimits*/
                     /*~I:1565*/
                     if (!strcmp(szCommand,"SCL"))
                     /*~-1*/
                     {
                        /*~A:1566*/
                        /*~+:Variablendeklarationen*/
                        /*~T*/
                        float fMaxDeviation;
                        float fMaxDrift;
                        /*~E:A1566*/
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;

                        /*~I:1567*/
                        if (!InstructionDecoder_CheckNbParameters(2,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0);
                           Parameter[1].fFloat = Communication_GetFloatParameter(1);

                           /*~I:1568*/
                           if (!GET_RESPONSE)
                           /*~-1*/
                           {
                              /*~T*/
                              // Alles okay
                              /*~C:1569*/
                              switch (Parameter[0].nLong)
                              /*~-1*/
                              {
                              /*~F:1570*/
                              case 0:	// Grenzwert 'Nullpunkt�berpr�fung' setzen
                              /*~-1*/
                              {
                              /*~T*/
                              g_Limit.fLimitZeroPointCheck = Parameter[1].fFloat;
                              // speichern
                              Save_Parameter(LOAD_SAVE_LIMIT_ZEROPOINTCHECK,&g_Limit.fLimitZeroPointCheck,4);
                              /*~A:1571*/
                              /*~+:Ausf�hrungsstatus auf 'OKAY' setzen*/
                              /*~+:*/
                              /*~T*/
                              // Ausf�hrungsstatus auf 'OKAY' setzen
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              /*~E:A1571*/
                              /*~A:1572*/
                              /*~+:Kanal 0 - Textausgabe*/
                              /*~I:1573*/
#ifdef CHANNEL_0 
                              /*~A:1574*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              lText2Send = TEXT_CHECKLIMIT_ZEROPOINTCHECK_SET;
                              /*~E:A1574*/
                              /*~-1*/
#endif
                              /*~E:I1573*/
                              /*~E:A1572*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1570*/
                              /*~F:1575*/
                              case 1:	// Grenzwert 'Temperaturgang' setzen
                              /*~-1*/
                              {
                              /*~T*/
                              MRW_Compensation_GetCheckLimits(&fMaxDeviation,&fMaxDrift);
                              MRW_Compensation_SetCheckLimits(Parameter[1].fFloat,fMaxDrift);
                              /*~A:1576*/
                              /*~+:Ausf�hrungsstatus auf 'OKAY' setzen*/
                              /*~+:*/
                              /*~T*/
                              // Ausf�hrungsstatus auf 'OKAY' setzen
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              /*~E:A1576*/
                              /*~A:1577*/
                              /*~+:Kanal 0 - Textausgabe*/
                              /*~I:1578*/
#ifdef CHANNEL_0 
                              /*~A:1579*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              lText2Send = TEXT_CHECKLIMIT_MAXDEVIATION_SET;
                              /*~E:A1579*/
                              /*~-1*/
#endif
                              /*~E:I1578*/
                              /*~E:A1577*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1575*/
                              /*~F:1580*/
                              case 2:	// Grenzwert 'Drift' setzen
                              /*~-1*/
                              {
                              /*~T*/
                              MRW_Compensation_GetCheckLimits(&fMaxDeviation,&fMaxDrift);
                              MRW_Compensation_SetCheckLimits(fMaxDeviation,Parameter[1].fFloat);
                              /*~A:1581*/
                              /*~+:Ausf�hrungsstatus auf 'OKAY' setzen*/
                              /*~+:*/
                              /*~T*/
                              // Ausf�hrungsstatus auf 'OKAY' setzen
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              /*~E:A1581*/
                              /*~A:1582*/
                              /*~+:Kanal 0 - Textausgabe*/
                              /*~I:1583*/
#ifdef CHANNEL_0 
                              /*~A:1584*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              lText2Send = TEXT_CHECKLIMIT_MAXDRIFT_SET;
                              /*~E:A1584*/
                              /*~-1*/
#endif
                              /*~E:I1583*/
                              /*~E:A1582*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1580*/
                              /*~O:C1569*/
                              /*~-2*/
                              default:
                              {
                              /*~K*/
                              /*~+:Fehler !!!*/
                              /*~A:1585*/
                              /*~+:Ausf�hrungsstatus auf 'E002' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E002;
                              /*~E:A1585*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~-1*/
                              }
                              /*~E:C1569*/
                           /*~-1*/
                           }
                           /*~O:I1568*/
                           /*~-2*/
                           else
                           {
                              /*~K*/
                              /*~+:Fehler !!!*/
                              /*~A:1586*/
                              /*~+:Ausf�hrungsstatus auf 'E005' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A1586*/
                           /*~-1*/
                           }
                           /*~E:I1568*/
                        /*~-1*/
                        }
                        /*~O:I1567*/
                        /*~-2*/
                        else
                        {
                           /*~A:1587*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1587*/
                        /*~-1*/
                        }
                        /*~E:I1567*/
                     /*~-1*/
                     }
                     /*~E:I1565*/
                     /*~E:A1564*/
                     /*~A:1588*/
                     /*~+:SCO - SetCompensationOnoff*/
                     /*~I:1589*/
                     if ((!strcmp(szCommand,"SCO")) || (!strcmp(szCommand,"SCE")))
                     /*~-1*/
                     {
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;

                        /*~I:1590*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~I:1591*/
                           if (!strcmp(szCommand,"SCO"))
                           /*~-1*/
                           {
                              /*~T*/
                              // Parameter auslesen
                              Parameter[0].nLong = Communication_GetLongParameter(0);
                           /*~-1*/
                           }
                           /*~O:I1591*/
                           /*~-2*/
                           else
                           {
                              /*~T*/
                              Parameter[0].nLong = 1;
                           /*~-1*/
                           }
                           /*~E:I1591*/
                           /*~I:1592*/
                           if (!GET_RESPONSE)
                           /*~-1*/
                           {
                              /*~I:1593*/
                              if (Parameter[0].nLong == 0)
                              /*~-1*/
                              {
                              /*~T*/
                              // Temperaturkompensation ausschalten
                              MRW_Compensation_SetCompensationOn(0);

                              /*~A:1594*/
                              /*~+:Eintrag im Diagnosespeicher vornehmen*/
                              /*~T*/
                              ulDiagnosisEntry2Set = DIAGNOSIS_WARNING_TEMPCOMP_OFF;
                              /*~E:A1594*/
                              /*~A:1595*/
                              /*~+:Kanal 0 - Textausgabe*/
                              /*~I:1596*/
#ifdef CHANNEL_0 
                              /*~I:1597*/
                              if (!SYSTEM_MRW_MANAGER)
                              /*~-1*/
                              {
                              /*~A:1598*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              lText2Send = TEXT_COMPENSATION_SWITCHED_OFF;
                              /*~E:A1598*/
                              /*~-1*/
                              }
                              /*~E:I1597*/
                              /*~-1*/
#endif
                              /*~E:I1596*/
                              /*~E:A1595*/
                              /*~-1*/
                              }
                              /*~O:I1593*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              // Temperaturkompensation einschalten
                              MRW_Compensation_SetCompensationOn(1);

                              /*~A:1599*/
                              /*~+:Eintrag im Diagnosespeicher vornehmen*/
                              /*~T*/
                              ulDiagnosisEntry2Set = DIAGNOSIS_WARNING_TEMPCOMP_ON;
                              /*~E:A1599*/
                              /*~A:1600*/
                              /*~+:Kanal 0 - Textausgabe*/
                              /*~I:1601*/
#ifdef CHANNEL_0 
                              /*~A:1602*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              lText2Send = TEXT_COMPENSATION_SWITCHED_ON;
                              /*~E:A1602*/
                              /*~-1*/
#endif
                              /*~E:I1601*/
                              /*~E:A1600*/
                              /*~-1*/
                              }
                              /*~E:I1593*/
                              /*~A:1603*/
                              /*~+:Ausf�hrungsstatus auf 'OKAY' setzen*/
                              /*~+:*/
                              /*~T*/
                              // Ausf�hrungsstatus auf 'OKAY' setzen
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              /*~E:A1603*/
                           /*~-1*/
                           }
                           /*~O:I1592*/
                           /*~-2*/
                           else
                           {
                              /*~K*/
                              /*~+:Fehler !!!*/
                              /*~A:1604*/
                              /*~+:Ausf�hrungsstatus auf 'E005' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A1604*/
                           /*~-1*/
                           }
                           /*~E:I1592*/
                        /*~-1*/
                        }
                        /*~O:I1590*/
                        /*~-2*/
                        else
                        {
                           /*~A:1605*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1605*/
                        /*~-1*/
                        }
                        /*~E:I1590*/
                     /*~-1*/
                     }
                     /*~E:I1589*/
                     /*~E:A1588*/
                     /*~A:1606*/
                     /*~+:SCR - SetConvertingRate*/
                     /*~A:1607*/
                     /*~+:Doxygen-Dokumentation*/
                     /*~T*/
                     /* Doxygen-Dokumentation */
                     /*~T*/
                     /*!
                     \page SUBPAGE_COMMANDS_SCR SCR
                     
                     
                     
                     
                     <table width=95% rules=all bgcolor="#E0E0F0">
                     \TABLE_COMMAND{1.,SCR,<Char><Float>,Wandlungsrate zur Gewichtsermittlung setzen, set the conversionrate of the weight-evaluation}
                     \TABLE_PARAMETER{2.,1,0\,1,Kanal,channel}
                     \TABLE_PARAMETER{2,,Wandlungsrate,conversionrate}
                     \TABLE_RETURN{3.,Text,text,OK / Mitteilung\, dass die Wandlungsrate gesetzt wurde,OK / message that the conversionrate was set}
                     \TABLE_RETURN_ADD{E002,Parameterfehler,parameterfault}
                     \TABLE_RETURN_ADD{E005,Ausf�hrungsfehler,execution-error}
                     \TABLE_RETURN_ADD{E007,Zuwenige Parameter,too less parameters}
                     \TABLE_RETURN_ADD{E008,Zuviele Parameter,too much parameters}
                     \TABLE_INTERFACE{4.,RS232}
                     \TABLE_CLOSE
                     \ref SUBPAGE_COMMANDS  \~german ">>> Befehls�bersicht " \~english ">>> Command-overview" \~ \n
                     
                     @cond FOR_PROGRAMMING_DOCS \ref SUBPAGE_SOFTWARE_CODESEGMENTS_COMMANDS_SCR \~german ">>> Code" \~english ">>> code" \~ @endcond
                     */
                     /*~T*/
                     /*!
                     \page SUBPAGE_COMMANDS_TABLE
                     \TABLE_COMMANDS{SUBPAGE_COMMANDS_SCR,<Char><Float>,Wandlungsrate zur Gewichtsermittlung setzen, set the conversionrate of the weight-evaluation}
                     */
                     /*~E:A1607*/
                     /*~A:1608*/
                     /*~+:Doxygen-Dokumentation - Codeausschnitt (Teil 1)*/
                     /*~T*/
                     /* Doxygen-Dokumentation - Codeausschnitt (Teil 1) */

                     /*~T*/
                     /*!
                     @cond FOR_PROGRAMMING_DOCS
                     \page SUBPAGE_SOFTWARE_CODESEGMENTS_COMMANDS_SCR SCR 
                     \code
                     @endcond
                     */

                     /*~E:A1608*/
                     /*~I:1609*/
                     if (!strcmp(szCommand,"SCR"))
                     /*~-1*/
                     {
                        /*~A:1610*/
                        /*~+:Variablendeklarationen*/
                        /*~T*/

                        /*~E:A1610*/
                        /*~A:1611*/
                        /*~+:Variableninitialisierungen*/
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;


                        /*~E:A1611*/
                        /*~I:1612*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           /* Parameter einlesen */
                           /* Wandlungsrate */
                           Parameter[0].fFloat = Communication_GetFloatParameter(0);
                           /*~I:1613*/
#ifdef MOF
                           /*~T*/
                           /* Parameter einlesen */
                           /* Wandlungsrate */
                           Parameter[0].fFloat = 4*Communication_GetFloatParameter(0);
                           /*~T*/
                           /* Die Wandlungsrate muss mal vier genommen werden, da der ADC im Togglebetrieb l�uft. D.h. es wird nur mit bei jeder zweiten Wandlung der DMS-Messwert ermittelt - bei der anderen Messung der Rohmesswert der Stromr�ckf�hrung. Zudem wird bei jeder Umschaltung ein Reset der ADCs ausgef�hrt, was zur Folge hat, dass der Messwert erst nach zweiten Wandlung zur Verf�gung steht.*/
                           /*~-1*/
#endif
                           /*~E:I1613*/
                           /*~I:1614*/
                           if ((Parameter[0].fFloat <= 105.3)&&(Parameter[0].fFloat >= 5.35))
                           /*~-1*/
                           {
                              /*~T*/
                              /* AD-Wandler initialisieren */
                              byRetVal = ADuC836_ADCSetSincFilter(Parameter[0].fFloat,ADuC836_ADC_FREQUENCY_32KHZ);
                              /*~I:1615*/
                              if (!GET_RESPONSE)
                              /*~-1*/
                              {
                              /*~I:1616*/
                              if (byRetVal == 0)
                              /*~-1*/
                              {
                              /*~T*/
                              // Alles okay
                              /*~A:1617*/
                              /*~+:Ausf�hrungsstatus auf 'OKAY' setzen*/
                              /*~+:*/
                              /*~T*/
                              // Ausf�hrungsstatus auf 'OKAY' setzen
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              /*~E:A1617*/
                              /*~A:1618*/
                              /*~+:Wandlungsrate abspeichern*/
                              /*~T*/
                              /* Wandlungsrate abspeichern */
                              Save_Parameter(LOAD_SAVE_MEASUREMENT_CONVERSIONRATE,&Parameter[0].fFloat,4);
                              /*~E:A1618*/
                              /*~A:1619*/
                              /*~+:Eintrag in Diagnosespeicher vornehmen*/
                              /*~T*/
                              ulDiagnosisEntry2Set = DIAGNOSIS_MESSAGE_WEIGHT_CONVERSIONRATE_CHANGED;
                              /*~E:A1619*/
                              /*~A:1620*/
                              /*~+:Textausgabe*/
                              /*~I:1621*/
#ifdef CHANNEL_0
                              /*~T*/
                              lText2Send = TEXT_MEASUREMENT_CONVERSIONRATE_CHANGED;
                              /*~-1*/
#endif
                              /*~E:I1621*/
                              /*~E:A1620*/
                              /*~-1*/
                              }
                              /*~O:I1616*/
                              /*~-2*/
                              else
                              {
                              /*~A:1622*/
                              /*~+:Ausf�hrungsfehler - E005*/
                              /*~T*/
                              /* Ausf�hrungsfehler - E005 */
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A1622*/
                              /*~-1*/
                              }
                              /*~E:I1616*/
                              /*~-1*/
                              }
                              /*~O:I1615*/
                              /*~-2*/
                              else
                              {
                              /*~K*/
                              /*~+:Fehler !!!*/
                              /*~A:1623*/
                              /*~+:Ausf�hrungsstatus auf 'E005' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A1623*/
                              /*~-1*/
                              }
                              /*~E:I1615*/
                           /*~-1*/
                           }
                           /*~O:I1614*/
                           /*~-2*/
                           else
                           {
                              /*~A:1624*/
                              /*~+:Parameterfehler - E002*/
                              /*~T*/
                              /* Parameterfehler - E002 */
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E002;
                              /*~E:A1624*/
                           /*~-1*/
                           }
                           /*~E:I1614*/
                        /*~-1*/
                        }
                        /*~O:I1612*/
                        /*~-2*/
                        else
                        {
                           /*~A:1625*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1625*/
                        /*~-1*/
                        }
                        /*~E:I1612*/
                     /*~-1*/
                     }
                     /*~E:I1609*/
                     /*~A:1626*/
                     /*~+:Doxygen-Dokumentation - Codeausschnitt (Teil 2)*/
                     /*~T*/
                     /* Doxygen-Dokumentation - Codeausschnitt (Teil 2) */

                     /*~T*/
                     /*!
                     @cond FOR_PROGRAMMING_DOCS
                     \page SUBPAGE_SOFTWARE_CODESEGMENTS_COMMANDS_SCR
                     \endcode 
                     \ref SUBPAGE_SOFTWARE_CODESEGMENTS_COMMANDS  \~german ">>> zur�ck" \~english ">>> back" \~
                     @endcond
                     */

                     /*~E:A1626*/
                     /*~E:A1606*/
                     /*~I:1627*/
#ifdef SPEZIALVERSION_FUER_TESTSYSTEME 
                     /*~A:1628*/
                     /*~+:SCU - SetCUrrent*/
                     /*~I:1629*/
                     if (!strcmp(szCommand,"SCU"))
                     /*~-1*/
                     {
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:1630*/
                        if (!InstructionDecoder_CheckNbParameters(2,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~C:1631*/
                           switch (Communication_GetLongParameter(0))
                           /*~-1*/
                           {
                              /*~F:1632*/
                              case 0:
                              /*~-1*/
                              {
                              /*~I:1633*/
#ifdef CHANNEL_0
                              /*~I:1634*/
                              if ((Communication_GetFloatParameter(1) >=  3)&&(Communication_GetFloatParameter(1) < 21))
                              /*~-1*/
                              {
                              /*~T*/
                              g_Weight_lSimulatedRMW = (long)(Communication_GetFloatParameter(1)* 1000);
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              /*~-1*/
                              }
                              /*~O:I1634*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_NOK;
                              /*~-1*/
                              }
                              /*~E:I1634*/
                              /*~-1*/
#endif
                              /*~E:I1633*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1632*/
                              /*~F:1635*/
                              case 1:
                              /*~-1*/
                              {
                              /*~I:1636*/
#ifdef CHANNEL_1
                              /*~I:1637*/
                              if ((Communication_GetFloatParameter(1) >=  3)&&(Communication_GetFloatParameter(1) < 21))
                              /*~-1*/
                              {
                              /*~T*/
                              g_Weight_lSimulatedRMW = (long)(Communication_GetFloatParameter(1)* 1000);
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK; 
                              /*~-1*/
                              }
                              /*~O:I1637*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_NOK;
                              /*~-1*/
                              }
                              /*~E:I1637*/
                              /*~-1*/
#endif
                              /*~E:I1636*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1635*/
                           /*~-1*/
                           }
                           /*~E:C1631*/
                        /*~-1*/
                        }
                        /*~O:I1630*/
                        /*~-2*/
                        else
                        {
                           /*~A:1638*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1638*/
                        /*~-1*/
                        }
                        /*~E:I1630*/
                     /*~-1*/
                     }
                     /*~E:I1629*/
                     /*~E:A1628*/
                     /*~-1*/
#endif
                     /*~E:I1627*/
                     /*~A:1639*/
                     /*~+:SCV - SetCompensationValues*/
                     /*~I:1640*/
                     if (!strcmp(szCommand,"SCV"))
                     /*~-1*/
                     {
                        /*~A:1641*/
                        /*~+:Variablendeklarationen*/
                        /*~T*/
                        unsigned char byChannel;
                        char chTemperature;
                        int nValue2Set;
                        /*~E:A1641*/
                        /*~A:1642*/
                        /*~+:Variableninitialisierungen*/
                        /*~T*/
                        byChannel = (char)Communication_GetLongParameter(0);
                        chTemperature = (char)Communication_GetLongParameter(1);
                        nValue2Set = (int)Communication_GetLongParameter(2);
                        /*~E:A1642*/
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:1643*/
                        if (!InstructionDecoder_CheckNbParameters(3,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~C:1644*/
                           switch (byChannel)
                           /*~-1*/
                           {
                              /*~F:1645*/
                              case 0:
                              /*~-1*/
                              {
                              /*~A:1646*/
                              /*~+:Kanal 0*/
                              /*~I:1647*/
#ifdef CHANNEL_0
                              /*~I:1648*/
                              if (!Compensation_SetCompensationValues(chTemperature,nValue2Set))
                              /*~-1*/
                              {
                              /*~A:1649*/
                              /*~+:Eintrag in Diagnosespeicher vornehmen*/
                              /*~T*/
                              ulDiagnosisEntry2Set = DIAGNOSIS_WARNING_COMPENSATION_VALUE_SET_MANUALLY;
                              /*~E:A1649*/
                              /*~A:1650*/
                              /*~+:Textausgabe f�r Terminalbetrieb*/
                              /*~T*/
                              lText2Send = TEXT_COMPENSATION_REFPOINT_MANUALLY_SET_CHANNEL_0;
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              /*~E:A1650*/
                              /*~-1*/
                              }
                              /*~O:I1648*/
                              /*~-2*/
                              else
                              {
                              /*~A:1651*/
                              /*~+:Fehler - E002 senden*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E002;
                              /*~E:A1651*/
                              /*~-1*/
                              }
                              /*~E:I1648*/
                              /*~-1*/
#endif
                              /*~E:I1647*/
                              /*~E:A1646*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1645*/
                              /*~F:1652*/
                              case 1:
                              /*~-1*/
                              {
                              /*~A:1653*/
                              /*~+:Kanal 1*/
                              /*~I:1654*/
#ifdef CHANNEL_1
                              /*~I:1655*/
                              if (!Compensation_SetCompensationValues(chTemperature,nValue2Set))
                              /*~-1*/
                              {
                              /*~A:1656*/
                              /*~+:Eintrag in Diagnosespeicher vornehmen*/
                              /*~T*/
                              ulDiagnosisEntry2Set = DIAGNOSIS_WARNING_COMPENSATION_VALUE_SET_MANUALLY;
                              /*~E:A1656*/
                              /*~A:1657*/
                              /*~+:Textausgabe f�r Terminalbetrieb*/
                              /*~T*/
                              lText2Send = TEXT_COMPENSATION_REFPOINT_MANUALLY_SET_CHANNEL_1;
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              /*~E:A1657*/
                              /*~-1*/
                              }
                              /*~O:I1655*/
                              /*~-2*/
                              else
                              {
                              /*~A:1658*/
                              /*~+:Fehler - E002 senden*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E002;
                              /*~E:A1658*/
                              /*~-1*/
                              }
                              /*~E:I1655*/
                              /*~-1*/
#endif
                              /*~E:I1654*/
                              /*~E:A1653*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1652*/
                              /*~O:C1644*/
                              /*~-2*/
                              default:
                              {
                              /*~A:1659*/
                              /*~+:Fehler - E001 senden*/
                              /*~I:1660*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I1660*/
                              /*~E:A1659*/
                              /*~-1*/
                              }
                           /*~-1*/
                           }
                           /*~E:C1644*/
                        /*~-1*/
                        }
                        /*~O:I1643*/
                        /*~-2*/
                        else
                        {
                           /*~A:1661*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1661*/
                        /*~-1*/
                        }
                        /*~E:I1643*/
                     /*~-1*/
                     }
                     /*~E:I1640*/
                     /*~E:A1639*/
                     /*~A:1662*/
                     /*~+:SEC - SetEmodulCompensation_onoff*/
                     /*~I:1663*/
                     if (!strcmp(szCommand,"SEC"))
                     /*~-1*/
                     {
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;

                        /*~I:1664*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           // Parameter auslesen
                           Parameter[0].nLong = Communication_GetLongParameter(0);
                           /*~I:1665*/
                           if (!GET_RESPONSE)
                           /*~-1*/
                           {
                              /*~I:1666*/
                              if (Parameter[0].nLong == 0)
                              /*~-1*/
                              {
                              /*~T*/
                              // E-Modul-Kompensation ausschalten
                              Weight_SetEModulCompensationOn(0);


                              /*~A:1667*/
                              /*~+:Eintrag im Diagnosespeicher vornehmen*/
                              /*~T*/
                              ulDiagnosisEntry2Set = DIAGNOSIS_WARNING_EMODULCOMP_OFF;
                              /*~E:A1667*/
                              /*~A:1668*/
                              /*~+:Kanal 0 - Textausgabe*/
                              /*~I:1669*/
#ifdef CHANNEL_0 
                              /*~A:1670*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              lText2Send = TEXT_E_MODUL_COMPENSATION_SWITCHED_OFF;
                              /*~E:A1670*/
                              /*~-1*/
#endif
                              /*~E:I1669*/
                              /*~E:A1668*/
                              /*~-1*/
                              }
                              /*~O:I1666*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              // E-Modul-Kompensation einschalten
                              Weight_SetEModulCompensationOn(1);


                              /*~A:1671*/
                              /*~+:Eintrag im Diagnosespeicher vornehmen*/
                              /*~T*/
                              ulDiagnosisEntry2Set = DIAGNOSIS_WARNING_EMODULCOMP_ON;
                              /*~E:A1671*/
                              /*~A:1672*/
                              /*~+:Kanal 0 - Textausgabe*/
                              /*~I:1673*/
#ifdef CHANNEL_0 
                              /*~A:1674*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              lText2Send = TEXT_E_MODUL_COMPENSATION_SWITCHED_ON;
                              /*~E:A1674*/
                              /*~-1*/
#endif
                              /*~E:I1673*/
                              /*~E:A1672*/
                              /*~-1*/
                              }
                              /*~E:I1666*/
                              /*~A:1675*/
                              /*~+:Ausf�hrungsstatus auf 'OKAY' setzen*/
                              /*~+:*/
                              /*~T*/
                              // Ausf�hrungsstatus auf 'OKAY' setzen
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              /*~E:A1675*/
                           /*~-1*/
                           }
                           /*~O:I1665*/
                           /*~-2*/
                           else
                           {
                              /*~K*/
                              /*~+:Fehler !!!*/
                              /*~A:1676*/
                              /*~+:Ausf�hrungsstatus auf 'E005' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A1676*/
                           /*~-1*/
                           }
                           /*~E:I1665*/
                        /*~-1*/
                        }
                        /*~O:I1664*/
                        /*~-2*/
                        else
                        {
                           /*~A:1677*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1677*/
                        /*~-1*/
                        }
                        /*~E:I1664*/
                     /*~-1*/
                     }
                     /*~E:I1663*/
                     /*~E:A1662*/
                     /*~A:1678*/
                     /*~+:SFD - SetFilterDepth*/
                     /*~I:1679*/
                     if (!strcmp(szCommand,"SFD"))
                     /*~-1*/
                     {
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;

                        /*~I:1680*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0);

                           /*~I:1681*/
                           if (!GET_RESPONSE)
                           /*~-1*/
                           {
                              /*~T*/
                              // Alles okay
                              /*~T*/
                              byTemp = Parameter[0].nLong;
                              /*~C:1682*/
                              switch (AverageFilter_SetFilterDepth(WEIGHT_WEIGHTCHANNEL,byTemp))
                              /*~-1*/
                              {
                              /*~F:1683*/
                              case 0:
                              /*~-1*/
                              {
                              /*~T*/
                              // Alles okay
                              // und Wert abspeichern
                              Save_Parameter(LOAD_SAVE_FILTER_DEPTH_WEIGHT,&byTemp,0);
                              /*~A:1684*/
                              /*~+:Ausf�hrungsstatus auf 'OKAY' setzen*/
                              /*~+:*/
                              /*~T*/
                              // Ausf�hrungsstatus auf 'OKAY' setzen
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              /*~E:A1684*/
                              /*~A:1685*/
                              /*~+:Kanal 0 - Textausgabe*/
                              /*~I:1686*/
#ifdef CHANNEL_0 
                              /*~A:1687*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              lText2Send = TEXT_AVERAGE_FILTER_FILTERDEPTH_SET;
                              /*~E:A1687*/
                              /*~-1*/
#endif
                              /*~E:I1686*/
                              /*~E:A1685*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1683*/
                              /*~F:1688*/
                              case 5:
                              /*~-1*/
                              {
                              /*~T*/
                              // Parameter au�erhalb der Grenzwerte
                              /*~T*/
                              // den gesetzen Wert abfragen
                              byTemp = AverageFilter_GetFilterDepth(WEIGHT_WEIGHTCHANNEL);
                              // und abspeichern
                              Save_Parameter(LOAD_SAVE_FILTER_DEPTH_WEIGHT,&byTemp,0);
                              /*~A:1689*/
                              /*~+:Ausf�hrungsstatus auf 'E002' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E002;
                              /*~E:A1689*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1688*/
                              /*~O:C1682*/
                              /*~-2*/
                              default:
                              {
                              /*~K*/
                              /*~+:Fehler !!!*/
                              /*~A:1690*/
                              /*~+:Ausf�hrungsstatus auf 'E005' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A1690*/
                              /*~-1*/
                              }
                              /*~-1*/
                              }
                              /*~E:C1682*/
                           /*~-1*/
                           }
                           /*~O:I1681*/
                           /*~-2*/
                           else
                           {
                              /*~K*/
                              /*~+:Fehler !!!*/
                              /*~A:1691*/
                              /*~+:Ausf�hrungsstatus auf 'E005' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A1691*/
                           /*~-1*/
                           }
                           /*~E:I1681*/
                        /*~-1*/
                        }
                        /*~O:I1680*/
                        /*~-2*/
                        else
                        {
                           /*~A:1692*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1692*/
                        /*~-1*/
                        }
                        /*~E:I1680*/
                     /*~-1*/
                     }
                     /*~E:I1679*/
                     /*~E:A1678*/
                     /*~A:1693*/
                     /*~+:SFE - SetFeedbackError*/
                     /*~I:1694*/
#ifdef MIT_STROM_ABWEICHUNGSSIMULATION
                     /*~I:1695*/
                     if (!strcmp(szCommand,"SFE"))	// SetFeedbackError
                     /*~-1*/
                     {
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;

                        /*~I:1696*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].fFloat = Communication_GetFloatParameter(0);

                           /*~I:1697*/
                           if (!GET_RESPONSE)
                           /*~-1*/
                           {
                              /*~T*/
                              g_CurrentInterface.FeedBack.fSimulatedDerivation = Parameter[0].fFloat;
                              /*~A:1698*/
                              /*~+:Ausf�hrungsstatus auf 'OKAY' setzen*/
                              /*~+:*/
                              /*~T*/
                              // Ausf�hrungsstatus auf 'OKAY' setzen
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              /*~E:A1698*/
                              /*~A:1699*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~I:1700*/
#ifdef CHANNEL_0
                              /*~T*/
                              lText2Send = TEXT_CURRENT_DEVIATION_SET;
                              /*~-1*/
#endif
                              /*~E:I1700*/
                              /*~E:A1699*/
                           /*~-1*/
                           }
                           /*~O:I1697*/
                           /*~-2*/
                           else
                           {
                              /*~K*/
                              /*~+:Fehler !!!*/
                              /*~A:1701*/
                              /*~+:Ausf�hrungsstatus auf 'E005' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A1701*/
                           /*~-1*/
                           }
                           /*~E:I1697*/
                        /*~-1*/
                        }
                        /*~O:I1696*/
                        /*~-2*/
                        else
                        {
                           /*~A:1702*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1702*/
                        /*~-1*/
                        }
                        /*~E:I1696*/
                     /*~-1*/
                     }
                     /*~E:I1695*/
                     /*~-1*/
#endif
                     /*~E:I1694*/
                     /*~E:A1693*/
                     /*~I:1703*/
#ifdef SYSTEM_CND_WITH_DEADBAND_FILTER
                     /*~A:1704*/
                     /*~+:SFW - SetFilterWidth*/
                     /*~I:1705*/
                     if (!strcmp(szCommand,"SFW"))
                     /*~-1*/
                     {
                        /*~A:1706*/
                        /*~+:Variablendeklarationen*/
                        /*~T*/
                        int nFilterBandWidth;
                        /*~E:A1706*/
                        /*~A:1707*/
                        /*~+:Variableninitialisierungen*/
                        /*~T*/

                        /*~E:A1707*/
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:1708*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           nFilterBandWidth = Communication_GetLongParameter(0);
                           /*~I:1709*/
                           if (!GET_RESPONSE)
                           /*~-1*/
                           {
                              /*~T*/
                              // Alles okay
                              /*~T*/
                              // Totbandfilter-Bandbreite setzen
                              DeadBandFilter_SetBandWidth(WEIGHT_WEIGHTCHANNEL,(float)nFilterBandWidth);

                              // und Wert abspeichern
                              Save_Parameter(LOAD_SAVE_FILTER_BANDWIDTH_WEIGHT,&nFilterBandWidth,0);
                              /*~A:1710*/
                              /*~+:Ausf�hrungsstatus auf 'OKAY' setzen*/
                              /*~+:*/
                              /*~T*/
                              // Ausf�hrungsstatus auf 'OKAY' setzen
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              /*~E:A1710*/
                              /*~A:1711*/
                              /*~+:Kanal 0 - Textausgabe*/
                              /*~I:1712*/
#ifdef CHANNEL_0
                              /*~A:1713*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              lText2Send = TEXT_DEADBAND_FILTER_FILTERWIDTH_SET;
                              /*~E:A1713*/
                              /*~-1*/
#endif
                              /*~E:I1712*/
                              /*~E:A1711*/
                           /*~-1*/
                           }
                           /*~O:I1709*/
                           /*~-2*/
                           else
                           {
                              /*~K*/
                              /*~+:Fehler !!!*/
                              /*~A:1714*/
                              /*~+:Ausf�hrungsstatus auf 'E005' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A1714*/
                           /*~-1*/
                           }
                           /*~E:I1709*/
                        /*~-1*/
                        }
                        /*~O:I1708*/
                        /*~-2*/
                        else
                        {
                           /*~A:1715*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1715*/
                        /*~-1*/
                        }
                        /*~E:I1708*/
                     /*~-1*/
                     }
                     /*~E:I1705*/
                     /*~E:A1704*/
                     /*~O:I1703*/
                     /*~-1*/
#else
                     /*~A:1716*/
                     /*~+:SFW - SetFilterWidth (Dummy)*/
                     /*~I:1717*/
                     if (!strcmp(szCommand,"SFW"))
                     /*~-1*/
                     {
                        /*~A:1718*/
                        /*~+:Variablendeklarationen*/
                        /*~T*/

                        /*~E:A1718*/
                        /*~A:1719*/
                        /*~+:Variableninitialisierungen*/
                        /*~T*/

                        /*~E:A1719*/
                        /*~A:1720*/
                        /*~+:Ausf�hrungsstatus auf 'OKAY' setzen*/
                        /*~+:*/
                        /*~T*/
                        // Ausf�hrungsstatus auf 'OKAY' setzen
                        byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                        /*~E:A1720*/
                        /*~A:1721*/
                        /*~+:Kanal 0 - Textausgabe*/
                        /*~I:1722*/
#ifdef CHANNEL_0
                        /*~A:1723*/
                        /*~+:Text f�r Terminalbetrieb*/
                        /*~T*/
                        lText2Send = TEXT_DEADBAND_FILTER_FILTERWIDTH_SET;
                        /*~E:A1723*/
                        /*~-1*/
#endif
                        /*~E:I1722*/
                        /*~E:A1721*/
                     /*~-1*/
                     }
                     /*~E:I1717*/
                     /*~E:A1716*/
                     /*~-1*/
#endif
                     /*~E:I1703*/
                     /*~A:1724*/
                     /*~+:SID - SetsystemID*/
                     /*~I:1725*/
                     if (!strcmp(szCommand,"SID"))
                     /*~-1*/
                     {
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:1726*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~I:1727*/
#ifdef CHANNEL_0
                           /*~I:1728*/
                           if (!Global.ulSystemID)
                           /*~-1*/
                           {
                              /*~T*/
                              Global.ulSystemID = Communication_GetLongParameter(0);

                              Save_Parameter(LOAD_SAVE_SYSTEM_ID,&Global.ulSystemID,4);
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              lText2Send = TEXT_ID_SET; 
                           /*~-1*/
                           }
                           /*~O:I1728*/
                           /*~-2*/
                           else
                           {
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;

                              lText2Send = TEXT_SYSTEM_ID_ALREADY_SET;
                           /*~-1*/
                           }
                           /*~E:I1728*/
                           /*~-1*/
#endif
                           /*~E:I1727*/
                        /*~-1*/
                        }
                        /*~O:I1726*/
                        /*~-2*/
                        else
                        {
                           /*~A:1729*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1729*/
                        /*~-1*/
                        }
                        /*~E:I1726*/
                     /*~-1*/
                     }
                     /*~E:I1725*/
                     /*~E:A1724*/
                     /*~I:1730*/
#ifdef MIT_GEWICHTSSIMULATION 
                     /*~A:1731*/
                     /*~+:SIW - SImulateWeight*/
                     /*~I:1732*/
                     if (!strcmp(szCommand,"SIW"))
                     /*~-1*/
                     {
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:1733*/
                        if (!InstructionDecoder_CheckNbParameters(2,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~C:1734*/
                           switch (Communication_GetLongParameter(0))
                           /*~-1*/
                           {
                              /*~F:1735*/
                              case 0:
                              /*~-1*/
                              {
                              /*~I:1736*/
#ifdef CHANNEL_0
                              /*~I:1737*/
                              if (Communication_GetLongParameter(1) < 65000)
                              /*~-1*/
                              {
                              /*~T*/
                              g_Weight_lSimulatedRMW = Communication_GetLongParameter(1);
                              /*~T*/
                              g_SystemControl.bySimulate |= 0x01;
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              lText2Send = TEXT_SIMULATED_RMW_SET_CH0; 
                              /*~-1*/
                              }
                              /*~O:I1737*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              g_SystemControl.bySimulate &= 0xFE;
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              lText2Send = TEXT_RMW_SIMULATION_STOPPED_CH0; 
                              /*~-1*/
                              }
                              /*~E:I1737*/
                              /*~-1*/
#endif
                              /*~E:I1736*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1735*/
                              /*~F:1738*/
                              case 1:
                              /*~-1*/
                              {
                              /*~I:1739*/
#ifdef CHANNEL_1
                              /*~I:1740*/
                              if (Communication_GetLongParameter(1) < 65000)
                              /*~-1*/
                              {
                              /*~T*/
                              g_Weight_lSimulatedRMW = Communication_GetLongParameter(1);
                              /*~T*/
                              g_SystemControl.bySimulate |= 0x01;
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              lText2Send = TEXT_SIMULATED_RMW_SET_CH1; 
                              /*~-1*/
                              }
                              /*~O:I1740*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              g_SystemControl.bySimulate &= 0xFE;
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              lText2Send = TEXT_RMW_SIMULATION_STOPPED_CH1; 
                              /*~-1*/
                              }
                              /*~E:I1740*/
                              /*~-1*/
#endif
                              /*~E:I1739*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1738*/
                           /*~-1*/
                           }
                           /*~E:C1734*/
                        /*~-1*/
                        }
                        /*~O:I1733*/
                        /*~-2*/
                        else
                        {
                           /*~A:1741*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1741*/
                        /*~-1*/
                        }
                        /*~E:I1733*/
                     /*~-1*/
                     }
                     /*~E:I1732*/
                     /*~E:A1731*/
                     /*~-1*/
#endif
                     /*~E:I1730*/
                     /*~A:1742*/
                     /*~+:SLC - SetLoadCelltype*/
                     /*~I:1743*/
                     if (!strcmp(szCommand,"SLC"))
                     /*~-1*/
                     {
                        /*~A:1744*/
                        /*~+:Variablendeklarationen*/
                        /*~T*/
                        BYTE byError;
                        /*~E:A1744*/
                        /*~A:1745*/
                        /*~+:Variableninitialisierungen*/
                        /*~T*/
                        byError = 0;
                        /*~E:A1745*/
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;

                        /*~I:1746*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0);
                           /*~I:1747*/
                           if (!GET_RESPONSE)
                           /*~-1*/
                           {
                              /*~T*/
                              // Alles okay
                              /*~C:1748*/
                              switch ((unsigned char)Parameter[0].nLong)
                              /*~-1*/
                              {
                              /*~F:1749*/
                              case 1:
                              /*~-1*/
                              {
                              /*~T*/
                              // Defaultparameter 'Standard-Zelle'
                              /*~I:1750*/
                              if ((g_SystemControl.byLoadCellType)&&(g_SystemControl.byLoadCellType != 1))
                              /*~-1*/
                              {
                              /*~T*/
                              // Zellentyp hat sich ge�ndert

                              // Kalibrierfaktor �ndern
                              Measurement_GetCalibrationFactor(WEIGHT_WEIGHTCHANNEL,&fTemp);
                              Weight_SetCalibrationFactor(fTemp / 5);

                              // Filtertiefe halbieren
                              byTemp = AverageFilter_GetFilterDepth(WEIGHT_WEIGHTCHANNEL) / 2;
                              AverageFilter_SetFilterDepth(WEIGHT_WEIGHTCHANNEL,byTemp);
                              // und speichern
                              Save_Parameter(LOAD_SAVE_FILTER_DEPTH_WEIGHT,&byTemp,0);


                              // Verst�rkungsfaktoren der Stromschnittstelle anpassen
                              fTemp = ADuC836_DACGetGain(0);
                              ADuC836_DACSetGain(fTemp / 5);

                              fTemp = ADuC836_DACGetGain(1);
                              ADuC836_DACSetGainNorm(fTemp / 5);

                              // und neue Einstellungen sichern
                              CurrentInterface_SaveDACSettings(CURRENTINTERFACE_ALL_SETTINGS);
                              /*~-1*/
                              }
                              /*~E:I1750*/
                              /*~T*/
                              g_Limit.fLimitZeroPointCheck = LIMIT_ZERODRIFT_DETECTION;
                              // speichern
                              Save_Parameter(LOAD_SAVE_LIMIT_ZEROPOINTCHECK,&g_Limit.fLimitZeroPointCheck,4);
                              /*~T*/
                              MRW_Compensation_SetCheckLimits(MRW_COMPENSATION_LIMIT_DEVIATIONS,MRW_COMPENSATION_LIMIT_DRIFT);
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1749*/
                              /*~F:1751*/
                              case 2:
                              /*~-1*/
                              {
                              /*~T*/
                              // Defaultparameter 'XL-Zelle'
                              /*~I:1752*/
                              if (g_SystemControl.byLoadCellType != 2)
                              /*~-1*/
                              {
                              /*~T*/
                              // Zellentyp hat sich ge�ndert

                              // Kalibrierfaktor �ndern
                              Measurement_GetCalibrationFactor(WEIGHT_WEIGHTCHANNEL,&fTemp);
                              Weight_SetCalibrationFactor(fTemp * 5);

                              // Filtertiefe verdoppeln
                              byTemp = AverageFilter_GetFilterDepth(WEIGHT_WEIGHTCHANNEL) * 2;
                              AverageFilter_SetFilterDepth(WEIGHT_WEIGHTCHANNEL,byTemp);
                              // und speichern
                              Save_Parameter(LOAD_SAVE_FILTER_DEPTH_WEIGHT,&byTemp,0);

                              // Verst�rkungsfaktoren der Stromschnittstelle anpassen
                              fTemp = ADuC836_DACGetGain(0);
                              ADuC836_DACSetGain(fTemp * 5);

                              fTemp = ADuC836_DACGetGain(1);
                              ADuC836_DACSetGainNorm(fTemp * 5);

                              // und neue Einstellungen sichern
                              CurrentInterface_SaveDACSettings(CURRENTINTERFACE_ALL_SETTINGS);
                              /*~-1*/
                              }
                              /*~E:I1752*/
                              /*~T*/
                              g_Limit.fLimitZeroPointCheck = LIMIT_ZERODRIFT_DETECTION_XL;
                              // speichern
                              Save_Parameter(LOAD_SAVE_LIMIT_ZEROPOINTCHECK,&g_Limit.fLimitZeroPointCheck,4);
                              /*~T*/
                              MRW_Compensation_SetCheckLimits(MRW_COMPENSATION_LIMIT_DEVIATIONS_XL,MRW_COMPENSATION_LIMIT_DRIFT_XL);
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1751*/
                              /*~O:C1748*/
                              /*~-2*/
                              default:
                              {
                              /*~T*/
                              byError = 1;
                              /*~A:1753*/
                              /*~+:Ausf�hrungsstatus auf 'E002' setzen*/
                              /*~K*/
                              /*~+:Parameter au�erhalb der Grenzen !!!*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E002;
                              /*~E:A1753*/
                              /*~-1*/
                              }
                              /*~-1*/
                              }
                              /*~E:C1748*/
                              /*~I:1754*/
                              if (!byError)
                              /*~-1*/
                              {
                              /*~T*/
                              // Wert setzen
                              g_SystemControl.byLoadCellType = (unsigned char)Parameter[0].nLong;
                              // und abspeichern
                              Save_Parameter(LOAD_SAVE_CELLTYPE,&g_SystemControl.byLoadCellType,0);
                              /*~A:1755*/
                              /*~+:Ausf�hrungsstatus auf 'OKAY' setzen*/
                              /*~+:*/
                              /*~T*/
                              // Ausf�hrungsstatus auf 'OKAY' setzen
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              /*~E:A1755*/
                              /*~A:1756*/
                              /*~+:Kanal 0 - Textausgabe*/
                              /*~I:1757*/
#ifdef CHANNEL_0 
                              /*~A:1758*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              lText2Send = TEXT_LOADCELL_TYPE_SET;
                              /*~E:A1758*/
                              /*~-1*/
#endif
                              /*~E:I1757*/
                              /*~E:A1756*/
                              /*~-1*/
                              }
                              /*~E:I1754*/
                           /*~-1*/
                           }
                           /*~O:I1747*/
                           /*~-2*/
                           else
                           {
                              /*~A:1759*/
                              /*~+:Ausf�hrungsstatus auf 'E005' setzen*/
                              /*~K*/
                              /*~+:Fehler !!!*/
                              /*~I:1760*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~-1*/
#endif
                              /*~E:I1760*/
                              /*~E:A1759*/
                           /*~-1*/
                           }
                           /*~E:I1747*/
                        /*~-1*/
                        }
                        /*~O:I1746*/
                        /*~-2*/
                        else
                        {
                           /*~A:1761*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1761*/
                        /*~-1*/
                        }
                        /*~E:I1746*/
                     /*~-1*/
                     }
                     /*~E:I1743*/
                     /*~E:A1742*/
                     /*~A:1762*/
                     /*~+:SLS - SetdacLimitStatus*/
                     /*~I:1763*/
                     if (!strcmp(szCommand,"SLS"))
                     /*~-1*/
                     {
                        /*~A:1764*/
                        /*~+:Variablendeklarationen*/
                        /*~T*/
                        unsigned long ulEepromClearID;
                        bit bOnOff;
                        /*~E:A1764*/
                        /*~A:1765*/
                        /*~+:Variableninitialisierungen*/
                        /*~T*/
                        ulEepromClearID = 0L;
                        /*~E:A1765*/
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:1766*/
                        if (!InstructionDecoder_CheckNbParameters(2,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           // Parameter auslesen
                           Parameter[0].nLong = Communication_GetLongParameter(0);
                           Parameter[1].nLong = Communication_GetLongParameter(1);
                           bOnOff = (bit) Communication_GetLongParameter(2); 
                           /*~C:1767*/
                           switch (Parameter[0].nLong)
                           /*~-1*/
                           {
                              /*~F:1768*/
                              case 0:
                              /*~-1*/
                              {
                              /*~A:1769*/
                              /*~+:Kanal 0*/
                              /*~I:1770*/
#ifdef CHANNEL_0
                              /*~T*/
                              ADuC836_DACEnableLimit(Parameter[1].nLong,bOnOff);
                              /*~A:1771*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              lText2Send = TEXT_LIMIT_STATE_CLEARED_CHANNEL_0;
                              /*~E:A1771*/
                              /*~-1*/
#endif
                              /*~E:I1770*/
                              /*~E:A1769*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1768*/
                              /*~F:1772*/
                              case 1:
                              /*~-1*/
                              {
                              /*~A:1773*/
                              /*~+:Kanal 1*/
                              /*~I:1774*/
#ifdef CHANNEL_1
                              /*~T*/
                              ADuC836_DACEnableLimit(Parameter[1].nLong,bOnOff);
                              /*~A:1775*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              lText2Send = TEXT_LIMIT_STATE_CLEARED_CHANNEL_1;
                              /*~E:A1775*/
                              /*~-1*/
#endif
                              /*~E:I1774*/
                              /*~E:A1773*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1772*/
                              /*~O:C1767*/
                              /*~-2*/
                              default:
                              {
                              /*~A:1776*/
                              /*~+:Kanal 0*/
                              /*~I:1777*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I1777*/
                              /*~E:A1776*/
                              /*~-1*/
                              }
                           /*~-1*/
                           }
                           /*~E:C1767*/
                        /*~-1*/
                        }
                        /*~O:I1766*/
                        /*~-2*/
                        else
                        {
                           /*~A:1778*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1778*/
                        /*~-1*/
                        }
                        /*~E:I1766*/
                     /*~-1*/
                     }
                     /*~E:I1763*/
                     /*~E:A1762*/
                     /*~I:1779*/
#ifdef MOF
                     /*~A:1780*/
                     /*~+:SMF - SetMotionFilter*/
                     /*~I:1781*/
                     if ((!strcmp(szCommand,"SMF"))||(!strcmp(szCommand,"SMT")))
                     /*~-1*/
                     {
                        /*~A:1782*/
                        /*~+:Variablendeklarationen*/
                        /*~T*/
                        MEASUREMENT_MOTIONPARAMETER MotionParameter;
                        /*~E:A1782*/
                        /*~A:1783*/
                        /*~+:Variableninitialisierungen*/
                        /*~T*/

                        /*~E:A1783*/
                        /*~T*/
                        // Text wurde bereits gesendet
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;

                        /*~I:1784*/
                        if (!InstructionDecoder_CheckNbParameters(2,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           // Parameter auslesen
                           Parameter[0].nLong = Communication_GetLongParameter(0);
                           Parameter[1].nLong = Communication_GetLongParameter(1);

                           // Motionparameter auslesen
                           Weight_GetMotionParameter(&MotionParameter);
                           /*~I:1785*/
                           if (!GET_RESPONSE)
                           /*~-1*/
                           {
                              /*~T*/
                              // Alles okay
                              /*~I:1786*/
                              if (!Parameter[0].nLong)
                              /*~-1*/
                              {
                              /*~T*/
                              // Motion-Parameter setzen
                              MotionParameter.byMotionFilter = (unsigned char)Parameter[1].nLong;
                              /*~A:1787*/
                              /*~+:Kanal 0 - Textausgabe*/
                              /*~I:1788*/
#ifdef CHANNEL_0
                              /*~A:1789*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              lText2Send = TEXT_MEASUREMENT_MOTIONFILTER_SET;
                              /*~E:A1789*/
                              /*~-1*/
#endif
                              /*~E:I1788*/
                              /*~E:A1787*/
                              /*~-1*/
                              }
                              /*~O:I1786*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              // No-Motion-Parameter setzen
                              MotionParameter.byNoMotionFilter = (unsigned char)Parameter[1].nLong;
                              /*~A:1790*/
                              /*~+:Kanal 0 - Textausgabe*/
                              /*~I:1791*/
#ifdef CHANNEL_0
                              /*~A:1792*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              lText2Send = TEXT_MEASUREMENT_NOMOTIONFILTER_SET;
                              /*~E:A1792*/
                              /*~-1*/
#endif
                              /*~E:I1791*/
                              /*~E:A1790*/
                              /*~-1*/
                              }
                              /*~E:I1786*/
                              /*~A:1793*/
                              /*~+:Ausf�hrungsstatus auf 'OKAY' setzen*/
                              /*~+:*/
                              /*~T*/
                              // Ausf�hrungsstatus auf 'OKAY' setzen
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              /*~E:A1793*/
                              /*~T*/
                              Weight_SetMotionParameter(MotionParameter,1);

                           /*~-1*/
                           }
                           /*~O:I1785*/
                           /*~-2*/
                           else
                           {
                              /*~K*/
                              /*~+:Fehler !!!*/
                              /*~A:1794*/
                              /*~+:Ausf�hrungsstatus auf 'E005' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A1794*/
                           /*~-1*/
                           }
                           /*~E:I1785*/
                        /*~-1*/
                        }
                        /*~O:I1784*/
                        /*~-2*/
                        else
                        {
                           /*~A:1795*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1795*/
                        /*~-1*/
                        }
                        /*~E:I1784*/
                     /*~-1*/
                     }
                     /*~E:I1781*/
                     /*~E:A1780*/
                     /*~-1*/
#endif
                     /*~E:I1779*/
                     /*~A:1796*/
                     /*~+:SML - SetMotionLimit*/
                     /*~I:1797*/
                     if (!strcmp(szCommand,"SML"))
                     /*~-1*/
                     {
                        /*~A:1798*/
                        /*~+:Variablendeklarationen*/
                        /*~T*/
                        MEASUREMENT_MOTIONPARAMETER MotionParameter;
                        /*~E:A1798*/
                        /*~A:1799*/
                        /*~+:Variableninitialisierungen*/
                        /*~T*/

                        /*~E:A1799*/
                        /*~T*/
                        // Text wurde bereits gesendet
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;

                        /*~I:1800*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           // Parameter auslesen
                           Parameter[0].fFloat = Communication_GetFloatParameter(0);

                           // Motionparameter auslesen
                           Weight_GetMotionParameter(&MotionParameter);
                           /*~I:1801*/
                           if (!GET_RESPONSE)
                           /*~-1*/
                           {
                              /*~T*/
                              // Alles okay
                              /*~T*/
                              // Motion-Parameter setzen
                              MotionParameter.fMotionLimit = Parameter[0].fFloat;

                              Weight_SetMotionParameter(MotionParameter,1);

                              /*~A:1802*/
                              /*~+:Ausf�hrungsstatus auf 'OKAY' setzen*/
                              /*~+:*/
                              /*~T*/
                              // Ausf�hrungsstatus auf 'OKAY' setzen
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              /*~E:A1802*/
                              /*~A:1803*/
                              /*~+:Kanal 0 - Textausgabe*/
                              /*~I:1804*/
#ifdef CHANNEL_0
                              /*~A:1805*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              lText2Send = TEXT_MEASUREMENT_MOTIONFILTER_SET;
                              /*~E:A1805*/
                              /*~-1*/
#endif
                              /*~E:I1804*/
                              /*~E:A1803*/
                           /*~-1*/
                           }
                           /*~O:I1801*/
                           /*~-2*/
                           else
                           {
                              /*~K*/
                              /*~+:Fehler !!!*/
                              /*~A:1806*/
                              /*~+:Ausf�hrungsstatus auf 'E005' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A1806*/
                           /*~-1*/
                           }
                           /*~E:I1801*/
                        /*~-1*/
                        }
                        /*~O:I1800*/
                        /*~-2*/
                        else
                        {
                           /*~A:1807*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1807*/
                        /*~-1*/
                        }
                        /*~E:I1800*/
                     /*~-1*/
                     }
                     /*~E:I1797*/
                     /*~E:A1796*/
                     /*~A:1808*/
                     /*~+:SMT - SetMotionTimer*/
                     /*~I:1809*/
                     if (!strcmp(szCommand,"SMT"))
                     /*~-1*/
                     {
                        /*~A:1810*/
                        /*~+:Variablendeklarationen*/
                        /*~T*/
                        MEASUREMENT_MOTIONPARAMETER MotionParameter;
                        /*~E:A1810*/
                        /*~A:1811*/
                        /*~+:Variableninitialisierungen*/
                        /*~T*/

                        /*~E:A1811*/
                        /*~T*/
                        // Text wurde bereits gesendet
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;

                        /*~I:1812*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           // Parameter auslesen
                           Parameter[0].nLong = Communication_GetLongParameter(0);

                           // Motionparameter auslesen
                           Weight_GetMotionParameter(&MotionParameter);
                           /*~I:1813*/
                           if (!GET_RESPONSE)
                           /*~-1*/
                           {
                              /*~T*/
                              // Alles okay
                              /*~T*/
                              // Motion-Parameter setzen
                              MotionParameter.byMotionFilter = (unsigned char)Parameter[0].nLong;
                              /*~A:1814*/
                              /*~+:Kanal 0 - Textausgabe*/
                              /*~I:1815*/
#ifdef CHANNEL_0
                              /*~A:1816*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              lText2Send = TEXT_MEASUREMENT_MOTIONTIMER_SET;
                              /*~E:A1816*/
                              /*~-1*/
#endif
                              /*~E:I1815*/
                              /*~E:A1814*/
                              /*~A:1817*/
                              /*~+:Ausf�hrungsstatus auf 'OKAY' setzen*/
                              /*~+:*/
                              /*~T*/
                              // Ausf�hrungsstatus auf 'OKAY' setzen
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              /*~E:A1817*/
                              /*~T*/
                              Weight_SetMotionParameter(MotionParameter,1);

                           /*~-1*/
                           }
                           /*~O:I1813*/
                           /*~-2*/
                           else
                           {
                              /*~K*/
                              /*~+:Fehler !!!*/
                              /*~A:1818*/
                              /*~+:Ausf�hrungsstatus auf 'E005' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A1818*/
                           /*~-1*/
                           }
                           /*~E:I1813*/
                        /*~-1*/
                        }
                        /*~O:I1812*/
                        /*~-2*/
                        else
                        {
                           /*~A:1819*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1819*/
                        /*~-1*/
                        }
                        /*~E:I1812*/
                     /*~-1*/
                     }
                     /*~E:I1809*/
                     /*~E:A1808*/
                     /*~I:1820*/
#ifdef MIT_EINSTELLBARER_MESSWERTTIEFE
                     /*~A:1821*/
                     /*~+:SNM - SetNumberofMeasurements*/
                     /*~I:1822*/
                     if (!strcmp(szCommand,"SNM"))
                     /*~-1*/
                     {
                        /*~A:1823*/
                        /*~+:Variablendeklarationen*/
                        /*~T*/
                        unsigned char byMeasurementDepth;
                        /*~E:A1823*/
                        /*~A:1824*/
                        /*~+:Variableninitialisierungen*/
                        /*~T*/

                        /*~E:A1824*/
                        /*~T*/
                        // Text wurde bereits gesendet
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;

                        /*~I:1825*/
                        if (!InstructionDecoder_CheckNbParameters(2,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           // Parameter auslesen
                           Parameter[0].nLong = Communication_GetLongParameter(0);
                           Parameter[1].nLong = Communication_GetLongParameter(1);

                           byMeasurementDepth = (unsigned char)Parameter[1].nLong;
                           /*~I:1826*/
                           if (!GET_RESPONSE)
                           /*~-1*/
                           {
                              /*~T*/
                              // Alles okay
                              /*~I:1827*/
                              if (byMeasurementDepth)
                              /*~-1*/
                              {
                              /*~C:1828*/
                              switch (Parameter[0].nLong)
                              /*~-1*/
                              {
                              /*~F:1829*/
                              case 0: // Messwerttiefe f�r Gewichtswert
                              /*~-1*/
                              {
                              /*~I:1830*/
                              if (byMeasurementDepth > 0)
                              /*~-1*/
                              {
                              /*~A:1831*/
                              /*~+:Messwerttiefe setzen*/
                              /*~T*/
                              // Messwerttiefe setzen
                              ADuC836_ADCSetMeasurementDepth(ADuC836_ADC_PRIMARY,byMeasurementDepth);
                              /*~E:A1831*/
                              /*~A:1832*/
                              /*~+:und speichern*/
                              /*~T*/
                              // und speichern
                              Save_Parameter(LOAD_SAVE_WEIGHT_MEASUREMENT_DEPTH,&byMeasurementDepth,1);
                              /*~E:A1832*/
                              /*~A:1833*/
                              /*~+:Eintrag in Diagnosespeicher vornehmen*/
                              /*~T*/
                              ulDiagnosisEntry2Set = DIAGNOSIS_MESSAGE_MEASUREMENT_DEPTH_RMW_SET;
                              /*~E:A1833*/
                              /*~A:1834*/
                              /*~+:Ausf�hrungsstatus auf 'OKAY' setzen*/
                              /*~+:*/
                              /*~T*/
                              // Ausf�hrungsstatus auf 'OKAY' setzen
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              /*~E:A1834*/
                              /*~A:1835*/
                              /*~+:Kanal 0 - Textausgabe*/
                              /*~I:1836*/
#ifdef CHANNEL_0
                              /*~A:1837*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              lText2Send = TEXT_MEASUREMENT_DEPTH_RMW_SET;
                              /*~E:A1837*/
                              /*~-1*/
#endif
                              /*~E:I1836*/
                              /*~E:A1835*/
                              /*~-1*/
                              }
                              /*~O:I1830*/
                              /*~-2*/
                              else
                              {
                              /*~A:1838*/
                              /*~+:Ausf�hrungsstatus auf 'E002' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E002;
                              /*~E:A1838*/
                              /*~-1*/
                              }
                              /*~E:I1830*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1829*/
                              /*~I:1839*/
#ifndef OHNE_STROMRUECKFUEHRUNG 
                              /*~F:1840*/
                              case 1:	// Messwerttiefe f�r Stromr�ckf�hrung
                              /*~-1*/
                              {
                              /*~I:1841*/
                              if (byMeasurementDepth > 0)
                              /*~-1*/
                              {
                              /*~A:1842*/
                              /*~+:Messwerttiefe setzen*/
                              /*~T*/
                              // Messwerttiefe setzen
                              ADuC836_ADCSetMeasurementDepth(ADuC836_ADC_PRIMARY_TOGGLE,byMeasurementDepth);

                              /*~E:A1842*/
                              /*~A:1843*/
                              /*~+:und speichern*/
                              /*~T*/
                              // und speichern
                              Save_Parameter(LOAD_SAVE_MEASUREMENT_DEPTH_FEEDBACK,&byMeasurementDepth,1);
                              /*~E:A1843*/
                              /*~A:1844*/
                              /*~+:Eintrag in Diagnosespeicher vornehmen*/
                              /*~T*/
                              ulDiagnosisEntry2Set = DIAGNOSIS_MESSAGE_MEASUREMENT_DEPTH_CURRENT_SET;
                              /*~E:A1844*/
                              /*~A:1845*/
                              /*~+:Ausf�hrungsstatus auf 'OKAY' setzen*/
                              /*~+:*/
                              /*~T*/
                              // Ausf�hrungsstatus auf 'OKAY' setzen
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              /*~E:A1845*/
                              /*~A:1846*/
                              /*~+:Kanal 0 - Textausgabe*/
                              /*~I:1847*/
#ifdef CHANNEL_0
                              /*~A:1848*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              lText2Send = TEXT_MEASUREMENT_DEPTH_FEEDBACK_SET;
                              /*~E:A1848*/
                              /*~-1*/
#endif
                              /*~E:I1847*/
                              /*~E:A1846*/
                              /*~-1*/
                              }
                              /*~O:I1841*/
                              /*~-2*/
                              else
                              {
                              /*~A:1849*/
                              /*~+:Ausf�hrungsstatus auf 'E002' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E002;
                              /*~E:A1849*/
                              /*~-1*/
                              }
                              /*~E:I1841*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1840*/
                              /*~-1*/
#endif
                              /*~E:I1839*/
                              /*~O:C1828*/
                              /*~-2*/
                              default:
                              {
                              /*~A:1850*/
                              /*~+:Ausf�hrungsstatus auf 'E002' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E002;
                              /*~E:A1850*/
                              /*~-1*/
                              }
                              /*~-1*/
                              }
                              /*~E:C1828*/
                              /*~-1*/
                              }
                              /*~O:I1827*/
                              /*~-2*/
                              else
                              {
                              /*~A:1851*/
                              /*~+:Ausf�hrungsstatus auf 'E002' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E002;
                              /*~E:A1851*/
                              /*~-1*/
                              }
                              /*~E:I1827*/
                           /*~-1*/
                           }
                           /*~O:I1826*/
                           /*~-2*/
                           else
                           {
                              /*~K*/
                              /*~+:Fehler !!!*/
                              /*~A:1852*/
                              /*~+:Ausf�hrungsstatus auf 'E005' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A1852*/
                           /*~-1*/
                           }
                           /*~E:I1826*/
                        /*~-1*/
                        }
                        /*~O:I1825*/
                        /*~-2*/
                        else
                        {
                           /*~A:1853*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1853*/
                        /*~-1*/
                        }
                        /*~E:I1825*/
                     /*~-1*/
                     }
                     /*~E:I1822*/
                     /*~E:A1821*/
                     /*~-1*/
#endif
                     /*~E:I1820*/
                     /*~I:1854*/
#ifdef DEVELOPMENT_SW
                     /*~A:1855*/
                     /*~+:SSC - SetSpiCheck*/
                     /*~I:1856*/
                     if (!strcmp(szCommand,"SSC"))
                     /*~-1*/
                     {
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;

                        /*~I:1857*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           // Parameter auslesen
                           Parameter[0].nLong = Communication_GetLongParameter(0);
                           /*~I:1858*/
                           if (Parameter[0].nLong)
                           /*~-1*/
                           {
                              /*~T*/
                              // SPI-Test einschalten
                              CommunicationControl.bTestSPI = 1;


                              /*~I:1859*/
#ifdef CHANNEL_0
                              /*~T*/
                              CommunicationControl.ulSPIE1CounterLast = -1; 
                              /*~-1*/
#endif
                              /*~E:I1859*/
                              /*~A:1860*/
                              /*~+:Kanal 0 - Textausgabe*/
                              /*~I:1861*/
#ifdef CHANNEL_0
                              /*~A:1862*/
                              /*~+:Ausf�hrungsstatus auf 'OKAY' setzen*/
                              /*~T*/
                              // Ausf�hrungsstatus auf 'OKAY' setzen
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              /*~E:A1862*/
                              /*~T*/
                              lText2Send = TEXT_SYSTEM_SPI_CHECK_ON;
                              /*~-1*/
#endif
                              /*~E:I1861*/
                              /*~E:A1860*/
                           /*~-1*/
                           }
                           /*~O:I1858*/
                           /*~-2*/
                           else
                           {
                              /*~T*/
                              // SPI-Test einschalten
                              CommunicationControl.bTestSPI = 0; 
                              /*~A:1863*/
                              /*~+:Kanal 0 - Textausgabe*/
                              /*~I:1864*/
#ifdef CHANNEL_0
                              /*~A:1865*/
                              /*~+:Ausf�hrungsstatus auf 'OKAY' setzen*/
                              /*~T*/
                              // Ausf�hrungsstatus auf 'OKAY' setzen
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              /*~E:A1865*/
                              /*~T*/
                              lText2Send = TEXT_SYSTEM_SPI_CHECK_OFF;
                              /*~-1*/
#endif
                              /*~E:I1864*/
                              /*~E:A1863*/
                           /*~-1*/
                           }
                           /*~E:I1858*/
                        /*~-1*/
                        }
                        /*~O:I1857*/
                        /*~-2*/
                        else
                        {
                           /*~A:1866*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1866*/
                        /*~-1*/
                        }
                        /*~E:I1857*/
                     /*~-1*/
                     }
                     /*~E:I1856*/
                     /*~E:A1855*/
                     /*~-1*/
#endif
                     /*~E:I1854*/
                     /*~A:1867*/
                     /*~+:SSN - SetSerialNumber*/
                     /*~I:1868*/
                     if (!strcmp(szCommand,"SSN"))
                     /*~-1*/
                     {
                        /*~A:1869*/
                        /*~+:Variablendeklarationen*/
                        /*~T*/
                        char *szSerialNumber;
                        /*~E:A1869*/
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;

                        /*~I:1870*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           szSerialNumber = Communication_GetStringParameter(0);

                           /*~I:1871*/
                           if (!System_SetSerialNumber(szSerialNumber))
                           /*~-1*/
                           {
                              /*~A:1872*/
                              /*~+:Kanal 0 - Textausgabe*/
                              /*~I:1873*/
#ifdef CHANNEL_0 
                              /*~A:1874*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              lText2Send = TEXT_SERAIL_NUMBER_SET;
                              /*~E:A1874*/
                              /*~-1*/
#endif
                              /*~E:I1873*/
                              /*~E:A1872*/
                           /*~-1*/
                           }
                           /*~O:I1871*/
                           /*~-2*/
                           else
                           {
                              /*~K*/
                              /*~+:Fehler !!!*/
                              /*~I:1875*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~-1*/
#endif
                              /*~E:I1875*/
                           /*~-1*/
                           }
                           /*~E:I1871*/
                        /*~-1*/
                        }
                        /*~O:I1870*/
                        /*~-2*/
                        else
                        {
                           /*~A:1876*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1876*/
                        /*~-1*/
                        }
                        /*~E:I1870*/
                     /*~-1*/
                     }
                     /*~E:I1868*/
                     /*~E:A1867*/
                     /*~A:1877*/
                     /*~+:SSP - SetStatisticsdataParameter*/
                     /*~I:1878*/
                     if (!strcmp(szCommand,"SSP"))
                     /*~-1*/
                     {
                        /*~A:1879*/
                        /*~+:Variablendeklarationen*/
                        /*~T*/
                        STATISTICSLIBRARY_SETUP StatisticsSetup;
                        float fLimit;
                        /*~E:A1879*/
                        /*~A:1880*/
                        /*~+:Variableninitialisierungen*/
                        /*~T*/

                        /*~E:A1880*/
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;

                        /*~I:1881*/
                        if (!InstructionDecoder_CheckNbParameters(2,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           // Parameter auslesen
                           Parameter[0].nLong = Communication_GetLongParameter(0);
                           Parameter[1].nLong = Communication_GetLongParameter(1);
                           fLimit = Communication_GetFloatParameter(1); 
                           /*~I:1882*/
                           if (!GET_RESPONSE)
                           /*~-1*/
                           {
                              /*~K*/
                              /*~+:// Alles okay*/
                              /*~T*/
                              // die aktuellen Parameter einlesen
                              StatisticsSetup = Statistics_GetSetup();
                              /*~A:1883*/
                              /*~+:Ausf�hrungsstatus auf 'OKAY' setzen*/
                              /*~+:*/
                              /*~T*/
                              // Ausf�hrungsstatus auf 'OKAY' setzen
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              /*~E:A1883*/
                              /*~C:1884*/
                              switch (Parameter[0].nLong)
                              /*~-1*/
                              {
                              /*~F:1885*/
                              case 0:	// Filter Temperatur�berwachung
                              /*~-1*/
                              {
                              /*~T*/
                              StatisticsSetup.chFilterCheckTemperature = (unsigned char)Parameter[1].nLong;
                              /*~A:1886*/
                              /*~+:Text f�r Terminalbetrieb - 2.Teil*/
                              /*~I:1887*/
#ifdef CHANNEL_0
                              /*~T*/
                              lText2Send = TEXT_STATISTICS_FILTER_TEMPERATURE_SET;
                              /*~-1*/
#endif
                              /*~E:I1887*/
                              /*~E:A1886*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1885*/
                              /*~F:1888*/
                              case 1:	// Filter Gewichts�berwachung
                              /*~-1*/
                              {
                              /*~T*/
                              StatisticsSetup.chFilterCheckWeight = (unsigned char)Parameter[1].nLong;
                              /*~A:1889*/
                              /*~+:Text f�r Terminalbetrieb - 2.Teil*/
                              /*~I:1890*/
#ifdef CHANNEL_0
                              /*~T*/
                              lText2Send = TEXT_STATISTICS_FILTER_WEIGHT_SET;
                              /*~-1*/
#endif
                              /*~E:I1890*/
                              /*~E:A1889*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1888*/
                              /*~F:1891*/
                              case 2:	// MotionLimit Gewichts�berwachung
                              /*~-1*/
                              {
                              /*~T*/
                              // StatisticsSetup.fMotionLimitCheckWeight = Parameter[2].fFloat;
                              StatisticsSetup.fMotionLimitCheckWeight = fLimit;
                              /*~A:1892*/
                              /*~+:Text f�r Terminalbetrieb - 2.Teil*/
                              /*~I:1893*/
#ifdef CHANNEL_0
                              /*~T*/
                              lText2Send = TEXT_STATISTICS_MOTIONLIMIT_WEIGHT_SET;
                              /*~-1*/
#endif
                              /*~E:I1893*/
                              /*~E:A1892*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1891*/
                              /*~F:1894*/
                              case 3:	// Filter Grenzwert�berschreitung und �berlast
                              /*~-1*/
                              {
                              /*~T*/
                              StatisticsSetup.chFilterOverLimit = (unsigned char)Parameter[1].nLong;
                              /*~A:1895*/
                              /*~+:Text f�r Terminalbetrieb - 2.Teil*/
                              /*~I:1896*/
#ifdef CHANNEL_0
                              /*~T*/
                              lText2Send = TEXT_STATISTICS_FILTER_OVERLIMIT_SET;
                              /*~-1*/
#endif
                              /*~E:I1896*/
                              /*~E:A1895*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1894*/
                              /*~F:1897*/
                              case 4:	// Grenzwert
                              /*~-1*/
                              {
                              /*~T*/
                              StatisticsSetup.fLimitOverLimit = fLimit;
                              /*~A:1898*/
                              /*~+: Text f�r Terminalbetrieb - 2.Teil*/
                              /*~I:1899*/
#ifdef CHANNEL_0
                              /*~T*/
                              lText2Send = TEXT_STATISTICS_LIMIT_OVERLIMIT_SET;
                              /*~-1*/
#endif
                              /*~E:I1899*/
                              /*~E:A1898*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1897*/
                              /*~O:C1884*/
                              /*~-2*/
                              default:
                              {
                              /*~K*/
                              /*~+:Fehler !!!*/
                              /*~A:1900*/
                              /*~+:Ausf�hrungsstatus auf 'E001' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~E:A1900*/
                              /*~-1*/
                              }
                              /*~-1*/
                              }
                              /*~E:C1884*/
                              /*~T*/
                              // Werte �bertragen
                              Statistics_SetSetup(StatisticsSetup);
                           /*~-1*/
                           }
                           /*~O:I1882*/
                           /*~-2*/
                           else
                           {
                              /*~K*/
                              /*~+:Fehler !!!*/
                              /*~A:1901*/
                              /*~+:Ausf�hrungsstatus auf 'E005' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A1901*/
                           /*~-1*/
                           }
                           /*~E:I1882*/
                        /*~-1*/
                        }
                        /*~O:I1881*/
                        /*~-2*/
                        else
                        {
                           /*~A:1902*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1902*/
                        /*~-1*/
                        }
                        /*~E:I1881*/
                     /*~-1*/
                     }
                     /*~E:I1878*/
                     /*~E:A1877*/
                     /*~A:1903*/
                     /*~+:SSS - SetSystemState*/
                     /*~I:1904*/
                     if (!strcmp(szCommand,"SSS"))
                     /*~-1*/
                     {
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;

                        /*~I:1905*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           // Parameter auslesen
                           Parameter[0].nLong = Communication_GetLongParameter(0);
                           /*~I:1906*/
                           if (!GET_RESPONSE)
                           /*~-1*/
                           {
                              /*~K*/
                              /*~+:// Acknowledge empfangen - Alles okay*/
                              /*~I:1907*/
                              if (Parameter[0].nLong)
                              /*~-1*/
                              {
                              /*~T*/
                              // Betriebszustand manuell setzen
                              System_SetSystemState(Parameter[0].nLong);

                              Global.Mode.bySetStateManualy = 1; 
                              /*~-1*/
                              }
                              /*~O:I1907*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              // Wieder zum normalen Betrieb �bergehen
                              System_SetSystemState(SYSTEM_RUNNING);

                              Global.Mode.bySetStateManualy = 0; 
                              /*~-1*/
                              }
                              /*~E:I1907*/
                              /*~A:1908*/
                              /*~+:Ausf�hrungsstatus auf 'OKAY' setzen*/
                              /*~+:*/
                              /*~T*/
                              // Ausf�hrungsstatus auf 'OKAY' setzen
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              /*~E:A1908*/
                              /*~A:1909*/
                              /*~+:Kanal 0 - Textausgabe*/
                              /*~I:1910*/
#ifdef CHANNEL_0
                              /*~C:1911*/
                              switch (Parameter[0].nLong)
                              /*~-1*/
                              {
                              /*~A:1912*/
                              /*~+:SYSTEM_RUNNING*/
                              /*~F:1913*/
                              case 0:
                              case SYSTEM_RUNNING:
                              /*~-1*/
                              {
                              /*~T*/
                              lText2Send = TEXT_SYSTEM_STATE_SET_2_RUNNING;
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1913*/
                              /*~E:A1912*/
                              /*~A:1914*/
                              /*~+:SYSTEM_REC_CHARACTERISTICS_ON*/
                              /*~F:1915*/
                              case SYSTEM_REC_CHARACTERISTICS_ON:
                              /*~-1*/
                              {
                              /*~T*/
                              lText2Send = TEXT_SYSTEM_STATE_SET_2_REC_CHARACTERISTICS;
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1915*/
                              /*~E:A1914*/
                              /*~A:1916*/
                              /*~+:SYSTEM_REC_CHARACTERISTICS_1ST_DRIFT*/
                              /*~F:1917*/
                              case SYSTEM_REC_CHARACTERISTICS_1ST_DRIFT:
                              /*~-1*/
                              {
                              /*~T*/
                              lText2Send = TEXT_SYSTEM_STATE_SET_2_FIRST_DRIFT_VALUE_DETERMINED;
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1917*/
                              /*~E:A1916*/
                              /*~A:1918*/
                              /*~+:SYSTEM_REC_CHARACTERISTICS_OKAY*/
                              /*~F:1919*/
                              case SYSTEM_REC_CHARACTERISTICS_OKAY:
                              /*~-1*/
                              {
                              /*~T*/
                              lText2Send = TEXT_SYSTEM_STATE_SET_2_REC_CHARACTERISTICS_FINISHED_SUCCESSFUL;
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1919*/
                              /*~E:A1918*/
                              /*~A:1920*/
                              /*~+:SYSTEM_REC_CHARACTERISTICS_ERROR*/
                              /*~F:1921*/
                              case SYSTEM_REC_CHARACTERISTICS_ERROR:
                              /*~-1*/
                              {
                              /*~T*/
                              lText2Send = TEXT_SYSTEM_STATE_SET_2_REC_CHARACTERISTICS_FINISHED_WITH_ERROR;
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1921*/
                              /*~E:A1920*/
                              /*~A:1922*/
                              /*~+:SYSTEM_ERROR*/
                              /*~F:1923*/
                              case SYSTEM_ERROR:
                              /*~-1*/
                              {
                              /*~T*/
                              lText2Send = TEXT_SYSTEM_STATE_SET_2_SYSTEM_ERROR;
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1923*/
                              /*~E:A1922*/
                              /*~O:C1911*/
                              /*~-2*/
                              default:
                              {
                              /*~K*/
                              /*~+:Fehler !!!*/
                              /*~I:1924*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E002;
                              /*~-1*/
#endif
                              /*~E:I1924*/
                              /*~-1*/
                              }
                              /*~-1*/
                              }
                              /*~E:C1911*/
                              /*~-1*/
#endif
                              /*~E:I1910*/
                              /*~E:A1909*/
                           /*~-1*/
                           }
                           /*~O:I1906*/
                           /*~-2*/
                           else
                           {
                              /*~K*/
                              /*~+:Fehler !!!*/
                              /*~A:1925*/
                              /*~+:Ausf�hrungsstatus auf 'E005' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A1925*/
                           /*~-1*/
                           }
                           /*~E:I1906*/
                        /*~-1*/
                        }
                        /*~O:I1905*/
                        /*~-2*/
                        else
                        {
                           /*~A:1926*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1926*/
                        /*~-1*/
                        }
                        /*~E:I1905*/
                     /*~-1*/
                     }
                     /*~E:I1904*/
                     /*~E:A1903*/
                     /*~A:1927*/
                     /*~+:SST - SetSimulatedTemperature*/
                     /*~I:1928*/
                     if (!strcmp(szCommand,"SST"))
                     /*~-1*/
                     {
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;

                        /*~I:1929*/
                        if (!InstructionDecoder_CheckNbParameters(2,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           // Parameter auslesen
                           Parameter[0].nLong = Communication_GetLongParameter(0);
                           Parameter[1].fFloat = Communication_GetFloatParameter(1);
                           /*~C:1930*/
                           switch (Parameter[0].nLong)
                           /*~-1*/
                           {
                              /*~F:1931*/
                              case 0:
                              /*~-1*/
                              {
                              /*~A:1932*/
                              /*~+:Kanal 0*/
                              /*~I:1933*/
#ifdef CHANNEL_0
                              /*~I:1934*/
                              if ((Parameter[1].fFloat >= -100)&&(Parameter[1].fFloat <= 100))
                              /*~-1*/
                              {
                              /*~T*/
                              g_SystemControl.bySimulate |= 0x02;
                              /*~T*/
                              // simulierte Temperatur setzen
                              Global.bySimulatedTemperature = (char)Parameter[1].fFloat;
                              /*~A:1935*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              lText2Send = TEXT_SIMULATED_TEMPERATURE_SET_CHANNEL_0;
                              /*~E:A1935*/
                              /*~-1*/
                              }
                              /*~O:I1934*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              g_SystemControl.bySimulate &= 0xFD;
                              /*~A:1936*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              lText2Send = lText2Send = TEXT_TEMPERATURE_SIMULATION_CHANCELD_CHANNEL_0;
                              /*~E:A1936*/
                              /*~-1*/
                              }
                              /*~E:I1934*/
                              /*~-1*/
#endif
                              /*~E:I1933*/
                              /*~E:A1932*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1931*/
                              /*~F:1937*/
                              case 1:
                              /*~-1*/
                              {
                              /*~A:1938*/
                              /*~+:Kanal 1*/
                              /*~I:1939*/
#ifdef CHANNEL_1
                              /*~I:1940*/
                              if ((Parameter[1].fFloat >= -100)&&(Parameter[1].fFloat <= 100))
                              /*~-1*/
                              {
                              /*~T*/
                              g_SystemControl.bySimulate |= 0x02;
                              /*~T*/
                              // simulierte Temperatur setzen
                              Global.bySimulatedTemperature = (char)Parameter[1].fFloat;
                              /*~A:1941*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              lText2Send = TEXT_SIMULATED_TEMPERATURE_SET_CHANNEL_1;
                              /*~E:A1941*/
                              /*~-1*/
                              }
                              /*~O:I1940*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              g_SystemControl.bySimulate &= 0xFD;
                              /*~A:1942*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              lText2Send = lText2Send = TEXT_TEMPERATURE_SIMULATION_CHANCELD_CHANNEL_1;
                              /*~E:A1942*/
                              /*~-1*/
                              }
                              /*~E:I1940*/
                              /*~-1*/
#endif
                              /*~E:I1939*/
                              /*~E:A1938*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1937*/
                              /*~O:C1930*/
                              /*~-2*/
                              default:
                              {
                              /*~A:1943*/
                              /*~+:Kanal 0*/
                              /*~I:1944*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I1944*/
                              /*~E:A1943*/
                              /*~-1*/
                              }
                           /*~-1*/
                           }
                           /*~E:C1930*/
                        /*~-1*/
                        }
                        /*~O:I1929*/
                        /*~-2*/
                        else
                        {
                           /*~A:1945*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1945*/
                        /*~-1*/
                        }
                        /*~E:I1929*/
                     /*~-1*/
                     }
                     /*~E:I1928*/
                     /*~E:A1927*/
                     /*~A:1946*/
                     /*~+:STA - SetTaretoActualweight*/
                     /*~K*/
                     /*~+:STA - identisch mit TET (TEachTare)*/
                     /*~E:A1946*/
                     /*~A:1947*/
                     /*~+:STH - SetTimeHysteresis*/
                     /*~I:1948*/
                     if (!strcmp(szCommand,"STH"))
                     /*~-1*/
                     {
                        /*~T*/
                        // Text wurde bereits gesendet
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;

                        /*~I:1949*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~I:1950*/
                           if (!GET_RESPONSE)
                           /*~-1*/
                           {
                              /*~T*/
                              // Parameter auslesen
                              Parameter[0].nLong = Communication_GetLongParameter(0);

                              /*~I:1951*/
                              if (Parameter[0].nLong <= 30)	// maximal 30 Sekunden
                              /*~-1*/
                              {
                              /*~T*/
                              CurrentInterface_SetTimeHysteresis(Parameter[0].nLong);
                              /*~A:1952*/
                              /*~+:Ausf�hrungsstatus auf 'OKAY' setzen*/
                              /*~+:*/
                              /*~T*/
                              // Ausf�hrungsstatus auf 'OKAY' setzen
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              /*~E:A1952*/
                              /*~A:1953*/
                              /*~+:Kanal 0 - Textausgabe*/
                              /*~I:1954*/
#ifdef CHANNEL_0
                              /*~A:1955*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              lText2Send = TEXT_CURRENT_INTERFACE_SET_TIME_HYSTERESIS;
                              /*~E:A1955*/
                              /*~-1*/
#endif
                              /*~E:I1954*/
                              /*~E:A1953*/
                              /*~-1*/
                              }
                              /*~O:I1951*/
                              /*~-2*/
                              else
                              {
                              /*~K*/
                              /*~+:Fehler !!!*/
                              /*~A:1956*/
                              /*~+:Ausf�hrungsstatus auf 'E002' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E002;
                              /*~E:A1956*/
                              /*~-1*/
                              }
                              /*~E:I1951*/
                           /*~-1*/
                           }
                           /*~O:I1950*/
                           /*~-2*/
                           else
                           {
                              /*~K*/
                              /*~+:Fehler !!!*/
                              /*~A:1957*/
                              /*~+:Ausf�hrungsstatus auf 'E005' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A1957*/
                           /*~-1*/
                           }
                           /*~E:I1950*/
                        /*~-1*/
                        }
                        /*~O:I1949*/
                        /*~-2*/
                        else
                        {
                           /*~A:1958*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1958*/
                        /*~-1*/
                        }
                        /*~E:I1949*/
                     /*~-1*/
                     }
                     /*~E:I1948*/
                     /*~E:A1947*/
                     /*~A:1959*/
                     /*~+:STO - SetTemperatureOffset*/
                     /*~I:1960*/
                     if (!strcmp(szCommand,"STO"))
                     /*~-1*/
                     {
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;

                        /*~I:1961*/
                        if (!InstructionDecoder_CheckNbParameters(2,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           // Parameter auslesen
                           Parameter[0].nLong = Communication_GetLongParameter(0);
                           Parameter[1].nLong = Communication_GetLongParameter(1);
                           /*~C:1962*/
                           switch (Parameter[0].nLong)
                           /*~-1*/
                           {
                              /*~F:1963*/
                              case 0:	// Temperaturoffset des Kanal 0 setzen
                              /*~-1*/
                              {
                              /*~A:1964*/
                              /*~+:Kanal 0*/
                              /*~I:1965*/
#ifdef CHANNEL_0
                              /*~T*/
                              // Temperaturoffset setzen und speichern
                              Analog_SetTemperatureOffset((char)Parameter[1].nLong,ANALOG_TEMPERATURE_CALIBRATION_SET_OFFSET_MANUALY); 
                              /*~A:1966*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              lText2Send = TEXT_TEMPERATURE_OFFSET_SET_CHANNEL_0;
                              /*~E:A1966*/
                              /*~-1*/
#endif
                              /*~E:I1965*/
                              /*~E:A1964*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1963*/
                              /*~F:1967*/
                              case 1:	// Temperaturoffset des Kanal 1 setzen
                              /*~-1*/
                              {
                              /*~A:1968*/
                              /*~+:Kanal 1*/
                              /*~I:1969*/
#ifdef CHANNEL_1
                              /*~T*/
                              // Temperaturoffset setzen und speichern
                              Analog_SetTemperatureOffset((char)Parameter[1].nLong,ANALOG_TEMPERATURE_CALIBRATION_SET_OFFSET_MANUALY); 
                              /*~A:1970*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              lText2Send = TEXT_TEMPERATURE_OFFSET_SET_CHANNEL_1;
                              /*~E:A1970*/
                              /*~-1*/
#endif
                              /*~E:I1969*/
                              /*~E:A1968*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1967*/
                              /*~F:1971*/
                              case 255: // Temperaturoffset berechnen
                              /*~-1*/
                              {
                              /*~I:1972*/
                              if (!GET_RESPONSE)
                              /*~-1*/
                              {
                              /*~K*/
                              /*~+:// Acknowledge empfangen - Alles okay*/
                              /*~T*/
                              Analog_SetTemperatureOffset((char)Parameter[1].nLong,ANALOG_TEMPERATURE_CALIBRATION_SET_OFFSET_AUTOMATICLY);
                              /*~A:1973*/
                              /*~+:Ausf�hrungsstatus auf 'OKAY' setzen*/
                              /*~+:*/
                              /*~T*/
                              // Ausf�hrungsstatus auf 'OKAY' setzen
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              /*~E:A1973*/
                              /*~A:1974*/
                              /*~+:Kanal 0 - Textausgabe*/
                              /*~I:1975*/
#ifdef CHANNEL_0
                              /*~A:1976*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              lText2Send = TEXT_TEMPERATURE_SENSOR_CALIBRATED;
                              /*~E:A1976*/
                              /*~-1*/
#endif
                              /*~E:I1975*/
                              /*~E:A1974*/
                              /*~-1*/
                              }
                              /*~O:I1972*/
                              /*~-2*/
                              else
                              {
                              /*~K*/
                              /*~+:Fehler !!!*/
                              /*~A:1977*/
                              /*~+:Ausf�hrungsstatus auf 'E005' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A1977*/
                              /*~-1*/
                              }
                              /*~E:I1972*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1971*/
                              /*~O:C1962*/
                              /*~-2*/
                              default:
                              {
                              /*~I:1978*/
#ifdef CHANNEL_0
                              /*~T*/
                              // Fehler
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I1978*/
                              /*~-1*/
                              }
                           /*~-1*/
                           }
                           /*~E:C1962*/
                        /*~-1*/
                        }
                        /*~O:I1961*/
                        /*~-2*/
                        else
                        {
                           /*~A:1979*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1979*/
                        /*~-1*/
                        }
                        /*~E:I1961*/
                     /*~-1*/
                     }
                     /*~E:I1960*/
                     /*~E:A1959*/
                     /*~A:1980*/
                     /*~+:STR - SetTaRa*/
                     /*~I:1981*/
                     if (!strcmp(szCommand,"STR"))
                     /*~-1*/
                     {
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;

                        /*~I:1982*/
                        if (!InstructionDecoder_CheckNbParameters(2,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           // Parameter auslesen
                           Parameter[0].nLong = Communication_GetLongParameter(0);
                           Parameter[1].fFloat = Communication_GetFloatParameter(1);
                           /*~C:1983*/
                           switch (Parameter[0].nLong)
                           /*~-1*/
                           {
                              /*~F:1984*/
                              case 0:
                              /*~-1*/
                              {
                              /*~A:1985*/
                              /*~+:Kanal 0*/
                              /*~I:1986*/
#ifdef CHANNEL_0
                              /*~I:1987*/
                              // Tara setzen und speichern
                              if (!Weight_SetTareValue(Parameter[1].fFloat,1))
                              /*~-1*/
                              {
                              /*~A:1988*/
                              /*~+:Eintrag in Diagnosespeicher vornehmen*/
                              /*~T*/
                              ulDiagnosisEntry2Set = DIAGNOSIS_MESSAGE_TARE_MANUAL;
                              /*~E:A1988*/
                              /*~A:1989*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              /*~I:1990*/
                              if (Parameter[1].fFloat)
                              /*~-1*/
                              {
                              /*~T*/
                              lText2Send = TEXT_MEASUREMENT_TARA_SET_2_FIX_VALUE_CHANNEL_0;
                              /*~-1*/
                              }
                              /*~O:I1990*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              lText2Send = TEXT_MEASUREMENT_TARA_CLEARED_CHANNEL_0;
                              /*~-1*/
                              }
                              /*~E:I1990*/
                              /*~E:A1989*/
                              /*~-1*/
                              }
                              /*~O:I1987*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~-1*/
                              }
                              /*~E:I1987*/
                              /*~-1*/
#endif
                              /*~E:I1986*/
                              /*~E:A1985*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1984*/
                              /*~F:1991*/
                              case 1:
                              /*~-1*/
                              {
                              /*~A:1992*/
                              /*~+:Kanal 1*/
                              /*~I:1993*/
#ifdef CHANNEL_1
                              /*~I:1994*/
                              // Tara setzen und speichern
                              if (!Weight_SetTareValue(Parameter[1].fFloat,1))
                              /*~-1*/
                              {
                              /*~A:1995*/
                              /*~+:Eintrag in Diagnosespeicher vornehmen*/
                              /*~T*/
                              ulDiagnosisEntry2Set = DIAGNOSIS_MESSAGE_TARE_MANUAL;
                              /*~E:A1995*/
                              /*~A:1996*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              /*~I:1997*/
                              if (Parameter[1].fFloat)
                              /*~-1*/
                              {
                              /*~T*/
                              lText2Send = TEXT_MEASUREMENT_TARA_SET_2_FIX_VALUE_CHANNEL_1;
                              /*~-1*/
                              }
                              /*~O:I1997*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              lText2Send = TEXT_MEASUREMENT_TARA_CLEARED_CHANNEL_1;
                              /*~-1*/
                              }
                              /*~E:I1997*/
                              /*~E:A1996*/
                              /*~-1*/
                              }
                              /*~O:I1994*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~-1*/
                              }
                              /*~E:I1994*/
                              /*~-1*/
#endif
                              /*~E:I1993*/
                              /*~E:A1992*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1991*/
                              /*~O:C1983*/
                              /*~-2*/
                              default:
                              {
                              /*~A:1998*/
                              /*~+:Kanal 0*/
                              /*~I:1999*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I1999*/
                              /*~E:A1998*/
                              /*~-1*/
                              }
                           /*~-1*/
                           }
                           /*~E:C1983*/
                        /*~-1*/
                        }
                        /*~O:I1982*/
                        /*~-2*/
                        else
                        {
                           /*~A:2000*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A2000*/
                        /*~-1*/
                        }
                        /*~E:I1982*/
                     /*~-1*/
                     }
                     /*~E:I1981*/
                     /*~E:A1980*/
                     /*~A:2001*/
                     /*~+:SZA - SetZeroActualweight*/
                     /*~I:2002*/
                     if (!strcmp(szCommand,"SZA"))
                     /*~-1*/
                     {
                        /*~A:2003*/
                        /*~+:Variablendeklarationen*/
                        /*~T*/
                        char byRetVal;
                        /*~E:A2003*/
                        /*~A:2004*/
                        /*~+:Variableninitialisierungen*/
                        /*~T*/

                        /*~E:A2004*/
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:2005*/
                        if (!InstructionDecoder_CheckNbParameters(0,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           byRetVal = Weight_SetZeroRegardingActualWeight();
                           //byRetVal = 0;
                           /*~I:2006*/
                           if (!GET_RESPONSE)
                           /*~-1*/
                           {
                              /*~I:2007*/
                              if (!byRetVal)
                              /*~-1*/
                              {
                              /*~T*/
                              // Alles okay
                              /*~A:2008*/
                              /*~+:Ausf�hrungsstatus auf 'OKAY' setzen*/
                              /*~+:*/
                              /*~T*/
                              // Ausf�hrungsstatus auf 'OKAY' setzen
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              /*~E:A2008*/
                              /*~A:2009*/
                              /*~+:Eintrag in Diagnosespeicher vornehmen*/
                              /*~T*/
                              ulDiagnosisEntry2Set = DIAGNOSIS_MESSAGE_ZERO;
                              /*~E:A2009*/
                              /*~A:2010*/
                              /*~+:Kanal 0 - Text f�r Terminalbetrieb*/
                              /*~I:2011*/
#ifdef CHANNEL_0
                              /*~T*/
                              lText2Send = TEXT_MEASUREMENT_OFFSET_SET_2_ACTUAL;
                              /*~-1*/
#endif
                              /*~E:I2011*/
                              /*~E:A2010*/
                              /*~-1*/
                              }
                              /*~O:I2007*/
                              /*~-2*/
                              else
                              {
                              /*~K*/
                              /*~+:Fehler !!!*/
                              /*~A:2012*/
                              /*~+:Ausf�hrungsstatus auf 'E005' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A2012*/
                              /*~I:2013*/
#ifdef MOF
                              /*~A:2014*/
                              /*~+:diverse Ausgaben zur genaueren Aufschl�sselung des Fehlers*/
                              /*~C:2015*/
                              switch (byRetVal)
                              /*~-1*/
                              {
                              /*~F:2016*/
                              case 1:
                              /*~-1*/
                              {
                              /*~A:2017*/
                              /*~+:Ausf�hrungsstatus auf 'E105' setzen*/
                              /*~T*/
                              Communication_SendString(COMMUNICATION_RS232,"E105",1,0);
                              /*~E:A2017*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F2016*/
                              /*~F:2018*/
                              case 2:
                              /*~-1*/
                              {
                              /*~A:2019*/
                              /*~+:Ausf�hrungsstatus auf 'E205' setzen*/
                              /*~T*/
                              Communication_SendString(COMMUNICATION_RS232,"E205",1,0);
                              /*~E:A2019*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F2018*/
                              /*~O:C2015*/
                              /*~-2*/
                              default:
                              {
                              /*~A:2020*/
                              /*~+:Ausf�hrungsstatus auf 'E305' setzen*/
                              /*~T*/
                              Communication_SendString(COMMUNICATION_RS232,"E305",1,0);
                              /*~E:A2020*/
                              /*~-1*/
                              }
                              /*~-1*/
                              }
                              /*~E:C2015*/
                              /*~E:A2014*/
                              /*~-1*/
#endif
                              /*~E:I2013*/
                              /*~-1*/
                              }
                              /*~E:I2007*/
                           /*~-1*/
                           }
                           /*~O:I2006*/
                           /*~-2*/
                           else
                           {
                              /*~K*/
                              /*~+:Fehler !!!*/
                              /*~A:2021*/
                              /*~+:Ausf�hrungsstatus auf 'E005' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A2021*/
                           /*~-1*/
                           }
                           /*~E:I2006*/
                        /*~-1*/
                        }
                        /*~O:I2005*/
                        /*~-2*/
                        else
                        {
                           /*~A:2022*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A2022*/
                        /*~-1*/
                        }
                        /*~E:I2005*/
                     /*~-1*/
                     }
                     /*~E:I2002*/
                     /*~E:A2001*/
                     /*~A:2023*/
                     /*~+:SZP - SetZeroPoint*/
                     /*~I:2024*/
                     if (!strcmp(szCommand,"SZP"))
                     /*~-1*/
                     {
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;

                        /*~I:2025*/
                        if (!InstructionDecoder_CheckNbParameters(2,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           // Parameter auslesen
                           Parameter[0].nLong = Communication_GetLongParameter(0);
                           Parameter[1].nLong = Communication_GetLongParameter(1);
                           /*~C:2026*/
                           switch (Parameter[0].nLong)
                           /*~-1*/
                           {
                              /*~F:2027*/
                              case 0:
                              /*~-1*/
                              {
                              /*~A:2028*/
                              /*~+:Kanal 0*/
                              /*~I:2029*/
#ifdef CHANNEL_0
                              /*~I:2030*/
                              if (!Weight_SetZero(Parameter[1].nLong))
                              /*~-1*/
                              {
                              /*~A:2031*/
                              /*~+:Eintrag in Diagnosespeicher vornehmen*/
                              /*~T*/
                              ulDiagnosisEntry2Set = DIAGNOSIS_MESSAGE_ZERO_TO_VALUE;
                              /*~E:A2031*/
                              /*~A:2032*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              lText2Send = TEXT_MEASUREMENT_OFFSET_SET_2_VALUE_CHANNEL_0;
                              /*~E:A2032*/
                              /*~-1*/
                              }
                              /*~O:I2030*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~-1*/
                              }
                              /*~E:I2030*/
                              /*~-1*/
#endif
                              /*~E:I2029*/
                              /*~E:A2028*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F2027*/
                              /*~F:2033*/
                              case 1:
                              /*~-1*/
                              {
                              /*~A:2034*/
                              /*~+:Kanal 1*/
                              /*~I:2035*/
#ifdef CHANNEL_1
                              /*~I:2036*/
                              if (!Weight_SetZero(Parameter[1].nLong))
                              /*~-1*/
                              {
                              /*~A:2037*/
                              /*~+:Eintrag in Diagnosespeicher vornehmen*/
                              /*~T*/
                              ulDiagnosisEntry2Set = DIAGNOSIS_MESSAGE_ZERO_TO_VALUE;
                              /*~E:A2037*/
                              /*~A:2038*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              lText2Send = TEXT_MEASUREMENT_OFFSET_SET_2_VALUE_CHANNEL_1;
                              /*~E:A2038*/
                              /*~-1*/
                              }
                              /*~O:I2036*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~-1*/
                              }
                              /*~E:I2036*/
                              /*~-1*/
#endif
                              /*~E:I2035*/
                              /*~E:A2034*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F2033*/
                              /*~O:C2026*/
                              /*~-2*/
                              default:
                              {
                              /*~A:2039*/
                              /*~+:Kanal 0*/
                              /*~I:2040*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I2040*/
                              /*~E:A2039*/
                              /*~-1*/
                              }
                           /*~-1*/
                           }
                           /*~E:C2026*/
                        /*~-1*/
                        }
                        /*~O:I2025*/
                        /*~-2*/
                        else
                        {
                           /*~A:2041*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A2041*/
                        /*~-1*/
                        }
                        /*~E:I2025*/
                     /*~-1*/
                     }
                     /*~E:I2024*/
                     /*~E:A2023*/
                     /*~T*/
                     break;
                  /*~-1*/
                  }
                  /*~E:F1441*/
                  /*~E:A1440*/
                  /*~A:2042*/
                  /*~+:T*/
                  /*~F:2043*/
                  case 'T':
                  /*~-1*/
                  {
                     /*~I:2044*/
#ifdef MIT_LIMITTEACH_VIA_RS232
                     /*~A:2045*/
                     /*~+:TEC - TEaCh*/
                     /*~I:2046*/
                     if (!strcmp(szCommand,"TEC"))
                     /*~-1*/
                     {
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:2047*/
                        if (!InstructionDecoder_CheckNbParameters(0,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~I:2048*/
                           if (!GET_RESPONSE)
                           /*~-1*/
                           {
                              /*~K*/
                              /*~+:// Alles okay*/
                              /*~I:2049*/
                              if (!Limit_SetAlarmLimitByWeight(1,0))
                              /*~-1*/
                              {
                              /*~A:2050*/
                              /*~+:Ausf�hrungsstatus auf 'OKAY' setzen*/
                              /*~+:*/
                              /*~T*/
                              // Ausf�hrungsstatus auf 'OKAY' setzen
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              /*~E:A2050*/
                              /*~A:2051*/
                              /*~+:Kanal 0 - Textausgabe*/
                              /*~I:2052*/
#ifdef CHANNEL_0
                              /*~T*/
                              lText2Send = TEXT_LIMIT_TEACHED;
                              /*~-1*/
#endif
                              /*~E:I2052*/
                              /*~E:A2051*/
                              /*~-1*/
                              }
                              /*~O:I2049*/
                              /*~-2*/
                              else
                              {
                              /*~K*/
                              /*~+:Fehler !!!*/
                              /*~A:2053*/
                              /*~+:Ausf�hrungsstatus auf 'E005' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A2053*/
                              /*~-1*/
                              }
                              /*~E:I2049*/
                           /*~-1*/
                           }
                           /*~O:I2048*/
                           /*~-2*/
                           else
                           {
                              /*~K*/
                              /*~+:Fehler !!!*/
                              /*~A:2054*/
                              /*~+:Ausf�hrungsstatus auf 'E005' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A2054*/
                           /*~-1*/
                           }
                           /*~E:I2048*/
                        /*~-1*/
                        }
                        /*~O:I2047*/
                        /*~-2*/
                        else
                        {
                           /*~A:2055*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A2055*/
                        /*~-1*/
                        }
                        /*~E:I2047*/
                     /*~-1*/
                     }
                     /*~E:I2046*/
                     /*~E:A2045*/
                     /*~-1*/
#endif
                     /*~E:I2044*/
                     /*~I:2056*/
#ifdef MIT_TARATEACH_VIA_RS232
                     /*~A:2057*/
                     /*~+:TET - TEachTare*/
                     /*~I:2058*/
                     if (!strcmp(szCommand,"TET"))
                     /*~-1*/
                     {
                        /*~A:2059*/
                        /*~+:Variablendeklarationen*/
                        /*~T*/

                        /*~E:A2059*/
                        /*~A:2060*/
                        /*~+:Variableninitialisierungen*/
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~E:A2060*/
                        /*~A:2061*/
                        /*~+:Kanal 0*/
                        /*~I:2062*/
#ifdef CHANNEL_0
                        /*~I:2063*/
                        if (!InstructionDecoder_CheckNbParameters(0,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~I:2064*/
                           if (!GET_RESPONSE)
                           /*~-1*/
                           {
                              /*~I:2065*/
                              if (!Limit_TeachTara())
                              /*~-1*/
                              {
                              /*~K*/
                              /*~+:Tarierung erfolgreich*/
                              /*~T*/
                              // Tara �bernehmen
                              Weight_TareWeight = Measurement_GetResult(WEIGHT_WEIGHTCHANNEL,MEASUREMENT_GET_TARE);
                              /*~A:2066*/
                              /*~+:Ausf�hrungsstatus auf 'OKAY' setzen*/
                              /*~+:*/
                              /*~T*/
                              // Ausf�hrungsstatus auf 'OKAY' setzen
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              /*~E:A2066*/
                              /*~A:2067*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              lText2Send = TEXT_TARE_TEACHED;
                              /*~E:A2067*/
                              /*~-1*/
                              }
                              /*~O:I2065*/
                              /*~-2*/
                              else
                              {
                              /*~K*/
                              /*~+:Fehler beim Teachen Kanal 0*/
                              /*~A:2068*/
                              /*~+:Ausf�hrungsstatus auf 'E005' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A2068*/
                              /*~-1*/
                              }
                              /*~E:I2065*/
                           /*~-1*/
                           }
                           /*~O:I2064*/
                           /*~-2*/
                           else
                           {
                              /*~K*/
                              /*~+:Fehler beim Teachen Kanal 1*/
                              /*~A:2069*/
                              /*~+:Ausf�hrungsstatus auf 'E005' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A2069*/
                           /*~-1*/
                           }
                           /*~E:I2064*/
                        /*~-1*/
                        }
                        /*~O:I2063*/
                        /*~-2*/
                        else
                        {
                           /*~A:2070*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A2070*/
                        /*~-1*/
                        }
                        /*~E:I2063*/
                        /*~-1*/
#endif
                        /*~E:I2062*/
                        /*~E:A2061*/
                        /*~A:2071*/
                        /*~+:Kanal 1*/
                        /*~I:2072*/
#ifdef CHANNEL_1
                        /*~I:2073*/
                        if (!InstructionDecoder_CheckNbParameters(0,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~I:2074*/
                           if (!Limit_TeachTara())
                           /*~-1*/
                           {
                              /*~T*/
                              // Tara �bernehmen
                              Weight_TareWeight = Measurement_GetResult(WEIGHT_WEIGHTCHANNEL,MEASUREMENT_GET_TARE);
                              /*~T*/
                              Communication_SendMessage(COMMUNICATION_SPI,COMMUNICATION_SHORT_ACK);
                           /*~-1*/
                           }
                           /*~O:I2074*/
                           /*~-2*/
                           else
                           {
                              /*~T*/
                              Communication_SendMessage(COMMUNICATION_SPI,COMMUNICATION_NOK);
                           /*~-1*/
                           }
                           /*~E:I2074*/
                        /*~-1*/
                        }
                        /*~O:I2073*/
                        /*~-2*/
                        else
                        {
                           /*~A:2075*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A2075*/
                        /*~-1*/
                        }
                        /*~E:I2073*/
                        /*~-1*/
#endif
                        /*~E:I2072*/
                        /*~E:A2071*/
                     /*~-1*/
                     }
                     /*~E:I2058*/
                     /*~E:A2057*/
                     /*~-1*/
#endif
                     /*~E:I2056*/
                     /*~A:2076*/
                     /*~+:TSL - TeStLimits*/
                     /*~I:2077*/
                     if (!strcmp(szCommand,"TSL"))
                     /*~-1*/
                     {
                        /*~A:2078*/
                        /*~+:Variablendeklarationen*/
                        /*~T*/

                        /*~E:A2078*/
                        /*~A:2079*/
                        /*~+:Variableninitialisierungen*/
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~E:A2079*/
                        /*~T*/
                        Parameter[0].nLong = Communication_GetLongParameter(0);
                        /*~A:2080*/
                        /*~+:Kanal 0*/
                        /*~I:2081*/
#ifdef CHANNEL_0
                        /*~I:2082*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~I:2083*/
                           if (!GET_RESPONSE)
                           /*~-1*/
                           {
                              /*~C:2084*/
                              switch (Parameter[0].nLong)
                              /*~-1*/
                              {
                              /*~F:2085*/
                              case 0:
                              /*~-1*/
                              {
                              /*~T*/
                              Limit_SetLimitCheckFlag(0x55);
                              /*~A:2086*/
                              /*~+:Ausf�hrungsstatus auf 'OKAY' setzen*/
                              /*~+:*/
                              /*~T*/
                              // Ausf�hrungsstatus auf 'OKAY' setzen
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              /*~E:A2086*/
                              /*~A:2087*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              lText2Send = TEXT_LOWER_LIMIT_TEST_STARTED;
                              /*~E:A2087*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F2085*/
                              /*~F:2088*/
                              case 1:
                              /*~-1*/
                              {
                              /*~T*/
                              Limit_SetLimitCheckFlag(0xAA);
                              /*~A:2089*/
                              /*~+:Ausf�hrungsstatus auf 'OKAY' setzen*/
                              /*~+:*/
                              /*~T*/
                              // Ausf�hrungsstatus auf 'OKAY' setzen
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              /*~E:A2089*/
                              /*~A:2090*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              lText2Send = TEXT_UPPER_LIMIT_TEST_STARTED;
                              /*~E:A2090*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F2088*/
                              /*~O:C2084*/
                              /*~-2*/
                              default:
                              {
                              /*~A:2091*/
                              /*~+:Ausf�hrungsstatus auf 'E002' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E002;
                              /*~E:A2091*/
                              /*~-1*/
                              }
                              /*~-1*/
                              }
                              /*~E:C2084*/
                           /*~-1*/
                           }
                           /*~O:I2083*/
                           /*~-2*/
                           else
                           {
                              /*~K*/
                              /*~+:Kanal 1 sendete keine Best�tigung*/
                              /*~A:2092*/
                              /*~+:Ausf�hrungsstatus auf 'E005' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A2092*/
                           /*~-1*/
                           }
                           /*~E:I2083*/
                        /*~-1*/
                        }
                        /*~O:I2082*/
                        /*~-2*/
                        else
                        {
                           /*~A:2093*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A2093*/
                        /*~-1*/
                        }
                        /*~E:I2082*/
                        /*~-1*/
#endif
                        /*~E:I2081*/
                        /*~E:A2080*/
                        /*~A:2094*/
                        /*~+:Kanal 1*/
                        /*~I:2095*/
#ifdef CHANNEL_1
                        /*~I:2096*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~I:2097*/
                           if (!GET_RESPONSE)
                           /*~-1*/
                           {
                              /*~C:2098*/
                              switch (Parameter[0].nLong)
                              /*~-1*/
                              {
                              /*~F:2099*/
                              case 0:
                              /*~-1*/
                              {
                              /*~A:2100*/
                              /*~+:Ausf�hrungsstatus auf 'OKAY' setzen*/
                              /*~+:*/
                              /*~T*/
                              // Ausf�hrungsstatus auf 'OKAY' setzen
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              /*~E:A2100*/
                              /*~T*/
                              Limit_SetLimitCheckFlag(0x55);
                              /*~T*/
                              Communication_SendMessage(COMMUNICATION_SPI,COMMUNICATION_SHORT_ACK);
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F2099*/
                              /*~F:2101*/
                              case 1:
                              /*~-1*/
                              {
                              /*~A:2102*/
                              /*~+:Ausf�hrungsstatus auf 'OKAY' setzen*/
                              /*~+:*/
                              /*~T*/
                              // Ausf�hrungsstatus auf 'OKAY' setzen
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              /*~E:A2102*/
                              /*~T*/
                              Limit_SetLimitCheckFlag(0xAA);
                              /*~T*/
                              Communication_SendMessage(COMMUNICATION_SPI,COMMUNICATION_SHORT_ACK);
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F2101*/
                              /*~O:C2098*/
                              /*~-2*/
                              default:
                              {
                              /*~A:2103*/
                              /*~+:Ausf�hrungsstatus auf 'E002' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E002;
                              /*~E:A2103*/
                              /*~-1*/
                              }
                              /*~-1*/
                              }
                              /*~E:C2098*/
                           /*~-1*/
                           }
                           /*~O:I2097*/
                           /*~-2*/
                           else
                           {
                              /*~A:2104*/
                              /*~+:Ausf�hrungsstatus auf 'E005' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A2104*/
                           /*~-1*/
                           }
                           /*~E:I2097*/
                        /*~-1*/
                        }
                        /*~O:I2096*/
                        /*~-2*/
                        else
                        {
                           /*~A:2105*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A2105*/
                        /*~-1*/
                        }
                        /*~E:I2096*/
                        /*~-1*/
#endif
                        /*~E:I2095*/
                        /*~E:A2094*/
                     /*~-1*/
                     }
                     /*~E:I2077*/
                     /*~E:A2076*/
                     /*~T*/
                     break;
                  /*~-1*/
                  }
                  /*~E:F2043*/
                  /*~E:A2042*/
                  /*~A:2106*/
                  /*~+:V*/
                  /*~F:2107*/
                  case 'V':
                  /*~-1*/
                  {
                     /*~A:2108*/
                     /*~+:VAS - ViewAlarmStatus*/
                     /*~K*/
                     /*~+:*/
                     /*~+:=> VDG*/
                     /*~E:A2108*/
                     /*~A:2109*/
                     /*~+:VDG - ViewDiaGnosis*/
                     /*~I:2110*/
                     // if ((!strcmp(szCommand,"VAS"))||(!strcmp(szCommand,"VDG")))
                     if (!strcmp(szCommand,"VAS"))

                     /*~-1*/
                     {
                        /*~A:2111*/
                        /*~+:Variablendeklarationen*/
                        /*~T*/
                        unsigned char byCounter;
                        /*~E:A2111*/
                        /*~A:2112*/
                        /*~+:Variableninitialisierungen*/
                        /*~T*/
                        byCounter = 3;
                        /*~E:A2112*/
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:2113*/
                        if (!SYSTEM_MRW_MANAGER)
                        /*~-1*/
                        {
                           /*~I:2114*/
                           if (!InstructionDecoder_CheckNbParameters(0,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                           /*~-1*/
                           {
                              /*~I:2115*/
#ifdef CHANNEL_0
                              /*~T*/
                              //  Wg. der langen Dauer der Ausgabe die Synchronisationspr�fung ausschalten
                              Communication_SendSPICommand("iSCS 0");
                              /*~I:2116*/
                              if (Communication_IsOK())
                              /*~-1*/
                              {
                              /*~T*/
                              Diagnosis_PrintMemory();
                              /*~T*/
                              Communication_SendSPICommand("iVDG");
                              /*~I:2117*/
                              if (Communication_IsOK())
                              /*~-1*/
                              {
                              /*~T*/
                              // Wg. der langen Dauer der Ausgabe die Synchronisationspr�fung ausschalten
                              System_SetCheckSynchronisation(0);
                              /*~-1*/
                              }
                              /*~E:I2117*/
                              /*~-1*/
                              }
                              /*~E:I2116*/
                              /*~-1*/
#endif
                              /*~E:I2115*/
                              /*~A:2118*/
                              /*~+:ausgeklammert*/
                              /*~I:2119*/
#ifdef MOF
                              /*~I:2120*/
#ifdef CHANNEL_0
                              /*~U:2121*/
                              /*~-2*/
                              do
                              {
                              /*~T*/
                              Communication_SendSPICommand("iSCS 0");
                              /*~-1*/
                              }
                              /*~O:U2121*/
                              while (!Communication_IsOK() && --byCounter);
                              /*~E:U2121*/
                              /*~T*/
                              Diagnosis_PrintMemory();
                              /*~T*/
                              byCounter = 3;
                              /*~U:2122*/
                              /*~-2*/
                              do
                              {
                              /*~T*/
                              Communication_SendSPICommand("iVDG");
                              /*~-1*/
                              }
                              /*~O:U2122*/
                              while (!Communication_IsOK() && --byCounter);
                              /*~E:U2122*/
                              /*~I:2123*/
                              if (byCounter)
                              /*~-1*/
                              {
                              /*~T*/
                              // Wg. der langen Dauer der Ausgabe die Synchronisationspr�fung ausschalten
                              System_SetCheckSynchronisation(0);
                              /*~-1*/
                              }
                              /*~E:I2123*/
                              /*~-1*/
#endif
                              /*~E:I2120*/
                              /*~-1*/
#endif
                              /*~E:I2119*/
                              /*~E:A2118*/
                           /*~-1*/
                           }
                           /*~O:I2114*/
                           /*~-2*/
                           else
                           {
                              /*~A:2124*/
                              /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                              /*~T*/

                              /*~E:A2124*/
                           /*~-1*/
                           }
                           /*~E:I2114*/
                        /*~-1*/
                        }
                        /*~O:I2113*/
                        /*~-2*/
                        else
                        {
                           /*~I:2125*/
                           if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                           /*~-1*/
                           {
                              /*~T*/
                              Parameter[0].nLong = Communication_GetLongParameter(0); 
                              /*~C:2126*/
                              switch (Parameter[0].nLong)
                              /*~-1*/
                              {
                              /*~F:2127*/
                              case 0:
                              /*~-1*/
                              {
                              /*~T*/
                              // Kanal 0

                              /*~I:2128*/
#ifdef CHANNEL_0
                              /*~T*/
                              //  Wg. der langen Dauer der Ausgabe die Synchronisationspr�fung ausschalten
                              Communication_SendSPICommand("iSCS 0");
                              /*~I:2129*/
                              if (Communication_IsOK())
                              /*~-1*/
                              {
                              /*~T*/
                              Diagnosis_PrintMemory();
                              /*~T*/
                              Communication_SendSPICommand("iSCS 1");
                              /*~-1*/
                              }
                              /*~E:I2129*/
                              /*~-1*/
#endif
                              /*~E:I2128*/
                              /*~A:2130*/
                              /*~+:ausgeklammert*/
                              /*~I:2131*/
#ifdef MOF
                              /*~I:2132*/
#ifdef CHANNEL_0
                              /*~U:2133*/
                              /*~-2*/
                              do
                              {
                              /*~T*/
                              Communication_SendSPICommand("iSCS 0");
                              /*~-1*/
                              }
                              /*~O:U2133*/
                              while (!Communication_IsOK() && --byCounter);
                              /*~E:U2133*/
                              /*~T*/
                              Diagnosis_PrintMemory();
                              /*~T*/
                              byCounter = 3;
                              /*~U:2134*/
                              /*~-2*/
                              do
                              {
                              /*~T*/
                              Communication_SendSPICommand("iSCS 1");
                              /*~-1*/
                              }
                              /*~O:U2134*/
                              while (!Communication_IsOK() && --byCounter);
                              /*~E:U2134*/
                              /*~-1*/
#endif
                              /*~E:I2132*/
                              /*~-1*/
#endif
                              /*~E:I2131*/
                              /*~E:A2130*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F2127*/
                              /*~F:2135*/
                              case 1:
                              /*~-1*/
                              {
                              /*~T*/
                              // Kanal 1
                              /*~I:2136*/
#ifdef CHANNEL_0
                              /*~T*/
                              Communication_SendSPICommand("iVDG");
                              /*~I:2137*/
                              if (Communication_IsOK())
                              /*~-1*/
                              {
                              /*~T*/
                              // Wg. der langen Dauer der Ausgabe die Synchronisationspr�fung ausschalten
                              System_SetCheckSynchronisation(0);
                              /*~-1*/
                              }
                              /*~E:I2137*/
                              /*~-1*/
#endif
                              /*~E:I2136*/
                              /*~A:2138*/
                              /*~+:ausgeklammert*/
                              /*~I:2139*/
#ifdef MOF
                              /*~I:2140*/
#ifdef CHANNEL_0
                              /*~U:2141*/
                              /*~-2*/
                              do
                              {
                              /*~T*/
                              Communication_SendSPICommand("iVDG");
                              /*~-1*/
                              }
                              /*~O:U2141*/
                              while (!Communication_IsOK() && --byCounter);
                              /*~E:U2141*/
                              /*~I:2142*/
                              if (byCounter)
                              /*~-1*/
                              {
                              /*~T*/
                              // Wg. der langen Dauer der Ausgabe die Synchronisationspr�fung ausschalten
                              System_SetCheckSynchronisation(0);
                              /*~-1*/
                              }
                              /*~E:I2142*/
                              /*~-1*/
#endif
                              /*~E:I2140*/
                              /*~-1*/
#endif
                              /*~E:I2139*/
                              /*~E:A2138*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F2135*/
                              /*~F:2143*/
                              case 2:
                              /*~-1*/
                              {
                              /*~T*/
                              // Freier Speicher Kanal 0
                              /*~I:2144*/
#ifdef CHANNEL_0
                              /*~T*/
                              Diagnosis_PrintFreeMemory();
                              /*~-1*/
#endif
                              /*~E:I2144*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F2143*/
                              /*~F:2145*/
                              case 3:
                              /*~-1*/
                              {
                              /*~T*/
                              // Freier Speicher Kanal 1
                              /*~I:2146*/
#ifdef CHANNEL_1
                              /*~T*/
                              Diagnosis_PrintFreeMemory();
                              /*~-1*/
#endif
                              /*~E:I2146*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F2145*/
                              /*~O:C2126*/
                              /*~-2*/
                              default:
                              {
                              /*~T*/
                              // Zur�cksetzen der Lese-Prozedur

                              Diagnosis_InitReadProcedure();
                              /*~-1*/
                              }
                              /*~-1*/
                              }
                              /*~E:C2126*/
                           /*~-1*/
                           }
                           /*~O:I2125*/
                           /*~-2*/
                           else
                           {
                              /*~A:2147*/
                              /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                              /*~T*/

                              /*~E:A2147*/
                           /*~-1*/
                           }
                           /*~E:I2125*/
                        /*~-1*/
                        }
                        /*~E:I2113*/
                     /*~-1*/
                     }
                     /*~E:I2110*/
                     /*~E:A2109*/
                     /*~T*/
                     break;
                  /*~-1*/
                  }
                  /*~E:F2107*/
                  /*~E:A2106*/
                  /*~K*/
                  /*~+:// interne Befehle (iXXX)*/
                  /*~A:2148*/
                  /*~+:i*/
                  /*~F:2149*/
                  case 'i':
                  /*~-1*/
                  {
                     /*~I:2150*/
#ifdef CHANNEL_0
                     /*~T*/
                     // Text wurde bereits gesendet
                     byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                     /*~-1*/
#endif
                     /*~E:I2150*/
                     /*~I:2151*/
#ifdef CHANNEL_1
                     /*~A:2152*/
                     /*~+:iACR - internal Command - AutomaticCompensationResults */
                     /*~I:2153*/
                     if (!strcmp(szCommand,"iACR"))
                     /*~-1*/
                     {
                        /*~A:2154*/
                        /*~+:SPI-Debugging - nur zu Testzwecken*/
                        /*~I:2155*/
#ifdef DEVELOPMENT_SW
                        /*~T*/
                        CommunicationControl.ulSPICounter++;
                        /*~-1*/
#endif
                        /*~E:I2155*/
                        /*~E:A2154*/
                        /*~T*/
                        Parameter[0].nLong = Communication_GetLongParameter(0);
                        Parameter[1].nLong = Communication_GetLongParameter(1);
                        /*~T*/
                        // Befehlsbest�tigung senden
                        Communication_SendSPICommand("OK");
                        /*~T*/
                        Compensation_PrintCompensationValues(1,Parameter[0].nLong,Parameter[1].nLong,0);
                     /*~-1*/
                     }
                     /*~E:I2153*/
                     /*~E:A2152*/
                     /*~A:2156*/
                     /*~+:iACS - internal Command - AutomaticCompensationStatus */
                     /*~I:2157*/
                     if (!strcmp(szCommand,"iACS"))
                     /*~-1*/
                     {
                        /*~A:2158*/
                        /*~+:Variablendeklarationen*/
                        /*~T*/
                        char byRecCharacteristicsOn;
                        /*~E:A2158*/
                        /*~A:2159*/
                        /*~+:Variableninitialisierungen*/
                        /*~T*/

                        /*~E:A2159*/
                        /*~A:2160*/
                        /*~+:SPI-Debugging - nur zu Testzwecken*/
                        /*~I:2161*/
#ifdef DEVELOPMENT_SW
                        /*~T*/
                        CommunicationControl.ulSPICounter++;
                        /*~-1*/
#endif
                        /*~E:I2161*/
                        /*~E:A2160*/
                        /*~T*/
                        MRW_Compensation_GetData(MRW_COMPENSATION_GET_REC_CHARACTERISTICS_ONOFF,0,&byRecCharacteristicsOn); 
                        /*~I:2162*/
                        if (byRecCharacteristicsOn)
                        /*~-1*/
                        {
                           /*~T*/
                           // Ausgabe Kanal 1
                           Compensation_PrintCompensationValues(0,0xFF,0,1);
                           /*~T*/
                           byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                        /*~-1*/
                        }
                        /*~E:I2162*/
                        /*~T*/
                        bDoNotWriteResult2Buffer = 0;
                     /*~-1*/
                     }
                     /*~E:I2157*/
                     /*~E:A2156*/
                     /*~A:2163*/
                     /*~+:iART - internal Command - AutomaticRecordTemperaturecompensation stoppen */
                     /*~I:2164*/
                     if (!strcmp(szCommand,"iART"))
                     /*~-1*/
                     {
                        /*~A:2165*/
                        /*~+:SPI-Debugging - nur zu Testzwecken*/
                        /*~I:2166*/
#ifdef DEVELOPMENT_SW
                        /*~T*/
                        CommunicationControl.ulSPICounter++;
                        /*~-1*/
#endif
                        /*~E:I2166*/
                        /*~E:A2165*/
                        /*~T*/
                        // Kennlinienaufnahme stoppen
                        MRW_Compensation_SetRecCharacteristicsOn(0);

                        System_SetSystemState(SYSTEM_RUNNING);
                        /*~A:2167*/
                        /*~+:Eintrag in Diagnosespeicher vornehmen*/
                        /*~T*/
                        ulDiagnosisEntry2Set = DIAGNOSIS_MESSAGE_TEMPCOMPENSATION_STOPPED;
                        /*~E:A2167*/
                        /*~T*/
                        // Best�tigung
                        byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                     /*~-1*/
                     }
                     /*~E:I2164*/
                     /*~E:A2163*/
                     /*~A:2168*/
                     /*~+:iCDL - internal Command - Connect2Docklight*/
                     /*~I:2169*/
                     if (!strcmp(szCommand,"iCDL"))
                     /*~-1*/
                     {
                        /*~A:2170*/
                        /*~+:SPI-Debugging - nur zu Testzwecken*/
                        /*~I:2171*/
#ifdef DEVELOPMENT_SW
                        /*~T*/
                        CommunicationControl.ulSPICounter++;
                        /*~-1*/
#endif
                        /*~E:I2171*/
                        /*~E:A2170*/
                        /*~T*/
                        // Docklightmodus setzen
                        System_Connect2MRW_Manager(0);

                        byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                     /*~-1*/
                     }
                     /*~E:I2169*/
                     /*~E:A2168*/
                     /*~A:2172*/
                     /*~+:iGDG - internal Command - GetDiaGnosis*/
                     /*~I:2173*/
                     if (!strcmp(szCommand,"iGDG"))
                     /*~-1*/
                     {
                        /*~A:2174*/
                        /*~+:Variablendeklarationen*/
                        /*~T*/
                        unsigned long 	ulMessage;
                        unsigned long 	ulTime;
                        /*~E:A2174*/
                        /*~A:2175*/
                        /*~+:SPI-Debugging - nur zu Testzwecken*/
                        /*~I:2176*/
#ifdef DEVELOPMENT_SW
                        /*~T*/
                        CommunicationControl.ulSPICounter++;
                        /*~-1*/
#endif
                        /*~E:I2176*/
                        /*~E:A2175*/
                        /*~T*/
                        byRetVal = Diagnosis_ReadMessageFromFlash(&ulTime,&ulMessage);
                        /*~T*/
                        Communication_SendLong(COMMUNICATION_SPI,0,ulTime,0,0);
                        Communication_SendLong(COMMUNICATION_SPI,0,ulMessage,0,0);
                        Communication_SendLong(COMMUNICATION_SPI,0,byRetVal,0,0);
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                     /*~-1*/
                     }
                     /*~E:I2173*/
                     /*~E:A2172*/
                     /*~A:2177*/
                     /*~+:iGLP - internal Command - GetLimitstatePartner*/
                     /*~I:2178*/
                     if (!strcmp(szCommand,"iGLP"))
                     /*~-1*/
                     {
                        /*~A:2179*/
                        /*~+:SPI-Debugging - nur zu Testzwecken*/
                        /*~I:2180*/
#ifdef DEVELOPMENT_SW
                        /*~T*/
                        CommunicationControl.ulSPICounter++;
                        /*~-1*/
#endif
                        /*~E:I2180*/
                        /*~E:A2179*/
                        /*~T*/
                        // Limitstatus des Partners auslesen
                        Global.chLimitStatus_Partner = (char)Communication_GetLongParameter(1);
                        /*~I:2181*/
                        if (!Communication_SendLong(COMMUNICATION_SPI,0,Limit_GetLimitState(),0,1))
                        /*~-1*/
                        {
                           /*~A:2182*/
                           /*~+:jetzt noch Ma�nahmen zur �berpr�fung der Gegenstelle treffen */
                           /*~T*/
                           System_IncCheckSynchronisationCounter();
                           /*~E:A2182*/
                        /*~-1*/
                        }
                        /*~E:I2181*/
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                     /*~-1*/
                     }
                     /*~E:I2178*/
                     /*~E:A2177*/
                     /*~A:2183*/
                     /*~+:iGPS - internal Command - GetPartnerState*/
                     /*~I:2184*/
                     if (!strcmp(szCommand,"iGPS"))
                     /*~-1*/
                     {
                        /*~A:2185*/
                        /*~+:Variablendeklarationen*/
                        /*~T*/
                        long lSystemStatePartner;

                        /*~E:A2185*/
                        /*~A:2186*/
                        /*~+:SPI-Debugging - nur zu Testzwecken*/
                        /*~I:2187*/
#ifdef DEVELOPMENT_SW
                        /*~T*/
                        CommunicationControl.ulSPICounter++;
                        /*~-1*/
#endif
                        /*~E:I2187*/
                        /*~E:A2186*/
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~C:2188*/
                        switch (Communication_GetLongParameter(0))
                        /*~-1*/
                        {
                           /*~F:2189*/
                           case 0:
                           /*~-1*/
                           {
                              /*~T*/
                              lSystemStatePartner = Communication_GetLongParameter(1);
                              /*~I:2190*/
                              // Partner-Systemstatus kann nur gesetzt werden, wenn das System nicht im Fehlerzustand ist !
                              if (SYSTEMSTATE != SYSTEM_ERROR)
                              /*~-1*/
                              {
                              /*~T*/
                              // Systemstatus des Partners auslesen
                              SYSTEMSTATE_PARTNER = lSystemStatePartner;
                              /*~-1*/
                              }
                              /*~E:I2190*/
                              /*~I:2191*/
#ifdef MIT_SYSTEMFEHLER_BEI_PARTNER_SYSTEMFEHLER
                              /*~I:2192*/
                              if (SYSTEMSTATE_PARTNER == SYSTEM_ERROR)
                              /*~-1*/
                              {
                              /*~A:2193*/
                              /*~+:Sicherheitsfunktion aufrufen*/
                              /*~T*/
                              // Sicherheitsfunktion aufrufen
                              Diagnosis_SecurityPartnerSystemError(SYSTEM_PARTNER_IN_SYSTEMERROR);
                              /*~E:A2193*/
                              /*~-1*/
                              }
                              /*~E:I2192*/
                              /*~-1*/
#endif
                              /*~E:I2191*/
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_SPI,0,SYSTEMSTATE,0,1);
                              /*~T*/
                              break;
                           /*~-1*/
                           }
                           /*~E:F2189*/
                           /*~F:2194*/
                           case 1:
                           /*~-1*/
                           {
                              /*~T*/
                              // Limitstatus des Partners auslesen
                              Global.chLimitStatus_Partner = (char)Communication_GetLongParameter(1);
                              /*~I:2195*/
                              if (!Communication_SendLong(COMMUNICATION_SPI,0,Limit_GetLimitState(),0,1))
                              /*~-1*/
                              {
                              /*~A:2196*/
                              /*~+:jetzt noch Ma�nahmen zur �berpr�fung der Gegenstelle treffen */
                              /*~T*/
                              System_IncCheckSynchronisationCounter();
                              /*~E:A2196*/
                              /*~-1*/
                              }
                              /*~E:I2195*/
                              /*~T*/
                              break;
                           /*~-1*/
                           }
                           /*~E:F2194*/
                        /*~-1*/
                        }
                        /*~E:C2188*/
                     /*~-1*/
                     }
                     /*~E:I2184*/
                     /*~E:A2183*/
                     /*~A:2197*/
                     /*~+:iGRS - internal Command - GetlastcommadexecutionReSult*/
                     /*~I:2198*/
                     if (!strcmp(szCommand,"iGRS"))
                     /*~-1*/
                     {
                        /*~A:2199*/
                        /*~+:SPI-Debugging - nur zu Testzwecken*/
                        /*~I:2200*/
#ifdef DEVELOPMENT_SW
                        /*~T*/
                        CommunicationControl.ulSPICounter++;
                        /*~-1*/
#endif
                        /*~E:I2200*/
                        /*~E:A2199*/
                        /*~A:2201*/
                        /*~+:Eintrag in Diagnosespeicher vornehmen*/
                        /*~I:2202*/
                        if (ulDiagnosisEntry2SetAtiGRS)
                        /*~-1*/
                        {
                           /*~T*/
                           Diagnosis_WriteMessage2Flash(ulDiagnosisEntry2SetAtiGRS);

                           ulDiagnosisEntry2SetAtiGRS = 0;
                        /*~-1*/
                        }
                        /*~E:I2202*/
                        /*~E:A2201*/
                        /*~I:2203*/
                        if (!Communication_SendLong(COMMUNICATION_SPI,0,g_byLastCommandExecutionResult,0,1))
                        /*~-1*/
                        {
                           /*~T*/
                           // Inhalt wieder l�schen
                           g_byLastCommandExecutionResult = 0xA5;
                        /*~-1*/
                        }
                        /*~E:I2203*/
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                     /*~-1*/
                     }
                     /*~E:I2198*/
                     /*~E:A2197*/
                     /*~A:2204*/
                     /*~+:iGSV - internal Command - GetStoredValue */
                     /*~I:2205*/
                     if (!strcmp(szCommand,"iGSV"))
                     /*~-1*/
                     {
                        /*~A:2206*/
                        /*~+:Variablendeklarationen*/
                        /*~T*/
                        unsigned char byValue2Get;
                        /*~E:A2206*/
                        /*~A:2207*/
                        /*~+:Variableninitialisierungen*/
                        /*~T*/

                        /*~E:A2207*/
                        /*~A:2208*/
                        /*~+:SPI-Debugging - nur zu Testzwecken*/
                        /*~I:2209*/
#ifdef DEVELOPMENT_SW
                        /*~T*/
                        CommunicationControl.ulSPICounter++;
                        /*~-1*/
#endif
                        /*~E:I2209*/
                        /*~E:A2208*/
                        /*~T*/
                        byValue2Get = (unsigned char)Communication_GetLongParameter(0);
                        /*~I:2210*/
                        if (g_ulTimeoutValue < SYSTEMTIME)
                        /*~-1*/
                        {
                           /*~T*/
                           // Timeout

                           // Inhalt wieder l�schen

                           /*~T*/
                           g_byValueStored = 0;
                        /*~-1*/
                        }
                        /*~O:I2210*/
                        /*~-2*/
                        else
                        {
                           /*~I:2211*/
                           if (!g_byValueStored)
                           /*~-1*/
                           {
                              /*~T*/
                              // Es liegt z.Z. kein Wert vor
                           /*~-1*/
                           }
                           /*~O:I2211*/
                           /*~-2*/
                           else
                           {
                              /*~I:2212*/
                              if (g_byValueStored == byValue2Get)
                              /*~-1*/
                              {
                              /*~T*/
                              // Der zu holende Wert entspricht dem abgespeicherten
                              /*~T*/
                              g_byValueStored = 0;
                              /*~C:2213*/
                              switch (byValue2Get)
                              /*~-1*/
                              {
                              /*~F:2214*/
                              case COMMUNICATION_NUMBER_OF_MEASUREMENTS:
                              case COMMUNICATION_FILTER_DEPTH:
                              case COMMUNICATION_LOADCELL:
                              case COMMUNICATION_MOTION_FILTER:
                              case COMMUNICATION_COMPENSATION_STATE:
                              case COMMUNICATION_E_COMPENSATION_STATE:
                              case COMMUNICATION_CURRENTINTERFACE_FEEDBACK_STATE:

                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_SPI,0,g_Value.byChar,0,0);
                              /*~T*/
                              return;
                              /*~-1*/
                              }
                              /*~E:F2214*/
                              /*~F:2215*/
                              case COMMUNICATION_FILTER_WIDTH:
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_SPI,0,g_Value.nInt,0,0);
                              /*~T*/
                              return;
                              /*~-1*/
                              }
                              /*~E:F2215*/
                              /*~F:2216*/
                              case COMMUNICATION_TIME_HYSTERESIS:
                              case COMMUNICATION_RS232_BAUDRATE:
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_SPI,0,g_Value.nLong,0,0);
                              /*~T*/
                              return;
                              /*~-1*/
                              }
                              /*~E:F2216*/
                              /*~F:2217*/
                              case COMMUNICATION_CHECKLIMIT_ZEROPOINTCHECK:
                              case COMMUNICATION_CHECKLIMIT_MAX_DEVIATION:
                              case COMMUNICATION_CHECKLIMIT_MAX_DRIFT:
                              case COMMUNICATION_MOTION_LIMIT:
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendFloat(COMMUNICATION_SPI,0,g_Value.fFloat,2,0,0);
                              /*~T*/
                              return;
                              /*~-1*/
                              }
                              /*~E:F2217*/
                              /*~-1*/
                              }
                              /*~E:C2213*/
                              /*~-1*/
                              }
                              /*~E:I2212*/
                           /*~-1*/
                           }
                           /*~E:I2211*/
                        /*~-1*/
                        }
                        /*~E:I2210*/
                        /*~T*/
                        Communication_SendString(COMMUNICATION_SPI,"NAV",0,0);
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                     /*~-1*/
                     }
                     /*~E:I2205*/
                     /*~E:A2204*/
                     /*~A:2218*/
                     /*~+:iGVR - internal Command - GetVeRsion */
                     /*~I:2219*/
                     if (!strcmp(szCommand,"iGVR"))
                     /*~-1*/
                     {
                        /*~A:2220*/
                        /*~+:SPI-Debugging - nur zu Testzwecken*/
                        /*~I:2221*/
#ifdef DEVELOPMENT_SW
                        /*~T*/
                        CommunicationControl.ulSPICounter++;
                        /*~-1*/
#endif
                        /*~E:I2221*/
                        /*~E:A2220*/
                        /*~T*/
                        Parameter[0].nLong = Communication_GetLongParameter(0); 
                        /*~C:2222*/
                        switch (Parameter[0].nLong)
                        /*~-1*/
                        {
                           /*~F:2223*/
                           case 0:		// Hardware-Version
                           /*~-1*/
                           {
                              /*~T*/
                              Communication_SendString(COMMUNICATION_SPI,TEXT_HARDWARE_VERSION,0,0);
                              /*~T*/
                              break;
                           /*~-1*/
                           }
                           /*~E:F2223*/
                           /*~F:2224*/
                           case 1:		// Software-Version
                           /*~-1*/
                           {
                              /*~T*/
                              Communication_SendString(COMMUNICATION_SPI,TEXT_SOFTWARE_VERSION,0,0);
                              /*~T*/
                              break;
                           /*~-1*/
                           }
                           /*~E:F2224*/
                        /*~-1*/
                        }
                        /*~E:C2222*/
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                     /*~-1*/
                     }
                     /*~E:I2219*/
                     /*~E:A2218*/
                     /*~A:2225*/
                     /*~+:iLED - internal Command - LEDset*/
                     /*~I:2226*/
                     if (!strcmp(szCommand,"iLED"))
                     /*~-1*/
                     {
                        /*~A:2227*/
                        /*~+:SPI-Debugging - nur zu Testzwecken*/
                        /*~I:2228*/
#ifdef DEVELOPMENT_SW
                        /*~T*/
                        CommunicationControl.ulSPICounter++;
                        /*~-1*/
#endif
                        /*~E:I2228*/
                        /*~E:A2227*/
                        /*~I:2229*/
                        if (Communication_GetLongParameter(0))
                        /*~-1*/
                        {
                           /*~I:2230*/
#ifndef SYSTEM_CND_LEDS_4_DEBUG
                           /*~T*/
                           // Platinen-LED einschalten
                           P06 = 0;

                           /*~-1*/
#endif
                           /*~E:I2230*/
                        /*~-1*/
                        }
                        /*~O:I2229*/
                        /*~-2*/
                        else
                        {
                           /*~I:2231*/
#ifndef SYSTEM_CND_LEDS_4_DEBUG 
                           /*~T*/
                           // Platinen-LED ausschalten
                           P06 = 1;

                           /*~-1*/
#endif
                           /*~E:I2231*/
                        /*~-1*/
                        }
                        /*~E:I2229*/
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                        // byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                     /*~-1*/
                     }
                     /*~E:I2226*/
                     /*~E:A2225*/
                     /*~A:2232*/
                     /*~+:iSCS - internal Command - SetCheckSysnchronisation onoff */
                     /*~I:2233*/
                     if (!strcmp(szCommand,"iSCS"))
                     /*~-1*/
                     {
                        /*~A:2234*/
                        /*~+:SPI-Debugging - nur zu Testzwecken*/
                        /*~I:2235*/
#ifdef DEVELOPMENT_SW
                        /*~T*/
                        CommunicationControl.ulSPICounter++;
                        /*~-1*/
#endif
                        /*~E:I2235*/
                        /*~E:A2234*/
                        /*~I:2236*/
                        if (Communication_GetLongParameter(0))
                        /*~-1*/
                        {
                           /*~T*/
                           // Synchronisationspr�fung ausschalten
                           System_SetCheckSynchronisation(1);
                        /*~-1*/
                        }
                        /*~O:I2236*/
                        /*~-2*/
                        else
                        {
                           /*~T*/
                           // Synchronisationspr�fung einschalten
                           System_SetCheckSynchronisation(0);
                        /*~-1*/
                        }
                        /*~E:I2236*/
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                        // byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                     /*~-1*/
                     }
                     /*~E:I2233*/
                     /*~E:A2232*/
                     /*~I:2237*/
#ifdef MIT_TEACHIN_FUNKTION
                     /*~A:2238*/
                     /*~+:iTIS - internal Command - TeachInStatus*/
                     /*~I:2239*/
                     if (!strcmp(szCommand,"iTIS"))
                     /*~-1*/
                     {
                        /*~A:2240*/
                        /*~+:SPI-Debugging - nur zu Testzwecken*/
                        /*~I:2241*/
#ifdef DEVELOPMENT_SW
                        /*~T*/
                        CommunicationControl.ulSPICounter++;
                        /*~-1*/
#endif
                        /*~E:I2241*/
                        /*~E:A2240*/
                        /*~T*/
                        Communication_SendLong(COMMUNICATION_SPI,0,(long)Global.chTeachInStatus,0,1);

                        // TeachIn-Interface aufrufen
                        TeachIn_Interface((char)Communication_GetLongParameter(0));

                        /*~T*/
                        // Merker f�r ein interpretierbares Kommando setzen
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                     /*~-1*/
                     }
                     /*~E:I2239*/
                     /*~E:A2238*/
                     /*~-1*/
#endif
                     /*~E:I2237*/
                     /*~A:2242*/
                     /*~+:iTSY - internal Command - TimerSYnchronize*/
                     /*~I:2243*/
                     if (!strcmp(szCommand,"iTSY"))
                     /*~-1*/
                     {
                        /*~A:2244*/
                        /*~+:Variablendeklartionen*/
                        /*~T*/
                        long lTimerDeviation;
                        unsigned long ulOperatingTimePartner;
                        /*~E:A2244*/
                        /*~A:2245*/
                        /*~+:SPI-Debugging - nur zu Testzwecken*/
                        /*~I:2246*/
#ifdef DEVELOPMENT_SW
                        /*~T*/
                        CommunicationControl.ulSPICounter++;
                        /*~-1*/
#endif
                        /*~E:I2246*/
                        /*~E:A2245*/
                        /*~T*/
                        // Differenz der beiden Zeitgeber errechnen
                        ulOperatingTimePartner = (unsigned long)Communication_GetLongParameter(0);
                        lTimerDeviation = (long)OPERATINGHOURS - (long)ulOperatingTimePartner;

                        // Timerstand korrigieren
                        OPERATINGHOURS -= lTimerDeviation;
                        CUSTOMTIMER -= lTimerDeviation;

                        byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                     /*~-1*/
                     }
                     /*~E:I2243*/
                     /*~E:A2242*/
                     /*~A:2247*/
                     /*~+:iVDG - internal Command - ViewDiaGnosis*/
                     /*~I:2248*/
                     if (!strcmp(szCommand,"iVDG"))
                     /*~-1*/
                     {
                        /*~A:2249*/
                        /*~+:SPI-Debugging - nur zu Testzwecken*/
                        /*~I:2250*/
#ifdef DEVELOPMENT_SW
                        /*~T*/
                        CommunicationControl.ulSPICounter++;
                        /*~-1*/
#endif
                        /*~E:I2250*/
                        /*~E:A2249*/
                        /*~T*/
                        // Befehlsbest�tigung senden
                        Communication_SendSPICommand("OK");
                        /*~T*/
                        Diagnosis_PrintMemory();
                     /*~-1*/
                     }
                     /*~O:I2248*/
                     /*~-2*/
                     else
                     {
                        /*~T*/
                        //                     byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                     /*~-1*/
                     }
                     /*~E:I2248*/
                     /*~E:A2247*/
                     /*~K*/
                     /*~+:*/
                     /*~A:2251*/
                     /*~+:SPI-Debugging - nur zu Testzwecken*/
                     /*~I:2252*/
#ifdef DEVELOPMENT_SW
                     /*~I:2253*/
#ifdef SYSTEM_CND_ENABLE_SPI_DEBUGGING
                     /*~I:2254*/
                     if (CommunicationControl.bTestSPI == 1)
                     /*~-1*/
                     {
                        /*~I:2255*/
#ifdef SYSTEM_CND_ALL_SPI_COMMUNICATIONS
                        /*~T*/
                        // Nur zu Debugzwecken
                        sprintf(achString,"%s - S:%ld",szCommand,CommunicationControl.ulSPICounter);
                        Communication_SendString(COMMUNICATION_RS232,achString,0,1);
                        /*~O:I2255*/
                        /*~-1*/
#else
                        /*~I:2256*/
                        if (strlen(szCommand) != 4)
                        /*~-1*/
                        {
                           /*~T*/
                           // Nur zu Debugzwecken
                           sprintf(achString,"%s - S:%ld",szCommand,CommunicationControl.ulSPICounter);
                           Communication_SendString(COMMUNICATION_RS232,achString,0,1);
                        /*~-1*/
                        }
                        /*~E:I2256*/
                        /*~-1*/
#endif
                        /*~E:I2255*/
                     /*~-1*/
                     }
                     /*~E:I2254*/
                     /*~-1*/
#endif
                     /*~E:I2253*/
                     /*~-1*/
#endif
                     /*~E:I2252*/
                     /*~E:A2251*/
                     /*~-1*/
#endif
                     /*~E:I2151*/
                     /*~T*/
                     break;
                  /*~-1*/
                  }
                  /*~E:F2149*/
                  /*~E:A2148*/
               /*~-1*/
               }
               /*~E:C61*/
            /*~-1*/
            }
            /*~O:I60*/
            /*~-2*/
            else
            {
               /*~K*/
               /*~+:/~* Ge�ndert am 09.02.2022 *~/*/
               /*~T*/
               /* Else-Zweig von 'if ((Communication_IsCommunicationEnabled() != 0)||(strcmp(szCommand,"ENA") == 0)||(strcmp(szCommand,"CDL") == 0)||(CommunicationControl.chLine2Interprete != COMMUNICATION_RS232))' */

               byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
               /*~K*/
               /*~+:/~* Ende - Ge�ndert am 09.02.2022 *~/*/
            /*~-1*/
            }
            /*~E:I60*/
         /*~-1*/
         }
         /*~O:I59*/
         /*~-2*/
         else
         {
            /*~T*/
            /* Else-Zweig von 'if ((byChecksumError == FALSE)||(strcmp(szCommand,"CDL") == 0))' */
            byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
         /*~-1*/
         }
         /*~E:I59*/
         /*~I:2257*/
#ifdef OLD
         /*~A:2258*/
         /*~+:Eintrag in Diagnosespeicher vornehmen*/
         /*~I:2259*/
         if (ulDiagnosisEntry2Set)
         /*~-1*/
         {
            /*~T*/
            Diagnosis_WriteMessage2Flash(ulDiagnosisEntry2Set);
         /*~-1*/
         }
         /*~E:I2259*/
         /*~E:A2258*/
         /*~A:2260*/
         /*~+:Kommandostatus auswerten*/
         /*~C:2261*/
         switch (byCommandStatus)
         /*~-1*/
         {
            /*~F:2262*/
            case INSTRUCTIONDECODER_SEND_OK:	// Kommando wurde ordnungsgem�� interpretiert
            //case INSTRUCTIONDECODER_SEND_TEXT	// Beide Bedingungen identisch
            /*~-1*/
            {
               /*~A:2263*/
               /*~+:INSTRUCTIONDECODER_SEND_OK*/
               /*~I:2264*/
               if (CommunicationControl.chLine2Interprete == COMMUNICATION_RS232)
               /*~-1*/
               {
                  /*~I:2265*/
                  if (!SYSTEM_MRW_MANAGER)
                  /*~-1*/
                  {
                     /*~I:2266*/
#ifdef CHANNEL_0
                     /*~I:2267*/
                     if (lText2Send)
                     /*~-1*/
                     {
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                     /*~-1*/
                     }
                     /*~E:I2267*/
                     /*~-1*/
#endif
                     /*~E:I2266*/
                     /*~I:2268*/
#ifdef CHANNEL_1
                     /*~I:2269*/
                     if (bDoNotWriteResult2Buffer)
                     /*~-1*/
                     {
                        /*~I:2270*/
                        if (lText2Send)
                        /*~-1*/
                        {
                           /*~T*/
                           sprintf(szString2Send,"T%04ld",lText2Send);
                           /*~T*/
                           Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~-1*/
                        }
                        /*~O:I2270*/
                        /*~-2*/
                        else
                        {
                           /*~T*/
                           Communication_SendMessage(COMMUNICATION_RS232,COMMUNICATION_OK);
                        /*~-1*/
                        }
                        /*~E:I2270*/
                     /*~-1*/
                     }
                     /*~E:I2269*/
                     /*~-1*/
#endif
                     /*~E:I2268*/
                  /*~-1*/
                  }
                  /*~O:I2265*/
                  /*~-2*/
                  else
                  {
                     /*~I:2271*/
#ifdef CHANNEL_0
                     /*~T*/
                     Communication_SendMessage(COMMUNICATION_RS232,COMMUNICATION_OK);
                     /*~-1*/
#endif
                     /*~E:I2271*/
                     /*~I:2272*/
#ifdef CHANNEL_1
                     /*~I:2273*/
                     if (bDoNotWriteResult2Buffer)
                     /*~-1*/
                     {
                        /*~T*/
                        Communication_SendMessage(COMMUNICATION_RS232,COMMUNICATION_OK);
                     /*~-1*/
                     }
                     /*~E:I2273*/
                     /*~-1*/
#endif
                     /*~E:I2272*/
                  /*~-1*/
                  }
                  /*~E:I2265*/
               /*~-1*/
               }
               /*~O:I2264*/
               /*~-2*/
               else
               {
                  /*~I:2274*/
                  if (CommunicationControl.chLine2Interprete == COMMUNICATION_SPI)
                  /*~-1*/
                  {
                     /*~T*/
                     // Befehlsbest�tigung senden
                     Communication_SendSPICommand("OK");
                  /*~-1*/
                  }
                  /*~E:I2274*/
               /*~-1*/
               }
               /*~E:I2264*/
               /*~T*/
               break;
               /*~E:A2263*/
            /*~-1*/
            }
            /*~E:F2262*/
            /*~F:2275*/
            case INSTRUCTIONDECODER_SEND_E001:			// Kanal existiert nicht
            /*~-1*/
            {
               /*~A:2276*/
               /*~+:INSTRUCTIONDECODER_SEND_E001*/
               /*~I:2277*/
               if (CommunicationControl.chLine2Interprete == COMMUNICATION_RS232)
               /*~-1*/
               {
                  /*~I:2278*/
                  if (!SYSTEM_MRW_MANAGER)
                  /*~-1*/
                  {
                     /*~I:2279*/
                     if (lText2Send)
                     /*~-1*/
                     {
                        /*~I:2280*/
#ifdef CHANNEL_0
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~-1*/
#endif
                        /*~E:I2280*/
                        /*~I:2281*/
#ifdef CHANNEL_1
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~-1*/
#endif
                        /*~E:I2281*/
                        /*~T*/
                        break;
                     /*~-1*/
                     }
                     /*~E:I2279*/
                  /*~-1*/
                  }
                  /*~E:I2278*/
                  /*~I:2282*/
#ifdef CHANNEL_0
                  /*~T*/
                  Communication_SendString(COMMUNICATION_RS232,TEXT_E001,1,0);
                  /*~-1*/
#endif
                  /*~E:I2282*/
                  /*~I:2283*/
#ifdef CHANNEL_1
                  /*~I:2284*/
                  if (bDoNotWriteResult2Buffer)
                  /*~-1*/
                  {
                     /*~T*/
                     Communication_SendString(COMMUNICATION_RS232,TEXT_E001,1,0);
                  /*~-1*/
                  }
                  /*~E:I2284*/
                  /*~-1*/
#endif
                  /*~E:I2283*/
               /*~-1*/
               }
               /*~O:I2277*/
               /*~-2*/
               else
               {
                  /*~T*/
                  // NotAcknowledge senden
                  byRetVal = ADuC836_SPISendChar(NAK);
               /*~-1*/
               }
               /*~E:I2277*/
               /*~T*/
               break;
               /*~E:A2276*/
            /*~-1*/
            }
            /*~E:F2275*/
            /*~F:2285*/
            case INSTRUCTIONDECODER_SEND_E002:			// Fehler in Parameterlist
            /*~-1*/
            {
               /*~A:2286*/
               /*~+:INSTRUCTIONDECODER_SEND_E002*/
               /*~I:2287*/
               if (CommunicationControl.chLine2Interprete == COMMUNICATION_RS232)
               /*~-1*/
               {
                  /*~I:2288*/
                  if (!SYSTEM_MRW_MANAGER)
                  /*~-1*/
                  {
                     /*~I:2289*/
                     if (lText2Send)
                     /*~-1*/
                     {
                        /*~I:2290*/
#ifdef CHANNEL_0
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~-1*/
#endif
                        /*~E:I2290*/
                        /*~I:2291*/
#ifdef CHANNEL_1
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~-1*/
#endif
                        /*~E:I2291*/
                        /*~T*/
                        break;
                     /*~-1*/
                     }
                     /*~E:I2289*/
                  /*~-1*/
                  }
                  /*~E:I2288*/
                  /*~I:2292*/
#ifdef CHANNEL_0
                  /*~T*/
                  Communication_SendString(COMMUNICATION_RS232,TEXT_E002,1,0);
                  /*~-1*/
#endif
                  /*~E:I2292*/
                  /*~I:2293*/
#ifdef CHANNEL_1
                  /*~I:2294*/
                  if (bDoNotWriteResult2Buffer)
                  /*~-1*/
                  {
                     /*~T*/
                     Communication_SendString(COMMUNICATION_RS232,TEXT_E002,1,0);
                  /*~-1*/
                  }
                  /*~E:I2294*/
                  /*~-1*/
#endif
                  /*~E:I2293*/
               /*~-1*/
               }
               /*~O:I2287*/
               /*~-2*/
               else
               {
                  /*~T*/
                  // NotAcknowledge senden
                  byRetVal = ADuC836_SPISendChar(NAK);
               /*~-1*/
               }
               /*~E:I2287*/
               /*~T*/
               break;
               /*~E:A2286*/
            /*~-1*/
            }
            /*~E:F2285*/
            /*~F:2295*/
            case INSTRUCTIONDECODER_SEND_E003:			// ReadOnly-Fehler
            /*~-1*/
            {
               /*~A:2296*/
               /*~+:INSTRUCTIONDECODER_SEND_E003*/
               /*~I:2297*/
               if (CommunicationControl.chLine2Interprete == COMMUNICATION_RS232)
               /*~-1*/
               {
                  /*~I:2298*/
                  if (!SYSTEM_MRW_MANAGER)
                  /*~-1*/
                  {
                     /*~I:2299*/
                     if (lText2Send)
                     /*~-1*/
                     {
                        /*~I:2300*/
#ifdef CHANNEL_0
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~-1*/
#endif
                        /*~E:I2300*/
                        /*~I:2301*/
#ifdef CHANNEL_1
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~-1*/
#endif
                        /*~E:I2301*/
                        /*~T*/
                        break;
                     /*~-1*/
                     }
                     /*~E:I2299*/
                  /*~-1*/
                  }
                  /*~E:I2298*/
                  /*~I:2302*/
#ifdef CHANNEL_0
                  /*~T*/
                  Communication_SendString(COMMUNICATION_RS232,TEXT_E003,1,0);
                  /*~-1*/
#endif
                  /*~E:I2302*/
                  /*~I:2303*/
#ifdef CHANNEL_1
                  /*~I:2304*/
                  if (bDoNotWriteResult2Buffer)
                  /*~-1*/
                  {
                     /*~T*/
                     Communication_SendString(COMMUNICATION_RS232,TEXT_E003,1,0);
                  /*~-1*/
                  }
                  /*~E:I2304*/
                  /*~-1*/
#endif
                  /*~E:I2303*/
               /*~-1*/
               }
               /*~O:I2297*/
               /*~-2*/
               else
               {
                  /*~T*/
                  // NotAcknowledge senden
                  byRetVal = ADuC836_SPISendChar(NAK);
               /*~-1*/
               }
               /*~E:I2297*/
               /*~T*/
               break;
               /*~E:A2296*/
            /*~-1*/
            }
            /*~E:F2295*/
            /*~F:2305*/
            case INSTRUCTIONDECODER_SEND_E004:			// Kommando konnte nicht interpretiert werden
            /*~-1*/
            {
               /*~A:2306*/
               /*~+:INSTRUCTIONDECODER_SEND_E004*/
               /*~I:2307*/
               if (CommunicationControl.chLine2Interprete == COMMUNICATION_RS232)
               /*~-1*/
               {
                  /*~I:2308*/
                  if (!SYSTEM_MRW_MANAGER)
                  /*~-1*/
                  {
                     /*~I:2309*/
                     if (lText2Send)
                     /*~-1*/
                     {
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~T*/
                        break;
                     /*~-1*/
                     }
                     /*~E:I2309*/
                  /*~-1*/
                  }
                  /*~E:I2308*/
                  /*~I:2310*/
#ifdef CHANNEL_0
                  /*~T*/
                  Communication_SendString(COMMUNICATION_RS232,TEXT_E004,1,0);
                  /*~-1*/
#endif
                  /*~E:I2310*/
               /*~-1*/
               }
               /*~O:I2307*/
               /*~-2*/
               else
               {
                  /*~T*/
                  // NotAcknowledge senden
                  byRetVal = ADuC836_SPISendChar(NAK);
               /*~-1*/
               }
               /*~E:I2307*/
               /*~T*/
               break;
               /*~E:A2306*/
            /*~-1*/
            }
            /*~E:F2305*/
            /*~F:2311*/
            case INSTRUCTIONDECODER_SEND_E005:			// Kommunikationsfehler mit dem Partner
            /*~-1*/
            {
               /*~A:2312*/
               /*~+:INSTRUCTIONDECODER_SEND_E005*/
               /*~I:2313*/
               if (CommunicationControl.chLine2Interprete == COMMUNICATION_RS232)
               /*~-1*/
               {
                  /*~I:2314*/
                  if (!SYSTEM_MRW_MANAGER)
                  /*~-1*/
                  {
                     /*~I:2315*/
                     if (lText2Send)
                     /*~-1*/
                     {
                        /*~I:2316*/
#ifdef CHANNEL_0
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~-1*/
#endif
                        /*~E:I2316*/
                        /*~I:2317*/
#ifdef CHANNEL_1
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~-1*/
#endif
                        /*~E:I2317*/
                        /*~T*/
                        break;
                     /*~-1*/
                     }
                     /*~E:I2315*/
                  /*~-1*/
                  }
                  /*~E:I2314*/
                  /*~I:2318*/
#ifdef CHANNEL_0
                  /*~T*/
                  Communication_SendString(COMMUNICATION_RS232,TEXT_E005,1,0);
                  /*~-1*/
#endif
                  /*~E:I2318*/
                  /*~I:2319*/
#ifdef CHANNEL_1
                  /*~I:2320*/
                  if (bDoNotWriteResult2Buffer)
                  /*~-1*/
                  {
                     /*~T*/
                     Communication_SendString(COMMUNICATION_RS232,TEXT_E005,1,0);
                  /*~-1*/
                  }
                  /*~E:I2320*/
                  /*~-1*/
#endif
                  /*~E:I2319*/
               /*~-1*/
               }
               /*~O:I2313*/
               /*~-2*/
               else
               {
                  /*~T*/
                  // NotAcknowledge senden
                  byRetVal = ADuC836_SPISendChar(NAK);
               /*~-1*/
               }
               /*~E:I2313*/
               /*~T*/
               break;
               /*~E:A2312*/
            /*~-1*/
            }
            /*~E:F2311*/
            /*~F:2321*/
            case INSTRUCTIONDECODER_SEND_E006:			// Kommando noch nicht implementiert
            /*~-1*/
            {
               /*~A:2322*/
               /*~+:INSTRUCTIONDECODER_SEND_E006*/
               /*~I:2323*/
               if (CommunicationControl.chLine2Interprete == COMMUNICATION_RS232)
               /*~-1*/
               {
                  /*~I:2324*/
                  if (!SYSTEM_MRW_MANAGER)
                  /*~-1*/
                  {
                     /*~I:2325*/
                     if (lText2Send)
                     /*~-1*/
                     {
                        /*~I:2326*/
#ifdef CHANNEL_0
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~-1*/
#endif
                        /*~E:I2326*/
                        /*~I:2327*/
#ifdef CHANNEL_1
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~-1*/
#endif
                        /*~E:I2327*/
                        /*~T*/
                        break;
                     /*~-1*/
                     }
                     /*~E:I2325*/
                  /*~-1*/
                  }
                  /*~E:I2324*/
                  /*~I:2328*/
#ifdef CHANNEL_0
                  /*~T*/
                  Communication_SendString(COMMUNICATION_RS232,TEXT_E006,1,0);
                  /*~-1*/
#endif
                  /*~E:I2328*/
                  /*~I:2329*/
#ifdef CHANNEL_1
                  /*~I:2330*/
                  if (bDoNotWriteResult2Buffer)
                  /*~-1*/
                  {
                     /*~T*/
                     Communication_SendString(COMMUNICATION_RS232,TEXT_E006,1,0);
                  /*~-1*/
                  }
                  /*~E:I2330*/
                  /*~-1*/
#endif
                  /*~E:I2329*/
               /*~-1*/
               }
               /*~O:I2323*/
               /*~-2*/
               else
               {
                  /*~T*/
                  // NotAcknowledge senden
                  byRetVal = ADuC836_SPISendChar(NAK);
               /*~-1*/
               }
               /*~E:I2323*/
               /*~T*/
               break;
               /*~E:A2322*/
            /*~-1*/
            }
            /*~E:F2321*/
            /*~F:2331*/
            case INSTRUCTIONDECODER_SEND_E007:			// Parameter fehlt 
            /*~-1*/
            {
               /*~A:2332*/
               /*~+:INSTRUCTIONDECODER_SEND_E007*/
               /*~I:2333*/
               if (CommunicationControl.chLine2Interprete == COMMUNICATION_RS232)
               /*~-1*/
               {
                  /*~I:2334*/
                  if (!SYSTEM_MRW_MANAGER)
                  /*~-1*/
                  {
                     /*~I:2335*/
                     if (lText2Send)
                     /*~-1*/
                     {
                        /*~I:2336*/
#ifdef CHANNEL_0
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~-1*/
#endif
                        /*~E:I2336*/
                        /*~I:2337*/
#ifdef CHANNEL_1
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~-1*/
#endif
                        /*~E:I2337*/
                        /*~T*/
                        break;
                     /*~-1*/
                     }
                     /*~E:I2335*/
                  /*~-1*/
                  }
                  /*~E:I2334*/
                  /*~I:2338*/
#ifdef CHANNEL_0
                  /*~T*/
                  Communication_SendString(COMMUNICATION_RS232,TEXT_E007,1,0);
                  /*~-1*/
#endif
                  /*~E:I2338*/
                  /*~I:2339*/
#ifdef CHANNEL_1
                  /*~I:2340*/
                  if (bDoNotWriteResult2Buffer)
                  /*~-1*/
                  {
                     /*~T*/
                     Communication_SendString(COMMUNICATION_RS232,TEXT_E007,1,0);
                  /*~-1*/
                  }
                  /*~E:I2340*/
                  /*~-1*/
#endif
                  /*~E:I2339*/
               /*~-1*/
               }
               /*~O:I2333*/
               /*~-2*/
               else
               {
                  /*~T*/
                  // NotAcknowledge senden
                  byRetVal = ADuC836_SPISendChar(NAK);
               /*~-1*/
               }
               /*~E:I2333*/
               /*~T*/
               break;
               /*~E:A2332*/
            /*~-1*/
            }
            /*~E:F2331*/
            /*~F:2341*/
            case INSTRUCTIONDECODER_SEND_E008:			// Unerwartetes Zeichen im Kommandostring 
            /*~-1*/
            {
               /*~A:2342*/
               /*~+:INSTRUCTIONDECODER_SEND_E008*/
               /*~I:2343*/
               if (CommunicationControl.chLine2Interprete == COMMUNICATION_RS232)
               /*~-1*/
               {
                  /*~I:2344*/
                  if (!SYSTEM_MRW_MANAGER)
                  /*~-1*/
                  {
                     /*~I:2345*/
                     if (lText2Send)
                     /*~-1*/
                     {
                        /*~I:2346*/
#ifdef CHANNEL_0
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~-1*/
#endif
                        /*~E:I2346*/
                        /*~I:2347*/
#ifdef CHANNEL_1
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~-1*/
#endif
                        /*~E:I2347*/
                        /*~T*/
                        break;
                     /*~-1*/
                     }
                     /*~E:I2345*/
                  /*~-1*/
                  }
                  /*~E:I2344*/
                  /*~I:2348*/
#ifdef CHANNEL_0
                  /*~T*/
                  Communication_SendString(COMMUNICATION_RS232,TEXT_E008,1,0);
                  /*~-1*/
#endif
                  /*~E:I2348*/
                  /*~I:2349*/
#ifdef CHANNEL_1
                  /*~I:2350*/
                  if (bDoNotWriteResult2Buffer)
                  /*~-1*/
                  {
                     /*~T*/
                     Communication_SendString(COMMUNICATION_RS232,TEXT_E008,1,0);
                  /*~-1*/
                  }
                  /*~E:I2350*/
                  /*~-1*/
#endif
                  /*~E:I2349*/
               /*~-1*/
               }
               /*~O:I2343*/
               /*~-2*/
               else
               {
                  /*~T*/
                  // NotAcknowledge senden
                  byRetVal = ADuC836_SPISendChar(NAK);
               /*~-1*/
               }
               /*~E:I2343*/
               /*~T*/
               break;
               /*~E:A2342*/
            /*~-1*/
            }
            /*~E:F2341*/
            /*~F:2351*/
            case INSTRUCTIONDECODER_SEND_E009:			// Wert au�erhalb des Grenzwertes

            /*~-1*/
            {
               /*~A:2352*/
               /*~+:INSTRUCTIONDECODER_SEND_E009*/
               /*~I:2353*/
               if (CommunicationControl.chLine2Interprete == COMMUNICATION_RS232)
               /*~-1*/
               {
                  /*~I:2354*/
                  if (!SYSTEM_MRW_MANAGER)
                  /*~-1*/
                  {
                     /*~I:2355*/
                     if (lText2Send)
                     /*~-1*/
                     {
                        /*~I:2356*/
#ifdef CHANNEL_0
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~-1*/
#endif
                        /*~E:I2356*/
                        /*~I:2357*/
#ifdef CHANNEL_1
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~-1*/
#endif
                        /*~E:I2357*/
                        /*~T*/
                        break;
                     /*~-1*/
                     }
                     /*~E:I2355*/
                  /*~-1*/
                  }
                  /*~E:I2354*/
                  /*~I:2358*/
#ifdef CHANNEL_0
                  /*~T*/
                  Communication_SendString(COMMUNICATION_RS232,TEXT_E009,1,0);
                  /*~-1*/
#endif
                  /*~E:I2358*/
                  /*~I:2359*/
#ifdef CHANNEL_1
                  /*~I:2360*/
                  if (bDoNotWriteResult2Buffer)
                  /*~-1*/
                  {
                     /*~T*/
                     Communication_SendString(COMMUNICATION_RS232,TEXT_E009,1,0);
                  /*~-1*/
                  }
                  /*~E:I2360*/
                  /*~-1*/
#endif
                  /*~E:I2359*/
               /*~-1*/
               }
               /*~O:I2353*/
               /*~-2*/
               else
               {
                  /*~T*/
                  // NotAcknowledge senden
                  byRetVal = ADuC836_SPISendChar(NAK);
               /*~-1*/
               }
               /*~E:I2353*/
               /*~T*/
               break;
               /*~E:A2352*/
            /*~-1*/
            }
            /*~E:F2351*/
            /*~F:2361*/
            case INSTRUCTIONDECODER_SEND_E010:			// Drifterkennung l�uft (nur SLC)

            /*~-1*/
            {
               /*~A:2362*/
               /*~+:INSTRUCTIONDECODER_SEND_E010*/
               /*~I:2363*/
               if (CommunicationControl.chLine2Interprete == COMMUNICATION_RS232)
               /*~-1*/
               {
                  /*~I:2364*/
                  if (!SYSTEM_MRW_MANAGER)
                  /*~-1*/
                  {
                     /*~I:2365*/
                     if (lText2Send)
                     /*~-1*/
                     {
                        /*~I:2366*/
#ifdef CHANNEL_0
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~-1*/
#endif
                        /*~E:I2366*/
                        /*~I:2367*/
#ifdef CHANNEL_1
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~-1*/
#endif
                        /*~E:I2367*/
                        /*~T*/
                        break;
                     /*~-1*/
                     }
                     /*~E:I2365*/
                     /*~I:2368*/
#ifdef CHANNEL_0
                     /*~T*/
                     Communication_SendString(COMMUNICATION_RS232,TEXT_E010,1,0);
                     /*~-1*/
#endif
                     /*~E:I2368*/
                     /*~I:2369*/
#ifdef CHANNEL_1 
                     /*~I:2370*/
                     if (bDoNotWriteResult2Buffer)
                     /*~-1*/
                     {
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,TEXT_E010,1,0);
                     /*~-1*/
                     }
                     /*~E:I2370*/
                     /*~-1*/
#endif
                     /*~E:I2369*/
                  /*~-1*/
                  }
                  /*~E:I2364*/
               /*~-1*/
               }
               /*~O:I2363*/
               /*~-2*/
               else
               {
                  /*~T*/
                  // NotAcknowledge senden
                  byRetVal = ADuC836_SPISendChar(NAK);
               /*~-1*/
               }
               /*~E:I2363*/
               /*~T*/
               break;
               /*~E:A2362*/
            /*~-1*/
            }
            /*~E:F2361*/
            /*~F:2371*/
            case INSTRUCTIONDECODER_SEND_E011:			// Parameter der Partner sind unterschiedlich 
            /*~-1*/
            {
               /*~A:2372*/
               /*~+:INSTRUCTIONDECODER_SEND_E011*/
               /*~I:2373*/
               if (CommunicationControl.chLine2Interprete == COMMUNICATION_RS232)
               /*~-1*/
               {
                  /*~I:2374*/
                  if (!SYSTEM_MRW_MANAGER)
                  /*~-1*/
                  {
                     /*~I:2375*/
                     if (lText2Send)
                     /*~-1*/
                     {
                        /*~I:2376*/
#ifdef CHANNEL_0
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~-1*/
#endif
                        /*~E:I2376*/
                        /*~I:2377*/
#ifdef CHANNEL_1
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~-1*/
#endif
                        /*~E:I2377*/
                        /*~T*/
                        break;
                     /*~-1*/
                     }
                     /*~E:I2375*/
                  /*~-1*/
                  }
                  /*~E:I2374*/
                  /*~I:2378*/
#ifdef CHANNEL_0
                  /*~T*/
                  Communication_SendString(COMMUNICATION_RS232,TEXT_E011,1,0);
                  /*~-1*/
#endif
                  /*~E:I2378*/
                  /*~I:2379*/
#ifdef CHANNEL_1 
                  /*~I:2380*/
                  if (bDoNotWriteResult2Buffer)
                  /*~-1*/
                  {
                     /*~T*/
                     Communication_SendString(COMMUNICATION_RS232,TEXT_E011,1,0);
                  /*~-1*/
                  }
                  /*~E:I2380*/
                  /*~-1*/
#endif
                  /*~E:I2379*/
               /*~-1*/
               }
               /*~O:I2373*/
               /*~-2*/
               else
               {
                  /*~T*/
                  // NotAcknowledge senden
                  byRetVal = ADuC836_SPISendChar(NAK);
               /*~-1*/
               }
               /*~E:I2373*/
               /*~T*/
               break;
               /*~E:A2372*/
            /*~-1*/
            }
            /*~E:F2371*/
            /*~F:2381*/
            case INSTRUCTIONDECODER_SEND_E012:			// Checksummenfehler
            /*~-1*/
            {
               /*~A:2382*/
               /*~+:INSTRUCTIONDECODER_SEND_E012*/
               /*~I:2383*/
               if (CommunicationControl.chLine2Interprete == COMMUNICATION_RS232)
               /*~-1*/
               {
                  /*~I:2384*/
                  if (!SYSTEM_MRW_MANAGER)
                  /*~-1*/
                  {
                     /*~I:2385*/
                     if (lText2Send)
                     /*~-1*/
                     {
                        /*~I:2386*/
#ifdef CHANNEL_0
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~-1*/
#endif
                        /*~E:I2386*/
                        /*~I:2387*/
#ifdef CHANNEL_1
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~-1*/
#endif
                        /*~E:I2387*/
                        /*~T*/
                        break;
                     /*~-1*/
                     }
                     /*~E:I2385*/
                  /*~-1*/
                  }
                  /*~E:I2384*/
                  /*~T*/
                  Communication_SendString(COMMUNICATION_RS232,TEXT_E012,1,0);
               /*~-1*/
               }
               /*~O:I2383*/
               /*~-2*/
               else
               {
                  /*~T*/
                  // NotAcknowledge senden
                  byRetVal = ADuC836_SPISendChar(NAK);
               /*~-1*/
               }
               /*~E:I2383*/
               /*~T*/
               break;
               /*~E:A2382*/
            /*~-1*/
            }
            /*~E:F2381*/
            /*~F:2388*/
            case INSTRUCTIONDECODER_SEND_NOK:			// NOK senden
            /*~-1*/
            {
               /*~A:2389*/
               /*~+:INSTRUCTIONDECODER_SEND_NOK*/
               /*~I:2390*/
               if (CommunicationControl.chLine2Interprete == COMMUNICATION_RS232)
               /*~-1*/
               {
                  /*~I:2391*/
                  if (!SYSTEM_MRW_MANAGER)
                  /*~-1*/
                  {
                     /*~I:2392*/
                     if (lText2Send)
                     /*~-1*/
                     {
                        /*~A:2393*/
                        /*~+:RS232-Ausgabe*/
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~E:A2393*/
                        /*~T*/
                        break;
                     /*~-1*/
                     }
                     /*~E:I2392*/
                  /*~-1*/
                  }
                  /*~E:I2391*/
                  /*~A:2394*/
                  /*~+:RS232-Ausgabe*/
                  /*~T*/
                  Communication_SendMessage(COMMUNICATION_RS232,COMMUNICATION_NOK);
                  /*~E:A2394*/
               /*~-1*/
               }
               /*~E:I2390*/
               /*~T*/
               break;
               /*~E:A2389*/
            /*~-1*/
            }
            /*~E:F2388*/
            /*~F:2395*/
            case INSTRUCTIONDECODER_SEND_NOTHING:
            /*~-1*/
            {
               /*~T*/
               break;
            /*~-1*/
            }
            /*~E:F2395*/
         /*~-1*/
         }
         /*~E:C2261*/
         /*~I:2396*/
#ifdef CHANNEL_1
         /*~I:2397*/
         if (!bDoNotWriteResult2Buffer)
         /*~-1*/
         {
            /*~T*/
            bDoNotWriteResult2Buffer = 1;

            g_byLastCommandExecutionResult = byCommandStatus;
         /*~-1*/
         }
         /*~E:I2397*/
         /*~-1*/
#endif
         /*~E:I2396*/
         /*~E:A2260*/
         /*~-1*/
#endif
         /*~E:I2257*/
         /*~A:2398*/
         /*~+:Eintrag in Diagnosespeicher vornehmen*/
         /*~I:2399*/
#ifdef CHANNEL_0
         /*~A:2400*/
         /*~+:Kanal 0*/
         /*~I:2401*/
         if (ulDiagnosisEntry2Set)
         /*~-1*/
         {
            /*~T*/
            Diagnosis_WriteMessage2Flash(ulDiagnosisEntry2Set);
         /*~-1*/
         }
         /*~E:I2401*/
         /*~E:A2400*/
         /*~-1*/
#endif
         /*~E:I2399*/
         /*~I:2402*/
#ifdef CHANNEL_1
         /*~A:2403*/
         /*~+:Kanal 1*/
         /*~I:2404*/
         if (ulDiagnosisEntry2Set)
         /*~-1*/
         {
            /*~I:2405*/
            if (bDoNotWriteResult2Buffer)
            /*~-1*/
            {
               /*~T*/
               Diagnosis_WriteMessage2Flash(ulDiagnosisEntry2Set);
            /*~-1*/
            }
            /*~O:I2405*/
            /*~-2*/
            else
            {
               /*~T*/
               ulDiagnosisEntry2SetAtiGRS = ulDiagnosisEntry2Set;
            /*~-1*/
            }
            /*~E:I2405*/
         /*~-1*/
         }
         /*~E:I2404*/
         /*~E:A2403*/
         /*~-1*/
#endif
         /*~E:I2402*/
         /*~E:A2398*/
         /*~A:2406*/
         /*~+:Kommandostatus auswerten*/
         /*~C:2407*/
         switch (byCommandStatus)
         /*~-1*/
         {
            /*~F:2408*/
            case INSTRUCTIONDECODER_SEND_OK:	// Kommando wurde ordnungsgem�� interpretiert
            //case INSTRUCTIONDECODER_SEND_TEXT	// Beide Bedingungen identisch
            /*~-1*/
            {
               /*~A:2409*/
               /*~+:INSTRUCTIONDECODER_SEND_OK*/
               /*~I:2410*/
               if (CommunicationControl.chLine2Interprete == COMMUNICATION_RS232)
               /*~-1*/
               {
                  /*~I:2411*/
                  if (!SYSTEM_MRW_MANAGER)
                  /*~-1*/
                  {
                     /*~I:2412*/
#ifdef CHANNEL_0
                     /*~I:2413*/
                     if (lText2Send)
                     /*~-1*/
                     {
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                     /*~-1*/
                     }
                     /*~E:I2413*/
                     /*~-1*/
#endif
                     /*~E:I2412*/
                     /*~I:2414*/
#ifdef CHANNEL_1
                     /*~I:2415*/
                     if (bDoNotWriteResult2Buffer)
                     /*~-1*/
                     {
                        /*~I:2416*/
                        if (lText2Send)
                        /*~-1*/
                        {
                           /*~T*/
                           sprintf(szString2Send,"T%04ld",lText2Send);
                           /*~T*/
                           Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~-1*/
                        }
                        /*~O:I2416*/
                        /*~-2*/
                        else
                        {
                           /*~T*/
                           Communication_SendMessage(COMMUNICATION_RS232,COMMUNICATION_OK);
                        /*~-1*/
                        }
                        /*~E:I2416*/
                     /*~-1*/
                     }
                     /*~E:I2415*/
                     /*~-1*/
#endif
                     /*~E:I2414*/
                  /*~-1*/
                  }
                  /*~O:I2411*/
                  /*~-2*/
                  else
                  {
                     /*~I:2417*/
#ifdef CHANNEL_0
                     /*~T*/
                     Communication_SendMessage(COMMUNICATION_RS232,COMMUNICATION_OK);
                     /*~-1*/
#endif
                     /*~E:I2417*/
                     /*~I:2418*/
#ifdef CHANNEL_1
                     /*~I:2419*/
                     if (bDoNotWriteResult2Buffer)
                     /*~-1*/
                     {
                        /*~T*/
                        Communication_SendMessage(COMMUNICATION_RS232,COMMUNICATION_OK);
                     /*~-1*/
                     }
                     /*~E:I2419*/
                     /*~-1*/
#endif
                     /*~E:I2418*/
                  /*~-1*/
                  }
                  /*~E:I2411*/
                  /*~K*/
                  /*~+:/~* Hinzugef�gt am 09.02.2022 *~/*/
                  /*~I:2420*/
#ifdef CHANNEL_0 
                  /*~I:2421*/
                  if (lText2Send == TEXT_RETAIN_VARIABLES_REORGANIZED)
                  /*~-1*/
                  {
                     /*~T*/
                     // Reset nach der Reorganisation der Retain-Variablen ausf�hren
                     /*~I:2422*/
#ifndef DEVELOPMENT_SW	/* Nur definiert in der Debug-Version */ 
                     /*~T*/
                     System_Reset();
                     /*~-1*/
#endif
                     /*~E:I2422*/
                  /*~-1*/
                  }
                  /*~E:I2421*/
                  /*~-1*/
#endif
                  /*~E:I2420*/
                  /*~K*/
                  /*~+:/~* Ende - Hinzugef�gt am 09.02.2022 *~/*/
               /*~-1*/
               }
               /*~O:I2410*/
               /*~-2*/
               else
               {
                  /*~I:2423*/
                  if (CommunicationControl.chLine2Interprete == COMMUNICATION_SPI)
                  /*~-1*/
                  {
                     /*~T*/
                     // Befehlsbest�tigung senden
                     Communication_SendSPICommand("OK");
                  /*~-1*/
                  }
                  /*~E:I2423*/
               /*~-1*/
               }
               /*~E:I2410*/
               /*~T*/
               break;
               /*~E:A2409*/
            /*~-1*/
            }
            /*~E:F2408*/
            /*~F:2424*/
            case INSTRUCTIONDECODER_SEND_E001:			// Kanal existiert nicht
            /*~-1*/
            {
               /*~A:2425*/
               /*~+:INSTRUCTIONDECODER_SEND_E001*/
               /*~I:2426*/
               if (CommunicationControl.chLine2Interprete == COMMUNICATION_RS232)
               /*~-1*/
               {
                  /*~I:2427*/
                  if (!SYSTEM_MRW_MANAGER)
                  /*~-1*/
                  {
                     /*~I:2428*/
                     if (lText2Send)
                     /*~-1*/
                     {
                        /*~I:2429*/
#ifdef CHANNEL_0
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~-1*/
#endif
                        /*~E:I2429*/
                        /*~I:2430*/
#ifdef CHANNEL_1
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~-1*/
#endif
                        /*~E:I2430*/
                        /*~T*/
                        break;
                     /*~-1*/
                     }
                     /*~E:I2428*/
                  /*~-1*/
                  }
                  /*~E:I2427*/
                  /*~I:2431*/
#ifdef CHANNEL_0
                  /*~T*/
                  Communication_SendString(COMMUNICATION_RS232,TEXT_E001,1,0);
                  /*~-1*/
#endif
                  /*~E:I2431*/
                  /*~I:2432*/
#ifdef CHANNEL_1
                  /*~I:2433*/
                  if (bDoNotWriteResult2Buffer)
                  /*~-1*/
                  {
                     /*~T*/
                     Communication_SendString(COMMUNICATION_RS232,TEXT_E001,1,0);
                  /*~-1*/
                  }
                  /*~E:I2433*/
                  /*~-1*/
#endif
                  /*~E:I2432*/
               /*~-1*/
               }
               /*~O:I2426*/
               /*~-2*/
               else
               {
                  /*~T*/
                  // NotAcknowledge senden
                  byRetVal = ADuC836_SPISendChar(NAK);
               /*~-1*/
               }
               /*~E:I2426*/
               /*~T*/
               break;
               /*~E:A2425*/
            /*~-1*/
            }
            /*~E:F2424*/
            /*~F:2434*/
            case INSTRUCTIONDECODER_SEND_E002:			// Fehler in Parameterlist
            /*~-1*/
            {
               /*~A:2435*/
               /*~+:INSTRUCTIONDECODER_SEND_E002*/
               /*~I:2436*/
               if (CommunicationControl.chLine2Interprete == COMMUNICATION_RS232)
               /*~-1*/
               {
                  /*~I:2437*/
                  if (!SYSTEM_MRW_MANAGER)
                  /*~-1*/
                  {
                     /*~I:2438*/
                     if (lText2Send)
                     /*~-1*/
                     {
                        /*~I:2439*/
#ifdef CHANNEL_0
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~-1*/
#endif
                        /*~E:I2439*/
                        /*~I:2440*/
#ifdef CHANNEL_1
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~-1*/
#endif
                        /*~E:I2440*/
                        /*~T*/
                        break;
                     /*~-1*/
                     }
                     /*~E:I2438*/
                  /*~-1*/
                  }
                  /*~E:I2437*/
                  /*~I:2441*/
#ifdef CHANNEL_0
                  /*~T*/
                  Communication_SendString(COMMUNICATION_RS232,TEXT_E002,1,0);
                  /*~-1*/
#endif
                  /*~E:I2441*/
                  /*~I:2442*/
#ifdef CHANNEL_1
                  /*~I:2443*/
                  if (bDoNotWriteResult2Buffer)
                  /*~-1*/
                  {
                     /*~T*/
                     Communication_SendString(COMMUNICATION_RS232,TEXT_E002,1,0);
                  /*~-1*/
                  }
                  /*~E:I2443*/
                  /*~-1*/
#endif
                  /*~E:I2442*/
               /*~-1*/
               }
               /*~O:I2436*/
               /*~-2*/
               else
               {
                  /*~T*/
                  // NotAcknowledge senden
                  byRetVal = ADuC836_SPISendChar(NAK);
               /*~-1*/
               }
               /*~E:I2436*/
               /*~T*/
               break;
               /*~E:A2435*/
            /*~-1*/
            }
            /*~E:F2434*/
            /*~F:2444*/
            case INSTRUCTIONDECODER_SEND_E003:			// ReadOnly-Fehler
            /*~-1*/
            {
               /*~A:2445*/
               /*~+:INSTRUCTIONDECODER_SEND_E003*/
               /*~I:2446*/
               if (CommunicationControl.chLine2Interprete == COMMUNICATION_RS232)
               /*~-1*/
               {
                  /*~I:2447*/
                  if (!SYSTEM_MRW_MANAGER)
                  /*~-1*/
                  {
                     /*~I:2448*/
                     if (lText2Send)
                     /*~-1*/
                     {
                        /*~I:2449*/
#ifdef CHANNEL_0
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~-1*/
#endif
                        /*~E:I2449*/
                        /*~I:2450*/
#ifdef CHANNEL_1
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~-1*/
#endif
                        /*~E:I2450*/
                        /*~T*/
                        break;
                     /*~-1*/
                     }
                     /*~E:I2448*/
                  /*~-1*/
                  }
                  /*~E:I2447*/
                  /*~I:2451*/
#ifdef CHANNEL_0
                  /*~T*/
                  Communication_SendString(COMMUNICATION_RS232,TEXT_E003,1,0);
                  /*~-1*/
#endif
                  /*~E:I2451*/
                  /*~I:2452*/
#ifdef CHANNEL_1
                  /*~I:2453*/
                  if (bDoNotWriteResult2Buffer)
                  /*~-1*/
                  {
                     /*~T*/
                     Communication_SendString(COMMUNICATION_RS232,TEXT_E003,1,0);
                  /*~-1*/
                  }
                  /*~E:I2453*/
                  /*~-1*/
#endif
                  /*~E:I2452*/
               /*~-1*/
               }
               /*~O:I2446*/
               /*~-2*/
               else
               {
                  /*~T*/
                  // NotAcknowledge senden
                  byRetVal = ADuC836_SPISendChar(NAK);
               /*~-1*/
               }
               /*~E:I2446*/
               /*~T*/
               break;
               /*~E:A2445*/
            /*~-1*/
            }
            /*~E:F2444*/
            /*~F:2454*/
            case INSTRUCTIONDECODER_SEND_E004:			// Kommando konnte nicht interpretiert werden
            /*~-1*/
            {
               /*~A:2455*/
               /*~+:INSTRUCTIONDECODER_SEND_E004*/
               /*~I:2456*/
               if (CommunicationControl.chLine2Interprete == COMMUNICATION_RS232)
               /*~-1*/
               {
                  /*~I:2457*/
                  if (!SYSTEM_MRW_MANAGER)
                  /*~-1*/
                  {
                     /*~I:2458*/
                     if (lText2Send)
                     /*~-1*/
                     {
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~T*/
                        break;
                     /*~-1*/
                     }
                     /*~E:I2458*/
                  /*~-1*/
                  }
                  /*~E:I2457*/
                  /*~I:2459*/
#ifdef CHANNEL_0
                  /*~T*/
                  Communication_SendString(COMMUNICATION_RS232,TEXT_E004,1,0);
                  /*~-1*/
#endif
                  /*~E:I2459*/
               /*~-1*/
               }
               /*~O:I2456*/
               /*~-2*/
               else
               {
                  /*~T*/
                  // NotAcknowledge senden
                  byRetVal = ADuC836_SPISendChar(NAK);
               /*~-1*/
               }
               /*~E:I2456*/
               /*~T*/
               break;
               /*~E:A2455*/
            /*~-1*/
            }
            /*~E:F2454*/
            /*~F:2460*/
            case INSTRUCTIONDECODER_SEND_E005:			// Kommunikationsfehler mit dem Partner
            /*~-1*/
            {
               /*~A:2461*/
               /*~+:INSTRUCTIONDECODER_SEND_E005*/
               /*~I:2462*/
               if (CommunicationControl.chLine2Interprete == COMMUNICATION_RS232)
               /*~-1*/
               {
                  /*~I:2463*/
                  if (!SYSTEM_MRW_MANAGER)
                  /*~-1*/
                  {
                     /*~I:2464*/
                     if (lText2Send)
                     /*~-1*/
                     {
                        /*~I:2465*/
#ifdef CHANNEL_0
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~-1*/
#endif
                        /*~E:I2465*/
                        /*~I:2466*/
#ifdef CHANNEL_1
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~-1*/
#endif
                        /*~E:I2466*/
                        /*~T*/
                        break;
                     /*~-1*/
                     }
                     /*~E:I2464*/
                  /*~-1*/
                  }
                  /*~E:I2463*/
                  /*~I:2467*/
#ifdef CHANNEL_0
                  /*~T*/
                  Communication_SendString(COMMUNICATION_RS232,TEXT_E005,1,0);
                  /*~-1*/
#endif
                  /*~E:I2467*/
                  /*~I:2468*/
#ifdef CHANNEL_1
                  /*~I:2469*/
                  if (bDoNotWriteResult2Buffer)
                  /*~-1*/
                  {
                     /*~T*/
                     Communication_SendString(COMMUNICATION_RS232,TEXT_E005,1,0);
                  /*~-1*/
                  }
                  /*~E:I2469*/
                  /*~-1*/
#endif
                  /*~E:I2468*/
               /*~-1*/
               }
               /*~O:I2462*/
               /*~-2*/
               else
               {
                  /*~T*/
                  // NotAcknowledge senden
                  byRetVal = ADuC836_SPISendChar(NAK);
               /*~-1*/
               }
               /*~E:I2462*/
               /*~T*/
               break;
               /*~E:A2461*/
            /*~-1*/
            }
            /*~E:F2460*/
            /*~F:2470*/
            case INSTRUCTIONDECODER_SEND_E006:			// Kommando noch nicht implementiert
            /*~-1*/
            {
               /*~A:2471*/
               /*~+:INSTRUCTIONDECODER_SEND_E006*/
               /*~I:2472*/
               if (CommunicationControl.chLine2Interprete == COMMUNICATION_RS232)
               /*~-1*/
               {
                  /*~I:2473*/
                  if (!SYSTEM_MRW_MANAGER)
                  /*~-1*/
                  {
                     /*~I:2474*/
                     if (lText2Send)
                     /*~-1*/
                     {
                        /*~I:2475*/
#ifdef CHANNEL_0
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~-1*/
#endif
                        /*~E:I2475*/
                        /*~I:2476*/
#ifdef CHANNEL_1
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~-1*/
#endif
                        /*~E:I2476*/
                        /*~T*/
                        break;
                     /*~-1*/
                     }
                     /*~E:I2474*/
                  /*~-1*/
                  }
                  /*~E:I2473*/
                  /*~I:2477*/
#ifdef CHANNEL_0
                  /*~T*/
                  Communication_SendString(COMMUNICATION_RS232,TEXT_E006,1,0);
                  /*~-1*/
#endif
                  /*~E:I2477*/
                  /*~I:2478*/
#ifdef CHANNEL_1
                  /*~I:2479*/
                  if (bDoNotWriteResult2Buffer)
                  /*~-1*/
                  {
                     /*~T*/
                     Communication_SendString(COMMUNICATION_RS232,TEXT_E006,1,0);
                  /*~-1*/
                  }
                  /*~E:I2479*/
                  /*~-1*/
#endif
                  /*~E:I2478*/
               /*~-1*/
               }
               /*~O:I2472*/
               /*~-2*/
               else
               {
                  /*~T*/
                  // NotAcknowledge senden
                  byRetVal = ADuC836_SPISendChar(NAK);
               /*~-1*/
               }
               /*~E:I2472*/
               /*~T*/
               break;
               /*~E:A2471*/
            /*~-1*/
            }
            /*~E:F2470*/
            /*~F:2480*/
            case INSTRUCTIONDECODER_SEND_E007:			// Parameter fehlt 
            /*~-1*/
            {
               /*~A:2481*/
               /*~+:INSTRUCTIONDECODER_SEND_E007*/
               /*~I:2482*/
               if (CommunicationControl.chLine2Interprete == COMMUNICATION_RS232)
               /*~-1*/
               {
                  /*~I:2483*/
                  if (!SYSTEM_MRW_MANAGER)
                  /*~-1*/
                  {
                     /*~I:2484*/
                     if (lText2Send)
                     /*~-1*/
                     {
                        /*~I:2485*/
#ifdef CHANNEL_0
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~-1*/
#endif
                        /*~E:I2485*/
                        /*~I:2486*/
#ifdef CHANNEL_1
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~-1*/
#endif
                        /*~E:I2486*/
                        /*~T*/
                        break;
                     /*~-1*/
                     }
                     /*~E:I2484*/
                  /*~-1*/
                  }
                  /*~E:I2483*/
                  /*~I:2487*/
#ifdef CHANNEL_0
                  /*~T*/
                  Communication_SendString(COMMUNICATION_RS232,TEXT_E007,1,0);
                  /*~-1*/
#endif
                  /*~E:I2487*/
                  /*~I:2488*/
#ifdef CHANNEL_1
                  /*~I:2489*/
                  if (bDoNotWriteResult2Buffer)
                  /*~-1*/
                  {
                     /*~T*/
                     Communication_SendString(COMMUNICATION_RS232,TEXT_E007,1,0);
                  /*~-1*/
                  }
                  /*~E:I2489*/
                  /*~-1*/
#endif
                  /*~E:I2488*/
               /*~-1*/
               }
               /*~O:I2482*/
               /*~-2*/
               else
               {
                  /*~T*/
                  // NotAcknowledge senden
                  byRetVal = ADuC836_SPISendChar(NAK);
               /*~-1*/
               }
               /*~E:I2482*/
               /*~T*/
               break;
               /*~E:A2481*/
            /*~-1*/
            }
            /*~E:F2480*/
            /*~F:2490*/
            case INSTRUCTIONDECODER_SEND_E008:			// Unerwartetes Zeichen im Kommandostring 
            /*~-1*/
            {
               /*~A:2491*/
               /*~+:INSTRUCTIONDECODER_SEND_E008*/
               /*~I:2492*/
               if (CommunicationControl.chLine2Interprete == COMMUNICATION_RS232)
               /*~-1*/
               {
                  /*~I:2493*/
                  if (!SYSTEM_MRW_MANAGER)
                  /*~-1*/
                  {
                     /*~I:2494*/
                     if (lText2Send)
                     /*~-1*/
                     {
                        /*~I:2495*/
#ifdef CHANNEL_0
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~-1*/
#endif
                        /*~E:I2495*/
                        /*~I:2496*/
#ifdef CHANNEL_1
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~-1*/
#endif
                        /*~E:I2496*/
                        /*~T*/
                        break;
                     /*~-1*/
                     }
                     /*~E:I2494*/
                  /*~-1*/
                  }
                  /*~E:I2493*/
                  /*~I:2497*/
#ifdef CHANNEL_0
                  /*~T*/
                  Communication_SendString(COMMUNICATION_RS232,TEXT_E008,1,0);
                  /*~-1*/
#endif
                  /*~E:I2497*/
                  /*~I:2498*/
#ifdef CHANNEL_1
                  /*~I:2499*/
                  if (bDoNotWriteResult2Buffer)
                  /*~-1*/
                  {
                     /*~T*/
                     Communication_SendString(COMMUNICATION_RS232,TEXT_E008,1,0);
                  /*~-1*/
                  }
                  /*~E:I2499*/
                  /*~-1*/
#endif
                  /*~E:I2498*/
               /*~-1*/
               }
               /*~O:I2492*/
               /*~-2*/
               else
               {
                  /*~T*/
                  // NotAcknowledge senden
                  byRetVal = ADuC836_SPISendChar(NAK);
               /*~-1*/
               }
               /*~E:I2492*/
               /*~T*/
               break;
               /*~E:A2491*/
            /*~-1*/
            }
            /*~E:F2490*/
            /*~F:2500*/
            case INSTRUCTIONDECODER_SEND_E009:			// Wert au�erhalb des Grenzwertes

            /*~-1*/
            {
               /*~A:2501*/
               /*~+:INSTRUCTIONDECODER_SEND_E009*/
               /*~I:2502*/
               if (CommunicationControl.chLine2Interprete == COMMUNICATION_RS232)
               /*~-1*/
               {
                  /*~I:2503*/
                  if (!SYSTEM_MRW_MANAGER)
                  /*~-1*/
                  {
                     /*~I:2504*/
                     if (lText2Send)
                     /*~-1*/
                     {
                        /*~I:2505*/
#ifdef CHANNEL_0
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~-1*/
#endif
                        /*~E:I2505*/
                        /*~I:2506*/
#ifdef CHANNEL_1
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~-1*/
#endif
                        /*~E:I2506*/
                        /*~T*/
                        break;
                     /*~-1*/
                     }
                     /*~E:I2504*/
                  /*~-1*/
                  }
                  /*~E:I2503*/
                  /*~I:2507*/
#ifdef CHANNEL_0
                  /*~T*/
                  Communication_SendString(COMMUNICATION_RS232,TEXT_E009,1,0);
                  /*~-1*/
#endif
                  /*~E:I2507*/
                  /*~I:2508*/
#ifdef CHANNEL_1
                  /*~I:2509*/
                  if (bDoNotWriteResult2Buffer)
                  /*~-1*/
                  {
                     /*~T*/
                     Communication_SendString(COMMUNICATION_RS232,TEXT_E009,1,0);
                  /*~-1*/
                  }
                  /*~E:I2509*/
                  /*~-1*/
#endif
                  /*~E:I2508*/
               /*~-1*/
               }
               /*~O:I2502*/
               /*~-2*/
               else
               {
                  /*~T*/
                  // NotAcknowledge senden
                  byRetVal = ADuC836_SPISendChar(NAK);
               /*~-1*/
               }
               /*~E:I2502*/
               /*~T*/
               break;
               /*~E:A2501*/
            /*~-1*/
            }
            /*~E:F2500*/
            /*~F:2510*/
            case INSTRUCTIONDECODER_SEND_E010:			// Drifterkennung l�uft (nur SLC)

            /*~-1*/
            {
               /*~A:2511*/
               /*~+:INSTRUCTIONDECODER_SEND_E010*/
               /*~I:2512*/
               if (CommunicationControl.chLine2Interprete == COMMUNICATION_RS232)
               /*~-1*/
               {
                  /*~I:2513*/
                  if (!SYSTEM_MRW_MANAGER)
                  /*~-1*/
                  {
                     /*~I:2514*/
                     if (lText2Send)
                     /*~-1*/
                     {
                        /*~I:2515*/
#ifdef CHANNEL_0
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~-1*/
#endif
                        /*~E:I2515*/
                        /*~I:2516*/
#ifdef CHANNEL_1
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~-1*/
#endif
                        /*~E:I2516*/
                        /*~T*/
                        break;
                     /*~-1*/
                     }
                     /*~E:I2514*/
                     /*~I:2517*/
#ifdef CHANNEL_0
                     /*~T*/
                     Communication_SendString(COMMUNICATION_RS232,TEXT_E010,1,0);
                     /*~-1*/
#endif
                     /*~E:I2517*/
                     /*~I:2518*/
#ifdef CHANNEL_1 
                     /*~I:2519*/
                     if (bDoNotWriteResult2Buffer)
                     /*~-1*/
                     {
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,TEXT_E010,1,0);
                     /*~-1*/
                     }
                     /*~E:I2519*/
                     /*~-1*/
#endif
                     /*~E:I2518*/
                  /*~-1*/
                  }
                  /*~E:I2513*/
               /*~-1*/
               }
               /*~O:I2512*/
               /*~-2*/
               else
               {
                  /*~T*/
                  // NotAcknowledge senden
                  byRetVal = ADuC836_SPISendChar(NAK);
               /*~-1*/
               }
               /*~E:I2512*/
               /*~T*/
               break;
               /*~E:A2511*/
            /*~-1*/
            }
            /*~E:F2510*/
            /*~F:2520*/
            case INSTRUCTIONDECODER_SEND_E011:			// Parameter der Partner sind unterschiedlich 
            /*~-1*/
            {
               /*~A:2521*/
               /*~+:INSTRUCTIONDECODER_SEND_E011*/
               /*~I:2522*/
               if (CommunicationControl.chLine2Interprete == COMMUNICATION_RS232)
               /*~-1*/
               {
                  /*~I:2523*/
                  if (!SYSTEM_MRW_MANAGER)
                  /*~-1*/
                  {
                     /*~I:2524*/
                     if (lText2Send)
                     /*~-1*/
                     {
                        /*~I:2525*/
#ifdef CHANNEL_0
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~-1*/
#endif
                        /*~E:I2525*/
                        /*~I:2526*/
#ifdef CHANNEL_1
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~-1*/
#endif
                        /*~E:I2526*/
                        /*~T*/
                        break;
                     /*~-1*/
                     }
                     /*~E:I2524*/
                  /*~-1*/
                  }
                  /*~E:I2523*/
                  /*~I:2527*/
#ifdef CHANNEL_0
                  /*~T*/
                  Communication_SendString(COMMUNICATION_RS232,TEXT_E011,1,0);
                  /*~-1*/
#endif
                  /*~E:I2527*/
                  /*~I:2528*/
#ifdef CHANNEL_1 
                  /*~I:2529*/
                  if (bDoNotWriteResult2Buffer)
                  /*~-1*/
                  {
                     /*~T*/
                     Communication_SendString(COMMUNICATION_RS232,TEXT_E011,1,0);
                  /*~-1*/
                  }
                  /*~E:I2529*/
                  /*~-1*/
#endif
                  /*~E:I2528*/
               /*~-1*/
               }
               /*~O:I2522*/
               /*~-2*/
               else
               {
                  /*~T*/
                  // NotAcknowledge senden
                  byRetVal = ADuC836_SPISendChar(NAK);
               /*~-1*/
               }
               /*~E:I2522*/
               /*~T*/
               break;
               /*~E:A2521*/
            /*~-1*/
            }
            /*~E:F2520*/
            /*~F:2530*/
            case INSTRUCTIONDECODER_SEND_E012:			// Checksummenfehler
            /*~-1*/
            {
               /*~A:2531*/
               /*~+:INSTRUCTIONDECODER_SEND_E012*/
               /*~I:2532*/
               if (CommunicationControl.chLine2Interprete == COMMUNICATION_RS232)
               /*~-1*/
               {
                  /*~I:2533*/
                  if (!SYSTEM_MRW_MANAGER)
                  /*~-1*/
                  {
                     /*~I:2534*/
                     if (lText2Send)
                     /*~-1*/
                     {
                        /*~I:2535*/
#ifdef CHANNEL_0
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~-1*/
#endif
                        /*~E:I2535*/
                        /*~I:2536*/
#ifdef CHANNEL_1
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~-1*/
#endif
                        /*~E:I2536*/
                        /*~T*/
                        break;
                     /*~-1*/
                     }
                     /*~E:I2534*/
                  /*~-1*/
                  }
                  /*~E:I2533*/
                  /*~T*/
                  Communication_SendString(COMMUNICATION_RS232,TEXT_E012,1,0);
               /*~-1*/
               }
               /*~O:I2532*/
               /*~-2*/
               else
               {
                  /*~T*/
                  // NotAcknowledge senden
                  byRetVal = ADuC836_SPISendChar(NAK);
               /*~-1*/
               }
               /*~E:I2532*/
               /*~T*/
               break;
               /*~E:A2531*/
            /*~-1*/
            }
            /*~E:F2530*/
            /*~F:2537*/
            case INSTRUCTIONDECODER_SEND_NOK:			// NOK senden
            /*~-1*/
            {
               /*~A:2538*/
               /*~+:INSTRUCTIONDECODER_SEND_NOK*/
               /*~I:2539*/
               if (CommunicationControl.chLine2Interprete == COMMUNICATION_RS232)
               /*~-1*/
               {
                  /*~I:2540*/
                  if (!SYSTEM_MRW_MANAGER)
                  /*~-1*/
                  {
                     /*~I:2541*/
                     if (lText2Send)
                     /*~-1*/
                     {
                        /*~A:2542*/
                        /*~+:RS232-Ausgabe*/
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~E:A2542*/
                        /*~T*/
                        break;
                     /*~-1*/
                     }
                     /*~E:I2541*/
                  /*~-1*/
                  }
                  /*~E:I2540*/
                  /*~A:2543*/
                  /*~+:RS232-Ausgabe*/
                  /*~T*/
                  Communication_SendMessage(COMMUNICATION_RS232,COMMUNICATION_NOK);
                  /*~E:A2543*/
               /*~-1*/
               }
               /*~E:I2539*/
               /*~T*/
               break;
               /*~E:A2538*/
            /*~-1*/
            }
            /*~E:F2537*/
            /*~F:2544*/
            case INSTRUCTIONDECODER_SEND_NOTHING:
            /*~-1*/
            {
               /*~T*/
               break;
            /*~-1*/
            }
            /*~E:F2544*/
         /*~-1*/
         }
         /*~E:C2407*/
         /*~I:2545*/
#ifdef CHANNEL_1
         /*~I:2546*/
         if (!bDoNotWriteResult2Buffer)
         /*~-1*/
         {
            /*~T*/
            bDoNotWriteResult2Buffer = 1;

            g_byLastCommandExecutionResult = byCommandStatus;
         /*~-1*/
         }
         /*~E:I2546*/
         /*~-1*/
#endif
         /*~E:I2545*/
         /*~E:A2406*/
      /*~-1*/
      }
      /*~E:I58*/
   /*~-1*/
   }
   /*~E:I57*/
   /*~I:2547*/
#ifdef MOF
   /*~I:2548*/
   if (CommunicationControl.chLine2Interprete == COMMUNICATION_RS232)
   /*~-1*/
   {
      /*~A:2549*/
      /*~+:Kanal 0 - Freigabesteuerung*/
      /*~I:2550*/
#ifdef CHANNEL_0
      /*~T*/
      ulTimeout = SYSTEMTIME + HANDSHAKING_TIMEOUT; 
      /*~L:2551*/
      while ((byStatelineStatus == COMMUNICATION_INSTUCTIONDECODER_STATE_LINE)&&(ulTimeout >= SYSTEMTIME))
      /*~-1*/
      {
         /*~T*/

      /*~-1*/
      }
      /*~E:L2551*/
      /*~T*/
      // Freigabeleitung f�r Start des Instruction-Dekoders auf Partner-Seite wieder l�schen
      COMMUNICATION_INSTUCTIONDECODER_RELEASE_LINE = 0;	
      /*~-1*/
#endif
      /*~E:I2550*/
      /*~E:A2549*/
      /*~A:2552*/
      /*~+:Kanal 1 - Freigabesteuerung*/
      /*~I:2553*/
#ifdef CHANNEL_1
      /*~T*/
      ulTimeout = SYSTEMTIME + HANDSHAKING_TIMEOUT; 
      /*~L:2554*/
      while ((ADuC836_RS232IsTransmissionReady() == FALSE)&&(ulTimeout >= SYSTEMTIME))
      /*~-1*/
      {
         /*~T*/

      /*~-1*/
      }
      /*~E:L2554*/
      /*~T*/
      ulTimeout = SYSTEMTIME + HANDSHAKING_TIMEOUT; 
      /*~T*/
      COMMUNICATION_INSTUCTIONDECODER_RELEASE_LINE = !COMMUNICATION_INSTUCTIONDECODER_RELEASE_LINE;
      /*~L:2555*/
      while ((COMMUNICATION_INSTUCTIONDECODER_STATE_LINE == TRUE)&&(ulTimeout >= SYSTEMTIME))
      /*~-1*/
      {
         /*~T*/

      /*~-1*/
      }
      /*~E:L2555*/
      /*~L:2556*/
      while ((COMMUNICATION_INSTUCTIONDECODER_STATE_LINE == FALSE)&&(ulTimeout >= SYSTEMTIME))
      /*~-1*/
      {
         /*~T*/

      /*~-1*/
      }
      /*~E:L2556*/
      /*~-1*/
#endif
      /*~E:I2553*/
      /*~E:A2552*/
   /*~-1*/
   }
   /*~E:I2548*/
   /*~-1*/
#endif
   /*~E:I2547*/
   /*~E:A20*/
   /*~A:2557*/
   /*~+:Letzes Kommando f�r immer l�schen*/
   /*~T*/
   // letzes Kommando f�r immer l�schen
   memset(pCommunicationCommand,0,sizeof(COMMUNICATION_COMMAND));
   /*~E:A2557*/
/*~-1*/
}
/*~E:F10*/
/*~E:A9*/
/*~A:2558*/
/*~+:char 			InstructionDecoder_CheckLimits(void *pParameter2Check, void *pLimitLow, void *pLimitHigh, unsigned char chDataType)*/
/*~F:2559*/
char InstructionDecoder_CheckLimits(void *pParameter2Check, void *pLimitLow, void *pLimitHigh, unsigned char chDataType)
/*~-1*/
{
   /*~A:2560*/
   /*~+:Variablendeklarationen*/
   /*~T*/
   char byRetVal;
   /*~E:A2560*/
   /*~A:2561*/
   /*~+:Variableninitialisierungen*/
   /*~T*/

   /*~E:A2561*/
   /*~C:2562*/
   switch (chDataType)
   /*~-1*/
   {
      /*~F:2563*/
      case DATATYPE_CHAR:
      /*~-1*/
      {
         /*~A:2564*/
         /*~+:Variablendeklarationen*/
         /*~T*/
         char byTempLimit;
         /*~E:A2564*/
         /*~A:2565*/
         /*~+:Variableninitialisierungen*/
         /*~T*/

         /*~E:A2565*/
         /*~I:2566*/
         if (*(char*)pLimitLow > *(char*)pLimitHigh)
         /*~-1*/
         {
            /*~T*/
            // unterer und oberer Grenzwert vertauscht

            byTempLimit = *(char*)pLimitLow;

            *(char*)pLimitLow = *(char*)pLimitHigh;
            *(char*)pLimitHigh = byTempLimit;
         /*~-1*/
         }
         /*~E:I2566*/
         /*~I:2567*/
         if (*(char*)pParameter2Check < *(char*)pLimitLow)
         /*~-1*/
         {
            /*~T*/
            // Parameter liegt unterhalb des unteren Grenzwertes
            *(char*)pParameter2Check = *(char*)pLimitLow;

            // 1 zur�ckliefern
            byRetVal = 1;
         /*~-1*/
         }
         /*~O:I2567*/
         /*~-2*/
         else
         {
            /*~I:2568*/
            if (*(char*)pParameter2Check > *(char*)pLimitHigh)
            /*~-1*/
            {
               /*~T*/
               // Parameter liegt oberhalb des oberen Grenzwertes
               *(char*)pParameter2Check = *(char*)pLimitHigh;

               // 2 zur�ckliefern
               byRetVal = 2;
            /*~-1*/
            }
            /*~O:I2568*/
            /*~-2*/
            else
            {
               /*~T*/
               // Grenzwert innerhalb der Grenzen - R�ckgabe von 0 und Ausstieg

               return 0;
            /*~-1*/
            }
            /*~E:I2568*/
         /*~-1*/
         }
         /*~E:I2567*/
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F2563*/
      /*~F:2569*/
      case DATATYPE_INT:
      /*~-1*/
      {
         /*~A:2570*/
         /*~+:Variablendeklarationen*/
         /*~T*/
         int nTempLimit;
         /*~E:A2570*/
         /*~A:2571*/
         /*~+:Variableninitialisierungen*/
         /*~T*/

         /*~E:A2571*/
         /*~I:2572*/
         if (*(int*)pLimitLow > *(int*)pLimitHigh)
         /*~-1*/
         {
            /*~T*/
            // unterer und oberer Grenzwert vertauscht

            nTempLimit = *(int*)pLimitLow;

            *(int*)pLimitLow = *(int*)pLimitHigh;
            *(int*)pLimitHigh = nTempLimit;
         /*~-1*/
         }
         /*~E:I2572*/
         /*~I:2573*/
         if (*(int*)pParameter2Check < *(int*)pLimitLow)
         /*~-1*/
         {
            /*~T*/
            // Parameter liegt unterhalb des unteren Grenzwertes
            *(int*)pParameter2Check = *(int*)pLimitLow;

            // 1 zur�ckliefern
            byRetVal = 1;
         /*~-1*/
         }
         /*~O:I2573*/
         /*~-2*/
         else
         {
            /*~I:2574*/
            if (*(int*)pParameter2Check > *(int*)pLimitHigh)
            /*~-1*/
            {
               /*~T*/
               // Parameter liegt oberhalb des oberen Grenzwertes
               *(int*)pParameter2Check = *(int*)pLimitHigh;

               // 2 zur�ckliefern
               byRetVal = 2;
            /*~-1*/
            }
            /*~O:I2574*/
            /*~-2*/
            else
            {
               /*~T*/
               // Grenzwert innerhalb der Grenzen - R�ckgabe von 0 und Ausstieg

               return 0;
            /*~-1*/
            }
            /*~E:I2574*/
         /*~-1*/
         }
         /*~E:I2573*/
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F2569*/
      /*~F:2575*/
      case DATATYPE_LONG:
      /*~-1*/
      {
         /*~A:2576*/
         /*~+:Variablendeklarationen*/
         /*~T*/
         long lTempLimit;
         /*~E:A2576*/
         /*~A:2577*/
         /*~+:Variableninitialisierungen*/
         /*~T*/

         /*~E:A2577*/
         /*~I:2578*/
         if (*(long*)pLimitLow > *(long*)pLimitHigh)
         /*~-1*/
         {
            /*~T*/
            // unterer und oberer Grenzwert vertauscht

            lTempLimit = *(long*)pLimitLow;

            *(long*)pLimitLow = *(long*)pLimitHigh;
            *(long*)pLimitHigh = lTempLimit;
         /*~-1*/
         }
         /*~E:I2578*/
         /*~I:2579*/
         if (*(long*)pParameter2Check < *(long*)pLimitLow)
         /*~-1*/
         {
            /*~T*/
            // Parameter liegt unterhalb des unteren Grenzwertes
            *(long*)pParameter2Check = *(long*)pLimitLow;

            // 1 zur�ckliefern
            byRetVal = 1;
         /*~-1*/
         }
         /*~O:I2579*/
         /*~-2*/
         else
         {
            /*~I:2580*/
            if (*(long*)pParameter2Check > *(long*)pLimitHigh)
            /*~-1*/
            {
               /*~T*/
               // Parameter liegt oberhalb des oberen Grenzwertes
               *(long*)pParameter2Check = *(long*)pLimitHigh;

               // 2 zur�ckliefern
               byRetVal = 2;
            /*~-1*/
            }
            /*~O:I2580*/
            /*~-2*/
            else
            {
               /*~T*/
               // Grenzwert innerhalb der Grenzen - R�ckgabe von 0 und Ausstieg

               return 0;
            /*~-1*/
            }
            /*~E:I2580*/
         /*~-1*/
         }
         /*~E:I2579*/
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F2575*/
      /*~F:2581*/
      case DATATYPE_FLOAT:
      /*~-1*/
      {
         /*~A:2582*/
         /*~+:Variablendeklarationen*/
         /*~T*/
         float fTempLimit;
         /*~E:A2582*/
         /*~A:2583*/
         /*~+:Variableninitialisierungen*/
         /*~T*/

         /*~E:A2583*/
         /*~I:2584*/
         if (*(float*)pLimitLow > *(float*)pLimitHigh)
         /*~-1*/
         {
            /*~T*/
            // unterer und oberer Grenzwert vertauscht

            fTempLimit = *(float*)pLimitLow;

            *(float*)pLimitLow = *(float*)pLimitHigh;
            *(float*)pLimitHigh = fTempLimit;
         /*~-1*/
         }
         /*~E:I2584*/
         /*~I:2585*/
         if (*(float*)pParameter2Check < *(float*)pLimitLow)
         /*~-1*/
         {
            /*~T*/
            // Parameter liegt unterhalb des unteren Grenzwertes
            *(float*)pParameter2Check = *(float*)pLimitLow;

            // 1 zur�ckliefern
            byRetVal = 1;
         /*~-1*/
         }
         /*~O:I2585*/
         /*~-2*/
         else
         {
            /*~I:2586*/
            if (*(float*)pParameter2Check > *(float*)pLimitHigh)
            /*~-1*/
            {
               /*~T*/
               // Parameter liegt oberhalb des oberen Grenzwertes
               *(float*)pParameter2Check = *(float*)pLimitHigh;

               // 2 zur�ckliefern
               byRetVal = 2;
            /*~-1*/
            }
            /*~O:I2586*/
            /*~-2*/
            else
            {
               /*~T*/
               // Grenzwert innerhalb der Grenzen - R�ckgabe von 0 und Ausstieg

               return 0;
            /*~-1*/
            }
            /*~E:I2586*/
         /*~-1*/
         }
         /*~E:I2585*/
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F2581*/
   /*~-1*/
   }
   /*~E:C2562*/
   /*~T*/
   // Meldung ausgeben
   Communication_SendString(COMMUNICATION_RS232,TEXT_E002,0,0);
   /*~T*/
   return byRetVal;
/*~-1*/
}
/*~E:F2559*/
/*~E:A2558*/
/*~A:2587*/
/*~+:char 			InstructionDecoder_CheckNbParameters(unsigned char byNbParametersExpected,char byShowErrorsBy,unsigned char *pStatus)*/
/*~F:2588*/
char InstructionDecoder_CheckNbParameters(unsigned char byNbParametersExpected,char byShowErrorsBy,unsigned char *pStatus)
/*~-1*/
{
   /*~A:2589*/
   /*~+:Variablendeklarationen*/
   /*~T*/
   // Variablendeklarationen
   unsigned char byNumberOfParameters;
   /*~E:A2589*/
   /*~A:2590*/
   /*~+:Variableninitialisierungen*/
   /*~T*/
   // Variableninitialisierungen
   /*~E:A2590*/
   /*~T*/
   byNumberOfParameters = Communication_GetNumberOfParameters();
   /*~I:2591*/
   if (byNumberOfParameters == byNbParametersExpected)
   /*~-1*/
   {
      /*~T*/
      // Anzahl der Parameter stimmt
      /*~T*/
      return 0;
   /*~-1*/
   }
   /*~O:I2591*/
   /*~-2*/
   else
   {
      /*~I:2592*/
      if (byNbParametersExpected > byNumberOfParameters)
      /*~-1*/
      {
         /*~T*/
         // Anzahl der �bergebenen Parameter zu klein
         /*~I:2593*/
#ifdef CHANNEL_0
         /*~I:2594*/
         if (byShowErrorsBy & 0x01)
         /*~-1*/
         {
            /*~A:2595*/
            /*~+:E007*/
            /*~T*/
            Communication_SendString(COMMUNICATION_RS232,TEXT_E007,1,0);
            /*~E:A2595*/
         /*~-1*/
         }
         /*~E:I2594*/
         /*~-1*/
#endif
         /*~E:I2593*/
         /*~I:2596*/
#ifdef CHANNEL_1
         /*~I:2597*/
         if (byShowErrorsBy & 0x02)
         /*~-1*/
         {
            /*~A:2598*/
            /*~+:E007*/
            /*~T*/
            *pStatus = INSTRUCTIONDECODER_SEND_E007; 
            /*~E:A2598*/
         /*~-1*/
         }
         /*~E:I2597*/
         /*~-1*/
#endif
         /*~E:I2596*/
         /*~T*/
         return 1;
      /*~-1*/
      }
      /*~O:I2592*/
      /*~-2*/
      else
      {
         /*~T*/
         // Anzahl der �bergebenen Parameter zu gro�
         /*~I:2599*/
#ifdef CHANNEL_0
         /*~I:2600*/
         if (byShowErrorsBy & 0x01)
         /*~-1*/
         {
            /*~A:2601*/
            /*~+:E008*/
            /*~T*/
            Communication_SendString(COMMUNICATION_RS232,TEXT_E008,1,0);
            /*~E:A2601*/
         /*~-1*/
         }
         /*~E:I2600*/
         /*~-1*/
#endif
         /*~E:I2599*/
         /*~I:2602*/
#ifdef CHANNEL_1
         /*~I:2603*/
         if (byShowErrorsBy & 0x02)
         /*~-1*/
         {
            /*~A:2604*/
            /*~+:E008*/
            /*~T*/
            *pStatus = INSTRUCTIONDECODER_SEND_E008; 
            /*~E:A2604*/
         /*~-1*/
         }
         /*~E:I2603*/
         /*~-1*/
#endif
         /*~E:I2602*/
         /*~T*/
         return 2;
      /*~-1*/
      }
      /*~E:I2592*/
   /*~-1*/
   }
   /*~E:I2591*/
/*~-1*/
}
/*~E:F2588*/
/*~E:A2587*/
/*~I:2605*/
#ifdef CHANNEL_1
/*~A:2606*/
/*~+:void 			InstructionDecoder_StoreValue(unsigned char byValue2Store,GLOBAL_UNIVALUE Value)*/
/*~F:2607*/
void InstructionDecoder_StoreValue(unsigned char byValue2Store,GLOBAL_UNIVALUE_SHORT* pValue)
/*~-1*/
{
   /*~T*/
   g_byValueStored = byValue2Store;
   g_Value = *pValue;
   g_ulTimeoutValue = SYSTEMTIME + 500;
/*~-1*/
}
/*~E:F2607*/
/*~E:A2606*/
/*~-1*/
#endif
/*~E:I2605*/
