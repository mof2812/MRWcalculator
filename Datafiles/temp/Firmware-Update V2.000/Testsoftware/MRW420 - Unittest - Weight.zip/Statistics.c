/*~-1*/
/*~XSF_LANGUAGE: C/C++*/
/*~K*/
/*~+:File :        Statistics.c*/
/*~+:*/
/*~+:Version :     V1.0*/
/*~+:*/
/*~+:Date :        25.08.2005*/
/*~+:*/
/*~+:Time :        13:11*/
/*~+:*/
/*~+:Author :      MOF*/
/*~+:*/
/*~+:Hardware :*/
/*~+:*/
/*~+:Description :*/
/*~+:*/
/*~+:*/
/*~A:1*/
/*~+:Includes*/
/*~T*/
#include "Global.h" 
#include <Stdio.h>
/*~E:A1*/
/*~A:2*/
/*~+:Funktionseigene Definitionen*/
/*~T*/
/// @cond PROGRAMMERS_MANUAL
/*~T*/
/// @endcond
/*~E:A2*/
/*~A:3*/
/*~+:Funktionseigene Struktur-Definitionen*/
/*~T*/
/// @cond PROGRAMMERS_MANUAL
/*~T*/
/// @endcond
/*~E:A3*/
/*~A:4*/
/*~+:Funktionsprototypen*/
/*~T*/
void 						Statistics(void);
void 						Statistics_Clear(unsigned char chWhat2Clear);
STATISTICSLIBRARY_SETUP 	Statistics_GetSetup(void);
void 						Statistics_Ini(char byClearResults);
void 						Statistics_PrintData(unsigned char chWhat2Print);
void 						Statistics_SetSetup(STATISTICSLIBRARY_SETUP StatisticsSetup);
void 						Statistics_Setup(char byDefault);
/*~E:A4*/
/*~A:5*/
/*~+:Globale Variablen*/
/*~T*/
/// @cond PROGRAMMERS_MANUAL
/*~T*/
/// @endcond
/*~E:A5*/
/*~A:6*/
/*~+:void 					Statistics(void)*/
/*~F:7*/
void Statistics(void)
/*~-1*/
{
   /*~A:8*/
   /*~+:Variablendeklarationen*/
   /*~T*/
   char byTemperature;
   float fCurrent;
   float fWeight;
   long lRMW;
   /*~E:A8*/
   /*~A:9*/
   /*~+:Variableninitialisierungen*/
   /*~T*/
   byTemperature = Global.byTemperature;
   fCurrent = CurrentInterface_GetCurrent(1);
   fWeight = Weight_NetWeight.fFloat;
   lRMW = Weight_ZeroCorrectedMeasurement.nLong;
   /*~E:A9*/
   /*~T*/
   // Absolutstatistik
   StatisticsLibrary_CheckTemperature(0,byTemperature);

   // Relativ-Statistik
   StatisticsLibrary_CheckTemperature(1,byTemperature);
   /*~T*/
   // Absolutstatistik
   StatisticsLibrary_CheckWeight(0,fWeight,lRMW,fCurrent);

   // Relativ-Statistik
   StatisticsLibrary_CheckWeight(1,fWeight,lRMW,fCurrent);
   /*~T*/
   // Absolutstatistik
   StatisticsLibrary_CheckOverload(0,Limit_GetLimitState() & LIMIT_ALARMLIMIT_EXCEEDED);

   // Relativ-Statistik
   StatisticsLibrary_CheckOverload(1,Limit_GetLimitState() & LIMIT_ALARMLIMIT_EXCEEDED);

   /*~T*/
   // Absolutstatistik
   StatisticsLibrary_CheckOverlimit(0,fWeight);

   // Relativ-Statistik
   StatisticsLibrary_CheckOverlimit(1,fWeight);

/*~-1*/
}
/*~E:F7*/
/*~E:A6*/
/*~A:10*/
/*~+:void 					Statistics_Clear(unsigned char chWhat2Clear)*/
/*~F:11*/
void Statistics_Clear(unsigned char chWhat2Clear)
/*~-1*/
{
   /*~A:12*/
   /*~+:Temperaturextrema l�schen*/
   /*~I:13*/
   if (chWhat2Clear & 0x10)
   /*~-1*/
   {
      /*~T*/
      // Relativ-Statistik
      StatisticsLibrary_Clear(1,0x01);
   /*~-1*/
   }
   /*~E:I13*/
   /*~I:14*/
   if (chWhat2Clear & 0x01)
   /*~-1*/
   {
      /*~T*/
      // Absolut-Statistik
      StatisticsLibrary_Clear(0,0x01);
      // Relativ-Statistik
      StatisticsLibrary_Clear(1,0x01);
   /*~-1*/
   }
   /*~E:I14*/
   /*~E:A12*/
   /*~A:15*/
   /*~+:Gewichtsextrema l�schen*/
   /*~I:16*/
   if (chWhat2Clear & 0x40)
   /*~-1*/
   {
      /*~T*/
      // Relativ-Statistik
      StatisticsLibrary_Clear(1,0x04);
   /*~-1*/
   }
   /*~E:I16*/
   /*~I:17*/
   if (chWhat2Clear & 0x04)
   /*~-1*/
   {
      /*~T*/
      // Absolut-Statistik
      StatisticsLibrary_Clear(0,0x04);
      // Relativ-Statistik
      StatisticsLibrary_Clear(1,0x04);
   /*~-1*/
   }
   /*~E:I17*/
   /*~E:A15*/
   /*~A:18*/
   /*~+:�berlast- und Grenzwert�berschreitungs-Z�hler l�schen*/
   /*~I:19*/
   if (chWhat2Clear & 0x80)
   /*~-1*/
   {
      /*~T*/
      // Relativ-Statistik
      StatisticsLibrary_Clear(1,0x08);
   /*~-1*/
   }
   /*~E:I19*/
   /*~I:20*/
   if (chWhat2Clear & 0x08)
   /*~-1*/
   {
      /*~T*/
      // Absolut-Statistik
      StatisticsLibrary_Clear(0,0x08);
      // Relativ-Statistik
      StatisticsLibrary_Clear(1,0x08);
   /*~-1*/
   }
   /*~E:I20*/
   /*~E:A18*/
/*~-1*/
}
/*~E:F11*/
/*~E:A10*/
/*~A:21*/
/*~+:STATISTICSLIBRARY_SETUP Statistics_GetSetup(void)*/
/*~F:22*/
STATISTICSLIBRARY_SETUP Statistics_GetSetup(void)
/*~-1*/
{
   /*~A:23*/
   /*~+:Variablendeklarationen*/
   /*~T*/
   STATISTICSLIBRARY_SETUP StatisticsSetup;
   /*~E:A23*/
   /*~A:24*/
   /*~+:Variableninitialisierungen*/
   /*~T*/

   /*~E:A24*/
   /*~T*/
   // Parameter laden
   Load_Parameter(LOAD_SAVE_STATISTICS_SETUP,&StatisticsSetup,sizeof(STATISTICSLIBRARY_SETUP));
   /*~T*/
   return StatisticsSetup;
/*~-1*/
}
/*~E:F22*/
/*~E:A21*/
/*~A:25*/
/*~+:void 					Statistics_Ini(char byClearResults)*/
/*~F:26*/
void Statistics_Ini(char byClearResults)
/*~-1*/
{
   /*~T*/
   Statistics_Setup(byClearResults);
   StatisticsLibrary_Ini(byClearResults);
/*~-1*/
}
/*~E:F26*/
/*~E:A25*/
/*~A:27*/
/*~+:void 					Statistics_PrintData(unsigned char chWhat2Print)*/
/*~F:28*/
void Statistics_PrintData(unsigned char chWhat2Print)
/*~-1*/
{
   /*~A:29*/
   /*~+:Variablendeklarationen*/
   /*~T*/
   STATISTICSLIBRARY_RESULT StatResults;
   char byParameterGuilty[2];

   /*~E:A29*/
   /*~A:30*/
   /*~+:Variableninitialisierungen*/
   /*~T*/
   byParameterGuilty[0] = byParameterGuilty[1] = 1;
   /*~E:A30*/
   /*~A:31*/
   /*~+:D�rfen alle Parameter ausgegeben werden ?*/
   /*~I:32*/
   if ((SYSTEM_MRW_MANAGER)&&(chWhat2Print == 255))
   /*~-1*/
   {
      /*~K*/
      /*~+:// Ausgabe aller Parameter in Verbindung mit MRW-Manager nicht m�glich - Parameter auf einen ung�ltigen wert setzen */
      /*~T*/
      chWhat2Print--;
   /*~-1*/
   }
   /*~E:I32*/
   /*~E:A31*/
   /*~I:33*/
   if (chWhat2Print == 255)
   /*~-1*/
   {
      /*~I:34*/
#ifdef CHANNEL_0
      /*~A:35*/
      /*~+:Kanalnummer*/
      /*~T*/
      // Kanalnummer
      Communication_SendString(COMMUNICATION_RS232,T_TEXT_CHANNEL_0,2,0);
      /*~E:A35*/
      /*~-1*/
#endif
      /*~E:I34*/
      /*~I:36*/
#ifdef CHANNEL_1
      /*~A:37*/
      /*~+:Kanalnummer*/
      /*~T*/
      // Kanalnummer
      Communication_SendString(COMMUNICATION_RS232,T_TEXT_CHANNEL_1,2,0);
      /*~E:A37*/
      /*~-1*/
#endif
      /*~E:I36*/
      /*~A:38*/
      /*~+:Kanalnummer unterstreichen*/
      /*~T*/
      // Doppellinie
      Communication_SendString(COMMUNICATION_RS232,T_TEXT_DOUBLE_LINE,1,1);
      /*~E:A38*/
      /*~A:39*/
      /*~+:�berschrift "Absolutstatistik"*/
      /*~T*/
      Communication_SendString(COMMUNICATION_RS232,T_TEXT_ABSOLUTE_STATISTICS,1,1);
      Communication_SendString(COMMUNICATION_RS232,T_TEXT_LINE_001,0,1);
      /*~E:A39*/
   /*~-1*/
   }
   /*~E:I33*/
   /*~A:40*/
   /*~+:Ausgabe der Daten der Absolutstatistik*/
   /*~T*/
   StatResults = StatisticsLibrary_GetResult(0);
   /*~I:41*/
#ifdef CHANNEL_0
   /*~A:42*/
   /*~+:Absolutstatistik - Kanal 0*/
   /*~C:43*/
   switch (chWhat2Print)
   /*~-1*/
   {
      /*~A:44*/
      /*~+:Betriebszeit*/
      /*~F:45*/
      case 0x07:
      case 0xFF:
      /*~-1*/
      {
         /*~I:46*/
         if (!SYSTEM_MRW_MANAGER)
         /*~-1*/
         {
            /*~T*/
            Communication_SendString(COMMUNICATION_RS232,T_TEXT_OPERATING_HOURS,1,0);

         /*~-1*/
         }
         /*~E:I46*/
         /*~T*/
         Communication_SendString(COMMUNICATION_RS232,System_GetOperatingHoursAsString(0),0,0);
         /*~I:47*/
         if (chWhat2Print != 0xFF)
         /*~-1*/
         {
            /*~T*/
            break;
         /*~-1*/
         }
         /*~E:I47*/
      /*~-1*/
      }
      /*~E:F45*/
      /*~E:A44*/
      /*~A:48*/
      /*~+:0x00 - nur aus Kompatibilit�tsgr�nden vorhanden*/
      /*~F:49*/
      case 0x00:	// nur aus Kompatibilit�tsgr�nden vorhanden
      /*~-1*/
      {
         /*~I:50*/
         if (chWhat2Print != 0xFF)
         /*~-1*/
         {
            /*~T*/
            Communication_SendLong(COMMUNICATION_RS232,TEXT_PARAMETER_NOT_INCLUDED_CHANNEL_0,0,1,0);
            /*~T*/
            break;
         /*~-1*/
         }
         /*~E:I50*/
      /*~-1*/
      }
      /*~E:F49*/
      /*~E:A48*/
      /*~A:51*/
      /*~+:Minimale Temperatur*/
      /*~F:52*/
      case 0x01: // minimale Temperatur
      /*~-1*/
      {
         /*~T*/
         Communication_SendLong(COMMUNICATION_RS232,TEXT_ABS_STATISTICS_MIN_TEMPERATURE_CHANNEL_0,StatResults.chMinTemperature,1,0);
         /*~I:53*/
         if (chWhat2Print != 0xFF)
         /*~-1*/
         {
            /*~T*/
            break;
         /*~-1*/
         }
         /*~E:I53*/
      /*~-1*/
      }
      /*~E:F52*/
      /*~E:A51*/
      /*~A:54*/
      /*~+:Maximale Temperatur*/
      /*~F:55*/
      case 0x02:	// maximale Temperatur
      /*~-1*/
      {
         /*~T*/
         Communication_SendLong(COMMUNICATION_RS232,TEXT_ABS_STATISTICS_MAX_TEMPERATURE_CHANNEL_0,StatResults.chMaxTemperature,1,0);
         /*~I:56*/
         if (chWhat2Print != 0xFF)
         /*~-1*/
         {
            /*~T*/
            break;
         /*~-1*/
         }
         /*~E:I56*/
      /*~-1*/
      }
      /*~E:F55*/
      /*~E:A54*/
      /*~A:57*/
      /*~+:Maximales Gewicht*/
      /*~F:58*/
      case 0x03:	// maximales Gewicht
      /*~-1*/
      {
         /*~T*/
         Communication_SendFloat(COMMUNICATION_RS232,TEXT_ABS_STATISTICS_MAX_WEIGHT_CHANNEL_0,StatResults.fMaxWeight,2,1,0);
         /*~I:59*/
         if (chWhat2Print != 0xFF)
         /*~-1*/
         {
            /*~T*/
            break;
         /*~-1*/
         }
         /*~E:I59*/
      /*~-1*/
      }
      /*~E:F58*/
      /*~E:A57*/
      /*~A:60*/
      /*~+:Anzahl der �berlastungen*/
      /*~F:61*/
      case 0x04:	// Anzahl der �berlastungen
      /*~-1*/
      {
         /*~T*/
         Communication_SendLong(COMMUNICATION_RS232,TEXT_ABS_STATISTICS_NB_OVERLOADS_CHANNEL_0,StatResults.nOverloads,1,0);
         /*~I:62*/
         if (chWhat2Print != 0xFF)
         /*~-1*/
         {
            /*~T*/
            break;
         /*~-1*/
         }
         /*~E:I62*/
      /*~-1*/
      }
      /*~E:F61*/
      /*~E:A60*/
      /*~A:63*/
      /*~+:0x05 - nur aus Kompatibilit�tsgr�nden vorhanden*/
      /*~F:64*/
      case 0x05:	// nur aus Kompatibilit�tsgr�nden vorhanden
      /*~-1*/
      {
         /*~I:65*/
         if (chWhat2Print != 0xFF)
         /*~-1*/
         {
            /*~T*/
            Communication_SendLong(COMMUNICATION_RS232,TEXT_PARAMETER_NOT_INCLUDED_CHANNEL_0,0,1,0);
            /*~T*/
            break;
         /*~-1*/
         }
         /*~E:I65*/
      /*~-1*/
      }
      /*~E:F64*/
      /*~E:A63*/
      /*~A:66*/
      /*~+:0x06 - nur aus Kompatibilit�tsgr�nden vorhanden*/
      /*~F:67*/
      case 0x06:	// nur aus Kompatibilit�tsgr�nden vorhanden
      /*~-1*/
      {
         /*~I:68*/
         if (chWhat2Print != 0xFF)
         /*~-1*/
         {
            /*~T*/
            Communication_SendLong(COMMUNICATION_RS232,TEXT_PARAMETER_NOT_INCLUDED_CHANNEL_0,0,1,0);
            /*~T*/
            break;
         /*~-1*/
         }
         /*~E:I68*/
      /*~-1*/
      }
      /*~E:F67*/
      /*~E:A66*/
      /*~A:69*/
      /*~+:Maximaler Rohmesswert*/
      /*~F:70*/
      case 0x08:	// maximaler Rohmesswert
      /*~-1*/
      {
         /*~T*/
         Communication_SendLong(COMMUNICATION_RS232,TEXT_ABS_STATISTICS_MAX_RMW_CHANNEL_0,StatResults.lMaxRMW,1,0);
         /*~I:71*/
         if (chWhat2Print != 0xFF)
         /*~-1*/
         {
            /*~T*/
            break;
         /*~-1*/
         }
         /*~E:I71*/
      /*~-1*/
      }
      /*~E:F70*/
      /*~E:A69*/
      /*~A:72*/
      /*~+:Maximaler Strom*/
      /*~F:73*/
      case 0x09:	// maximaler Strom
      /*~-1*/
      {
         /*~T*/
         Communication_SendFloat(COMMUNICATION_RS232,TEXT_ABS_STATISTICS_MAX_CURRENT_CHANNEL_0,StatResults.fMaxCurrent,2,1,0);
         /*~I:74*/
         if (chWhat2Print != 0xFF)
         /*~-1*/
         {
            /*~T*/
            break;
         /*~-1*/
         }
         /*~E:I74*/
      /*~-1*/
      }
      /*~E:F73*/
      /*~E:A72*/
      /*~A:75*/
      /*~+:Anzahl der Grenzwert�berschreitungen*/
      /*~F:76*/
      case 0x0A:	// Anzahl der Grenzwert�berschreitungen
      /*~-1*/
      {
         /*~T*/
         Communication_SendLong(COMMUNICATION_RS232,TEXT_ABS_STATISTICS_NB_OVERLIMITS_CHANNEL_0,StatResults.nOverLimits,1,0);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F76*/
      /*~E:A75*/
      /*~A:77*/
      /*~+:Zeitpunkt 'Maximales Gewicht'*/
      /*~F:78*/
      case 0x0B:	// Zeitpunkt bei maximalem Gewicht
      /*~-1*/
      {
         /*~A:79*/
         /*~+:Variablendeklarationen*/
         /*~T*/
         unsigned long ulTime;
         char szText[16];
         /*~E:A79*/
         /*~A:80*/
         /*~+:Variableninitialisierungen*/
         /*~T*/

         /*~E:A80*/
         /*~T*/
         Load_Parameter(LOAD_SAVE_STATISTICS_TIMEMAXWEIGHT_CH0,&ulTime,4);
         /*~I:81*/
         if (SYSTEM_MRW_MANAGER)
         /*~-1*/
         {
            /*~A:82*/
            /*~+:MRW-Manager-Mode : Zeitpunkt in Sekunden ausgeben*/
            /*~T*/
            Communication_SendLong(COMMUNICATION_RS232,TEXT_ABS_STATISTICS_TIME_AT_MAX_WEIGHT_CHANNEL_0,ulTime,1,0);
            /*~E:A82*/
         /*~-1*/
         }
         /*~O:I81*/
         /*~-2*/
         else
         {
            /*~A:83*/
            /*~+:Docklight-Modus : Zeit als String ausgeben*/
            /*~T*/
            Communication_SendString(COMMUNICATION_RS232,T_TEXT_ABS_STATISTICS_TIME_AT_MAX_WEIGHT_CHANNEL_0,1,0);
            /*~T*/
            sprintf(szText,"%ld:%02ld:%02ld",ulTime/3600,(ulTime%3600)/60,ulTime%60);
            Communication_SendString(COMMUNICATION_RS232,szText,0,0);
            /*~E:A83*/
         /*~-1*/
         }
         /*~E:I81*/
         /*~I:84*/
         if (chWhat2Print != 0xFF)
         /*~-1*/
         {
            /*~T*/
            break;
         /*~-1*/
         }
         /*~E:I84*/
      /*~-1*/
      }
      /*~E:F78*/
      /*~E:A77*/
      /*~O:C43*/
      /*~-2*/
      default:
      {
         /*~I:85*/
         if (!(chWhat2Print & 0x40))
         /*~-1*/
         {
            /*~T*/
            byParameterGuilty[0] = 0;
         /*~-1*/
         }
         /*~E:I85*/
      /*~-1*/
      }
   /*~-1*/
   }
   /*~E:C43*/
   /*~E:A42*/
   /*~-1*/
#endif
   /*~E:I41*/
   /*~I:86*/
#ifdef CHANNEL_1
   /*~A:87*/
   /*~+:Absolutstatistik - Kanal 1*/
   /*~C:88*/
   switch (chWhat2Print)
   /*~-1*/
   {
      /*~A:89*/
      /*~+:Betriebszeit*/
      /*~F:90*/
      case 0x07:
      case 0xFF:
      /*~-1*/
      {
         /*~I:91*/
         if (!SYSTEM_MRW_MANAGER)
         /*~-1*/
         {
            /*~T*/
            Communication_SendString(COMMUNICATION_RS232,T_TEXT_OPERATING_HOURS,1,0);

         /*~-1*/
         }
         /*~E:I91*/
         /*~T*/
         Communication_SendString(COMMUNICATION_RS232,System_GetOperatingHoursAsString(0),0,0);
         /*~I:92*/
         if (chWhat2Print != 0xFF)
         /*~-1*/
         {
            /*~T*/
            break;
         /*~-1*/
         }
         /*~E:I92*/
      /*~-1*/
      }
      /*~E:F90*/
      /*~E:A89*/
      /*~A:93*/
      /*~+:0x00 - nur aus Kompatibilit�tsgr�nden vorhanden*/
      /*~F:94*/
      case 0x00:	// nur aus Kompatibilit�tsgr�nden vorhanden
      /*~-1*/
      {
         /*~I:95*/
         if (chWhat2Print != 0xFF)
         /*~-1*/
         {
            /*~T*/
            Communication_SendLong(COMMUNICATION_RS232,TEXT_PARAMETER_NOT_INCLUDED_CHANNEL_1,0,1,0);
            /*~T*/
            break;
         /*~-1*/
         }
         /*~E:I95*/
      /*~-1*/
      }
      /*~E:F94*/
      /*~E:A93*/
      /*~A:96*/
      /*~+:Minimale Temperatur*/
      /*~F:97*/
      case 0x01: // minimale Temperatur
      /*~-1*/
      {
         /*~T*/
         Communication_SendLong(COMMUNICATION_RS232,TEXT_ABS_STATISTICS_MIN_TEMPERATURE_CHANNEL_1,StatResults.chMinTemperature,1,0);
         /*~I:98*/
         if (chWhat2Print != 0xFF)
         /*~-1*/
         {
            /*~T*/
            break;
         /*~-1*/
         }
         /*~E:I98*/
      /*~-1*/
      }
      /*~E:F97*/
      /*~E:A96*/
      /*~A:99*/
      /*~+:Maximale Temperatur*/
      /*~F:100*/
      case 0x02:	// maximale Temperatur
      /*~-1*/
      {
         /*~T*/
         Communication_SendLong(COMMUNICATION_RS232,TEXT_ABS_STATISTICS_MAX_TEMPERATURE_CHANNEL_1,StatResults.chMaxTemperature,1,0);
         /*~I:101*/
         if (chWhat2Print != 0xFF)
         /*~-1*/
         {
            /*~T*/
            break;
         /*~-1*/
         }
         /*~E:I101*/
      /*~-1*/
      }
      /*~E:F100*/
      /*~E:A99*/
      /*~A:102*/
      /*~+:Maximales Gewicht*/
      /*~F:103*/
      case 0x03:	// maximales Gewicht
      /*~-1*/
      {
         /*~T*/
         Communication_SendFloat(COMMUNICATION_RS232,TEXT_ABS_STATISTICS_MAX_WEIGHT_CHANNEL_1,StatResults.fMaxWeight,2,1,0);
         /*~I:104*/
         if (chWhat2Print != 0xFF)
         /*~-1*/
         {
            /*~T*/
            break;
         /*~-1*/
         }
         /*~E:I104*/
      /*~-1*/
      }
      /*~E:F103*/
      /*~E:A102*/
      /*~A:105*/
      /*~+:Anzahl der �berlastungen*/
      /*~F:106*/
      case 0x04:	// Anzahl der �berlastungen
      /*~-1*/
      {
         /*~T*/
         Communication_SendLong(COMMUNICATION_RS232,TEXT_ABS_STATISTICS_NB_OVERLOADS_CHANNEL_1,StatResults.nOverloads,1,0);
         /*~I:107*/
         if (chWhat2Print != 0xFF)
         /*~-1*/
         {
            /*~T*/
            break;
         /*~-1*/
         }
         /*~E:I107*/
      /*~-1*/
      }
      /*~E:F106*/
      /*~E:A105*/
      /*~A:108*/
      /*~+:0x05 - nur aus Kompatibilit�tsgr�nden vorhanden*/
      /*~F:109*/
      case 0x05:	// nur aus Kompatibilit�tsgr�nden vorhanden
      /*~-1*/
      {
         /*~I:110*/
         if (chWhat2Print != 0xFF)
         /*~-1*/
         {
            /*~T*/
            Communication_SendLong(COMMUNICATION_RS232,TEXT_PARAMETER_NOT_INCLUDED_CHANNEL_1,0,1,0);
            /*~T*/
            break;
         /*~-1*/
         }
         /*~E:I110*/
      /*~-1*/
      }
      /*~E:F109*/
      /*~E:A108*/
      /*~A:111*/
      /*~+:0x06 - nur aus Kompatibilit�tsgr�nden vorhanden*/
      /*~F:112*/
      case 0x06:	// nur aus Kompatibilit�tsgr�nden vorhanden
      /*~-1*/
      {
         /*~I:113*/
         if (chWhat2Print != 0xFF)
         /*~-1*/
         {
            /*~T*/
            Communication_SendLong(COMMUNICATION_RS232,TEXT_PARAMETER_NOT_INCLUDED_CHANNEL_1,0,1,0);
            /*~T*/
            break;
         /*~-1*/
         }
         /*~E:I113*/
      /*~-1*/
      }
      /*~E:F112*/
      /*~E:A111*/
      /*~A:114*/
      /*~+:Maximaler Rohmesswert*/
      /*~F:115*/
      case 0x08:	// maximaler Rohmesswert
      /*~-1*/
      {
         /*~T*/
         Communication_SendLong(COMMUNICATION_RS232,TEXT_ABS_STATISTICS_MAX_RMW_CHANNEL_1,StatResults.lMaxRMW,1,0);
         /*~I:116*/
         if (chWhat2Print != 0xFF)
         /*~-1*/
         {
            /*~T*/
            break;
         /*~-1*/
         }
         /*~E:I116*/
      /*~-1*/
      }
      /*~E:F115*/
      /*~E:A114*/
      /*~A:117*/
      /*~+:Maximaler Strom*/
      /*~F:118*/
      case 0x09:	// maximaler Strom
      /*~-1*/
      {
         /*~T*/
         Communication_SendFloat(COMMUNICATION_RS232,TEXT_ABS_STATISTICS_MAX_CURRENT_CHANNEL_1,StatResults.fMaxCurrent,2,1,0);
         /*~I:119*/
         if (chWhat2Print != 0xFF)
         /*~-1*/
         {
            /*~T*/
            break;
         /*~-1*/
         }
         /*~E:I119*/
      /*~-1*/
      }
      /*~E:F118*/
      /*~E:A117*/
      /*~A:120*/
      /*~+:Anzahl der Grenzwert�berschreitungen*/
      /*~F:121*/
      case 0x0A:	// Anzahl der Grenzwert�berschreitungen
      /*~-1*/
      {
         /*~T*/
         Communication_SendLong(COMMUNICATION_RS232,TEXT_ABS_STATISTICS_NB_OVERLIMITS_CHANNEL_1,StatResults.nOverLimits,1,0);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F121*/
      /*~E:A120*/
      /*~A:122*/
      /*~+:Zeitpunkt 'Maximales Gewicht'*/
      /*~F:123*/
      case 0x0B:	// Zeitpunkt bei maximalem Gewicht
      /*~-1*/
      {
         /*~A:124*/
         /*~+:Variablendeklarationen*/
         /*~T*/
         unsigned long ulTime;
         char szText[16];
         /*~E:A124*/
         /*~A:125*/
         /*~+:Variableninitialisierungen*/
         /*~T*/

         /*~E:A125*/
         /*~T*/
         Load_Parameter(LOAD_SAVE_STATISTICS_TIMEMAXWEIGHT_CH0,&ulTime,4);
         /*~I:126*/
         if (SYSTEM_MRW_MANAGER)
         /*~-1*/
         {
            /*~A:127*/
            /*~+:MRW-Manager-Mode : Zeitpunkt in Sekunden ausgeben*/
            /*~T*/
            Communication_SendLong(COMMUNICATION_RS232,TEXT_ABS_STATISTICS_TIME_AT_MAX_WEIGHT_CHANNEL_1,ulTime,1,0);
            /*~E:A127*/
         /*~-1*/
         }
         /*~O:I126*/
         /*~-2*/
         else
         {
            /*~A:128*/
            /*~+:Docklight-Modus : Zeit als String ausgeben*/
            /*~T*/
            Communication_SendString(COMMUNICATION_RS232,T_TEXT_ABS_STATISTICS_TIME_AT_MAX_WEIGHT_CHANNEL_1,1,0);
            /*~T*/
            sprintf(szText,"%ld:%02ld:%02ld",ulTime/3600,(ulTime%3600)/60,ulTime%60);
            Communication_SendString(COMMUNICATION_RS232,szText,0,0);
            /*~E:A128*/
         /*~-1*/
         }
         /*~E:I126*/
         /*~I:129*/
         if (chWhat2Print != 0xFF)
         /*~-1*/
         {
            /*~T*/
            break;
         /*~-1*/
         }
         /*~E:I129*/
      /*~-1*/
      }
      /*~E:F123*/
      /*~E:A122*/
      /*~O:C88*/
      /*~-2*/
      default:
      {
         /*~I:130*/
         if (!(chWhat2Print & 0x40))
         /*~-1*/
         {
            /*~T*/
            byParameterGuilty[0] = 0;
         /*~-1*/
         }
         /*~E:I130*/
      /*~-1*/
      }
   /*~-1*/
   }
   /*~E:C88*/
   /*~E:A87*/
   /*~-1*/
#endif
   /*~E:I86*/
   /*~E:A40*/
   /*~I:131*/
   if (chWhat2Print == 255)
   /*~-1*/
   {
      /*~A:132*/
      /*~+:�berschrift "Relativstatistik"*/
      /*~T*/
      Communication_SendString(COMMUNICATION_RS232,T_TEXT_RELATIVE_STATISTICS,2,1);
      Communication_SendString(COMMUNICATION_RS232,T_TEXT_LINE_001,0,1);
      /*~E:A132*/
   /*~-1*/
   }
   /*~E:I131*/
   /*~A:133*/
   /*~+:Ausgabe der Daten der Relativstatistik*/
   /*~T*/
   StatResults = StatisticsLibrary_GetResult(1);
   /*~I:134*/
#ifdef CHANNEL_0
   /*~A:135*/
   /*~+:Relativstatistik - Kanal 0*/
   /*~I:136*/
   if (chWhat2Print >= 0x40)
   /*~-1*/
   {
      /*~C:137*/
      switch (chWhat2Print)
      /*~-1*/
      {
         /*~A:138*/
         /*~+:Betriebszeit*/
         /*~F:139*/
         case 0x47:
         case 0xFF:
         /*~-1*/
         {
            /*~I:140*/
            if (!SYSTEM_MRW_MANAGER)
            /*~-1*/
            {
               /*~T*/
               Communication_SendString(COMMUNICATION_RS232,T_TEXT_OPERATING_HOURS,1,0);

            /*~-1*/
            }
            /*~E:I140*/
            /*~T*/
            // Absoluten Betriebsstundenz�hler auslesen (Betriebsstundenz�hler 1)
            //Communication_SendString(COMMUNICATION_RS232,System_GetOperatingHoursAsString(0),0,0);
            // Relativen Betriebsstundenz�hler auslesen (Betriebsstundenz�hler 2)
            Communication_SendString(COMMUNICATION_RS232,System_GetOperatingHoursAsString(1),0,0);
            /*~I:141*/
            if (chWhat2Print != 0xFF)
            /*~-1*/
            {
               /*~T*/
               break;
            /*~-1*/
            }
            /*~E:I141*/
         /*~-1*/
         }
         /*~E:F139*/
         /*~E:A138*/
         /*~A:142*/
         /*~+:0x40 - nur aus Kompatibilit�tsgr�nden vorhanden*/
         /*~F:143*/
         case 0x40:	// nur aus Kompatibilit�tsgr�nden vorhanden
         /*~-1*/
         {
            /*~I:144*/
            if (chWhat2Print != 0xFF)
            /*~-1*/
            {
               /*~T*/
               Communication_SendLong(COMMUNICATION_RS232,TEXT_PARAMETER_NOT_INCLUDED_CHANNEL_0,0,1,0);
               /*~T*/
               break;
            /*~-1*/
            }
            /*~E:I144*/
         /*~-1*/
         }
         /*~E:F143*/
         /*~E:A142*/
         /*~A:145*/
         /*~+:Minimale Temperatur*/
         /*~F:146*/
         case 0x41: // minimale Temperatur
         /*~-1*/
         {
            /*~T*/
            Communication_SendLong(COMMUNICATION_RS232,TEXT_REL_STATISTICS_MIN_TEMPERATURE_CHANNEL_0,StatResults.chMinTemperature,1,0);
            /*~I:147*/
            if (chWhat2Print != 0xFF)
            /*~-1*/
            {
               /*~T*/
               break;
            /*~-1*/
            }
            /*~E:I147*/
         /*~-1*/
         }
         /*~E:F146*/
         /*~E:A145*/
         /*~A:148*/
         /*~+:Maximale Temperatur*/
         /*~F:149*/
         case 0x42:	// maximale Temperatur
         /*~-1*/
         {
            /*~T*/
            Communication_SendLong(COMMUNICATION_RS232,TEXT_REL_STATISTICS_MAX_TEMPERATURE_CHANNEL_0,StatResults.chMaxTemperature,1,0);
            /*~I:150*/
            if (chWhat2Print != 0xFF)
            /*~-1*/
            {
               /*~T*/
               break;
            /*~-1*/
            }
            /*~E:I150*/
         /*~-1*/
         }
         /*~E:F149*/
         /*~E:A148*/
         /*~A:151*/
         /*~+:Maximales Gewicht*/
         /*~F:152*/
         case 0x43:	// maximales Gewicht
         /*~-1*/
         {
            /*~T*/
            Communication_SendFloat(COMMUNICATION_RS232,TEXT_REL_STATISTICS_MAX_WEIGHT_CHANNEL_0,StatResults.fMaxWeight,2,1,0);
            /*~I:153*/
            if (chWhat2Print != 0xFF)
            /*~-1*/
            {
               /*~T*/
               break;
            /*~-1*/
            }
            /*~E:I153*/
         /*~-1*/
         }
         /*~E:F152*/
         /*~E:A151*/
         /*~A:154*/
         /*~+:Anzahl der �berlastungen*/
         /*~F:155*/
         case 0x44:	// Anzahl der �berlastungen
         /*~-1*/
         {
            /*~T*/
            Communication_SendLong(COMMUNICATION_RS232,TEXT_REL_STATISTICS_NB_OVERLOADS_CHANNEL_0,StatResults.nOverloads,1,0);
            /*~I:156*/
            if (chWhat2Print != 0xFF)
            /*~-1*/
            {
               /*~T*/
               break;
            /*~-1*/
            }
            /*~E:I156*/
         /*~-1*/
         }
         /*~E:F155*/
         /*~E:A154*/
         /*~A:157*/
         /*~+:0x45 - nur aus Kompatibilit�tsgr�nden vorhanden*/
         /*~F:158*/
         case 0x45:	// nur aus Kompatibilit�tsgr�nden vorhanden
         /*~-1*/
         {
            /*~I:159*/
            if (chWhat2Print != 0xFF)
            /*~-1*/
            {
               /*~T*/
               Communication_SendLong(COMMUNICATION_RS232,TEXT_PARAMETER_NOT_INCLUDED_CHANNEL_0,0,1,0);
               /*~T*/
               break;
            /*~-1*/
            }
            /*~E:I159*/
         /*~-1*/
         }
         /*~E:F158*/
         /*~E:A157*/
         /*~A:160*/
         /*~+:0x46 - nur aus Kompatibilit�tsgr�nden vorhanden*/
         /*~F:161*/
         case 0x46:	// nur aus Kompatibilit�tsgr�nden vorhanden
         /*~-1*/
         {
            /*~I:162*/
            if (chWhat2Print != 0xFF)
            /*~-1*/
            {
               /*~T*/
               Communication_SendLong(COMMUNICATION_RS232,TEXT_PARAMETER_NOT_INCLUDED_CHANNEL_0,0,1,0);
               /*~T*/
               break;
            /*~-1*/
            }
            /*~E:I162*/
         /*~-1*/
         }
         /*~E:F161*/
         /*~E:A160*/
         /*~A:163*/
         /*~+:Maximaler Rohmesswert*/
         /*~F:164*/
         case 0x48:	// maximaler Rohmesswert
         /*~-1*/
         {
            /*~T*/
            Communication_SendLong(COMMUNICATION_RS232,TEXT_REL_STATISTICS_MAX_RMW_CHANNEL_0,StatResults.lMaxRMW,1,0);
            /*~I:165*/
            if (chWhat2Print != 0xFF)
            /*~-1*/
            {
               /*~T*/
               break;
            /*~-1*/
            }
            /*~E:I165*/
         /*~-1*/
         }
         /*~E:F164*/
         /*~E:A163*/
         /*~A:166*/
         /*~+:Maximaler Strom*/
         /*~F:167*/
         case 0x49:	// maximaler Strom
         /*~-1*/
         {
            /*~T*/
            Communication_SendFloat(COMMUNICATION_RS232,TEXT_REL_STATISTICS_MAX_CURRENT_CHANNEL_0,StatResults.fMaxCurrent,2,1,0);
            /*~I:168*/
            if (chWhat2Print != 0xFF)
            /*~-1*/
            {
               /*~T*/
               break;
            /*~-1*/
            }
            /*~E:I168*/
         /*~-1*/
         }
         /*~E:F167*/
         /*~E:A166*/
         /*~A:169*/
         /*~+:Anzahl der Grenzwert�berschreitungen*/
         /*~F:170*/
         case 0x4A:	// Anzahl der Grenzwert�berschreitungen
         /*~-1*/
         {
            /*~T*/
            Communication_SendLong(COMMUNICATION_RS232,TEXT_REL_STATISTICS_NB_OVERLIMITS_CHANNEL_0,StatResults.nOverLimits,1,0);
            /*~T*/
            break;
         /*~-1*/
         }
         /*~E:F170*/
         /*~E:A169*/
         /*~A:171*/
         /*~+:Zeitpunkt 'Maximales Gewicht'*/
         /*~F:172*/
         case 0x0B:	// Zeitpunkt bei maximalem Gewicht
         /*~-1*/
         {
            /*~A:173*/
            /*~+:Variablendeklarationen*/
            /*~T*/
            unsigned long ulTime;
            char szText[16];
            /*~E:A173*/
            /*~A:174*/
            /*~+:Variableninitialisierungen*/
            /*~T*/

            /*~E:A174*/
            /*~T*/
            Load_Parameter(LOAD_SAVE_STATISTICS_TIMEMAXWEIGHT_CH1,&ulTime,4);
            /*~I:175*/
            if (SYSTEM_MRW_MANAGER)
            /*~-1*/
            {
               /*~A:176*/
               /*~+:MRW-Manager-Mode : Zeitpunkt in Sekunden ausgeben*/
               /*~T*/
               Communication_SendLong(COMMUNICATION_RS232,TEXT_REL_STATISTICS_TIME_AT_MAX_WEIGHT_CHANNEL_0,ulTime,1,0);
               /*~E:A176*/
            /*~-1*/
            }
            /*~O:I175*/
            /*~-2*/
            else
            {
               /*~A:177*/
               /*~+:Docklight-Modus : Zeit als String ausgeben*/
               /*~T*/
               Communication_SendString(COMMUNICATION_RS232,T_TEXT_REL_STATISTICS_TIME_AT_MAX_WEIGHT_CHANNEL_0,1,0);
               /*~T*/
               sprintf(szText,"%ld:%02ld:%02ld",ulTime/3600,(ulTime%3600)/60,ulTime%60);
               Communication_SendString(COMMUNICATION_RS232,szText,0,0);
               /*~E:A177*/
            /*~-1*/
            }
            /*~E:I175*/
            /*~I:178*/
            if (chWhat2Print != 0xFF)
            /*~-1*/
            {
               /*~T*/
               break;
            /*~-1*/
            }
            /*~E:I178*/
         /*~-1*/
         }
         /*~E:F172*/
         /*~E:A171*/
         /*~O:C137*/
         /*~-2*/
         default:
         {
            /*~T*/
            byParameterGuilty[1] = 0;
         /*~-1*/
         }
      /*~-1*/
      }
      /*~E:C137*/
   /*~-1*/
   }
   /*~E:I136*/
   /*~E:A135*/
   /*~-1*/
#endif
   /*~E:I134*/
   /*~I:179*/
#ifdef CHANNEL_1
   /*~A:180*/
   /*~+:Relativstatistik - Kanal 1*/
   /*~I:181*/
   if (chWhat2Print >= 0x40)
   /*~-1*/
   {
      /*~C:182*/
      switch (chWhat2Print)
      /*~-1*/
      {
         /*~A:183*/
         /*~+:Betriebszeit*/
         /*~F:184*/
         case 0x47:
         case 0xFF:
         /*~-1*/
         {
            /*~I:185*/
            if (!SYSTEM_MRW_MANAGER)
            /*~-1*/
            {
               /*~T*/
               Communication_SendString(COMMUNICATION_RS232,T_TEXT_OPERATING_HOURS,1,0);

            /*~-1*/
            }
            /*~E:I185*/
            /*~T*/
            Communication_SendString(COMMUNICATION_RS232,System_GetOperatingHoursAsString(0),0,0);
            /*~I:186*/
            if (chWhat2Print != 0xFF)
            /*~-1*/
            {
               /*~T*/
               break;
            /*~-1*/
            }
            /*~E:I186*/
         /*~-1*/
         }
         /*~E:F184*/
         /*~E:A183*/
         /*~A:187*/
         /*~+:0x40 - nur aus Kompatibilit�tsgr�nden vorhanden*/
         /*~F:188*/
         case 0x40:	// nur aus Kompatibilit�tsgr�nden vorhanden

         /*~-1*/
         {
            /*~I:189*/
            if (chWhat2Print != 0xFF)
            /*~-1*/
            {
               /*~T*/
               Communication_SendLong(COMMUNICATION_RS232,TEXT_PARAMETER_NOT_INCLUDED_CHANNEL_1,0,1,0);
               /*~T*/
               break;
            /*~-1*/
            }
            /*~E:I189*/
         /*~-1*/
         }
         /*~E:F188*/
         /*~E:A187*/
         /*~A:190*/
         /*~+:Minimale Temperatur*/
         /*~F:191*/
         case 0x41: // minimale Temperatur
         /*~-1*/
         {
            /*~T*/
            Communication_SendLong(COMMUNICATION_RS232,TEXT_REL_STATISTICS_MIN_TEMPERATURE_CHANNEL_1,StatResults.chMinTemperature,1,0);
            /*~I:192*/
            if (chWhat2Print != 0xFF)
            /*~-1*/
            {
               /*~T*/
               break;
            /*~-1*/
            }
            /*~E:I192*/
         /*~-1*/
         }
         /*~E:F191*/
         /*~E:A190*/
         /*~A:193*/
         /*~+:Maximale Temperatur*/
         /*~F:194*/
         case 0x42:	// maximale Temperatur
         /*~-1*/
         {
            /*~T*/
            Communication_SendLong(COMMUNICATION_RS232,TEXT_REL_STATISTICS_MAX_TEMPERATURE_CHANNEL_1,StatResults.chMaxTemperature,1,0);
            /*~I:195*/
            if (chWhat2Print != 0xFF)
            /*~-1*/
            {
               /*~T*/
               break;
            /*~-1*/
            }
            /*~E:I195*/
         /*~-1*/
         }
         /*~E:F194*/
         /*~E:A193*/
         /*~A:196*/
         /*~+:Maximales Gewicht*/
         /*~F:197*/
         case 0x43:	// maximales Gewicht
         /*~-1*/
         {
            /*~T*/
            Communication_SendFloat(COMMUNICATION_RS232,TEXT_REL_STATISTICS_MAX_WEIGHT_CHANNEL_1,StatResults.fMaxWeight,2,1,0);
            /*~I:198*/
            if (chWhat2Print != 0xFF)
            /*~-1*/
            {
               /*~T*/
               break;
            /*~-1*/
            }
            /*~E:I198*/
         /*~-1*/
         }
         /*~E:F197*/
         /*~E:A196*/
         /*~A:199*/
         /*~+:Anzahl der �berlastungen*/
         /*~F:200*/
         case 0x44:	// Anzahl der �berlastungen
         /*~-1*/
         {
            /*~T*/
            Communication_SendLong(COMMUNICATION_RS232,TEXT_REL_STATISTICS_NB_OVERLOADS_CHANNEL_1,StatResults.nOverloads,1,0);
            /*~I:201*/
            if (chWhat2Print != 0xFF)
            /*~-1*/
            {
               /*~T*/
               break;
            /*~-1*/
            }
            /*~E:I201*/
         /*~-1*/
         }
         /*~E:F200*/
         /*~E:A199*/
         /*~A:202*/
         /*~+:0x45 - nur aus Kompatibilit�tsgr�nden vorhanden*/
         /*~F:203*/
         case 0x45:	// nur aus Kompatibilit�tsgr�nden vorhanden
         /*~-1*/
         {
            /*~I:204*/
            if (chWhat2Print != 0xFF)
            /*~-1*/
            {
               /*~T*/
               Communication_SendLong(COMMUNICATION_RS232,TEXT_PARAMETER_NOT_INCLUDED_CHANNEL_1,0,1,0);
               /*~T*/
               break;
            /*~-1*/
            }
            /*~E:I204*/
         /*~-1*/
         }
         /*~E:F203*/
         /*~E:A202*/
         /*~A:205*/
         /*~+:0x46 - nur aus Kompatibilit�tsgr�nden vorhanden*/
         /*~F:206*/
         case 0x46:	// nur aus Kompatibilit�tsgr�nden vorhanden
         /*~-1*/
         {
            /*~I:207*/
            if (chWhat2Print != 0xFF)
            /*~-1*/
            {
               /*~T*/
               Communication_SendLong(COMMUNICATION_RS232,TEXT_PARAMETER_NOT_INCLUDED_CHANNEL_1,0,1,0);
               /*~T*/
               break;
            /*~-1*/
            }
            /*~E:I207*/
         /*~-1*/
         }
         /*~E:F206*/
         /*~E:A205*/
         /*~A:208*/
         /*~+:Maximaler Rohmesswert*/
         /*~F:209*/
         case 0x48:	// maximaler Rohmesswert
         /*~-1*/
         {
            /*~T*/
            Communication_SendLong(COMMUNICATION_RS232,TEXT_REL_STATISTICS_MAX_RMW_CHANNEL_1,StatResults.lMaxRMW,1,0);
            /*~I:210*/
            if (chWhat2Print != 0xFF)
            /*~-1*/
            {
               /*~T*/
               break;
            /*~-1*/
            }
            /*~E:I210*/
         /*~-1*/
         }
         /*~E:F209*/
         /*~E:A208*/
         /*~A:211*/
         /*~+:Maximaler Strom*/
         /*~F:212*/
         case 0x49:	// maximaler Strom
         /*~-1*/
         {
            /*~T*/
            Communication_SendFloat(COMMUNICATION_RS232,TEXT_REL_STATISTICS_MAX_CURRENT_CHANNEL_1,StatResults.fMaxCurrent,2,1,0);
            /*~I:213*/
            if (chWhat2Print != 0xFF)
            /*~-1*/
            {
               /*~T*/
               break;
            /*~-1*/
            }
            /*~E:I213*/
         /*~-1*/
         }
         /*~E:F212*/
         /*~E:A211*/
         /*~A:214*/
         /*~+:Anzahl der Grenzwert�berschreitungen*/
         /*~F:215*/
         case 0x4A:	// Anzahl der Grenzwert�berschreitungen
         /*~-1*/
         {
            /*~T*/
            Communication_SendLong(COMMUNICATION_RS232,TEXT_REL_STATISTICS_NB_OVERLIMITS_CHANNEL_1,StatResults.nOverLimits,1,0);
            /*~T*/
            break;
         /*~-1*/
         }
         /*~E:F215*/
         /*~E:A214*/
         /*~A:216*/
         /*~+:Zeitpunkt 'Maximales Gewicht'*/
         /*~F:217*/
         case 0x0B:	// Zeitpunkt bei maximalem Gewicht
         /*~-1*/
         {
            /*~A:218*/
            /*~+:Variablendeklarationen*/
            /*~T*/
            unsigned long ulTime;
            char szText[16];
            /*~E:A218*/
            /*~A:219*/
            /*~+:Variableninitialisierungen*/
            /*~T*/

            /*~E:A219*/
            /*~T*/
            Load_Parameter(LOAD_SAVE_STATISTICS_TIMEMAXWEIGHT_CH1,&ulTime,4);
            /*~I:220*/
            if (SYSTEM_MRW_MANAGER)
            /*~-1*/
            {
               /*~A:221*/
               /*~+:MRW-Manager-Mode : Zeitpunkt in Sekunden ausgeben*/
               /*~T*/
               Communication_SendLong(COMMUNICATION_RS232,TEXT_REL_STATISTICS_TIME_AT_MAX_WEIGHT_CHANNEL_1,ulTime,1,0);
               /*~E:A221*/
            /*~-1*/
            }
            /*~O:I220*/
            /*~-2*/
            else
            {
               /*~A:222*/
               /*~+:Docklight-Modus : Zeit als String ausgeben*/
               /*~T*/
               Communication_SendString(COMMUNICATION_RS232,T_TEXT_REL_STATISTICS_TIME_AT_MAX_WEIGHT_CHANNEL_1,1,0);
               /*~T*/
               sprintf(szText,"%ld:%02ld:%02ld",ulTime/3600,(ulTime%3600)/60,ulTime%60);
               Communication_SendString(COMMUNICATION_RS232,szText,0,0);
               /*~E:A222*/
            /*~-1*/
            }
            /*~E:I220*/
            /*~I:223*/
            if (chWhat2Print != 0xFF)
            /*~-1*/
            {
               /*~T*/
               break;
            /*~-1*/
            }
            /*~E:I223*/
         /*~-1*/
         }
         /*~E:F217*/
         /*~E:A216*/
         /*~O:C182*/
         /*~-2*/
         default:
         {
            /*~T*/
            byParameterGuilty[1] = 0;
         /*~-1*/
         }
      /*~-1*/
      }
      /*~E:C182*/
   /*~-1*/
   }
   /*~E:I181*/
   /*~E:A180*/
   /*~-1*/
#endif
   /*~E:I179*/
   /*~E:A133*/
   /*~A:224*/
   /*~+:Fehlermeldung ausgeben, wenn der Parameter nicht g�ltig war*/
   /*~I:225*/
   if ((!byParameterGuilty[0])||(!byParameterGuilty[1]))
   /*~-1*/
   {
      /*~K*/
      /*~+:// Parameter war nicht g�ltig*/
      /*~T*/
      Communication_SendString(COMMUNICATION_RS232,TEXT_E002,1,0);

   /*~-1*/
   }
   /*~E:I225*/
   /*~E:A224*/
/*~-1*/
}
/*~E:F28*/
/*~E:A27*/
/*~A:226*/
/*~+:void 					Statistics_Setup(char byDefault)*/
/*~F:227*/
void Statistics_Setup(char byDefault)
/*~-1*/
{
   /*~A:228*/
   /*~+:Variablendeklarationen*/
   /*~T*/
   STATISTICSLIBRARY_SETUP StatisticsSetup;
   /*~E:A228*/
   /*~A:229*/
   /*~+:Variableninitialisierungen*/
   /*~T*/

   /*~E:A229*/
   /*~I:230*/
   if (byDefault)
   /*~-1*/
   {
      /*~T*/
      // Defaultwerte setzen
      StatisticsSetup.byRunStatistics = 1;
      StatisticsSetup.chFilterCheckTemperature = 3;
      StatisticsSetup.chFilterCheckWeight = 3;
      StatisticsSetup.fMotionLimitCheckWeight = 5;
      StatisticsSetup.chFilterOverLimit = 3;
      StatisticsSetup.fLimitOverLimit = 1000; 
      /*~T*/
      // Parameter speichern
      Save_Parameter(LOAD_SAVE_STATISTICS_SETUP,&StatisticsSetup,sizeof(STATISTICSLIBRARY_SETUP));
   /*~-1*/
   }
   /*~O:I230*/
   /*~-2*/
   else
   {
      /*~T*/
      // Parameter laden
      Load_Parameter(LOAD_SAVE_STATISTICS_SETUP,&StatisticsSetup,sizeof(STATISTICSLIBRARY_SETUP));
   /*~-1*/
   }
   /*~E:I230*/
   /*~T*/
   // Statistik auf alle F�lle einschalten
   StatisticsSetup.byRunStatistics = 1;
   /*~T*/
   // Parameter f�r die Absolut- und Relativ-Statistik setzen
   StatisticsLibrary_Setup(0,StatisticsSetup);
   StatisticsLibrary_Setup(1,StatisticsSetup);
/*~-1*/
}
/*~E:F227*/
/*~E:A226*/
/*~A:231*/
/*~+:void 					Statistics_SetSetup(STATISTICSLIBRARY_SETUP StatisticsSetup)*/
/*~F:232*/
void Statistics_SetSetup(STATISTICSLIBRARY_SETUP StatisticsSetup)
/*~-1*/
{
   /*~T*/
   // Parameter speichern
   Save_Parameter(LOAD_SAVE_STATISTICS_SETUP,&StatisticsSetup,sizeof(STATISTICSLIBRARY_SETUP));
   /*~T*/
   // Parameter f�r die Absolut- und Relativ-Statistik setzen
   StatisticsLibrary_Setup(0,StatisticsSetup);
   StatisticsLibrary_Setup(1,StatisticsSetup);
/*~-1*/
}
/*~E:F232*/
/*~E:A231*/
/*~K*/
/*~+:*/
/*~A:233*/
/*~+:void 					StatisticsLibrary_Interface(unsigned char chWhat2Do,unsigned char chAddParameter,void* pData)*/
/*~F:234*/
void StatisticsLibrary_Interface(unsigned char chWhat2Do,unsigned char chAddParameter,void* pData)
/*~-1*/
{
   /*~A:235*/
   /*~+:Variablendeklarationen*/
   /*~T*/
   unsigned char chOffset;
   /*~E:A235*/
   /*~A:236*/
   /*~+:Variableninitialisierungen*/
   /*~I:237*/
   if (chAddParameter)
   /*~-1*/
   {
      /*~T*/
      chOffset = 1;
   /*~-1*/
   }
   /*~O:I237*/
   /*~-2*/
   else
   {
      /*~T*/
      chOffset = 0;
   /*~-1*/
   }
   /*~E:I237*/
   /*~E:A236*/
   /*~C:238*/
   switch (chWhat2Do)
   /*~-1*/
   {
      /*~A:239*/
      /*~+:Laden der einzelnen Statistikdaten*/
      /*~A:240*/
      /*~+:STATISTICSLIBRARY_LOAD_MINTEMP*/
      /*~F:241*/
      case STATISTICSLIBRARY_LOAD_MINTEMP:
      /*~-1*/
      {
         /*~T*/
         Load_Parameter(LOAD_SAVE_STATISTICS_MINTEMP + chOffset,pData,1);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F241*/
      /*~E:A240*/
      /*~A:242*/
      /*~+:STATISTICSLIBRARY_LOAD_MAXTEMP*/
      /*~F:243*/
      case STATISTICSLIBRARY_LOAD_MAXTEMP:
      /*~-1*/
      {
         /*~T*/
         Load_Parameter(LOAD_SAVE_STATISTICS_MAXTEMP + chOffset,pData,1);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F243*/
      /*~E:A242*/
      /*~A:244*/
      /*~+:STATISTICSLIBRARY_LOAD_MAXWEIGHT*/
      /*~F:245*/
      case STATISTICSLIBRARY_LOAD_MAXWEIGHT:
      /*~-1*/
      {
         /*~T*/
         Load_Parameter(LOAD_SAVE_STATISTICS_MAXWEIGHT + chOffset,pData,4);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F245*/
      /*~E:A244*/
      /*~A:246*/
      /*~+:STATISTICSLIBRARY_LOAD_MAXRMW*/
      /*~F:247*/
      case STATISTICSLIBRARY_LOAD_MAXRMW:
      /*~-1*/
      {
         /*~T*/
         Load_Parameter(LOAD_SAVE_STATISTICS_MAXRMW + chOffset,pData,4);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F247*/
      /*~E:A246*/
      /*~A:248*/
      /*~+:STATISTICSLIBRARY_LOAD_MAXCURRENT*/
      /*~F:249*/
      case STATISTICSLIBRARY_LOAD_MAXCURRENT:
      /*~-1*/
      {
         /*~T*/
         Load_Parameter(LOAD_SAVE_STATISTICS_MAXCURRENT + chOffset,pData,4);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F249*/
      /*~E:A248*/
      /*~A:250*/
      /*~+:STATISTICSLIBRARY_LOAD_NBOVERLOADS*/
      /*~F:251*/
      case STATISTICSLIBRARY_LOAD_NBOVERLOADS:
      /*~-1*/
      {
         /*~T*/
         Load_Parameter(LOAD_SAVE_STATISTICS_NBOVERLOADS + chOffset,pData,2);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F251*/
      /*~E:A250*/
      /*~A:252*/
      /*~+:STATISTICSLIBRARY_LOAD_NBOVERLIMITS*/
      /*~F:253*/
      case STATISTICSLIBRARY_LOAD_NBOVERLIMITS:
      /*~-1*/
      {
         /*~T*/
         Load_Parameter(LOAD_SAVE_STATISTICS_NBOVERLIMITS + chOffset,pData,2);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F253*/
      /*~E:A252*/
      /*~E:A239*/
      /*~A:254*/
      /*~+:Speichern der einzelnen Statistikdaten*/
      /*~A:255*/
      /*~+:STATISTICSLIBRARY_SAVE_MINTEMP*/
      /*~F:256*/
      case STATISTICSLIBRARY_SAVE_MINTEMP:
      /*~-1*/
      {
         /*~T*/
         Save_Parameter(LOAD_SAVE_STATISTICS_MINTEMP + chOffset,pData,1);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F256*/
      /*~E:A255*/
      /*~A:257*/
      /*~+:STATISTICSLIBRARY_SAVE_MAXTEMP*/
      /*~F:258*/
      case STATISTICSLIBRARY_SAVE_MAXTEMP:
      /*~-1*/
      {
         /*~T*/
         Save_Parameter(LOAD_SAVE_STATISTICS_MAXTEMP + chOffset,pData,1);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F258*/
      /*~E:A257*/
      /*~A:259*/
      /*~+:STATISTICSLIBRARY_SAVE_MAXWEIGHT*/
      /*~F:260*/
      case STATISTICSLIBRARY_SAVE_MAXWEIGHT:
      /*~-1*/
      {
         /*~T*/
         Save_Parameter(LOAD_SAVE_STATISTICS_MAXWEIGHT + chOffset,pData,4);
         Save_Parameter(LOAD_SAVE_STATISTICS_TIMEMAXWEIGHT + chOffset,&OPERATINGHOURS,4);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F260*/
      /*~E:A259*/
      /*~A:261*/
      /*~+:STATISTICSLIBRARY_SAVE_MAXRMW*/
      /*~F:262*/
      case STATISTICSLIBRARY_SAVE_MAXRMW:
      /*~-1*/
      {
         /*~T*/
         Save_Parameter(LOAD_SAVE_STATISTICS_MAXRMW + chOffset,pData,4);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F262*/
      /*~E:A261*/
      /*~A:263*/
      /*~+:STATISTICSLIBRARY_SAVE_MAXCURRENT*/
      /*~F:264*/
      case STATISTICSLIBRARY_SAVE_MAXCURRENT:
      /*~-1*/
      {
         /*~T*/
         Save_Parameter(LOAD_SAVE_STATISTICS_MAXCURRENT + chOffset,pData,4);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F264*/
      /*~E:A263*/
      /*~A:265*/
      /*~+:STATISTICSLIBRARY_SAVE_NBOVERLOADS*/
      /*~F:266*/
      case STATISTICSLIBRARY_SAVE_NBOVERLOADS:
      /*~-1*/
      {
         /*~T*/
         Save_Parameter(LOAD_SAVE_STATISTICS_NBOVERLOADS + chOffset,pData,2);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F266*/
      /*~E:A265*/
      /*~A:267*/
      /*~+:STATISTICSLIBRARY_SAVE_NBOVERLIMITS*/
      /*~F:268*/
      case STATISTICSLIBRARY_SAVE_NBOVERLIMITS:
      /*~-1*/
      {
         /*~T*/
         Save_Parameter(LOAD_SAVE_STATISTICS_NBOVERLIMITS + chOffset,pData,2);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F268*/
      /*~E:A267*/
      /*~E:A254*/
   /*~-1*/
   }
   /*~E:C238*/
/*~-1*/
}
/*~E:F234*/
/*~E:A233*/
