/*~-1*/
/*~XSF_LANGUAGE: C/C++*/
/*~A:1*/
/*~+:Versions-Beschreibung*/
/*~K*/
/*#LH:0F"Doxygen_AverageFilter.h"=29-51*/
/*~+:-> Doxygen_AverageFilter.h*/
/*~+:*/
/*~+:Doxygen_AverageFilter.h*/
/*~E:A1*/
/*~I:2*/
#ifndef __AVERAGEFILTER_H

/*~T*/
#define __AVERAGEFILTER_H

/*~A:3*/
/*~+:Includes*/
/*~T*/

/*~E:A3*/
/*~A:4*/
/*~+:Definitionen*/
/*~I:5*/
#ifdef AVERAGEFILTER_1 
/*~T*/
#define AVERAGEFILTER_NB_CHANELS		1
#define AVERAGEFILTER_MAXFILTERDEPTH	255	///< maximale Filtertiefe
/*~-1*/
#endif
/*~E:I5*/
/*~I:6*/
#ifdef AVERAGEFILTER_1_20 
/*~T*/
#define AVERAGEFILTER_NB_CHANELS		1
#define AVERAGEFILTER_MAXFILTERDEPTH	20	///< maximale Filtertiefe
/*~-1*/
#endif
/*~E:I6*/
/*~I:7*/
#ifdef AVERAGEFILTER_1_32 
/*~T*/
#define AVERAGEFILTER_NB_CHANELS		1
#define AVERAGEFILTER_MAXFILTERDEPTH	32	///< maximale Filtertiefe
/*~-1*/
#endif
/*~E:I7*/
/*~I:8*/
#ifdef AVERAGEFILTER_2_20 
/*~T*/
#define AVERAGEFILTER_NB_CHANELS		2
#define AVERAGEFILTER_MAXFILTERDEPTH	20	///< maximale Filtertiefe
/*~-1*/
#endif
/*~E:I8*/
/*~I:9*/
#ifdef AVERAGEFILTER_2_32 
/*~T*/
#define AVERAGEFILTER_NB_CHANELS		2
#define AVERAGEFILTER_MAXFILTERDEPTH	32	///< maximale Filtertiefe
/*~-1*/
#endif
/*~E:I9*/
/*~I:10*/
#ifdef AVERAGEFILTER_3_20 
/*~T*/
#define AVERAGEFILTER_NB_CHANELS		3
#define AVERAGEFILTER_MAXFILTERDEPTH	20	///< maximale Filtertiefe
/*~-1*/
#endif
/*~E:I10*/
/*~I:11*/
#ifdef AVERAGEFILTER_4_20
/*~T*/
#define AVERAGEFILTER_NB_CHANELS		4
#define AVERAGEFILTER_MAXFILTERDEPTH	20	///< maximale Filtertiefe
/*~-1*/
#endif
/*~E:I11*/
/*~E:A4*/
/*~A:12*/
/*~+:Struktur-Definitionen*/
/*~T*/

/*~E:A12*/
/*~A:13*/
/*~+:Funktionsdeklarationen*/
/*~T*/
extern char 			AverageFilter_Filter(unsigned char byChannel, long* pnWhat2Filter);
extern unsigned char	AverageFilter_GetFilterDepth(unsigned char byChannel);
extern void 			AverageFilter_Init(void);
extern char 			AverageFilter_Preset(unsigned char byChannel, long nValue);
extern char 			AverageFilter_SetFilterDepth(unsigned char byChannel, unsigned char byFilterDepth);

extern char 			AverageFilter_Setup(unsigned char byChannel, unsigned char byFilterdepth);

extern char* 			AverageFilter_Version(void);
/*~E:A13*/
/*~A:14*/
/*~+:Variablen*/
/*~T*/

/*~E:A14*/
/*~-1*/
#endif
/*~E:I2*/
