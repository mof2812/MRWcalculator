/*~-1*/
/*~XSF_LANGUAGE: C/C++*/
/*~K*/
/*~+:File :        Weight.c*/
/*~+:*/
/*~+:Version :     V1.001*/
/*~+:*/
/*~+:Date :        09.02.2022*/
/*~+:*/
/*~+:Time :        10:23*/
/*~+:*/
/*~+:Author :      MOF*/
/*~+:*/
/*~+:Hardware :*/
/*~+:*/
/*~+:Description : Routinen zur Ermittlung des Gewichtswertes in digitaler und normierter Form. Zus�tzlich wird hier noch die Auswertung der Temperatur und der Netzteilspannung erledigt. */
/*~+:*/
/*~+:*/
/*~A:1*/
/*~+:Includes*/
/*~T*/
#include "Weight.h"
/*~E:A1*/
/*~I:2*/
#ifdef SYSTEM_CND_UNITTEST_WEIGHT

/*~T*/
#include "Simulator.h"
#include <string.h>
#include <stdio.h>
/*~-1*/
#endif
/*~E:I2*/
/*~A:3*/
/*~+:Funktionseigene Definitionen*/
/*~T*/

/*~E:A3*/
/*~A:4*/
/*~+:Funktionseigene Struktur-Definitionen*/
/*~T*/

/*~E:A4*/
/*~A:5*/
/*~+:Funktionsprototypen*/
/*~T*/
void 				Weight(void);
char				Weight_GetEModulCompensationOnOff(void);
void 				Weight_GetMotionParameter(MEASUREMENT_MOTIONPARAMETER *pMotionParameter);
unsigned char 		Weight_Ini(unsigned char byMode);
char 				Weight_IsMotion(void);
char 				Weight_SetCalibrationFactor(float fCalibrationFactor);
char 				Weight_SetCalibrationRegardingActualWeight(float fRatedValue);
void 				Weight_SetEModulCompensationOn(bit bOnOff);
char 				Weight_SetMotionParameter(MEASUREMENT_MOTIONPARAMETER MotionParameter,bit bStore);

char 				Weight_SetTareValue(float fTare2Set,bit bStore);
char 				Weight_SetZero(long lZero2Set);
char 				Weight_SetZeroRegardingActualWeight(void);

/*~E:A5*/
/*~A:6*/
/*~+:Globale Variablen*/
/*~T*/
MEASUREMENT_VALUE Weight_MeasurementFromADC;
MEASUREMENT_VALUE Weight_FilteredMeasurement;
MEASUREMENT_VALUE Weight_CorrectedMeasurement;
MEASUREMENT_VALUE Weight_ZeroCorrectedMeasurement;
MEASUREMENT_VALUE Weight_ZeroCorrectedMeasurementStandardized;
MEASUREMENT_VALUE Weight_ZeroCorrectedMeasurementWithTare;
MEASUREMENT_VALUE Weight_GrossWeight;
MEASUREMENT_VALUE Weight_TareWeight;
MEASUREMENT_VALUE Weight_NetWeight;

long g_Weight_lSimulatedRMW;
unsigned int  g_Weight_uExecuteMotionCounter;


/*~E:A6*/
/*~A:7*/
/*~+:void 				Weight(void)*/
/*~F:8*/
void Weight(void)
/*~-1*/
{
   /*~A:9*/
   /*~+:Beschreibung*/
   /*~T*/
   /*!
   \fn void Weight(void)
   
   <b>Beschreibung:</b><br>
   Ermittelt das normierte Systemgewicht und diverse Zwischenergebnisse.
   
   \retval
   ./.
   
   <b>Zugriff:</b><br>
   [X] �ffentlich / [ ] Privat
   */
   /*~E:A9*/
   /*~A:10*/
   /*~+:Variablendeklarationen*/
   /*~T*/
   MEASUREMENT_VALUE Measurement;
   MEASUREMENT_MOTIONPARAMETER MotionParameter;
   float fCalibrationFactor;
   /*~K*/
   /*~+:*/
   /*~T*/
   MEASUREMENT_VALUE 	MVTemp;
   /*~K*/
   /*~+:*/
   /*~E:A10*/
   /*~I:11*/
#ifdef SYSTEM_CND_UNITTEST_WEIGHT
   /*~T*/
   char szDebug[24];
   /*~-1*/
#endif
   /*~E:I11*/
   /*~A:12*/
   /*~+:Variableninitialsierungen*/
   /*~T*/

   /*~E:A12*/
   /*~I:13*/
   if ((ADuC836_ADCIsNewConversionValue(ADuC836_ADC_PRIMARY) != 0)||(g_SystemControl.bySimulate & 0x01))
   /*~-1*/
   {
      /*~T*/
      // JA

      /*~A:14*/
      /*~+:Nur zu Debugzwecken - SYSTEM_CND_LEDS_4_DEBUG_P06_CHECK_WEIGHING_CYCLE*/
      /*~I:15*/
#ifdef SYSTEM_CND_LEDS_4_DEBUG_P06_CHECK_WEIGHING_CYCLE		// nicht definiert
      /*~T*/
      P06 = 0;
      /*~-1*/
#endif
      /*~E:I15*/
      /*~E:A14*/
      /*~I:16*/
#ifdef MIT_GEWICHTSSIMULATION		// nicht simuliert
      /*~A:17*/
      /*~+:MIT_GEWICHTSSIMULATION*/
      /*~I:18*/
      if (!(g_SystemControl.bySimulate & 0x01))
      /*~-1*/
      {
         /*~T*/
         // Roh-Messwert vom ADC holen
         Measurement.nLong = ADuC836_ADCGetConversionValue(ADuC836_ADC_PRIMARY,0);
      /*~-1*/
      }
      /*~O:I18*/
      /*~-2*/
      else
      {
         /*~A:19*/
         /*~+:Simulation des Gewicht-Rohmesswerts*/
         /*~T*/
         Measurement.nLong = g_Weight_lSimulatedRMW;
         /*~E:A19*/
      /*~-1*/
      }
      /*~E:I18*/
      /*~E:A17*/
      /*~O:I16*/
      /*~-1*/
#else
      /*~I:20*/
#ifndef SYSTEM_CND_UNITTEST_WEIGHT 
      /*~T*/
      // Roh-Messwert vom ADC holen
      Measurement.nLong = ADuC836_ADCGetConversionValue(ADuC836_ADC_PRIMARY,0);
      /*~O:I20*/
      /*~-1*/
#else
      /*~T*/
      // Roh-Messwert vom simulierten ADC holen
      Measurement.nLong = Simulator_GetRMW();
      /*~-1*/
#endif
      /*~E:I20*/
      /*~-1*/
#endif
      /*~E:I16*/
      /*~T*/
      Weight_MeasurementFromADC = Measurement;
      /*~I:21*/
#ifdef SYSTEM_CND_UNITTEST_WEIGHT
      /*~T*/
      sprintf(szDebug, "%ld", Weight_MeasurementFromADC.nLong);
      Communication_SendRawString(COMMUNICATION_RS232, szDebug);

      /*~-1*/
#endif
      /*~E:I21*/
      /*~T*/
      // Rohmesswertfilterung (nur wenn tats�chlich ein neuer Wert vorliegt !!!)
      Measurement_Processing(MEASUREMENT_PROCESSING_FILTER,WEIGHT_WEIGHTCHANNEL,&Measurement);
      /*~I:22*/
#ifdef SYSTEM_CND_UNITTEST_WEIGHT
      /*~T*/
      sprintf(szDebug, ";%ld", Measurement.nLong);
      Communication_SendRawString(COMMUNICATION_RS232, szDebug);

      /*~-1*/
#endif
      /*~E:I22*/
      /*~T*/
      // Nullpunktverrechnung
      Measurement_Processing(MEASUREMENT_PROCESSING_ZERO,WEIGHT_WEIGHTCHANNEL,&Measurement);
      /*~I:23*/
#ifdef SYSTEM_CND_UNITTEST_WEIGHT
      /*~T*/
      sprintf(szDebug, ";%ld", Measurement.nLong);
      Communication_SendRawString(COMMUNICATION_RS232, szDebug);

      /*~-1*/
#endif
      /*~E:I23*/
      /*~K*/
      /*~+:/~* Ge�ndert am 09.02.2022 aufgrund eines Fehlers in der E-Modul-Berechnung *~/*/
      /*~T*/
      // Temperatur- und E-Modul-Kompensation
      Measurement_Processing(MEASUREMENT_PROCESSING_CORRECTION,WEIGHT_WEIGHTCHANNEL,&Measurement);
      Weight_ZeroCorrectedMeasurement = Measurement;
      /*~I:24*/
#ifdef SYSTEM_CND_UNITTEST_WEIGHT
      /*~T*/
      sprintf(szDebug, ";%ld", Weight_ZeroCorrectedMeasurement.nLong);
      Communication_SendRawString(COMMUNICATION_RS232, szDebug);

      /*~-1*/
#endif
      /*~E:I24*/
      /*~F:25*/
      /* F�r die Kennlinienaufnahme bedarf des korrigierten, aber nicht nullpunktverrechneten Messwerts */
      /*~-1*/
      {
         /*~T*/
         Measurement_GetZero(WEIGHT_WEIGHTCHANNEL,&MVTemp); /* Nullpunkt holen */

         Weight_FilteredMeasurement.nLong = Weight_ZeroCorrectedMeasurement.nLong + MVTemp.nLong;	/* und verrechnen */

      /*~-1*/
      }
      /*~E:F25*/
      /*~I:26*/
#ifdef SYSTEM_CND_UNITTEST_WEIGHT
      /*~T*/
      sprintf(szDebug, ";%ld", Weight_FilteredMeasurement.nLong);
      Communication_SendRawString(COMMUNICATION_RS232, szDebug);

      /*~-1*/
#endif
      /*~E:I26*/
      /*~K*/
      /*~+:/~* Ende - Ge�ndert am 09.02.2022 *~/*/
      /*~T*/
      // Normierung
      Measurement_Processing(MEASUREMENT_PROCESSING_STANDARDIZATION,WEIGHT_WEIGHTCHANNEL,&Measurement);
      Weight_ZeroCorrectedMeasurementStandardized = Measurement;

      /*~I:27*/
#ifdef SYSTEM_CND_UNITTEST_WEIGHT
      /*~T*/
      sprintf(szDebug, ";%0.2f", Weight_ZeroCorrectedMeasurementStandardized.fFloat);
      Communication_SendRawString(COMMUNICATION_RS232, szDebug);

      /*~-1*/
#endif
      /*~E:I27*/
      /*~T*/
      // Tara-Verechnung
      Measurement_Processing(MEASUREMENT_PROCESSING_TARE,WEIGHT_WEIGHTCHANNEL,&Measurement);

      /*~T*/
      //Measurement_GetResults(WEIGHT_WEIGHTCHANNEL,&Results[WEIGHT_WEIGHTCHANNEL],0);
      Measurement_GetResult(WEIGHT_WEIGHTCHANNEL,MEASUREMENT_GET_GROSS,&Weight_GrossWeight);

      Measurement_GetResult(WEIGHT_WEIGHTCHANNEL,MEASUREMENT_GET_TARE,&Weight_TareWeight);

      Measurement_GetResult(WEIGHT_WEIGHTCHANNEL,MEASUREMENT_GET_NET,&Weight_NetWeight);
      /*~I:28*/
#ifdef SYSTEM_CND_UNITTEST_WEIGHT
      /*~T*/
      sprintf(szDebug, ";%0.2f", Weight_GrossWeight.fFloat);
      Communication_SendRawString(COMMUNICATION_RS232, szDebug);

      /*~T*/
      sprintf(szDebug, ";%0.2f", Weight_TareWeight.fFloat);
      Communication_SendRawString(COMMUNICATION_RS232, szDebug);

      /*~T*/
      sprintf(szDebug, ";%0.2f", Weight_NetWeight.fFloat);
      Communication_SendRawString(COMMUNICATION_RS232, szDebug);

      /*~-1*/
#endif
      /*~E:I28*/
      /*~T*/
      // Jetzt noch den Tarawert vom nullpunktkorrigiertem Rohmesswert abziehen
      // Dazu zun�chst den Kalibrierfaktor ermitteln
      Measurement_GetCalibrationFactor(WEIGHT_WEIGHTCHANNEL,&fCalibrationFactor);
      // und rechnen
      Weight_ZeroCorrectedMeasurementWithTare.nLong = Weight_ZeroCorrectedMeasurement.nLong - (long)(Weight_TareWeight.fFloat / fCalibrationFactor);
      /*~A:29*/
      /*~+:Nur zu Debugzwecken - SYSTEM_CND_LEDS_4_DEBUG_P06_CHECK_WEIGHING_CYCLE*/
      /*~I:30*/
#ifdef SYSTEM_CND_LEDS_4_DEBUG_P06_CHECK_WEIGHING_CYCLE
      /*~T*/
      P06 = 1;
      /*~-1*/
#endif
      /*~E:I30*/
      /*~E:A29*/
      /*~I:31*/
#ifdef SYSTEM_CND_UNITTEST_WEIGHT
      /*~T*/
      sprintf(szDebug, ";%ld\r\n", Weight_ZeroCorrectedMeasurementWithTare.nLong);
      Communication_SendRawString(COMMUNICATION_RS232, szDebug);

      /*~-1*/
#endif
      /*~E:I31*/
   /*~-1*/
   }
   /*~O:I13*/
   /*~-2*/
   else
   {
      /*~T*/
      // NEIN
      /*~T*/
      // Letzten Messwert �bernehmen

      //Measurement = Weight_MeasurementFromADC;
   /*~-1*/
   }
   /*~E:I13*/
   /*~I:32*/
   if (Flag100ms)
   /*~-1*/
   {
      /*~A:33*/
      /*~+:Motion-�berpr�fung*/
      /*~T*/
      Weight_GetMotionParameter(&MotionParameter);
      /*~I:34*/
      if (g_Weight_uExecuteMotionCounter++ >= MotionParameter.byMotionFilter)
      /*~-1*/
      {
         /*~T*/
         g_Weight_uExecuteMotionCounter = 0;

         // Motion-�berpr�fung
         Measurement_Processing(MEASUREMENT_PROCESSING_MOTION,WEIGHT_WEIGHTCHANNEL,&Weight_ZeroCorrectedMeasurementStandardized);

      /*~-1*/
      }
      /*~E:I34*/
      /*~E:A33*/
   /*~-1*/
   }
   /*~E:I32*/
   /*~A:35*/
   /*~+:Nur zu Debugzwecken - SYSTEM_CND_LEDS_4_DEBUG_P06_MOTION*/
   /*~I:36*/
#ifdef SYSTEM_CND_LEDS_4_DEBUG_P06_MOTION
   /*~I:37*/
   if (Weight_IsMotion())
   /*~-1*/
   {
      /*~T*/
      P06 = 1;
   /*~-1*/
   }
   /*~O:I37*/
   /*~-2*/
   else
   {
      /*~T*/
      P06 = 0;
   /*~-1*/
   }
   /*~E:I37*/
   /*~-1*/
#endif
   /*~E:I36*/
   /*~E:A35*/
/*~-1*/
}
/*~E:F8*/
/*~E:A7*/
/*~A:38*/
/*~+:char				Weight_GetEModulCompensationOnOff(void)*/
/*~F:39*/
char Weight_GetEModulCompensationOnOff(void)
/*~-1*/
{
   /*~T*/
   return Global.chEModulCompensationOn;
/*~-1*/
}
/*~E:F39*/
/*~E:A38*/
/*~A:40*/
/*~+:void 				Weight_GetMotionParameter(MEASUREMENT_MOTIONPARAMETER *pMotionParameter)*/
/*~F:41*/
void Weight_GetMotionParameter(MEASUREMENT_MOTIONPARAMETER *pMotionParameter)
/*~-1*/
{
   /*~T*/
   Measurement_GetMotionParameter(WEIGHT_WEIGHTCHANNEL,pMotionParameter);
/*~-1*/
}
/*~E:F41*/
/*~E:A40*/
/*~A:42*/
/*~+:unsigned char 			Weight_Ini(unsigned char byMode)*/
/*~F:43*/
unsigned char Weight_Ini(unsigned char byMode)
/*~-1*/
{
   /*~A:44*/
   /*~+:Beschreibung*/
   /*~T*/
   /*!
   \fn unsigned char Weight_Ini(unsigned char byMode)
   
   <b>Beschreibung:</b><br>
   Initialisierung der Parameter zur Gewichtsermittlung.
   
   \param
   byMode: 
   \param
   0 = Initialisierung mit Defaultwerten, 
   \param
   1 = Initialisierung mit abgespeicherten Werten.
   
   \return
   Status der Funktionsausf�hrung.
   
   \retval
   0: Alles okay.
   
   \retval
   1: Fehler bei der Messwert-Initialisierung.
   
   \retval
   2: Fehler beim Einrichten des Messwertkanals 'Gewichtskanal'.
   
   \retval
   3: Fehler beim Einrichten des Messwertkanals 'Temperaturkanal' (in Vorbereitung).
   
   \retval
   4: Fehler beim Einrichten des Messwertkanals 'Netzteilkanal' (nur Master) (in Vorbereitung).
   
   \retval
   5: Fehler beim Setzen des Kalibrierfaktors 'Gewichtskanal'.
   
   \retval
   6: Fehler beim Setzen des Kalibrierfaktors 'Temperaturkanal' (in Vorbereitung).
   
   \retval
   7: Fehler beim Setzen des Kalibrierfaktors 'Netzteilkanal' (nur Master) (in Vorbereitung).
   
   \retval
   8: Fehler beim Setzen der Motion-Parameter 'Gewichtskanal'.
   
   \retval
   9: Fehler beim Setzen der Motion-Parameter 'Temperaturkanal' (in Vorbereitung).
   
   \retval
   10: Fehler beim Setzen der Motion-Parameter 'Netzteilkanal' (nur Master) (in Vorbereitung).
   
   \retval
   11: Fehler beim Setzen der Messwert-Sequenz 'Gewichtskanal'.
   
   \retval
   12: Fehler beim Setzen der Messwert-Sequenz 'Temperaturkanal' (in Vorbereitung).
   
   \retval
   13: Fehler beim Setzen der Messwert-Sequenz 'Netzteilkanal' (nur Master) (in Vorbereitung).
   
   \retval
   14: Fehler beim Initialisieren der Korrekturfunktion 'Gewichtskanal'.
   
   \retval
   15: Fehler beim Initialisieren der Korrekturfunktion 'Temperaturkanal' (in Vorbereitung). 
   
   \retval
   16: Fehler beim Initialisieren der Korrekturfunktion 'Netzteilkanal' (nur Master) (in Vorbereitung). 
   
   \retval
   17: Fehler bei der Initialisierung des Filters 'Gewichtskanal'.
   
   \retval
   18: Fehler bei der Initialisierung des Filters 'Temperaturkanal' (in Vorbereitung). 
   
   \retval
   19: Fehler bei der Initialisierung des Filters 'Netzteilkanal' (nur Master) (in Vorbereitung). 
   
   \retval
   20: Fehler beim Setzen des Taras.
   
   <b>Zugriff:</b><br>
   [X] �ffentlich / [ ] Privat
   */
   /*~E:A44*/
   /*~A:45*/
   /*~+:Variablendeklarationen*/
   /*~T*/
   MEASUREMENT_MOTIONPARAMETER MotionParameter;
   unsigned char chRetVal;
   /*~E:A45*/
   /*~A:46*/
   /*~+:Variableninitialsierungen*/
   /*~T*/
   // R�ckgabewert nullen
   chRetVal = 0;

   // Z�hler f�r Aktivierung der Motion-Untersuchung
   g_Weight_uExecuteMotionCounter = 0;
   /*~E:A46*/
   /*~A:47*/
   /*#LJ:Weight_Ini=1*/
   /*~+:Messwert-Routine einrichten.*/
   /*~I:48*/
#ifdef MOF	///< wird jetzt in der Main_Init vorgenommen
   /*~A:49*/
   /*~+:Messwertroutinen initialisieren.*/
   /*~T*/
   // Messwertroutinen initialisieren
   Measurement_Init();
   /*~E:A49*/
   /*~-1*/
#endif
   /*~E:I48*/
   /*~C:50*/
   switch (byMode)
   /*~-1*/
   {
      /*~A:51*/
      /*~+:Initialisierung mit Defaultwerten.*/
      /*~F:52*/
      case 0:		// Initialisierung mit Defaultwerten
      /*~-1*/
      {
         /*~A:53*/
         /*~+:Nullpunkt setzen*/
         /*~T*/
         Weight_SetZero(0);
         /*~E:A53*/
         /*~A:54*/
         /*~+:Kalibrierfaktor setzen. Bei Fehler: R�ckgabe von 5*/
         /*~I:55*/
         // Kalibrierfaktor setzen
         if (Weight_SetCalibrationFactor(0.12))
         /*~-1*/
         {
            /*~T*/
            // Fehler beim Setzen des Kalibrierfaktors
            return 5;
         /*~-1*/
         }
         /*~E:I55*/
         /*~E:A54*/
         /*~A:56*/
         /*~+:Motion-Parameter setzen. Bei Fehler: R�ckgabe von 2*/
         /*~T*/
         // Motion-Grenze und �berpr�fungsrate setzen
         // Motion�berpr�fung erfolgt bei jedem Aufruf von Measurement_Processing und wird
         // bei einer Messwertbewegung von mehr als 10kg als solche erkannt.
         MotionParameter.fMotionLimit = 10;
         // MotionParameter.byMotionCheckOn = 1;
         MotionParameter.byMotionFilter = 4;			// Motionpr�fung alle 400ms
         //         MotionParameter.byNoMotionFilter = 6;		// wird nicht ben�tigt
         /*~T*/
         // Motion-�berpr�fung einstellen
         /*~I:57*/
         if (chRetVal = Weight_SetMotionParameter(MotionParameter,1))
         /*~-1*/
         {
            /*~T*/
            return (chRetVal);
         /*~-1*/
         }
         /*~E:I57*/
         /*~E:A56*/
         /*~A:58*/
         /*~+:Tara setzen. Bei Fehler: R�ckgabe von 20*/
         /*~I:59*/
         if (Weight_SetTareValue(0,1))
         /*~-1*/
         {
            /*~T*/
            // Fehler beim Setzen des Taras
            return 20;
         /*~-1*/
         }
         /*~E:I59*/
         /*~E:A58*/
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F52*/
      /*~E:A51*/
      /*~A:60*/
      /*~+:Initialisierung mit abgespeicherten Werten.*/
      /*~F:61*/
      case 1:		// Initialisierung mit abgespeicherten Werten
      /*~-1*/
      {
         /*~A:62*/
         /*~+:Variablendeklarationen*/
         /*~T*/
         float fValue;
         long lValue;

         /*~E:A62*/
         /*~A:63*/
         /*~+:Nullpunkt*/
         /*~T*/
         // Nullpunkt auslesen 
         Load_Parameter(LOAD_SAVE_WEIGHT_ZERO,&lValue,0);

         // und setzen
         Weight_SetZero(lValue);
         /*~E:A63*/
         /*~A:64*/
         /*~+:Kalibrierfaktor*/
         /*~T*/
         // Kalibrierfaktor auslesen 
         Load_Parameter(LOAD_SAVE_WEIGHT_CALIBRATION_FACTOR,&fValue,0);

         // und setzen
         Weight_SetCalibrationFactor(fValue);
         /*~E:A64*/
         /*~A:65*/
         /*~+:Tara*/
         /*~T*/
         // Kalibrierfaktor auslesen 
         Load_Parameter(LOAD_SAVE_WEIGHT_TARA,&fValue,0);
         /*~T*/
         // und setzen
         /*~I:66*/
         if (Weight_SetTareValue(fValue,1))
         /*~-1*/
         {
            /*~T*/
            return 20;
         /*~-1*/
         }
         /*~E:I66*/
         /*~E:A65*/
         /*~A:67*/
         /*~+:Motion-Parameter*/
         /*~T*/
         // Motionparameter auslesen 
         Load_Parameter(LOAD_SAVE_WEIGHT_MOTIONPARAMETER,&MotionParameter,0);
         /*~T*/
         // und setzen
         /*~I:68*/
         if (chRetVal = Weight_SetMotionParameter(MotionParameter,0))
         /*~-1*/
         {
            /*~T*/
            return (chRetVal);
         /*~-1*/
         }
         /*~E:I68*/
         /*~E:A67*/
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F61*/
      /*~E:A60*/
   /*~-1*/
   }
   /*~E:C50*/
   /*~E:A47*/
   /*~A:69*/
   /*~+:Korrekturfunktion initialisieren. Bei Fehler: R�ckgabe von 14,15 oder 16.*/
   /*~I:70*/
   // Korrekturfunktion initialisieren
   if (Correction_Ini(byMode))
   /*~-1*/
   {
      /*~T*/
      // Fehler beim Initialisieren der Korrekturfunktion
      return 14;
   /*~-1*/
   }
   /*~E:I70*/
   /*~E:A69*/
   /*~A:71*/
   /*~+:E-Modul-Kompensation einschalten*/
   /*~I:72*/
   if (!byMode)
   /*~-1*/
   {
      /*~T*/
      // Global.chEModulCompensationOn = 0;
      // E-Modul-Kompensation defaultm��ig einschalten
      Global.chEModulCompensationOn = 1;

      // und speichern
      Save_Parameter(LOAD_SAVE_E_MODUL_COMPENSATION_ONOFF,&Global.chEModulCompensationOn,1);
   /*~-1*/
   }
   /*~O:I72*/
   /*~-2*/
   else
   {
      /*~T*/
      Load_Parameter(LOAD_SAVE_E_MODUL_COMPENSATION_ONOFF,&Global.chEModulCompensationOn,1);
   /*~-1*/
   }
   /*~E:I72*/
   /*~T*/

   /*~E:A71*/
   /*~T*/
   return 0;
/*~-1*/
}
/*~E:F43*/
/*~E:A42*/
/*~A:73*/
/*~+:char 				Weight_IsMotion(void)*/
/*~F:74*/
char Weight_IsMotion(void)
/*~-1*/
{
   /*~T*/
   return Measurement_IsMotion(WEIGHT_WEIGHTCHANNEL);
/*~-1*/
}
/*~E:F74*/
/*~E:A73*/
/*~A:75*/
/*~+:char 				Weight_SetCalibrationFactor(float fCalibrationFactor)*/
/*~F:76*/
char Weight_SetCalibrationFactor(float fCalibrationFactor)
/*~-1*/
{
   /*~A:77*/
   /*~+:Beschreibung*/
   /*~T*/
   /*!
   \fn char Weight_SetCalibrationFactor(float fCalibrationFactor)
   
   <b>Beschreibung:</b><br>
   Manuelles Setzen des Kalibrierfaktors.
   
   \param
   fCalibrationFactor: Zu setzender Kalibrierfaktor.
   
   \return
   Status der Funktionsausf�hrung.
   
   \retval
   0: Alles okay.
   \retval
   1: Fehler beim Setzen des Kalibrierfaktors - alter Wert wird beibehalten.
   
   <b>Zugriff:</b><br>
   [X] �ffentlich / [ ] Privat
   */
   /*~E:A77*/
   /*~A:78*/
   /*~+:Variablendeklarationen*/
   /*~T*/
   float fOldCalibrationFactor;
   /*~E:A78*/
   /*~A:79*/
   /*~+:Variableninitialisierungen*/
   /*~T*/
   Measurement_GetCalibrationFactor (0,&fOldCalibrationFactor);  
   /*~E:A79*/
   /*~I:80*/
   if ((fCalibrationFactor >= MIN_KALIBRIERFAKTOR)&&(fCalibrationFactor <= MAX_KALIBRIERFAKTOR))
   /*~-1*/
   {
      /*~I:81*/
      // Kalibrierfaktor berechnen
      if (!Measurement_SetCalibrationFactor(0,fCalibrationFactor))
      /*~-1*/
      {
         /*~I:82*/
         if (fCalibrationFactor != fOldCalibrationFactor)
         /*~-1*/
         {
            /*~T*/
            //Kalibrierfaktor abspeichern
            Save_Parameter(LOAD_SAVE_WEIGHT_CALIBRATION_FACTOR,&fCalibrationFactor,0);
         /*~-1*/
         }
         /*~E:I82*/
         /*~T*/
         return 0;
         /*~K*/
         /*~+:*/
      /*~-1*/
      }
      /*~O:I81*/
      /*~-2*/
      else
      {
         /*~T*/
         // Fehler
      /*~-1*/
      }
      /*~E:I81*/
   /*~-1*/
   }
   /*~O:I80*/
   /*~-2*/
   else
   {
      /*~T*/
      // Fehler
   /*~-1*/
   }
   /*~E:I80*/
   /*~T*/
   // alten Kalibrierfaktor wieder setzen
   Measurement_SetCalibrationFactor(0,fOldCalibrationFactor);
   /*~T*/
   return 1;
/*~-1*/
}
/*~E:F76*/
/*~E:A75*/
/*~A:83*/
/*~+:char				Weight_SetCalibrationRegardingActualWeight(float fRatedValue)*/
/*~F:84*/
char Weight_SetCalibrationRegardingActualWeight(float fRatedValue)
/*~-1*/
{
   /*~A:85*/
   /*~+:Beschreibung*/
   /*~T*/
   /*!
   \fn char Weight_SetCalibrationRegardingActualWeight(float fRatedValue)
   
   <b>Beschreibung:</b><br>
   Kalibrierfaktor in Abh�ngigkeit des aktuelle Gewichtes und einem Sollgewicht setzen. Die �berpr�fung auf eine eventuelle Gewichtsbewegung erfolgt in der Messwertbibliotheke.
   
   \param
   fRatedValue: Sollgewicht, auf welches kalibriert wird.
   
   \return
   Status der Funktionsausf�hrung.
   
   \retval
   0: Alles okay.
   \retval
   1: Fehler beim Setzen des Kalibrierfaktors - alter Wert wird beibehalten.
   \retval
   2: Gewicht instabil.
   
   <b>Zugriff:</b><br>
   [X] �ffentlich / [ ] Privat
   */
   /*~E:A85*/
   /*~A:86*/
   /*~+:Variablendeklarationen*/
   /*~T*/
   MEASUREMENT_VALUE Weight;
   float fCalibrationFactor;
   float fOldCalibrationFactor;
   /*~E:A86*/
   /*~A:87*/
   /*~+:Variableninitialisierungen*/
   /*~T*/
   Weight.fFloat = fRatedValue;
   Measurement_GetCalibrationFactor (0,&fOldCalibrationFactor);  
   /*~E:A87*/
   /*~I:88*/
   // Kalibrierfaktor berechnen
   if (!Measurement_CalcCalibrationFactor(0,Weight,0))
   /*~-1*/
   {
      /*~T*/
      // Kalibrierfaktor zur�cklesen
      Measurement_GetCalibrationFactor (0,&fCalibrationFactor);
      /*~I:89*/
      if ((fCalibrationFactor >= MIN_KALIBRIERFAKTOR)&&(fCalibrationFactor <= MAX_KALIBRIERFAKTOR))
      /*~-1*/
      {
         /*~T*/
         //Kalibrierfaktor abspeichern
         Save_Parameter(LOAD_SAVE_WEIGHT_CALIBRATION_FACTOR,&fCalibrationFactor,0);
         /*~T*/
         return 0;
         /*~K*/
         /*~+:*/
      /*~-1*/
      }
      /*~O:I89*/
      /*~-2*/
      else
      {
         /*~T*/
         // Fehler
      /*~-1*/
      }
      /*~E:I89*/
   /*~-1*/
   }
   /*~O:I88*/
   /*~-2*/
   else
   {
      /*~T*/
      // Fehler
   /*~-1*/
   }
   /*~E:I88*/
   /*~T*/
   // alten Kalibrierfaktor wieder setzen
   Measurement_SetCalibrationFactor(0,fOldCalibrationFactor);
   /*~T*/
   return 1;
/*~-1*/
}
/*~E:F84*/
/*~E:A83*/
/*~A:90*/
/*~+:void 				Weight_SetEModulCompensationOn(bit bOnOff)*/
/*~F:91*/
void Weight_SetEModulCompensationOn(bit bOnOff)
/*~-1*/
{
   /*~T*/
   Global.chEModulCompensationOn = bOnOff;

   // und speichern
   Save_Parameter(LOAD_SAVE_E_MODUL_COMPENSATION_ONOFF,&Global.chEModulCompensationOn,1);
/*~-1*/
}
/*~E:F91*/
/*~E:A90*/
/*~A:92*/
/*~+:char 				Weight_SetMotionParameter(MEASUREMENT_MOTIONPARAMETER MotionParameter,bit bStore)*/
/*~F:93*/
char Weight_SetMotionParameter(MEASUREMENT_MOTIONPARAMETER MotionParameter,bit bStore)
/*~-1*/
{
   /*~I:94*/
   // Motion-�berpr�fung einstellen
   if (Measurement_SetMotionParameter(WEIGHT_WEIGHTCHANNEL,MotionParameter))
   /*~-1*/
   {
      /*~T*/
      // Fehler beim Setzen der Motion-Parameter
      return 8;
   /*~-1*/
   }
   /*~O:I94*/
   /*~-2*/
   else
   {
      /*~I:95*/
      if (bStore)
      /*~-1*/
      {
         /*~T*/
         // Motionparameter speichern 
         Save_Parameter(LOAD_SAVE_WEIGHT_MOTIONPARAMETER,&MotionParameter,0);
      /*~-1*/
      }
      /*~E:I95*/
   /*~-1*/
   }
   /*~E:I94*/
/*~-1*/
}
/*~E:F93*/
/*~E:A92*/
/*~A:96*/
/*~+:char 				Weight_SetTareValue(float fTare2Set,bit bStore)*/
/*~F:97*/
char Weight_SetTareValue(float fTare2Set,bit bStore)
/*~-1*/
{
   /*~A:98*/
   /*~+:Variablendeklarationen*/
   /*~T*/
   MEASUREMENT_VALUE Tare;
   /*~E:A98*/
   /*~I:99*/
   // nur positive Tara-Werte zulassen
   // if (fTare2Set >= 0)
   if(1)
   /*~-1*/
   {
      /*~T*/
      Tare.fFloat = fTare2Set;

      /*~I:100*/
      // Tara setzen
      if (!Measurement_SetTareValue(WEIGHT_WEIGHTCHANNEL,&Tare.fFloat))
      /*~-1*/
      {
         /*~I:101*/
         if (bStore)
         /*~-1*/
         {
            /*~T*/
            // Tara speichern 
            Save_Parameter(LOAD_SAVE_WEIGHT_TARA,&fTare2Set,0);
         /*~-1*/
         }
         /*~E:I101*/
         /*~T*/
         return 0;
      /*~-1*/
      }
      /*~O:I100*/
      /*~-2*/
      else
      {
         /*~T*/
         return 1;
      /*~-1*/
      }
      /*~E:I100*/
   /*~-1*/
   }
   /*~O:I99*/
   /*~-2*/
   else
   {
      /*~T*/
      return 2;
   /*~-1*/
   }
   /*~E:I99*/
/*~-1*/
}
/*~E:F97*/
/*~E:A96*/
/*~A:102*/
/*~+:char 				Weight_SetZero(long lZero2Set)*/
/*~F:103*/
char Weight_SetZero(long lZero2Set)
/*~-1*/
{
   /*~A:104*/
   /*~+:Beschreibung*/
   /*~T*/
   /*!
   \fn char Weight_SetZero(long lZero2Set)
   
   <b>Beschreibung:</b><br>
   Manuelles Setzen des Nullpunktes.
   
   \param
   lZero2Set: Zu setzender Nullpunkt.
   
   \return
   Status der Funktionsausf�hrung.
   
   \retval
   0: Alles okay.
   \retval
   1: Fehler beim Setzen des Nullpunktes - alter Wert wird beibehalten.
   
   <b>Zugriff:</b><br>
   [X] �ffentlich / [ ] Privat
   */

   /*~E:A104*/
   /*~A:105*/
   /*~+:Variablendeklarationen*/
   /*~T*/
   MEASUREMENT_VALUE Zero;
   MEASUREMENT_VALUE OldZero;
   /*~E:A105*/
   /*~A:106*/
   /*~+:Variabelninitialisierungen*/
   /*~T*/
   Measurement_GetZero (WEIGHT_WEIGHTCHANNEL,&OldZero);
   Zero.nLong = lZero2Set;
   /*~E:A106*/
   /*~I:107*/
   if ((Zero.nLong >= MIN_NULLPUNKT)&&(Zero.nLong <= MAX_NULLPUNKT))
   /*~-1*/
   {
      /*~I:108*/
      if (!Measurement_SetZeroValue(WEIGHT_WEIGHTCHANNEL,&Zero))
      /*~-1*/
      {
         /*~I:109*/
         if (Zero.nLong != OldZero.nLong)
         /*~-1*/
         {
            /*~T*/
            //Nullpunkt abspeichern
            Save_Parameter(LOAD_SAVE_WEIGHT_ZERO,&Zero,0);
         /*~-1*/
         }
         /*~E:I109*/
         /*~T*/
         return 0;
         /*~K*/
         /*~+:*/
      /*~-1*/
      }
      /*~O:I108*/
      /*~-2*/
      else
      {
         /*~T*/
         // Fehler
      /*~-1*/
      }
      /*~E:I108*/
   /*~-1*/
   }
   /*~O:I107*/
   /*~-2*/
   else
   {
      /*~T*/
      // Fehler
   /*~-1*/
   }
   /*~E:I107*/
   /*~T*/
   // alten Nullpunkt wieder setzen
   Measurement_SetZeroValue(WEIGHT_WEIGHTCHANNEL,&OldZero);
   /*~T*/
   return 1;
/*~-1*/
}
/*~E:F103*/
/*~E:A102*/
/*~A:110*/
/*~+:char 				Weight_SetZeroRegardingActualWeight(void)*/
/*~F:111*/
char Weight_SetZeroRegardingActualWeight(void)
/*~-1*/
{
   /*~A:112*/
   /*~+:Beschreibung*/
   /*~T*/
   /*!
   \fn char Weight_SetZeroRegardingActualWeight(void)
   
   <b>Beschreibung:</b><br>
   Setzen des Nullpunkts auf den augenblicklichen Gewichtswert. Die �berpr�fung auf eine eventuelle Gewichtsbewegung erfolgt in der Messwertbibliotheke.
   
   \param
   ./.
   
   \return
   Status der Funktionsausf�hrung.
   
   \retval
   0: Alles okay.
   \retval
   1: Fehler beim Setzen des Nullpunktes - alter Wert wird beibehalten.
   
   <b>Zugriff:</b><br>
   [X] �ffentlich / [ ] Privat
   */
   /*~E:A112*/
   /*~A:113*/
   /*~+:Variablendeklarationen*/
   /*~T*/
   MEASUREMENT_VALUE Zero;
   /*~E:A113*/
   /*~A:114*/
   /*~+:Variableninitialisierungen*/
   /*~T*/
     
   /*~E:A114*/
   /*~I:115*/
   // Setzen des Nullpunktes auf den aktuellen Rohmesswert
   if (!Measurement_SetZero(WEIGHT_WEIGHTCHANNEL))
   /*~-1*/
   {
      /*~T*/
      // neuen Nullpunkt auslesen
      Measurement_GetZero (WEIGHT_WEIGHTCHANNEL,&Zero);

      /*~I:116*/
      if ((Zero.nLong >= MIN_NULLPUNKT)&&(Zero.nLong <= MAX_NULLPUNKT))
      /*~-1*/
      {
         /*~T*/
         //Nullpunkt abspeichern
         Save_Parameter(LOAD_SAVE_WEIGHT_ZERO,&Zero,0);
         /*~T*/
         return 0;
      /*~-1*/
      }
      /*~O:I116*/
      /*~-2*/
      else
      {
         /*~T*/
         // Fehler
         /*~T*/
         return 1;
      /*~-1*/
      }
      /*~E:I116*/
   /*~-1*/
   }
   /*~O:I115*/
   /*~-2*/
   else
   {
      /*~T*/
      // Fehler
      /*~T*/
      return 2;
   /*~-1*/
   }
   /*~E:I115*/
/*~-1*/
}
/*~E:F111*/
/*~E:A110*/
