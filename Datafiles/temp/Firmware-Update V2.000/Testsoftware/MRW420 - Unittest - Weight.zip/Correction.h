/*~-1*/
/*~XSF_LANGUAGE: C/C++*/
/*~K*/
/*~+:File :        Correction.h*/
/*~+:*/
/*~+:Version :     V1.0*/
/*~+:*/
/*~+:Date :        04.07.2005*/
/*~+:*/
/*~+:Time :        10:23*/
/*~+:*/
/*~+:Author :      MOF*/
/*~+:*/
/*~+:Hardware :*/
/*~+:*/
/*~+:Description :*/
/*~I:1*/
#ifndef __CORRECTION_H

/*~T*/
#define __CORRECTION_H

/*~A:2*/
/*~+:Includes*/
/*~T*/
#include "Global.h"
#include "Measurement.h"
/*~E:A2*/
/*~A:3*/
/*~+:Definitionen*/
/*~T*/

/*~E:A3*/
/*~A:4*/
/*~+:Struktur-Definitionen*/
/*~T*/

/*~E:A4*/
/*~A:5*/
/*~+:Funktionsdeklarationen*/
/*~T*/
extern unsigned char 		Correction_Ini(unsigned char byMode);
extern char 				Correction_Interface(unsigned char byChannel,MEASUREMENT_VALUE* pMeasurement2Correct);
/*~E:A5*/
/*~A:6*/
/*~+:Variablen*/
/*~T*/

/*~E:A6*/
/*~-1*/
#endif
/*~E:I1*/
