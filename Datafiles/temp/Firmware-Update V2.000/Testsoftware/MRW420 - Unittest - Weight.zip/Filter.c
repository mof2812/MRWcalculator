/*~-1*/
/*~XSF_LANGUAGE: C/C++*/
/*~K*/
/*~+:File :        Filter.c*/
/*~+:*/
/*~+:Version :     V1.0*/
/*~+:*/
/*~+:Date :        04.07.2005*/
/*~+:*/
/*~+:Time :        10:23*/
/*~+:*/
/*~+:Author :      MOF*/
/*~+:*/
/*~+:Hardware :*/
/*~+:*/
/*~+:Description : Routinen zur Filterung der Messwerte.*/
/*~A:1*/
/*~+:Includes*/
/*~T*/
#include "Filter.h"
/*~E:A1*/
/*~A:2*/
/*~+:Funktionseigene Definitionen*/
/*~T*/

/*~E:A2*/
/*~A:3*/
/*~+:Funktionseigene Struktur-Definitionen*/
/*~T*/

/*~E:A3*/
/*~A:4*/
/*~+:Funktionsprototypen*/
/*~T*/
unsigned char 		Filter_Ini(unsigned char byMode);
char 				Filter_Interface(unsigned char byChannel,MEASUREMENT_VALUE* pMeasurement2Filter);
/*~E:A4*/
/*~A:5*/
/*~+:Globale Variablen*/
/*~T*/

/*~E:A5*/
/*~A:6*/
/*~+:unsigned char 		Filter_Ini(unsigned char byMode)*/
/*~F:7*/
unsigned char Filter_Ini(unsigned char byMode)
/*~-1*/
{
   /*~A:8*/
   /*~+:Beschreibung*/
   /*~T*/
   /*!
   \fn unsigned char Filter_Ini(unsigned char byMode)
   
   <b>Beschreibung:</b><br>
   Initialisierung der Filter-Funktion.
   
   \param
   byMode:
   \param
   0 = Initialisierung mit Defaultwerten, 
   \param
   1 = Initialisierung mit abgespeicherten Werten.
   
   \return
   Status der Funktionsausf�hrung
   
   \retval
   0: Alles okay
   
   \retval
   1: Fehler beim Anlegen der Filterkan�le
   
   \retval
   2: Fehler beim Parametrieren des Filterkanals 'Gewichtsermittlung'.
   
   \retval
   3: Fehler beim Parametrieren des Filterkanals 'Temperaturermittlung'.
   
   \retval
   4: Fehler beim Parametrieren des Filterkanals 'Netzteilspannungsermittlung'.
   
   \retval
   5: Fehler beim Parametrieren des Totbandfilters 'Gewichtsermittlung'.
    
   <b>Zugriff:</b><br>
   [ ] �ffentlich / [X] Privat
   */
   /*~E:A8*/
   /*~A:9*/
   /*~+:Variablendeklarationen*/
   /*~T*/
   unsigned char 	chFilterdepth2Set[3];
   /*~I:10*/
#ifdef SYSTEM_CND_WITH_DEADBAND_FILTER
   /*~T*/
   int				nBandWidth;
   /*~-1*/
#endif
   /*~E:I10*/
   /*~E:A9*/
   /*~A:11*/
   /*~+:Variableninitialisierungen*/
   /*~T*/

   /*~E:A11*/
   /*~A:12*/
   /*~+:Filterkan�le*/
   /*~A:13*/
   /*~+:Mittelwert-Filter*/
   /*~T*/
   AverageFilter_Init();
   /*~E:A13*/
   /*~I:14*/
#ifdef SYSTEM_CND_WITH_DEADBAND_FILTER
   /*~A:15*/
   /*~+:Totband-Filter*/
   /*~I:16*/
   if (DeadBandFilter_Init())
   /*~-1*/
   {
      /*~T*/
      return 1;
   /*~-1*/
   }
   /*~E:I16*/
   /*~E:A15*/
   /*~-1*/
#endif
   /*~E:I14*/
   /*~E:A12*/
   /*~C:17*/
   switch (byMode)
   /*~-1*/
   {
      /*~F:18*/
      /*#LJ:Filter_Ini=12*/
      case 0:		// Initialisierung mit Defaultwerten
      /*~-1*/
      {
         /*~A:19*/
         /*~+:Mittelwertfilterparameter auf Default*/
         /*~A:20*/
         /*~+:Mittelwertfilter f�r die Gewichtsermittlung mit einer Filtertiefe von 6 anlegen*/
         /*~T*/
         // Mittelwertfilter mit einer Filtertiefe von 6 anlegen, Long-Werte werden �bergeben

         chFilterdepth2Set[WEIGHT_WEIGHTCHANNEL] = FILTER_AVERAGEFILTER_DEFAULT_FILERDEPTH;
         /*~E:A20*/
         /*~E:A19*/
         /*~I:21*/
#ifdef SYSTEM_CND_WITH_DEADBAND_FILTER
         /*~A:22*/
         /*~+:Totbandfilterparameter auf Default*/
         /*~T*/
         // Defaultbandbreite anlegen
         nBandWidth = FILTER_DEADBANDFILTER_DEFAULT_BANDWIDTH;
         /*~E:A22*/
         /*~-1*/
#endif
         /*~E:I21*/
         /*~A:23*/
         /*~+:Mittelwertfilterparameter speichern*/
         /*~A:24*/
         /*~+:Parameter f�r den Mittelwertfilter der Gewichtsermittlung speichern*/
         /*~T*/
         // Mittelwertfiltertiefe f�r die Gewichtsermittlung speichern
         Save_Parameter(LOAD_SAVE_FILTER_DEPTH_WEIGHT,&chFilterdepth2Set[WEIGHT_WEIGHTCHANNEL],0);

         /*~E:A24*/
         /*~E:A23*/
         /*~I:25*/
#ifdef SYSTEM_CND_WITH_DEADBAND_FILTER
         /*~A:26*/
         /*~+:Totbandfilterparameter speichern*/
         /*~T*/
         // Parameter f�r den Totbandfilter der Gewichtsermittlung speichern
         Save_Parameter(LOAD_SAVE_FILTER_BANDWIDTH_WEIGHT,&nBandWidth,0);

         /*~E:A26*/
         /*~-1*/
#endif
         /*~E:I25*/
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F18*/
      /*~F:27*/
      case 1:		// Initialisierung mit abgespeicherten Werten
      /*~-1*/
      {
         /*~A:28*/
         /*~+:Mittelwertfilterparameter laden*/
         /*~A:29*/
         /*~+:Parameter f�r den Mittelwertfilter der Gewichtsermittlung laden*/
         /*~T*/
         // Mittelwertfiltertiefe f�r die Gewichtsermittlung laden
         Load_Parameter(LOAD_SAVE_FILTER_DEPTH_WEIGHT,&chFilterdepth2Set[WEIGHT_WEIGHTCHANNEL],0);
         /*~E:A29*/
         /*~E:A28*/
         /*~I:30*/
#ifdef SYSTEM_CND_WITH_DEADBAND_FILTER
         /*~A:31*/
         /*~+:Totbandfilterparameter laden*/
         /*~T*/
         // Totbandfilter-Bandbreite f�r die Gewichtsermittlung laden
         Load_Parameter(LOAD_SAVE_FILTER_BANDWIDTH_WEIGHT,&nBandWidth,0);

         /*~I:32*/
         // Plausibilit�tspr�fung
         if ((nBandWidth < 1)||(nBandWidth > 1000))
         /*~-1*/
         {
            /*~T*/
            nBandWidth = FILTER_DEADBANDFILTER_DEFAULT_BANDWIDTH;

            // Neue Bandweite speichern
            Save_Parameter(LOAD_SAVE_FILTER_BANDWIDTH_WEIGHT,&nBandWidth,0);
         /*~-1*/
         }
         /*~E:I32*/
         /*~E:A31*/
         /*~-1*/
#endif
         /*~E:I30*/
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F27*/
   /*~-1*/
   }
   /*~E:C17*/
   /*~A:33*/
   /*~+:Mittelwertfilterparameter setzen*/
   /*~A:34*/
   /*~+:Mittelwertfilter f�r die Gewichtsermittlung parametrieren*/
   /*~I:35*/
   // Mittelwertfilter f�r die Gewichtsermittlung parametrieren

   if (AverageFilter_Setup(WEIGHT_WEIGHTCHANNEL,chFilterdepth2Set[WEIGHT_WEIGHTCHANNEL]))
   /*~-1*/
   {
      /*~T*/
      return 2;
   /*~-1*/
   }
   /*~E:I35*/
   /*~E:A34*/
   /*~I:36*/
#ifdef MOF
   /*~I:37*/
#ifdef CHANNEL_0
   /*~A:38*/
   /*~+:Mittelwertfilter f�r die Netzteilspannungsermittlung parametrieren*/
   /*~I:39*/
   // Mittelwertfilter f�r die Netzteilspannungsermittlung parametrieren

   if (AverageFilter_Setup(WEIGHT_SUPPLYCHANEL,chFilterdepth2Set[WEIGHT_SUPPLYCHANEL],chDatatype2Set[WEIGHT_SUPPLYCHANEL]))
   /*~-1*/
   {
      /*~T*/
      return 4;
   /*~-1*/
   }
   /*~E:I39*/
   /*~E:A38*/
   /*~-1*/
#endif
   /*~E:I37*/
   /*~-1*/
#endif
   /*~E:I36*/
   /*~E:A33*/
   /*~I:40*/
#ifdef SYSTEM_CND_WITH_DEADBAND_FILTER
   /*~A:41*/
   /*~+:Totbandfilterparameter setzen*/
   /*~I:42*/
   if (DeadBandFilter_Setup(0,(float)nBandWidth,DEADBANDFILTER_LONGDATA))
   /*~-1*/
   {
      /*~T*/
      // Fehler beim Parametrieren des Totbandfilters 'Gewichtsermittlung'
      return 5;
   /*~-1*/
   }
   /*~E:I42*/
   /*~E:A41*/
   /*~-1*/
#endif
   /*~E:I40*/
   /*~T*/
   // Alles okay
   return 0;
/*~-1*/
}
/*~E:F7*/
/*~E:A6*/
/*~A:43*/
/*~+:char Filter_Interface(unsigned char byChannel,MEASUREMENT_VALUE* pMeasurement2Filter)*/
/*~F:44*/
char Filter_Interface(unsigned char byChannel,MEASUREMENT_VALUE* pMeasurement2Filter)
/*~-1*/
{
   /*~A:45*/
   /*~+:Variablendeklarationen*/
   /*~I:46*/
#ifdef SYSTEM_CND_WITH_DEADBAND_FILTER
   /*~T*/
   unsigned char byMode;
   /*~-1*/
#endif
   /*~E:I46*/
   /*~T*/
   unsigned char byRetVal;
   /*~E:A45*/
   /*~T*/
   byRetVal = 0;
   /*~I:47*/
#ifdef SYSTEM_CND_WITH_DEADBAND_FILTER
   /*~A:48*/
   /*~+:Totband- und Mittelwertfilter*/
   /*~C:49*/
   switch (byChannel)
   /*~-1*/
   {
      /*~A:50*/
      /*~+:WEIGHT_WEIGHTCHANNEL*/
      /*~F:51*/
      case WEIGHT_WEIGHTCHANNEL:
      /*~-1*/
      {
         /*~T*/
         byMode = 0x03;	// Mittelwert- und Totbandfilter
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F51*/
      /*~E:A50*/
      /*~A:52*/
      /*~+:CURRENTINTERFACE_FEEDBACKCHANEL*/
      /*~F:53*/
      case CURRENTINTERFACE_FEEDBACKCHANEL:
      /*~-1*/
      {
         /*~T*/
         byMode = 0x01;	// Mittelwertfilter
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F53*/
      /*~E:A52*/
   /*~-1*/
   }
   /*~E:C49*/
   /*~I:54*/
   if (byMode & 0x01)		// Mittelwertfilter
   /*~-1*/
   {
      /*~T*/
      byRetVal |= AverageFilter_Filter(byChannel,(long*)pMeasurement2Filter);
   /*~-1*/
   }
   /*~E:I54*/
   /*~I:55*/
   if (byMode & 0x02)		// Totbandfilter
   /*~-1*/
   {
      /*~T*/
      byRetVal |= DeadBandFilter_Filter(byChannel,pMeasurement2Filter);
   /*~-1*/
   }
   /*~E:I55*/
   /*~E:A48*/
   /*~O:I47*/
   /*~-1*/
#else
   /*~A:56*/
   /*~+:Mittelwertfilter*/
   /*~T*/
   // Mittelwertfilter
   byRetVal |= AverageFilter_Filter(byChannel,(long*)pMeasurement2Filter);
   /*~E:A56*/
   /*~-1*/
#endif
   /*~E:I47*/
   /*~T*/
   return byRetVal;
/*~-1*/
}
/*~E:F44*/
/*~E:A43*/
