/*~-1*/
/*~XSF_LANGUAGE: C/C++*/
/*~A:1*/
/*~+:Versions-Beschreibung*/
/*~A:2*/
/*~+:Version und Versionsdatum*/
/*~T*/
/*!
\addtogroup versions_externals
@{
<tr>
	<td>Statistics.h</td>
	<td>Michael Offenbach</td>
	<td>1.000</td>
	<td>05.01.2005</td>
	<td></td>
</tr>
@}
*/
/*~E:A2*/
/*~A:3*/
/*~+:Ziel-Hardware*/
/*~T*/
/*!\page HardwarePage Ziel-Hardware

\section sec_HardwarePage_Muster 'Muster'

<table border=1 width=100% height=1% rules=rows cellspacing=0 bgcolor="#E0E0F0">

<tr align=left valign=top>
	<th>Motherboard</th>
	<th>Prozessor</th>
	<th>ROM</th>
	<th>RAM</th>
</tr>

<tr>
	<td>MRW-Limit V1.2B 2/2004</td>
	<td>8051-Core</td>
	<td>62 <B>kByte</B></td>
	<td>2 <B>kByte</B></td>
</tr></table>

*/
/*~E:A3*/
/*~A:4*/
/*~+:Compiler-Einstellungen*/
/*~T*/
/*!\page CompilerPage Compiler-Einstellungen

\section sec_CompilerPage_Muster 'Musterprojekt'

<table border=1 width=100% height=1% rules=rows cellspacing=0 bgcolor="#E0E0F0">

<tr align=left valign=top>
	<th>Compiler</th>
	<th>Betriebssystem</th>
	<th>Speichermodell</th>
	<th>Code-Speicher-Gr��e</th>
	<th>Optimierungen</th>
	<th>Sonstiges</th>
</tr>

<tr>
	<td>Keil uVision2 V2.40<BR>C51 V7.08<BR>A51 V7.08a</td>
	<td>Kein Betriebssystem</td>
	<td>Large: variables in XDATA</td>
	<td>Large: 64k program</td>
	<td>6 Loop rotation<BR>Favor speed</td>
	<td>---</td>
</tr></table>

*/
/*~E:A4*/
/*~A:5*/
/*~+:Ressourcen*/
/*~T*/
/*!\page RessourcePage Ressourcen

\section sec_RessourcePage_Musterr 'Musterprojekt'

<table border=1 width=100% height=1% rules=rows cellspacing=0 bgcolor="#E0E0F0">

<tr align=left valign=top>
	<th>CODE</th>
	<th>IDATA</th>
	<th>XDATA</th>
	<th>Dynamische Variablen</th>
</tr>

<tr>
	<td>--- <B>Bytes</B></td>
	<td>--- <B>Bytes</B></td>
	<td>--- <B>Bytes</B></td>
	<td>--- <B>Bytes</B></td>
</tr></table>

*/
/*~E:A5*/
/*~A:6*/
/*~+:Zykluszeiten*/
/*~T*/
/*!\page CycletimePage Zykluszeiten

\section sec_CycletimePage_Muster 'Musterprojekt'

<table border=1 width=100% height=1% rules=rows cellspacing=0 bgcolor="#E0E0F0">

<tr align=left valign=top>
	<th>Minimale Durchlaufzeit</th>
	<th>Maximale Durchlaufzeit</th>
</tr>

<tr>
	<td>--- <B>ms</B></td>
	<td>--- <B>ms</B></td>
</tr></table>

*/
/*~E:A6*/
/*~A:7*/
/*~+:Verschiedenes*/
/*~T*/
/*!\page MiscPage Verschiedenes

\section sec_MiscPage_Muster 'Musterprojekt'

<table border=1 width=100% height=1% rules=rows cellspacing=0 bgcolor="#E0E0F0">

<tr align=left valign=top>
	<th>Benutzte Interrups</th>
	<th>Benutzte Registerb�nke</th>
</tr>

<tr>
	<td>---</td>
	<td>---</td>
</tr></table>

*/
/*~E:A7*/
/*~A:8*/
/*~+:Lifecycle*/
/*~T*/
/*!\page LifeCyclePage Lifecycle

\section sec_LifeCyclePage_Muster 'Musterprojekt'

<table border=1 width=100% height=1% rules=rows cellspacing=0 bgcolor="#E0E0F0">

<tr align=left valign=top>
	<th>Version</th>
	<th>Datum</th>
	<th>Programmierer</th>
	<th>�nderungen</th>
</tr>

<tr>
	<td>1.000</td>
	<td>18.03.05</td>
	<td>Michael Offenbach</td>
	<td>Erste lauff�hige Version</td>
</tr>

</table>
*/
/*~E:A8*/
/*~A:9*/
/*~+:Beispiel*/
/*~T*/
/*!\page ExamplePage_Muster Beispiel 'Musterprojekt'
\code

main()
{
	Muster_Funktion(1,2);
}
\endcode
*/ 
/*~E:A9*/
/*~E:A1*/
/*~I:10*/
#ifndef __STATISTICSLIBRARY_H
/*~T*/
#define __STATISTICSLIBRARY_H
/*~A:11*/
/*~+:Defines*/
/*~A:12*/
/*~+:Konfiguration*/
/*~T*/
// Anzahl der Statistikkan�le
#define STATISTICSLIBRARY_NB_CHANELS							2
/*~E:A12*/
/*~T*/
#define STATISTICSLIBRARY_CLRALL								0xFF

#define STATISTICSLIBRARY_DONT_CLEAR_RESULTS					0x00
#define STATISTICSLIBRARY_CLEAR_RESULTS							0x01

#define STATISTICSLIBRARY_LOAD									0x00
#define STATISTICSLIBRARY_SAVE									0x01

#define STATISTICSLIBRARY_LOAD_MINTEMP							0x00
#define STATISTICSLIBRARY_LOAD_MAXTEMP							0x01
#define STATISTICSLIBRARY_LOAD_MAXWEIGHT						0x04
#define STATISTICSLIBRARY_LOAD_MAXRMW							0x05
#define STATISTICSLIBRARY_LOAD_MAXCURRENT						0x06
#define STATISTICSLIBRARY_LOAD_NBOVERLOADS						0x10
#define STATISTICSLIBRARY_LOAD_NBOVERLIMITS						0x11

#define STATISTICSLIBRARY_SAVE_MINTEMP							0x80
#define STATISTICSLIBRARY_SAVE_MAXTEMP							0x81
#define STATISTICSLIBRARY_SAVE_MAXWEIGHT						0x84
#define STATISTICSLIBRARY_SAVE_MAXRMW							0x85
#define STATISTICSLIBRARY_SAVE_MAXCURRENT						0x86
#define STATISTICSLIBRARY_SAVE_NBOVERLOADS						0x90
#define STATISTICSLIBRARY_SAVE_NBOVERLIMITS						0x91
/*~E:A11*/
/*~A:13*/
/*~+:Strukturdefinitionen*/
/*~T*/
typedef struct
{
	float fMaxWeight;								// maximaler Gewichtswert
	long lMaxRMW;									// maximaler Rohmesswert
	float fMaxCurrent;								// maximaler Ausgangsstrom	
	unsigned int nCounter;							// Z�hler f�r maximalen Gewichtswert
	unsigned int nCounterCurrent;					// Z�hler f�r maximalen Strom
	unsigned int nFilter;							// Filter zur Extremwertermittlung
	float fTempMaxWeight;							// tempor�rer Extremwert-Speicher
	long lTempMaxRMW;								// tempor�rer Extremwert-Speicher
	float fTempMaxCurrent;							// tempor�rer Extremwert-Speicher
	float fMotionLimit;								// Motion-Grenzwert
	float fLastWeight;								// zuletzt �bergebener Gewichtswert
	float fWeightChange;							// Gewichts�nderung
	unsigned char byMotion;							// Gewicht instabil
}STATISTICSLIBRARY_CHECKWEIGHT;
/*~T*/
typedef struct
{
	unsigned int nOverlimits;						// Grenzwert�berschreitungen	
	unsigned char nCounter;							// Z�hler f�r Grenzwert�berschreitungen 
	int nFilter;
	float fLimit;
	unsigned char byStatus;
}STATISTICSLIBRARY_CHECKOVERLIMIT;
/*~T*/
typedef struct
{
	unsigned int nOverloads;
	unsigned char byLastStatus;
}STATISTICSLIBRARY_CHECKOVERLOAD;
/*~T*/
typedef struct
{
	char chMinTemperature;							// Minimal-Temperatur
	char chMaxTemperature;							// Maximal-Temperatur
	unsigned int nCounterMinTemp;					// Z�hler f�r Minimal-Temperatur 
	unsigned int nCounterMaxTemp;					// Z�hler f�r Maximal-Temperatur
	unsigned int nFilter;							// Filter Temperatur�berpr�fung
}STATISTICSLIBRARY_CHECKTEMPERATURE;
/*~T*/
typedef struct
{
	unsigned char byRunStatistics;
	unsigned char chFilterCheckTemperature;
	unsigned char chFilterCheckWeight;
	float fMotionLimitCheckWeight;
	unsigned char chFilterOverLimit;
	float fLimitOverLimit;
}STATISTICSLIBRARY_SETUP;
/*~T*/
typedef struct
{
	char 			chMaxTemperature;
	char 			chMinTemperature;
	float 			fMaxWeight;
	long 			lMaxRMW;
	float			fMaxCurrent;
	unsigned int 	nOverloads;
	unsigned int 	nOverLimits;
}STATISTICSLIBRARY_RESULT;
/*~T*/
typedef struct
{
	char chRunStatistics;					// Statistik aktiv 
// -------------------- CheckTemperature -------------------- //
	STATISTICSLIBRARY_CHECKTEMPERATURE StatCheckTemperature;
// -------------------- CheckWeight -------------------- //
	STATISTICSLIBRARY_CHECKWEIGHT StatCheckWeight;
// -------------------- CheckOverload -------------------- //
	STATISTICSLIBRARY_CHECKOVERLOAD StatCheckOverload;
// -------------------- CheckOverlimits -------------------- //
	STATISTICSLIBRARY_CHECKOVERLIMIT StatCheckOverlimit;

}STATISTICSLIBRARY;
/*~E:A13*/
/*~A:14*/
/*~+:Funktionsdeklarationen*/
/*~T*/
extern void 						StatisticsLibrary_CheckOverlimit(unsigned char byChanel,float fWeight);
extern void 						StatisticsLibrary_CheckOverload(unsigned char byChanel,unsigned char byOverload);

extern void						 	StatisticsLibrary_CheckTemperature(unsigned char byChanel,char byTemperature);

extern void 						StatisticsLibrary_CheckWeight(unsigned char byChanel,float fWeight,long lRMW,float fCurrent);

extern void 						StatisticsLibrary_Clear(unsigned char byChanel,unsigned char byWhat);

extern STATISTICSLIBRARY_RESULT 	StatisticsLibrary_GetResult(unsigned char byChanel);
extern void 						StatisticsLibrary_Ini(char byClearResults);
extern char 						StatisticsLibrary_Setup(unsigned char byChanel,STATISTICSLIBRARY_SETUP StatSetup);

extern void 						StatisticsLibrary_StartStop(unsigned char byChanel,bit bStartStop);

extern char* 						StatisticsLibrary_Version(void);
/*~T*/
extern void StatisticsLibrary_Interface(unsigned char chWhat2Do,unsigned char chAddParameter,void* pData); 
/*~I:15*/
#ifdef MOF
/*~T*/
extern char Load_Statistics(unsigned char byChanel,unsigned char byWhat,void* ptrParameter);
extern char Save_Statistics(unsigned char byChanel,unsigned char byWhat,void* ptrParameter);
/*~T*/
extern STATISTICS_RESULT Statistics_CheckAll(unsigned char byChanel,float fWeight,float fDeviation,long lWeightMaster,long lWeightSlave,long lMasterWeightAbsolute,long lSlaveWeightAbsolute,unsigned char byOverload,char cTemperature,unsigned char byMode);

extern STATISTICS_RESULT Statistics_CheckOverLimits(unsigned char byChanel,long lWeight);

extern STATISTICS_RESULT Statistics_CheckOverload(unsigned char byChanel,unsigned char byOverload);

extern STATISTICS_RESULT Statistics_CheckRMWWeight(unsigned char byChanel,long lMasterWeight,long lSlaveWeight,long lMasterWeightAbsolute,long lSlaveWeightAbsolute,unsigned char byMode);

extern STATISTICS_RESULT Statistics_CheckTemperature(unsigned char byChanel,char byTemperature);

extern STATISTICS_RESULT Statistics_CheckWeight(unsigned char byChanel,float fMasterWeight,float fSlaveWeight,unsigned char byMode);

extern void Statistics_Clear(unsigned char byChanel,unsigned char byWhat);

extern STATISTICS_RESULT Statistics_GetResult(unsigned char byChanel);

extern char Statistics_Init(unsigned char byChanels);

extern void Statistics_Save(unsigned char byWhat);

extern char Statistics_Setup(unsigned char byChanel,STATISTICS_SETUP StatSetup);

extern void Statistics_StartStop(unsigned char byChanel,bit bStartStop);
/*~-1*/
#endif
/*~E:I15*/
/*~E:A14*/
/*~A:16*/
/*~+:Variablendeklarationen*/
/*~T*/

/*~E:A16*/
/*~A:17*/
/*~+:Dokumentationen*/
/*~A:18*/
/*~+:STATISTICS_RESULT Statistics_CheckAll(unsigned char byChanel,float fWeightMaster,float fWeightSlave,long lWeightMaster,long lWeightSlave,long lMasterWeightAbsolute,long lSlaveWeightAbsolute,unsigned char byOverload,char cTemperature,unsigned char byMode)*/
/*~K*/
/*#LJ:0=551*/
/*~+:STATISTICS_RESULT Statistics_CheckAll(unsigned char byChanel,float fWeightMaster,float fWeightSlave,long lWeightMaster,long lWeightSlave,long lMasterWeightAbsolute,long lSlaveWeightAbsolute,unsigned char byOverload,char cTemperature,unsigned char byMode)*/
/*~+:*/
/*~+:Beschreibung:*/
/*~+:-------------*/
/*~+:�berpr�fung der �bergebenen Werte auf alle der in dem Statistik-Modul m�glichen Auswertem�glichkeiten. Die genauen Beschreibungen bitte in den Statistics_Check-Funktionen nachlesen.*/
/*~+:*/
/*~+:*/
/*~+:Parameter:*/
/*~+:----------*/
/*~+:*/
/*~+:unsigned char byChanel:*/
/*~+:	Statistik-Kanal, welcher �berpr�ft werden soll*/
/*~+:*/
/*~+:*/
/*~+:float fMasterWeight:*/
/*~+:	Master-Gewichtswert*/
/*~+:*/
/*~+:*/
/*~+:float fSlaveWeight:*/
/*~+:	Slave-Gewichtswert*/
/*~+:*/
/*~+:*/
/*~+:long lMasterWeight:*/
/*~+:	Master-Rohmesswert*/
/*~+:*/
/*~+:*/
/*~+:long lSlaveWeight:*/
/*~+:	Slave-Rohmesswert*/
/*~+:*/
/*~+:*/
/*~+:long lMasterWeightAbsolute:*/
/*~+:	Master-Rohmesswert ohne Tara-Offset-Korrektur*/
/*~+:*/
/*~+:*/
/*~+:long lSlaveWeightAbsolute:*/
/*~+:	Slave-Rohmesswert ohne Tara-Offset-Korrektur*/
/*~+:*/
/*~+:*/
/*~+:unsigned char byOverload:*/
/*~+:	0 : System nicht in �berlast*/
/*~+:	1 : System in �berlast*/
/*~+:*/
/*~+:*/
/*~+:char cTemperature:*/
/*~+:	Der zur statistischen Auswertung �bergebene Temperaturwert.*/
/*~+:*/
/*~+:*/
/*~+:unsigned char byMode:*/
/*~+:	Ist dieser Parameter gesetzt (>0), wird dieser zu �berpr�fende Wert auch ohne Pr�fung der 			Gewichtsbewegung und des Filters zur Aktualisierung des Statistik-Ergebnisses herangezogen*/
/*~+:*/
/*~+:*/
/*~+:R�ckgabe: */
/*~+:---------*/
/*~+: */
/*~+:STATISTICS_RESULT :*/
/*~+:	Ergebnis-Struktur des aktuellen Kanals (angegeben durch byChanel)*/
/*~+:*/
/*~+:	char byMaxTemperature :*/
/*~+:			Maximaltemperatur*/
/*~+:*/
/*~+:	char byMinTemperature :*/
/*~+:			Minimaltemperatur*/
/*~+:*/
/*~+:	float fMaxWeight_Master :*/
/*~+:			maximales Master-Gewicht*/
/*~+:*/
/*~+:	float fMaxWeight_Slave :*/
/*~+:			maximales Slave-Gewicht*/
/*~+:*/
/*~+:	float fMaxDeviation :*/
/*~+:			maximale normierte Kanalabweichung*/
/*~+:*/
/*~+:	long lMaxWeight_Master :*/
/*~+:			maximaler Master-Rohmesswert*/
/*~+:*/
/*~+:	long lMaxWeight_Slave :*/
/*~+:			maximaler Slave-Rohmesswert*/
/*~+:*/
/*~+:	long lMaxDeviationAbsolute :*/
/*~+:			maximale absolute Kanalabweichung*/
/*~+: */
/*~+:	long lMaxDeviationWithTara :*/
/*~+:			maximale Tara-Offset bereinigte Kanalabweichung*/
/*~+:*/
/*~+:	unsigned int nOverloads :*/
/*~+:			Anzahl �berlastungen*/
/*~+:*/
/*~+:	unsigned int nOverLimits :*/
/*~+:			Anzahl Grenzwert-�berschreitungen*/
/*~+:*/
/*~+:*/
/*~+:Zugriff:*/
/*~+:--------*/
/*~+:public*/
/*~E:A18*/
/*~A:19*/
/*~+:STATISTICS_RESULT Statistics_CheckOverLimits(unsigned char byChanel,long lWeight)*/
/*~K*/
/*~+:STATISTICS_RESULT Statistics_CheckOverLimits(unsigned char byChanel,long lWeight)*/
/*~+:*/
/*~+:Beschreibung:*/
/*~+:-------------*/
/*~+:Ermittlung der Grenzwert-�berschreitungen*/
/*~+:*/
/*~+:*/
/*~+:Parameter:*/
/*~+:----------*/
/*~+:*/
/*~+:unsigned char byChanel:*/
/*~+:	Statistik-Kanal, welcher �berpr�ft werden soll. Dabei wird untersucht, ob �ber eine l�ngere 		Zeit (Angabe in der Setup-Funktion) der Rohmesswert �ber einer Grenzwertschwelle (ebenfalls 		�ber Setup eingestellt) liegt. Hiernach mu� der Rohmesswert wiederum �ber die gleiche Zeit 			unter der Schwelle zu liegen kommen, bevor eine neue �berschreizung festgestellt werden 			kann.*/
/*~+:*/
/*~+:long lWeight:*/
/*~+:	Zur �berpr�fung anstehender Rohmesswert */
/*~+:*/
/*~+:*/
/*~+:R�ckgabe: */
/*~+:---------*/
/*~+:*/
/*~+:STATISTICS_RESULT :*/
/*~+:	Ergebnis-Struktur des aktuellen Kanals (angegeben durch byChanel)*/
/*~+:*/
/*~+:	char byMaxTemperature :*/
/*~+:			Maximaltemperatur*/
/*~+:*/
/*~+:	char byMinTemperature :*/
/*~+:			Minimaltemperatur*/
/*~+:*/
/*~+:	float fMaxWeight_Master :*/
/*~+:			maximales Master-Gewicht*/
/*~+:*/
/*~+:	float fMaxWeight_Slave :*/
/*~+:			maximales Slave-Gewicht*/
/*~+:*/
/*~+:	float fMaxDeviation :*/
/*~+:			maximale normierte Kanalabweichung*/
/*~+:*/
/*~+:	long lMaxWeight_Master :*/
/*~+:			maximaler Master-Rohmesswert*/
/*~+:*/
/*~+:	long lMaxWeight_Slave :*/
/*~+:			maximaler Slave-Rohmesswert*/
/*~+:*/
/*~+:	long lMaxDeviationAbsolute :*/
/*~+:			maximale absolute Kanalabweichung*/
/*~+: */
/*~+:	long lMaxDeviationWithTara :*/
/*~+:			maximale Tara-Offset bereinigte Kanalabweichung*/
/*~+:*/
/*~+:	unsigned int nOverloads :*/
/*~+:			Anzahl �berlastungen*/
/*~+:*/
/*~+:	unsigned int nOverLimits :*/
/*~+:			Anzahl Grenzwert-�berschreitungen*/
/*~+:*/
/*~+:*/
/*~+:Zugriff:*/
/*~+:--------*/
/*~+:public*/
/*~+:*/
/*~E:A19*/
/*~A:20*/
/*~+:STATISTICS_RESULT Statistics_CheckOverload(unsigned char byChanel,unsigned char byOverload)*/
/*~K*/
/*~+:STATISTICS_RESULT Statistics_CheckOverload(unsigned char byChanel,unsigned char byOverload)*/
/*~+:*/
/*~+:Beschreibung:*/
/*~+:-------------*/
/*~+:Ermittlung der �berlastungen*/
/*~+:*/
/*~+:*/
/*~+:Parameter:*/
/*~+:----------*/
/*~+:*/
/*~+:unsigned char byChanel:*/
/*~+:	Statistik-Kanal, welcher �berpr�ft werden soll*/
/*~+:*/
/*~+:unsigned char byOverload:*/
/*~+:	0 : System nicht in �berlast*/
/*~+:	1 : System in �berlast */
/*~+:*/
/*~+:*/
/*~+:R�ckgabe: */
/*~+:---------*/
/*~+:*/
/*~+:STATISTICS_RESULT :*/
/*~+:	Ergebnis-Struktur des aktuellen Kanals (angegeben durch byChanel)*/
/*~+:*/
/*~+:	char byMaxTemperature :*/
/*~+:			Maximaltemperatur*/
/*~+:*/
/*~+:	char byMinTemperature :*/
/*~+:			Minimaltemperatur*/
/*~+:*/
/*~+:	float fMaxWeight_Master :*/
/*~+:			maximales Master-Gewicht*/
/*~+:*/
/*~+:	float fMaxWeight_Slave :*/
/*~+:			maximales Slave-Gewicht*/
/*~+:*/
/*~+:	float fMaxDeviation :*/
/*~+:			maximale normierte Kanalabweichung*/
/*~+:*/
/*~+:	long lMaxWeight_Master :*/
/*~+:			maximaler Master-Rohmesswert*/
/*~+:*/
/*~+:	long lMaxWeight_Slave :*/
/*~+:			maximaler Slave-Rohmesswert*/
/*~+:*/
/*~+:	long lMaxDeviationAbsolute :*/
/*~+:			maximale absolute Kanalabweichung*/
/*~+: */
/*~+:	long lMaxDeviationWithTara :*/
/*~+:			maximale Tara-Offset bereinigte Kanalabweichung*/
/*~+:*/
/*~+:	unsigned int nOverloads :*/
/*~+:			Anzahl �berlastungen*/
/*~+:*/
/*~+:	unsigned int nOverLimits :*/
/*~+:			Anzahl Grenzwert-�berschreitungen*/
/*~+:*/
/*~+:*/
/*~+:Zugriff:*/
/*~+:--------*/
/*~+:public*/
/*~+:*/
/*~E:A20*/
/*~A:21*/
/*~+:STATISTICS_RESULT Statistics_CheckRMWWeight(unsigned char byChanel,long lMasterWeight,long lSlaveWeight,long lMasterWeightAbsolute,long lSlaveWeightAbsolute,unsigned char byMode)*/
/*~K*/
/*~+:STATISTICS_RESULT Statistics_CheckRMWWeight(unsigned char byChanel,long lMasterWeight,long lSlaveWeight,long lMasterWeightAbsolute,long lSlaveWeightAbsolute,unsigned char byMode)*/
/*~+:*/
/*~+:Beschreibung:*/
/*~+:-------------*/
/*~+:�berpr�fung des Master- und Slave-Rohmesswerts sowie der Kanalabst�nde beider Kan�le auf ein eventuelles Maximum. (weitere Beschreibung s.u. Statistics_CheckRMWWeightEx())  */
/*~+:*/
/*~+:*/
/*~+:Parameter:*/
/*~+:----------*/
/*~+:*/
/*~+:unsigned char byChanel:*/
/*~+:	Statistik-Kanal, welcher �berpr�ft werden soll*/
/*~+:*/
/*~+:*/
/*~+:long lMasterWeight:*/
/*~+:	Master-Rohmesswert*/
/*~+:*/
/*~+:*/
/*~+:long lSlaveWeight:*/
/*~+:	Slave-Rohmesswert*/
/*~+:*/
/*~+:*/
/*~+:long lMasterWeightAbsolute:*/
/*~+:	Master-Rohmesswert ohne Tara-Offset-Korrektur*/
/*~+:*/
/*~+:*/
/*~+:long lSlaveWeightAbsolute:*/
/*~+:	Slave-Rohmesswert ohne Tara-Offset-Korrektur*/
/*~+:*/
/*~+:*/
/*~+:unsigned char byMode:*/
/*~+:	Ist dieser Parameter gesetzt (>0), wird dieser Gewichtswert auch ohne Pr�fung der 				Gewichtsbewegung und des Filters zur Aktualisierung des Statistik-Ergebnisses herangezogen */
/*~+:*/
/*~+:*/
/*~+:R�ckgabe: */
/*~+:---------*/
/*~+:*/
/*~+:STATISTICS_RESULT :*/
/*~+:	Ergebnis-Struktur des aktuellen Kanals (angegeben durch byChanel)*/
/*~+:*/
/*~+:	char byMaxTemperature :*/
/*~+:			Maximaltemperatur*/
/*~+:*/
/*~+:	char byMinTemperature :*/
/*~+:			Minimaltemperatur*/
/*~+:*/
/*~+:	float fMaxWeight_Master :*/
/*~+:			maximales Master-Gewicht*/
/*~+:*/
/*~+:	float fMaxWeight_Slave :*/
/*~+:			maximales Slave-Gewicht*/
/*~+:*/
/*~+:	float fMaxDeviation :*/
/*~+:			maximale normierte Kanalabweichung*/
/*~+:*/
/*~+:	long lMaxWeight_Master :*/
/*~+:			maximaler Master-Rohmesswert*/
/*~+:*/
/*~+:	long lMaxWeight_Slave :*/
/*~+:			maximaler Slave-Rohmesswert*/
/*~+:*/
/*~+:	long lMaxDeviationAbsolute :*/
/*~+:			maximale absolute Kanalabweichung*/
/*~+: */
/*~+:	long lMaxDeviationWithTara :*/
/*~+:			maximale Tara-Offset bereinigte Kanalabweichung*/
/*~+:*/
/*~+:	unsigned int nOverloads :*/
/*~+:			Anzahl �berlastungen*/
/*~+:*/
/*~+:	unsigned int nOverLimits :*/
/*~+:			Anzahl Grenzwert-�berschreitungen*/
/*~+:*/
/*~+:*/
/*~+:Zugriff:*/
/*~+:--------*/
/*~+:public*/
/*~+:*/
/*~E:A21*/
/*~A:22*/
/*~+:STATISTICS_RESULT Statistics_CheckTemperature(unsigned char byChanel,char byTemperature)*/
/*~K*/
/*~+:STATISTICS_RESULT Statistics_CheckTemperature(unsigned char byChanel,char cTemperature)*/
/*~+:*/
/*~+:Beschreibung:*/
/*~+:-------------*/
/*~+:Ermittlung der Temperaturextrema. Hierzu wird zyklisch ein Temperaturwert (cTemperature) als Parameter �bergeben. Die Funktion speichert diesen Wert zun�chst tempor�r bei �berschreiten des aktuellen Extremas ab und �bernimmt das so gefundene Extrema, sobald ein zuvor festgelegter Umfang an hintereinander aufgetretenen �berschreitungen festgestellt wurde.  */
/*~+:*/
/*~+:Parameter:*/
/*~+:----------*/
/*~+:*/
/*~+:unsigned char byChanel: */
/*~+:	Statistik-Kanal, in dem diese Auswertung erfolgen soll. Der Wert darf nicht gr��er als die 			Anzahl der durch "Statistics_Init" initialisierten Kan�le sein.*/
/*~+:*/
/*~+:*/
/*~+:char cTemperature:*/
/*~+:	Der zur statistischen Auswertung �bergebene Temperaturwert.*/
/*~+:*/
/*~+:*/
/*~+:R�ckgabe: */
/*~+:---------*/
/*~+:*/
/*~+:STATISTICS_RESULT :*/
/*~+:	Ergebnis-Struktur des aktuellen Kanals (angegeben durch byChanel)*/
/*~+:*/
/*~+:	char byMaxTemperature :*/
/*~+:			Maximaltemperatur*/
/*~+:*/
/*~+:	char byMinTemperature :*/
/*~+:			Minimaltemperatur*/
/*~+:*/
/*~+:	float fMaxWeight_Master :*/
/*~+:			maximales Master-Gewicht*/
/*~+:*/
/*~+:	float fMaxWeight_Slave :*/
/*~+:			maximales Slave-Gewicht*/
/*~+:*/
/*~+:	float fMaxDeviation :*/
/*~+:			maximale normierte Kanalabweichung*/
/*~+:*/
/*~+:	long lMaxWeight_Master :*/
/*~+:			maximaler Master-Rohmesswert*/
/*~+:*/
/*~+:	long lMaxWeight_Slave :*/
/*~+:			maximaler Slave-Rohmesswert*/
/*~+:*/
/*~+:	long lMaxDeviationAbsolute :*/
/*~+:			maximale absolute Kanalabweichung*/
/*~+: */
/*~+:	long lMaxDeviationWithTara :*/
/*~+:			maximale Tara-Offset bereinigte Kanalabweichung*/
/*~+:*/
/*~+:	unsigned int nOverloads :*/
/*~+:			Anzahl �berlastungen*/
/*~+:*/
/*~+:	unsigned int nOverLimits :*/
/*~+:			Anzahl Grenzwert-�berschreitungen*/
/*~+: */
/*~E:A22*/
/*~A:23*/
/*~+:STATISTICS_RESULT Statistics_CheckWeight(unsigned char byChanel,float fMasterWeight,float fSlaveWeight,unsigned char byMode)*/
/*~K*/
/*~+:STATISTICS_RESULT Statistics_CheckWeight(unsigned char byChanel,float fMasterWeight,float fSlaveWeight,unsigned char byMode)*/
/*~+:*/
/*~+:*/
/*~+:Beschreibung:*/
/*~+:-------------*/
/*~+:�berpr�fung des Master- und Slave-Gewichts sowie des Kanalabstands beider Kan�le auf ein eventuelles Maximum. (weitere Beschreibung s.u. Statistics_CheckWeightEx())  */
/*~+:*/
/*~+:*/
/*~+:Parameter:*/
/*~+:----------*/
/*~+:*/
/*~+:unsigned char byChanel:*/
/*~+:	Statistik-Kanal, welcher �berpr�ft werden soll*/
/*~+:*/
/*~+:*/
/*~+:float fMasterWeight:*/
/*~+:	Master-Gewichtswert*/
/*~+:*/
/*~+:*/
/*~+:float fSlaveWeight:*/
/*~+:	Slave-Gewichtswert*/
/*~+:*/
/*~+:*/
/*~+:unsigned char byMode:*/
/*~+:	Ist dieser Parameter gesetzt (>0), wird dieser Gewichtswert auch ohne Pr�fung der 				Gewichtsbewegung und des Filters zur Aktualisierung des Statistik-Ergebnisses herangezogen */
/*~+:*/
/*~+:*/
/*~+:R�ckgabe: */
/*~+:---------*/
/*~+:*/
/*~+:STATISTICS_RESULT :*/
/*~+:	Ergebnis-Struktur des aktuellen Kanals (angegeben durch byChanel)*/
/*~+:*/
/*~+:	char byMaxTemperature :*/
/*~+:			Maximaltemperatur*/
/*~+:*/
/*~+:	char byMinTemperature :*/
/*~+:			Minimaltemperatur*/
/*~+:*/
/*~+:	float fMaxWeight_Master :*/
/*~+:			maximales Master-Gewicht*/
/*~+:*/
/*~+:	float fMaxWeight_Slave :*/
/*~+:			maximales Slave-Gewicht*/
/*~+:*/
/*~+:	float fMaxDeviation :*/
/*~+:			maximale normierte Kanalabweichung*/
/*~+:*/
/*~+:	long lMaxWeight_Master :*/
/*~+:			maximaler Master-Rohmesswert*/
/*~+:*/
/*~+:	long lMaxWeight_Slave :*/
/*~+:			maximaler Slave-Rohmesswert*/
/*~+:*/
/*~+:	long lMaxDeviationAbsolute :*/
/*~+:			maximale absolute Kanalabweichung*/
/*~+: */
/*~+:	long lMaxDeviationWithTara :*/
/*~+:			maximale Tara-Offset bereinigte Kanalabweichung*/
/*~+:*/
/*~+:	unsigned int nOverloads :*/
/*~+:			Anzahl �berlastungen*/
/*~+:*/
/*~+:	unsigned int nOverLimits :*/
/*~+:			Anzahl Grenzwert-�berschreitungen*/
/*~+:*/
/*~+:*/
/*~+:Zugriff:*/
/*~+:--------*/
/*~+:public*/
/*~+:*/
/*~E:A23*/
/*~A:24*/
/*~+:void Statistics_Clear(unsigned char byChanel,unsigned char byWhat)*/
/*~K*/
/*~+:void Statistics_Clear(unsigned char byChanel,unsigned char byWhat)*/
/*~+:*/
/*~+:Beschreibung:*/
/*~+:-------------*/
/*~+:L�schen eines oder mehrere Teilergebnisse des angegebenen Statistik-Kanals*/
/*~+:*/
/*~+:*/
/*~+:Parameter:*/
/*~+:----------*/
/*~+:*/
/*~+:unsigned char byChanel:*/
/*~+:	Statistik-Kanal, von dem Ergebnisse gel�scht werden sollen*/
/*~+:*/
/*~+:unsigned char byWhat:*/
/*~+:	Angabe des Ergebnisses, welches gel�scht werden soll. Die Angabe ist bitcodiert, und kann 		somit kombiniert werden. Dabei gilt im einzelnen:*/
/*~+:*/
/*~+:	xxxx xxx1 : "Temperatur" - Extrema l�schen */
/*~+:	xxxx xx1x : "Kanalabweichung" - Extrema l�schen*/
/*~+:	xxxx x1xx : "Gewicht" - Extrema l�schen*/
/*~+:	xxxx 1xxx : �berlast-Z�hler l�schen*/
/*~+:	xxx1 xxxx : Grenzwert-Z�hler l�schen */
/*~+:	*/
/*~+:	(x) : beliebig */
/*~+:*/
/*~+:*/
/*~+:R�ckgabe: */
/*~+:---------*/
/*~+:keine*/
/*~+:*/
/*~+:*/
/*~+:Zugriff:*/
/*~+:--------*/
/*~+:public*/
/*~+:*/
/*~E:A24*/
/*~A:25*/
/*~+:STATISTICS_RESULT Statistics_GetResult(unsigned char byChanel)*/
/*~K*/
/*~+:STATISTICS_RESULT Statistics_GetResult(unsigned char byChanel)*/
/*~+:*/
/*~+:Beschreibung:*/
/*~+:-------------*/
/*~+:Ausgabe der Ergebnisse eines �ber byChanel bestimmten Statistik-Kanals*/
/*~+:*/
/*~+:*/
/*~+:Parameter:*/
/*~+:----------*/
/*~+:*/
/*~+:unsigned char byChanel:*/
/*~+:	Statistik-Kanal, dessen Ergebnisse ausgelesen werden sollen*/
/*~+:*/
/*~+:*/
/*~+:R�ckgabe: */
/*~+:---------*/
/*~+:*/
/*~+:STATISTICS_RESULT :*/
/*~+:	Ergebnis-Struktur des aktuellen Kanals (angegeben durch byChanel)*/
/*~+:*/
/*~+:	char byMaxTemperature :*/
/*~+:			Maximaltemperatur*/
/*~+:*/
/*~+:	char byMinTemperature :*/
/*~+:			Minimaltemperatur*/
/*~+:*/
/*~+:	float fMaxWeight_Master :*/
/*~+:			maximales Master-Gewicht*/
/*~+:*/
/*~+:	float fMaxWeight_Slave :*/
/*~+:			maximales Slave-Gewicht*/
/*~+:*/
/*~+:	float fMaxDeviation :*/
/*~+:			maximale normierte Kanalabweichung*/
/*~+:*/
/*~+:	long lMaxWeight_Master :*/
/*~+:			maximaler Master-Rohmesswert*/
/*~+:*/
/*~+:	long lMaxWeight_Slave :*/
/*~+:			maximaler Slave-Rohmesswert*/
/*~+:*/
/*~+:	long lMaxDeviationAbsolute :*/
/*~+:			maximale absolute Kanalabweichung*/
/*~+: */
/*~+:	long lMaxDeviationWithTara :*/
/*~+:			maximale Tara-Offset bereinigte Kanalabweichung*/
/*~+:*/
/*~+:	unsigned int nOverloads :*/
/*~+:			Anzahl �berlastungen*/
/*~+:*/
/*~+:	unsigned int nOverLimits :*/
/*~+:			Anzahl Grenzwert-�berschreitungen*/
/*~+:*/
/*~+:*/
/*~+:Zugriff:*/
/*~+:--------*/
/*~+:public*/
/*~+:*/
/*~E:A25*/
/*~A:26*/
/*~+:char Statistics_Init(unsigned char byChanels)*/
/*~K*/
/*~+:char Statistics_Init(unsigned char byChanels)*/
/*~+:*/
/*~+:Beschreibung:*/
/*~+:-------------*/
/*~+:Initialisierung der Statistik-Kan�le*/
/*~+:*/
/*~+:*/
/*~+:Parameter:*/
/*~+:----------*/
/*~+:*/
/*~+:unsigned char byChanels:*/
/*~+:	Anzahl der Statistik-Kan�le*/
/*~+:*/
/*~+:*/
/*~+:R�ckgabe: */
/*~+:---------*/
/*~+:0 :	Initialisierung ok*/
/*~+:1 : Nicht gen�gend Speicher vorhanden*/
/*~+:*/
/*~+:*/
/*~+:Zugriff:*/
/*~+:--------*/
/*~+:public*/
/*~E:A26*/
/*~A:27*/
/*~+:char Statistics_Setup(unsigned char byChanel,STATISTICS_SETUP StatSetup)*/
/*~K*/
/*~+:char Statistics_Setup(unsigned char byChanel,STATISTICS_SETUP StatSetup)*/
/*~+:*/
/*~+:Beschreibung:*/
/*~+:-------------*/
/*~+:Setzt alle Parameter zur statistischen Auswertung des entsprechenden Statistik-Kanals. Dabei werden die Parameter in der Struktur StatSetup gesetzt und dieser Funktion �bergeben.*/
/*~+:*/
/*~+:*/
/*~+:Parameter:*/
/*~+:----------*/
/*~+:*/
/*~+:unsigned char byChanel:*/
/*~+:	Statistik-Kanal, f�r den die Parameter gelten sollen*/
/*~+:*/
/*~+:STATISTICS_SETUP StatSetup:*/
/*~+:*/
/*~+:	unsigned char byRunStatistics : */
/*~+:				0 = Stoppen des Statistik-Kanals*/
/*~+:				1 = Starten des Statistik-Kanals*/
/*~+:*/
/*~+:	unsigned int nFilterCheckTemperature : */
/*~+:				Filter zur Aufnahmen der Extrem-Temperaturen (minimale Anzahl der 								�berschreitungen des aktuellen Extremas bis zu dessen Aktualisierung)*/
/*~+:*/
/*~+:	unsigned int nFilterCheckWeight :*/
/*~+:				Filter zur Aufnahme der Maximalgewichte (minimale Anzahl der 									�berschreitungen des aktuellen Extremas bis zu dessen Aktualisierung)*/
/*~+:*/
/*~+:	float fMotionLimitCheckWeight : */
/*~+:				Grenzwert zwischen zwei Messungen zur Erkennung einer Gewichtsbewegung*/
/*~+:				(zur Erfassung der Gewichtsextrema)*/
/*~+: */
/*~+:	unsigned int nFilterCheckDeviation :*/
/*~+:				Filter zur Aufnahme der Maximal-Kanalabweichung (minimale Anzahl der 								�berschreitungen des aktuellen Extremas bis zu dessen Aktualisierung)			*/
/*~+:*/
/*~+:	float fMotionLimitCheckDeviation :*/
/*~+:				Grenzwert zwischen zwei Messungen zur Erkennung einer Gewichtsbewegung*/
/*~+:				(zur Erfassung der Kanalabweichung)*/
/*~+:*/
/*~+:	int nFilterOverLimit :*/
/*~+:				Filter zur Aufnahme der Anzahl der Grenzwert�berschreitungen (minimale Anzahl 						der Grenzwert-�berschreitungen bzw. Unterschreitungen bis zur Inkrementierung 						des Z�hlers bzw. bis zur Erkennung der Unterschreitung der Grenze)*/
/*~+:*/
/*~+:	long lLimitOverLimit :*/
/*~+:				Grenzwert, bei dessen �berschreitung der Z�hler inkrementiert wird.*/
/*~+:*/
/*~+:*/
/*~+:R�ckgabe: */
/*~+:---------*/
/*~+:0 :	Initialisierung ok*/
/*~+:1 :	Initialisierung fehlgeschlagen	*/
/*~+:*/
/*~+:*/
/*~+:Zugriff:*/
/*~+:--------*/
/*~+:public*/
/*~+:*/
/*~+:*/
/*~E:A27*/
/*~A:28*/
/*~+:void Statistics_StartStop(unsigned char byChanel,bit bStartStop)*/
/*~K*/
/*~+:void Statistics_StartStop(unsigned char byChanel,bit bStartStop)*/
/*~+:*/
/*~+:Beschreibung:*/
/*~+:-------------*/
/*~+:Startet oder stoppt die statistische Auswertung des angegebenen Statistik-Kanals*/
/*~+:*/
/*~+:*/
/*~+:Parameter:*/
/*~+:----------*/
/*~+:*/
/*~+:unsigned char byChanel:*/
/*~+:	Statistik-Kanal, welcher gestartet oder gestoppt werden soll*/
/*~+:*/
/*~+:bit bStartStop:*/
/*~+:	0 : Statistik-Kanal wird angehalten*/
/*~+:	1 : Statistik-Kanal wird gestartet */
/*~+:*/
/*~+:*/
/*~+:R�ckgabe: */
/*~+:---------*/
/*~+:keine*/
/*~+:*/
/*~+:*/
/*~+:Zugriff:*/
/*~+:--------*/
/*~+:public*/
/*~E:A28*/
/*~E:A17*/
/*~-1*/
#endif
/*~E:I10*/
