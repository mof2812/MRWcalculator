/*~-1*/
/*~XSF_LANGUAGE: C/C++*/
/*~A:1*/
/*~+:Includes*/
/*~T*/
#include "EE24C64.h"
#include "string.h"
/*~E:A1*/
/*~A:2*/
/*~+:Defines*/
/*~T*/
#define WRITE 0xA0		///< Identifier einer Schreiboperation
#define READ  0xA1		///< Identifier einer Leseoperation
/*~E:A2*/
/*~A:3*/
/*~+:Funktionsdeklarationen*/
/*~T*/
void 	E2CheckMemory(unsigned int nStartAdress,unsigned int nEndAdress,unsigned int* pnDefects,unsigned int nErrorBufferSize);

void 	E2ClearAll(void);
char 	E2Compare(unsigned int wE2Address, unsigned int wCount, void *pMemAddress);
bit 	E2GetErrorStatus (void);
void 	E2Init (void);
void 	E2Read(unsigned int wE2Address, unsigned int wCount, void *pMemAddress);
void 	E2ReadBlock (void *, unsigned int);
char 	E2Write(unsigned int wE2Address, unsigned int wCount, void *pMemAddress);
void 	E2WriteBlock (void *, unsigned int);
void 	E2WriteDisable (void);
void 	E2WriteEnable (void);

/*~E:A3*/
/*~A:4*/
/*~+:Variablendeklarationen*/
/*~T*/
static unsigned char byPageIndex = 0; //06.05.2003
/*~E:A4*/
/*~A:5*/
/*~+:void 	E2CheckMemory(unsigned int nStartAdress,unsigned int nEndAdress,unsigned int* pnDefects,unsigned int nErrorBufferSize)*/
/*~F:6*/
void E2CheckMemory(unsigned int nStartAdress,unsigned int nEndAdress,unsigned int* pnDefects,unsigned int nErrorBufferSize)
/*~-1*/
{
   /*~A:7*/
   /*~+:Beschreibung*/
   /*~T*/
   /*!
   \fn void E2CheckMemory(unsigned int nStartAdress,unsigned int nEndAdress,unsigned int* pnDefects,unsigned int nErrorBufferSize)
   
   <b>Beschreibung:</b><br>
   �berpr�fung der Eeprom-Speicherzellen. Hierbei wird die Speicherzelle zun�chst mit 0xAA beschrieben und zur�ckgelesen. Anschlie�end erfolgt der gleiche Test mit 0x55. Bei Unstimmigkeiten erfolgt eine dementsprechende R�ckmeldung. Nach Abschlu� des Tests ist der Speicher wieder in seinem urspr�nglichen Zustand.
   
   \param
   nStartAdress: Eeprom-Startadresse des Tests.
   
   \param
   nEndAdress: Eeprom-Endadresse des Tests.
   
   \param
   pnDefects: Pointer auf einen externen Fehlerspeicher.
   
   \param
   nErrorBufferSize: Gr��e der externen Fehlerspeichers.
   
   \return
   ./.
   
   <b>Zugriff:</b><br>
   [X] �ffentlich / [ ] Privat
   
   \ref
   ExamplePage_EE24C64 "Beispiel 'Eeprom-Treiber AT24C64'"
   */

   /*~E:A7*/
   /*~A:8*/
   /*~+:Variablendeklarationen*/
   /*~T*/
   unsigned int nAdress,nPtrErrorBuffer;
   unsigned char byTestChar,byWPIndex,byEAIndex,byOrgContent;
   /*~E:A8*/
   /*~A:9*/
   /*~+:Variableninitialisierungen*/
   /*~T*/
   nPtrErrorBuffer = 0;
   /*~E:A9*/
   /*~A:10*/
   /*~+:WriteProtection-Status und EnableAll-Status zwischenspeichern*/
   /*~T*/
   byWPIndex = WP;
   byEAIndex = EA;
   /*~E:A10*/
   /*~A:11*/
   /*~+:WriteProtection und EnableAll l�schen*/
   /*~T*/
   WP = 0;
   EA = 0;
   /*~E:A11*/
   /*~A:12*/
   /*~+:Eeprom-Speicher mit 0xAA f�llen und anschlie�end pr�fen. Bei einem Fehler erfolgt die R�ckgabe der Adresse der fehlerhaften Speicheradresse*/
   /*~L:13*/
   for (nAdress = nStartAdress;nAdress<=nEndAdress;nAdress++)
   /*~-1*/
   {
      /*~A:14*/
      /*~+:Originalwert auslesen und zwischenspeichern*/
      /*~T*/
      E2Read(nAdress,1,&byOrgContent);
      /*~E:A14*/
      /*~T*/
      byTestChar = 0xAA;
      /*~T*/
      E2Write(nAdress,1,&byTestChar);
      /*~T*/
      byTestChar = 0x00;
      /*~T*/
      E2Read(nAdress,1,&byTestChar);
      /*~A:15*/
      /*~+:Originalwert zur�ckschreiben*/
      /*~T*/
      E2Write(nAdress,1,&byOrgContent);
      /*~E:A15*/
      /*~I:16*/
      if (byTestChar != 0xAA)
      /*~-1*/
      {
         /*~T*/
         *(pnDefects+nPtrErrorBuffer) = nAdress;
         /*~I:17*/
         if (++nPtrErrorBuffer >= nErrorBufferSize - 1)
         /*~-1*/
         {
            /*~T*/
            *(pnDefects+nPtrErrorBuffer) = 0xFFFF;
            /*~T*/
            return;
         /*~-1*/
         }
         /*~E:I17*/
      /*~-1*/
      }
      /*~E:I16*/
   /*~-1*/
   }
   /*~E:L13*/
   /*~E:A12*/
   /*~A:18*/
   /*~+:Eeprom-Speicher mit 0x55 f�llen und anschlie�end pr�fen. Bei einem Fehler erfolgt die R�ckgabe der Adresse der fehlerhaften Speicheradresse*/
   /*~L:19*/
   for (nAdress = nStartAdress;nAdress<=nEndAdress;nAdress++)
   /*~-1*/
   {
      /*~A:20*/
      /*~+:Originalwert auslesen und zwischenspeichern*/
      /*~T*/
      E2Read(nAdress,1,&byOrgContent);
      /*~E:A20*/
      /*~T*/
      byTestChar = 0x55;
      /*~T*/
      E2Write(nAdress,1,&byTestChar);
      /*~T*/
      byTestChar = 0x00;
      /*~T*/
      E2Read(nAdress,1,&byTestChar);
      /*~A:21*/
      /*~+:Originalwert zur�ckschreiben*/
      /*~T*/
      E2Write(nAdress,1,&byOrgContent);
      /*~E:A21*/
      /*~I:22*/
      if (byTestChar != 0x55)
      /*~-1*/
      {
         /*~T*/
         *(pnDefects+nPtrErrorBuffer) = nAdress;
         /*~I:23*/
         if (++nPtrErrorBuffer >= nErrorBufferSize - 1)
         /*~-1*/
         {
            /*~T*/
            *(pnDefects+nPtrErrorBuffer) = 0xFFFF;
            /*~T*/
            return;
         /*~-1*/
         }
         /*~E:I23*/
      /*~-1*/
      }
      /*~E:I22*/
   /*~-1*/
   }
   /*~E:L19*/
   /*~E:A18*/
   /*~A:24*/
   /*~+:Write Protection und Enable All ggf. setzen*/
   /*~I:25*/
   if (byWPIndex)
   /*~-1*/
   {
      /*~T*/
      WP = 1;
   /*~-1*/
   }
   /*~O:I25*/
   /*~-2*/
   else
   {
      /*~T*/
      WP = 0;
   /*~-1*/
   }
   /*~E:I25*/
   /*~I:26*/
   if (byEAIndex)
   /*~-1*/
   {
      /*~T*/
      EA = 1;
   /*~-1*/
   }
   /*~O:I26*/
   /*~-2*/
   else
   {
      /*~T*/
      EA = 0;
   /*~-1*/
   }
   /*~E:I26*/
   /*~E:A24*/
   /*~A:27*/
   /*~+:Kennung des Endes der Fehlertabelle setzen (0xFFFF)*/
   /*~T*/
   *(pnDefects+nPtrErrorBuffer) = 0xFFFF;
   /*~E:A27*/
/*~-1*/
}
/*~E:F6*/
/*~E:A5*/
/*~A:28*/
/*~+:void 	E2ClearAll(void)*/
/*~F:29*/
void E2ClearAll(void)

/*~-1*/
{
   /*~A:30*/
   /*~+:Beschreibung*/
   /*~T*/
   /*!
   \fn void E2ClearAll(void)
   
   <b>Beschreibung:</b><br>
   L�scht den kompletten Eeprom-Inhalt.
   \param
   ./.
   
   \return
   ./.
   
   <b>Zugriff:</b><br>
   [X] �ffentlich / [ ] Privat
   
   \ref
   ExamplePage_EE24C64 "Beispiel 'Eeprom-Treiber AT24C64'"
   */

   /*~E:A30*/
   /*~A:31*/
   /*~+:Variablendeklarationen*/
   /*~T*/
   unsigned char pbyData[E2_PAGEWIDTH];
   unsigned char byWriteProtectCopy;
   int i;
   /*~E:A31*/
   /*~A:32*/
   /*~+:Variableninitialisierungen*/
   /*~T*/
   i = 0;
   /*~E:A32*/
   /*~T*/
   // EEPROM freigeben
   byWriteProtectCopy = WP;
   WP = 0;
   /*~A:33*/
   /*~+:Puffer l�schen*/
   /*~T*/
   memset(&pbyData[0],0,E2_PAGEWIDTH);
   /*~E:A33*/
   /*~A:34*/
   /*~+:Eeprom schrittweise l�schen*/
   /*~L:35*/
   while (i < 0x0400)
   /*~-1*/
   {
      /*~T*/
      E2Write(i,E2_PAGEWIDTH,&pbyData[0]);
      /*~T*/
      i += E2_PAGEWIDTH;
   /*~-1*/
   }
   /*~E:L35*/
   /*~E:A34*/
   /*~T*/
   // EEPROM freigeben
   WP = byWriteProtectCopy;
/*~-1*/
}
/*~E:F29*/
/*~E:A28*/
/*~A:36*/
/*~+:char 	E2Compare(unsigned int wE2Address, unsigned int wCount, void *pMemAddress)*/
/*~F:37*/
char E2Compare(unsigned int wE2Address, unsigned int wCount, void *pMemAddress)
/*~-1*/
{
   /*~A:38*/
   /*~+:Beschreibung*/
   /*~T*/
   /*!
   \fn char E2Compare(unsigned int wE2Address, unsigned int wCount, void *pMemAddress)
   
   <b>Beschreibung:</b><br>
   Vergleicht einen Adresse im RAM-Speicher mit dem Eeprom-Speicher.
   
   \param
   wE2Address: Adresse im Eeprom ab der verglichen werden soll.
   
   \param
   wCount: Anzahl der zu vergleichenden Zeichen.
   
   \param
   pMemAddress: Adresse der Daten im RAM-Speicher, mit denen der Eeprominhalt verglichen werden soll.
   
   \return
   Status des Vergleichs.
   
   \retval
   0: Daten stimmen �berein.
   \retval
   1: Daten sind unterschiedlich.
   
   <b>Zugriff:</b><br>
   [X] �ffentlich / [ ] Privat
   
   \ref
   ExamplePage_EE24C64 "Beispiel 'Eeprom-Treiber AT24C64'"
   */
   /*~E:A38*/
   /*~A:39*/
   /*~+:Variablendeklarationen*/
   /*~T*/
   char byChar2Compare;
   /*~E:A39*/
   /*~A:40*/
   /*~+:Variableninitialisierungen*/
   /*~T*/

   /*~E:A40*/
   /*~L:41*/
   while (wCount--)
   /*~-1*/
   {
      /*~T*/
      E2Read(wE2Address+wCount,1,&byChar2Compare);
      /*~I:42*/
      if (byChar2Compare != *((char*)pMemAddress+wCount))
      /*~-1*/
      {
         /*~T*/
         return 1;
      /*~-1*/
      }
      /*~E:I42*/
   /*~-1*/
   }
   /*~E:L41*/
   /*~T*/
   return 0;
/*~-1*/
}
/*~E:F37*/
/*~E:A36*/
/*~A:43*/
/*~+:bit 	E2GetErrorStatus (void)*/
/*~F:44*/
bit E2GetErrorStatus (void)
/*~-1*/
{
   /*~A:45*/
   /*~+:Beispiel*/
   /*~T*/
   /*!
   \fn bit E2GetErrorStatus (void)
   
   <b>Beschreibung:</b><br>
   Ermittlung des Eeprom-Fehlerstatus.
   
   \param
   ./.
   
   \return
   Staus des Eeproms.
   
   \retval
   0: Eeprom hat ein Acknowledge gesetzt.
   \retval
   1: Acknowledge ist ausgeblieben
   
   <b>Zugriff:</b><br>
   [X] �ffentlich / [ ] Privat
   
   \ref
   ExamplePage_EE24C64 "Beispiel 'Eeprom-Treiber AT24C64'"
   */

   /*~E:A45*/
   /*~A:46*/
   /*~+:Variablendekalartionen*/
   /*~T*/
   bit bStatus;
   /*~E:A46*/
   /*~T*/
   I2CStart();
   bStatus = I2CSend(0xA0); //Start Bedingung

   /*~T*/
   return(bStatus);
/*~-1*/
}
/*~E:F44*/
/*~E:A43*/
/*~A:47*/
/*~+:void 	E2Init (void)*/
/*~F:48*/
void E2Init (void)
/*~-1*/
{
   /*~A:49*/
   /*~+:Beschreibung*/
   /*~T*/
   /*!
   \fn void E2Init (void)
   
   <b>Beschreibung:</b><br>
   Initialisierung der Eeprom-Routinen. Im Anschlu� ist das Eeprom zun�chst schreibgesch�tzt.
   
   \param
   ./.
   
   \return
   ./.
   
   \retval
   
   <b>Zugriff:</b><br>
   [X] �ffentlich / [ ] Privat
   
   \ref
   ExamplePage_EE24C64 "Beispiel 'Eeprom-Treiber AT24C64'"
   */

   /*~E:A49*/
   /*~T*/
   WP   = 1;           // Setze Schreibschutz
/*~-1*/
}
/*~E:F48*/
/*~E:A47*/
/*~A:50*/
/*~+:void 	E2Read(unsigned int wE2Address, unsigned int wCount, void *pMemAddress)*/
/*~F:51*/
void E2Read(unsigned int wE2Address, unsigned int wCount, void *pMemAddress)
/*~-1*/
{
   /*~A:52*/
   /*~+:Beschreibung*/
   /*~T*/
   /*!
   \fn void E2Read(unsigned int wE2Address, unsigned int wCount, void *pMemAddress)
   
   <b>Beschreibung:</b><br>
   Liest eine beliebige Anzahl von Zeichen aus dem Eeprom aus.
    
   \param
   wE2Address: Quell-Adresse im Eeprom.  
   
   \param
   wCount: Anzahl der zu lesenden Zeichen
   
   \param
   pMemAddress: Ziel-Adresse des ersten zu lesenden Zeichens.
   
   \return
   ./.
   
   <b>Zugriff:</b><br>
   [X] �ffentlich / [ ] Privat
   
   \ref
   ExamplePage_EE24C64 "Beispiel 'Eeprom-Treiber AT24C64'"
   */
   /*~E:A52*/
   /*~A:53*/
   /*~+:Variablendeklarationen*/
   /*~T*/
   unsigned char byInstruction[3];

   /*~E:A53*/
   /*~T*/
   byInstruction[0] = WRITE;
   byInstruction[2] = (char)(wE2Address % 256);
   byInstruction[1] = (char)(wE2Address >> 8);


   I2CStart();

   I2CSend(byInstruction[0]); /* enter instruction & address*/
   I2CSend(byInstruction[1]);
   I2CSend(byInstruction[2]);

   byInstruction[0] = READ;
   I2CStart();
   I2CSend(byInstruction[0]); /* enter instruction & address*/
   /* read the desired page */

   E2ReadBlock(pMemAddress, wCount);

   I2CStop();

   /*~T*/
   return;
/*~-1*/
}
/*~E:F51*/
/*~E:A50*/
/*~A:54*/
/*~+:void 	E2ReadBlock (void *pDestination, unsigned int wLenght)*/
/*~F:55*/
void E2ReadBlock (void *pDestination, unsigned int wLenght)

/*~-1*/
{
   /*~A:56*/
   /*~+:Beschreibung*/
   /*~T*/
   /// @cond PROGRAMMERS_MANUAL
   /*~T*/
   /*!
   \fn void E2ReadBlock (void *pDestination, unsigned int wLenght)
   
   <b>Beschreibung:</b><br>
   Liest einen Datenblock aus dem Eeprom. Diese Funktion ist eine Unterfunktion zu E2Read(..).
   
   \param
   pSource: Zieladresse des Datenblocks.
   
   \param
   wLength: Anzahl der zu lesenden Bytes.
   
   \return
   ./.
   
   <b>Zugriff:</b><br>
   [ ] �ffentlich / [X] Privat
   
   \ref
   ExamplePage_EE24C64 "Beispiel 'Eeprom-Treiber AT24C64'"
   */
   /*~T*/
   /// @endcond

   /*~E:A56*/
   /*~A:57*/
   /*~+:Variablendeklarationen*/
   /*~T*/
   unsigned char *pDataIndex;

   /*~E:A57*/
   /*~A:58*/
   /*~+:Variableninitialisierungen*/
   /*~T*/
   pDataIndex = pDestination;
   /*~E:A58*/
   /*~T*/
   *pDataIndex = I2CReceive();
   pDataIndex++;
    wLenght--;
   /*~T*/
   /* Read Data out of the receive buffer */
   //        *pDataIndex = I2CReceive();
   //        pDataIndex++;
   //        I2CAck();

   /*~L:59*/
   while (wLenght > 0)
   /*~-1*/
   {
      /*~T*/
      I2CAck();
      *pDataIndex = I2CReceive();
      pDataIndex++;
      wLenght--;

   /*~-1*/
   }
   /*~E:L59*/
   /*~T*/
   return;
/*~-1*/
}
/*~E:F55*/
/*~E:A54*/
/*~A:60*/
/*~+:char 	E2Write(unsigned int wE2Address, unsigned int wCount, void *pMemAddress)*/
/*~F:61*/
char E2Write (unsigned int wE2Address, unsigned int wCount, void *pMemAddress)
/*~-1*/
{
   /*~A:62*/
   /*~+:Beschreibung*/
   /*~T*/
   /*!
   \fn char E2Write (unsigned int wE2Address, unsigned int wCount, void *pMemAddress)
   
   <b>Beschreibung:</b><br>
   Schreibt eine beliebige Anzahl von Zeichen in des Eeprom. Anschlie�end wird das Datum wieder ausgelesen und gepr�ft.
    
   \param
   wE2Address: Ziel-Adresse im Eeprom.  
   
   \param
   wCount: Anzahl der zu schreibenden Zeichen
   
   \param
   pMemAddress: Quell-Adresse des ersten zu schreibenden Zeichens.
   
   \return
   Status des Schreibvorgangs.
   
   \retval
   0: Daten stimmen �berein.
   \retval
   1: Daten sind unterschiedlich.
   
   <b>Zugriff:</b><br>
   [X] �ffentlich / [ ] Privat
   
   \ref
   ExamplePage_EE24C64 "Beispiel 'Eeprom-Treiber AT24C64'"
   */

   /*~E:A62*/
   /*~A:63*/
   /*~+:Variablendeklarationen*/
   /*~T*/
   bit bStatus;
   unsigned char *pDataIndex=pMemAddress,byInstruction[3];
   unsigned int wE2AddressIndex=wE2Address, wCountIndex=wCount;
   char byCounter;

   /*~E:A63*/
   /*~A:64*/
   /*~+:Variableninitialisierungen*/
   /*~T*/
   byCounter = 0;
   /*~E:A64*/
   /*~U:65*/
   /*~-2*/
   do
   {
      /*~T*/
      /* Find position within actual page */

      /*~I:66*/
      if (byPageIndex = wE2AddressIndex % E2_PAGEWIDTH)
      /*~-1*/
      {
         /*~T*/
         byPageIndex = E2_PAGEWIDTH-byPageIndex;
      /*~-1*/
      }
      /*~O:I66*/
      /*~-2*/
      else
      {
         /*~T*/
         byPageIndex = E2_PAGEWIDTH;
      /*~-1*/
      }
      /*~E:I66*/
      /*~T*/
      /* write page by page (a new page for every loop) */
      /*~L:67*/
      while (wCountIndex>0)
      /*~-1*/
      {
         /*~I:68*/
         if ((int)(wCountIndex-byPageIndex) < 0)
         /*~-1*/
         {
            /*~T*/
            byPageIndex=wCountIndex;
            wCountIndex=0;

         /*~-1*/
         }
         /*~O:I68*/
         /*~-2*/
         else
         {
            /*~T*/
            wCountIndex-=byPageIndex;
         /*~-1*/
         }
         /*~E:I68*/
         /*~T*/
         byInstruction[0] = WRITE;
         byInstruction[2] = (char)(wE2AddressIndex % 256);
         byInstruction[1] = (char)(wE2AddressIndex >> 8);

         /* write instruction */
         I2CStart();

         I2CSend(byInstruction[0]); /* enter instruction & address*/
         I2CSend(byInstruction[1]);
         I2CSend(byInstruction[2]);

         E2WriteBlock(pDataIndex, byPageIndex);
         I2CStop();

         /*~A:69*/
         /*~+:Waren bis EEPROM fertig ist.  RAUSGENOMMEN. Wird jetzt durch Spooler �bernommen*/
         /*~U:70*/
         /*~-2*/
         do
         {
            /*~T*/
            I2CStart();
            bStatus = I2CSend(0xA0); //Start Bedingung

         /*~-1*/
         }
         /*~O:U70*/
         while (bStatus);
         /*~E:U70*/
         /*~E:A69*/
         /*~T*/
         wE2AddressIndex+=byPageIndex;
         pDataIndex+=byPageIndex;
         byPageIndex = E2_PAGEWIDTH;

      /*~-1*/
      }
      /*~E:L67*/
   /*~-1*/
   }
   /*~O:U65*/
   while ((E2Compare(wE2Address,wCount,pMemAddress) && byCounter++ < 3));
   /*~E:U65*/
   /*~I:71*/
   if (byCounter < 3)
   /*~-1*/
   {
      /*~T*/
      // Okay
      return 0;
   /*~-1*/
   }
   /*~O:I71*/
   /*~-2*/
   else
   {
      /*~T*/
      // Dreimal hintereinander konnte das Datum nicht korrekt eingetragen werden
      return 1;
   /*~-1*/
   }
   /*~E:I71*/
/*~-1*/
}
/*~E:F61*/
/*~E:A60*/
/*~A:72*/
/*~+:void 	E2WriteBlock (void *pSource, unsigned int wLength)*/
/*~+:*/
/*~F:73*/
void E2WriteBlock (void *pSource, unsigned int wLength)

/*~-1*/
{
   /*~A:74*/
   /*~+:Beschreibung*/
   /*~T*/
   /// @cond PROGRAMMERS_MANUAL
   /*~T*/
   /*!
   \fn void E2WriteBlock (void *pSource, unsigned int wLength)
   
   <b>Beschreibung:</b><br>
   Schreibt einen Datenblock in des Eeprom. Diese Funktion ist eine Unterfunktion zu E2Write(..).
   
   \param
   pSource: Quelladresse des Datenblocks.
   
   \param
   wLength: Anzahl der zu schreibenden Bytes.
   
   \return
   ./.
   
   <b>Zugriff:</b><br>
   [ ] �ffentlich / [X] Privat
   
   \ref
   ExamplePage_EE24C64 "Beispiel 'Eeprom-Treiber AT24C64'"
   */

   /*~T*/
   /// @cond PROGRAMMERS_MANUAL
   /*~E:A74*/
   /*~A:75*/
   /*~+:Variablendeklarationen*/
   /*~T*/
   char *pDataIndex;

   /*~E:A75*/
   /*~A:76*/
   /*~+:Variableninitialisierungen*/
   /*~T*/
   pDataIndex = pSource;
   /*~E:A76*/
   /*~L:77*/
   for (;wLength > 0;wLength--)
   /*~-1*/
   {
      /*~T*/
      I2CSend(*pDataIndex++);

   /*~-1*/
   }
   /*~E:L77*/
   /*~T*/
   return;
/*~-1*/
}
/*~E:F73*/
/*~E:A72*/
/*~A:78*/
/*~+:void 	E2WriteDisable (void)*/
/*~F:79*/
void E2WriteDisable (void)
/*~-1*/
{
   /*~A:80*/
   /*~+:Beschreibung*/
   /*~T*/
   /*!
   \fn void E2WriteDisable (void)
   
   <b>Beschreibung:</b><br>
   Setzt den Schreibschutz.
   
   \param
   void:
   
   \return
   ./.
   
   <b>Zugriff:</b><br>
   [X] �ffentlich / [ ] Privat
   
   \ref
   ExamplePage_EE24C64 "Beispiel 'Eeprom-Treiber AT24C64'"
   */

   /*~E:A80*/
   /*~T*/
   WP = 1; //write disable
/*~-1*/
}
/*~E:F79*/
/*~E:A78*/
/*~A:81*/
/*~+:void 	E2WriteEnable (void)*/
/*~F:82*/
void E2WriteEnable (void)
/*~-1*/
{
   /*~A:83*/
   /*~+:Beschreibung*/
   /*~T*/
   /*!
   \fn void E2WriteEnable (void)
   
   <b>Beschreibung:</b><br>
   Hebt den ggf. vorhandenen Schreibschutz auf.
   
   \param
   void:
   
   \return
   ./.
   
   <b>Zugriff:</b><br>
   [X] �ffentlich / [ ] Privat
   
   \ref
   ExamplePage_EE24C64 "Beispiel 'Eeprom-Treiber AT24C64'"
   */

   /*~E:A83*/
   /*~T*/
   WP = 0; //write enable
/*~-1*/
}
/*~E:F82*/
/*~E:A81*/
