/*~-1*/
/*~XSF_LANGUAGE: C/C++*/
/*~A:1*/
/*~+:Versions-Beschreibung*/
/*~A:2*/
/*~+:Version und Versionsdatum*/
/*~T*/
/*!
\mainpage "Modul-Beschreibung"
\author Michael Offenbach
\date 09.02.2022 
\version V1.001
\warning Achtung - funktioniert nur mit intern mit 12MHz getakteten Prozessoren!!!
*/
/*~E:A2*/
/*~A:3*/
/*~+:Ziel-Hardware*/
/*~T*/
/*!\page HardwarePage Ziel-Hardware

\section sec_HardwarePage_Kommunikation 'Kommunikationroutinen'

<table border=1 width=100% height=1% rules=rows cellspacing=0 bgcolor="#E0E0F0">

<tr align=left valign=top>
	<th>Motherboard</th>
	<th>Prozessor</th>
	<th>ROM</th>
	<th>RAM</th>
</tr>

<tr>
	<td>MRW420 </td>
	<td>8051-Core</td>
	<td>62 <B>kByte</B></td>
	<td>2 <B>kByte</B></td>
</tr></table>

*/
/*~E:A3*/
/*~A:4*/
/*~+:Compiler-Einstellungen*/
/*~T*/
/*!\page CompilerPage Compiler-Einstellungen

\section sec_CompilerPage_Kommunikation 'Kommunikationroutinen'

<table border=1 width=100% height=1% rules=rows cellspacing=0 bgcolor="#E0E0F0">

<tr align=left valign=top>
	<th>Compiler</th>
	<th>Betriebssystem</th>
	<th>Speichermodell</th>
	<th>Code-Speicher-Gr��e</th>
	<th>Optimierungen</th>
	<th>Sonstiges</th>
</tr>

<tr>
	<td>Keil uVision2 V2.40<BR>C51 V7.08<BR>A51 V7.08a</td>
	<td>Kein Betriebssystem</td>
	<td>Large: variables in XDATA</td>
	<td>Large: 64k program</td>
	<td>
	[ ] 0 Constant Folding<BR>
	[ ] 1 Dead Code Elimination<BR>
	[ ] 2 Data Overlaying<BR>
	[ ] 3 Peephole Optimization<BR>
	[ ] 4 Register Variables<BR>
	[ ] 5 Common Subexpression Elimination<BR>
	[X] 6 Loop Rotation<BR>
	[ ] 7 Extended Index Access Optimizing<BR>
	[ ] 8 Reuse Common Entry Code<BR>
	[ ] 9 Common Block Subroutines<BR>
	<BR>
	[ ]Favor size<BR>
	[X]Favor speed</td>
	<td>---</td>
</tr></table>

*/
/*~E:A4*/
/*~A:5*/
/*~+:Ressourcen*/
/*~T*/
/*!\page RessourcePage Ressourcen

\section sec_RessourcePage_Kommunikation 'Kommunikationroutinen'

<table border=1 width=100% height=1% rules=rows cellspacing=0 bgcolor="#E0E0F0">

<tr align=left valign=top>
	<th>CODE</th>
	<th>IDATA</th>
	<th>XDATA</th>
	<th>Dynamische Variablen</th>
</tr>

<tr>
	<td>--- <B>Bytes</B></td>
	<td>--- <B>Bytes</B></td>
	<td>--- <B>Bytes</B></td>
	<td>(8+Maximale Parameterstringl�nge) * Anzahl m�glicher Parameter + Maximale Parameterstringl�nge + Empfangspuffergr��e + Sendepuffergr��e + 1<B>Bytes</B></td>
</tr></table>

*/
/*~E:A5*/
/*~A:6*/
/*~+:Zykluszeiten*/
/*~T*/
/*!\page CycletimePage Zykluszeiten

\section sec_CycletimePage_Kommunikation 'Kommunikationroutinen'

<table border=1 width=100% height=1% rules=rows cellspacing=0 bgcolor="#E0E0F0">

<tr align=left valign=top>
	<th>Minimale Durchlaufzeit</th>
	<th>Maximale Durchlaufzeit</th>
</tr>

<tr>
	<td>--- <B>ms</B></td>
	<td>--- <B>ms</B></td>
</tr></table>

*/
/*~E:A6*/
/*~A:7*/
/*~+:Verschiedenes*/
/*~T*/
/*!\page MiscPage Verschiedenes

\section sec_MiscPage_Kommunikation 'Kommunikationroutinen'

<table border=1 width=100% height=1% rules=rows cellspacing=0 bgcolor="#E0E0F0">

<tr align=left valign=top>
	<th>Benutzte Interrups</th>
	<th>Benutzte Registerb�nke</th>
</tr>

<tr>
	<td>4--</td>
	<td>---</td>
</tr></table>

*/
/*~E:A7*/
/*~A:8*/
/*~+:Lifecycle*/
/*~T*/
/*!\page LifeCyclePage Lifecycle

\section sec_LifeCyclePage_Kommunikation 'Kommunikationroutinen'

<table border=1 width=100% height=1% rules=rows cellspacing=0 bgcolor="#E0E0F0">

<tr align=left valign=top>
	<th>Version</th>
	<th>Datum</th>
	<th>Programmierer</th>
	<th>�nderungen</th>
</tr>

<tr>
	<td>1.000</td>
	<td>08.06.05</td>
	<td>Michael Offenbach</td>
	<td>Erste lauff�hige Version</td>
</tr>

<tr>
	<td>1.001</td>
	<td>29.11.21</td>
	<td>Michael Offenbach</td>
	<td>Funktion 'Communication_EnableCommunication()' zur Unterbindung der RS232-Befehlsverarbeitung eingebunden. De-/Aktivierung �ber Uart-Befehl.</td>
</tr>

</table>

*/
/*~E:A8*/
/*~A:9*/
/*~+:Beispiel*/
/*~T*/
/*!\page ExamplePage_Kommunikation 'Kommunikationroutinen'
\code


//Modulbeschreibung:
//Demo-Programm zur Demonstration der Einbindung der Befehle zur Kommunikation.


//Includes
#include "aduc836.h"
#include "rs232.h"
#include <Stdlib.h>

#pragma NOAREGS


unsigned char ptrDynVar[0x200];
main()
{

   // ADuC836 spezifische Einstellungen
   CFG836 |= 1;
   PLLCON &= 0xF8;
   T0 = 0;

   // Speicherplatz f�r die dynamischen Variablen reservieren
   init_mempool(ptrDynVar,sizeof(ptrDynVar));

   // RS232-Schnittstelle mit meiner Datenbreite von 8 Bit bei 9600Baud initialisieren
   RS232_Ini(8,9600);

   // Kommunikation initialisieren (Puffergr��e Empf�nger 256Byte, Sender 32Byte)
   Communication_Ini(256,32);

   // Kommunikation parametrieren (max. 4 Parameter, Texte eines Parameters kann 16 Zeichen lang sein, als Parametertrennzeichen fungiert das Leerzeichen, keine Pr�fsumme) 
   Communication_Setup(4,16,' ',COMMUNICATION_NO_CHECKSUM);

   while (1)
   {
      if (CommunicationControl.chCommandsInBuffer)
      {
         // Es ist ein Kommando im Puffer - auslesen
         Communication_GetNextCommand();
      }
   }
}


\endcode
*/

/*~E:A9*/
/*~E:A1*/
/*~I:10*/
#ifndef __COMMUNICATION_H

/*~T*/
#define __COMMUNICATION_H

/*~A:11*/
/*~+:Includes*/
/*~T*/
#include "Structdef.h"
#include "System.cnd"
/*~E:A11*/
/*~A:12*/
/*~+:Definitionen*/
/*~T*/
#define COMMUNICATION_INSTUCTIONDECODER_STATE_LINE		P32	///< Freigabeleitung der RS232-Kommunikation
#define COMMUNICATION_INSTUCTIONDECODER_RELEASE_LINE	P37	///< Freigabeleitung der RS232-Kommunikation 		!!! Wird bereits von der ADuC836-Bibliothek verwendet !!!

/*~K*/
/*~+:/~* Ge�ndert am 09.02.2022 *~/*/
/*~T*/
#define COMMUNICATION_DISABLE_CODE							0x55AA55AA
/*~K*/
/*~+:/~* Ende - Ge�ndert am 09.02.2022 *~/*/
/*~I:13*/
#ifdef SYSTEM_CND_DISABLE_SPI_COMMUNICATION_AT_FAULTS
/*~T*/
#define COMMUNICATION_MAX_SPI_COMMUNICATION_REPLIES			3
/*~-1*/
#endif
/*~E:I13*/
/*~T*/
#define COMMUNICATION_RS232					0	///< Daten sollen �ber die RS232-Schnittstelle ausgegeben werden

#define COMMUNICATION_SPI					1	///< Daten sollen �ber die SPI-Schnittstelle ausgegeben werden

#define COMMUNICATION_ALL					127	///< Alle Schnittstellen 

#define COMMUNICATION_NONE					255	///< Keine Schnittstelle 

/*~I:14*/
#ifdef CHANNEL_0
/*~T*/
#define COMMUNICATION_NB_RECBUFFERS	2
/*~-1*/
#endif
/*~E:I14*/
/*~I:15*/
#ifdef CHANNEL_1 
/*~T*/
#define COMMUNICATION_NB_RECBUFFERS	2
/*~-1*/
#endif
/*~E:I15*/
/*~T*/
#define COMMANDBUFFER_SIZE					9	///< Puffergr��e f�r Befehle
#define MAX_PARAMETERS						4	///< maximale Anzahl an Parametern
#define RECBUFFER_SIZE						32	///< Empfangspuffergr��e
#define TRANSBUFFER_SIZE					69	///< Sendepuffergr��e
/*~T*/
#define STX									0x02
#define ETX									0x03
#define ACK									0x06
#define ACKNOWLEDGE							0x06
#define NAK									0x15
/*~T*/
#define COMMUNICATION_NO_CHECKSUM			0	///< Kommunikation ohne Pr�fsumme
#define COMMUNICATION_CRC16					1	///< Kommunikation mit CRC16-Pr�fsumme
/*~T*/
// Ausgabe der einzelnen Kommandoelemente
#define COMMUNICATION_ACTUAL_COMMAND		0	///< Ausgabe des aktuellen Kommandos
#define COMMUNICATION_PARAMETER_AS_STRING	1	///< Ausgabe des Stringparameters
#define COMMUNICATION_PARAMETER_AS_FLOAT	2	///< Ausgabe des Floatparameters
#define COMMUNICATION_PARAMETER_AS_LONG		3	///< Ausgabe des Longparameters
/*~T*/
#define COMMUNICATION_VIA_RS232				0	///< Kommunikation �ber die RS232
#define COMMUNICATION_VIA_SPI				1	///< Kommunikation �ber die SPI
/*~T*/
// Freigabesteuerung RS232
#define COMMUNICATION_SET_RELEASE			0	///< Kanal 0: Freigabe erteilen
#define COMMUNICATION_CLEAR_RELEASE			1	///< Kanal 1: Freigabe zur�ckgeben
#define COMMUNICATION_WAIT_RELEASE			2	///< Kanal 0: Warte bis Kanal 1 die Freigabe zur�ck gibt
/*~T*/
// Zu sendende Mitteilung bzw. erwartete R�ckantwort
#define COMMUNICATION_SHORT_ACK				0
#define COMMUNICATION_ACK					1	
#define COMMUNICATION_OK					2	
#define COMMUNICATION_NOK					3
#define COMMUNICATION_NAK					4
/*~T*/
#define COMMUNICATION_CHECKLIMIT_ZEROPOINTCHECK			1		///< Werte m�ssen gr��er als 0 sein
#define COMMUNICATION_CHECKLIMIT_MAX_DEVIATION			2
#define COMMUNICATION_CHECKLIMIT_MAX_DRIFT				3
#define COMMUNICATION_FILTER_DEPTH						4
#define COMMUNICATION_FILTER_WIDTH						5
#define COMMUNICATION_LOADCELL							6
#define COMMUNICATION_NUMBER_OF_MEASUREMENTS			7
#define COMMUNICATION_TIME_HYSTERESIS					8
#define COMMUNICATION_MOTION_FILTER						9
#define COMMUNICATION_MOTION_LIMIT						10
#define COMMUNICATION_COMPENSATION_STATE				11
#define COMMUNICATION_E_COMPENSATION_STATE				12
#define COMMUNICATION_CURRENTINTERFACE_FEEDBACK_STATE	13
#define COMMUNICATION_CHECKSUM_ERROR					14
#define COMMUNICATION_RS232_BAUDRATE					15
/*~E:A12*/
/*~A:16*/
/*~+:Struktur-Definitionen*/
/*~T*/
typedef struct
{
/*~I:17*/
#ifdef DEVELOPMENT_SW
/*~T*/
	unsigned char	bTestSPI;						///< SPI-Test ist eingeschaltet
/*~-1*/
#endif
/*~E:I17*/
/*~T*/
	unsigned char 	chSeparator;					///< Trennzeichen zwischen den Parametern

	unsigned char 	chRecBufferPointer[2];			///< Pointer auf die n�chste Position im Empfangsbuffer

	unsigned char	chSTXReceived[2];				///< STX wurde empfangen
	signed int 		nAnzahlSendezeichen;            ///< Anzahl der Zeichen im Sendebuffer
	unsigned char 	chRecBuffer[2][RECBUFFER_SIZE];	///< Empfangspuffer	

	unsigned char 	chTransBuffer[2][TRANSBUFFER_SIZE];///< Sendepuffer
	unsigned char 	chReleasedSet;					///< Freigabe der RS232-Schnittstelle f�r Kanal 1
	unsigned char	chLine2Interprete;				///< zu �bersetzender Empfangskanal
	unsigned char	byResetRepliesDueToSPIFaults;	///< Anzahl der erfolgten Resets nach
													///< Kommunikationsproblemen
	unsigned char	byDisableSPICommunication;		///< SPI-Kommunikation unterbinden
	unsigned char	byResetInhibitFlag;				///< Reset bei SPI-Kommunikationsproblemen unterbinden
//	unsigned char	byDisableCRC16;					///< Unterbinde die CRC16-Pr�fung

/*~I:18*/
#ifdef DEVELOPMENT_SW
/*~T*/
	unsigned long	ulSPICounter;
/*~I:19*/
#ifdef CHANNEL_0
/*~T*/
	unsigned long	ulSPIE1Counter;

/*~I:20*/
#ifndef SYSTEM_CND_ALL_SPI_COMMUNICATIONS
/*~T*/
	unsigned long	ulSPIE1CounterLast;
/*~-1*/
#endif
/*~E:I20*/
/*~-1*/
#endif
/*~E:I19*/
/*~-1*/
#endif
/*~E:I18*/
/*~K*/
/*~+:/~* Ge�ndert am 09.02.2022 *~/*/
/*~T*/
	unsigned long ulCommunicationDisable;			///< �ber diese Variable l�sst sich die Kommunikation sperren

/*~K*/
/*~+:/~* Ende - Ge�ndert am 09.02.2022 *~/*/
/*~T*/
}COMMUNICATION_CONTROL;
/*~T*/
typedef struct
{
	unsigned char 	achCommand[COMMANDBUFFER_SIZE];	///< Kommando (darf maximal 8 Zeichen lang sein)
	GLOBAL_UNIVALUE Parameter[MAX_PARAMETERS];		///< Parameterspeicher
	unsigned char byParametersFound;				///< Anzahl der gefundenen Parameter
}COMMUNICATION_COMMAND;

/*~E:A16*/
/*~A:21*/
/*~+:Funktionsdeklarationen*/
/*~I:22*/
#ifdef MIT_CRC16
/*~T*/
extern unsigned char* 		Communication_AppendChecksum(unsigned char *szString);
extern unsigned char 		Communication_CheckReceiveFrame(unsigned char *szString);
/*~-1*/
#endif
/*~E:I22*/
/*~T*/
extern void 			Communication_ClearSPIFaultCounter(unsigned char bClearCounterOnly);
/*~K*/
/*~+:/~* Ge�ndert am 09.02.2022 *~/*/
/*~T*/
extern char 			Communication_EnableCommunication(unsigned char bEnable);
/*~K*/
/*~+:/~* Ende - Ge�ndert am 09.02.2022 *~/*/
/*~I:23*/
#ifdef MIT_CRC16
/*~T*/
extern void 			Communication_EnableCRC16(unsigned char byEnable);

/*~-1*/
#endif
/*~E:I23*/
/*~I:24*/
#ifdef CHANNEL_0
/*~T*/
extern char 			Communication_GetFloat(float *pfValue,unsigned long ulTimeout);
/*~-1*/
#endif
/*~E:I24*/
/*~T*/
extern float 			Communication_GetFloatParameter(unsigned char chWhichParameter);
extern unsigned char* 		Communication_GetCommand(void);

/*~I:25*/
#ifdef CHANNEL_0 
/*~T*/
extern char 			Communication_GetLong(long *plValue);

/*~-1*/
#endif
/*~E:I25*/
/*~T*/
extern long 			Communication_GetLongParameter(unsigned char chWhichParameter);
extern unsigned char 		Communication_GetNumberOfParameters(void);
extern char 			Communication_GetRecBuffer(unsigned char chLine,char* pDest);
/*~I:26*/
#ifdef CHANNEL_0
/*~T*/
extern unsigned char		Communication_GetSPIResponse(void);
extern unsigned char		Communication_GetSPIValue(unsigned char byWhat2Get,void *pValue);

/*~-1*/
#endif
/*~E:I26*/
/*~T*/
extern char 			Communication_GetString(unsigned char *pchString);

extern char* 			Communication_GetStringParameter(unsigned char chWhichParameter);
extern void			Communication_IncrementSPIFaultCounter(void);
extern void 			Communication_Ini(unsigned char chSeparator,unsigned char byMode);
extern unsigned char* 		Communication_Interpret(unsigned char *szString);
extern char 			Communication_IsESC(void);

/*~K*/
/*~+:/~* Ge�ndert am 09.02.2022 *~/*/
/*~T*/
extern unsigned char 		Communication_IsCommunicationEnabled(void);

/*~K*/
/*~+:/~* Ende - Ge�ndert am 09.02.2022 *~/*/
/*~T*/
extern char 			Communication_IsOK(void);
extern unsigned char 		Communication_IsSPICommuncationDisabled(void);
extern void 			Communication_SendCR(unsigned char chNbCRs);
extern void 			Communication_SendFloat(unsigned char chLine2Send,long lText2Send,float fValue,char chPrecision,unsigned char chCRBefore,unsigned char chCRAfter);

extern char 			Communication_SendLong(unsigned char chLine2Send,long lText2Send,long lValue,unsigned char chCRBefore,unsigned char chCRAfter);

extern char 			Communication_SendMessage(unsigned char chLine2Send,unsigned char chWhat2Send);

extern char 			Communication_SendNext(void);
extern char 			Communication_SendRawString(unsigned char chLine2Send,unsigned char *szString);


/*~I:27*/
#ifdef MIT_CRC16
/*~T*/
extern char 			Communication_SendRawString_CRC16(unsigned char chLine2Send,unsigned char *szString,unsigned char byClearCRC);

/*~-1*/
#endif
/*~E:I27*/
/*~T*/
extern char 			Communication_SendSPICommand(unsigned char *szCommand);
extern char 			Communication_SendSPICommandEx(unsigned char *szCommand,unsigned char bySingleCharMode);

extern char 			Communication_SendString(unsigned char chLine2Send,unsigned char *szString,unsigned char chCRBefore,unsigned char chCRAfter);

extern char 			Communication_SendStringEx(unsigned char chLine2Send,unsigned char *szString,unsigned char chCRBefore,unsigned char chCRAfter,unsigned char bySingleCharMode);

extern void 			Communication_SetResetInhibitFlag(unsigned char bSet);
extern char 			Communication_Wait4Response(void);
/*~E:A21*/
/*~A:28*/
/*~+:Variablen*/
/*~T*/
extern COMMUNICATION_CONTROL CommunicationControl;
extern COMMUNICATION_COMMAND *pCommunicationCommand;
/*~E:A28*/
/*~-1*/
#endif
/*~E:I10*/
