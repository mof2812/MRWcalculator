/*~-1*/
/*~XSF_LANGUAGE: C/C++*/
/*~K*/
/*~+:File :        CommunicationControl.c*/
/*~+:*/
/*~+:Version :     V1.001*/
/*~+:*/
/*~+:Date :        09.02.2022*/
/*~+:*/
/*~+:Time :        10:23*/
/*~+:*/
/*~+:Author :      MOF*/
/*~+:*/
/*~+:Hardware :*/
/*~+:*/
/*~+:Description :*/
/*~+:*/
/*~+:*/
/*~A:1*/
/*~+:Includes*/
/*~T*/
#include "Global.h"
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
/*~E:A1*/
/*~A:2*/
/*~+:Funktionseigene Definitionen*/
/*~T*/

/*~E:A2*/
/*~A:3*/
/*~+:Funktionseigene Struktur-Definitionen*/
/*~T*/

/*~E:A3*/
/*~A:4*/
/*~+:Funktionsprototypen*/
/*~T*/
extern void Debug(long lLong_1,long lLong_2,long lLong_3,long lLong_4);
/*~K*/
/*~+:*/
/*~I:5*/
#ifdef MIT_CRC16
/*~T*/
unsigned char* 	Communication_AppendChecksum(unsigned char *szString);
unsigned int 	Communication_BuildCRC(unsigned char *szString,int nLen,unsigned char byInitialize);

unsigned char 	Communication_CheckReceiveFrame(unsigned char *szString);

/*~-1*/
#endif
/*~E:I5*/
/*~T*/
void 			Communication_ClearSPIFaultCounter(unsigned char bClearCounterOnly);

/*~K*/
/*~+:/~* Ge�ndert am 09.02.2022 *~/*/
/*~T*/
char 			Communication_EnableCommunication(unsigned char bEnable);
/*~K*/
/*~+:/~* Ende - Ge�ndert am 09.02.2022 *~/*/
/*~I:6*/
#ifdef MIT_CRC16
/*~T*/
void 			Communication_EnableCRC16(unsigned char byEnable);

/*~-1*/
#endif
/*~E:I6*/
/*~T*/
unsigned char* 	Communication_GetCommand(void);

/*~I:7*/
#ifdef CHANNEL_0
/*~T*/
char 			Communication_GetFloat(float *pfValue,unsigned long ulTimeout);
/*~-1*/
#endif
/*~E:I7*/
/*~T*/
float 			Communication_GetFloatParameter(unsigned char chWhichParameter);

/*~I:8*/
#ifdef CHANNEL_0
/*~T*/
char 			Communication_GetLong(long *plValue);
/*~-1*/
#endif
/*~E:I8*/
/*~T*/
long 			Communication_GetLongParameter(unsigned char chWhichParameter);
unsigned char 	Communication_GetNumberOfParameters(void);
char 			Communication_GetRecBuffer(unsigned char chLine, char* pDest);
/*~I:9*/
#ifdef CHANNEL_0
/*~T*/
unsigned char	Communication_GetSPIResponse(void);
unsigned char	Communication_GetSPIValue(unsigned char byWhat2Get,void *pValue);

/*~-1*/
#endif
/*~E:I9*/
/*~T*/
char 			Communication_GetString(unsigned char *pchString);
char* 			Communication_GetStringParameter(unsigned char chWhichParameter);
void			Communication_IncrementSPIFaultCounter(void);
void 			Communication_Ini(unsigned char chSeparator,unsigned char byMode);
unsigned char* 		Communication_Interpret(unsigned char *szString);

/*~K*/
/*~+:/~* Ge�ndert am 09.02.2022 *~/*/
/*~T*/
unsigned char 		Communication_IsCommunicationEnabled(void);

/*~K*/
/*~+:/~* Ende - Ge�ndert am 09.02.2022 *~/*/
/*~T*/
char 			Communication_IsESC(void);
char 			Communication_IsOK(void);
unsigned char 	Communication_IsSPICommuncationDisabled(void);
void 			Communication_SendCR(unsigned char chNbCRs);
void 			Communication_SendFloat(unsigned char chLine2Send,long lText2Send,float fValue,char chPrecision,unsigned char chCRBefore,unsigned char chCRAfter);

char 			Communication_SendLong(unsigned char chLine2Send,long lText2Send,long lValue,unsigned char chCRBefore,unsigned char chCRAfter);

char 			Communication_SendMessage(unsigned char chLine2Send,unsigned char chWhat2Send);
char 			Communication_SendNext(void);
char 			Communication_SendRawString(unsigned char chLine2Send,unsigned char *szString);

/*~I:10*/
#ifdef MIT_CRC16
/*~T*/
char 			Communication_SendRawString_CRC16(unsigned char chLine2Send,unsigned char *szString,unsigned char byClearCRC);

/*~-1*/
#endif
/*~E:I10*/
/*~T*/

char 			Communication_SendSPICommand(unsigned char *szCommand);
char 			Communication_SendSPICommandEx(unsigned char *szCommand,unsigned char bySingleCharMode);

char 			Communication_SendString(unsigned char chLine2Send,unsigned char *szString,unsigned char chCRBefore,unsigned char chCRAfter);

char 			Communication_SendStringEx(unsigned char chLine2Send,unsigned char *szString,unsigned char chCRBefore,unsigned char chCRAfter,unsigned char bySingleCharMode);

void 			Communication_SetResetInhibitFlag(unsigned char bSet);
char 			Communication_Wait4Response(void);
/*~E:A4*/
/*~A:11*/
/*~+:Globale Variablen*/
/*~T*/
COMMUNICATION_CONTROL CommunicationControl;
COMMUNICATION_COMMAND *pCommunicationCommand;
unsigned char *pucRecBufferIndex;
/*~I:12*/
#ifdef DEVELOPMENT_SW
/*~I:13*/
#ifdef CHANNEL_0
/*~T*/
unsigned long ulE1Counter = 0;

/*~-1*/
#endif
/*~E:I13*/
/*~-1*/
#endif
/*~E:I12*/
/*~E:A11*/
/*~I:14*/
#ifdef MIT_CRC16
/*~A:15*/
/*~+:unsigned char* Communication_AppendChecksum(unsigned char *szString)*/
/*~F:16*/
unsigned char* Communication_AppendChecksum(unsigned char *szString)
/*~-1*/
{
   /*~A:17*/
   /*~+:Variablendeklarationen*/
   /*~T*/

   /*~E:A17*/
   /*~A:18*/
   /*~+:Variableninitialisierungen*/
   /*~T*/

   /*~E:A18*/
   /*~I:19*/
   if (CommunicationControl.byDisableCRC16 == FALSE)
   /*~-1*/
   {
      /*~T*/
      Communication_BuildCRC(szString,-1,TRUE);
      /*~T*/
      // Leerzeichen vor der Pr�fsumme mit einbeziehen
      CRC16_Build(0x20);
      /*~T*/
      return CRC16_ToASCII(); 
   /*~-1*/
   }
   /*~O:I19*/
   /*~-2*/
   else
   {
      /*~T*/
      return "";
   /*~-1*/
   }
   /*~E:I19*/
/*~-1*/
}
/*~E:F16*/
/*~E:A15*/
/*~-1*/
#endif
/*~E:I14*/
/*~I:20*/
#ifdef MIT_CRC16
/*~A:21*/
/*~+:unsigned int 	Communication_BuildCRC(unsigned char *szString,int nLen,unsigned char byInitialize)*/
/*~F:22*/
/*#LJ:Communication_BuildCRC=26*/
unsigned int Communication_BuildCRC(unsigned char *szString,int nLen,unsigned char byInitialize)
/*~-1*/
{
   /*~A:23*/
   /*~+:Variablendeklarationen*/
   /*~T*/
   unsigned int uChecksum;
   int i;
   /*~E:A23*/
   /*~A:24*/
   /*~+:Variableninitialisierungen*/
   /*~T*/

   /*~E:A24*/
   /*~I:25*/
   if (CommunicationControl.byDisableCRC16 == FALSE)
   /*~-1*/
   {
      /*~I:26*/
      if (byInitialize == TRUE)
      /*~-1*/
      {
         /*~T*/
         // Checksumme zun�chst l�schen
         CRC16_Clear();
      /*~-1*/
      }
      /*~E:I26*/
      /*~I:27*/
      if (nLen < 0)
      /*~-1*/
      {
         /*~T*/
         nLen = strlen(szString);
      /*~-1*/
      }
      /*~E:I27*/
      /*~L:28*/
      for (i=0;i<nLen;i++)
      /*~-1*/
      {
         /*~T*/
         uChecksum = CRC16_Build(*(unsigned char*)(szString + i));
      /*~-1*/
      }
      /*~E:L28*/
      /*~T*/
      return uChecksum;
   /*~-1*/
   }
   /*~O:I25*/
   /*~-2*/
   else
   {
      /*~T*/
      return 0;
   /*~-1*/
   }
   /*~E:I25*/
/*~-1*/
}
/*~E:F22*/
/*~E:A21*/
/*~-1*/
#endif
/*~E:I20*/
/*~I:29*/
#ifdef MIT_CRC16
/*~A:30*/
/*~+:unsigned char 	Communication_CheckReceiveFrame(unsigned char *szString)*/
/*~F:31*/
unsigned char Communication_CheckReceiveFrame(unsigned char *szString)
/*~-1*/
{
   /*~A:32*/
   /*~+:Variablendeklarationen*/
   /*~T*/
   int 			nLen;
   unsigned char 	ucChecksumError;
   /*~E:A32*/
   /*~A:33*/
   /*~+:Variableninitialisierungen*/
   /*~T*/

   /*~E:A33*/
   /*~I:34*/
   if (CommunicationControl.byDisableCRC16 == FALSE)
   /*~-1*/
   {
      /*~T*/
      nLen = strlen(szString) - 4; 
      /*~T*/
      /* Pr�fsumme ermitteln */
      Communication_BuildCRC(szString,nLen,TRUE);
      /*~T*/
      /* �berpr�fung zwischen selbst ermittelter und �bermittelter Pr�fsumme */
      /*~I:35*/
      if (strcmp(CRC16_ToASCII(),szString + nLen) != 0)
      /*~-1*/
      {
         /*~T*/
         ucChecksumError = TRUE;
      /*~-1*/
      }
      /*~O:I35*/
      /*~-2*/
      else
      {
         /*~T*/
         ucChecksumError = FALSE;
      /*~-1*/
      }
      /*~E:I35*/
      /*~T*/
      /* Pr�fsumme aus dem Befehlsstring entfernen */
      *(szString + nLen - 1) = 0;
   /*~-1*/
   }
   /*~O:I34*/
   /*~-2*/
   else
   {
      /*~T*/
      ucChecksumError = 0;
   /*~-1*/
   }
   /*~E:I34*/
   /*~T*/
   return ucChecksumError;
/*~-1*/
}
/*~E:F31*/
/*~E:A30*/
/*~-1*/
#endif
/*~E:I29*/
/*~A:36*/
/*~+:void 			Communication_ClearSPIFaultCounter(unsigned char bClearCounterOnly)*/
/*~F:37*/
void Communication_ClearSPIFaultCounter(unsigned char bClearCounterOnly)
/*~-1*/
{
   /*~I:38*/
   if (!bClearCounterOnly)
   /*~-1*/
   {
      /*~T*/
      CommunicationControl.byDisableSPICommunication = 0;
      /*~A:39*/
      /*~+:Flag zur Unterbindung eines Resets bei Kommunikationsproblemen l�schen*/
      /*~T*/
      Communication_SetResetInhibitFlag(0);
      /*~E:A39*/
   /*~-1*/
   }
   /*~O:I38*/
   /*~-2*/
   else
   {
      /*~A:40*/
      /*~+:Flag zur Unterbindung eines Resets bei Kommunikationsproblemen setzen*/
      /*~T*/
      Communication_SetResetInhibitFlag(1);
      /*~E:A40*/
   /*~-1*/
   }
   /*~E:I38*/
   /*~T*/
   CommunicationControl.byResetRepliesDueToSPIFaults = 0;
   /*~A:41*/
   /*~+:Z�hlerstand speichern*/
   /*~T*/
   // Z�hlerstand speichern
   Save_Parameter(LOAD_SAVE_SPI_FAULT_COUNTER,&CommunicationControl.byResetRepliesDueToSPIFaults,1);
   /*~E:A41*/
/*~-1*/
}
/*~E:F37*/
/*~E:A36*/
/*~K*/
/*~+:/~* Ge�ndert am 09.02.2022 *~/*/
/*~A:42*/
/*~+:char 			Communication_EnableCommunication(unsigned char bEnable)*/
/*~F:43*/
char Communication_EnableCommunication(unsigned char bEnable)
/*~-1*/
{
   /*~A:44*/
   /*~+:Variablendeklarationen*/
   /*~T*/
   char byRetVal;
   /*~E:A44*/
   /*~A:45*/
   /*~+:Variableninitialisierungen*/
   /*~T*/
   byRetVal = 0;			/* Kein Fehler */
   /*~E:A45*/
   /*~I:46*/
   if (bEnable == 1)
   /*~-1*/
   {
      /*~T*/
      CommunicationControl.ulCommunicationDisable = ~(COMMUNICATION_DISABLE_CODE);
   /*~-1*/
   }
   /*~O:I46*/
   /*~-2*/
   else
   {
      /*~T*/
      CommunicationControl.ulCommunicationDisable = COMMUNICATION_DISABLE_CODE;
   /*~-1*/
   }
   /*~E:I46*/
   /*~T*/
   byRetVal = Save_Parameter(LOAD_SAVE_RS232_DISABLE_CODE,&CommunicationControl.ulCommunicationDisable, 4);
   /*~T*/
   return(byRetVal);
/*~-1*/
}
/*~E:F43*/
/*~E:A42*/
/*~K*/
/*~+:/~* Ende - Ge�ndert am 09.02.2022 *~/*/
/*~I:47*/
#ifdef MIT_CRC16
/*~A:48*/
/*~+:void 			Communication_EnableCRC16(unsigned char byEnable)*/
/*~F:49*/
void Communication_EnableCRC16(unsigned char byEnable)
/*~-1*/
{
   /*~I:50*/
#ifdef MIT_CRC16
   /*~T*/
   CommunicationControl.byDisableCRC16 = !byEnable;
   /*~O:I50*/
   /*~-1*/
#else
   /*~T*/
   CommunicationControl.byDisableCRC16 = FALSE;
   /*~-1*/
#endif
   /*~E:I50*/
/*~-1*/
}
/*~E:F49*/
/*~E:A48*/
/*~-1*/
#endif
/*~E:I47*/
/*~A:51*/
/*~+:unsigned char* 	Communication_GetCommand(void)*/
/*~F:52*/
unsigned char* Communication_GetCommand(void)
/*~-1*/
{
   /*~A:53*/
   /*~+:Beschreibung*/
   /*~T*/
   /*!
   \fn unsigned char* Communication_GetCommand(void)
   
   <b>Beschreibung:</b><br>
   Bestimmung des aktuellen Kommandos. Zuvor wird das letzte empfangene Frame zum Kanal 1 weitergeleitet
   
   \param
   ./.
   
   \return
   Aktuelles Kommando.
   
   <b>Zugriff:</b><br>
   [X] �ffentlich / [ ] Privat
   
   \ref
   ExamplePage_Kommunikation "Kommunikationroutinen"
   */

   /*~E:A53*/
   /*~A:54*/
   /*~+:Variablendeklarationen*/
   /*~T*/

   /*~E:A54*/
   /*~A:55*/
   /*~+:Variableninitialisierungen*/
   /*~T*/

   /*~E:A55*/
   /*~T*/
   return pCommunicationCommand->achCommand;
/*~-1*/
}
/*~E:F52*/
/*~E:A51*/
/*~A:56*/
/*~+:// ausgeklammert*/
/*~+:char 			Communication_GetFloat(float *pfValue,unsigned long ulTimeout)*/
/*~I:57*/
#ifdef MOF
/*~I:58*/
#ifdef CHANNEL_0
/*~A:59*/
/*~+:char 			Communication_GetFloat(float *pfValue,unsigned long ulTimeout)	// �ber SPI-SChnittstelle */
/*~F:60*/
char Communication_GetFloat(float *pfValue,unsigned long ulTimeout)
/*~-1*/
{
   /*~A:61*/
   /*~+:Variablendeklarationen*/
   /*~T*/
   char chRetVal;
   char szString[40];
   /*~E:A61*/
   /*~A:62*/
   /*~+:Variableninitialisierungen*/
   /*~T*/
   chRetVal = 1;
   /*~E:A62*/
   /*~I:63*/
   if (!ADuC836_SPIWait4Response(ulTimeout))
   /*~-1*/
   {
      /*~I:64*/
      if (!Communication_GetRecBuffer(COMMUNICATION_SPI,szString))
      /*~-1*/
      {
         /*~T*/
         *pfValue = atof(szString);;
      /*~-1*/
      }
      /*~O:I64*/
      /*~-2*/
      else
      {
         /*~T*/
         return 2;
      /*~-1*/
      }
      /*~E:I64*/
      /*~T*/
      return 0;
   /*~-1*/
   }
   /*~O:I63*/
   /*~-2*/
   else
   {
      /*~T*/
      return 1;
   /*~-1*/
   }
   /*~E:I63*/
/*~-1*/
}
/*~E:F60*/
/*~E:A59*/
/*~-1*/
#endif
/*~E:I58*/
/*~-1*/
#endif
/*~E:I57*/
/*~E:A56*/
/*~A:65*/
/*~+:float 			Communication_GetFloatParameter(unsigned char chWhichParameter)*/
/*~F:66*/
float Communication_GetFloatParameter(unsigned char chWhichParameter)
/*~-1*/
{
   /*~A:67*/
   /*~+:Beschreibung*/
   /*~T*/
   /*!
   \fn float Communication_GetFloatParameter(unsigned char chWhichParameter)
   
   <b>Beschreibung:</b><br>
   Bestimmung des Float-Wertes eines Parameters im aktuellen Kommandostring.
   
   \param
   chWhichParameter: Nummer des Parameters, dessen Wert zur�ckgeliefert werden soll.
   
   \return
   Float-Wert des angew�hlten Parameters.
   
   <b>Zugriff:</b><br>
   [X] �ffentlich / [ ] Privat
   
   \ref
   ExamplePage_Kommunikation "Kommunikationroutinen"
   */

   /*~E:A67*/
   /*~T*/
   return atof(pCommunicationCommand->Parameter[chWhichParameter].szString);
/*~-1*/
}
/*~E:F66*/
/*~E:A65*/
/*~I:68*/
#ifdef CHANNEL_0
/*~A:69*/
/*~+:char 			Communication_GetLong(long *plValue)	// �ber SPI-SChnittstelle*/
/*~F:70*/
char Communication_GetLong(long *plValue)
/*~-1*/
{
   /*~A:71*/
   /*~+:Variablendeklarationen*/
   /*~T*/
   char szString[40];
   /*~E:A71*/
   /*~A:72*/
   /*~+:Variableninitialisierungen*/
   /*~T*/

   /*~E:A72*/
   /*~I:73*/
   if (!ADuC836_SPIWait4Response(SYSTEM_TIMEOUT_SPI))
   /*~-1*/
   {
      /*~I:74*/
      if (!Communication_GetRecBuffer(COMMUNICATION_SPI,szString))
      /*~-1*/
      {
         /*~T*/
         *plValue = atol(szString);
         /*~T*/
         return 0;
      /*~-1*/
      }
      /*~O:I74*/
      /*~-2*/
      else
      {
         /*~A:75*/
         /*~+:SPI-Debugging - nur zu Testzwecken*/
         /*~I:76*/
#ifdef DEVELOPMENT_SW
         /*~I:77*/
#ifdef CHANNEL_0
         /*~I:78*/
#ifdef SYSTEM_CND_ALL_SPI_COMMUNICATIONS
         /*~I:79*/
         if (CommunicationControl.bTestSPI == 1)
         /*~-1*/
         {
            /*~T*/
            Communication_SendString(COMMUNICATION_RS232,"M:E2",0,1);
         /*~-1*/
         }
         /*~E:I79*/
         /*~-1*/
#endif
         /*~E:I78*/
         /*~-1*/
#endif
         /*~E:I77*/
         /*~-1*/
#endif
         /*~E:I76*/
         /*~E:A75*/
         /*~T*/
         return 2;
      /*~-1*/
      }
      /*~E:I74*/
   /*~-1*/
   }
   /*~O:I73*/
   /*~-2*/
   else
   {
      /*~A:80*/
      /*~+:SPI-Debugging - nur zu Testzwecken*/
      /*~I:81*/
#ifdef DEVELOPMENT_SW
      /*~I:82*/
#ifdef CHANNEL_0
      /*~I:83*/
#ifdef SYSTEM_CND_ALL_SPI_COMMUNICATIONS
      /*~I:84*/
      if (CommunicationControl.bTestSPI == 1)
      /*~-1*/
      {
         /*~T*/
         Communication_SendString(COMMUNICATION_RS232,"M:E1",0,1);
      /*~-1*/
      }
      /*~E:I84*/
      /*~-1*/
#endif
      /*~E:I83*/
      /*~T*/
      CommunicationControl.ulSPIE1Counter++;
      /*~-1*/
#endif
      /*~E:I82*/
      /*~-1*/
#endif
      /*~E:I81*/
      /*~E:A80*/
      /*~T*/
      return 1;
   /*~-1*/
   }
   /*~E:I73*/
/*~-1*/
}
/*~E:F70*/
/*~E:A69*/
/*~-1*/
#endif
/*~E:I68*/
/*~A:85*/
/*~+:long 			Communication_GetLongParameter(unsigned char chWhichParameter)*/
/*~F:86*/
long Communication_GetLongParameter(unsigned char chWhichParameter)
/*~-1*/
{
   /*~A:87*/
   /*~+:Beschreibung*/
   /*~T*/
   /*!
   \fn long Communication_GetLongParameter(unsigned char chWhichParameter)
   
   <b>Beschreibung:</b><br>
   Bestimmung des Long-Wertes eines Parameters im aktuellen Kommandostring.
   
   \param
   chWhichParameter: Nummer des Parameters, dessen Wert zur�ckgeliefert werden soll.
   
   \return
   Long-Wert des angew�hlten Parameters.
   
   <b>Zugriff:</b><br>
   [X] �ffentlich / [ ] Privat
   
   \ref
   ExamplePage_Kommunikation "Kommunikationroutinen"
   */

   /*~E:A87*/
   /*~T*/
   return atol(pCommunicationCommand->Parameter[chWhichParameter].szString);
/*~-1*/
}
/*~E:F86*/
/*~E:A85*/
/*~A:88*/
/*~+:unsigned char 		Communication_GetNumberOfParameters(void)*/
/*~F:89*/
unsigned char Communication_GetNumberOfParameters(void)
/*~-1*/
{
   /*~T*/
   return pCommunicationCommand->byParametersFound;
/*~-1*/
}
/*~E:F89*/
/*~E:A88*/
/*~A:90*/
/*~+:char 			Communication_GetRecBuffer(unsigned char chLine, char* pDest)*/
/*~F:91*/
char Communication_GetRecBuffer(unsigned char chLine, char* pDest)
/*~-1*/
{
   /*~I:92*/
   if (chLine == COMMUNICATION_SPI)
   /*~-1*/
   {
      /*~T*/
      return ADuC836_SPIGetRecBuffer(pDest);
   /*~-1*/
   }
   /*~O:I92*/
   /*~-2*/
   else
   {
      /*~I:93*/
      if (chLine == COMMUNICATION_RS232)
      /*~-1*/
      {
         /*~T*/
         return ADuC836_RS232GetRecBuffer(pDest);
      /*~-1*/
      }
      /*~O:I93*/
      /*~-2*/
      else
      {
         /*~T*/
         return 2;
      /*~-1*/
      }
      /*~E:I93*/
   /*~-1*/
   }
   /*~E:I92*/
/*~-1*/
}
/*~E:F91*/
/*~E:A90*/
/*~I:94*/
#ifdef CHANNEL_0
/*~A:95*/
/*~+:unsigned char		Communication_GetSPIResponse(void)*/
/*~F:96*/
unsigned char Communication_GetSPIResponse(void)
/*~-1*/
{
   /*~A:97*/
   /*~+:Beschreibung*/
   /*~T*/
   /*!
   \fn char Communication_GetResponse(unsigned char chLine2Send,unsigned char chAnswertExpected)
   
   <b>Beschreibung:</b><br>
   Kanal 0 erfragt den Status der Befehlsausf�hrung des Kanal 1.
   
   \param
   ./.
   
   \return
   Status der Befehlsausf�hrung des Kanal 1.
   
   \retval
   0 : Alles okay
   \retval
   1 : Fehler bei der Ausf�hrung des Befehls
   \retval
   2: Kommunikationsfehler
   
   <b>Zugriff:</b><br>
   [X] �ffentlich / [ ] Privat
   
   */

   /*~E:A97*/
   /*~A:98*/
   /*~+:Variablendeklarationen*/
   /*~T*/
   long lData;
   char chError;
   unsigned long ulTimeout;
   /*~E:A98*/
   /*~A:99*/
   /*~+:Variableninitialsierungen*/
   /*~T*/
   chError = 0;
   ulTimeout = SYSTEMTIME + SYSTEM_TIMEOUT_SPI_LAST_COMMAND_EXECUTION;	// Timeout setzen
   /*~E:A99*/
   /*~U:100*/
   /*~-2*/
   do
   {
      /*~T*/
      chError = Communication_SendSPICommand("iGRS");
      /*~I:101*/
      if (!chError)
      /*~-1*/
      {
         /*~T*/
         chError = Communication_GetLong(&lData);
         /*~I:102*/
         if (!chError)
         /*~-1*/
         {
            /*~I:103*/
            if (lData == 0xA5)
            /*~-1*/
            {
               /*~T*/
               // mal ein wenig warten (3ms)
               System_Wait(30);
            /*~-1*/
            }
            /*~E:I103*/
         /*~-1*/
         }
         /*~E:I102*/
      /*~-1*/
      }
      /*~E:I101*/
   /*~-1*/
   }
   /*~O:U100*/
   while (((lData == 0xA5)||(chError))&&(ulTimeout > SYSTEMTIME));
   /*~E:U100*/
   /*~I:104*/
   if (!chError)
   /*~-1*/
   {
      /*~T*/
      return (unsigned char)lData;	///< 0: Okay
   /*~-1*/
   }
   /*~O:I104*/
   /*~-2*/
   else
   {
      /*~T*/
      return -1;	///< Kommunikationsfehler
   /*~-1*/
   }
   /*~E:I104*/
/*~-1*/
}
/*~E:F96*/
/*~E:A95*/
/*~I:105*/
#ifdef MOF
/*~A:106*/
/*~+:unsigned char	Communication_GetSPIValue(unsigned char byWhat2Get,void *pValue)*/
/*~F:107*/
unsigned char Communication_GetSPIValue(unsigned char byWhat2Get,void *pValue)
/*~-1*/
{
   /*~A:108*/
   /*~+:Beschreibung*/
   /*~T*/
   /*!
   \fn char Communication_GetResponse(unsigned char chLine2Send,unsigned char chAnswertExpected)
   
   <b>Beschreibung:</b><br>
   Kanal 0 erfragt den Status der Befehlsausf�hrung des Kanal 1.
   
   \param
   ./.
   
   \return
   Status der Befehlsausf�hrung des Kanal 1.
   
   \retval
   0 : Alles okay
   \retval
   1 : Fehler bei der Ausf�hrung des Befehls
   \retval
   2: Kommunikationsfehler
   
   <b>Zugriff:</b><br>
   [X] �ffentlich / [ ] Privat
   
   */

   /*~E:A108*/
   /*~A:109*/
   /*~+:Variablendeklarationen*/
   /*~T*/
   char chError;
   unsigned long ulTimeout;
   char szString[40];
   GLOBAL_UNIVALUE_SHORT *pUniValue;
   /*~E:A109*/
   /*~A:110*/
   /*~+:Variableninitialsierungen*/
   /*~T*/
   pUniValue = pValue;
   chError = 0;
   ulTimeout = SYSTEMTIME + 2000;	// 2000ms Timeout
   /*~E:A110*/
   /*~U:111*/
   /*~-2*/
   do
   {
      /*~T*/
      sprintf(szString,"iGSV %bd",byWhat2Get);
      /*~T*/
      chError = Communication_SendSPICommand(szString);
      /*~I:112*/
      if (!chError)
      /*~-1*/
      {
         /*~I:113*/
         if (!Communication_GetString(szString))
         /*~-1*/
         {
            /*~I:114*/
            if (!strcmp(szString,"NAV"))
            /*~-1*/
            {
               /*~T*/
               // Es liegt noch kein Wert vor
               /*~T*/
               chError = 0x01;
               /*~T*/
               // mal ein wenig warten
               System_Wait(30);
            /*~-1*/
            }
            /*~O:I114*/
            /*~-2*/
            else
            {
               /*~C:115*/
               switch (byWhat2Get)
               /*~-1*/
               {
                  /*~F:116*/
                  case COMMUNICATION_CHECKLIMIT_ZEROPOINTCHECK:
                  case COMMUNICATION_CHECKLIMIT_MAX_DEVIATION:
                  case COMMUNICATION_CHECKLIMIT_MAX_DRIFT:
                  case COMMUNICATION_MOTION_LIMIT: 
                  /*~-1*/
                  {
                     /*~T*/
                     pUniValue->fFloat = atof(szString);
                     /*~T*/
                     return 0;
                  /*~-1*/
                  }
                  /*~E:F116*/
                  /*~F:117*/
                  case COMMUNICATION_FILTER_DEPTH:
                  case COMMUNICATION_FILTER_WIDTH:
                  case COMMUNICATION_LOADCELL:
                  case COMMUNICATION_NUMBER_OF_MEASUREMENTS:
                  case COMMUNICATION_TIME_HYSTERESIS:
                  case COMMUNICATION_MOTION_FILTER:
                  case COMMUNICATION_COMPENSATION_STATE:
                  case COMMUNICATION_E_COMPENSATION_STATE:
                  case COMMUNICATION_CURRENTINTERFACE_FEEDBACK_STATE:
                  case COMMUNICATION_CHECKSUM_ERROR:
                  case COMMUNICATION_RS232_BAUDRATE:

                  /*~-1*/
                  {
                     /*~T*/
                     pUniValue->nLong = atol(szString);
                     /*~T*/
                     return 0;
                  /*~-1*/
                  }
                  /*~E:F117*/
                  /*~O:C115*/
                  /*~-2*/
                  default:
                  {
                     /*~T*/
                     return 5;
                  /*~-1*/
                  }
               /*~-1*/
               }
               /*~E:C115*/
            /*~-1*/
            }
            /*~E:I114*/
         /*~-1*/
         }
         /*~O:I113*/
         /*~-2*/
         else
         {
            /*~T*/
            chError = 0x03;
         /*~-1*/
         }
         /*~E:I113*/
      /*~-1*/
      }
      /*~E:I112*/
   /*~-1*/
   }
   /*~O:U111*/
   while ((chError)&&(ulTimeout > SYSTEMTIME));
   /*~E:U111*/
   /*~T*/
   return 5;	///< entspricht E005
/*~-1*/
}
/*~E:F107*/
/*~E:A106*/
/*~-1*/
#endif
/*~E:I105*/
/*~A:118*/
/*~+:unsigned char		Communication_GetSPIValue(unsigned char byWhat2Get,void *pValue)*/
/*~F:119*/
unsigned char Communication_GetSPIValue(unsigned char byWhat2Get,void *pValue)
/*~-1*/
{
   /*~A:120*/
   /*~+:Beschreibung*/
   /*~T*/
   /*!
   \fn char Communication_GetResponse(unsigned char chLine2Send,unsigned char chAnswertExpected)
   
   <b>Beschreibung:</b><br>
   Kanal 0 erfragt den Status der Befehlsausf�hrung des Kanal 1.
   
   \param
   ./.
   
   \return
   Status der Befehlsausf�hrung des Kanal 1.
   
   \retval
   0 : Alles okay
   \retval
   1 : Fehler bei der Ausf�hrung des Befehls
   \retval
   2: Kommunikationsfehler
   
   <b>Zugriff:</b><br>
   [X] �ffentlich / [ ] Privat
   
   */

   /*~E:A120*/
   /*~A:121*/
   /*~+:Variablendeklarationen*/
   /*~T*/
   char chError;
   unsigned char byCounter = 0;
   unsigned long ulTimeout;
   char szString[40];
   GLOBAL_UNIVALUE_SHORT *pUniValue;
   /*~E:A121*/
   /*~A:122*/
   /*~+:Variableninitialsierungen*/
   /*~T*/
   pUniValue = pValue;
   chError = 0;
   ulTimeout = SYSTEMTIME + 2000;	// 2000ms Timeout
   byCounter = 0;
   /*~E:A122*/
   /*~U:123*/
   /*~-2*/
   do
   {
      /*~T*/
      sprintf(szString,"iGSV %bd",byWhat2Get);
      /*~T*/
      chError = Communication_SendSPICommand(szString);
      /*~I:124*/
      if (!chError)
      /*~-1*/
      {
         /*~T*/
         memset(szString,0,40);
         /*~I:125*/
         if (!Communication_GetString(szString))
         /*~-1*/
         {
            /*~I:126*/
            if (!strcmp(szString,"NAV"))
            /*~-1*/
            {
               /*~T*/
               // Es liegt noch kein Wert vor
               /*~T*/
               chError = 0x01;
               /*~T*/
               // mal ein wenig warten
               System_Wait(100);
            /*~-1*/
            }
            /*~O:I126*/
            /*~-2*/
            else
            {
               /*~C:127*/
               switch (byWhat2Get)
               /*~-1*/
               {
                  /*~F:128*/
                  case COMMUNICATION_CHECKLIMIT_ZEROPOINTCHECK:
                  case COMMUNICATION_CHECKLIMIT_MAX_DEVIATION:
                  case COMMUNICATION_CHECKLIMIT_MAX_DRIFT:
                  case COMMUNICATION_MOTION_LIMIT: 
                  /*~-1*/
                  {
                     /*~T*/
                     pUniValue->fFloat = atof(szString);
                     /*~T*/
                     return 0;
                  /*~-1*/
                  }
                  /*~E:F128*/
                  /*~F:129*/
                  case COMMUNICATION_FILTER_DEPTH:
                  case COMMUNICATION_FILTER_WIDTH:
                  case COMMUNICATION_LOADCELL:
                  case COMMUNICATION_NUMBER_OF_MEASUREMENTS:
                  case COMMUNICATION_TIME_HYSTERESIS:
                  case COMMUNICATION_MOTION_FILTER:
                  case COMMUNICATION_COMPENSATION_STATE:
                  case COMMUNICATION_E_COMPENSATION_STATE:
                  case COMMUNICATION_CURRENTINTERFACE_FEEDBACK_STATE:
                  case COMMUNICATION_CHECKSUM_ERROR:
                  case COMMUNICATION_RS232_BAUDRATE:

                  /*~-1*/
                  {
                     /*~T*/
                     pUniValue->nLong = atol(szString);
                     /*~T*/
                     return 0;
                  /*~-1*/
                  }
                  /*~E:F129*/
                  /*~O:C127*/
                  /*~-2*/
                  default:
                  {
                     /*~T*/
                     return 5;
                  /*~-1*/
                  }
               /*~-1*/
               }
               /*~E:C127*/
            /*~-1*/
            }
            /*~E:I126*/
         /*~-1*/
         }
         /*~O:I125*/
         /*~-2*/
         else
         {
            /*~T*/
            chError = 0x03;
         /*~-1*/
         }
         /*~E:I125*/
      /*~-1*/
      }
      /*~O:I124*/
      /*~-2*/
      else
      {
         /*~T*/
         ADuC836_TimerDelay(100);
      /*~-1*/
      }
      /*~E:I124*/
   /*~-1*/
   }
   /*~O:U123*/
   while ((chError)&&(byCounter++ < 5));
   /*~E:U123*/
   /*~T*/
   return 5;	///< entspricht E005
/*~-1*/
}
/*~E:F119*/
/*~E:A118*/
/*~-1*/
#endif
/*~E:I94*/
/*~A:130*/
/*~+:char 			Communication_GetString(unsigned char *pchString)	// �ber SPI-SChnittstelle*/
/*~F:131*/
char Communication_GetString(unsigned char *pchString)
/*~-1*/
{
   /*~A:132*/
   /*~+:Variablendeklarationen*/
   /*~T*/
   char chRetVal;
   /*~E:A132*/
   /*~A:133*/
   /*~+:Variableninitialisierungen*/
   /*~T*/
   chRetVal = 1;
   /*~E:A133*/
   /*~I:134*/
   if (!ADuC836_SPIWait4Response(SYSTEM_TIMEOUT_SPI))
   /*~-1*/
   {
      /*~T*/
      Communication_GetRecBuffer(COMMUNICATION_SPI,pchString);
      /*~T*/
      return 0;
   /*~-1*/
   }
   /*~O:I134*/
   /*~-2*/
   else
   {
      /*~T*/
      return 1;
   /*~-1*/
   }
   /*~E:I134*/
/*~-1*/
}
/*~E:F131*/
/*~E:A130*/
/*~A:135*/
/*~+:long 			Communication_GetStringParameter(unsigned char chWhichParameter)*/
/*~F:136*/
char* Communication_GetStringParameter(unsigned char chWhichParameter)
/*~-1*/
{
   /*~A:137*/
   /*~+:Beschreibung*/
   /*~T*/
   /*!
   \fn long Communication_GetLongParameter(unsigned char chWhichParameter)
   
   <b>Beschreibung:</b><br>
   Bestimmung des Long-Wertes eines Parameters im aktuellen Kommandostring.
   
   \param
   chWhichParameter: Nummer des Parameters, dessen Wert zur�ckgeliefert werden soll.
   
   \return
   Long-Wert des angew�hlten Parameters.
   
   <b>Zugriff:</b><br>
   [X] �ffentlich / [ ] Privat
   
   \ref
   ExamplePage_Kommunikation "Kommunikationroutinen"
   */

   /*~E:A137*/
   /*~T*/
   return pCommunicationCommand->Parameter[chWhichParameter].szString;
/*~-1*/
}
/*~E:F136*/
/*~E:A135*/
/*~A:138*/
/*~+:void			Communication_IncrementSPIFaultCounter(void)*/
/*~F:139*/
void Communication_IncrementSPIFaultCounter(void)
/*~-1*/
{
   /*~I:140*/
#ifdef SYSTEM_CND_DISABLE_SPI_COMMUNICATION_AT_FAULTS
   /*~I:141*/
   if (CommunicationControl.byDisableSPICommunication < 2)
   /*~-1*/
   {
      /*~T*/
      // SPI-Kommunikation ist noch freigegeben
      /*~T*/
      CommunicationControl.byResetRepliesDueToSPIFaults++;
      /*~A:142*/
      /*~+:Z�hlerstand speichern*/
      /*~T*/
      // Z�hlerstand speichern
      Save_Parameter(LOAD_SAVE_SPI_FAULT_COUNTER,&CommunicationControl.byResetRepliesDueToSPIFaults,1);
      /*~E:A142*/
      /*~I:143*/
      if (CommunicationControl.byResetRepliesDueToSPIFaults > COMMUNICATION_MAX_SPI_COMMUNICATION_REPLIES)
      /*~-1*/
      {
         /*~T*/
         // Es gibt keine Hoffnung mehr, dass die Kommunikation nach einem Reset wieder zum Laufen kommt
         /*~T*/
         CommunicationControl.byDisableSPICommunication = 2;
         /*~A:144*/
         /*~+:Sicherheitsfunktion aufrufen*/
         /*~T*/
         // Sicherheitsfunktion aufrufen
         Diagnosis_SecurityInternalCommunication(SYTEM_ERROR_INTERNAL_COMMUNICATION);
         /*~E:A144*/
      /*~-1*/
      }
      /*~O:I143*/
      /*~-2*/
      else
      {
         /*~T*/
         // Es sind noch nicht gen�gend Wiederholungen erfolgt - es gibt noch Hoffnung
         /*~T*/
         CommunicationControl.byDisableSPICommunication = 1;
         /*~I:145*/
#ifdef MOF

         /*~A:146*/
         /*~+:ausgeklammert seit Version V1.010*/
         /*~F:147*/
         /* ausgeklammert seit Version V1.010 - Bei hohem Datenaufkommen �ber die RS232 kommt es immer wieder zu Fehlers bei der SPI-�bertragung. Diese versuchte ihrerseits mit den nachfolgenden Zeilen einen Reset auszuf�hren um erneut in Gang zu kommen. Das hatte zur Auswirkung, dass die RS232-Kommunikation ins Stocken geriet - teilweise sogar Daten verlor. Daher wird ab sofort auf diese Option verzichtet */
         /*~-1*/
         {
            /*~I:148*/
            if (!CommunicationControl.byResetInhibitFlag)
            /*~-1*/
            {
               /*~T*/
               // Sytem zur�cksetzen
               System_Reset();
            /*~-1*/
            }
            /*~E:I148*/
         /*~-1*/
         }
         /*~E:F147*/
         /*~E:A146*/
         /*~-1*/
#endif
         /*~E:I145*/
      /*~-1*/
      }
      /*~E:I143*/
   /*~-1*/
   }
   /*~O:I141*/
   /*~-2*/
   else
   {
      /*~T*/
      // SPI-Kommunikation ist wegen wiederholten Kommunikationsproblemen gesperrt worden.
   /*~-1*/
   }
   /*~E:I141*/
   /*~-1*/
#endif
   /*~E:I140*/
/*~-1*/
}
/*~E:F139*/
/*~E:A138*/
/*~K*/
/*~+:/~* Ge�ndert am 09.02.2022 *~/*/
/*~A:149*/
/*~+:void 			Communication_Ini(unsigned char chSeparator,unsigned char byMode)*/
/*~F:150*/
void Communication_Ini(unsigned char chSeparator,unsigned char byMode)
/*~-1*/
{
   /*~A:151*/
   /*~+:Variablendeklarationen*/
   /*~T*/
   ///< Variablendeklarationen
   unsigned long ulBaudrate;
   /*~E:A151*/
   /*~A:152*/
   /*~+:Variableninitialisierungen*/
   /*~T*/
   ///< Variableninitialisierungen

   /*~E:A152*/
   /*~A:153*/
   /*~+:Beschreibung*/
   /*~T*/
   /*!
   \fn unsigned char Communication_Ini(unsigned int uRecBufferSize, unsigned int uTransBufferSize)
   
   <b>Beschreibung:</b><br>
   Initialisierungsroutine der Kommunikation. Hierbei wird die Gr��e des Empfangspuffers und des Sendepuffers festgelegt.
    
   \param
   uRecBufferSize: Gr��e des Empfangspuffers.
   
   \param
   uTransBufferSize: Gr��e des Sendepuffers.
   
   \return
   Status der Funktionsausf�hrung.
   
   \retval
   0: Alles okay.
   
   \retval
   1: Nicht gen�gend Speicherplatz f�r dynamische Variablen vorhanden.
   
   <b>Zugriff:</b><br>
   [X] �ffentlich / [ ] Privat
   
   \ref
   ExamplePage_Kommunikation "Kommunikationroutinen"
   */

   /*~E:A153*/
   /*~A:154*/
   /*~+:SPI-Schnittstelle initialisieren*/
   /*~I:155*/
#ifdef CHANNEL_0
   /*~A:156*/
   /*~+:SPI-Schnittstelle von Kanal 0 initialisieren*/
   /*~K*/
   /*~+:/~* Ge�ndert am 09.02.2022 *~/*/
   /*~T*/
   ADuC836_SPIDefaultIni(1,&CommunicationControl.chRecBuffer[COMMUNICATION_SPI][0],RECBUFFER_SIZE);	// Master-Mode
   /*~K*/
   /*~+:/~* Ende - Ge�ndert am 09.02.2022 *~/*/
   /*~E:A156*/
   /*~-1*/
#endif
   /*~E:I155*/
   /*~I:157*/
#ifdef CHANNEL_1 
   /*~A:158*/
   /*~+:SPI-Schnittstelle von Kanal 1 initialisieren*/
   /*~K*/
   /*~+:/~* Ge�ndert am 09.02.2022 *~/*/
   /*~T*/
   ADuC836_SPIDefaultIni(0,&CommunicationControl.chRecBuffer[COMMUNICATION_SPI][0],RECBUFFER_SIZE);	// Slave-Mode
   /*~K*/
   /*~+:/~* Ende - Ge�ndert am 09.02.2022 *~/*/
   /*~E:A158*/
   /*~-1*/
#endif
   /*~E:I157*/
   /*~E:A154*/
   /*~A:159*/
   /*~+:RS232-Schnittstelle initialisieren*/
   /*~I:160*/
#ifdef SYSTEM_CND_VARIABLE_BAUDRATE 
   /*~A:161*/
   /*~+:Schnittstelle mit variabler Baudrate setzen*/
   /*~I:162*/
   if (byMode == BYDEFAULT)
   /*~-1*/
   {
      /*~A:163*/
      /*~+:Per Default wird die Kommunikationsgeschwindigkeit auf 9600 Baud gesetzt*/
      /*~T*/
      ADuC836_RS232Ini(8,9600,&CommunicationControl.chRecBuffer[COMMUNICATION_RS232][0],RECBUFFER_SIZE,&CommunicationControl.chTransBuffer[COMMUNICATION_RS232],1);
      /*~E:A163*/
   /*~-1*/
   }
   /*~O:I162*/
   /*~-2*/
   else
   {
      /*~A:164*/
      /*~+:Kommunikationsgeschwindigkeit aus Eeprom auslesenund setzen*/
      /*~T*/
      Load_Parameter(LOAD_SAVE_RS232_BAUDRATE,&ulBaudrate,4);
      /*~T*/
      ADuC836_RS232Ini(8,ulBaudrate,&CommunicationControl.chRecBuffer[COMMUNICATION_RS232][0],RECBUFFER_SIZE,&CommunicationControl.chTransBuffer[COMMUNICATION_RS232],1);
      /*~E:A164*/
   /*~-1*/
   }
   /*~E:I162*/
   /*~E:A161*/
   /*~O:I160*/
   /*~-1*/
#else
   /*~T*/
   ADuC836_RS232Ini(8,9600,&CommunicationControl.chRecBuffer[COMMUNICATION_RS232][0],RECBUFFER_SIZE,&CommunicationControl.chTransBuffer[COMMUNICATION_RS232],1);
   /*~-1*/
#endif
   /*~E:I160*/
   /*~E:A159*/
   /*~T*/
   // Struktur f�r den Empfang zur�cksetzen
   memset(&CommunicationControl,0,sizeof(COMMUNICATION_CONTROL));

   CommunicationControl.chSeparator = chSeparator;

   /*~K*/
   /*~+:/~* Ge�ndert am 09.02.2022 *~/*/
   /*~A:165*/
   /*~+:RS232-Freigabe auslesen*/
   /*~C:166*/
   switch (byMode)
   /*~-1*/
   {
      /*~A:167*/
      /*~+:Initialisierung mit Defaultwerten.*/
      /*~F:168*/
      case 0:		// Initialisierung mit Defaultwerten
      /*~-1*/
      {
         /*~A:169*/
         /*~+:RS232-Freigabe setzen*/
         /*~T*/
         /*#LJ:Communication_EnableCommunication=63*/
         // RS232-Freigabe setzen
         Communication_EnableCommunication(1);
         /*~E:A169*/
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F168*/
      /*~E:A167*/
      /*~A:170*/
      /*~+:Initialisierung mit abgespeicherten Werten.*/
      /*~F:171*/
      case 1:		// Initialisierung mit abgespeicherten Werten
      /*~-1*/
      {
         /*~A:172*/
         /*~+:RS232-Freigabe auslesen*/
         /*~T*/
         // RS232-Freigabe auslesen
         Load_Parameter(LOAD_SAVE_RS232_DISABLE_CODE, &CommunicationControl.ulCommunicationDisable, 4);
         /*~E:A172*/
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F171*/
      /*~E:A170*/
   /*~-1*/
   }
   /*~E:C166*/
   /*~E:A165*/
   /*~K*/
   /*~+:/~* Ende - Ge�ndert am 09.02.2022 *~/*/
   /*~I:173*/
#ifdef MIT_CRC16
   /*~T*/
   Communication_EnableCRC16(TRUE);
   /*~O:I173*/
   /*~-1*/
#else
   /*~T*/
   // Communication_EnableCRC16(FALSE);
   /*~-1*/
#endif
   /*~E:I173*/
   /*~A:174*/
   /*~+:Z�hlerstand der ausgef�hrten Resets aufgrund von SPI-Kommunikationsproblemen laden*/
   /*~A:175*/
   /*~+:Mit Abschaltung der SPI-Kommunikation bei Ausfall der SPI-Schnittstelle*/
   /*~I:176*/
#ifdef SYSTEM_CND_DISABLE_SPI_COMMUNICATION_AT_FAULTS 
   /*~T*/
   // Z�hlerstand der ausgef�hrten Resets aufgrund von SPI-Kommunikationsproblemen laden
   Load_Parameter(LOAD_SAVE_SPI_FAULT_COUNTER,&CommunicationControl.byResetRepliesDueToSPIFaults,1);
   /*~I:177*/
   if (CommunicationControl.byResetRepliesDueToSPIFaults == 0)
   /*~-1*/
   {
      /*~T*/
      CommunicationControl.byDisableSPICommunication = 0;
   /*~-1*/
   }
   /*~O:I177*/
   /*~-2*/
   else
   {
      /*~I:178*/
      if (CommunicationControl.byResetRepliesDueToSPIFaults <= COMMUNICATION_MAX_SPI_COMMUNICATION_REPLIES)
      /*~-1*/
      {
         /*~T*/
         CommunicationControl.byDisableSPICommunication = 1;
      /*~-1*/
      }
      /*~O:I178*/
      /*~-2*/
      else
      {
         /*~T*/
         CommunicationControl.byDisableSPICommunication = 2;
      /*~-1*/
      }
      /*~E:I178*/
   /*~-1*/
   }
   /*~E:I177*/
   /*~-1*/
#endif
   /*~E:I176*/
   /*~E:A175*/
   /*~E:A174*/
   /*~A:179*/
   /*~+:Sperrflag f�r Reset bei SPI-Kommunikationsproblemen setzen/l�schen*/
   /*~I:180*/
   if (byMode == BYDEFAULT)
   /*~-1*/
   {
      /*~A:181*/
      /*~+:Per Default wird das Sperrflag gesetzt*/
      /*~T*/
      Communication_SetResetInhibitFlag(1);
      /*~E:A181*/
   /*~-1*/
   }
   /*~O:I180*/
   /*~-2*/
   else
   {
      /*~A:182*/
      /*~+:Sperrflag aus Eeprom auslesen*/
      /*~T*/
      Load_Parameter(LOAD_SAVE_FLAG_DONOT_RESET,&CommunicationControl.byResetInhibitFlag,1);
      /*~I:183*/
      if (CommunicationControl.byResetInhibitFlag > 1)
      /*~-1*/
      {
         /*~T*/
         Communication_SetResetInhibitFlag(1);
      /*~-1*/
      }
      /*~E:I183*/
      /*~E:A182*/
   /*~-1*/
   }
   /*~E:I180*/
   /*~E:A179*/
   /*~A:184*/
   /*~+:Steuerleitungen initialisieren*/
   /*~T*/
   // Portpins zur Freigabe der RS232-Schnittstelle initialisieren

   COMMUNICATION_INSTUCTIONDECODER_RELEASE_LINE = FALSE;
   COMMUNICATION_INSTUCTIONDECODER_STATE_LINE = TRUE;
   /*~E:A184*/
   /*~A:185*/
   /*~+:Test der SPI-Schnittstelle abschalten (oder per #define auch einschalten) und Variablen initialisieren*/
   /*~I:186*/
#ifdef DEVELOPMENT_SW
   /*~T*/
   CommunicationControl.bTestSPI = 0;
   /*~T*/
   CommunicationControl.ulSPICounter = 0;
   /*~I:187*/
#ifdef CHANNEL_0
   /*~T*/
   CommunicationControl.ulSPIE1Counter = 0;

   /*~-1*/
#endif
   /*~E:I187*/
   /*~-1*/
#endif
   /*~E:I186*/
   /*~E:A185*/
/*~-1*/
}
/*~E:F150*/
/*~E:A149*/
/*~K*/
/*~+:/~* Ende - Ge�ndert am 09.02.2022 *~/*/
/*~A:188*/
/*~+:unsigned char* 		Communication_Interpret(unsigned char *szString)*/
/*~F:189*/
unsigned char* Communication_Interpret(unsigned char *szString)
/*~-1*/
{
   /*~A:190*/
   /*~+:Variablendeklarationen*/
   /*~T*/
   unsigned char 	chPointer;
   unsigned char 	chParameterPointer;
   unsigned char 	chSeparatorFound;
   unsigned char 	chBytes2Move;
   /*~E:A190*/
   /*~A:191*/
   /*~+:Variableninitialisierungen*/
   /*~T*/
   chPointer = chParameterPointer = chSeparatorFound = 0;

   /*~E:A191*/
   /*~T*/
   (char*)pCommunicationCommand = szString;
   /*~L:192*/
   while ((*szString)&&(chParameterPointer < 4))
   /*~-1*/
   {
      /*~T*/
      chPointer++;
      /*~I:193*/
      if (*szString == CommunicationControl.chSeparator)
      /*~-1*/
      {
         /*~I:194*/
         if (!chSeparatorFound)
         /*~-1*/
         {
            /*~T*/
            chSeparatorFound = 1;
            *szString = 0x00;

            /*~I:195*/
            if ((chPointer > 1)&&(*(szString + 1))&&(*(szString + 1) != 0x20))
            /*~-1*/
            {
               /*~I:196*/
               if (!chParameterPointer)
               /*~-1*/
               {
                  /*~T*/
                  // chBytes2Move = sizeof(COMMUNICATION_COMMAND) - COMMANDBUFFER_SIZE + chPointer;

                  chBytes2Move = 4 * GLOBAL_STRINGSIZE + 3;// 3 f�r Trennzeichen 
                  /*~T*/
                  memmove((char*)pCommunicationCommand->Parameter,szString + 1,chBytes2Move);
                  /*~T*/
                  szString = (char*)pCommunicationCommand->Parameter;
                  szString--; 
                  /*~T*/
                  chParameterPointer++;
                  chPointer = 0;
               /*~-1*/
               }
               /*~O:I196*/
               /*~-2*/
               else
               {
                  /*~T*/
                  // chBytes2Move = sizeof(COMMUNICATION_COMMAND) - COMMANDBUFFER_SIZE - GLOBAL_STRINGSIZE * (chParameterPointer - 1) - chPointer;

                  chBytes2Move = (4 - chParameterPointer) * GLOBAL_STRINGSIZE + 3 - chParameterPointer;
                  /*~T*/
                  // memmove((char*)pCommunicationCommand + COMMANDBUFFER_SIZE + GLOBAL_STRINGSIZE * (chParameterPointer),szString + 1,chBytes2Move);

                  memmove((char*)&pCommunicationCommand->Parameter[chParameterPointer],szString + 1,chBytes2Move);
                  /*~T*/
                  // szString = (char*)pCommunicationCommand + COMMANDBUFFER_SIZE  + GLOBAL_STRINGSIZE * chParameterPointer - 1; 

                  szString = (char*)&pCommunicationCommand->Parameter[chParameterPointer];
                  szString--;
                  /*~T*/
                  chParameterPointer++;
                  chPointer = 0;
               /*~-1*/
               }
               /*~E:I196*/
            /*~-1*/
            }
            /*~E:I195*/
         /*~-1*/
         }
         /*~E:I194*/
      /*~-1*/
      }
      /*~O:I193*/
      /*~-2*/
      else
      {
         /*~T*/
         chSeparatorFound = 0;
      /*~-1*/
      }
      /*~E:I193*/
      /*~T*/
      szString++;

   /*~-1*/
   }
   /*~E:L192*/
   /*~T*/
   pCommunicationCommand->byParametersFound = chParameterPointer;
   /*~T*/
   return pCommunicationCommand->achCommand;
/*~-1*/
}
/*~E:F189*/
/*~E:A188*/
/*~K*/
/*~+:/~* Ge�ndert am 09.02.2022 *~/*/
/*~A:197*/
/*~+:unsigned char 		Communication_IsCommunicationEnabled(void)*/
/*~F:198*/
unsigned char Communication_IsCommunicationEnabled(void)
/*~-1*/
{
   /*~A:199*/
   /*~+:Variablendeklarationen*/
   /*~T*/
   unsigned char byRetVal;
   /*~E:A199*/
   /*~A:200*/
   /*~+:Variableninitialisierungen*/
   /*~T*/

   /*~E:A200*/
   /*~T*/
   byRetVal = (CommunicationControl.ulCommunicationDisable != COMMUNICATION_DISABLE_CODE);
   /*~T*/
   return(byRetVal);
/*~-1*/
}
/*~E:F198*/
/*~E:A197*/
/*~K*/
/*~+:/~* Ende - Ge�ndert am 09.02.2022 *~/*/
/*~A:201*/
/*~+:char 			Communication_IsESC(void)*/
/*~F:202*/
char Communication_IsESC(void)
/*~-1*/
{
   /*~T*/
   return ADuC836_RS232IsEscape();
/*~-1*/
}
/*~E:F202*/
/*~E:A201*/
/*~A:203*/
/*~+:char 			Communication_IsOK(void)*/
/*~F:204*/
char Communication_IsOK(void)
/*~-1*/
{
   /*~A:205*/
   /*~+:Variablendeklarationen*/
   /*~T*/
   unsigned char byRecBuffer[40];
   /*~E:A205*/
   /*~A:206*/
   /*~+:Variableninitialisierungen*/
   /*~T*/

   /*~E:A206*/
   /*~I:207*/
   if (!Communication_GetString(byRecBuffer))
   /*~-1*/
   {
      /*~I:208*/
      if (!strcmp(byRecBuffer,"OK"))
      /*~-1*/
      {
         /*~T*/
         // Alles okay
         return 1;
      /*~-1*/
      }
      /*~O:I208*/
      /*~-2*/
      else
      {
         /*~T*/
         // Keine Best�tigung erhalten
         return 0;
      /*~-1*/
      }
      /*~E:I208*/
   /*~-1*/
   }
   /*~O:I207*/
   /*~-2*/
   else
   {
      /*~T*/
      return 0;
   /*~-1*/
   }
   /*~E:I207*/
/*~-1*/
}
/*~E:F204*/
/*~E:A203*/
/*~A:209*/
/*~+:unsigned char 	Communication_IsSPICommuncationDisabled(void)*/
/*~F:210*/
unsigned char Communication_IsSPICommuncationDisabled(void)
/*~-1*/
{
   /*~I:211*/
#ifdef SYSTEM_CND_DISABLE_SPI_COMMUNICATION_AT_FAULTS
   /*~I:212*/
   if (CommunicationControl.byDisableSPICommunication < 2)
   /*~-1*/
   {
      /*~T*/
      return FALSE;
   /*~-1*/
   }
   /*~O:I212*/
   /*~-2*/
   else
   {
      /*~T*/
      return TRUE;
   /*~-1*/
   }
   /*~E:I212*/
   /*~I:213*/
#ifdef MOF
   // bis vor Version V1.006
   /*~T*/
   return CommunicationControl.byDisableSPICommunication;
   /*~-1*/
#endif
   /*~E:I213*/
   /*~O:I211*/
   /*~-1*/
#else
   /*~T*/
   return FALSE;
   /*~-1*/
#endif
   /*~E:I211*/
/*~-1*/
}
/*~E:F210*/
/*~E:A209*/
/*~A:214*/
/*~+:void 			Communication_SendCR(unsigned char chNbCRs)*/
/*~F:215*/
void Communication_SendCR(unsigned char chNbCRs)
/*~-1*/
{
   /*~A:216*/
   /*~+:Variablendeklarationen*/
   /*~T*/
   char szCRs2Send[80];
   /*~E:A216*/
   /*~A:217*/
   /*~+:Variableninitialisierungen*/
   /*~T*/

   /*~E:A217*/
   /*~I:218*/
   if (chNbCRs)
   /*~-1*/
   {
      /*~T*/
      szCRs2Send[0] = 0;
      /*~L:219*/
      while (chNbCRs--)
      /*~-1*/
      {
         /*~T*/
         strcat(&szCRs2Send,"\r\n");
      /*~-1*/
      }
      /*~E:L219*/
      /*~T*/
      Communication_SendString(COMMUNICATION_RS232,szCRs2Send,0,0);
   /*~-1*/
   }
   /*~E:I218*/
/*~-1*/
}
/*~E:F215*/
/*~E:A214*/
/*~A:220*/
/*~+:void 			Communication_SendFloat(unsigned char chLine2Send,long lText2Send,float fValue,char chPrecision,unsigned char chCRBefore,unsigned char chCRAfter)*/
/*~F:221*/
void Communication_SendFloat(unsigned char chLine2Send,long lText2Send,float fValue,char chPrecision,unsigned char chCRBefore,unsigned char chCRAfter)
/*~-1*/
{
   /*~A:222*/
   /*~+:Beschreibung*/
   /*~T*/
   /*!
   \fn void Communication_SendFloat(long lText2Send,float fValue,unsigned char chCRBefore,unsigned char chCRAfter)
   
   <b>Beschreibung:</b><br>
   Sendet einen Float-Wert.
   
   \param
   lText2Send: Textindex des Textes, welcher vor dem eigentlichen Wert ausgegeben werden soll. 
   
   \param
   lValue: Zu sendender Float-Wert.
   
   \param
   chCRBefore: Anzahl der Zeilenvorsch�be vor Ausgabe des Zahlenwertes.
   
   \param
   chCRAfter: Anzahl der Zeilenvorsch�be nach Ausgabe des Zahlenwertes.
   
   \return
   ./.
   
   <b>Zugriff:</b><br>
   [X] �ffentlich / [ ] Privat
   
   \ref
   ExamplePage_Kommunikation "Kommunikationroutinen"
   */

   /*~E:A222*/
   /*~A:223*/
   /*~+:Variablendeklarationen*/
   /*~T*/
   unsigned char szString2Send[16];
   /*~E:A223*/
   /*~A:224*/
   /*~+:Variableninitialisierungen*/
   /*~I:225*/
#ifdef CHANNEL_0
   /*~T*/
   chLine2Send = COMMUNICATION_RS232;
   /*~-1*/
#endif
   /*~E:I225*/
   /*~E:A224*/
   /*~C:226*/
   switch (chLine2Send)
   /*~-1*/
   {
      /*~A:227*/
      /*~+:COMMUNICATION_RS232*/
      /*~F:228*/
      case COMMUNICATION_RS232:
      /*~-1*/
      {
         /*~A:229*/
         /*~+:Variablendeklarationen*/
         /*~T*/
         char szFormat[6];
         char bOldETOStatus;
         /*~E:A229*/
         /*~A:230*/
         /*~+:Variableninitialisierungen*/
         /*~T*/

         /*~E:A230*/
         /*~I:231*/
         if (chPrecision >= 0)
         /*~-1*/
         {
            /*~T*/
            sprintf(szFormat,"%%.%bdf",chPrecision);
         /*~-1*/
         }
         /*~O:I231*/
         /*~-2*/
         else
         {
            /*~T*/
            strcpy(szFormat,"%f");
         /*~-1*/
         }
         /*~E:I231*/
         /*~I:232*/
         if (!SYSTEM_MRW_MANAGER)
         /*~-1*/
         {
            /*~I:233*/
            if (lText2Send)
            /*~-1*/
            {
               /*~T*/
               sprintf(szString2Send,"T%04ld",lText2Send);
               Communication_SendString(COMMUNICATION_RS232,szString2Send,chCRBefore,0);

               chCRBefore = 0;
            /*~-1*/
            }
            /*~E:I233*/
         /*~-1*/
         }
         /*~E:I232*/
         /*~T*/
         bOldETOStatus = ET0;
         ET0 = 0;	// Timer-Interrupt sperren, das es hier Probleme mit sprintf gibt

         sprintf(szString2Send,szFormat,fValue);

         ET0 = bOldETOStatus;	// Timer-Interrupt ggf. wieder zulassen
         /*~T*/
         Communication_SendString(COMMUNICATION_RS232,szString2Send,0,chCRAfter);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F228*/
      /*~E:A227*/
      /*~A:234*/
      /*~+:COMMUNICATION_SPI*/
      /*~F:235*/
      case COMMUNICATION_SPI:
      /*~-1*/
      {
         /*~T*/
         sprintf(szString2Send,"%f",fValue);

         Communication_SendString(COMMUNICATION_SPI,szString2Send,chCRBefore,chCRAfter);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F235*/
      /*~E:A234*/
   /*~-1*/
   }
   /*~E:C226*/
/*~-1*/
}
/*~E:F221*/
/*~E:A220*/
/*~A:236*/
/*~+:char 			Communication_SendLong(unsigned char chLine2Send,long lText2Send,long lValue,unsigned char chCRBefore,unsigned char chCRAfter)*/
/*~F:237*/
char Communication_SendLong(unsigned char chLine2Send,long lText2Send,long lValue,unsigned char chCRBefore,unsigned char chCRAfter)
/*~-1*/
{
   /*~A:238*/
   /*~+:Beschreibung*/
   /*~T*/
   /*!
   \fn void Communication_SendLong(long lText2Send,long lValue,unsigned char chCRBefore,unsigned char chCRAfter)
   
   <b>Beschreibung:</b><br>
   Sendet einen Long-Wert �ber die SPI-Schnittstelle.
   
   \param
   lText2Send: Textindex des Textes, welcher vor dem eigentlichen Wert ausgegeben werden soll. 
   
   \param
   lValue: Zu sendender Long-Wert.
   
   \param
   chCRBefore: Anzahl der Zeilenvorsch�be vor Ausgabe des Zahlenwertes.
   
   \param
   chCRAfter: Anzahl der Zeilenvorsch�be nach Ausgabe des Zahlenwertes.
   
   \return
   ./.
   
   <b>Zugriff:</b><br>
   [X] �ffentlich / [ ] Privat
   
   \ref
   ExamplePage_Kommunikation "Kommunikationroutinen"
   */

   /*~E:A238*/
   /*~A:239*/
   /*~+:Variablendeklarationen*/
   /*~T*/
   unsigned char szString2Send[16];
   /*~E:A239*/
   /*~A:240*/
   /*~+:Variableninitialisierungen*/
   /*~I:241*/
#ifdef CHANNEL_0
   /*~T*/
   chLine2Send = COMMUNICATION_RS232;
   /*~-1*/
#endif
   /*~E:I241*/
   /*~E:A240*/
   /*~C:242*/
   switch (chLine2Send)
   /*~-1*/
   {
      /*~A:243*/
      /*~+:COMMUNICATION_RS232*/
      /*~F:244*/
      case COMMUNICATION_RS232:
      /*~-1*/
      {
         /*~I:245*/
         if (!SYSTEM_MRW_MANAGER)
         /*~-1*/
         {
            /*~I:246*/
            if (lText2Send)
            /*~-1*/
            {
               /*~T*/
               sprintf(szString2Send,"T%04ld",lText2Send);
               Communication_SendString(COMMUNICATION_RS232,szString2Send,chCRBefore,0);

               sprintf(szString2Send,"%ld",lValue);
               return Communication_SendString(COMMUNICATION_RS232,szString2Send,0,chCRAfter);
            /*~-1*/
            }
            /*~E:I246*/
         /*~-1*/
         }
         /*~E:I245*/
         /*~T*/
         sprintf(szString2Send,"%ld",lValue);

         return Communication_SendString(COMMUNICATION_RS232,szString2Send,chCRBefore,chCRAfter);
      /*~-1*/
      }
      /*~E:F244*/
      /*~E:A243*/
      /*~A:247*/
      /*~+:COMMUNICATION_SPI*/
      /*~F:248*/
      case COMMUNICATION_SPI:
      /*~-1*/
      {
         /*~T*/
         sprintf(szString2Send,"%ld",lValue);

         return Communication_SendString(COMMUNICATION_SPI,szString2Send,chCRBefore,chCRAfter);
      /*~-1*/
      }
      /*~E:F248*/
      /*~E:A247*/
   /*~-1*/
   }
   /*~E:C242*/
/*~-1*/
}
/*~E:F237*/
/*~E:A236*/
/*~A:249*/
/*~+:char 			Communication_SendMessage(unsigned char chLine2Send,unsigned char chWhat2Send)*/
/*~F:250*/
char Communication_SendMessage(unsigned char chLine2Send,unsigned char chWhat2Send)
/*~-1*/
{
   /*~C:251*/
   switch (chWhat2Send)
   /*~-1*/
   {
      /*~F:252*/
      case COMMUNICATION_SHORT_ACK:
      /*~-1*/
      {
         /*~A:253*/
         /*~+:Variablendeklarationen*/
         /*~T*/
         char szString[2];
         /*~E:A253*/
         /*~A:254*/
         /*~+:Variableninitialisierungen*/
         /*~T*/
         szString[0] = 0x06;
         szString[1] = 0x00;
         /*~E:A254*/
         /*~T*/
         return Communication_SendString(chLine2Send,szString,0,0);
      /*~-1*/
      }
      /*~E:F252*/
      /*~F:255*/
      case COMMUNICATION_ACK:
      /*~-1*/
      {
         /*~T*/
         return Communication_SendString(chLine2Send,"ACK",0,0);
      /*~-1*/
      }
      /*~E:F255*/
      /*~F:256*/
      case COMMUNICATION_OK:
      /*~-1*/
      {
         /*~T*/
         return Communication_SendString(chLine2Send,"OK",0,0);
      /*~-1*/
      }
      /*~E:F256*/
      /*~F:257*/
      case COMMUNICATION_NOK:
      /*~-1*/
      {
         /*~T*/
         return Communication_SendString(chLine2Send,"NOK",0,0);
      /*~-1*/
      }
      /*~E:F257*/
      /*~F:258*/
      case COMMUNICATION_NAK:
      /*~-1*/
      {
         /*~T*/
         return Communication_SendString(chLine2Send,"NAK",0,0);
      /*~-1*/
      }
      /*~E:F258*/
   /*~-1*/
   }
   /*~E:C251*/
/*~-1*/
}
/*~E:F250*/
/*~E:A249*/
/*~A:259*/
/*~+:// ausgeklammert*/
/*~+:char 			Communication_SendMirror(unsigned char chLine2Send,unsigned char *szString)*/
/*~I:260*/
#ifdef MOF
/*~A:261*/
/*~+:char 			Communication_SendMirror(unsigned char chLine2Send,unsigned char *szString)*/
/*~F:262*/
char Communication_SendMirror(unsigned char chLine2Send,unsigned char *szString)
/*~-1*/
{
   /*~A:263*/
   /*~+:Beschreibung*/
   /*~T*/
   /*!
   \fn char Communication_SendMirror(unsigned char chLine2Send,unsigned char *szString)
   
   <b>Beschreibung:</b><br>
   Sendet die Spiegelung von szString.
   
   \param
   chLine2Send: Zielschnittstelle.
   
   \param
   szString: zu spiegelnder String.
   
   \return
   ./.
   
   <b>Zugriff:</b><br>
   [X] �ffentlich / [ ] Privat
   
   \ref
   ExamplePage_Kommunikation "Kommunikationroutinen"
   */

   /*~E:A263*/
   /*~A:264*/
   /*~+:Variablendeklarationen*/
   /*~T*/
   char byRetVal;
   char byMaxRetries;
   /*~E:A264*/
   /*~A:265*/
   /*~+:Variableninitialisierungen*/
   /*~T*/
   byMaxRetries = 1;
   /*~E:A265*/
   /*~C:266*/
   switch (chLine2Send)
   /*~-1*/
   {
      /*~A:267*/
      /*~+:COMMUNICATION_RS232*/
      /*~F:268*/
      case COMMUNICATION_RS232:
      /*~-1*/
      {
         /*~T*/
         sprintf(&CommunicationControl.chTransBuffer[COMMUNICATION_RS232],"%c,%s,%c",0x02,szString,0x20);
         /*~T*/
         // Ausgabe starten
         byRetVal = ADuC836_RS232Send(250);
         /*~T*/
         return byRetVal;
      /*~-1*/
      }
      /*~E:F268*/
      /*~E:A267*/
      /*~A:269*/
      /*~+:COMMUNICATION_SPI*/
      /*~F:270*/
      case COMMUNICATION_SPI:
      /*~-1*/
      {
         /*~T*/
         // Sendestring zusammensetzen
         sprintf(&CommunicationControl.chTransBuffer[COMMUNICATION_SPI],"%c,%s,%c",0x02,szString,0x20);
         /*~U:271*/
         /*~-2*/
         do
         {
            /*~T*/
            Watchdog();
            /*~T*/
            byRetVal = ADuC836_SPISendPtr(&CommunicationControl.chTransBuffer[COMMUNICATION_SPI],0);
         /*~-1*/
         }
         /*~O:U271*/
         while (byRetVal && --byMaxRetries);
         /*~E:U271*/
         /*~T*/
         return byRetVal;
      /*~-1*/
      }
      /*~E:F270*/
      /*~E:A269*/
   /*~-1*/
   }
   /*~E:C266*/
/*~-1*/
}
/*~E:F262*/
/*~E:A261*/
/*~-1*/
#endif
/*~E:I260*/
/*~E:A259*/
/*~A:272*/
/*~+:char 			Communication_SendNext(void)*/
/*~F:273*/
char Communication_SendNext(void)
/*~-1*/
{
   /*~A:274*/
   /*~+:Variablendeklarationen*/
   /*~T*/
   char chChar2Send;
   char chRetVal;
   static unsigned char bySendPointer = 0; 
   /*~E:A274*/
   /*~A:275*/
   /*~+:Variableninitialisierungen*/
   /*~T*/

   /*~E:A275*/
   /*~T*/
   chRetVal = 0;
   /*~T*/
   chChar2Send = CommunicationControl.chTransBuffer[COMMUNICATION_SPI][bySendPointer];
   /*~C:276*/
   switch (chChar2Send)
   /*~-1*/
   {
      /*~F:277*/
      case 0:
      /*~-1*/
      {
         /*~T*/
         chRetVal = 2;
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F277*/
      /*~F:278*/
      case 0x02:
      /*~-1*/
      {
         /*~T*/
         // Vorbereitungen f�r den anschlie�enden Empfang treffen
         ADuC836_SPIReleaseReception();
         /*~T*/
         ADuC836_SPISwitch2Mode(ADUC836_SPI_MASTER_MODE);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F278*/
      /*~F:279*/
      case 0x03:
      /*~-1*/
      {
         /*~T*/
         chRetVal = 1;

         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F279*/
   /*~-1*/
   }
   /*~E:C276*/
   /*~I:280*/
   if (chRetVal < 2)
   /*~-1*/
   {
      /*~I:281*/
      if (ADuC836_SPISendChar(chChar2Send) != 0)
      /*~-1*/
      {
         /*~T*/
         chRetVal = 3;

      /*~-1*/
      }
      /*~E:I281*/
      /*~T*/
      bySendPointer++;
   /*~-1*/
   }
   /*~E:I280*/
   /*~I:282*/
   if (chRetVal != 0)
   /*~-1*/
   {
      /*~T*/
      ADuC836_SPISwitch2Mode(ADUC836_SPI_SLAVE_MODE);
      /*~T*/
      bySendPointer = 0;
   /*~-1*/
   }
   /*~E:I282*/
   /*~T*/
   return chRetVal;
/*~-1*/
}
/*~E:F273*/
/*~E:A272*/
/*~A:283*/
/*~+:char 			Communication_SendRawString(unsigned char chLine2Send,unsigned char *szString)*/
/*~F:284*/
char Communication_SendRawString(unsigned char chLine2Send,unsigned char *szString)
/*~-1*/
{
   /*~A:285*/
   /*~+:Beschreibung*/
   /*~T*/
   /*!
   \fn void Communication_SendString(unsigned char *szString,unsigned char chCRBefore,unsigned char chCRAfter)
   
   <b>Beschreibung:</b><br>
   Sendet einen String aus.
   
   \param
   szString: zu sendender String.
   
   \param
   chCRBefore: Anzahl der Zeilenvorsch�be vor Ausgabe des Textes .
   
   \param
   chCRAfter: Anzahl der Zeilenvorsch�be nach Ausgabe des Textes .
   
   \return
   ./.
   
   <b>Zugriff:</b><br>
   [X] �ffentlich / [ ] Privat
   
   \ref
   ExamplePage_Kommunikation "Kommunikationroutinen"
   */

   /*~E:A285*/
   /*~A:286*/
   /*~+:Variablendeklarationen*/
   /*~T*/
   char byRetVal;
   char byMaxRetries;

   /*~E:A286*/
   /*~A:287*/
   /*~+:Variableninitialisierungen*/
   /*~T*/
   byMaxRetries = 1;
   /*~E:A287*/
   /*~C:288*/
   switch (chLine2Send)
   /*~-1*/
   {
      /*~A:289*/
      /*~+:COMMUNICATION_RS232*/
      /*~F:290*/
      case COMMUNICATION_RS232:
      /*~-1*/
      {
         /*~T*/
         sprintf(&CommunicationControl.chTransBuffer[COMMUNICATION_RS232],"%s",szString);
         /*~T*/
         // Ausgabe starten
         byRetVal = ADuC836_RS232Send(250);
         /*~T*/
         return byRetVal;
      /*~-1*/
      }
      /*~E:F290*/
      /*~E:A289*/
      /*~A:291*/
      /*~+:COMMUNICATION_SPI*/
      /*~F:292*/
      case COMMUNICATION_SPI:
      /*~-1*/
      {
         /*~U:293*/
         /*~-2*/
         do
         {
            /*~T*/
            Watchdog();
            /*~T*/
            // Master-Mode setzen
            ADuC836_SPISwitch2Mode(ADUC836_SPI_MASTER_MODE);
            /*~T*/
            sprintf(&CommunicationControl.chTransBuffer[COMMUNICATION_SPI],"%s",szString);

            byRetVal = ADuC836_SPISendPtr(&CommunicationControl.chTransBuffer[COMMUNICATION_SPI],0);
         /*~-1*/
         }
         /*~O:U293*/
         while (byRetVal && --byMaxRetries);
         /*~E:U293*/
         /*~T*/
         // zur�ck in den Slave-Mode
         ADuC836_SPISwitch2Mode(ADUC836_SPI_SLAVE_MODE);
         /*~T*/
         return byRetVal;
      /*~-1*/
      }
      /*~E:F292*/
      /*~E:A291*/
   /*~-1*/
   }
   /*~E:C288*/
/*~-1*/
}
/*~E:F284*/
/*~E:A283*/
/*~I:294*/
#ifdef MIT_CRC16
/*~A:295*/
/*~+:char 			Communication_SendRawString_CRC16(unsigned char chLine2Send,unsigned char *szString,unsigned char byClearCRC)*/
/*~F:296*/
char Communication_SendRawString_CRC16(unsigned char chLine2Send,unsigned char *szString,unsigned char byClearCRC)
/*~-1*/
{
   /*~A:297*/
   /*~+:Beschreibung*/
   /*~T*/
   /*!
   \fn void Communication_SendString(unsigned char *szString,unsigned char chCRBefore,unsigned char chCRAfter)
   
   <b>Beschreibung:</b><br>
   Sendet einen String aus.
   
   \param
   szString: zu sendender String.
   
   \param
   chCRBefore: Anzahl der Zeilenvorsch�be vor Ausgabe des Textes .
   
   \param
   chCRAfter: Anzahl der Zeilenvorsch�be nach Ausgabe des Textes .
   
   \return
   ./.
   
   <b>Zugriff:</b><br>
   [X] �ffentlich / [ ] Privat
   
   \ref
   ExamplePage_Kommunikation "Kommunikationroutinen"
   */

   /*~E:A297*/
   /*~A:298*/
   /*~+:Variablendeklarationen*/
   /*~T*/
   char 			byRetVal;
   char 			byMaxRetries;
   unsigned char 	*pbyChar;
   unsigned int	uCheckSum;

   /*~E:A298*/
   /*~A:299*/
   /*~+:Variableninitialisierungen*/
   /*~T*/
   byMaxRetries = 1;
   /*~E:A299*/
   /*~C:300*/
   switch (chLine2Send)
   /*~-1*/
   {
      /*~A:301*/
      /*~+:COMMUNICATION_RS232*/
      /*~F:302*/
      case COMMUNICATION_RS232:
      /*~-1*/
      {
         /*~T*/
         Communication_BuildCRC(szString,-1,byClearCRC);
         /*~T*/
         // Leerzeichen mit kalkulieren
         uCheckSum = CRC16_Build(0x20);
         /*~T*/
         pbyChar = szString + strlen(szString) - 1;
         /*~I:303*/
         if (*pbyChar == 0x03)
         /*~-1*/
         {
            /*~T*/
            // Letztes Zeichen ist ein ETX => Ausgabe
            *pbyChar = 0;
            sprintf(&CommunicationControl.chTransBuffer[COMMUNICATION_RS232],"%s %04X%c",szString,uCheckSum,0x03);
         /*~-1*/
         }
         /*~O:I303*/
         /*~-2*/
         else
         {
            /*~T*/
            sprintf(&CommunicationControl.chTransBuffer[COMMUNICATION_RS232],"%s",szString);
         /*~-1*/
         }
         /*~E:I303*/
         /*~T*/
         // Ausgabe starten
         byRetVal = ADuC836_RS232Send(250);
         /*~T*/
         return byRetVal;
      /*~-1*/
      }
      /*~E:F302*/
      /*~E:A301*/
      /*~A:304*/
      /*~+:COMMUNICATION_SPI*/
      /*~F:305*/
      case COMMUNICATION_SPI:
      /*~-1*/
      {
         /*~U:306*/
         /*~-2*/
         do
         {
            /*~T*/
            Watchdog();
            /*~T*/
            // Master-Mode setzen
            ADuC836_SPISwitch2Mode(ADUC836_SPI_MASTER_MODE);
            /*~T*/
            sprintf(&CommunicationControl.chTransBuffer[COMMUNICATION_SPI],"%s",szString);

            byRetVal = ADuC836_SPISendPtr(&CommunicationControl.chTransBuffer[COMMUNICATION_SPI],0);
         /*~-1*/
         }
         /*~O:U306*/
         while (byRetVal && --byMaxRetries);
         /*~E:U306*/
         /*~T*/
         // zur�ck in den Slave-Mode
         ADuC836_SPISwitch2Mode(ADUC836_SPI_SLAVE_MODE);
         /*~T*/
         return byRetVal;
      /*~-1*/
      }
      /*~E:F305*/
      /*~E:A304*/
   /*~-1*/
   }
   /*~E:C300*/
/*~-1*/
}
/*~E:F296*/
/*~E:A295*/
/*~-1*/
#endif
/*~E:I294*/
/*~A:307*/
/*~+:char 			Communication_SendSPICommand(unsigned char *szCommand)*/
/*~F:308*/
char Communication_SendSPICommand(unsigned char *szCommand)
/*~-1*/
{
   /*~A:309*/
   /*~+:Variablendeklarationen*/
   /*~T*/
   char byRetVal;
   /*~I:310*/
#ifdef DEVELOPMENT_SW
   /*~I:311*/
#ifdef CHANNEL_0
   /*~T*/
   // Nur zu SPI-Testzwecken
   char achString[24];
   char achCommand[5];
   /*~-1*/
#endif
   /*~E:I311*/
   /*~-1*/
#endif
   /*~E:I310*/
   /*~E:A309*/
   /*~A:312*/
   /*~+:Variableninitialisierungen*/
   /*~T*/

   /*~E:A312*/
   /*~A:313*/
   /*~+:SPI-Debugging (nur zu Testzwecken)*/
   /*~I:314*/
#ifdef DEVELOPMENT_SW
   /*~I:315*/
#ifdef CHANNEL_0
   /*~T*/
   CommunicationControl.ulSPICounter++;
   /*~I:316*/
   if (CommunicationControl.bTestSPI == 1)
   /*~-1*/
   {
      /*~T*/
      strncpy(achCommand,szCommand,4);
      /*~I:317*/
#ifdef SYSTEM_CND_ALL_SPI_COMMUNICATIONS
      /*~T*/
      sprintf(achString,"%s - M:%ld(%ld)",achCommand,CommunicationControl.ulSPICounter,CommunicationControl.ulSPIE1Counter);
      Communication_SendString(COMMUNICATION_RS232,achString,0,0);
      /*~O:I317*/
      /*~-1*/
#else
      /*~I:318*/
      if (CommunicationControl.ulSPIE1CounterLast != CommunicationControl.ulSPIE1Counter)
      /*~-1*/
      {
         /*~T*/
         sprintf(achString,"M.-Errors: %ld (@: %ld)",CommunicationControl.ulSPIE1Counter,CommunicationControl.ulSPICounter);
         Communication_SendString(COMMUNICATION_RS232,achString,0,0);
         /*~T*/
         CommunicationControl.ulSPIE1CounterLast = CommunicationControl.ulSPIE1Counter;
      /*~-1*/
      }
      /*~E:I318*/
      /*~-1*/
#endif
      /*~E:I317*/
   /*~-1*/
   }
   /*~E:I316*/
   /*~-1*/
#endif
   /*~E:I315*/
   /*~-1*/
#endif
   /*~E:I314*/
   /*~E:A313*/
   /*~T*/
   byRetVal = Communication_SendString(COMMUNICATION_SPI,szCommand,0,0);
   /*~T*/
   return byRetVal;
/*~-1*/
}
/*~E:F308*/
/*~E:A307*/
/*~A:319*/
/*~+:char 			Communication_SendSPICommandEx(unsigned char *szCommand,unsigned char bySingleCharMode)*/
/*~F:320*/
char Communication_SendSPICommandEx(unsigned char *szCommand,unsigned char bySingleCharMode)
/*~-1*/
{
   /*~A:321*/
   /*~+:Variablendeklarationen*/
   /*~T*/
   char byRetVal;
   /*~E:A321*/
   /*~A:322*/
   /*~+:Variableninitialisierungen*/
   /*~T*/

   /*~E:A322*/
   /*~T*/
   byRetVal = Communication_SendStringEx(COMMUNICATION_SPI,szCommand,0,0,bySingleCharMode);
   /*~T*/
   return byRetVal;
/*~-1*/
}
/*~E:F320*/
/*~E:A319*/
/*~A:323*/
/*~+:char 			Communication_SendString(unsigned char chLine2Send,unsigned char *szString,unsigned char chCRBefore,unsigned char chCRAfter)*/
/*~F:324*/
char Communication_SendString(unsigned char chLine2Send,unsigned char *szString,unsigned char chCRBefore,unsigned char chCRAfter)
/*~-1*/
{
   /*~A:325*/
   /*~+:Beschreibung*/
   /*~T*/
   /*!
   \fn void Communication_SendString(unsigned char *szString,unsigned char chCRBefore,unsigned char chCRAfter)
   
   <b>Beschreibung:</b><br>
   Sendet einen String aus.
   
   \param
   szString: zu sendender String.
   
   \param
   chCRBefore: Anzahl der Zeilenvorsch�be vor Ausgabe des Textes .
   
   \param
   chCRAfter: Anzahl der Zeilenvorsch�be nach Ausgabe des Textes .
   
   \return
   ./.
   
   <b>Zugriff:</b><br>
   [X] �ffentlich / [ ] Privat
   
   \ref
   ExamplePage_Kommunikation "Kommunikationroutinen"
   */

   /*~E:A325*/
   /*~A:326*/
   /*~+:Variablendeklarationen*/
   /*~T*/
   char byRetVal;
   char byMaxRetries;

   /*~E:A326*/
   /*~A:327*/
   /*~+:Variableninitialisierungen*/
   /*~T*/
   byMaxRetries = 1;
   /*~E:A327*/
   /*~C:328*/
   switch (chLine2Send)
   /*~-1*/
   {
      /*~A:329*/
      /*~+:COMMUNICATION_RS232*/
      /*~F:330*/
      case COMMUNICATION_RS232:
      /*~-1*/
      {
         /*~A:331*/
         /*~+:vorangestellte CRs ausgeben*/
         /*~I:332*/
         if (!SYSTEM_MRW_MANAGER)
         /*~-1*/
         {
            /*~I:333*/
            if (chCRBefore)
            /*~-1*/
            {
               /*~T*/
               CommunicationControl.chTransBuffer[COMMUNICATION_RS232][0] = 0;
               /*~L:334*/
               while (chCRBefore--)
               /*~-1*/
               {
                  /*~T*/
                  strcat(&CommunicationControl.chTransBuffer[COMMUNICATION_RS232],"\r\n");
               /*~-1*/
               }
               /*~E:L334*/
               /*~T*/
               ADuC836_RS232Send(250);
            /*~-1*/
            }
            /*~E:I333*/
         /*~-1*/
         }
         /*~E:I332*/
         /*~E:A331*/
         /*~I:335*/
#ifndef MIT_CRC16
         /*~T*/
         sprintf(&CommunicationControl.chTransBuffer[COMMUNICATION_RS232],"%c%s%c",STX,szString,ETX);
         /*~O:I335*/
         /*~-1*/
#else
         /*~T*/
         sprintf(&CommunicationControl.chTransBuffer[COMMUNICATION_RS232],"%c%s %s%c",STX,szString,Communication_AppendChecksum(szString),ETX);
         /*~-1*/
#endif
         /*~E:I335*/
         /*~A:336*/
         /*~+:nachgestellte CRs an den String anh�ngen*/
         /*~I:337*/
         if (!SYSTEM_MRW_MANAGER)
         /*~-1*/
         {
            /*~L:338*/
            while (chCRAfter--)
            /*~-1*/
            {
               /*~T*/
               strcat(&CommunicationControl.chTransBuffer[COMMUNICATION_RS232],"\r\n");
            /*~-1*/
            }
            /*~E:L338*/
         /*~-1*/
         }
         /*~E:I337*/
         /*~E:A336*/
         /*~T*/
         // Ausgabe starten
         byRetVal = ADuC836_RS232Send(250);
         /*~T*/
         return byRetVal;
      /*~-1*/
      }
      /*~E:F330*/
      /*~E:A329*/
      /*~I:339*/
#ifdef MOF
      /*~A:340*/
      /*~+:bis V1.010, 15.06.2016*/
      /*~+:*/
      /*~+:COMMUNICATION_SPI*/
      /*~F:341*/
      case COMMUNICATION_SPI:
      /*~-1*/
      {
         /*~T*/
         // Sendestring zusammensetzen
         sprintf(&CommunicationControl.chTransBuffer[COMMUNICATION_SPI],"%c%s%c",STX,szString,ETX);
         /*~U:342*/
         /*~-2*/
         do
         {
            /*~T*/
            Watchdog();
            /*~T*/
            byRetVal = ADuC836_SPISendPtr(&CommunicationControl.chTransBuffer[COMMUNICATION_SPI],0);
         /*~-1*/
         }
         /*~O:U342*/
         while (byRetVal && --byMaxRetries);
         /*~E:U342*/
         /*~T*/
         return byRetVal;
      /*~-1*/
      }
      /*~E:F341*/
      /*~E:A340*/
      /*~-1*/
#endif
      /*~E:I339*/
      /*~A:343*/
      /*~+:COMMUNICATION_SPI*/
      /*~F:344*/
      case COMMUNICATION_SPI:
      /*~-1*/
      {
         /*~T*/
         // Sendestring zusammensetzen
         sprintf(&CommunicationControl.chTransBuffer[COMMUNICATION_SPI],"%c%s%c",STX,szString,ETX);
         /*~T*/
         byRetVal = ADuC836_SPISendPtr(&CommunicationControl.chTransBuffer[COMMUNICATION_SPI],strlen(szString) + 2);
         /*~T*/
         return byRetVal;
      /*~-1*/
      }
      /*~E:F344*/
      /*~E:A343*/
   /*~-1*/
   }
   /*~E:C328*/
/*~-1*/
}
/*~E:F324*/
/*~E:A323*/
/*~A:345*/
/*~+:char 			Communication_SendStringEx(unsigned char chLine2Send,unsigned char *szString,unsigned char chCRBefore,unsigned char chCRAfter,unsigned char bySingleCharMode)*/
/*~F:346*/
char Communication_SendStringEx(unsigned char chLine2Send,unsigned char *szString,unsigned char chCRBefore,unsigned char chCRAfter,unsigned char bySingleCharMode)
/*~-1*/
{
   /*~A:347*/
   /*~+:Beschreibung*/
   /*~T*/
   /*!
   \fn void Communication_SendString(unsigned char *szString,unsigned char chCRBefore,unsigned char chCRAfter)
   
   <b>Beschreibung:</b><br>
   Sendet einen String aus.
   
   \param
   szString: zu sendender String.
   
   \param
   chCRBefore: Anzahl der Zeilenvorsch�be vor Ausgabe des Textes .
   
   \param
   chCRAfter: Anzahl der Zeilenvorsch�be nach Ausgabe des Textes .
   
   \return
   ./.
   
   <b>Zugriff:</b><br>
   [X] �ffentlich / [ ] Privat
   
   \ref
   ExamplePage_Kommunikation "Kommunikationroutinen"
   */

   /*~E:A347*/
   /*~A:348*/
   /*~+:Variablendeklarationen*/
   /*~T*/
   char byRetVal;
   char byMaxRetries;

   /*~E:A348*/
   /*~A:349*/
   /*~+:Variableninitialisierungen*/
   /*~T*/
   byMaxRetries = 1;
   /*~E:A349*/
   /*~C:350*/
   switch (chLine2Send)
   /*~-1*/
   {
      /*~A:351*/
      /*~+:COMMUNICATION_RS232*/
      /*~F:352*/
      case COMMUNICATION_RS232:
      /*~-1*/
      {
         /*~A:353*/
         /*~+:vorangestellte CRs ausgeben*/
         /*~I:354*/
         if (!SYSTEM_MRW_MANAGER)
         /*~-1*/
         {
            /*~I:355*/
            if (chCRBefore)
            /*~-1*/
            {
               /*~T*/
               CommunicationControl.chTransBuffer[COMMUNICATION_RS232][0] = 0;
               /*~L:356*/
               while (chCRBefore--)
               /*~-1*/
               {
                  /*~T*/
                  strcat(&CommunicationControl.chTransBuffer[COMMUNICATION_RS232],"\r\n");
               /*~-1*/
               }
               /*~E:L356*/
               /*~T*/
               ADuC836_RS232Send(250);
            /*~-1*/
            }
            /*~E:I355*/
         /*~-1*/
         }
         /*~E:I354*/
         /*~E:A353*/
         /*~I:357*/
#ifndef MIT_CRC16
         /*~T*/
         sprintf(&CommunicationControl.chTransBuffer[COMMUNICATION_RS232],"%c%s%c",STX,szString,ETX);
         /*~O:I357*/
         /*~-1*/
#else
         /*~T*/
         sprintf(&CommunicationControl.chTransBuffer[COMMUNICATION_RS232],"%c%s %s%c",STX,szString,Communication_AppendChecksum(szString),ETX);
         /*~-1*/
#endif
         /*~E:I357*/
         /*~A:358*/
         /*~+:nachgestellte CRs an den String anh�ngen*/
         /*~I:359*/
         if (!SYSTEM_MRW_MANAGER)
         /*~-1*/
         {
            /*~L:360*/
            while (chCRAfter--)
            /*~-1*/
            {
               /*~T*/
               strcat(&CommunicationControl.chTransBuffer[COMMUNICATION_RS232],"\r\n");
            /*~-1*/
            }
            /*~E:L360*/
         /*~-1*/
         }
         /*~E:I359*/
         /*~E:A358*/
         /*~T*/
         // Ausgabe starten
         byRetVal = ADuC836_RS232Send(250);
         /*~T*/
         return byRetVal;
      /*~-1*/
      }
      /*~E:F352*/
      /*~E:A351*/
      /*~I:361*/
#ifdef MOF
      /*~A:362*/
      /*~+:bis V1.010, 15.06.2016*/
      /*~+:*/
      /*~+:COMMUNICATION_SPI*/
      /*~F:363*/
      case COMMUNICATION_SPI:
      /*~-1*/
      {
         /*~T*/
         // Sendestring zusammensetzen
         sprintf(&CommunicationControl.chTransBuffer[COMMUNICATION_SPI],"%c%s%c",STX,szString,ETX);
         /*~U:364*/
         /*~-2*/
         do
         {
            /*~T*/
            Watchdog();
            /*~T*/
            byRetVal = ADuC836_SPISendPtr(&CommunicationControl.chTransBuffer[COMMUNICATION_SPI],0);
         /*~-1*/
         }
         /*~O:U364*/
         while (byRetVal && --byMaxRetries);
         /*~E:U364*/
         /*~T*/
         return byRetVal;
      /*~-1*/
      }
      /*~E:F363*/
      /*~E:A362*/
      /*~-1*/
#endif
      /*~E:I361*/
      /*~A:365*/
      /*~+:COMMUNICATION_SPI*/
      /*~F:366*/
      case COMMUNICATION_SPI:
      /*~-1*/
      {
         /*~T*/
         // Sendestring zusammensetzen
         sprintf(&CommunicationControl.chTransBuffer[COMMUNICATION_SPI],"%c%s%c",STX,szString,ETX);
         /*~I:367*/
         if (bySingleCharMode == 0)
         /*~-1*/
         {
            /*~T*/
            byRetVal = ADuC836_SPISendPtr(&CommunicationControl.chTransBuffer[COMMUNICATION_SPI],strlen(szString) + 2);
         /*~-1*/
         }
         /*~O:I367*/
         /*~-2*/
         else
         {
            /*~T*/
            byRetVal = Communication_SendNext();
         /*~-1*/
         }
         /*~E:I367*/
         /*~T*/
         return byRetVal;
      /*~-1*/
      }
      /*~E:F366*/
      /*~E:A365*/
   /*~-1*/
   }
   /*~E:C350*/
/*~-1*/
}
/*~E:F346*/
/*~E:A345*/
/*~A:368*/
/*~+:void 			Communication_SetResetInhibitFlag(unsigned char bSet)*/
/*~F:369*/
void Communication_SetResetInhibitFlag(unsigned char bSet)
/*~-1*/
{
   /*~I:370*/
   if ((CommunicationControl.byResetInhibitFlag <= 1)||(bSet))
   /*~-1*/
   {
      /*~I:371*/
      if(CommunicationControl.byResetInhibitFlag != bSet)
      /*~-1*/
      {
         /*~T*/
         CommunicationControl.byResetInhibitFlag = bSet;
         /*~T*/
         Save_Parameter(LOAD_SAVE_FLAG_DONOT_RESET,&CommunicationControl.byResetInhibitFlag,1);
      /*~-1*/
      }
      /*~E:I371*/
   /*~-1*/
   }
   /*~E:I370*/
/*~-1*/
}
/*~E:F369*/
/*~E:A368*/
/*~A:372*/
/*~+:char 			Communication_Wait4Response(void)*/
/*~F:373*/
char Communication_Wait4Response(void)
/*~-1*/
{
   /*~T*/
   return ADuC836_SPIWait4Response(SYSTEM_TIMEOUT_SPI);
/*~-1*/
}
/*~E:F373*/
/*~E:A372*/
