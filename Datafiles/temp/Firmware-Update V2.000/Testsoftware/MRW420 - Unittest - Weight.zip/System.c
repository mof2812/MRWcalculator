/*~-1*/
/*~XSF_LANGUAGE: C/C++*/
/*~K*/
/*~+:File :        System.c*/
/*~+:*/
/*~+:Version :     V1.0*/
/*~+:*/
/*~+:Date :        24.08.2005*/
/*~+:*/
/*~+:Time :        10:23*/
/*~+:*/
/*~+:Author :      MOF*/
/*~+:*/
/*~+:Hardware :*/
/*~+:*/
/*~+:Description :*/
/*~+:*/
/*~+:*/
/*~A:1*/
/*~+:Includes*/
/*~T*/
#include "Global.h"
#include <Stdio.h>
#include <Stdlib.h>
#include <String.h>
/*~E:A1*/
/*~T*/
extern RS232_T RS232;
/*~A:2*/
/*~+:Funktionseigene Definitionen*/
/*~I:3*/
#ifdef CHANNEL_0 
/*~T*/
#define SYSTEM_SYNC_ERROR_LIMIT				15//3  // bis 04.08.2008: 10
/*~-1*/
#endif
/*~E:I3*/
/*~I:4*/
#ifdef CHANNEL_1 
/*~T*/
#define SYSTEM_SYNC_ERROR_LIMIT				20//4  // bis 04.08.2008: 10
/*~-1*/
#endif
/*~E:I4*/
/*~E:A2*/
/*~A:5*/
/*~+:Funktionseigene Struktur-Definitionen*/
/*~T*/

/*~E:A5*/
/*~A:6*/
/*~+:Funktionsprototypen*/
/*~T*/
void 			System(void);
unsigned long 	System_BuildAdminCode(void);
char 			System_CheckVersion(void);
void 			System_ClearErrorCounters(void);
void 			System_ClearOperatingHours(char byTimer);

/*~T*/
void	 		System_ClearSystemError(void);
void 			System_Connect2MRW_Manager(char byMode);
char* 			System_GetItemNumber(void);
long 			System_GetOperatingHours(char byTimer,unsigned char bHighResolution);
unsigned char*	System_GetOperatingHoursAsString(char byTimer);
char* 			System_GetSerialNumber(void);
/*~I:7*/
#ifdef CHANNEL_1
/*~T*/
void 			System_IncCheckSynchronisationCounter(void);

/*~-1*/
#endif
/*~E:I7*/
/*~T*/
void 			System_Ini(unsigned char chMode);
unsigned char	System_IsConnected2MRW_Manager(void);

/*~I:8*/
#ifdef MOF
/*~T*/
void 			System_ReleaseExternalInterrupt(void);

/*~-1*/
#endif
/*~E:I8*/
/*~T*/
void 			System_Reset(void);
void 			System_SaveOperatingHours(void);
void 			System_SetCheckSynchronisation(unsigned char chOnOff);
char 			System_SetItemNumber(char *szItemNumber2Set);
char 			System_SetSerialNumber(char *szSerialNumber2Set);
void 			System_SetSystemState(unsigned long ulState2Set);
void 			System_Synchronization(void);
void 			System_SystemErrorSetWatchdog(void);
void 			System_UpdateOperatingHours(unsigned char byMode);
void			System_Wait(unsigned int uTimeMS);
void 			External_Interface(unsigned char chNbOfExtInterrupt);
void 			Timer_Interface(void);
/*~E:A6*/
/*~A:9*/
/*~+:Globale Variablen*/
/*~T*/
SYSTEM g_SystemControl;
/*~E:A9*/
/*~A:10*/
/*~+:extern deklarierte Variablen*/
/*~T*/
extern SPI_T SPI;
/*~E:A10*/
/*~A:11*/
/*~+:// Version mit Statemachine zum Absetzen der zyklischen Befehle*/
/*~+:void 			System(void)*/
/*~F:12*/
void System(void)
/*~-1*/
{
   /*~A:13*/
   /*~+:Kanal 0*/
   /*~I:14*/
#ifdef CHANNEL_0
   /*~A:15*/
   /*~+:Variablendeklarationen*/
   /*~T*/
   static unsigned char byIgnoreTimerflag = 0;
   /*~T*/
   unsigned char chSPIBuffer[24];	//[24]
   long lLong;
   unsigned char chError;
   static unsigned char bReleaseFlag = 0;
   static unsigned char byTimeDivider = 0;
   static unsigned char byToggle = 0;

   /*~E:A15*/
   /*~A:16*/
   /*~+:Variableninitialisierungen*/
   /*~T*/

   /*~E:A16*/
   /*~I:17*/
#ifdef DEVELOPMENT_SW
   	#ifdef SYSTEM_CND_ENABLE_SPI_DEBUGGING
   		if (byIgnoreTimerflag||((Flag100ms)&&(CommunicationControl.bTestSPI == 1))||((Flag300ms)&&(CommunicationControl.bTestSPI != 1)))
   	#else
   		if ((Flag300ms)||(byIgnoreTimerflag))
   	#endif
#else
   	if ((Flag300ms)||(byIgnoreTimerflag))
#endif

   /*~-1*/
   {
      /*~A:18*/
      /*~+:Zyklischer Datenaustausch*/
      /*~K*/
      /*~+:// alle 300ms*/
      /*~I:19*/
      if (bReleaseFlag == 1)
      /*~-1*/
      {
         /*~I:20*/
         if (ADuC836_RS232IsCommunicationInProcess() == 0)
         /*~-1*/
         {
            /*~C:21*/
            switch (byToggle)
            /*~-1*/
            {
               /*~F:22*/
               case 0:
               /*~-1*/
               {
                  /*~I:23*/
#ifdef SYSTEM_CND_DISABLE_SPI_COMMUNICATION_AT_FAULTS 
                  /*~A:24*/
                  /*~+:Mit Abschaltung der SPI-Kommunikation bei Ausfall der SPI-Schnittstelle*/
                  /*~T*/
                  // Mit Abschaltung der SPI-Kommunikation bei Ausfall der SPI-Schnittstelle
                  /*~I:25*/
                  if (Communication_IsSPICommuncationDisabled() == FALSE)
                  /*~-1*/
                  {
                     /*~T*/
                     // Frame zusammensetzen
                     sprintf(chSPIBuffer,"iGPS 0 %ld",SYSTEMSTATE);
                     /*~I:26*/
                     if (!Communication_SendSPICommand(chSPIBuffer))
                     /*~-1*/
                     {
                        /*~I:27*/
                        // Partner-Systemstatus auslesen
                        if (!Communication_GetLong(&lLong))
                        /*~-1*/
                        {
                           /*~T*/
                           SYSTEMSTATE_PARTNER = lLong;
                           /*~I:28*/
#ifdef MIT_SYSTEMFEHLER_BEI_PARTNER_SYSTEMFEHLER
                           /*~I:29*/
                           if (SYSTEMSTATE_PARTNER == SYSTEM_ERROR)
                           /*~-1*/
                           {
                              /*~A:30*/
                              /*~+:Sicherheitsfunktion aufrufen*/
                              /*~T*/
                              // Sicherheitsfunktion aufrufen
                              Diagnosis_SecurityPartnerSystemError(SYSTEM_PARTNER_IN_SYSTEMERROR);
                              /*~E:A30*/
                           /*~-1*/
                           }
                           /*~E:I29*/
                           /*~-1*/
#endif
                           /*~E:I28*/
                        /*~-1*/
                        }
                        /*~O:I27*/
                        /*~-2*/
                        else
                        {
                           /*~T*/
                           chError = 2;
                        /*~-1*/
                        }
                        /*~E:I27*/
                     /*~-1*/
                     }
                     /*~O:I26*/
                     /*~-2*/
                     else
                     {
                        /*~T*/
                        chError = 1;
                     /*~-1*/
                     }
                     /*~E:I26*/
                  /*~-1*/
                  }
                  /*~E:I25*/
                  /*~E:A24*/
                  /*~O:I23*/
                  /*~-1*/
#else
                  /*~A:31*/
                  /*~+:Ohne Abschaltung der SPI-Kommunikation bei Ausfall der SPI-Schnittstelle*/
                  /*~T*/
                  // Ohne Abschaltung der SPI-Kommunikation bei Ausfall der SPI-Schnittstelle
                  /*~T*/
                  // Frame zusammensetzen
                  sprintf(chSPIBuffer,"iGPS 0 %ld",SYSTEMSTATE);
                  /*~I:32*/
                  if (!Communication_SendSPICommand(chSPIBuffer))
                  /*~-1*/
                  {
                     /*~I:33*/
                     // Partner-Systemstatus auslesen
                     if (!Communication_GetLong(&lLong))
                     /*~-1*/
                     {
                        /*~T*/
                        SYSTEMSTATE_PARTNER = lLong;
                        /*~I:34*/
#ifdef MIT_SYSTEMFEHLER_BEI_PARTNER_SYSTEMFEHLER
                        /*~I:35*/
                        if (SYSTEMSTATE_PARTNER == SYSTEM_ERROR)
                        /*~-1*/
                        {
                           /*~A:36*/
                           /*~+:Sicherheitsfunktion aufrufen*/
                           /*~T*/
                           // Sicherheitsfunktion aufrufen
                           Diagnosis_SecurityPartnerSystemError(SYSTEM_PARTNER_IN_SYSTEMERROR);
                           /*~E:A36*/
                        /*~-1*/
                        }
                        /*~E:I35*/
                        /*~-1*/
#endif
                        /*~E:I34*/
                     /*~-1*/
                     }
                     /*~O:I33*/
                     /*~-2*/
                     else
                     {
                        /*~T*/
                        chError = 2;
                     /*~-1*/
                     }
                     /*~E:I33*/
                  /*~-1*/
                  }
                  /*~O:I32*/
                  /*~-2*/
                  else
                  {
                     /*~T*/
                     chError = 1;
                  /*~-1*/
                  }
                  /*~E:I32*/
                  /*~E:A31*/
                  /*~-1*/
#endif
                  /*~E:I23*/
                  /*~T*/
                  break;
               /*~-1*/
               }
               /*~E:F22*/
               /*~F:37*/
               case 1:
               /*~-1*/
               {
                  /*~I:38*/
#ifdef SYSTEM_CND_DISABLE_SPI_COMMUNICATION_AT_FAULTS 
                  /*~A:39*/
                  /*~+:Mit Abschaltung der SPI-Kommunikation bei Ausfall der SPI-Schnittstelle*/
                  /*~T*/
                  // Mit Abschaltung der SPI-Kommunikation bei Ausfall der SPI-Schnittstelle
                  /*~I:40*/
                  if (Communication_IsSPICommuncationDisabled() == FALSE)
                  /*~-1*/
                  {
                     /*~T*/
                     // Frame zusammensetzen
                     sprintf(chSPIBuffer,"iGPS 1 %bu",Limit_GetLimitState());
                     /*~I:41*/
                     if (!Communication_SendSPICommand(chSPIBuffer))
                     /*~-1*/
                     {
                        /*~I:42*/
                        // Partner-Grenzwertstatus auslesen
                        if (!Communication_GetLong(&lLong))
                        /*~-1*/
                        {
                           /*~T*/
                           Global.chLimitStatus_Partner = (char)lLong;
                           /*~T*/
                           chError = 0;
                        /*~-1*/
                        }
                        /*~O:I42*/
                        /*~-2*/
                        else
                        {
                           /*~T*/
                           chError = 4;
                        /*~-1*/
                        }
                        /*~E:I42*/
                     /*~-1*/
                     }
                     /*~O:I41*/
                     /*~-2*/
                     else
                     {
                        /*~T*/
                        chError = 3;
                     /*~-1*/
                     }
                     /*~E:I41*/
                     /*~A:43*/
                     /*~+:Fehlerauswertung zur �berpr�fung, ob der Partner noch lebt*/
                     /*~I:44*/
#ifndef NO_SYNC_CHECK
                     /*~I:45*/
                     if (g_SystemControl.bCheckSynchronisationOn)
                     /*~-1*/
                     {
                        /*~I:46*/
                        if (chError)
                        /*~-1*/
                        {
                           /*~A:47*/
                           /*~+:Es ist ein Fehler aufgetreten - Fehlerz�hler inkrementieren*/
                           /*~I:48*/
                           if (g_SystemControl.chSyncErrorCounter < SYSTEM_SYNC_ERROR_LIMIT - 1)
                           /*~-1*/
                           {
                              /*~T*/
                              g_SystemControl.chSyncErrorCounter++;
                           /*~-1*/
                           }
                           /*~O:I48*/
                           /*~-2*/
                           else
                           {
                              /*~T*/
                              g_SystemControl.chSyncErrorCounter = 0;
                              /*~I:49*/
#ifdef  MOF 
                              // ausgeklammert ab Version V1.006
                              /*~T*/
                              // Sicherheitsfunktion aufrufen
                              Diagnosis_SecurityInternalCommunication(SYTEM_ERROR_INTERNAL_COMMUNICATION);
                              /*~-1*/
#endif
                              /*~E:I49*/
                              /*~A:50*/
                              /*~+:Fehlerz�hler der SPI-Kommunikations�berwachung inkrementieren und ggf. Reset ausf�hren*/
                              /*~T*/
                              Communication_IncrementSPIFaultCounter();
                              /*~E:A50*/
                           /*~-1*/
                           }
                           /*~E:I48*/
                           /*~E:A47*/
                        /*~-1*/
                        }
                        /*~O:I46*/
                        /*~-2*/
                        else
                        {
                           /*~A:51*/
                           /*~+:Alles okay - Fehlerz�hler nullen*/
                           /*~T*/
                           g_SystemControl.chSyncErrorCounter = 0;
                           /*~E:A51*/
                           /*~A:52*/
                           /*~+:Fehlerz�hler der SPI-Kommunikations�berwachung l�schen*/
                           /*~T*/
                           Communication_ClearSPIFaultCounter(0);
                           /*~E:A52*/
                        /*~-1*/
                        }
                        /*~E:I46*/
                     /*~-1*/
                     }
                     /*~O:I45*/
                     /*~-2*/
                     else
                     {
                        /*~I:53*/
                        if (!chError)
                        /*~-1*/
                        {
                           /*~T*/
                           g_SystemControl.bCheckSynchronisationOn = 1;
                        /*~-1*/
                        }
                        /*~E:I53*/
                     /*~-1*/
                     }
                     /*~E:I45*/
                     /*~-1*/
#endif
                     /*~E:I44*/
                     /*~E:A43*/
                  /*~-1*/
                  }
                  /*~E:I40*/
                  /*~E:A39*/
                  /*~O:I38*/
                  /*~-1*/
#else
                  /*~A:54*/
                  /*~+:Ohne Abschaltung der SPI-Kommunikation bei Ausfall der SPI-Schnittstelle*/
                  /*~T*/
                  // Ohne Abschaltung der SPI-Kommunikation bei Ausfall der SPI-Schnittstelle
                  /*~T*/
                  // Frame zusammensetzen
                  sprintf(chSPIBuffer,"iGPS 1 %bu",Limit_GetLimitState());
                  /*~I:55*/
                  if (!Communication_SendSPICommand(chSPIBuffer))
                  /*~-1*/
                  {
                     /*~I:56*/
                     // Partner-Grenzwertstatus auslesen
                     if (!Communication_GetLong(&lLong))
                     /*~-1*/
                     {
                        /*~T*/
                        Global.chLimitStatus_Partner = (char)lLong;
                        /*~T*/
                        chError = 0;
                     /*~-1*/
                     }
                     /*~O:I56*/
                     /*~-2*/
                     else
                     {
                        /*~T*/
                        chError = 4;
                     /*~-1*/
                     }
                     /*~E:I56*/
                  /*~-1*/
                  }
                  /*~O:I55*/
                  /*~-2*/
                  else
                  {
                     /*~T*/
                     chError = 3;
                  /*~-1*/
                  }
                  /*~E:I55*/
                  /*~A:57*/
                  /*~+:Fehlerauswertung zur �berpr�fung, ob der Partner noch lebt*/
                  /*~I:58*/
#ifndef NO_SYNC_CHECK
                  /*~I:59*/
                  if (chError)
                  /*~-1*/
                  {
                     /*~A:60*/
                     /*~+:Es ist ein Fehler aufgetreten - Fehlerz�hler inkrementieren*/
                     /*~I:61*/
                     if (g_SystemControl.chSyncErrorCounter < SYSTEM_SYNC_ERROR_LIMIT - 1)
                     /*~-1*/
                     {
                        /*~T*/
                        g_SystemControl.chSyncErrorCounter++;
                     /*~-1*/
                     }
                     /*~O:I61*/
                     /*~-2*/
                     else
                     {
                        /*~T*/
                        g_SystemControl.chSyncErrorCounter = 0;
                        /*~T*/
                        // Sicherheitsfunktion aufrufen
                        Diagnosis_SecurityInternalCommunication(SYTEM_ERROR_INTERNAL_COMMUNICATION);
                        /*~I:62*/
#ifdef MOF
                        /*~A:63*/
                        /*~+:Reset ausf�hren*/
                        /*~T*/
                        // System-Reset ausf�hren
                        System_Reset();
                        /*~E:A63*/
                        /*~-1*/
#endif
                        /*~E:I62*/
                     /*~-1*/
                     }
                     /*~E:I61*/
                     /*~E:A60*/
                  /*~-1*/
                  }
                  /*~O:I59*/
                  /*~-2*/
                  else
                  {
                     /*~A:64*/
                     /*~+:Alles okay - Fehlerz�hler nullen*/
                     /*~T*/
                     g_SystemControl.chSyncErrorCounter = 0;
                     /*~E:A64*/
                  /*~-1*/
                  }
                  /*~E:I59*/
                  /*~-1*/
#endif
                  /*~E:I58*/
                  /*~E:A57*/
                  /*~E:A54*/
                  /*~-1*/
#endif
                  /*~E:I38*/
                  /*~T*/
                  byToggle = 255;
                  /*~T*/
                  break;
               /*~-1*/
               }
               /*~E:F37*/
               /*~O:C21*/
               /*~-2*/
               default:
               {
                  /*~T*/
                  byToggle = 255;
               /*~-1*/
               }
            /*~-1*/
            }
            /*~E:C21*/
            /*~T*/
            byToggle++;
         /*~-1*/
         }
         /*~E:I20*/
      /*~-1*/
      }
      /*~O:I19*/
      /*~-2*/
      else
      {
         /*~T*/
         bReleaseFlag = 1;
      /*~-1*/
      }
      /*~E:I19*/
      /*~E:A18*/
   /*~-1*/
   }
   /*~E:I17*/
   /*~I:65*/
   if (Flag10000ms)
   /*~-1*/
   {
      /*~T*/
      // alle 10s
      /*~I:66*/
      if (++byTimeDivider == 60)
      /*~-1*/
      {
         /*~T*/
         // alle 10min.
         /*~I:67*/
         if (ADuC836_RS232IsCommunicationInProcess() == 0)
         /*~-1*/
         {
            /*~A:68*/
            /*~+:Systemzeit synchronisieren*/
            /*~I:69*/
#ifdef SYSTEM_CND_DISABLE_SPI_COMMUNICATION_AT_FAULTS 
            /*~A:70*/
            /*~+:Mit Abschaltung der SPI-Kommunikation bei Ausfall der SPI-Schnittstelle*/
            /*~I:71*/
            if (Communication_IsSPICommuncationDisabled() == FALSE)
            /*~-1*/
            {
               /*~T*/
               // sprintf(chSPIBuffer,"iTSY %ld",SYSTEMTIME);
               sprintf(chSPIBuffer,"iTSY %ld",OPERATINGHOURS);
               /*~T*/
               Communication_SendSPICommand(chSPIBuffer);
               /*~U:72*/
               /*~-2*/
               do
               {
                  /*~T*/

               /*~-1*/
               }
               /*~O:U72*/
               while (!Communication_IsOK());
               /*~E:U72*/
            /*~-1*/
            }
            /*~E:I71*/
            /*~E:A70*/
            /*~O:I69*/
            /*~-1*/
#else
            /*~A:73*/
            /*~+:Ohne Abschaltung der SPI-Kommunikation bei Ausfall der SPI-Schnittstelle*/
            /*~T*/
            // sprintf(chSPIBuffer,"iTSY %ld",SYSTEMTIME);
            sprintf(chSPIBuffer,"iTSY %ld",OPERATINGHOURS);
            /*~T*/
            Communication_SendSPICommand(chSPIBuffer);
            /*~T*/
            Communication_IsOK();
            /*~E:A73*/
            /*~-1*/
#endif
            /*~E:I69*/
            /*~E:A68*/
         /*~-1*/
         }
         /*~E:I67*/
         /*~T*/
         // Teiler zur�cksetzen
         byTimeDivider = 0;
      /*~-1*/
      }
      /*~E:I66*/
   /*~-1*/
   }
   /*~E:I65*/
   /*~-1*/
#endif
   /*~E:I14*/
   /*~E:A13*/
   /*~A:74*/
   /*~+:Kanal 1*/
   /*~I:75*/
#ifdef CHANNEL_1
   /*~I:76*/
   // if (Flag2000ms)	bis 04.08.2008
   if (Flag100ms)
   /*~-1*/
   {
      /*~A:77*/
      /*~+:�berpr�fung, ob sich die Gegenstelle noch meldet (�berpr�fung der Synchronisation)*/
      /*~I:78*/
#ifndef NO_SYNC_CHECK
      /*~I:79*/
#ifdef SYSTEM_CND_DISABLE_SPI_COMMUNICATION_AT_FAULTS 
      /*~A:80*/
      /*~+:Mit Abschaltung der SPI-Kommunikation bei Ausfall der SPI-Schnittstelle*/
      /*~I:81*/
      if (g_SystemControl.bCheckSynchronisationOn)
      /*~-1*/
      {
         /*~I:82*/
         if (g_SystemControl.chCheckSynchronisationCounter)
         /*~-1*/
         {
            /*~T*/
            g_SystemControl.chCheckSynchronisationCounter = 0;
            g_SystemControl.chSyncErrorCounter = 0;
            /*~A:83*/
            /*~+:Alles okay - Fehlerz�hler der SPI-Kommunikations�berwachung l�schen*/
            /*~T*/
            Communication_ClearSPIFaultCounter(0);
            /*~E:A83*/
         /*~-1*/
         }
         /*~O:I82*/
         /*~-2*/
         else
         {
            /*~I:84*/
            if (g_SystemControl.chSyncErrorCounter < SYSTEM_SYNC_ERROR_LIMIT - 1)
            /*~-1*/
            {
               /*~T*/
               g_SystemControl.chSyncErrorCounter++;
            /*~-1*/
            }
            /*~O:I84*/
            /*~-2*/
            else
            {
               /*~T*/
               g_SystemControl.chSyncErrorCounter = 0;
               /*~I:85*/
#ifdef MOF 
               // ausgeklammert ab Version V1.006
               /*~A:86*/
               /*~+:Sicherheitsfunktion aufrufen*/
               /*~T*/
               // Sicherheitsfunktion aufrufen
               Diagnosis_SecurityInternalCommunication(SYTEM_ERROR_INTERNAL_COMMUNICATION);
               /*~E:A86*/
               /*~-1*/
#endif
               /*~E:I85*/
               /*~A:87*/
               /*~+:Fehlerz�hler der SPI-Kommunikations�berwachung inkrementieren und ggf. Reset ausf�hren*/
               /*~T*/
               Communication_IncrementSPIFaultCounter();
               /*~E:A87*/
            /*~-1*/
            }
            /*~E:I84*/
         /*~-1*/
         }
         /*~E:I82*/
      /*~-1*/
      }
      /*~E:I81*/
      /*~E:A80*/
      /*~O:I79*/
      /*~-1*/
#else
      /*~A:88*/
      /*~+:Ohne Abschaltung der SPI-Kommunikation bei Ausfall der SPI-Schnittstelle*/
      /*~I:89*/
      if (g_SystemControl.bCheckSynchronisationOn)
      /*~-1*/
      {
         /*~I:90*/
         if (g_SystemControl.chCheckSynchronisationCounter)
         /*~-1*/
         {
            /*~T*/
            g_SystemControl.chCheckSynchronisationCounter = 0;
            g_SystemControl.chSyncErrorCounter = 0;
         /*~-1*/
         }
         /*~O:I90*/
         /*~-2*/
         else
         {
            /*~I:91*/
            if (g_SystemControl.chSyncErrorCounter < SYSTEM_SYNC_ERROR_LIMIT - 1)
            /*~-1*/
            {
               /*~T*/
               g_SystemControl.chSyncErrorCounter++;
            /*~-1*/
            }
            /*~O:I91*/
            /*~-2*/
            else
            {
               /*~T*/
               g_SystemControl.chSyncErrorCounter = 0;
               /*~I:92*/
#ifdef  MOF 
               // ausgeklammert ab Version V1.006
               /*~A:93*/
               /*~+:Sicherheitsfunktion aufrufen*/
               /*~T*/
               // Sicherheitsfunktion aufrufen
               Diagnosis_SecurityInternalCommunication(SYTEM_ERROR_INTERNAL_COMMUNICATION);
               /*~E:A93*/
               /*~-1*/
#endif
               /*~E:I92*/
               /*~A:94*/
               /*~+:Reset ausf�hren*/
               /*~T*/
               // System-Reset ausf�hren
               System_Reset();
               /*~E:A94*/
            /*~-1*/
            }
            /*~E:I91*/
         /*~-1*/
         }
         /*~E:I90*/
      /*~-1*/
      }
      /*~E:I89*/
      /*~E:A88*/
      /*~-1*/
#endif
      /*~E:I79*/
      /*~-1*/
#endif
      /*~E:I78*/
      /*~E:A77*/
   /*~-1*/
   }
   /*~E:I76*/
   /*~-1*/
#endif
   /*~E:I75*/
   /*~E:A74*/
/*~-1*/
}
/*~E:F12*/
/*~E:A11*/
/*~A:95*/
/*~+:unsigned long 	System_BuildAdminCode(void)*/
/*~F:96*/
unsigned long System_BuildAdminCode(void)
/*~-1*/
{
   /*~T*/
   return Global.ulAdminCode = OPERATINGHOURS / 3600 + (OPERATINGHOURS % 3600) / 60 + OPERATINGHOURS % 60;
/*~-1*/
}
/*~E:F96*/
/*~E:A95*/
/*~A:97*/
/*~+:char 			System_CheckVersion(void)*/
/*~F:98*/
char System_CheckVersion(void)
/*~-1*/
{
   /*~I:99*/
#ifdef CHANNEL_0
   /*~A:100*/
   /*~+:Variablendeklarationen*/
   /*~T*/
   unsigned char chVersion[24];
   unsigned char chRetVal;
   unsigned char chRepeats;
   /*~E:A100*/
   /*~A:101*/
   /*~+:Variableninitialisierungen*/
   /*~T*/
   chRetVal = 2;
   chRepeats = 5;
   /*~E:A101*/
   /*~U:102*/
   /*~-2*/
   do
   {
      /*~I:103*/
      /*#LJ:1=9*/
      if (!Communication_SendSPICommand("iGVR 1"))
      /*~-1*/
      {
         /*~I:104*/
         if (!Communication_GetString(chVersion))
         /*~-1*/
         {
            /*~I:105*/
            if (!strcmp(chVersion,TEXT_SOFTWARE_VERSION))
            /*~-1*/
            {
               /*~T*/
               chRetVal = 0;
            /*~-1*/
            }
            /*~O:I105*/
            /*~-2*/
            else
            {
               /*~T*/
               // Version stimmt nicht
               chRetVal = 3;
            /*~-1*/
            }
            /*~E:I105*/
         /*~-1*/
         }
         /*~O:I104*/
         /*~-2*/
         else
         {
            /*~T*/
            // Empfangs-Timeout
            chRetVal = 2;
         /*~-1*/
         }
         /*~E:I104*/
      /*~-1*/
      }
      /*~O:I103*/
      /*~-2*/
      else
      {
         /*~T*/
         chRetVal = 1;
      /*~-1*/
      }
      /*~E:I103*/
   /*~-1*/
   }
   /*~O:U102*/
   while ((chRepeats--)&&(chRetVal)&&(Communication_IsSPICommuncationDisabled() == FALSE));
   /*~E:U102*/
   /*~T*/
   return chRetVal;
   /*~O:I99*/
   /*~-1*/
#else
   /*~T*/
   return 0;
   /*~-1*/
#endif
   /*~E:I99*/
/*~-1*/
}
/*~E:F98*/
/*~E:A97*/
/*~A:106*/
/*~+:void 			System_ClearErrorCounters(void)*/
/*~F:107*/
void System_ClearErrorCounters(void)
/*~-1*/
{
   /*~A:108*/
   /*~+:Untersuchung des Netzteils*/
   /*~I:109*/
#ifdef CHANNEL_0
   /*~T*/
   Global.byErrorPowerSupplyCounter = 0;
   /*~-1*/
#endif
   /*~E:I109*/
   /*~I:110*/
#ifdef VCC_CHECK_ON_BOTH_CHANELS
   /*~I:111*/
#ifdef CHANNEL_1
   /*~T*/
   Global.byErrorPowerSupplyCounter = 0;
   /*~-1*/
#endif
   /*~E:I111*/
   /*~-1*/
#endif
   /*~E:I110*/
   /*~E:A108*/
   /*~A:112*/
   /*~+:Abweichung zwischen Soll- und Iststrom*/
   /*~T*/
   g_CurrentInterface.FeedBack.byMaxDeviationCounter = 0;
   /*~E:A112*/
   /*~A:113*/
   /*~+:Interne Kommunikation*/
   /*~I:114*/
#ifndef NO_SYNC_CHECK 
   /*~T*/
   g_SystemControl.chSyncErrorCounter = 0;
   /*~-1*/
#endif
   /*~E:I114*/
   /*~E:A113*/
/*~-1*/
}
/*~E:F107*/
/*~E:A106*/
/*~A:115*/
/*~+:void 			System_ClearOperatingHours(char byTimer)*/
/*~F:116*/
void System_ClearOperatingHours(char byTimer)
/*~-1*/
{
   /*~I:117*/
   if (!byTimer)
   /*~-1*/
   {
      /*~T*/
      // Betriebsstundenz�hler nullen
      OPERATINGHOURS = 0L;
      // und speichern
      Save_Parameter(LOAD_SAVE_OPERATING_HOURS,&OPERATINGHOURS,4);
   /*~-1*/
   }
   /*~O:I117*/
   /*~-2*/
   else
   {
      /*~T*/
      // Relativen Betriebsstundenz�hler nullen
      CUSTOMTIMER = 0L;
      // und speichern
      Save_Parameter(LOAD_SAVE_OPERATING_HOURS_2,&CUSTOMTIMER,4);
   /*~-1*/
   }
   /*~E:I117*/
/*~-1*/
}
/*~E:F116*/
/*~E:A115*/
/*~A:118*/
/*~+:void	 		System_ClearSystemError(void)*/
/*~F:119*/
void System_ClearSystemError(void)
/*~-1*/
{
   /*~I:120*/
   if (SYSTEMSTATE == SYSTEM_ERROR)
   /*~-1*/
   {
      /*~T*/
      System_SetSystemState(SYSTEM_RUNNING);

      ADuC836_DACClearOutput(0);
      /*~T*/
      // Z�hlerst�nde l�schen
      System_ClearErrorCounters();
   /*~-1*/
   }
   /*~E:I120*/
/*~-1*/
}
/*~E:F119*/
/*~E:A118*/
/*~A:121*/
/*~+:void 			System_Connect2MRW_Manager(char byMode)*/
/*~F:122*/
void System_Connect2MRW_Manager(char byMode)
/*~-1*/
{
   /*~I:123*/
   if (!byMode)
   /*~-1*/
   {
      /*~T*/
      g_SystemControl.byMRWManagerMode = 0;
   /*~-1*/
   }
   /*~O:I123*/
   /*~-2*/
   else
   {
      /*~T*/
      g_SystemControl.byMRWManagerMode = 1;
   /*~-1*/
   }
   /*~E:I123*/
/*~-1*/
}
/*~E:F122*/
/*~E:A121*/
/*~A:124*/
/*~+:char* 			System_GetItemNumber(void)*/
/*~F:125*/
char* System_GetItemNumber(void)
/*~-1*/
{
   /*~T*/
   // Parameter aus dem EEPROM laden
   Load_Parameter(LOAD_SAVE_ARTICLENUMBER,&g_SystemControl.szItemNumber,0);

   return g_SystemControl.szItemNumber; 
/*~-1*/
}
/*~E:F125*/
/*~E:A124*/
/*~A:126*/
/*~+:long 			System_GetOperatingHours(char byTimer,unsigned char bHighResolution)*/
/*~F:127*/
long System_GetOperatingHours(char byTimer,unsigned char bHighResolution)
/*~-1*/
{
   /*~I:128*/
   if (!byTimer)
   /*~-1*/
   {
      /*~I:129*/
      if (bHighResolution)
      /*~-1*/
      {
         /*~T*/
         // in Minuten
         return OPERATINGHOURS / 60;
      /*~-1*/
      }
      /*~O:I129*/
      /*~-2*/
      else
      {
         /*~T*/
         // in Stunden
         return OPERATINGHOURS / 3600;
      /*~-1*/
      }
      /*~E:I129*/
   /*~-1*/
   }
   /*~O:I128*/
   /*~-2*/
   else
   {
      /*~I:130*/
      if (bHighResolution)
      /*~-1*/
      {
         /*~T*/
         // in Minuten
         return CUSTOMTIMER / 60;
      /*~-1*/
      }
      /*~O:I130*/
      /*~-2*/
      else
      {
         /*~T*/
         // in Stunden
         return CUSTOMTIMER / 3600;
      /*~-1*/
      }
      /*~E:I130*/
   /*~-1*/
   }
   /*~E:I128*/
/*~-1*/
}
/*~E:F127*/
/*~E:A126*/
/*~A:131*/
/*~+:unsigned char*	System_GetOperatingHoursAsString(char byTimer)*/
/*~F:132*/
unsigned char* System_GetOperatingHoursAsString(char byTimer)
/*~-1*/
{
   /*~A:133*/
   /*~+:Variablendeklarationen*/
   /*~T*/
   unsigned char szString[14];
   /*~E:A133*/
   /*~I:134*/
   if (!byTimer)
   /*~-1*/
   {
      /*~T*/
      sprintf(szString,"%ld:%02ld:%02ld",OPERATINGHOURS / 3600,(OPERATINGHOURS % 3600) / 60,OPERATINGHOURS % 60);
   /*~-1*/
   }
   /*~O:I134*/
   /*~-2*/
   else
   {
      /*~T*/
      sprintf(szString,"%ld:%02ld:%02ld",CUSTOMTIMER / 3600,(CUSTOMTIMER % 3600) / 60,CUSTOMTIMER % 60);
   /*~-1*/
   }
   /*~E:I134*/
   /*~T*/
   return szString;
/*~-1*/
}
/*~E:F132*/
/*~E:A131*/
/*~A:135*/
/*~+:char* 			System_GetSerialNumber(void)*/
/*~F:136*/
char* System_GetSerialNumber(void)
/*~-1*/
{
   /*~T*/
   // Parameter aus dem EEPROM laden
   Load_Parameter(LOAD_SAVE_SERIALNUMBER,&g_SystemControl.szSerialNumber,0);

   return g_SystemControl.szSerialNumber; 
/*~-1*/
}
/*~E:F136*/
/*~E:A135*/
/*~I:137*/
#ifdef CHANNEL_1
/*~A:138*/
/*~+:void 			System_IncCheckSynchronisationCounter(void)*/
/*~F:139*/
void System_IncCheckSynchronisationCounter(void)
/*~-1*/
{
   /*~T*/
   g_SystemControl.chCheckSynchronisationCounter++;
/*~-1*/
}
/*~E:F139*/
/*~E:A138*/
/*~-1*/
#endif
/*~E:I137*/
/*~A:140*/
/*~+:void 			System_Ini(unsigned char chMode)*/
/*~F:141*/
void System_Ini(unsigned char chMode)
/*~-1*/
{
   /*~A:142*/
   /*~+:Variablendeklarationen*/
   /*~T*/
   unsigned char chRetries;
   unsigned long ulOperatingHoursInitCode;

   /*~E:A142*/
   /*~A:143*/
   /*~+:Variableninitialisierungen*/
   /*~T*/
   g_SystemControl.byMRWManagerMode = 1;		///< MRW-Manager-Mode
   g_SystemControl.chSyncErrorCounter = 0;
   g_SystemControl.bCheckSynchronisationOn = 1;
   g_SystemControl.bySimulate = 0;

   /*~T*/
   ulOperatingHoursInitCode = 0;
   chRetries = 0;

   /*~I:144*/
#ifndef NO_STARTSYNC 
   /*~T*/
   g_SystemControl.chSystemSynchronized = 0;
   /*~O:I144*/
   /*~-1*/
#else
   /*~T*/
   g_SystemControl.chSystemSynchronized = 1;
   /*~-1*/
#endif
   /*~E:I144*/
   /*~E:A143*/
   /*~I:145*/
   if (chMode)
   /*~-1*/
   {
      /*~A:146*/
      /*~+:System-ID laden*/
      /*~T*/
      // SystemID laden
      Load_Parameter(LOAD_SAVE_SYSTEM_ID,&Global.ulSystemID,4);
      /*~E:A146*/
      /*~A:147*/
      /*~+:Artikelnummer und Seriennummer laden*/
      /*~T*/
      // Artikelnummer laden
      System_GetItemNumber();
      // Seriennummer laden
      System_GetSerialNumber();

      /*~E:A147*/
      /*~A:148*/
      /*~+:Zellentyp laden*/
      /*~T*/
      // Zellentyp laden
      /*~T*/
      Load_Parameter(LOAD_SAVE_CELLTYPE,&g_SystemControl.byLoadCellType,1);
      /*~E:A148*/
   /*~-1*/
   }
   /*~O:I145*/
   /*~-2*/
   else
   {
      /*~A:149*/
      /*~+:System-ID nullen*/
      /*~T*/
      // SystemID auf 0 setzen
      Global.ulSystemID = 0;

      Save_Parameter(LOAD_SAVE_SYSTEM_ID,&Global.ulSystemID,4);
      /*~E:A149*/
      /*~A:150*/
      /*~+:Artikelnummer und Seriennummer l�schen*/
      /*~T*/
      // Artikelnummer l�schen
      System_SetItemNumber("");
      // Seriennummer l�schen
      System_SetSerialNumber("");

      /*~E:A150*/
      /*~I:151*/
#ifdef MOF
      /*~A:152*/
      /*~+:Zellentyp nullen*/
      /*~T*/
      // Zellentyp nullen
      /*~T*/
      g_SystemControl.byLoadCellType = 0;

      // speichern
      Save_Parameter(LOAD_SAVE_CELLTYPE,&g_SystemControl.byLoadCellType,1);
      /*~E:A152*/
      /*~-1*/
#endif
      /*~E:I151*/
      /*~A:153*/
      /*~+:Zellentyp auf Standard-Zelle setzen*/
      /*~T*/
      // Zellentyp nullen
      /*~T*/
      g_SystemControl.byLoadCellType = 1;

      // speichern
      Save_Parameter(LOAD_SAVE_CELLTYPE,&g_SystemControl.byLoadCellType,1);
      /*~E:A153*/
   /*~-1*/
   }
   /*~E:I145*/
   /*~A:154*/
   /*~+:Betriebsstundenz�hler initialisieren*/
   /*~U:155*/
   /*~-2*/
   do
   {
      /*~T*/
      Load_Parameter(LOAD_SAVE_OPERATING_HOURS_INITCODE,&ulOperatingHoursInitCode,4);
      /*~I:156*/
      if (ulOperatingHoursInitCode == 0x5A5A5A5A)
      /*~-1*/
      {
         /*~A:157*/
         /*~+:Betriebsstundenz�hler bereits initialisiert - Laden der Z�hlerst�nde*/
         /*~T*/
         // und laden
         Load_Parameter(LOAD_SAVE_OPERATING_HOURS,&OPERATINGHOURS,4);
         Load_Parameter(LOAD_SAVE_OPERATING_HOURS_2,&CUSTOMTIMER,4);
         /*~E:A157*/
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:I156*/
   /*~-1*/
   }
   /*~O:U155*/
   while (chRetries++ < 3);
   /*~E:U155*/
   /*~I:158*/
   if (ulOperatingHoursInitCode != 0x5A5A5A5A)
   /*~-1*/
   {
      /*~A:159*/
      /*~+:Betriebsstundenz�hler noch nicht initialisiert - Z�hlerst�nde nullen und speichern*/
      /*~T*/
      // Initialsiierungscode nicht gefunden 

      // Initialsiierungscode setzen
      ulOperatingHoursInitCode = 0x5A5A5A5A;
      // und speichern
      Save_Parameter(LOAD_SAVE_OPERATING_HOURS_INITCODE,&ulOperatingHoursInitCode,4);

      // Betriebsstundenz�hler nullen
      OPERATINGHOURS = 0;
      CUSTOMTIMER = 0;
      // und speichern
      Save_Parameter(LOAD_SAVE_OPERATING_HOURS,&OPERATINGHOURS,4);
      Save_Parameter(LOAD_SAVE_OPERATING_HOURS_2,&CUSTOMTIMER,4);
      /*~E:A159*/
   /*~-1*/
   }
   /*~E:I158*/
   /*~E:A154*/
   /*~T*/
   // Administratorcode bilden
   Global.ulAdminCode = System_BuildAdminCode();  
   /*~A:160*/
   /*~+:Synchronisation-Pr�fung ein-/ausschalten*/
   /*~I:161*/
#ifdef NO_SYNC_CHECK 
   /*~T*/
   System_SetCheckSynchronisation(0);
   /*~O:I161*/
   /*~-1*/
#else
   /*~T*/
   System_SetCheckSynchronisation(1);
   /*~-1*/
#endif
   /*~E:I161*/
   /*~E:A160*/
/*~-1*/
}
/*~E:F141*/
/*~E:A140*/
/*~A:162*/
/*~+:unsigned char	System_IsConnected2MRW_Manager(void)*/
/*~F:163*/
unsigned char System_IsConnected2MRW_Manager(void)
/*~-1*/
{
   /*~T*/
   return g_SystemControl.byMRWManagerMode;
/*~-1*/
}
/*~E:F163*/
/*~E:A162*/
/*~I:164*/
#ifdef MOF
/*~A:165*/
/*~+:void 			System_ReleaseExternalInterrupt(void)*/
/*~F:166*/
void System_ReleaseExternalInterrupt(void)
/*~-1*/
{
   /*~A:167*/
   /*~+:Variablendeklarationen*/
   /*~T*/
   char ch;
   /*~E:A167*/
   /*~A:168*/
   /*~+:Variablendeklarationen*/
   /*~T*/
   ch = 0;
   /*~E:A168*/
   /*~T*/
   // Release Leitung auf HIGH -> Vorbereitung zum Interrupt
   SYSTEM_INSTUCTIONDECODER_RELEASE_LINE = 1;
   /*~L:169*/
   while (ch < 5)
   /*~-1*/
   {
      /*~T*/
      ch++;
   /*~-1*/
   }
   /*~E:L169*/
   /*~T*/
   // Release Leitung auf LOW -> Interrupt
   SYSTEM_INSTUCTIONDECODER_RELEASE_LINE = 0;
/*~-1*/
}
/*~E:F166*/
/*~E:A165*/
/*~-1*/
#endif
/*~E:I164*/
/*~A:170*/
/*~+:void 			System_Reset(void)*/
/*~F:171*/
void System_Reset(void)
/*~-1*/
{
   /*~L:172*/
   while (1)
   /*~-1*/
   {
      /*~T*/

   /*~-1*/
   }
   /*~E:L172*/
/*~-1*/
}
/*~E:F171*/
/*~E:A170*/
/*~A:173*/
/*~+:void 			System_SaveOperatingHours(void)*/
/*~F:174*/
void System_SaveOperatingHours(void)
/*~-1*/
{
   /*~K*/
   /*~+:Aufruf jede Sekunde*/
   /*~T*/
   // soll direkt gespeichert werden oder sind 15 Minuten rum?

   // und speichern
   Save_Parameter(LOAD_SAVE_OPERATING_HOURS,&OPERATINGHOURS,4);
   Save_Parameter(LOAD_SAVE_OPERATING_HOURS_2,&CUSTOMTIMER,4);
/*~-1*/
}
/*~E:F174*/
/*~E:A173*/
/*~A:175*/
/*~+:void 			System_SetCheckSynchronisation(unsigned char chOnOff)*/
/*~F:176*/
void System_SetCheckSynchronisation(unsigned char chOnOff)
/*~-1*/
{
   /*~T*/
   g_SystemControl.bCheckSynchronisationOn = chOnOff; 
/*~-1*/
}
/*~E:F176*/
/*~E:A175*/
/*~A:177*/
/*~+:char 			System_SetItemNumber(char *szItemNumber2Set)*/
/*~F:178*/
char System_SetItemNumber(char *szItemNumber2Set)
/*~-1*/
{
   /*~T*/
   strncpy(g_SystemControl.szItemNumber,szItemNumber2Set,11);

   // und speichern
   return Save_Parameter(LOAD_SAVE_ARTICLENUMBER,szItemNumber2Set,0);
/*~-1*/
}
/*~E:F178*/
/*~E:A177*/
/*~A:179*/
/*~+:char 			System_SetSerialNumber(char *szSerialNumber2Set)*/
/*~F:180*/
char System_SetSerialNumber(char *szSerialNumber2Set)
/*~-1*/
{
   /*~T*/
   strncpy(g_SystemControl.szSerialNumber,szSerialNumber2Set,13);

   // und speichern
   return Save_Parameter(LOAD_SAVE_SERIALNUMBER,szSerialNumber2Set,0);
/*~-1*/
}
/*~E:F180*/
/*~E:A179*/
/*~A:181*/
/*~+:void 			System_SetSystemState(unsigned long ulState2Set)*/
/*~F:182*/
void System_SetSystemState(unsigned long ulState2Set)
/*~-1*/
{
   /*~I:183*/
   if (((SYSTEMSTATE >= SYSTEM_REC_CHARACTERISTICS_ON)&&(SYSTEMSTATE <= SYSTEM_REC_CHARACTERISTICS_OKAY))||(ulState2Set == SYSTEM_REC_CHARACTERISTICS_ON))
   /*~-1*/
   {
      /*~T*/
      // System befindet sich im Zustand "Kennlinienaufnahme
      /*~I:184*/
      if (ulState2Set != SYSTEM_ERROR)
      /*~-1*/
      {
         /*~T*/
         // Systemfehler werden unterdr�ckt
         SYSTEMSTATE = ulState2Set; 
      /*~-1*/
      }
      /*~E:I184*/
   /*~-1*/
   }
   /*~O:I183*/
   /*~-2*/
   else
   {
      /*~I:185*/
      // Systemstatus kann nur gesetzt werden, wenn das System nicht im Fehlerzustand ist !
      if (SYSTEMSTATE != SYSTEM_ERROR)
      /*~-1*/
      {
         /*~T*/
         SYSTEMSTATE = ulState2Set; 
      /*~-1*/
      }
      /*~E:I185*/
   /*~-1*/
   }
   /*~E:I183*/
/*~-1*/
}
/*~E:F182*/
/*~E:A181*/
/*~A:186*/
/*~+:void 			System_Synchronization(void)*/
/*~F:187*/
void System_Synchronization(void)
/*~-1*/
{
   /*~I:188*/
#ifndef NO_STARTSYNC
   /*~A:189*/
   /*~+:Variablendeklarationen*/
   /*~I:190*/
#ifdef CHANNEL_0
   /*~T*/
   unsigned char chRetVal;
   /*~-1*/
#endif
   /*~E:I190*/
   /*~I:191*/
#ifdef CHANNEL_1
   /*~T*/
   unsigned char byReceivedString[40];
   /*~-1*/
#endif
   /*~E:I191*/
   /*~E:A189*/
   /*~A:192*/
   /*~+:Variableninitialisierungen*/
   /*~T*/

   /*~E:A192*/
   /*~A:193*/
   /*~+:Kanal 0*/
   /*~I:194*/
#ifdef CHANNEL_0
   /*~U:195*/
   /*~-2*/
   do
   {
      /*~T*/
      chRetVal = 1;
      /*~I:196*/
      if (!Communication_SendSPICommand("iSYN"))
      /*~-1*/
      {
         /*~I:197*/
         if (!Communication_Wait4Response())
         /*~-1*/
         {
            /*~T*/
            // ein neuer Befehl wurde empfangen
            /*~T*/
            Communication_Interpret(&(CommunicationControl.chRecBuffer[COMMUNICATION_SPI][0]));
            /*~I:198*/
            if (!strcmp(&CommunicationControl.chRecBuffer[COMMUNICATION_SPI][0],"iSYN"))
            /*~-1*/
            {
               /*~T*/
               chRetVal = 0;

            /*~-1*/
            }
            /*~E:I198*/
         /*~-1*/
         }
         /*~E:I197*/
      /*~-1*/
      }
      /*~E:I196*/
      /*~A:199*/
      /*~+:Im Fehlerfalle etwas warten*/
      /*~I:200*/
      if (chRetVal)
      /*~-1*/
      {
         /*~T*/
         // bei Misserfolg etwas warten
         System_Wait(500);
      /*~-1*/
      }
      /*~E:I200*/
      /*~E:A199*/
   /*~-1*/
   }
   /*~O:U195*/
   while (chRetVal);
   /*~E:U195*/
   /*~-1*/
#endif
   /*~E:I194*/
   /*~E:A193*/
   /*~A:201*/
   /*~+:Kanal 1*/
   /*~I:202*/
#ifdef CHANNEL_1
   /*~T*/
   g_SystemControl.chSystemSynchronized = 0;
   /*~L:203*/
   while (!g_SystemControl.chSystemSynchronized)
   /*~-1*/
   {
      /*~I:204*/
      if (!Communication_Wait4Response())
      /*~-1*/
      {
         /*~T*/
         // ein neuer Befehl wurde empfangen
         /*~T*/
         Communication_GetRecBuffer(COMMUNICATION_SPI,byReceivedString);
         /*~T*/
         Communication_Interpret(byReceivedString);
         /*~I:205*/
         if (!strcmp(byReceivedString,"iSYN"))
         /*~-1*/
         {
            /*~T*/
            // Synchronisationsbefehl senden
            /*~I:206*/
            if (!Communication_SendSPICommand("iSYN"))
            /*~-1*/
            {
               /*~T*/
               g_SystemControl.chSystemSynchronized = 1;
            /*~-1*/
            }
            /*~E:I206*/
         /*~-1*/
         }
         /*~E:I205*/
      /*~-1*/
      }
      /*~E:I204*/
   /*~-1*/
   }
   /*~E:L203*/
   /*~-1*/
#endif
   /*~E:I202*/
   /*~E:A201*/
   /*~-1*/
#endif
   /*~E:I188*/
/*~-1*/
}
/*~E:F187*/
/*~E:A186*/
/*~A:207*/
/*~+:void 			System_SystemErrorSetWatchdog(void)*/
/*~F:208*/
void System_SystemErrorSetWatchdog(void)
/*~-1*/
{
   /*~T*/
   // Stromausgang l�schen
   ADuC836_DACClearOutput(1);

   // Systemfehler setzen
   System_SetSystemState(SYSTEM_ERROR);

   // Digitalkan�le setzen
   Digital();

   // System-Reset ausf�hren
   System_Reset();
/*~-1*/
}
/*~E:F208*/
/*~E:A207*/
/*~A:209*/
/*~+:void 			System_UpdateOperatingHours(unsigned char byMode)*/
/*~F:210*/
void System_UpdateOperatingHours(unsigned char byMode)
/*~-1*/
{
   /*~K*/
   /*~+:Aufruf jede Sekunde*/
   /*~T*/
   // Betriebsstundenz�hler inkrementieren
   OPERATINGHOURS++;
   CUSTOMTIMER++;
   /*~I:211*/
   if (byMode || (!(OPERATINGHOURS % 900)))
   /*~-1*/
   {
      /*~T*/
      // soll direkt gespeichert werden oder sind 15 Minuten rum?

      // und speichern
      Save_Parameter(LOAD_SAVE_OPERATING_HOURS,&OPERATINGHOURS,4);
      Save_Parameter(LOAD_SAVE_OPERATING_HOURS_2,&CUSTOMTIMER,4);
   /*~-1*/
   }
   /*~E:I211*/
/*~-1*/
}
/*~E:F210*/
/*~E:A209*/
/*~A:212*/
/*~+:void			System_Wait(unsigned int uTimeMS)*/
/*~F:213*/
void System_Wait(unsigned int uTimeMS)
/*~-1*/
{
   /*~T*/
   ADuC836_TimerDelay(uTimeMS);
/*~-1*/
}
/*~E:F213*/
/*~E:A212*/
/*~K*/
/*~+:*/
/*~A:214*/
/*~+:void 			External_Interface(unsigned char chNbOfExtInterrupt)*/
/*~F:215*/
void External_Interface(unsigned char chNbOfExtInterrupt)
/*~-1*/
{
   /*~A:216*/
   /*~+:Variablendeklarationen*/
   /*~T*/

   /*~E:A216*/
   /*~A:217*/
   /*~+:Variableninitialisierungen*/
   /*~T*/

   /*~E:A217*/
   /*~I:218*/
   if (chNbOfExtInterrupt == 0)
   /*~-1*/
   {
      /*~T*/
      IE0 = 0;

   /*~-1*/
   }
   /*~O:I218*/
   /*~-2*/
   else
   {
      /*~T*/
      IE1 = 0;
   /*~-1*/
   }
   /*~E:I218*/
/*~-1*/
}
/*~E:F215*/
/*~E:A214*/
/*~A:219*/
/*~+:void 			Timer_Interface(void)*/
/*~F:220*/
void Timer_Interface(void)
/*~-1*/
{
   /*~A:221*/
   /*~+:Variablendeklarationen*/
   /*~I:222*/
#ifdef CHANNEL_0
   /*~I:223*/
#ifdef TIMER_TIMEBASE_1MS
   /*~T*/
   static unsigned char chCounter = 0;

   /*~-1*/
#endif
   /*~E:I223*/
   /*~-1*/
#endif
   /*~E:I222*/
   /*~E:A221*/
   /*~I:224*/
#ifdef MIT_TEACHIN_FUNKTION
   /*~I:225*/
#ifdef TIMER_TIMEBASE_10MS
   /*~A:226*/
   /*~+:Impulsgenerator f�r TeachIn-Modul - Nur Kanal 0 !*/
   /*~I:227*/
#ifdef CHANNEL_0
   /*~T*/
   // Impulsgenerator f�r TeachIn-Modul
   TeachIn_ImpulsTimer();
   /*~-1*/
#endif
   /*~E:I227*/
   /*~E:A226*/
   /*~O:I225*/
   /*~-1*/
#else
   /*~I:228*/
#ifdef TIMER_TIMEBASE_1MS
   /*~A:229*/
   /*~+:Impulsgenerator f�r TeachIn-Modul - Nur Kanal 1 !*/
   /*~I:230*/
#ifdef CHANNEL_0
   /*~I:231*/
   if (++chCounter >= 10)
   /*~-1*/
   {
      /*~T*/
      chCounter = 0;

      // Impulsgenerator f�r TeachIn-Modul
      TeachIn_ImpulsTimer();
   /*~-1*/
   }
   /*~E:I231*/
   /*~-1*/
#endif
   /*~E:I230*/
   /*~E:A229*/
   /*~-1*/
#endif
   /*~E:I228*/
   /*~-1*/
#endif
   /*~E:I225*/
   /*~-1*/
#endif
   /*~E:I224*/
/*~-1*/
}
/*~E:F220*/
/*~E:A219*/
/*~K*/
/*~+:*/
