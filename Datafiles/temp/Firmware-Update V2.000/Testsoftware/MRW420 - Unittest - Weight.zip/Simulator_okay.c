/*~-1*/
/*~XSF_LANGUAGE: C/C++*/
/*~K*/
/*~+:File :        Simulator.c*/
/*~+:*/
/*~+:Version :     V1.000*/
/*~+:*/
/*~+:Date :        18.03.2022*/
/*~+:*/
/*~+:Time :        10:23*/
/*~+:*/
/*~+:Author :      MOF*/
/*~+:*/
/*~+:Hardware :*/
/*~+:*/
/*~+:Description :*/
/*~+:*/
/*~+:*/
/*~A:1*/
/*~+:Includes*/
/*~T*/
#include "Simulator.h"
#include "System.cnd"
#include "global.h"
#include <string.h>
#include <stdio.h>
/*~E:A1*/
/*~A:2*/
/*~+:Funktionseigene Definitionen*/
/*~T*/

/*~E:A2*/
/*~A:3*/
/*~+:Funktionseigene Struktur-Definitionen*/
/*~T*/

/*~E:A3*/
/*~A:4*/
/*~+:Funktionsprototypen*/
/*~T*/

/*~E:A4*/
/*~A:5*/
/*~+:Globale Variablen*/
/*~T*/

/*~E:A5*/
/*~T*/
const long ai32SimulationTable[] = {32767, 0, 500, -32768, 0x7FFFFFFF, 0x80000000};
/*~F:6*/
long Simulator_GetRMW(void)
/*~-1*/
{
   /*~T*/
   /* Variablendeklarationen */
   long i32SimulatatedRMW;
   static unsigned short byStep = 0;
   static unsigned short bInit = 1;
   static unsigned int u16Cnt = 0;
   unsigned int u16MaxCnt;
   static long i32LastSimulatedRMW = 0L;
   long i32Step;
   int nCorVal;
   unsigned short u8FilterDepth;
   MEASUREMENT_VALUE MV;
   char szDebug[36];
   /*~T*/
   /* Variableninitialisierungen */
   i32SimulatatedRMW = 0L;

   /*~T*/
   /* Implementierung */
   /*~T*/
   Global.byTemperature = Global.bySimulatedTemperature = SYSTEM_CND_UNITTEST_SIMULATED_TEMP;
   /*~C:7*/
   switch (byStep)
   /*~-1*/
   {
      /*~F:8*/
      case 0:
      /*~-1*/
      {
         /*~I:9*/
         if (bInit != 0)
         /*~-1*/
         {
            /*~T*/
            bInit = 0;
            /*~T*/
            /* Zelle fuer die Tests parametrieren */
            Weight_SetZero(SYSTEM_CND_UNITTEST_SIMULATED_ZERO);
            AverageFilter_SetFilterDepth(WEIGHT_WEIGHTCHANNEL, SYSTEM_CND_UNITTEST_SIMULATED_FILTERDEPTH);

            /*~I:10*/
            if (SYSTEM_CND_UNITTEST_SIMULATED_TEMP != 20)
            /*~-1*/
            {
               /*~T*/
               Compensation_SetCompensationValues(SYSTEM_CND_UNITTEST_SIMULATED_TEMP, (SYSTEM_CND_UNITTEST_SIMULATED_TEMP - 20) * 20);
            /*~-1*/
            }
            /*~E:I10*/
            /*~T*/
            Communication_SendRawString(COMMUNICATION_RS232, "\r\nFirmware:;");
            Communication_SendRawString(COMMUNICATION_RS232, TEXT_SOFTWARE_VERSION);
            Communication_SendRawString(COMMUNICATION_RS232, "\r\n");

            Communication_SendRawString(COMMUNICATION_RS232, "Nullpunkt:;");
            Measurement_GetZero(WEIGHT_WEIGHTCHANNEL,&MV);
            sprintf(szDebug, "%ld", MV.nLong);
            Communication_SendRawString(COMMUNICATION_RS232, szDebug);
            Communication_SendRawString(COMMUNICATION_RS232, "\r\n");

            Communication_SendRawString(COMMUNICATION_RS232, "Kalibrierfaktor:;");
            Measurement_GetCalibrationFactor(WEIGHT_WEIGHTCHANNEL,&MV.fFloat);
            sprintf(szDebug, "%f", MV.fFloat);
            Communication_SendRawString(COMMUNICATION_RS232, szDebug);
            Communication_SendRawString(COMMUNICATION_RS232, "\r\n");

            Communication_SendRawString(COMMUNICATION_RS232, "Filtertiefe:;");
            u8FilterDepth = AverageFilter_GetFilterDepth(WEIGHT_WEIGHTCHANNEL);
            sprintf(szDebug, "%bd", u8FilterDepth);
            Communication_SendRawString(COMMUNICATION_RS232, szDebug);
            Communication_SendRawString(COMMUNICATION_RS232, "\r\n");

            Communication_SendRawString(COMMUNICATION_RS232, "Simulierte Temperatur:;");
            sprintf(szDebug, "%bd", Global.byTemperature);
            Communication_SendRawString(COMMUNICATION_RS232, szDebug);
            Communication_SendRawString(COMMUNICATION_RS232, "\r\n");

            Communication_SendRawString(COMMUNICATION_RS232, "Temperaturkorrekturwert:;");

            /*~I:11*/
            if (Global.byTemperature != 20)
            /*~-1*/
            {
               /*~T*/
               nCorVal = Compensation_GetCompensationValue((char)Global.byTemperature);

            /*~-1*/
            }
            /*~O:I11*/
            /*~-2*/
            else
            {
               /*~T*/
               nCorVal = 0;
            /*~-1*/
            }
            /*~E:I11*/
            /*~T*/
            sprintf(szDebug, "%d", nCorVal);
            Communication_SendRawString(COMMUNICATION_RS232, szDebug);
            Communication_SendRawString(COMMUNICATION_RS232, "\r\n");

            Communication_SendRawString(COMMUNICATION_RS232, "\r\n");
            Communication_SendRawString(COMMUNICATION_RS232, "Simulierter RMW");
            Communication_SendRawString(COMMUNICATION_RS232, ";RMW gefiltert");
            Communication_SendRawString(COMMUNICATION_RS232, ";RMW NP bereinigt");
            Communication_SendRawString(COMMUNICATION_RS232, ";RMW kompensiert");
            Communication_SendRawString(COMMUNICATION_RS232, ";RMW kompensiert - ohne NP");
            Communication_SendRawString(COMMUNICATION_RS232, ";Gewichtswert");
            Communication_SendRawString(COMMUNICATION_RS232, ";Brutto-Gewicht");
            Communication_SendRawString(COMMUNICATION_RS232, ";Tara-Gewicht");
            Communication_SendRawString(COMMUNICATION_RS232, ";Netto-Gewicht");
            Communication_SendRawString(COMMUNICATION_RS232, ";Netto-RMW");
            Communication_SendRawString(COMMUNICATION_RS232, "\r\n");
         /*~-1*/
         }
         /*~E:I9*/
         /*~T*/
         /* �ber Tabelle */
         /*~T*/
         u16MaxCnt = sizeof(ai32SimulationTable) / sizeof(long);

         i32SimulatatedRMW = ai32SimulationTable[u16Cnt];
         u16Cnt++;
         /*~I:12*/
         if (u16Cnt >= u16MaxCnt)
         /*~-1*/
         {
            /*~T*/
            u16Cnt = 0;
            bInit = 1;

            byStep++;
         /*~-1*/
         }
         /*~E:I12*/
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F8*/
      /*~F:13*/
      case 1:
      /*~-1*/
      {
         /*~T*/
         /* �ber Intervall */
         /*~I:14*/
#if ((SYSTEM_CND_UNITTEST_INTERVAL_END != SYSTEM_CND_UNITTEST_INTERVAL_START) && (SYSTEM_CND_UNITTEST_INTERVAL_STEP != 0)) 
         /*~T*/
         /* Set interval */
         i32Step = SYSTEM_CND_UNITTEST_INTERVAL_STEP;
         /*~I:15*/
         if ((SYSTEM_CND_UNITTEST_INTERVAL_END < SYSTEM_CND_UNITTEST_INTERVAL_START) && (SYSTEM_CND_UNITTEST_INTERVAL_STEP > 0))
         /*~-1*/
         {
            /*~T*/
            i32Step *= -1;
         /*~-1*/
         }
         /*~O:I15*/
         /*~-2*/
         else
         {
            /*~I:16*/
            if ((SYSTEM_CND_UNITTEST_INTERVAL_END > SYSTEM_CND_UNITTEST_INTERVAL_START) && (SYSTEM_CND_UNITTEST_INTERVAL_STEP < 0))
            /*~-1*/
            {
               /*~T*/
               i32Step *= -1;
            /*~-1*/
            }
            /*~E:I16*/
         /*~-1*/
         }
         /*~E:I15*/
         /*~I:17*/
         if (bInit != 0)
         /*~-1*/
         {
            /*~T*/
            bInit = 0;
            i32SimulatatedRMW = SYSTEM_CND_UNITTEST_INTERVAL_START;
         /*~-1*/
         }
         /*~O:I17*/
         /*~-2*/
         else
         {
            /*~T*/
            i32SimulatatedRMW = i32LastSimulatedRMW + i32Step;
            /*~I:18*/
            if (i32Step > 0)
            /*~-1*/
            {
               /*~I:19*/
               if ((i32SimulatatedRMW >= SYSTEM_CND_UNITTEST_INTERVAL_END) || ((i32LastSimulatedRMW > 0) && (i32SimulatatedRMW < 0L)))
               /*~-1*/
               {
                  /*~T*/
                  i32SimulatatedRMW = SYSTEM_CND_UNITTEST_INTERVAL_END;
                  byStep++; 
               /*~-1*/
               }
               /*~E:I19*/
            /*~-1*/
            }
            /*~O:I18*/
            /*~-2*/
            else
            {
               /*~I:20*/
               if ((i32SimulatatedRMW <= SYSTEM_CND_UNITTEST_INTERVAL_END) || ((i32LastSimulatedRMW < 0) && (i32SimulatatedRMW > 0L)))
               /*~-1*/
               {
                  /*~T*/
                  i32SimulatatedRMW = SYSTEM_CND_UNITTEST_INTERVAL_END;
                  byStep++; 
               /*~-1*/
               }
               /*~E:I20*/
            /*~-1*/
            }
            /*~E:I18*/
         /*~-1*/
         }
         /*~E:I17*/
         /*~T*/
         i32LastSimulatedRMW = i32SimulatatedRMW;
         /*~O:I14*/
         /*~-1*/
#else
         /*~T*/
         byStep++;
         /*~-1*/
#endif
         /*~E:I14*/
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F13*/
      /*~F:21*/
      case 2:
      /*~-1*/
      {
         /*~L:22*/
         while (1)
         /*~-1*/
         {
            /*~T*/

         /*~-1*/
         }
         /*~E:L22*/
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F21*/
   /*~-1*/
   }
   /*~E:C7*/
   /*~T*/
   /* Rueckgabe */
   return(i32SimulatatedRMW);
/*~-1*/
}
/*~E:F6*/
/*~I:23*/
#ifdef OLD
/*~F:24*/
int Simulator_GetRMW(void)
/*~-1*/
{
   /*~T*/
   static unsigned long u32TimePassedS = 0L;
   static unsigned long u32TimeStamp = 0L;
   static unsigned char byStep = 0;
   int i16SimulatatedRMW;
   float fTemperature;
   float fSlope = 0.0;
   char szDebug[36];
   unsigned char bRecCharacteristicsOn;
   /*~I:25*/
   if (MRW_Compensation_GetRecCharacteristicsOnOffStatus() != 0)
   /*~-1*/
   {
      /*~T*/
      bRecCharacteristicsOn = 1;
      /*~T*/
      /* Kennlinienaufnahme gestartet */
      /*~I:26*/
      if (Flag1000ms)
      /*~-1*/
      {
         /*~T*/
         u32TimePassedS += 1L;
      /*~-1*/
      }
      /*~E:I26*/
      /*~T*/
      /* Simuliere die Temperatur */
      /*~K*/
      /*~+:*/
      /*~C:27*/
      switch (byStep)
      /*~-1*/
      {
         /*~F:28*/
         case 0:
         /*~-1*/
         {
            /*~T*/
            /* Nullpunkt setzen */
            Weight_SetZero(SYSTEM_CND_TEST_REC_CHARACTERISTICS_OFFSET);
            /*~I:29*/
#ifdef CHANNEL_0
            /*~T*/
            Communication_SendRawString(COMMUNICATION_RS232, "Aufnahme;");
            Communication_SendRawString(COMMUNICATION_RS232, "Step;");
            Communication_SendRawString(COMMUNICATION_RS232, "Temperatur intern[�C];");
            Communication_SendRawString(COMMUNICATION_RS232, "Temperatur[�C];");
            Communication_SendRawString(COMMUNICATION_RS232, "Rohmesswert[digit];");

            Communication_SendRawString(COMMUNICATION_RS232, "Weight_MeasurementFromADC[digit];");
            Communication_SendRawString(COMMUNICATION_RS232, "Weight_ZeroCorrectedMeasurement[digit];");
            Communication_SendRawString(COMMUNICATION_RS232, "Weight_FilteredMeasurement[digit];");
            Communication_SendRawString(COMMUNICATION_RS232, "Weight_ZeroCorrectedMeasurementStandardized[kg];");

            Communication_SendRawString(COMMUNICATION_RS232, "\r\n");


            /*~-1*/
#endif
            /*~E:I29*/
            /*~T*/
            /* Zeitstempel nullen */
            u32TimeStamp = 0L;
            /*~T*/
            byStep = 1;
         /*~-1*/
         }
         /*~E:F28*/
         /*~F:30*/
         case 1:
         /*~-1*/
         {
            /*~T*/
            fTemperature = 20.0;
            /*~I:31*/
            if (u32TimePassedS >= SYSTEM_CND_TEST_REC_CHARACTERISTICS_DURATION_CAL_TEMP)
            /*~-1*/
            {
               /*~T*/
               u32TimePassedS = 0L;
               byStep = 10;
            /*~-1*/
            }
            /*~E:I31*/
            /*~T*/
            break;
         /*~-1*/
         }
         /*~E:F30*/
         /*~F:32*/
         case 10:
         /*~-1*/
         {
            /*~T*/
            fSlope = (float)(SYSTEM_CND_TEST_REC_CHARACTERISTICS_TEMP_HI - 20) / SYSTEM_CND_TEST_REC_CHARACTERISTICS_DURATION_RISE_1;

            fTemperature = 20.0 + (float)u32TimePassedS * fSlope;
            /*~I:33*/
            if (u32TimePassedS >= SYSTEM_CND_TEST_REC_CHARACTERISTICS_DURATION_RISE_1)
            /*~-1*/
            {
               /*~T*/
               u32TimePassedS = 0L;
               byStep = 20;
            /*~-1*/
            }
            /*~E:I33*/
            /*~T*/
            break;
         /*~-1*/
         }
         /*~E:F32*/
         /*~F:34*/
         case 20:
         /*~-1*/
         {
            /*~T*/
            fTemperature = SYSTEM_CND_TEST_REC_CHARACTERISTICS_TEMP_HI;
            /*~I:35*/
            if (u32TimePassedS >= SYSTEM_CND_TEST_REC_CHARACTERISTICS_DURATION_STABLE_1)
            /*~-1*/
            {
               /*~T*/
               u32TimePassedS = 0L;
               byStep = 30;
            /*~-1*/
            }
            /*~E:I35*/
            /*~T*/
            break;
         /*~-1*/
         }
         /*~E:F34*/
         /*~F:36*/
         case 30:
         /*~-1*/
         {
            /*~T*/
            fSlope = (float)(SYSTEM_CND_TEST_REC_CHARACTERISTICS_TEMP_LOW - SYSTEM_CND_TEST_REC_CHARACTERISTICS_TEMP_HI) / SYSTEM_CND_TEST_REC_CHARACTERISTICS_DURATION_FALL_1;

            fTemperature = SYSTEM_CND_TEST_REC_CHARACTERISTICS_TEMP_HI + (float)u32TimePassedS * fSlope;
            /*~I:37*/
            if (u32TimePassedS >= SYSTEM_CND_TEST_REC_CHARACTERISTICS_DURATION_FALL_1)
            /*~-1*/
            {
               /*~T*/
               u32TimePassedS = 0L;
               byStep = 40;
            /*~-1*/
            }
            /*~E:I37*/
            /*~T*/
            break;
         /*~-1*/
         }
         /*~E:F36*/
         /*~F:38*/
         case 40:
         /*~-1*/
         {
            /*~T*/
            fTemperature = SYSTEM_CND_TEST_REC_CHARACTERISTICS_TEMP_LOW;
            /*~I:39*/
            if (u32TimePassedS >= SYSTEM_CND_TEST_REC_CHARACTERISTICS_DURATION_STABLE_1)
            /*~-1*/
            {
               /*~T*/
               u32TimePassedS = 0L;
               byStep = 50;
            /*~-1*/
            }
            /*~E:I39*/
            /*~T*/
            break;
         /*~-1*/
         }
         /*~E:F38*/
         /*~F:40*/
         case 50:
         /*~-1*/
         {
            /*~T*/
            fSlope = (float)(SYSTEM_CND_TEST_REC_CHARACTERISTICS_TEMP_HI - SYSTEM_CND_TEST_REC_CHARACTERISTICS_TEMP_LOW) / SYSTEM_CND_TEST_REC_CHARACTERISTICS_DURATION_RISE_2;

            fTemperature = SYSTEM_CND_TEST_REC_CHARACTERISTICS_TEMP_LOW + (float)u32TimePassedS * fSlope;
            /*~I:41*/
            if (u32TimePassedS >= SYSTEM_CND_TEST_REC_CHARACTERISTICS_DURATION_RISE_2)
            /*~-1*/
            {
               /*~T*/
               u32TimePassedS = 0L;
               byStep = 60;
            /*~-1*/
            }
            /*~E:I41*/
            /*~T*/
            break;
         /*~-1*/
         }
         /*~E:F40*/
         /*~F:42*/
         case 60:
         /*~-1*/
         {
            /*~T*/
            fTemperature = SYSTEM_CND_TEST_REC_CHARACTERISTICS_TEMP_HI;
            /*~I:43*/
            if (u32TimePassedS >= SYSTEM_CND_TEST_REC_CHARACTERISTICS_DURATION_STABLE_1)
            /*~-1*/
            {
               /*~T*/
               u32TimePassedS = 0L;
               byStep = 70;
            /*~-1*/
            }
            /*~E:I43*/
            /*~T*/
            break;
         /*~-1*/
         }
         /*~E:F42*/
         /*~F:44*/
         case 70:
         /*~-1*/
         {
            /*~T*/
            fSlope = (float)(SYSTEM_CND_TEST_REC_CHARACTERISTICS_TEMP_LOW - SYSTEM_CND_TEST_REC_CHARACTERISTICS_TEMP_HI) / SYSTEM_CND_TEST_REC_CHARACTERISTICS_DURATION_FALL_1;

            fTemperature = SYSTEM_CND_TEST_REC_CHARACTERISTICS_TEMP_HI + (float)u32TimePassedS * fSlope;
            /*~I:45*/
            if (u32TimePassedS >= SYSTEM_CND_TEST_REC_CHARACTERISTICS_DURATION_FALL_1)
            /*~-1*/
            {
               /*~T*/
               u32TimePassedS = 0L;
               byStep = 80;
            /*~-1*/
            }
            /*~E:I45*/
            /*~T*/
            break;
         /*~-1*/
         }
         /*~E:F44*/
         /*~F:46*/
         case 80:
         /*~-1*/
         {
            /*~T*/
            fTemperature = SYSTEM_CND_TEST_REC_CHARACTERISTICS_TEMP_LOW;
            /*~I:47*/
            if (u32TimePassedS >= SYSTEM_CND_TEST_REC_CHARACTERISTICS_DURATION_STABLE_1)
            /*~-1*/
            {
               /*~T*/
               u32TimePassedS = 0L;
               byStep = 90;
            /*~-1*/
            }
            /*~E:I47*/
            /*~T*/
            break;
         /*~-1*/
         }
         /*~E:F46*/
         /*~F:48*/
         case 90:
         /*~-1*/
         {
            /*~T*/
            fSlope = (float)(20.0 - SYSTEM_CND_TEST_REC_CHARACTERISTICS_TEMP_LOW) / SYSTEM_CND_TEST_REC_CHARACTERISTICS_DURATION_RISE_3;

            fTemperature = SYSTEM_CND_TEST_REC_CHARACTERISTICS_TEMP_LOW + (float)u32TimePassedS * fSlope;
            /*~I:49*/
            if (u32TimePassedS >= SYSTEM_CND_TEST_REC_CHARACTERISTICS_DURATION_RISE_3)
            /*~-1*/
            {
               /*~T*/
               u32TimePassedS = 0L;
               byStep = 255;
            /*~-1*/
            }
            /*~E:I49*/
            /*~T*/
            break;
         /*~-1*/
         }
         /*~E:F48*/
         /*~F:50*/
         case 255:
         /*~-1*/
         {
            /*~T*/
            fTemperature = 20.0;
            /*~T*/
            break;
         /*~-1*/
         }
         /*~E:F50*/
      /*~-1*/
      }
      /*~E:C27*/
   /*~-1*/
   }
   /*~O:I25*/
   /*~-2*/
   else
   {
      /*~T*/
      bRecCharacteristicsOn = 0;

      fTemperature = 22.0;

      u32TimePassedS = 0L;
      byStep = 0;
   /*~-1*/
   }
   /*~E:I25*/
   /*~T*/
   Global.bySimulatedTemperature = (char)fTemperature;
   /*~T*/
   /* Simuliere den Rohmesswert */
   i16SimulatatedRMW = (int)(SYSTEM_CND_TEST_REC_CHARACTERISTICS_OFFSET + (fTemperature - 20.0) * SYSTEM_CND_TEST_REC_CHARACTERISTICS_GAIN);
   /*~I:51*/
   if (Flag1000ms)
   /*~-1*/
   {
      /*~I:52*/
#ifdef CHANNEL_0
      /*~T*/
      /* Debug-Ausgabe */
      //sprintf(szDebug, "%ld;%bd;%0.3f;%bd;%d\r\n", u32TimeStamp, bRecCharacteristicsOn, fTemperature, Global.bySimulatedTemperature, i16SimulatatedRMW);
      sprintf(szDebug, "%ld;%bd;%bd;%0.3f;%bd;%d", u32TimeStamp, bRecCharacteristicsOn, byStep, fTemperature, Global.bySimulatedTemperature, i16SimulatatedRMW);
      Communication_SendRawString(COMMUNICATION_RS232, szDebug);
      /*~-1*/
#endif
      /*~E:I52*/
      /*~T*/
      /* Update Timestamp */
      u32TimeStamp += 1L;
   /*~-1*/
   }
   /*~E:I51*/
   /*~T*/
   return(i16SimulatatedRMW);
/*~-1*/
}
/*~E:F24*/
/*~-1*/
#endif
/*~E:I23*/
