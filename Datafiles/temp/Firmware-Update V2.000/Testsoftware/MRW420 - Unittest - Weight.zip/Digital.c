/*~-1*/
/*~XSF_LANGUAGE: C/C++*/
/*~K*/
/*~+:File :        Digital.c*/
/*~+:*/
/*~+:Version :     V1.0*/
/*~+:*/
/*~+:Date :        09.06.2005*/
/*~+:*/
/*~+:Time :        10:23*/
/*~+:*/
/*~+:Author :      MOF*/
/*~+:*/
/*~+:Hardware :*/
/*~+:*/
/*~+:Description :*/
/*~+:*/
/*~+:*/
/*~A:1*/
/*~+:Includes*/
/*~T*/
#include "Digital.h"
#include "Global.h"
/*~E:A1*/
/*~A:2*/
/*~+:Funktionseigene Definitionen*/
/*~T*/

/*~E:A2*/
/*~A:3*/
/*~+:Funktionseigene Struktur-Definitionen*/
/*~T*/
typedef struct
{
	unsigned char chStatus;
	unsigned char chActualOnOff;
}DIGITAL_LED;
/*~E:A3*/
/*~A:4*/
/*~+:Funktionsprototypen*/
/*~T*/
void 			Digital(void);

/*~I:5*/
#ifdef CHANNEL_0
/*~T*/
void 			Digital_ClearLEDTestMode(void);
unsigned char 	Digital_GetLED(unsigned char chLed2Get);
/*~-1*/
#endif
/*~E:I5*/
/*~T*/
void 			Digital_Init(void);
/*~I:6*/
#ifdef CHANNEL_0
/*~T*/
void 			Digital_SetLED(unsigned char chLed2Set,unsigned char chStatus);
void 			Digital_SetLEDManually(unsigned char chLed2Set,unsigned char bOn);

/*~-1*/
#endif
/*~E:I6*/
/*~E:A4*/
/*~A:7*/
/*~+:Globale Variablen*/
/*~T*/
DIGITAL_LED Digital_Led[4];
DIGITAL g_Digital;
/*~E:A7*/
/*~A:8*/
/*~+:void 			Digital(void)*/
/*~F:9*/
void Digital(void)
/*~-1*/
{
   /*~A:10*/
   /*~+:Kanal 0*/
   /*~I:11*/
#ifdef CHANNEL_0
   /*~A:12*/
   /*~+:Beschreibung*/
   /*~T*/
   /*!
   \fn void Digital(void)
   
   <b>Beschreibung:</b><br>
   Setzen der Digitalen Ausg�nge anhand des Gesamtsystemstatus.
   
   \param
   ./.
   
   \return
   ./.
   
   <b>Zugriff:</b><br>
   [X] �ffentlich / [ ] Privat
   */
   /*~E:A12*/
   /*~A:13*/
   /*~+:Variablendeklarationen*/
   /*~T*/
   unsigned char chSetLedOn;
   unsigned char chLED;
   unsigned char byCounter;
   static unsigned char chOnOffToggleFlag = 0;
   /*~E:A13*/
   /*~A:14*/
   /*~+:Variableninitialsierungen*/
   /*~T*/
   byCounter = 0;
   /*~E:A14*/
   /*~A:15*/
   /*~+:Timerflags auswerten*/
   /*~I:16*/
   if (Flag100ms)
   /*~-1*/
   {
      /*~I:17*/
      if (chOnOffToggleFlag & 0x01)
      /*~-1*/
      {
         /*~T*/
         chOnOffToggleFlag &= 0xFE; 
      /*~-1*/
      }
      /*~O:I17*/
      /*~-2*/
      else
      {
         /*~T*/
         chOnOffToggleFlag |= 0x01;
      /*~-1*/
      }
      /*~E:I17*/
   /*~-1*/
   }
   /*~E:I16*/
   /*~I:18*/
   if (Flag300ms)
   /*~-1*/
   {
      /*~I:19*/
      if (chOnOffToggleFlag & 0x02)
      /*~-1*/
      {
         /*~T*/
         chOnOffToggleFlag &= 0xFD; 
      /*~-1*/
      }
      /*~O:I19*/
      /*~-2*/
      else
      {
         /*~T*/
         chOnOffToggleFlag |= 0x02;
      /*~-1*/
      }
      /*~E:I19*/
   /*~-1*/
   }
   /*~E:I18*/
   /*~I:20*/
   if (Flag500ms)
   /*~-1*/
   {
      /*~I:21*/
      if (chOnOffToggleFlag & 0x04)
      /*~-1*/
      {
         /*~T*/
         chOnOffToggleFlag &= 0xFB; 
      /*~-1*/
      }
      /*~O:I21*/
      /*~-2*/
      else
      {
         /*~T*/
         chOnOffToggleFlag |= 0x04;
      /*~-1*/
      }
      /*~E:I21*/
   /*~-1*/
   }
   /*~E:I20*/
   /*~I:22*/
   if (Flag1000ms)
   /*~-1*/
   {
      /*~I:23*/
      if (chOnOffToggleFlag & 0x08)
      /*~-1*/
      {
         /*~T*/
         chOnOffToggleFlag &= 0xF7; 
      /*~-1*/
      }
      /*~O:I23*/
      /*~-2*/
      else
      {
         /*~T*/
         chOnOffToggleFlag |= 0x08;
      /*~-1*/
      }
      /*~E:I23*/
   /*~-1*/
   }
   /*~E:I22*/
   /*~I:24*/
   if (Flag2000ms)
   /*~-1*/
   {
      /*~I:25*/
      if (chOnOffToggleFlag & 0x10)
      /*~-1*/
      {
         /*~T*/
         chOnOffToggleFlag &= 0xEF; 
      /*~-1*/
      }
      /*~O:I25*/
      /*~-2*/
      else
      {
         /*~T*/
         chOnOffToggleFlag |= 0x10;
      /*~-1*/
      }
      /*~E:I25*/
   /*~-1*/
   }
   /*~E:I24*/
   /*~I:26*/
   if (Flag10000ms)
   /*~-1*/
   {
      /*~I:27*/
      if (chOnOffToggleFlag & 0x20)
      /*~-1*/
      {
         /*~T*/
         chOnOffToggleFlag &= 0xDF; 
      /*~-1*/
      }
      /*~O:I27*/
      /*~-2*/
      else
      {
         /*~T*/
         chOnOffToggleFlag |= 0x20;
      /*~-1*/
      }
      /*~E:I27*/
   /*~-1*/
   }
   /*~E:I26*/
   /*~E:A15*/
   /*~I:28*/
   if (g_Digital.bLEDTestMode == FALSE)
   /*~-1*/
   {
      /*~C:29*/
      switch (SYSTEMSTATE)
      /*~-1*/
      {
         /*~A:30*/
         /*~+:SYSTEM_ERROR (muss immer vor dem Status SYSTEM_RUNNING stehen !!!)*/
         /*~F:31*/
         case SYSTEM_ERROR:
         /*~-1*/
         {
            /*~T*/
            Digital_SetLED(DIGITAL_LED_ST_OUT,DIGITAL_ON);
            /*~T*/
            // kein Break, damit die Nullpunkt�berwachung und die Anzeigen zum Programmlauf und Grenzwert�berschreitung angezeigt werden k�nnen
            // break;
         /*~-1*/
         }
         /*~E:F31*/
         /*~E:A30*/
         /*~A:32*/
         /*~+:SYSTEM_RUNNING*/
         /*~F:33*/
         case SYSTEM_RUNNING:	// System l�uft
         /*~-1*/
         {
            /*~T*/
            // Programmlauf-LED
            Digital_SetLED(DIGITAL_LED_P_OK,DIGITAL_TOGGLE_1000);
            /*~K*/
            /*~+:*/
            /*~I:34*/
            // Tara-Limit:
            if ((Limit_GetLimitState()& LIMIT_TARALIMIT_EXCEEDED)||(Global.chLimitStatus_Partner & LIMIT_TARALIMIT_EXCEEDED))
            /*~-1*/
            {
               /*~T*/
               // Tara-Grenzwert �berschritten
               Digital_SetLED(DIGITAL_LED_ST_IN,DIGITAL_OFF);
            /*~-1*/
            }
            /*~O:I34*/
            /*~-2*/
            else
            {
               /*~T*/
               Digital_SetLED(DIGITAL_LED_ST_IN,DIGITAL_ON);
            /*~-1*/
            }
            /*~E:I34*/
            /*~K*/
            /*~+:*/
            /*~I:35*/
            if (SYSTEMSTATE == SYSTEM_RUNNING)	// Achtung - es kann hier auch SYSTEM_ERROR anstehen
            /*~-1*/
            {
               /*~I:36*/
               // Grenzwertalarm:
               if ((Limit_GetLimitState()& LIMIT_HANGINGLIMT_EXCEEDED)||(Limit_GetLimitState()& LIMIT_ALARMLIMIT_EXCEEDED))
               /*~-1*/
               {
                  /*~T*/
                  Digital_SetLED(DIGITAL_LED_ST_OUT,DIGITAL_TOGGLE_1000);
               /*~-1*/
               }
               /*~O:I36*/
               /*~-2*/
               else
               {
                  /*~T*/
                  Digital_SetLED(DIGITAL_LED_ST_OUT,DIGITAL_OFF);
               /*~-1*/
               }
               /*~E:I36*/
               /*~I:37*/
               // Grenzwertalarm:
               if ((Global.chLimitStatus_Partner & LIMIT_HANGINGLIMT_EXCEEDED)||(Global.chLimitStatus_Partner & LIMIT_ALARMLIMIT_EXCEEDED))
               /*~-1*/
               {
                  /*~T*/
                  Digital_SetLED(DIGITAL_LED_ST_OUT_CH1,DIGITAL_TOGGLE_1000);
               /*~-1*/
               }
               /*~O:I37*/
               /*~-2*/
               else
               {
                  /*~T*/
                  Digital_SetLED(DIGITAL_LED_ST_OUT_CH1,DIGITAL_OFF);
               /*~-1*/
               }
               /*~E:I37*/
            /*~-1*/
            }
            /*~E:I35*/
            /*~T*/
            break;
         /*~-1*/
         }
         /*~E:F33*/
         /*~E:A32*/
         /*~A:38*/
         /*~+:SYSTEM_REC_CHARACTERISTICS_ON*/
         /*~F:39*/
         case SYSTEM_REC_CHARACTERISTICS_ON:
         /*~-1*/
         {
            /*~T*/
            Digital_SetLED(DIGITAL_LED_ST_IN,DIGITAL_ON);
            Digital_SetLED(DIGITAL_LED_P_OK,DIGITAL_ON);
            // Digital_SetLED(DIGITAL_LED_ST_IN,DIGITAL_TOGGLE_2000);
            // Digital_SetLED(DIGITAL_LED_P_OK,DIGITAL_TOGGLE_2000);
            /*~T*/
            break;
         /*~-1*/
         }
         /*~E:F39*/
         /*~E:A38*/
         /*~A:40*/
         /*~+:SYSTEM_REC_CHARACTERISTICS_1ST_DRIFT*/
         /*~F:41*/
         case SYSTEM_REC_CHARACTERISTICS_1ST_DRIFT:
         /*~-1*/
         {
            /*~T*/
            Digital_SetLED(DIGITAL_LED_ST_IN,DIGITAL_TOGGLE_1000_INV);
            Digital_SetLED(DIGITAL_LED_P_OK,DIGITAL_TOGGLE_1000);
            /*~T*/
            break;
         /*~-1*/
         }
         /*~E:F41*/
         /*~E:A40*/
         /*~A:42*/
         /*~+:SYSTEM_REC_CHARACTERISTICS_ERROR*/
         /*~F:43*/
         case SYSTEM_REC_CHARACTERISTICS_ERROR:
         /*~-1*/
         {
            /*~T*/
            Digital_SetLED(DIGITAL_LED_ST_IN,DIGITAL_OFF);
            Digital_SetLED(DIGITAL_LED_P_OK,DIGITAL_OFF);

            /*~T*/
            break;
         /*~-1*/
         }
         /*~E:F43*/
         /*~E:A42*/
         /*~A:44*/
         /*~+:SYSTEM_REC_CHARACTERISTICS_OKAY*/
         /*~F:45*/
         case SYSTEM_REC_CHARACTERISTICS_OKAY:
         /*~-1*/
         {
            /*~T*/
            Digital_SetLED(DIGITAL_LED_ST_IN,DIGITAL_TOGGLE_1000);
            Digital_SetLED(DIGITAL_LED_P_OK,DIGITAL_TOGGLE_1000);

            /*~T*/
            break;
         /*~-1*/
         }
         /*~E:F45*/
         /*~E:A44*/
      /*~-1*/
      }
      /*~E:C29*/
      /*~K*/
      /*~+:// Partner-Status*/
      /*~C:46*/
      switch (SYSTEMSTATE_PARTNER)
      /*~-1*/
      {
         /*~A:47*/
         /*~+:SYSTEM_REC_CHARACTERISTICS_ON*/
         /*~F:48*/
         case SYSTEM_REC_CHARACTERISTICS_ON:
         /*~-1*/
         {
            /*~T*/
            Digital_SetLED(DIGITAL_LED_ST_OUT,DIGITAL_ON);
            Digital_SetLED(DIGITAL_LED_ST_OUT_CH1,DIGITAL_ON);
            // Digital_SetLED(DIGITAL_LED_ST_OUT,DIGITAL_TOGGLE_2000);
            // Digital_SetLED(DIGITAL_LED_ST_OUT_CH1,DIGITAL_TOGGLE_2000);

            /*~T*/
            break;
         /*~-1*/
         }
         /*~E:F48*/
         /*~E:A47*/
         /*~A:49*/
         /*~+:SYSTEM_REC_CHARACTERISTICS_1ST_DRIFT*/
         /*~F:50*/
         case SYSTEM_REC_CHARACTERISTICS_1ST_DRIFT:
         /*~-1*/
         {
            /*~T*/
            Digital_SetLED(DIGITAL_LED_ST_OUT,DIGITAL_TOGGLE_1000_INV);
            Digital_SetLED(DIGITAL_LED_ST_OUT_CH1,DIGITAL_TOGGLE_1000);

            /*~T*/
            break;
         /*~-1*/
         }
         /*~E:F50*/
         /*~E:A49*/
         /*~A:51*/
         /*~+:SYSTEM_REC_CHARACTERISTICS_ERROR*/
         /*~F:52*/
         case SYSTEM_REC_CHARACTERISTICS_ERROR:
         /*~-1*/
         {
            /*~T*/
            Digital_SetLED(DIGITAL_LED_ST_OUT,DIGITAL_OFF);
            Digital_SetLED(DIGITAL_LED_ST_OUT_CH1,DIGITAL_OFF);

            /*~T*/
            break;
         /*~-1*/
         }
         /*~E:F52*/
         /*~E:A51*/
         /*~A:53*/
         /*~+:SYSTEM_REC_CHARACTERISTICS_OKAY*/
         /*~F:54*/
         case SYSTEM_REC_CHARACTERISTICS_OKAY:
         /*~-1*/
         {
            /*~T*/
            Digital_SetLED(DIGITAL_LED_ST_OUT,DIGITAL_TOGGLE_1000);
            Digital_SetLED(DIGITAL_LED_ST_OUT_CH1,DIGITAL_TOGGLE_1000);

            /*~T*/
            break;
         /*~-1*/
         }
         /*~E:F54*/
         /*~E:A53*/
         /*~A:55*/
         /*~+:SYSTEM_ERROR*/
         /*~F:56*/
         case SYSTEM_ERROR:
         /*~-1*/
         {
            /*~T*/
            // Systemfehler signalisieren
            Digital_SetLED(DIGITAL_LED_ST_OUT_CH1,DIGITAL_ON); 
            /*~T*/
            break;
         /*~-1*/
         }
         /*~E:F56*/
         /*~E:A55*/
      /*~-1*/
      }
      /*~E:C46*/
      /*~K*/
      /*~+:*/
   /*~-1*/
   }
   /*~E:I28*/
   /*~A:57*/
   /*~+:Leds gem�� ihrem Status ein-/ausschalten*/
   /*~L:58*/
   for (chLED = 0;chLED < 4; chLED++)
   /*~-1*/
   {
      /*~C:59*/
      switch (chLED)
      /*~-1*/
      {
         /*~A:60*/
         /*~+:DIGITAL_LED_ST_IN*/
         /*~F:61*/
         case DIGITAL_LED_ST_IN:
         /*~-1*/
         {
            /*~C:62*/
            switch (Digital_GetLED(DIGITAL_LED_ST_IN))
            /*~-1*/
            {
               /*~A:63*/
               /*~+:DIGITAL_ON*/
               /*~F:64*/
               case DIGITAL_ON:
               /*~-1*/
               {
                  /*~T*/
                  chSetLedOn = 1;
                  /*~T*/
                  break;
               /*~-1*/
               }
               /*~E:F64*/
               /*~E:A63*/
               /*~A:65*/
               /*~+:DIGITAL_OFF*/
               /*~F:66*/
               case DIGITAL_OFF:
               /*~-1*/
               {
                  /*~T*/
                  chSetLedOn = 0;
                  /*~T*/
                  break;
               /*~-1*/
               }
               /*~E:F66*/
               /*~E:A65*/
               /*~A:67*/
               /*~+:DIGITAL_TOGGLE_XXX_xxx*/
               /*~F:68*/
               case DIGITAL_TOGGLE_100:
               /*~-1*/
               {
                  /*~I:69*/
                  if (chOnOffToggleFlag & 0x01)
                  /*~-1*/
                  {
                     /*~T*/
                     chSetLedOn = 1;
                  /*~-1*/
                  }
                  /*~O:I69*/
                  /*~-2*/
                  else
                  {
                     /*~T*/
                     chSetLedOn = 0;
                  /*~-1*/
                  }
                  /*~E:I69*/
                  /*~T*/
                  break;
               /*~-1*/
               }
               /*~E:F68*/
               /*~F:70*/
               case DIGITAL_TOGGLE_100_INV:
               /*~-1*/
               {
                  /*~I:71*/
                  if (chOnOffToggleFlag & 0x01)
                  /*~-1*/
                  {
                     /*~T*/
                     chSetLedOn = 0;
                  /*~-1*/
                  }
                  /*~O:I71*/
                  /*~-2*/
                  else
                  {
                     /*~T*/
                     chSetLedOn = 1;
                  /*~-1*/
                  }
                  /*~E:I71*/
                  /*~T*/
                  break;
               /*~-1*/
               }
               /*~E:F70*/
               /*~F:72*/
               case DIGITAL_TOGGLE_300:
               /*~-1*/
               {
                  /*~I:73*/
                  if (chOnOffToggleFlag & 0x02)
                  /*~-1*/
                  {
                     /*~T*/
                     chSetLedOn = 1;
                  /*~-1*/
                  }
                  /*~O:I73*/
                  /*~-2*/
                  else
                  {
                     /*~T*/
                     chSetLedOn = 0;
                  /*~-1*/
                  }
                  /*~E:I73*/
                  /*~T*/
                  break;
               /*~-1*/
               }
               /*~E:F72*/
               /*~F:74*/
               case DIGITAL_TOGGLE_300_INV:
               /*~-1*/
               {
                  /*~I:75*/
                  if (chOnOffToggleFlag & 0x02)
                  /*~-1*/
                  {
                     /*~T*/
                     chSetLedOn = 0;
                  /*~-1*/
                  }
                  /*~O:I75*/
                  /*~-2*/
                  else
                  {
                     /*~T*/
                     chSetLedOn = 1;
                  /*~-1*/
                  }
                  /*~E:I75*/
                  /*~T*/
                  break;
               /*~-1*/
               }
               /*~E:F74*/
               /*~F:76*/
               case DIGITAL_TOGGLE_500:
               /*~-1*/
               {
                  /*~I:77*/
                  if (chOnOffToggleFlag & 0x04)
                  /*~-1*/
                  {
                     /*~T*/
                     chSetLedOn = 1;
                  /*~-1*/
                  }
                  /*~O:I77*/
                  /*~-2*/
                  else
                  {
                     /*~T*/
                     chSetLedOn = 0;
                  /*~-1*/
                  }
                  /*~E:I77*/
                  /*~T*/
                  break;
               /*~-1*/
               }
               /*~E:F76*/
               /*~F:78*/
               case DIGITAL_TOGGLE_500_INV:
               /*~-1*/
               {
                  /*~I:79*/
                  if (chOnOffToggleFlag & 0x04)
                  /*~-1*/
                  {
                     /*~T*/
                     chSetLedOn = 0;
                  /*~-1*/
                  }
                  /*~O:I79*/
                  /*~-2*/
                  else
                  {
                     /*~T*/
                     chSetLedOn = 1;
                  /*~-1*/
                  }
                  /*~E:I79*/
                  /*~T*/
                  break;
               /*~-1*/
               }
               /*~E:F78*/
               /*~F:80*/
               case DIGITAL_TOGGLE_1000:
               /*~-1*/
               {
                  /*~I:81*/
                  if (chOnOffToggleFlag & 0x08)
                  /*~-1*/
                  {
                     /*~T*/
                     chSetLedOn = 1;
                  /*~-1*/
                  }
                  /*~O:I81*/
                  /*~-2*/
                  else
                  {
                     /*~T*/
                     chSetLedOn = 0;
                  /*~-1*/
                  }
                  /*~E:I81*/
                  /*~T*/
                  break;
               /*~-1*/
               }
               /*~E:F80*/
               /*~F:82*/
               case DIGITAL_TOGGLE_1000_INV:
               /*~-1*/
               {
                  /*~I:83*/
                  if (chOnOffToggleFlag & 0x08)
                  /*~-1*/
                  {
                     /*~T*/
                     chSetLedOn = 0;
                  /*~-1*/
                  }
                  /*~O:I83*/
                  /*~-2*/
                  else
                  {
                     /*~T*/
                     chSetLedOn = 1;
                  /*~-1*/
                  }
                  /*~E:I83*/
                  /*~T*/
                  break;
               /*~-1*/
               }
               /*~E:F82*/
               /*~F:84*/
               case DIGITAL_TOGGLE_2000:
               /*~-1*/
               {
                  /*~I:85*/
                  if (chOnOffToggleFlag & 0x10)
                  /*~-1*/
                  {
                     /*~T*/
                     chSetLedOn = 1;
                  /*~-1*/
                  }
                  /*~O:I85*/
                  /*~-2*/
                  else
                  {
                     /*~T*/
                     chSetLedOn = 0;
                  /*~-1*/
                  }
                  /*~E:I85*/
                  /*~T*/
                  break;
               /*~-1*/
               }
               /*~E:F84*/
               /*~F:86*/
               case DIGITAL_TOGGLE_2000_INV:
               /*~-1*/
               {
                  /*~I:87*/
                  if (chOnOffToggleFlag & 0x10)
                  /*~-1*/
                  {
                     /*~T*/
                     chSetLedOn = 0;
                  /*~-1*/
                  }
                  /*~O:I87*/
                  /*~-2*/
                  else
                  {
                     /*~T*/
                     chSetLedOn = 1;
                  /*~-1*/
                  }
                  /*~E:I87*/
                  /*~T*/
                  break;
               /*~-1*/
               }
               /*~E:F86*/
               /*~F:88*/
               case DIGITAL_TOGGLE_10000:
               /*~-1*/
               {
                  /*~I:89*/
                  if (chOnOffToggleFlag & 0x20)
                  /*~-1*/
                  {
                     /*~T*/
                     chSetLedOn = 1;
                  /*~-1*/
                  }
                  /*~O:I89*/
                  /*~-2*/
                  else
                  {
                     /*~T*/
                     chSetLedOn = 0;
                  /*~-1*/
                  }
                  /*~E:I89*/
                  /*~T*/
                  break;
               /*~-1*/
               }
               /*~E:F88*/
               /*~F:90*/
               case DIGITAL_TOGGLE_10000_INV:
               /*~-1*/
               {
                  /*~I:91*/
                  if (chOnOffToggleFlag & 0x20)
                  /*~-1*/
                  {
                     /*~T*/
                     chSetLedOn = 0;
                  /*~-1*/
                  }
                  /*~O:I91*/
                  /*~-2*/
                  else
                  {
                     /*~T*/
                     chSetLedOn = 1;
                  /*~-1*/
                  }
                  /*~E:I91*/
                  /*~T*/
                  break;
               /*~-1*/
               }
               /*~E:F90*/
               /*~E:A67*/
               /*~A:92*/
               /*~+:DIGITAL_FLASH_MODE_1*/
               /*~F:93*/
               case DIGITAL_FLASH_MODE_1:
               /*~-1*/
               {
                  /*~I:94*/
                  if ((Flag1000ms)&&(P07))
                  /*~-1*/
                  {
                     /*~T*/
                     chSetLedOn = 1;
                  /*~-1*/
                  }
                  /*~O:I94*/
                  /*~-2*/
                  else
                  {
                     /*~I:95*/
                     if ((Flag100ms)&&(!P07))
                     /*~-1*/
                     {
                        /*~T*/
                        chSetLedOn = 0;
                     /*~-1*/
                     }
                     /*~E:I95*/
                  /*~-1*/
                  }
                  /*~E:I94*/
                  /*~T*/
                  break;
               /*~-1*/
               }
               /*~E:F93*/
               /*~E:A92*/
            /*~-1*/
            }
            /*~E:C62*/
            /*~I:96*/
            if (chSetLedOn)
            /*~-1*/
            {
               /*~I:97*/
#ifndef LEDS_4_DEBUG
               /*~T*/
               P07 = 0;
               /*~-1*/
#endif
               /*~E:I97*/
               /*~T*/
               Digital_Led[chLED].chActualOnOff = DIGITAL_ON;
            /*~-1*/
            }
            /*~O:I96*/
            /*~-2*/
            else
            {
               /*~I:98*/
#ifndef LEDS_4_DEBUG 
               /*~T*/
               P07 = 1;
               /*~-1*/
#endif
               /*~E:I98*/
               /*~T*/
               Digital_Led[chLED].chActualOnOff = DIGITAL_OFF;
            /*~-1*/
            }
            /*~E:I96*/
            /*~T*/
            break;
         /*~-1*/
         }
         /*~E:F61*/
         /*~E:A60*/
         /*~A:99*/
         /*~+:DIGITAL_LED_P_OK*/
         /*~F:100*/
         case DIGITAL_LED_P_OK:
         /*~-1*/
         {
            /*~C:101*/
            switch (Digital_GetLED(DIGITAL_LED_P_OK))
            /*~-1*/
            {
               /*~A:102*/
               /*~+:DIGITAL_ON*/
               /*~F:103*/
               case DIGITAL_ON:
               /*~-1*/
               {
                  /*~T*/
                  chSetLedOn = 1;
                  /*~T*/
                  break;
               /*~-1*/
               }
               /*~E:F103*/
               /*~E:A102*/
               /*~A:104*/
               /*~+:DIGITAL_OFF*/
               /*~F:105*/
               case DIGITAL_OFF:
               /*~-1*/
               {
                  /*~T*/
                  chSetLedOn = 0;
                  /*~T*/
                  break;
               /*~-1*/
               }
               /*~E:F105*/
               /*~E:A104*/
               /*~A:106*/
               /*~+:DIGITAL_TOGGLE_XXX_xxx*/
               /*~F:107*/
               case DIGITAL_TOGGLE_100:
               /*~-1*/
               {
                  /*~I:108*/
                  if (chOnOffToggleFlag & 0x01)
                  /*~-1*/
                  {
                     /*~T*/
                     chSetLedOn = 1;
                  /*~-1*/
                  }
                  /*~O:I108*/
                  /*~-2*/
                  else
                  {
                     /*~T*/
                     chSetLedOn = 0;
                  /*~-1*/
                  }
                  /*~E:I108*/
                  /*~T*/
                  break;
               /*~-1*/
               }
               /*~E:F107*/
               /*~F:109*/
               case DIGITAL_TOGGLE_100_INV:
               /*~-1*/
               {
                  /*~I:110*/
                  if (chOnOffToggleFlag & 0x01)
                  /*~-1*/
                  {
                     /*~T*/
                     chSetLedOn = 0;
                  /*~-1*/
                  }
                  /*~O:I110*/
                  /*~-2*/
                  else
                  {
                     /*~T*/
                     chSetLedOn = 1;
                  /*~-1*/
                  }
                  /*~E:I110*/
                  /*~T*/
                  break;
               /*~-1*/
               }
               /*~E:F109*/
               /*~F:111*/
               case DIGITAL_TOGGLE_300:
               /*~-1*/
               {
                  /*~I:112*/
                  if (chOnOffToggleFlag & 0x02)
                  /*~-1*/
                  {
                     /*~T*/
                     chSetLedOn = 1;
                  /*~-1*/
                  }
                  /*~O:I112*/
                  /*~-2*/
                  else
                  {
                     /*~T*/
                     chSetLedOn = 0;
                  /*~-1*/
                  }
                  /*~E:I112*/
                  /*~T*/
                  break;
               /*~-1*/
               }
               /*~E:F111*/
               /*~F:113*/
               case DIGITAL_TOGGLE_300_INV:
               /*~-1*/
               {
                  /*~I:114*/
                  if (chOnOffToggleFlag & 0x02)
                  /*~-1*/
                  {
                     /*~T*/
                     chSetLedOn = 0;
                  /*~-1*/
                  }
                  /*~O:I114*/
                  /*~-2*/
                  else
                  {
                     /*~T*/
                     chSetLedOn = 1;
                  /*~-1*/
                  }
                  /*~E:I114*/
                  /*~T*/
                  break;
               /*~-1*/
               }
               /*~E:F113*/
               /*~F:115*/
               case DIGITAL_TOGGLE_500:
               /*~-1*/
               {
                  /*~I:116*/
                  if (chOnOffToggleFlag & 0x04)
                  /*~-1*/
                  {
                     /*~T*/
                     chSetLedOn = 1;
                  /*~-1*/
                  }
                  /*~O:I116*/
                  /*~-2*/
                  else
                  {
                     /*~T*/
                     chSetLedOn = 0;
                  /*~-1*/
                  }
                  /*~E:I116*/
                  /*~T*/
                  break;
               /*~-1*/
               }
               /*~E:F115*/
               /*~F:117*/
               case DIGITAL_TOGGLE_500_INV:
               /*~-1*/
               {
                  /*~I:118*/
                  if (chOnOffToggleFlag & 0x04)
                  /*~-1*/
                  {
                     /*~T*/
                     chSetLedOn = 0;
                  /*~-1*/
                  }
                  /*~O:I118*/
                  /*~-2*/
                  else
                  {
                     /*~T*/
                     chSetLedOn = 1;
                  /*~-1*/
                  }
                  /*~E:I118*/
                  /*~T*/
                  break;
               /*~-1*/
               }
               /*~E:F117*/
               /*~F:119*/
               case DIGITAL_TOGGLE_1000:
               /*~-1*/
               {
                  /*~I:120*/
                  if (chOnOffToggleFlag & 0x08)
                  /*~-1*/
                  {
                     /*~T*/
                     chSetLedOn = 1;
                  /*~-1*/
                  }
                  /*~O:I120*/
                  /*~-2*/
                  else
                  {
                     /*~T*/
                     chSetLedOn = 0;
                  /*~-1*/
                  }
                  /*~E:I120*/
                  /*~T*/
                  break;
               /*~-1*/
               }
               /*~E:F119*/
               /*~F:121*/
               case DIGITAL_TOGGLE_1000_INV:
               /*~-1*/
               {
                  /*~I:122*/
                  if (chOnOffToggleFlag & 0x08)
                  /*~-1*/
                  {
                     /*~T*/
                     chSetLedOn = 0;
                  /*~-1*/
                  }
                  /*~O:I122*/
                  /*~-2*/
                  else
                  {
                     /*~T*/
                     chSetLedOn = 1;
                  /*~-1*/
                  }
                  /*~E:I122*/
                  /*~T*/
                  break;
               /*~-1*/
               }
               /*~E:F121*/
               /*~F:123*/
               case DIGITAL_TOGGLE_2000:
               /*~-1*/
               {
                  /*~I:124*/
                  if (chOnOffToggleFlag & 0x10)
                  /*~-1*/
                  {
                     /*~T*/
                     chSetLedOn = 1;
                  /*~-1*/
                  }
                  /*~O:I124*/
                  /*~-2*/
                  else
                  {
                     /*~T*/
                     chSetLedOn = 0;
                  /*~-1*/
                  }
                  /*~E:I124*/
                  /*~T*/
                  break;
               /*~-1*/
               }
               /*~E:F123*/
               /*~F:125*/
               case DIGITAL_TOGGLE_2000_INV:
               /*~-1*/
               {
                  /*~I:126*/
                  if (chOnOffToggleFlag & 0x10)
                  /*~-1*/
                  {
                     /*~T*/
                     chSetLedOn = 0;
                  /*~-1*/
                  }
                  /*~O:I126*/
                  /*~-2*/
                  else
                  {
                     /*~T*/
                     chSetLedOn = 1;
                  /*~-1*/
                  }
                  /*~E:I126*/
                  /*~T*/
                  break;
               /*~-1*/
               }
               /*~E:F125*/
               /*~F:127*/
               case DIGITAL_TOGGLE_10000:
               /*~-1*/
               {
                  /*~I:128*/
                  if (chOnOffToggleFlag & 0x20)
                  /*~-1*/
                  {
                     /*~T*/
                     chSetLedOn = 1;
                  /*~-1*/
                  }
                  /*~O:I128*/
                  /*~-2*/
                  else
                  {
                     /*~T*/
                     chSetLedOn = 0;
                  /*~-1*/
                  }
                  /*~E:I128*/
                  /*~T*/
                  break;
               /*~-1*/
               }
               /*~E:F127*/
               /*~F:129*/
               case DIGITAL_TOGGLE_10000_INV:
               /*~-1*/
               {
                  /*~I:130*/
                  if (chOnOffToggleFlag & 0x20)
                  /*~-1*/
                  {
                     /*~T*/
                     chSetLedOn = 0;
                  /*~-1*/
                  }
                  /*~O:I130*/
                  /*~-2*/
                  else
                  {
                     /*~T*/
                     chSetLedOn = 1;
                  /*~-1*/
                  }
                  /*~E:I130*/
                  /*~T*/
                  break;
               /*~-1*/
               }
               /*~E:F129*/
               /*~E:A106*/
               /*~A:131*/
               /*~+:DIGITAL_FLASH_MODE_1*/
               /*~F:132*/
               case DIGITAL_FLASH_MODE_1:
               /*~-1*/
               {
                  /*~I:133*/
                  if ((Flag1000ms)&&(!P10))
                  /*~-1*/
                  {
                     /*~T*/
                     chSetLedOn = 1;
                  /*~-1*/
                  }
                  /*~O:I133*/
                  /*~-2*/
                  else
                  {
                     /*~I:134*/
                     if ((Flag100ms)&&(P10))
                     /*~-1*/
                     {
                        /*~T*/
                        chSetLedOn = 0;
                     /*~-1*/
                     }
                     /*~E:I134*/
                  /*~-1*/
                  }
                  /*~E:I133*/
                  /*~T*/
                  break;
               /*~-1*/
               }
               /*~E:F132*/
               /*~E:A131*/
            /*~-1*/
            }
            /*~E:C101*/
            /*~I:135*/
            if (chSetLedOn)
            /*~-1*/
            {
               /*~I:136*/
#ifndef LEDS_4_DEBUG
               /*~T*/
               P10 = 1;
               /*~-1*/
#endif
               /*~E:I136*/
               /*~T*/
               Digital_Led[chLED].chActualOnOff = DIGITAL_ON;
            /*~-1*/
            }
            /*~O:I135*/
            /*~-2*/
            else
            {
               /*~I:137*/
#ifndef LEDS_4_DEBUG
               /*~T*/
               P10 = 0;
               /*~-1*/
#endif
               /*~E:I137*/
               /*~T*/
               Digital_Led[chLED].chActualOnOff = DIGITAL_OFF;
            /*~-1*/
            }
            /*~E:I135*/
            /*~T*/
            break;
         /*~-1*/
         }
         /*~E:F100*/
         /*~E:A99*/
         /*~A:138*/
         /*~+:DIGITAL_LED_ST_OUT*/
         /*~F:139*/
         case DIGITAL_LED_ST_OUT:
         /*~-1*/
         {
            /*~C:140*/
            switch (Digital_GetLED(DIGITAL_LED_ST_OUT))
            /*~-1*/
            {
               /*~A:141*/
               /*~+:DIGITAL_ON*/
               /*~F:142*/
               case DIGITAL_ON:
               /*~-1*/
               {
                  /*~T*/
                  chSetLedOn = 1;
                  /*~T*/
                  break;
               /*~-1*/
               }
               /*~E:F142*/
               /*~E:A141*/
               /*~A:143*/
               /*~+:DIGITAL_OFF*/
               /*~F:144*/
               case DIGITAL_OFF:
               /*~-1*/
               {
                  /*~T*/
                  chSetLedOn = 0;
                  /*~T*/
                  break;
               /*~-1*/
               }
               /*~E:F144*/
               /*~E:A143*/
               /*~A:145*/
               /*~+:DIGITAL_TOGGLE_XXX_xxx*/
               /*~F:146*/
               case DIGITAL_TOGGLE_100:
               /*~-1*/
               {
                  /*~I:147*/
                  if (chOnOffToggleFlag & 0x01)
                  /*~-1*/
                  {
                     /*~T*/
                     chSetLedOn = 1;
                  /*~-1*/
                  }
                  /*~O:I147*/
                  /*~-2*/
                  else
                  {
                     /*~T*/
                     chSetLedOn = 0;
                  /*~-1*/
                  }
                  /*~E:I147*/
                  /*~T*/
                  break;
               /*~-1*/
               }
               /*~E:F146*/
               /*~F:148*/
               case DIGITAL_TOGGLE_100_INV:
               /*~-1*/
               {
                  /*~I:149*/
                  if (chOnOffToggleFlag & 0x01)
                  /*~-1*/
                  {
                     /*~T*/
                     chSetLedOn = 0;
                  /*~-1*/
                  }
                  /*~O:I149*/
                  /*~-2*/
                  else
                  {
                     /*~T*/
                     chSetLedOn = 1;
                  /*~-1*/
                  }
                  /*~E:I149*/
                  /*~T*/
                  break;
               /*~-1*/
               }
               /*~E:F148*/
               /*~F:150*/
               case DIGITAL_TOGGLE_300:
               /*~-1*/
               {
                  /*~I:151*/
                  if (chOnOffToggleFlag & 0x02)
                  /*~-1*/
                  {
                     /*~T*/
                     chSetLedOn = 1;
                  /*~-1*/
                  }
                  /*~O:I151*/
                  /*~-2*/
                  else
                  {
                     /*~T*/
                     chSetLedOn = 0;
                  /*~-1*/
                  }
                  /*~E:I151*/
                  /*~T*/
                  break;
               /*~-1*/
               }
               /*~E:F150*/
               /*~F:152*/
               case DIGITAL_TOGGLE_300_INV:
               /*~-1*/
               {
                  /*~I:153*/
                  if (chOnOffToggleFlag & 0x02)
                  /*~-1*/
                  {
                     /*~T*/
                     chSetLedOn = 0;
                  /*~-1*/
                  }
                  /*~O:I153*/
                  /*~-2*/
                  else
                  {
                     /*~T*/
                     chSetLedOn = 1;
                  /*~-1*/
                  }
                  /*~E:I153*/
                  /*~T*/
                  break;
               /*~-1*/
               }
               /*~E:F152*/
               /*~F:154*/
               case DIGITAL_TOGGLE_500:
               /*~-1*/
               {
                  /*~I:155*/
                  if (chOnOffToggleFlag & 0x04)
                  /*~-1*/
                  {
                     /*~T*/
                     chSetLedOn = 1;
                  /*~-1*/
                  }
                  /*~O:I155*/
                  /*~-2*/
                  else
                  {
                     /*~T*/
                     chSetLedOn = 0;
                  /*~-1*/
                  }
                  /*~E:I155*/
                  /*~T*/
                  break;
               /*~-1*/
               }
               /*~E:F154*/
               /*~F:156*/
               case DIGITAL_TOGGLE_500_INV:
               /*~-1*/
               {
                  /*~I:157*/
                  if (chOnOffToggleFlag & 0x04)
                  /*~-1*/
                  {
                     /*~T*/
                     chSetLedOn = 0;
                  /*~-1*/
                  }
                  /*~O:I157*/
                  /*~-2*/
                  else
                  {
                     /*~T*/
                     chSetLedOn = 1;
                  /*~-1*/
                  }
                  /*~E:I157*/
                  /*~T*/
                  break;
               /*~-1*/
               }
               /*~E:F156*/
               /*~F:158*/
               case DIGITAL_TOGGLE_1000:
               /*~-1*/
               {
                  /*~I:159*/
                  if (chOnOffToggleFlag & 0x08)
                  /*~-1*/
                  {
                     /*~T*/
                     chSetLedOn = 1;
                  /*~-1*/
                  }
                  /*~O:I159*/
                  /*~-2*/
                  else
                  {
                     /*~T*/
                     chSetLedOn = 0;
                  /*~-1*/
                  }
                  /*~E:I159*/
                  /*~T*/
                  break;
               /*~-1*/
               }
               /*~E:F158*/
               /*~F:160*/
               case DIGITAL_TOGGLE_1000_INV:
               /*~-1*/
               {
                  /*~I:161*/
                  if (chOnOffToggleFlag & 0x08)
                  /*~-1*/
                  {
                     /*~T*/
                     chSetLedOn = 0;
                  /*~-1*/
                  }
                  /*~O:I161*/
                  /*~-2*/
                  else
                  {
                     /*~T*/
                     chSetLedOn = 1;
                  /*~-1*/
                  }
                  /*~E:I161*/
                  /*~T*/
                  break;
               /*~-1*/
               }
               /*~E:F160*/
               /*~F:162*/
               case DIGITAL_TOGGLE_2000:
               /*~-1*/
               {
                  /*~I:163*/
                  if (chOnOffToggleFlag & 0x10)
                  /*~-1*/
                  {
                     /*~T*/
                     chSetLedOn = 1;
                  /*~-1*/
                  }
                  /*~O:I163*/
                  /*~-2*/
                  else
                  {
                     /*~T*/
                     chSetLedOn = 0;
                  /*~-1*/
                  }
                  /*~E:I163*/
                  /*~T*/
                  break;
               /*~-1*/
               }
               /*~E:F162*/
               /*~F:164*/
               case DIGITAL_TOGGLE_2000_INV:
               /*~-1*/
               {
                  /*~I:165*/
                  if (chOnOffToggleFlag & 0x10)
                  /*~-1*/
                  {
                     /*~T*/
                     chSetLedOn = 0;
                  /*~-1*/
                  }
                  /*~O:I165*/
                  /*~-2*/
                  else
                  {
                     /*~T*/
                     chSetLedOn = 1;
                  /*~-1*/
                  }
                  /*~E:I165*/
                  /*~T*/
                  break;
               /*~-1*/
               }
               /*~E:F164*/
               /*~F:166*/
               case DIGITAL_TOGGLE_10000:
               /*~-1*/
               {
                  /*~I:167*/
                  if (chOnOffToggleFlag & 0x20)
                  /*~-1*/
                  {
                     /*~T*/
                     chSetLedOn = 1;
                  /*~-1*/
                  }
                  /*~O:I167*/
                  /*~-2*/
                  else
                  {
                     /*~T*/
                     chSetLedOn = 0;
                  /*~-1*/
                  }
                  /*~E:I167*/
                  /*~T*/
                  break;
               /*~-1*/
               }
               /*~E:F166*/
               /*~F:168*/
               case DIGITAL_TOGGLE_10000_INV:
               /*~-1*/
               {
                  /*~I:169*/
                  if (chOnOffToggleFlag & 0x20)
                  /*~-1*/
                  {
                     /*~T*/
                     chSetLedOn = 0;
                  /*~-1*/
                  }
                  /*~O:I169*/
                  /*~-2*/
                  else
                  {
                     /*~T*/
                     chSetLedOn = 1;
                  /*~-1*/
                  }
                  /*~E:I169*/
                  /*~T*/
                  break;
               /*~-1*/
               }
               /*~E:F168*/
               /*~E:A145*/
               /*~A:170*/
               /*~+:DIGITAL_FLASH_MODE_1*/
               /*~F:171*/
               case DIGITAL_FLASH_MODE_1:
               /*~-1*/
               {
                  /*~I:172*/
                  if ((Flag1000ms)&&(P06))
                  /*~-1*/
                  {
                     /*~T*/
                     chSetLedOn = 1;
                  /*~-1*/
                  }
                  /*~O:I172*/
                  /*~-2*/
                  else
                  {
                     /*~I:173*/
                     if ((Flag100ms)&&(!P06))
                     /*~-1*/
                     {
                        /*~T*/
                        chSetLedOn = 0;
                     /*~-1*/
                     }
                     /*~E:I173*/
                  /*~-1*/
                  }
                  /*~E:I172*/
                  /*~T*/
                  break;
               /*~-1*/
               }
               /*~E:F171*/
               /*~E:A170*/
            /*~-1*/
            }
            /*~E:C140*/
            /*~I:174*/
            if (chSetLedOn)
            /*~-1*/
            {
               /*~I:175*/
#ifndef LEDS_4_DEBUG
               /*~T*/
               P06 = 0;
               /*~-1*/
#endif
               /*~E:I175*/
               /*~T*/
               Digital_Led[chLED].chActualOnOff = DIGITAL_ON;
            /*~-1*/
            }
            /*~O:I174*/
            /*~-2*/
            else
            {
               /*~I:176*/
#ifndef LEDS_4_DEBUG 
               /*~T*/
               P06 = 1;
               /*~-1*/
#endif
               /*~E:I176*/
               /*~T*/
               Digital_Led[chLED].chActualOnOff = DIGITAL_OFF;
            /*~-1*/
            }
            /*~E:I174*/
            /*~I:177*/
#ifdef CHANNEL_1 
            /*~T*/
            // Beim 2.Kanal ist bereits nach der ersten LED Schlu�
            return;
            /*~O:I177*/
            /*~-1*/
#else
            /*~T*/
            break;
            /*~-1*/
#endif
            /*~E:I177*/
         /*~-1*/
         }
         /*~E:F139*/
         /*~E:A138*/
         /*~A:178*/
         /*~+:DIGITAL_LED_ST_OUT_CH1*/
         /*~F:179*/
         case DIGITAL_LED_ST_OUT_CH1:
         /*~-1*/
         {
            /*~C:180*/
            switch (Digital_GetLED(DIGITAL_LED_ST_OUT_CH1))
            /*~-1*/
            {
               /*~A:181*/
               /*~+:DIGITAL_ON*/
               /*~F:182*/
               case DIGITAL_ON:
               /*~-1*/
               {
                  /*~T*/
                  chSetLedOn = 1;
                  /*~T*/
                  break;
               /*~-1*/
               }
               /*~E:F182*/
               /*~E:A181*/
               /*~A:183*/
               /*~+:DIGITAL_OFF*/
               /*~F:184*/
               case DIGITAL_OFF:
               /*~-1*/
               {
                  /*~T*/
                  chSetLedOn = 0;
                  /*~T*/
                  break;
               /*~-1*/
               }
               /*~E:F184*/
               /*~E:A183*/
               /*~A:185*/
               /*~+:DIGITAL_TOGGLE_XXX_xxx*/
               /*~F:186*/
               case DIGITAL_TOGGLE_100:
               /*~-1*/
               {
                  /*~I:187*/
                  if (chOnOffToggleFlag & 0x01)
                  /*~-1*/
                  {
                     /*~T*/
                     chSetLedOn = 1;
                  /*~-1*/
                  }
                  /*~O:I187*/
                  /*~-2*/
                  else
                  {
                     /*~T*/
                     chSetLedOn = 0;
                  /*~-1*/
                  }
                  /*~E:I187*/
                  /*~T*/
                  break;
               /*~-1*/
               }
               /*~E:F186*/
               /*~F:188*/
               case DIGITAL_TOGGLE_100_INV:
               /*~-1*/
               {
                  /*~I:189*/
                  if (chOnOffToggleFlag & 0x01)
                  /*~-1*/
                  {
                     /*~T*/
                     chSetLedOn = 0;
                  /*~-1*/
                  }
                  /*~O:I189*/
                  /*~-2*/
                  else
                  {
                     /*~T*/
                     chSetLedOn = 1;
                  /*~-1*/
                  }
                  /*~E:I189*/
                  /*~T*/
                  break;
               /*~-1*/
               }
               /*~E:F188*/
               /*~F:190*/
               case DIGITAL_TOGGLE_300:
               /*~-1*/
               {
                  /*~I:191*/
                  if (chOnOffToggleFlag & 0x02)
                  /*~-1*/
                  {
                     /*~T*/
                     chSetLedOn = 1;
                  /*~-1*/
                  }
                  /*~O:I191*/
                  /*~-2*/
                  else
                  {
                     /*~T*/
                     chSetLedOn = 0;
                  /*~-1*/
                  }
                  /*~E:I191*/
                  /*~T*/
                  break;
               /*~-1*/
               }
               /*~E:F190*/
               /*~F:192*/
               case DIGITAL_TOGGLE_300_INV:
               /*~-1*/
               {
                  /*~I:193*/
                  if (chOnOffToggleFlag & 0x02)
                  /*~-1*/
                  {
                     /*~T*/
                     chSetLedOn = 0;
                  /*~-1*/
                  }
                  /*~O:I193*/
                  /*~-2*/
                  else
                  {
                     /*~T*/
                     chSetLedOn = 1;
                  /*~-1*/
                  }
                  /*~E:I193*/
                  /*~T*/
                  break;
               /*~-1*/
               }
               /*~E:F192*/
               /*~F:194*/
               case DIGITAL_TOGGLE_500:
               /*~-1*/
               {
                  /*~I:195*/
                  if (chOnOffToggleFlag & 0x04)
                  /*~-1*/
                  {
                     /*~T*/
                     chSetLedOn = 1;
                  /*~-1*/
                  }
                  /*~O:I195*/
                  /*~-2*/
                  else
                  {
                     /*~T*/
                     chSetLedOn = 0;
                  /*~-1*/
                  }
                  /*~E:I195*/
                  /*~T*/
                  break;
               /*~-1*/
               }
               /*~E:F194*/
               /*~F:196*/
               case DIGITAL_TOGGLE_500_INV:
               /*~-1*/
               {
                  /*~I:197*/
                  if (chOnOffToggleFlag & 0x04)
                  /*~-1*/
                  {
                     /*~T*/
                     chSetLedOn = 0;
                  /*~-1*/
                  }
                  /*~O:I197*/
                  /*~-2*/
                  else
                  {
                     /*~T*/
                     chSetLedOn = 1;
                  /*~-1*/
                  }
                  /*~E:I197*/
                  /*~T*/
                  break;
               /*~-1*/
               }
               /*~E:F196*/
               /*~F:198*/
               case DIGITAL_TOGGLE_1000:
               /*~-1*/
               {
                  /*~I:199*/
                  if (chOnOffToggleFlag & 0x08)
                  /*~-1*/
                  {
                     /*~T*/
                     chSetLedOn = 1;
                  /*~-1*/
                  }
                  /*~O:I199*/
                  /*~-2*/
                  else
                  {
                     /*~T*/
                     chSetLedOn = 0;
                  /*~-1*/
                  }
                  /*~E:I199*/
                  /*~T*/
                  break;
               /*~-1*/
               }
               /*~E:F198*/
               /*~F:200*/
               case DIGITAL_TOGGLE_1000_INV:
               /*~-1*/
               {
                  /*~I:201*/
                  if (chOnOffToggleFlag & 0x08)
                  /*~-1*/
                  {
                     /*~T*/
                     chSetLedOn = 0;
                  /*~-1*/
                  }
                  /*~O:I201*/
                  /*~-2*/
                  else
                  {
                     /*~T*/
                     chSetLedOn = 1;
                  /*~-1*/
                  }
                  /*~E:I201*/
                  /*~T*/
                  break;
               /*~-1*/
               }
               /*~E:F200*/
               /*~F:202*/
               case DIGITAL_TOGGLE_2000:
               /*~-1*/
               {
                  /*~I:203*/
                  if (chOnOffToggleFlag & 0x10)
                  /*~-1*/
                  {
                     /*~T*/
                     chSetLedOn = 1;
                  /*~-1*/
                  }
                  /*~O:I203*/
                  /*~-2*/
                  else
                  {
                     /*~T*/
                     chSetLedOn = 0;
                  /*~-1*/
                  }
                  /*~E:I203*/
                  /*~T*/
                  break;
               /*~-1*/
               }
               /*~E:F202*/
               /*~F:204*/
               case DIGITAL_TOGGLE_2000_INV:
               /*~-1*/
               {
                  /*~I:205*/
                  if (chOnOffToggleFlag & 0x10)
                  /*~-1*/
                  {
                     /*~T*/
                     chSetLedOn = 0;
                  /*~-1*/
                  }
                  /*~O:I205*/
                  /*~-2*/
                  else
                  {
                     /*~T*/
                     chSetLedOn = 1;
                  /*~-1*/
                  }
                  /*~E:I205*/
                  /*~T*/
                  break;
               /*~-1*/
               }
               /*~E:F204*/
               /*~F:206*/
               case DIGITAL_TOGGLE_10000:
               /*~-1*/
               {
                  /*~I:207*/
                  if (chOnOffToggleFlag & 0x20)
                  /*~-1*/
                  {
                     /*~T*/
                     chSetLedOn = 1;
                  /*~-1*/
                  }
                  /*~O:I207*/
                  /*~-2*/
                  else
                  {
                     /*~T*/
                     chSetLedOn = 0;
                  /*~-1*/
                  }
                  /*~E:I207*/
                  /*~T*/
                  break;
               /*~-1*/
               }
               /*~E:F206*/
               /*~F:208*/
               case DIGITAL_TOGGLE_10000_INV:
               /*~-1*/
               {
                  /*~I:209*/
                  if (chOnOffToggleFlag & 0x20)
                  /*~-1*/
                  {
                     /*~T*/
                     chSetLedOn = 0;
                  /*~-1*/
                  }
                  /*~O:I209*/
                  /*~-2*/
                  else
                  {
                     /*~T*/
                     chSetLedOn = 1;
                  /*~-1*/
                  }
                  /*~E:I209*/
                  /*~T*/
                  break;
               /*~-1*/
               }
               /*~E:F208*/
               /*~E:A185*/
               /*~A:210*/
               /*~+:DIGITAL_FLASH_MODE_1*/
               /*~F:211*/
               case DIGITAL_FLASH_MODE_1:
               /*~-1*/
               {
                  /*~I:212*/
                  if ((Flag1000ms)&&(P06))
                  /*~-1*/
                  {
                     /*~T*/
                     chSetLedOn = 1;
                  /*~-1*/
                  }
                  /*~O:I212*/
                  /*~-2*/
                  else
                  {
                     /*~I:213*/
                     if ((Flag100ms)&&(!P06))
                     /*~-1*/
                     {
                        /*~T*/
                        chSetLedOn = 0;
                     /*~-1*/
                     }
                     /*~E:I213*/
                  /*~-1*/
                  }
                  /*~E:I212*/
                  /*~T*/
                  break;
               /*~-1*/
               }
               /*~E:F211*/
               /*~E:A210*/
            /*~-1*/
            }
            /*~E:C180*/
            /*~I:214*/
#ifndef LEDS_4_DEBUG
            /*~I:215*/
            if (chSetLedOn)
            /*~-1*/
            {
               /*~I:216*/
               if (Digital_Led[chLED].chActualOnOff == DIGITAL_OFF)
               /*~-1*/
               {
                  /*~A:217*/
                  /*~+:Best�tigte Kommunikation*/
                  /*~T*/
                  byCounter = 2;
                  /*~I:218*/
#ifdef SYSTEM_CND_DISABLE_SPI_COMMUNICATION_AT_FAULTS 
                  /*~A:219*/
                  /*~+:Mit Abschaltung der SPI-Kommunikation bei Ausfall der SPI-Schnittstelle*/
                  /*~I:220*/
                  if (!Communication_IsSPICommuncationDisabled())
                  /*~-1*/
                  {
                     /*~U:221*/
                     /*~-2*/
                     do
                     {
                        /*~T*/
                        Communication_SendSPICommand("iLED 1");
                     /*~-1*/
                     }
                     /*~O:U221*/
                     while (!Communication_IsOK() && --byCounter);
                     /*~E:U221*/
                  /*~-1*/
                  }
                  /*~E:I220*/
                  /*~E:A219*/
                  /*~O:I218*/
                  /*~-1*/
#else
                  /*~A:222*/
                  /*~+:Ohne Abschaltung der SPI-Kommunikation bei Ausfall der SPI-Schnittstelle*/
                  /*~U:223*/
                  /*~-2*/
                  do
                  {
                     /*~T*/
                     Communication_SendSPICommand("iLED 1");
                  /*~-1*/
                  }
                  /*~O:U223*/
                  while (!Communication_IsOK() && --byCounter);
                  /*~E:U223*/
                  /*~E:A222*/
                  /*~-1*/
#endif
                  /*~E:I218*/
                  /*~I:224*/
                  if (byCounter)
                  /*~-1*/
                  {
                     /*~T*/
                     Digital_Led[chLED].chActualOnOff = DIGITAL_ON;
                  /*~-1*/
                  }
                  /*~E:I224*/
                  /*~E:A217*/
               /*~-1*/
               }
               /*~E:I216*/
            /*~-1*/
            }
            /*~O:I215*/
            /*~-2*/
            else
            {
               /*~I:225*/
               if (Digital_Led[chLED].chActualOnOff == DIGITAL_ON)
               /*~-1*/
               {
                  /*~A:226*/
                  /*~+:Best�tigte Kommunikation*/
                  /*~T*/
                  byCounter = 2;
                  /*~I:227*/
#ifdef SYSTEM_CND_DISABLE_SPI_COMMUNICATION_AT_FAULTS
                  /*~A:228*/
                  /*~+:Mit Abschaltung der SPI-Kommunikation bei Ausfall der SPI-Schnittstelle*/
                  /*~I:229*/
                  if (!Communication_IsSPICommuncationDisabled())
                  /*~-1*/
                  {
                     /*~U:230*/
                     /*~-2*/
                     do
                     {
                        /*~T*/
                        Communication_SendSPICommand("iLED 0");
                     /*~-1*/
                     }
                     /*~O:U230*/
                     while (!Communication_IsOK() && --byCounter);
                     /*~E:U230*/
                  /*~-1*/
                  }
                  /*~E:I229*/
                  /*~E:A228*/
                  /*~O:I227*/
                  /*~-1*/
#else
                  /*~A:231*/
                  /*~+:Ohne Abschaltung der SPI-Kommunikation bei Ausfall der SPI-Schnittstelle*/
                  /*~U:232*/
                  /*~-2*/
                  do
                  {
                     /*~T*/
                     Communication_SendSPICommand("iLED 0");
                  /*~-1*/
                  }
                  /*~O:U232*/
                  while (!Communication_IsOK() && --byCounter);
                  /*~E:U232*/
                  /*~E:A231*/
                  /*~-1*/
#endif
                  /*~E:I227*/
                  /*~I:233*/
                  if (byCounter)
                  /*~-1*/
                  {
                     /*~T*/
                     Digital_Led[chLED].chActualOnOff = DIGITAL_OFF;
                  /*~-1*/
                  }
                  /*~E:I233*/
                  /*~E:A226*/
               /*~-1*/
               }
               /*~E:I225*/
            /*~-1*/
            }
            /*~E:I215*/
            /*~-1*/
#endif
            /*~E:I214*/
            /*~T*/
            break;
         /*~-1*/
         }
         /*~E:F179*/
         /*~E:A178*/
      /*~-1*/
      }
      /*~E:C59*/
   /*~-1*/
   }
   /*~E:L58*/
   /*~E:A57*/
   /*~-1*/
#endif
   /*~E:I11*/
   /*~E:A10*/
/*~-1*/
}
/*~E:F9*/
/*~E:A8*/
/*~I:234*/
#ifdef CHANNEL_0
/*~A:235*/
/*~+:void 			Digital_ClearLEDTestMode(void)*/
/*~F:236*/
void Digital_ClearLEDTestMode(void)
/*~-1*/
{
   /*~T*/
   g_Digital.bLEDTestMode = FALSE;
/*~-1*/
}
/*~E:F236*/
/*~E:A235*/
/*~A:237*/
/*~+:unsigned char 	Digital_GetLED(unsigned char chLed2Get)*/
/*~F:238*/
unsigned char Digital_GetLED(unsigned char chLed2Get)
/*~-1*/
{
   /*~A:239*/
   /*~+:Beschreibung*/
   /*~T*/
   /*!
   \fn unsigned char Digital_GetLED(unsigned char chLed2Get)
   
   <b>Beschreibung:</b><br>
   Ausgabe des Status des digitalen LED-Ausgangs. 
   
   \param
   chLed2Get: Kennzeichner der entsprechenden LED.
   
   \return
   Status des digitalen LED-Ausgangs.
   
   <b>Zugriff:</b><br>
   [X] �ffentlich / [ ] Privat
   */
   /*~E:A239*/
   /*~T*/
   return Digital_Led[chLed2Get].chStatus;
/*~-1*/
}
/*~E:F238*/
/*~E:A237*/
/*~-1*/
#endif
/*~E:I234*/
/*~A:240*/
/*~+:void 			Digital_Init(void)*/
/*~F:241*/
void Digital_Init(void)
/*~-1*/
{
   /*~A:242*/
   /*~+:Beschreibung*/
   /*~T*/
   /*!
   \fn void Digital_Init(void)
   
   <b>Beschreibung:</b><br>
   Initialisieren der Struktur zum Modul 'Digital'.
   
   \param
   ./.
   
   \return
   ./.
   
   <b>Zugriff:</b><br>
   [X] �ffentlich / [ ] Privat
   */
   /*~E:A242*/
   /*~T*/
   g_Digital.bLEDTestMode = 0;
   g_Digital.byLEDTestMask = 0;
/*~-1*/
}
/*~E:F241*/
/*~E:A240*/
/*~I:243*/
#ifdef CHANNEL_0
/*~A:244*/
/*~+:void 			Digital_SetLED(unsigned char chLed2Set,unsigned char chStatus)*/
/*~F:245*/
void Digital_SetLED(unsigned char chLed2Set,unsigned char chStatus)
/*~-1*/
{
   /*~A:246*/
   /*~+:Beschreibung*/
   /*~T*/
   /*!
   \fn void Digital_SetLED(unsigned char chLed2Set,unsigned char chStatus)
   
   <b>Beschreibung:</b><br>
   Setzen des Status des digitalen LED-Ausgangs.
   
   \param
   chLed2Set: Kennzeichner der entsprechenden LED.
   
   \param
   chStatus: zu setzender Status (s. unter Definitionen).
   
   \return
   ./.
   
   <b>Zugriff:</b><br>
   [X] �ffentlich / [ ] Privat
   */
   /*~E:A246*/
   /*~T*/
   Digital_Led[chLed2Set].chStatus = chStatus;
   /*~I:247*/
#ifdef MOF
   /*~I:248*/
   if ((Digital_Led[chLed2Set].chStatus & 0x7F) != chStatus)
   /*~-1*/
   {
      /*~T*/
      // Status hat sich ge�ndert
      Digital_Led[chLed2Set].chStatus = chStatus | 0x80; 
   /*~-1*/
   }
   /*~O:I248*/
   /*~-2*/
   else
   {
      /*~T*/
      // Status ist gleich geblieben
      Digital_Led[chLed2Set].chStatus = chStatus; 
   /*~-1*/
   }
   /*~E:I248*/
   /*~-1*/
#endif
   /*~E:I247*/
/*~-1*/
}
/*~E:F245*/
/*~E:A244*/
/*~A:249*/
/*~+:void 			Digital_SetLEDManually(unsigned char chLed2Set,unsigned char bOn)*/
/*~F:250*/
void Digital_SetLEDManually(unsigned char chLed2Set,unsigned char bOn)
/*~-1*/
{
   /*~A:251*/
   /*~+:Beschreibung*/
   /*~T*/
   /*!
   \fn void Digital_SetLED(unsigned char chLed2Set,unsigned char chStatus)
   
   <b>Beschreibung:</b><br>
   Setzen des Status des digitalen LED-Ausgangs.
   
   \param
   chLed2Set: Kennzeichner der entsprechenden LED.
   
   \param
   chStatus: zu setzender Status (s. unter Definitionen).
   
   \return
   ./.
   
   <b>Zugriff:</b><br>
   [X] �ffentlich / [ ] Privat
   */
   /*~E:A251*/
   /*~T*/
   g_Digital.bLEDTestMode = TRUE;
   /*~A:252*/
   /*~+:DIGITAL_LED_RUN*/
   /*~I:253*/
   if (chLed2Set & DIGITAL_LED_RUN)
   /*~-1*/
   {
      /*~T*/
      Digital_Led[DIGITAL_LED_P_OK].chStatus = bOn;
   /*~-1*/
   }
   /*~E:I253*/
   /*~E:A252*/
   /*~A:254*/
   /*~+:DIGITAL_LED_ZEROCHECK*/
   /*~I:255*/
   if (chLed2Set & DIGITAL_LED_ZEROCHECK)
   /*~-1*/
   {
      /*~T*/
      Digital_Led[DIGITAL_LED_ST_IN].chStatus = bOn;
   /*~-1*/
   }
   /*~E:I255*/
   /*~E:A254*/
   /*~A:256*/
   /*~+:DIGITAL_LED_ERROR_CH0*/
   /*~I:257*/
   if (chLed2Set & DIGITAL_LED_ERROR_CH0)
   /*~-1*/
   {
      /*~T*/
      Digital_Led[DIGITAL_LED_ST_OUT].chStatus = bOn;
   /*~-1*/
   }
   /*~E:I257*/
   /*~E:A256*/
   /*~A:258*/
   /*~+:DIGITAL_LED_ERROR_CH1*/
   /*~I:259*/
   if (chLed2Set & DIGITAL_LED_ERROR_CH1)
   /*~-1*/
   {
      /*~T*/
      Digital_Led[DIGITAL_LED_ST_OUT_CH1].chStatus = bOn;
   /*~-1*/
   }
   /*~E:I259*/
   /*~E:A258*/
/*~-1*/
}
/*~E:F250*/
/*~E:A249*/
/*~-1*/
#endif
/*~E:I243*/
