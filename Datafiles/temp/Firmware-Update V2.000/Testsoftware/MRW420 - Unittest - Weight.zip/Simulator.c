/*~-1*/
/*~XSF_LANGUAGE: C/C++*/
/*~K*/
/*~+:File :        Simulator.c*/
/*~+:*/
/*~+:Version :     V1.000*/
/*~+:*/
/*~+:Date :        24.03.2022*/
/*~+:*/
/*~+:Time :        10:23*/
/*~+:*/
/*~+:Author :      MOF*/
/*~+:*/
/*~+:Hardware :*/
/*~+:*/
/*~+:Description :*/
/*~+:*/
/*~+:*/
/*~A:1*/
/*~+:Includes*/
/*~T*/
#include "Simulator.h"
#include "System.cnd"
#include "global.h"
#include <string.h>
#include <stdio.h>
/*~E:A1*/
/*~A:2*/
/*~+:Funktionseigene Definitionen*/
/*~T*/

/*~E:A2*/
/*~A:3*/
/*~+:Funktionseigene Struktur-Definitionen*/
/*~T*/

/*~E:A3*/
/*~A:4*/
/*~+:Funktionsprototypen*/
/*~T*/

/*~E:A4*/
/*~A:5*/
/*~+:Globale Variablen*/
/*~T*/

/*~E:A5*/
/*~T*/
const long ai32SimulationTable[] = {32767, 0, 500, -32768, 0x7FFFFFFF, 0x80000000};
const char ai8SimulationTableTemp[] = {70, 20, -30};
/*~F:6*/
long Simulator_GetRMW(void)
/*~-1*/
{
   /*~T*/
   /* Variablendeklarationen */
   long i32SimulatatedRMW;
   static unsigned char bInitInterval = 1;
   static unsigned short byStep = 0;
   static unsigned int u16Cnt = 0;
   static unsigned int u16CntTemp = 0;
   unsigned int u16MaxCnt;
   unsigned int u16MaxCntTemp;
   static long i32LastSimulatedRMW = 0L;
   long i32Step;
   int nCorVal;
   unsigned short u8FilterDepth;
   MEASUREMENT_VALUE MV;
   static short i8SimulatedTemperature = 20;
   char szDebug[36];
   /*~T*/
   /* Variableninitialisierungen */
   i32SimulatatedRMW = 0L;
   u16MaxCnt = sizeof(ai32SimulationTable) / sizeof(long);
   u16MaxCntTemp = sizeof(ai8SimulationTableTemp) / sizeof(char);

   /*~T*/
   /* Implementierung */
   /*~C:7*/
   switch (byStep)
   /*~-1*/
   {
      /*~F:8*/
      case 0:
      /*~-1*/
      {
         /*~T*/
         /* Zelle fuer die Tests parametrieren */
         Weight_SetZero(SYSTEM_CND_UNITTEST_SIMULATED_ZERO);

         AverageFilter_SetFilterDepth(WEIGHT_WEIGHTCHANNEL,SYSTEM_CND_UNITTEST_SIMULATED_FILTERDEPTH);

         Weight_SetTareValue(SYSTEM_CND_UNITTEST_SIMULATED_TARE,1);

         /*~T*/
         byStep++;
      /*~-1*/
      }
      /*~E:F8*/
      /*~F:9*/
      case 1:
      /*~-1*/
      {
         /*~T*/
         /* Temperatur �ber Tabelle */
         /*~T*/
         i8SimulatedTemperature = ai8SimulationTableTemp[u16CntTemp];
         u16CntTemp++;

         /*~I:10*/
         if (SYSTEM_CND_UNITTEST_SIMULATED_TEMP != 20)
         /*~-1*/
         {
            /*~T*/
            Compensation_SetCompensationValues(i8SimulatedTemperature, (i8SimulatedTemperature - 20) * 20);
         /*~-1*/
         }
         /*~E:I10*/
         /*~I:11*/
         if (u16CntTemp > u16MaxCntTemp)
         /*~-1*/
         {
            /*~L:12*/
            while (1)
            /*~-1*/
            {
               /*~T*/

            /*~-1*/
            }
            /*~E:L12*/
         /*~-1*/
         }
         /*~E:I11*/
         /*~T*/
         //u16Cnt = 0;

         byStep++;
      /*~-1*/
      }
      /*~E:F9*/
      /*~F:13*/
      case 2:
      /*~-1*/
      {
         /*~T*/
         Communication_SendRawString(COMMUNICATION_RS232, "\r\n\r\nFirmware:;");
         Communication_SendRawString(COMMUNICATION_RS232, TEXT_SOFTWARE_VERSION);
         Communication_SendRawString(COMMUNICATION_RS232, "\r\n");

         Communication_SendRawString(COMMUNICATION_RS232, "Nullpunkt:;");
         Measurement_GetZero(WEIGHT_WEIGHTCHANNEL,&MV);
         sprintf(szDebug, "%ld\r\n", MV.nLong);
         Communication_SendRawString(COMMUNICATION_RS232, szDebug);

         Communication_SendRawString(COMMUNICATION_RS232, "Kalibrierfaktor:;");
         Measurement_GetCalibrationFactor(WEIGHT_WEIGHTCHANNEL,&MV.fFloat);
         sprintf(szDebug, "%f\r\n", MV.fFloat);
         Communication_SendRawString(COMMUNICATION_RS232, szDebug);

         Communication_SendRawString(COMMUNICATION_RS232, "Tara:;");
         Measurement_GetResult(WEIGHT_WEIGHTCHANNEL,MEASUREMENT_GET_TARE,&Weight_TareWeight);
         sprintf(szDebug, "%0.2f\r\n", Weight_TareWeight.fFloat);
         Communication_SendRawString(COMMUNICATION_RS232, szDebug);

         Communication_SendRawString(COMMUNICATION_RS232, "Filtertiefe:;");
         u8FilterDepth = AverageFilter_GetFilterDepth(WEIGHT_WEIGHTCHANNEL);
         sprintf(szDebug, "%bd\r\n", u8FilterDepth);
         Communication_SendRawString(COMMUNICATION_RS232, szDebug);

         Communication_SendRawString(COMMUNICATION_RS232, "Simulierte Temperatur:;");
         sprintf(szDebug, "%d\r\n", i8SimulatedTemperature);
         Communication_SendRawString(COMMUNICATION_RS232, szDebug);

         Communication_SendRawString(COMMUNICATION_RS232, "Temperaturkorrekturwert:;");

         /*~I:14*/
         if (i8SimulatedTemperature != 20)
         /*~-1*/
         {
            /*~T*/
            nCorVal = Compensation_GetCompensationValue((char)i8SimulatedTemperature);

         /*~-1*/
         }
         /*~O:I14*/
         /*~-2*/
         else
         {
            /*~T*/
            nCorVal = 0;
         /*~-1*/
         }
         /*~E:I14*/
         /*~T*/
         sprintf(szDebug, "%d\r\n", nCorVal);
         Communication_SendRawString(COMMUNICATION_RS232, szDebug);

         Communication_SendRawString(COMMUNICATION_RS232, "\r\n");
         Communication_SendRawString(COMMUNICATION_RS232, "Simulierter RMW");
         Communication_SendRawString(COMMUNICATION_RS232, ";RMW gefiltert");
         Communication_SendRawString(COMMUNICATION_RS232, ";RMW NP bereinigt");
         Communication_SendRawString(COMMUNICATION_RS232, ";RMW kompensiert");
         Communication_SendRawString(COMMUNICATION_RS232, ";RMW kompensiert - ohne NP");
         Communication_SendRawString(COMMUNICATION_RS232, ";Gewichtswert");
         Communication_SendRawString(COMMUNICATION_RS232, ";Brutto-Gewicht");
         Communication_SendRawString(COMMUNICATION_RS232, ";Tara-Gewicht");
         Communication_SendRawString(COMMUNICATION_RS232, ";Netto-Gewicht");
         Communication_SendRawString(COMMUNICATION_RS232, ";Netto-RMW");
         Communication_SendRawString(COMMUNICATION_RS232, "\r\n");
         /*~T*/
         byStep++;
      /*~-1*/
      }
      /*~E:F13*/
      /*~F:15*/
      case 3:
      /*~-1*/
      {
         /*~T*/
         /* �ber Tabelle */
         /*~T*/
         i32SimulatatedRMW = ai32SimulationTable[u16Cnt];
         u16Cnt++;
         /*~I:16*/
         if (u16Cnt >= u16MaxCnt)
         /*~-1*/
         {
            /*~T*/
            u16Cnt = 0;
            bInitInterval = 1;

            byStep++;
         /*~-1*/
         }
         /*~E:I16*/
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F15*/
      /*~F:17*/
      case 4:
      /*~-1*/
      {
         /*~T*/
         /* �ber Intervall */
         /*~I:18*/
#if ((SYSTEM_CND_UNITTEST_INTERVAL_END != SYSTEM_CND_UNITTEST_INTERVAL_START) && (SYSTEM_CND_UNITTEST_INTERVAL_STEP != 0)) 
         /*~T*/
         /* Set interval */
         i32Step = SYSTEM_CND_UNITTEST_INTERVAL_STEP;
         /*~I:19*/
         if ((SYSTEM_CND_UNITTEST_INTERVAL_END < SYSTEM_CND_UNITTEST_INTERVAL_START) && (SYSTEM_CND_UNITTEST_INTERVAL_STEP > 0))
         /*~-1*/
         {
            /*~T*/
            i32Step *= -1;
         /*~-1*/
         }
         /*~O:I19*/
         /*~-2*/
         else
         {
            /*~I:20*/
            if ((SYSTEM_CND_UNITTEST_INTERVAL_END > SYSTEM_CND_UNITTEST_INTERVAL_START) && (SYSTEM_CND_UNITTEST_INTERVAL_STEP < 0))
            /*~-1*/
            {
               /*~T*/
               i32Step *= -1;
            /*~-1*/
            }
            /*~E:I20*/
         /*~-1*/
         }
         /*~E:I19*/
         /*~I:21*/
         if (bInitInterval != 0)
         /*~-1*/
         {
            /*~T*/
            bInitInterval = 0;
            i32SimulatatedRMW = SYSTEM_CND_UNITTEST_INTERVAL_START;
         /*~-1*/
         }
         /*~O:I21*/
         /*~-2*/
         else
         {
            /*~T*/
            i32SimulatatedRMW = i32LastSimulatedRMW + i32Step;
            /*~I:22*/
            if (i32Step > 0)
            /*~-1*/
            {
               /*~I:23*/
               if ((i32SimulatatedRMW >= SYSTEM_CND_UNITTEST_INTERVAL_END) || ((i32LastSimulatedRMW > 0) && (i32SimulatatedRMW < 0L)))
               /*~-1*/
               {
                  /*~T*/
                  i32SimulatatedRMW = SYSTEM_CND_UNITTEST_INTERVAL_END;
                  byStep = 1; 
               /*~-1*/
               }
               /*~E:I23*/
            /*~-1*/
            }
            /*~O:I22*/
            /*~-2*/
            else
            {
               /*~I:24*/
               if ((i32SimulatatedRMW <= SYSTEM_CND_UNITTEST_INTERVAL_END) || ((i32LastSimulatedRMW < 0) && (i32SimulatatedRMW > 0L)))
               /*~-1*/
               {
                  /*~T*/
                  i32SimulatatedRMW = SYSTEM_CND_UNITTEST_INTERVAL_END;
                  byStep = 1; 
               /*~-1*/
               }
               /*~E:I24*/
            /*~-1*/
            }
            /*~E:I22*/
         /*~-1*/
         }
         /*~E:I21*/
         /*~T*/
         i32LastSimulatedRMW = i32SimulatatedRMW;
         /*~O:I18*/
         /*~-1*/
#else
         /*~T*/
         byStep++;
         /*~-1*/
#endif
         /*~E:I18*/
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F17*/
   /*~-1*/
   }
   /*~E:C7*/
   /*~T*/
   Global.byTemperature = i8SimulatedTemperature;
   /*~T*/
   /* Rueckgabe */
   return(i32SimulatatedRMW);
/*~-1*/
}
/*~E:F6*/
