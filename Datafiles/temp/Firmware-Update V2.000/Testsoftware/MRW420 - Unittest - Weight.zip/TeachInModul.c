/*~-1*/
/*~XSF_LANGUAGE: C/C++*/
/*~K*/
/*~+:File :        TeachInModul.c*/
/*~+:*/
/*~+:Version :     V1.0*/
/*~+:*/
/*~+:Date :        20.07.2005*/
/*~+:*/
/*~+:Time :        10:23*/
/*~+:*/
/*~+:Author :      MOF*/
/*~+:*/
/*~+:Hardware :*/
/*~+:*/
/*~+:Description : Routinen zum Teachen von Tara und Grenzwert. */
/*~+:*/
/*~+:*/
/*~A:1*/
/*~+:Includes*/
/*~T*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "TeachInModul.h"
#include "ADuC836Driver.h"
#include "Weight.h"
/*~E:A1*/
/*~A:2*/
/*~+:Funktionseigene Definitionen*/
/*~T*/
#define TEACHINMODUL_MAX_TEACHRETRIES			10
/*~E:A2*/
/*~A:3*/
/*~+:Funktionseigene Struktur-Definitionen*/
/*~T*/

/*~E:A3*/
/*~A:4*/
/*~+:Funktionsprototypen*/
/*~T*/
char TeachInModul(void);
char TeachInModul_IsModulActive(void);
/*~E:A4*/
/*~A:5*/
/*~+:Globale Variablen*/
/*~T*/

/*~E:A5*/
/*~A:6*/
/*~+:void TeachIn_Interface(unsigned char chState)*/
/*~F:7*/
void TeachIn_Interface(unsigned char chState)
/*~-1*/
{
   /*~A:8*/
   /*~+:Variablendeklarationen*/
   /*~T*/
   static unsigned char chTeachRetries = 0;
   /*~E:A8*/
   /*~I:9*/
#ifdef CHANNEL_0
   /*~A:10*/
   /*~+:Variablendeklarationen*/
   /*~T*/
   unsigned char chSPIBuffer[12];
   unsigned char chState_Ch1;
   static unsigned char chNextLevel = 0;
   unsigned char chError;
   long lLong;
   /*~E:A10*/
   /*~A:11*/
   /*~+:Variableninitialisierungen*/
   /*~I:12*/
#ifdef CHANNEL_0
   /*~T*/
   Global.chTeachInStatus = chState; 
   /*~-1*/
#endif
   /*~E:I12*/
   /*~E:A11*/
   /*~I:13*/
   if (chState != TEACHIN_NOT_CONNECTED) // nur das verhindert Kommunikations�berschneidungen mit der RS232
   /*~-1*/
   {
      /*~A:14*/
      /*~+:TeachIn-Status dem Kanal 1 mitteilen und dessen auslesen*/
      /*~T*/
      // Frame zusammensetzen
      sprintf(chSPIBuffer,"iTIS %bu",Global.chTeachInStatus);
      /*~I:15*/
      if (!Communication_SendSPICommand(chSPIBuffer))
      /*~-1*/
      {
         /*~I:16*/
         if (!Communication_GetLong(&lLong))
         /*~-1*/
         {
            /*~T*/
            chError = 0;
         /*~-1*/
         }
         /*~O:I16*/
         /*~-2*/
         else
         {
            /*~T*/
            chError = 2;
         /*~-1*/
         }
         /*~E:I16*/
      /*~-1*/
      }
      /*~O:I15*/
      /*~-2*/
      else
      {
         /*~T*/
         chError = 1;
      /*~-1*/
      }
      /*~E:I15*/
      /*~I:17*/
      if (!chError)
      /*~-1*/
      {
         /*~T*/
         chState_Ch1 = (char)lLong;
      /*~-1*/
      }
      /*~O:I17*/
      /*~-2*/
      else
      {
         /*~T*/
         chState_Ch1 = 0;
      /*~-1*/
      }
      /*~E:I17*/
      /*~E:A14*/
   /*~-1*/
   }
   /*~E:I13*/
   /*~-1*/
#endif
   /*~E:I9*/
   /*~C:18*/
   switch (chState)
   /*~-1*/
   {
      /*~F:19*/
      case TEACHIN_NOT_CONNECTED:
      /*~-1*/
      {
         /*~T*/
         return;
      /*~-1*/
      }
      /*~E:F19*/
      /*~F:20*/
      case TEACHIN_CHECK_KEY:
      /*~-1*/
      {
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F20*/
      /*~F:21*/
      case TEACHIN_INIT_1ST_LEVEL:
      /*~-1*/
      {
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F21*/
      /*~F:22*/
      case TEACHIN_WAIT_4_KEY_1ST_LEVEL:
      case TEACHIN_WAIT_4_KEY_LAST_LEVEL: 
      /*~-1*/
      {
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F22*/
      /*~F:23*/
      case TEACHIN_1ST_LEVEL:		// Tara-Teach
      /*~-1*/
      {
         /*~A:24*/
         /*~+:CHANNEL_0*/
         /*~I:25*/
#ifdef CHANNEL_0
         /*~I:26*/
         if (!chNextLevel)
         /*~-1*/
         {
            /*~C:27*/
            switch (Limit_TeachTara())
            /*~-1*/
            {
               /*~F:28*/
               case -1:	// Fehler
               /*~-1*/
               {
                  /*~T*/
                  // Fehler w�hrend des Teachvorgangs
                  TeachIn_SetState(TEACHIN_ON_ERROR);
                  /*~T*/
                  break;
               /*~-1*/
               }
               /*~E:F28*/
               /*~F:29*/
               case 0:		// Alles okay
               /*~-1*/
               {
                  /*~T*/
                  chTeachRetries = 0;

                  // weiter zum n�chsten Level
                  chNextLevel = 1;
                  /*~A:30*/
                  /*~+:Eintrag in Diagnosespeicher vornehmen*/
                  /*~T*/
                  Diagnosis_WriteMessage2Flash(DIAGNOSIS_MESSAGE_TARATEACH);
                  /*~E:A30*/
                  /*~T*/
                  break;
               /*~-1*/
               }
               /*~E:F29*/
               /*~F:31*/
               case 1:		// Gewicht instabil
               /*~-1*/
               {
                  /*~I:32*/
                  if (chTeachRetries++ >= TEACHINMODUL_MAX_TEACHRETRIES)
                  /*~-1*/
                  {
                     /*~T*/
                     // Es wurde gen�gend Fehlversuche unternommen
                     TeachIn_SetState(TEACHIN_ON_ERROR);
                  /*~-1*/
                  }
                  /*~E:I32*/
                  /*~T*/
                  break;
               /*~-1*/
               }
               /*~E:F31*/
            /*~-1*/
            }
            /*~E:C27*/
         /*~-1*/
         }
         /*~O:I26*/
         /*~-2*/
         else
         {
            /*~I:33*/
            if (chState_Ch1 != TEACHIN_ON_ERROR)
            /*~-1*/
            {
               /*~I:34*/
               if (chState_Ch1 > chState)
               /*~-1*/
               {
                  /*~T*/
                  chNextLevel = 0;
                  /*~T*/
                  // weiter zum n�chsten Level
                  TeachIn_NextLevel();
               /*~-1*/
               }
               /*~E:I34*/
            /*~-1*/
            }
            /*~O:I33*/
            /*~-2*/
            else
            {
               /*~T*/
               // Fehler w�hrend des Teachvorgangs
               TeachIn_SetState(TEACHIN_ON_ERROR);
            /*~-1*/
            }
            /*~E:I33*/
         /*~-1*/
         }
         /*~E:I26*/
         /*~-1*/
#endif
         /*~E:I25*/
         /*~E:A24*/
         /*~A:35*/
         /*~+:CHANNEL_1*/
         /*~I:36*/
#ifdef CHANNEL_1
         /*~C:37*/
         switch (Limit_TeachTara())
         /*~-1*/
         {
            /*~F:38*/
            case -1:	// Fehler
            /*~-1*/
            {
               /*~T*/
               // Fehler w�hrend des Teachvorgangs
               chState = TEACHIN_ON_ERROR;
               /*~T*/
               break;
            /*~-1*/
            }
            /*~E:F38*/
            /*~F:39*/
            case 0:		// Alles okay
            /*~-1*/
            {
               /*~T*/
               chTeachRetries = 0;

               // weiter zum n�chsten Level
               chState++;
               /*~A:40*/
               /*~+:Eintrag in Diagnosespeicher vornehmen*/
               /*~T*/
               Diagnosis_WriteMessage2Flash(DIAGNOSIS_MESSAGE_TARATEACH);
               /*~E:A40*/
               /*~T*/
               break;
            /*~-1*/
            }
            /*~E:F39*/
            /*~F:41*/
            case 1:		// Gewicht instabil
            /*~-1*/
            {
               /*~I:42*/
               if (chTeachRetries++ >= TEACHINMODUL_MAX_TEACHRETRIES)
               /*~-1*/
               {
                  /*~T*/
                  // Es wurde gen�gend Fehlversuche unternommen
                  TeachIn_SetState(TEACHIN_ON_ERROR);
               /*~-1*/
               }
               /*~E:I42*/
               /*~T*/
               break;
            /*~-1*/
            }
            /*~E:F41*/
         /*~-1*/
         }
         /*~E:C37*/
         /*~-1*/
#endif
         /*~E:I36*/
         /*~E:A35*/
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F23*/
      /*~F:43*/
      case TEACHIN_INIT_LAST_LEVEL:
      /*~-1*/
      {
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F43*/
      /*~F:44*/
      case TEACHIN_LAST_LEVEL:		// Limit-Teach
      /*~-1*/
      {
         /*~A:45*/
         /*~+:CHANNEL_0*/
         /*~I:46*/
#ifdef CHANNEL_0
         /*~I:47*/
         if (!chNextLevel)
         /*~-1*/
         {
            /*~C:48*/
            switch (Limit_SetAlarmLimitByWeight(1,0))
            /*~-1*/
            {
               /*~F:49*/
               case 0:		// Alles okay
               /*~-1*/
               {
                  /*~T*/
                  chTeachRetries = 0;

                  // weiter zum n�chsten Level
                  chNextLevel = 1;
                  /*~A:50*/
                  /*~+:Eintrag in Diagnosespeicher vornehmen*/
                  /*~T*/
                  Diagnosis_WriteMessage2Flash(DIAGNOSIS_MESSAGE_LIMITTEACH);
                  /*~E:A50*/
                  /*~T*/
                  break;
               /*~-1*/
               }
               /*~E:F49*/
               /*~F:51*/
               case 1:		// Gewicht instabil
               /*~-1*/
               {
                  /*~I:52*/
                  if (chTeachRetries++ >= TEACHINMODUL_MAX_TEACHRETRIES)
                  /*~-1*/
                  {
                     /*~T*/
                     // Es wurde gen�gend Fehlversuche unternommen
                     TeachIn_SetState(TEACHIN_ON_ERROR);
                  /*~-1*/
                  }
                  /*~E:I52*/
                  /*~T*/
                  break;
               /*~-1*/
               }
               /*~E:F51*/
            /*~-1*/
            }
            /*~E:C48*/
         /*~-1*/
         }
         /*~O:I47*/
         /*~-2*/
         else
         {
            /*~I:53*/
            if (chState_Ch1 != TEACHIN_ON_ERROR)
            /*~-1*/
            {
               /*~I:54*/
               if (chState_Ch1 > chState)
               /*~-1*/
               {
                  /*~T*/
                  chNextLevel = 0;
                  /*~T*/
                  // weiter zum n�chsten Level
                  TeachIn_NextLevel();
               /*~-1*/
               }
               /*~E:I54*/
            /*~-1*/
            }
            /*~O:I53*/
            /*~-2*/
            else
            {
               /*~T*/
               // Fehler w�hrend des Teachvorgangs
               TeachIn_SetState(TEACHIN_ON_ERROR);
            /*~-1*/
            }
            /*~E:I53*/
         /*~-1*/
         }
         /*~E:I47*/
         /*~-1*/
#endif
         /*~E:I46*/
         /*~E:A45*/
         /*~A:55*/
         /*~+:CHANNEL_1*/
         /*~I:56*/
#ifdef CHANNEL_1
         /*~C:57*/
         switch (Limit_SetAlarmLimitByWeight(1,0))
         /*~-1*/
         {
            /*~F:58*/
            case 0:		// Alles okay
            /*~-1*/
            {
               /*~T*/
               chTeachRetries = 0;

               // weiter zum n�chsten Level
               chState++;
               /*~A:59*/
               /*~+:Eintrag in Diagnosespeicher vornehmen*/
               /*~T*/
               Diagnosis_WriteMessage2Flash(DIAGNOSIS_MESSAGE_LIMITTEACH);
               /*~E:A59*/
               /*~T*/
               break;
            /*~-1*/
            }
            /*~E:F58*/
            /*~F:60*/
            case 1:		// Gewicht instabil
            /*~-1*/
            {
               /*~I:61*/
               if (chTeachRetries++ >= TEACHINMODUL_MAX_TEACHRETRIES)
               /*~-1*/
               {
                  /*~T*/
                  // Es wurde gen�gend Fehlversuche unternommen
                  TeachIn_SetState(TEACHIN_ON_ERROR);
               /*~-1*/
               }
               /*~E:I61*/
               /*~T*/
               break;
            /*~-1*/
            }
            /*~E:F60*/
         /*~-1*/
         }
         /*~E:C57*/
         /*~-1*/
#endif
         /*~E:I56*/
         /*~E:A55*/
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F44*/
      /*~F:62*/
      case TEACHIN_WAIT_4_KEY_RELEASED:
      /*~-1*/
      {
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F62*/
      /*~F:63*/
      case TEACHIN_CONFIRMATION:
      /*~-1*/
      {
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F63*/
      /*~F:64*/
      case TEACHIN_ON_ERROR:
      /*~-1*/
      {
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F64*/
      /*~F:65*/
      case TEACHIN_WAIT_4_DISCONNECTED:
      /*~-1*/
      {
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F65*/
      /*~F:66*/
      case TEACHIN_RESTART_TEACHIN:
      /*~-1*/
      {
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F66*/
      /*~F:67*/
      case TEACHIN_SHOW_ACTIVE:
      /*~-1*/
      {
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F67*/
   /*~-1*/
   }
   /*~E:C18*/
   /*~I:68*/
#ifdef CHANNEL_1
   /*~T*/
   Global.chTeachInStatus = chState; 
   /*~-1*/
#endif
   /*~E:I68*/
/*~-1*/
}
/*~E:F7*/
/*~E:A6*/
/*~A:69*/
/*~+:char TeachInModul(void)*/
/*~F:70*/
char TeachInModul(void)
/*~-1*/
{
   /*~I:71*/
#ifdef CHANNEL_0
   /*~T*/
   return TeachIn();
   /*~-1*/
#endif
   /*~E:I71*/
   /*~I:72*/
#ifdef CHANNEL_1
   /*~T*/
   return 0;
   /*~-1*/
#endif
   /*~E:I72*/
/*~-1*/
}
/*~E:F70*/
/*~E:A69*/
/*~A:73*/
/*~+:char TeachInModul_IsModulActive(void)*/
/*~F:74*/
char TeachInModul_IsModulActive(void)
/*~-1*/
{
   /*~I:75*/
   if (TeachIn_GetState() == TEACHIN_NOT_CONNECTED)
   /*~-1*/
   {
      /*~T*/
      return 0;
   /*~-1*/
   }
   /*~O:I75*/
   /*~-2*/
   else
   {
      /*~T*/
      return 1;
   /*~-1*/
   }
   /*~E:I75*/
/*~-1*/
}
/*~E:F74*/
/*~E:A73*/
