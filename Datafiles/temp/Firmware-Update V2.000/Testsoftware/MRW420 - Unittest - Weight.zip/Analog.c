/*~-1*/
/*~XSF_LANGUAGE: C/C++*/
/*~K*/
/*~+:File :        Analog.c*/
/*~+:*/
/*~+:Version :     V1.0*/
/*~+:*/
/*~+:Date :        25.08.2005*/
/*~+:*/
/*~+:Time :        13:11*/
/*~+:*/
/*~+:Author :      MOF*/
/*~+:*/
/*~+:Hardware :*/
/*~+:*/
/*~+:Description :*/
/*~+:*/
/*~+:*/
/*~A:1*/
/*~+:Includes*/
/*~T*/
// #include "Analog.h"
// #include "ADuC836Driver.h"
#include "Diagnosis.h"
#include "Global.h" 
#include "math.h"
/*~E:A1*/
/*~A:2*/
/*~+:Funktionseigene Definitionen*/
/*~T*/
/// @cond PROGRAMMERS_MANUAL
/*~T*/
/// @endcond
/*~E:A2*/
/*~A:3*/
/*~+:Funktionseigene Struktur-Definitionen*/
/*~T*/
/// @cond PROGRAMMERS_MANUAL
/*~T*/
/// @endcond
/*~E:A3*/
/*~A:4*/
/*~+:Funktionsprototypen*/
/*~T*/
void Analog(void);
void Analog_CheckPowerSupply(long lRMW_PowerSupply );
void Analog_CheckPowerSupplyStatus(void);
char Analog_GetTemperatureOffset(void);
void Analog_Ini(unsigned char chMode);
void Analog_SetTemperatureOffset(char byOffset2Set,char byMode);
/*~E:A4*/
/*~A:5*/
/*~+:Globale Variablen*/
/*~T*/
/// @cond PROGRAMMERS_MANUAL
/*~T*/
/// @endcond
/*~E:A5*/
/*~A:6*/
/*~+:void Analog(void)*/
/*~F:7*/
void Analog(void)
/*~-1*/
{
   /*~A:8*/
   /*~+:Variablendeklarationen*/
   /*~T*/
   unsigned char chADCFlag;
   long lADC_Measurement;
   /*~E:A8*/
   /*~A:9*/
   /*~+:Variableninitialisierungen*/
   /*~T*/

   /*~E:A9*/
   /*~T*/
   chADCFlag = ADuC836_ADCIsNewConversionValue(ADuC836_ADC_AUXILIARY);
   /*~I:10*/
   if (chADCFlag)
   /*~-1*/
   {
      /*~T*/
      lADC_Measurement = ADuC836_ADCGetConversionValue(ADuC836_ADC_AUXILIARY,0);
   /*~-1*/
   }
   /*~O:I10*/
   /*~-2*/
   else
   {
      /*~A:11*/
      /*~+:Kanal 0*/
      /*~I:12*/
#ifdef CHANNEL_0
      /*~T*/
      chADCFlag = ADuC836_ADCIsNewConversionValue(ADuC836_ADC_AUXILIARY_TOGGLE);
      /*~I:13*/
      if (chADCFlag)
      /*~-1*/
      {
         /*~T*/
         lADC_Measurement = ADuC836_ADCGetConversionValue(ADuC836_ADC_AUXILIARY_TOGGLE,0);
      /*~-1*/
      }
      /*~O:I13*/
      /*~-2*/
      else
      {
         /*~T*/
         // Abbruch
         return;
      /*~-1*/
      }
      /*~E:I13*/
      /*~-1*/
#endif
      /*~E:I12*/
      /*~E:A11*/
   /*~-1*/
   }
   /*~E:I10*/
   /*~I:14*/
   if (lADC_Measurement != 0x80000000)
   /*~-1*/
   {
      /*~C:15*/
      switch (chADCFlag)
      /*~-1*/
      {
         /*~F:16*/
         case ANALOG_INPUT_AIN3:
         /*~-1*/
         {
            /*~T*/
            break;
         /*~-1*/
         }
         /*~E:F16*/
         /*~F:17*/
         case ANALOG_INPUT_AIN4:
         /*~-1*/
         {
            /*~T*/
            break;
         /*~-1*/
         }
         /*~E:F17*/
         /*~F:18*/
         case ANALOG_INPUT_TEMPERATURE:
         /*~-1*/
         {
            /*~I:19*/
#ifndef SYSTEM_CND_UNITTEST_WEIGHT
            /*~I:20*/
            if (!(g_SystemControl.bySimulate & 0x02))
            /*~-1*/
            {
               /*~T*/
               Global.byTemperature = (char)((lADC_Measurement / 256 - 128) - Global.byTemperatureOffset);
               /*~A:21*/
               /*~+:Die Temperatur darf sich von einer zur n�chsten Messung um maximal ein Grad �ndern !*/
               /*~I:22*/
               if (Global.byLastTemperature > -128)
               /*~-1*/
               {
                  /*~I:23*/
                  if (Global.byTemperature > Global.byLastTemperature)
                  /*~-1*/
                  {
                     /*~T*/
                     Global.byTemperature = Global.byLastTemperature + 1;
                  /*~-1*/
                  }
                  /*~O:I23*/
                  /*~-2*/
                  else
                  {
                     /*~I:24*/
                     if (Global.byTemperature < Global.byLastTemperature)
                     /*~-1*/
                     {
                        /*~T*/
                        Global.byTemperature = Global.byLastTemperature - 1;
                     /*~-1*/
                     }
                     /*~E:I24*/
                  /*~-1*/
                  }
                  /*~E:I23*/
               /*~-1*/
               }
               /*~O:I22*/
               /*~-2*/
               else
               {
                  /*~T*/
                  // der letzte Temperaturwert ist noch nicht initialisiert
               /*~-1*/
               }
               /*~E:I22*/
               /*~E:A21*/
               /*~T*/
               Global.byLastTemperature = Global.byTemperature; 
            /*~-1*/
            }
            /*~O:I20*/
            /*~-2*/
            else
            {
               /*~A:25*/
               /*~+:Simulation der Temperatur*/
               /*~T*/
               Global.byTemperature = Global.bySimulatedTemperature;
               /*~E:A25*/
            /*~-1*/
            }
            /*~E:I20*/
            /*~-1*/
#endif
            /*~E:I19*/
            /*~T*/
            break;
         /*~-1*/
         }
         /*~E:F18*/
         /*~F:26*/
         case ANALOG_INPUT_AIN5:	// Netzteilspannung
         /*~-1*/
         {
            /*~T*/
            Analog_CheckPowerSupplyStatus();
            /*~A:27*/
            /*~+:Kanal 0*/
            /*~I:28*/
#ifdef CHANNEL_0
            /*~T*/
            // Netzteil pr�fen
            Analog_CheckPowerSupply(lADC_Measurement);
            /*~-1*/
#endif
            /*~E:I28*/
            /*~E:A27*/
            /*~I:29*/
#ifdef VCC_CHECK_ON_BOTH_CHANELS
            /*~A:30*/
            /*~+:Kanal 1*/
            /*~I:31*/
#ifdef CHANNEL_1
            /*~T*/
            // Netzteil pr�fen
            Analog_CheckPowerSupply(lADC_Measurement);
            /*~-1*/
#endif
            /*~E:I31*/
            /*~E:A30*/
            /*~-1*/
#endif
            /*~E:I29*/
            /*~T*/
            break;
         /*~-1*/
         }
         /*~E:F26*/
      /*~-1*/
      }
      /*~E:C15*/
   /*~-1*/
   }
   /*~E:I14*/
/*~-1*/
}
/*~E:F7*/
/*~E:A6*/
/*~A:32*/
/*~+:void Analog_CheckPowerSupply(long lRMW_PowerSupply)*/
/*~F:33*/
void Analog_CheckPowerSupply(long lRMW_PowerSupply)
/*~-1*/
{
   /*~T*/
   Global.lRMW_PowerSupply = lRMW_PowerSupply;
   /*~I:34*/
   if ((lRMW_PowerSupply > OBERE_GRENZE_NETZTEIL)||(lRMW_PowerSupply < UNTERE_GRENZE_NETZTEIL))
   /*~-1*/
   {
      /*~I:35*/
      if (Global.byErrorPowerSupplyCounter > 20)
      /*~-1*/
      {
         /*~A:36*/
         /*~+:Sicherheitsfunktion 'Netzteilspannung' aufrufen*/
         /*~+:*/
         /*~T*/
         // Sicherheitsfunktion 'Netzteilspannung' aufrufen
         Diagnosis_SecurityPowerSupply(POWERSUPPLY_OUT_OF_LIMITS);
         /*~E:A36*/
      /*~-1*/
      }
      /*~O:I35*/
      /*~-2*/
      else
      {
         /*~T*/
         Global.byErrorPowerSupplyCounter++;
      /*~-1*/
      }
      /*~E:I35*/
   /*~-1*/
   }
   /*~O:I34*/
   /*~-2*/
   else
   {
      /*~T*/
      Global.byErrorPowerSupplyCounter= 0;
   /*~-1*/
   }
   /*~E:I34*/
/*~-1*/
}
/*~E:F33*/
/*~E:A32*/
/*~A:37*/
/*~+:void Analog_CheckPowerSupplyStatus(void)*/
/*~F:38*/
void Analog_CheckPowerSupplyStatus(void)
/*~-1*/
{
   /*~I:39*/
   if (!ANALOG_VCC_OK)
   /*~-1*/
   {
      /*~I:40*/
      if (Global.byErrorPowerSupplyStateCounter > 20)
      /*~-1*/
      {
         /*~A:41*/
         /*~+:Sicherheitsfunktion 'Netzteilstatus' aufrufen*/
         /*~+:*/
         /*~T*/
         // Sicherheitsfunktion 'Netzteilstatus' aufrufen
         Diagnosis_SecurityPowerSupply(POWERSUPPLY_VCC_NOK);
         /*~E:A41*/
      /*~-1*/
      }
      /*~O:I40*/
      /*~-2*/
      else
      {
         /*~T*/
         Global.byErrorPowerSupplyStateCounter++;
      /*~-1*/
      }
      /*~E:I40*/
   /*~-1*/
   }
   /*~O:I39*/
   /*~-2*/
   else
   {
      /*~T*/
      Global.byErrorPowerSupplyStateCounter= 0;
   /*~-1*/
   }
   /*~E:I39*/
/*~-1*/
}
/*~E:F38*/
/*~E:A37*/
/*~A:42*/
/*~+:char Analog_GetTemperatureOffset(void)*/
/*~F:43*/
char Analog_GetTemperatureOffset(void)
/*~-1*/
{
   /*~T*/
   return Global.byTemperatureOffset;
/*~-1*/
}
/*~E:F43*/
/*~E:A42*/
/*~A:44*/
/*~+:void Analog_Ini(unsigned char chMode)*/
/*~F:45*/
void Analog_Ini(unsigned char chMode)
/*~-1*/
{
   /*~A:46*/
   /*~+:Variablendeklarationen*/
   /*~T*/
   // Variablendeklarationen
   float fConversationRate;
   /*~E:A46*/
   /*~A:47*/
   /*~+:Variableninitialisierungen*/
   /*~T*/
   // Variableninitialisierungen

   /*~E:A47*/
   /*~I:48*/
   if (!chMode)
   /*~-1*/
   {
      /*~T*/
      Analog_SetTemperatureOffset(0,ANALOG_TEMPERATURE_CALIBRATION_CLEAR_OFFSET);
      /*~T*/
      /* Wandlungsrate abspeichern */
      fConversationRate = SYSTEM_CND_DEFAULT_CONVERSION_RATE_WEIGHT;

      Save_Parameter(LOAD_SAVE_MEASUREMENT_CONVERSIONRATE,&fConversationRate,4);

   /*~-1*/
   }
   /*~O:I48*/
   /*~-2*/
   else
   {
      /*~T*/
      Load_Parameter(LOAD_SAVE_TEMPERATURE_OFFSET,&Global.byTemperatureOffset,1);
      /*~T*/
      /* Wandlungsrate auslesen */
      Load_Parameter(LOAD_SAVE_MEASUREMENT_CONVERSIONRATE,&fConversationRate,4);
      /*~I:49*/
      if ((fConversationRate > 105.3)||(fConversationRate < 5.35))
      /*~-1*/
      {
         /*~T*/
         /* Wandlungsrate abspeichern */
         fConversationRate = SYSTEM_CND_DEFAULT_CONVERSION_RATE_WEIGHT;

         Save_Parameter(LOAD_SAVE_MEASUREMENT_CONVERSIONRATE,&fConversationRate,4);

      /*~-1*/
      }
      /*~E:I49*/
   /*~-1*/
   }
   /*~E:I48*/
   /*~T*/
   /* AD-Wandler initialisieren */
   ADuC836_ADCSetSincFilter(fConversationRate,ADuC836_ADC_FREQUENCY_32KHZ);
   /*~T*/
   Global.byLastTemperature = -128;
   Global.byErrorPowerSupplyCounter = 0;
   Global.byErrorPowerSupplyStateCounter = 0;
/*~-1*/
}
/*~E:F45*/
/*~E:A44*/
/*~A:50*/
/*~+:void Analog_SetTemperatureOffset(char byOffset2Set,char byMode)*/
/*~F:51*/
void Analog_SetTemperatureOffset(char byOffset2Set,char byMode)
/*~-1*/
{
   /*~C:52*/
   switch (byMode)
   /*~-1*/
   {
      /*~F:53*/
      case ANALOG_TEMPERATURE_CALIBRATION_CLEAR_OFFSET:
      /*~-1*/
      {
         /*~T*/
         Global.byTemperatureOffset = 0;
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F53*/
      /*~F:54*/
      case ANALOG_TEMPERATURE_CALIBRATION_SET_OFFSET_MANUALY:
      /*~-1*/
      {
         /*~T*/
         Global.byTemperatureOffset = byOffset2Set;
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F54*/
      /*~F:55*/
      case ANALOG_TEMPERATURE_CALIBRATION_SET_OFFSET_AUTOMATICLY:
      /*~-1*/
      {
         /*~T*/
         /* alt - bis 03.11.2011*/
         /* Global.byTemperatureOffset = Global.byTemperature - byOffset2Set; */
         /* ga�ndert: 03.11.2011 */
         Global.byTemperatureOffset = Global.byTemperatureOffset + Global.byTemperature - byOffset2Set;
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F55*/
   /*~-1*/
   }
   /*~E:C52*/
   /*~T*/
   // 04.11.2016
   Global.byLastTemperature = -128;
   /*~I:56*/
   // 04.11.2016
#ifdef MOF 
   /*~T*/
   // Temperaturen abgleichen
   Global.byTemperature = Global.byTemperature - Global.byTemperatureOffset;
   Global.byLastTemperature = Global.byTemperature;
   /*~-1*/
#endif
   /*~E:I56*/
   /*~T*/
   Save_Parameter(LOAD_SAVE_TEMPERATURE_OFFSET,&Global.byTemperatureOffset,1);
/*~-1*/
}
/*~E:F51*/
/*~E:A50*/
