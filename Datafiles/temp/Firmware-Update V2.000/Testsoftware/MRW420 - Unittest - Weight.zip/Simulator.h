/*~-1*/
/*~XSF_LANGUAGE: C/C++*/
/*~I:1*/
#ifndef __SIMULATOR_H

/*~T*/
#define __SIMULATOR_H

/*~A:2*/
/*~+:Includes*/
/*~T*/

/*~E:A2*/
/*~A:3*/
/*~+:Definitionen*/
/*~T*/

/*~E:A3*/
/*~A:4*/
/*~+:Struktur-Definitionen*/
/*~T*/

/*~E:A4*/
/*~A:5*/
/*~+:Funktionsdeklarationen*/
/*~T*/
long Simulator_GetRMW(void);
/*~E:A5*/
/*~A:6*/
/*~+:Variablen*/
/*~T*/

/*~E:A6*/
/*~-1*/
#endif
/*~E:I1*/
