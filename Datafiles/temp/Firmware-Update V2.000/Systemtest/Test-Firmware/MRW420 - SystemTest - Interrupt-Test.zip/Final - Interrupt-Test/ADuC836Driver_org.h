/*~-1*/
/*~XSF_LANGUAGE: C/C++*/
/*~K*/
/*~+:File :        ADuC836Driver.h*/
/*~+:*/
/*~+:Version :     V1.000*/
/*~+:*/
/*~+:Date :        */
/*~+:Time :        */
/*~+:*/
/*~+:Author :      MOF*/
/*~+:*/
/*~+:Hardware :*/
/*~+:*/
/*~+:Description :*/
/*~A:1*/
/*~+:Versions-Beschreibung*/
/*~K*/
/*#LH:0F"Doxygen_ADuC836Driver.h"=29-51*/
/*~+:-> Doxygen_ADuC836Driver.h*/
/*~+:*/
/*~+:Doxygen_ADuC836Driver.h*/
/*~E:A1*/
/*~I:2*/
#ifndef __ADUC836DRIVER_H 
/*~T*/
#define __ADUC836DRIVER_H
/*~A:3*/
/*~+:Konfiguration*/
/*~A:4*/
/*~+:Portbits*/
/*~T*/
// Portbits
sbit P00 = 0x80;
sbit P01 = 0x81;
sbit P02 = 0x82;
sbit P03 = 0x83;
sbit P04 = 0x84;
sbit P05 = 0x85;
sbit P06 = 0x86;
sbit P07 = 0x87;

sbit P10 = 0x90;
sbit P11 = 0x91;
sbit P12 = 0x92;
sbit P13 = 0x93;
sbit P14 = 0x94;
sbit P15 = 0x95;
sbit P16 = 0x96;
sbit P17 = 0x97;

sbit P20 = 0xA0;
sbit P21 = 0xA1;
sbit P22 = 0xA2;
sbit P23 = 0xA3;
sbit P24 = 0xA4;
sbit P25 = 0xA5;
sbit P26 = 0xA6;
sbit P27 = 0xA7;

sbit P30 = 0xB0;
sbit P31 = 0xB1;
sbit P32 = 0xB2;
sbit P33 = 0xB3;
sbit P34 = 0xB4;
sbit P35 = 0xB5;
sbit P36 = 0xB6;
sbit P37 = 0xB7; 
/*~E:A4*/
/*~A:5*/
/*~+:Flash*/
/*~T*/
#define MAX_FLASH_PAGE 1023

// Definitionen zum Ablauf
#define FLASH_COMMAND_READ_PAGE      		1
#define FLASH_COMMAND_WRITE_PAGE      		2
#define FLASH_COMMAND_VERIFY_PAGE     		4
#define FLASH_COMMAND_ERASE_PAGE      		5
#define FLASH_COMMAND_ERASE_ALL_PAGES 		6

/*~E:A5*/
/*~A:6*/
/*~+:Timer*/
/*~T*/
#define TIMER_NB_TIMERS			6			///< Anzahl der zu initialisierenden Timer
/*~T*/
#define TIMER_TIMEBASE_10MS
// #define TIMER_TIMEBASE_1MS
/*~E:A6*/
/*~A:7*/
/*~+:RS232*/
/*~T*/

/*~E:A7*/
/*~A:8*/
/*~+:SPI*/
/*~T*/

/*~E:A8*/
/*~E:A3*/
/*~A:9*/
/*~+:Includes*/
/*~T*/
#include "ADuC836.h"
/*~E:A9*/
/*~A:10*/
/*~+:Definitionen*/
/*~A:11*/
/*~+:ADC*/
/*~A:12*/
/*~+:ADC-Frequenz*/
/*~T*/
#define ADuC836_ADC_FREQUENCY_32KHZ		32768
/*~E:A12*/
/*~T*/
#define ADuC836_ADC_PRIMARY				0		///< Haupt-ADC
#define ADuC836_ADC_AUXILIARY			1		///< Hilfs-ADC
#define ADuC836_ADC_PRIMARY_TOGGLE		2		///< 2.Haupt-ADC (Toggle)
#define ADuC836_ADC_AUXILIARY_TOGGLE	3		///< 2.Hilfs-ADC(Toggle)
/*~A:13*/
/*~+:Hauptkanal-Konfiguration*/
/*~T*/
// Eingangsspannungsbereiche
#define ADuC836_ADC_RANGE_20MV		0x00	///< Eingangsspannungsbereich +/-20mV.
#define ADuC836_ADC_RANGE_40MV		0x01	///< Eingangsspannungsbereich +/-40mV.
#define ADuC836_ADC_RANGE_80MV		0x02	///< Eingangsspannungsbereich +/-80mV.
#define ADuC836_ADC_RANGE_160MV		0x03	///< Eingangsspannungsbereich +/-160mV.
#define ADuC836_ADC_RANGE_320MV		0x04	///< Eingangsspannungsbereich +/-320mV.
#define ADuC836_ADC_RANGE_640MV		0x05	///< Eingangsspannungsbereich +/-640mV.
#define ADuC836_ADC_RANGE_1280MV	0x06	///< Eingangsspannungsbereich +/-1,28V.
#define ADuC836_ADC_RANGE_2560MV	0x07	///< Eingangsspannungsbereich +/-2,56V.

/*~T*/
// Uni-/Bipolar-Modus
#define ADuC836_ADC_UNIPOLAR		0x08	///< Unipolare Betriebsart. D.h. ein kurgeschlossener Eingang entspricht 0x000000h.
#define ADuC836_ADC_BIPOLAR			0x00	///< Bipolare Betriebsart. D.h. ein kurgeschlossener Eingang entspricht 0x800000h.
/*~T*/
// Eingangspins des Differenzeingangs
#define ADuC836_ADC_INPUT_AIN1_AIN2	0x00	///< AIN1 und AIN2 bilden den Differenzeingang.
#define ADuC836_ADC_INPUT_AIN3_AIN4	0x10	///< AIN3 und AIN4 bilden den Differenzeingang.
#define ADuC836_ADC_INPUT_AIN2_AIN2	0x20	///< AIN2 und AIN2 bilden den Differenzeingang (=> interner Kurzschluss.
#define ADuC836_ADC_INPUT_AIN3_AIN2	0x30	///< AIN3 und AIN2 bilden den Differenzeingang.	
/*~T*/
// Referenzquelle
#define ADuC836_ADC_INTERNAL_REFERENCE	0x00	///< interne Referenzquelle w�hlen.
#define ADuC836_ADC_EXTERNAL_REFERENCE	0x40	///< externe Referenzquelle zwischen REFIN(+) und REFIN(-) w�hlen. 	 
/*~E:A13*/
/*~A:14*/
/*~+:Hilfskanal-Konfiguration*/
/*~T*/
// Uni-/Bipolar-Modus	s. Hauptkanal-Konfiguration
/*~T*/
// Eingangspins des ADC-Eingangs
#define ADuC836_ADC_INPUT_AIN3		0x00	///< AIN3 und AGND bilden den ADC-Eingang.
#define ADuC836_ADC_INPUT_AIN4		0x10	///< AIN4 und AGND bilden den ADC-Eingang.
#define ADuC836_ADC_INPUT_TEMP		0x20	///< Der interne Temperatursensor bildet die Eingangsquelle.
#define ADuC836_ADC_INPUT_AIN5		0x30	///< AIN5 und AGND bilden den ADC-Eingang.	
/*~T*/
// Referenzquelle	s. Hauptkanal-Konfiguration

/*~E:A14*/
/*~A:15*/
/*~+:Modi setzen*/
/*~T*/
// Betriebsmodi
#define ADuC836_ADC_POWER_DOWN				0x00	///< ADC im Power-Down-Modus.
#define ADuC836_ADC_IDLE_MODE				0x01 	///< ADC im Idle-Modus.
#define ADuC836_ADC_SINGLE_CONVERTION		0x02	///< ADC f�hrt eine einzelne Wandlung durch.
#define ADuC836_ADC_CONT_CONVERSION			0x03	///< ADC wandelt kontinuierlich den Eingangswert.
#define ADuC836_ADC_INT_ZERO_CALIBRATION	0x04	///< Interne Nullpunkt-Kalibrierung durchf�hren.
#define ADuC836_ADC_INT_SCALE_CALIBRATION	0x05	///< Interne Messbereichskalibrierung.
#define ADuC836_ADC_SYS_ZERO_CALIBRATION	0x06	///< System-Nullpunkt-Kalibrierung durchf�hren.
#define ADuC836_ADC_SYS_SCALE_CALIBRATION	0x07	///< System-Messbereichskalibrierung.
/*~T*/
// Freigabe des Hilfs-ADC's
#define ADuC836_ADC_ENABLE_AUXILIARY		0x10	///< Hilfs-ADC freigeben.

// Freigabe des Haupt-ADC's
#define ADuC836_ADC_ENABLE_PRIMARY			0x20	///< Haupt-ADC freigeben.

/*~E:A15*/
/*~A:16*/
/*~+:Default-Settings*/
/*~T*/
// Default-Ini-Settings

///< Defaultparameter f�r den Hauptkanal
#define ADuC836_ADC_DEFAULT_PRIMARY_SETTING				ADuC836_ADC_PRIMARY,ADuC836_ADC_CONT_CONVERSION|ADuC836_ADC_ENABLE_PRIMARY,ADuC836_ADC_RANGE_20MV|ADuC836_ADC_BIPOLAR|ADuC836_ADC_INPUT_AIN1_AIN2|ADuC836_ADC_EXTERNAL_REFERENCE,5.35,ADuC836_ADC_FREQUENCY_32KHZ	

#define ADuC836_ADC_DEFAULT_PRIMARY_TOGGLE_SETTING		ADuC836_ADC_PRIMARY_TOGGLE,ADuC836_ADC_CONT_CONVERSION|ADuC836_ADC_ENABLE_PRIMARY,ADuC836_ADC_RANGE_20MV|ADuC836_ADC_BIPOLAR|ADuC836_ADC_INPUT_AIN1_AIN2|ADuC836_ADC_EXTERNAL_REFERENCE,5.35,ADuC836_ADC_FREQUENCY_32KHZ
/*~T*/
///< Defaultparameter f�r den Hilfskanal
#define ADuC836_ADC_DEFAULT_AUXILIARY_SETTING			ADuC836_ADC_AUXILIARY,ADuC836_ADC_CONT_CONVERSION|ADuC836_ADC_ENABLE_AUXILIARY,ADuC836_ADC_INPUT_TEMP|ADuC836_ADC_BIPOLAR|ADuC836_ADC_INTERNAL_REFERENCE,5.35,ADuC836_ADC_FREQUENCY_32KHZ	

#define ADuC836_ADC_DEFAULT_AUXILIARY_TOGGLE_SETTING	ADuC836_ADC_AUXILIARY_TOGGLE,ADuC836_ADC_CONT_CONVERSION|ADuC836_ADC_ENABLE_AUXILIARY,ADuC836_ADC_INPUT_AIN3|ADuC836_ADC_BIPOLAR|ADuC836_ADC_EXTERNAL_REFERENCE,5.35,ADuC836_ADC_FREQUENCY_32KHZ
/*~E:A16*/
/*~A:17*/
/*~+:Kalibrierung*/
/*~T*/
#define ADuC836_ADC_INTERNALZEROSCALE_CALIBRATION			1	///< interne Nullpunktkalibrierung
#define ADuC836_ADC_INTERNALFULLSCALE_CALIBRATION			2	///< interne Verst�rkungskalibrierung
#define ADuC836_ADC_SYSTEMZEROSCALE_CALIBRATION				3	///< externe Nullpunktkalibrierung
#define ADuC836_ADC_SYSTEMFULLSCALE_CALIBRATION				4	///< externe Verst�rkungskalibrierung
/*~E:A17*/
/*~E:A11*/
/*~A:18*/
/*~+:DAC*/
/*~T*/
#define ADUC836_DAC_REGREAD				2		///< Lesen der DAC-Register
/*~T*/
#define ADUC836_DAC_NORM_OP				0		///< Normale DAC-Betriebsart
#define ADUC836_DAC_CLEAR_DAC			1		///< DAC powered-down

/*~T*/
#define ADUC836_DAC_DISABLE				0		///< DAC gesperrt
#define ADUC836_DAC_ENABLE				1		///< DAC freigegeben
/*~T*/
#define ADUC836_DAC_RANGE_2_REF			0		///< DAC-Bereich von 0 bis 2.5V (Vref)
#define ADUC836_DAC_RANGE_2_VDD			1		///< DAC-Bereich von 0 bis Vanalog
/*~T*/
#define ADUC836_DAC_RESOLUTION_12BIT	0		///< DAC-Aufl�sung 12 Bit
#define ADUC836_DAC_RESOLUTION_8BIT		1		///< DAC-Aufl�sung 8 Bit
/*~T*/
#define ADUC836_DAC_OUTPUTPIN_3			0 		///< DAC-Ausgang an Pin 3
#define ADUC836_DAC_OUTPUTPIN_12		1		///< DAC-Ausgang an Pin 12
/*~T*/
#define ADUC836_DAC_RMV					0
#define ADUC836_DAC_NORM				1
#define ADUC836_DAC						2
/*~K*/
/*~+:*/
/*~T*/
// Grenzwertbetrachtung

#define ADUC836_DAC_LOWER_LIMIT			0		///< Unterer Grenzwert
#define ADUC836_DAC_UPPER_LIMIT			1		///< Oberer Grenzwert

// Verhalten bei Grenzwert�berschreitungen
#define ADUC836_DAC_KEEP_OUTPUT			0		///< bei einer Grenzwert�berschreitung soll der DAC-Ausgang auf dem Ausgangswert des Grenzwertes eingestellt werden.

#define ADUC836_DAC_IGNORE				1		///< bei einer Grenzwert�berschreitung soll der DAC-Ausgang auf dem letzten Ausgangswert verharren.

#define ADUC836_DAC_SET2ZERO			2		///< bei einer Grenzwert�berschreitung soll der DAC-Ausgang auf 0 Digit eingestellt werden

#define ADUC836_DAC_SET2MAXIMUM			3		///< bei einer Grenzwert�berschreitung soll der DAC-Ausgang auf Maximum eingestellt werden
/*~E:A18*/
/*~A:19*/
/*~+:External*/
/*~T*/
#define EXTERNAL_INTERRUPT_0					0x00	///< Externer Interrupt 0 
#define EXTERNAL_INTERRUPT_1					0x01	///< Externer Interrupt 1 
/*~T*/
#define EXTERNAL_LEVEL_CONTROLLED				0x00	///< Interrupt ist pegelgesteuert
#define EXTERNAL_EDGE_CONTROLLED				0x01	///< Interrupt ist flankengesteuert
#define EXTERNAL_LOW_PRIORITY					0x00	///< niedrige Interrupt-Priorit�t 
#define EXTERNAL_HIGH_PRIORITY					0x02	///< hohe Interrupt-Priorit�t

/*~E:A19*/
/*~A:20*/
/*~+:Flash*/
/*~T*/

/*~E:A20*/
/*~A:21*/
/*~+:SPI*/
/*~T*/
#define ADUC836_SPI_HANDSHAKE_LINE	P37	///< Handshake-Leitung der SPI-Kommunikation
/*~T*/
// Master oder Slave-Betriebsmode
#define ADUC836_SPI_MASTER_MODE				0x10		///< SFR SPICON.SPIM = 1
#define ADUC836_SPI_SLAVE_MODE				0x00		///< SFR SPICON.SPIM = 0

// Aktive Clock-Flanke
#define ADUC836_SPI_CLOCKPOLARITY_HIGH		0x08		///< SFR SPICON.CPOL = 1
#define ADUC836_SPI_CLOCKPOLARITY_LOW		0x00		///< SFR SPICON.CPOL = 0

// Ort der 'Clockphase'
#define ADUC836_SPI_CLOCKPHASE_LEADING		0x04		///< SFR SPICON.CPHA = 1
#define ADUC836_SPI_CLOCKPHASE_TRAILING		0x00		///< SFR SPICON.CPHA = 0

// Bit-�bertragungsrate
#define ADUC836_SPI_BITRATE_FCORE_16		0x03		///< SFR SPICON.SPR0 = 1 , SPICON.SPR1 = 1
#define ADUC836_SPI_BITRATE_FCORE_8			0x02		///< SFR SPICON.SPIM = 0 , SPICON.SPR1 = 1
#define ADUC836_SPI_BITRATE_FCORE_4			0x01		///< SFR SPICON.SPIM = 1 , SPICON.SPR1 = 0
#define ADUC836_SPI_BITRATE_FCORE_2			0x00		///< SFR SPICON.SPIM = 0 , SPICON.SPR1 = 0
/*~T*/
// Sonstige Einstellungen

// SPI-Freigabe
#define ADUC836_SPI_DISABLE					0x00		///< SPI-Schnittstelle gesperrt
#define ADUC836_SPI_ENABLE					0x01		///< SPI-Schnittstelle freigegeben

// Interrupt-Priorit�t
#define ADUC836_SPI_LOW_INTERRUPT_PRIORITY	0x00		///< Niedrige Interrupt-Priorit�t
#define ADUC836_SPI_HIGH_INTERRUPT_PRIORITY	0x01		///< Hohe Interrupt-Priorit�t
/*~E:A21*/
/*~A:22*/
/*~+:Versionsabfragen*/
/*~T*/
#define ADUC836_PROJECT_VERSION					0
#define ADUC836_ADC_VERSION						1
#define ADUC836_DAC_VERSION						2
#define ADUC836_EXTERNAL_VERSION				3
#define ADUC836_FLASH_VERSION					4
#define ADUC836_RS232_VERSION					5
#define ADUC836_SPI_VERSION						6
#define ADUC836_TIMER_VERSION					7
#define ADUC836_WATCHDOG_VERSION				8
/*~E:A22*/
/*~A:23*/
/*~+:Watchdog*/
/*~T*/
#define ADuC836_WATCHDOG_ENABLE								0x02	///< Watchdog freischalten
#define ADuC836_WATCHDOG_DISABLE							0x00	///< Watchdog sperren

#define ADuC836_WATCHDOG_ENABLE_INTERRUPT					0x08	///< Watchdog-Interrupt freischalten
#define ADuC836_WATCHDOG_DISABLE_INTERRUPT					0x00	///< Watchdog-Interrupt sperren
#define ADuC836_WATCHDOG_IMMEDIATE_RESET					0x80	///< Sofortiger Reset
#define ADuC836_WATCHDOG_2000MS_RESET						0x70	///< Watchdog-Timeout nach 2000ms
#define ADuC836_WATCHDOG_1000MS_RESET						0x60	///< Watchdog-Timeout nach 1000ms
#define ADuC836_WATCHDOG_500MS_RESET						0x50	///< Watchdog-Timeout nach 500ms
#define ADuC836_WATCHDOG_250MS_RESET						0x40	///< Watchdog-Timeout nach 250ms
#define ADuC836_WATCHDOG_125MS_RESET						0x30	///< Watchdog-Timeout nach 125ms
#define ADuC836_WATCHDOG_62_5MS_RESET						0x20	///< Watchdog-Timeout nach 62.5ms
#define ADuC836_WATCHDOG_31_2MS_RESET						0x10	///< Watchdog-Timeout nach 31.2ms
#define ADuC836_WATCHDOG_15_6MS_RESET						0x00	///< Watchdog-Timeout nach 15.6ms

#define ADuC836_WATCHDOG_DEFAULT_SETTING			ADuC836_WATCHDOG_ENABLE | ADuC836_WATCHDOG_ENABLE_INTERRUPT | ADuC836_WATCHDOG_2000MS_RESET		 	

/*~T*/
// Aktionen der externen Watchdog-Interface-Funktion
#define ADuC836_WATCHDOG_WRITEADDRESS						0		///< Adresse an der der Watchdog ausgel�st wurde abspeichern
#define ADuC836_WATCHDOG_READADDRESS						1		///< Adresse an der der Watchdog ausgel�st wurde auslesen
#define ADuC836_WATCHDOG_CLEARADDRESS						2		///< Adresse an der der Watchdog ausgel�st wurde l�schen
/*~E:A23*/
/*~E:A10*/
/*~A:24*/
/*~+:Strukturdefinitionen*/
/*~A:25*/
/*~+:DAC*/
/*~T*/
typedef struct{
	long			lLowerLimit;					///< unterer Grenzwert
	long			lUpperLimit;					///< oberer Grenzwert
	unsigned char	byLowerLimitBehavior;			///< Verhalten im unteren Grenzwert
	unsigned char	byUpperLimitBehavior;			///< Verhalten im oberen Grenzwert
	unsigned int 	uHysteresisLowerLimit;			///< Zeithysteres unterer Grenzwert
	unsigned int 	uHysteresisUpperLimit;			///< Zeithysteres oberer Grenzwert
	unsigned char	byLimitSet;						///< Flags f�r gesetzte Grenzwerte

	unsigned char	byLimitState;					///< Grenzwert-Status
	unsigned int 	uLimitHysteresisCounter;		///< Z�hler f�r Zeithysterese 	
}DAC_LIMITS;
/*~T*/
typedef struct{
	unsigned char 	byPointsSet;					///< Kenn-Nummer des Referenzpunktes
	float 			fTrueValue;						///< Istwert dieses Referenzpunktes
	float 			fDesiredValue;					///< Sollwert dieses Referenzpunktes
	long 			lConvertionValue;				///< Digitalwert des Referenzpunktes inklusive Normierung
	long 			lRMV;							///< Digitalwert Rohmesswert zur DA-Wandlung
}DAC_CALIBRATIONPOINT;

/*~T*/
typedef struct
{
	float 					fOffset_RMV;			///< Offset der RMV-Normierung
	float 					fGain_RMV;				///< Verst�rkung der RMV-Normierung
	float 					fOffset_Norm;			///< Offset der DAC-Normierung
	float 					fGain_Norm;				///< Verst�rkung der DAC-Normierung 
	DAC_LIMITS				Limits;					///< DAV-Grenzwerte
	DAC_CALIBRATIONPOINT 	CalibrationPoint[2];	///< DAC-Kalibrierpunkte
	unsigned char 			bCorrectionOn;			///< Additive Korrektur eingeschaltet			
}DAC_SETTINGS;
/*~E:A25*/
/*~A:26*/
/*~+:RS232*/
/*~T*/
typedef struct
{
	unsigned char	chNewCommandReceived;	///< Neues Kommando empfangen
	unsigned char 	chRS232CommunicationInProcess; ///< Kommunikation l�uft
	unsigned char*	pchRecBuffer;			///< Empfangsbuffer
	unsigned char*	pchRecBufferIndex;
	unsigned int 	nTransPointer;			///< Zeiger auf das zu sendende Zeichen
	unsigned char*	pchTransBuffer;			///< Sendebuffer
	char 			bEOT;					///< 1 = Daten sind gesendet
	unsigned char	chBufferSize;			///< Eingangspuffergr��e pro Befehl
	char			bESC;					///< es wurde ein ESC (0x1B) empfanhen
	unsigned char 	bTransmissionReleased;	///< RS232-Ausgabe freigegeben
	unsigned long 	ulTimeoutRS232Release;	///< Timeout der RS232-Freigabe
}RS232_T;
/*~E:A26*/
/*~A:27*/
/*~+:SPI*/
/*~T*/
typedef struct
{
	unsigned char	chNewCommandReceived;	///< Neues Kommando empfangen
	unsigned char 	chSPICommunicationInProcess;	///< SPI-Kommunikation l�uft 
	char 			byRecPointer;			///< Zeiger auf das zu sendende Zeichen
	unsigned char*	pchRecBuffer;			///< Zeiger auf den Empfangsbuffer
	unsigned char*	pchRecBufferIndex;
	unsigned char 	chSPIDataReceived;		///< Datum empfangen
	unsigned long 	ulTimeout;				///< Timeout-Zeit
	unsigned char	chBufferSize;			///< Eingangspuffergr��e pro Befehl
}SPI_T;

/*~E:A27*/
/*~A:28*/
/*~+:Timer*/
/*~T*/
typedef struct
{
	unsigned long 	ulOperatingTime;			///< Betriebszeit (kein Betriebsstundenz�hler!)
	unsigned int 	uTimebase[TIMER_NB_TIMERS];	///< Zeitbasis jedes einzelnen Timers
	unsigned long	ulDestinationTime[TIMER_NB_TIMERS];		///< Zielzeit eine jeden Timers
	unsigned long 	ulDestinationTimeout;		///< Zielzeit 'Timeout'
	unsigned char	chTimerInterfaceOnOff;		///< Schalter f�r den Aufruf der Timer-Interface-Funktion
}TIMER;
/*~E:A28*/
/*~E:A24*/
/*~A:29*/
/*~+:Funktionsdeklarationen*/
/*~T*/
// Diese Funktionen m�ssen (!!!) extern bereitgestellt werden
extern void				Communication_Receive(unsigned char chCommunicationLine,unsigned char chCharReceived);
extern void 			Debug(long lLong_1,long lLong_2,long lLong_3,long lLong_4);
extern void 			External_Interface(unsigned char chNbOfExtInterrupt);
extern unsigned char	WatchdogInterface(unsigned char chWhat2Do,unsigned int *nWatchdogAddress);
/*~T*/
extern char* ADuC836_Version(unsigned char byModul);
/*~A:30*/
/*~+:ADC*/
/*~T*/
extern unsigned char 	ADuC836_ADCCalibration(unsigned char byCalibrationMode);
extern void 			ADuC836_ADCClearNewConversationFlag(unsigned char byADC_Chanel);
extern void 			ADuC836_ADCDefaultIni(void);
extern unsigned int 	ADuC836_ADCGetConversionTime(unsigned char byChanel);
extern long 			ADuC836_ADCGetConversionValue(unsigned char byADC_Chanel,unsigned char byIgnoreNewConversionFlag);

extern unsigned char 	ADuC836_ADCGetMeasurementDepth(unsigned char byADC_Chanel, unsigned char *p_byMeasurementDepth);

extern long 			ADuC836_ADCGetZeroOffset(unsigned char byADC_Chanel);
extern unsigned char 	ADuC836_ADCIni(unsigned char byADC_Chanel, unsigned char byADC_Mode, unsigned char byADC_Configuration,float fOutputUpdateRate,float fProcessorFrequency,char chHighPriority);

extern unsigned char 	ADuC836_ADCIsNewConversionValue(unsigned char byADC_Chanel);
extern unsigned char 	ADuC836_ADCSetBurnOutMode(unsigned char byOnOff);
extern unsigned char 	ADuC836_ADCSetMeasurementDepth(unsigned char byADC_Chanel, unsigned char byMeasurementDepth);
extern unsigned char 	ADuC836_ADCSetSincFilter(float fOutputUpdateRate,float fProcessorFrequency);
extern void ADC_SetToggleMode(unsigned char byADC_Chanel,bit bOnOff);
extern unsigned char 	ADuC836_ADCSetZeroOffset(unsigned char byADC_Chanel, long lZeroOffset);
extern unsigned char 	ADuC836_ADCToggle(unsigned char byADC);
extern void 			ADuC836_ADCToggleEx(unsigned char byADC,unsigned char byConversionChanel);

extern char* 			ADuC836_ADCVersion(void);

/*~E:A30*/
/*~A:31*/
/*~+:DAC*/
/*~T*/
extern unsigned char 			ADuC836_DACCalcCalibration(void);
extern void 					ADuC836_DACCalibrationClearPoints(void);
extern unsigned char			ADuC836_DACCalibrationSetPoint(unsigned char chPoint,float fTrueValue, float fDesiredValue);

extern float 					ADuC836_DACChangeGainbyStep(float fPercent);
extern long 					ADuC836_DACChangeOffsetbyStep(long lStep);
extern void 					ADuC836_DACClearCurrentDeviation(void);
extern void 					ADuC836_DACClearLimit(unsigned char chWhichLimit);
extern unsigned char 			ADuC836_DACClearOutput(char byMode);
extern unsigned char 			ADuC836_DACConvert(long *plValue2Convert, unsigned char chPass);

extern unsigned char 			ADuC836_DACConvertByOutputCurrent(float fOutputCurrent);
extern void 					ADuC836_DACDefaultIni(void);
extern unsigned char 			ADuC836_DACEnable(char byMode);
extern void 					ADuC836_DACEnableLimit(unsigned char chWhichLimit,bit bOnOff);

extern DAC_CALIBRATIONPOINT 	ADuC836_DACGetCalibrationPoint(unsigned char chPointId);
extern char 					ADuC836_DACGetCurrentDeviationCorrectionState(void);
extern long 					ADuC836_DACGetDigital(float fAnalog);
extern long 					ADuC836_DACGetDigitalNorm(float fAnalog);
extern float 					ADuC836_DACGetGain(unsigned char chWhat2Get);
extern float 					ADuC836_DACGetLastConvertedCurrent(void);
extern long 					ADuC836_DACGetLastConvertedValue(void);
extern long 					ADuC836_DACGetLimit(unsigned char chWhichLimit);
extern unsigned char 			ADuC836_DACGetLimitBehaviour(unsigned char chWhichLimit);
extern unsigned int 			ADuC836_DACGetLimitHysteresis(unsigned char byWhichLimit);
extern unsigned char 			ADuC836_DACGetLimitState(unsigned char chWhichLimit);
extern float 					ADuC836_DACGetOffset(unsigned char chWhat2Get);
extern long 					ADuC836_DACGetValue2Convert(void);
extern void 					ADuC836_DACIni(char byOutput,char byResolution,char byRange,char byEnable);

extern unsigned char 			ADuC836_DACIsLimit(unsigned char chWhichLimit);
extern unsigned char 			ADuC836_DACIsOutputCleared(void);
extern unsigned char 			ADuC836_DACLoadCalibrationPoint(unsigned char chPointId,DAC_CALIBRATIONPOINT DAC_CalibrationPoint2Set);

extern void 					ADuC836_DACLoadSettings(DAC_SETTINGS DAC_Settings2Load);
extern DAC_SETTINGS 			ADuC836_DACSaveSettings(void);
extern void 					ADuC836_DACSetCurrentDeviation(float fDeviation2Set);
extern void 					ADuC836_DACSetCurrentDeviationCorrectionOn(unsigned char byOn);
extern void						ADuC836_DACSetDigital2Value(long lConversioValue,float fOutputValue,float fFixedOutputValue);

extern void 					ADuC836_DACSetGain(float fGain2Set);
extern void 					ADuC836_DACSetGainNorm(float fGain2Set);
extern void 					ADuC836_DACSetLimit(unsigned char chWhichLimit,long lLimitValue,unsigned char chBehaviour);

extern void 					ADuC836_DACSetLimitHysteresis(unsigned char byWhichLimit,unsigned int uHysteresis);

extern void 					ADuC836_DACSetOffset(unsigned char chWhat2Get,float fOffset2Set);
extern unsigned char 			ADuC836_DACSetOutput(char byMode);
extern unsigned char 			ADuC836_DACSetRange(char byMode);
extern unsigned char 			ADuC836_DACSetResolution(char byMode);
extern char* 					ADuC836_DACVersion(void);
/*~E:A31*/
/*~A:32*/
/*~+:External*/
/*~T*/
extern void 	ADuC836_ExternalClearInterrupt(unsigned char chInterrupt2Clear);
extern void 	ADuC836_ExternalIni(unsigned char chModeExt0,unsigned char bOnOffExt0,unsigned char chModeExt1,unsigned char bOnOffExt1);

extern void 	ADuC836_ExternalSetInterrupt(unsigned char chInterrupt2Set);
extern char* 	ADuC836_ExternalVersion(void);
/*~E:A32*/
/*~A:33*/
/*~+:Flash*/
/*~T*/
// public-Funktionen

extern char 	ADuC836_FlashCheckResult(void);
extern char 	ADuC836_FlashClear(unsigned int nStartPage, unsigned int nEndPage);
extern char 	ADuC836_FlashDataSetPage(int nPageNr);
extern char 	ADuC836_FlashDataReadChar(char* pucData, int nPageNr, unsigned int nAnzahl);
extern char 	ADuC836_FlashDataReadFloat(float* pfData, int nPageNr, unsigned int nAnzahl);
extern char 	ADuC836_FlashDataReadInteger(int* pnData, int nPageNr, unsigned int nAnzahl);
extern char 	ADuC836_FlashDataReadLong(long* plData, int nPageNr, unsigned int nAnzahl);
extern char 	ADuC836_FlashDataReadPtr(void* pData, int nPageNr, unsigned int nAnzahl);
extern char 	ADuC836_FlashDataWriteChar(char* pucData, int nPageNr, unsigned int nAnzahl);
extern char 	ADuC836_FlashDataWriteFloat(float* pfData, int nPageNr, unsigned int nAnzahl);
extern char 	ADuC836_FlashDataWriteInteger(int* pnData, int nPageNr, unsigned int nAnzahl);
extern char 	ADuC836_FlashDataWriteLong(long* plData, int nPageNr, unsigned int nAnzahl);
extern char 	ADuC836_FlashDataWritePtr(void* pData, int nPageNr, unsigned int nAnzahl);
extern char 	ADuC836_FlashEraseAll(void);
extern char 	ADuC836_FlashErasePage(void);
extern char 	ADuC836_FlashReadPage(void);
extern char* 	ADuC836_FlashVersion(void);
extern char 	ADuC836_FlashWritePage(void);
/*~E:A33*/
/*~A:34*/
/*~+:RS232*/
/*~T*/
extern char 			ADuC836_RS232GetRecBuffer(char* pDest);
extern char 			ADuC836_RS232Ini(unsigned char chDatabits,unsigned int uBaudrate,unsigned char* pchRecBuffer,unsigned char chBufferSize,unsigned char* pchTransBuffer,char byHighPriority);

extern char 			ADuC836_RS232IsCommunicationInProcess(void);
extern char 			ADuC836_RS232IsEscape(void);
extern char 			ADuC836_RS232IsNewCommand(void);
extern char 			ADuC836_RS232IsTransmissionReady(void);
extern char 			ADuC836_RS232Send(unsigned long ulTimeoutMS);
extern char 			ADuC836_RS232SetBaudrate(unsigned int nBaudrate);
extern char 			ADuC836_RS232SetDataBits(unsigned char chDatabits);
extern void 			ADuC836_RS232SetNewCommandFlag(unsigned char bSetClear);
extern void 			ADuC836_RS232SetRelease(unsigned char byOnOff,unsigned long ulTimeout);
extern char* 			ADuC836_RS232Version(void);

/*~E:A34*/
/*~A:35*/
/*~+:SPI*/
/*~T*/
extern char 	ADuC836_SPICheckTimeout(void);
extern void 	ADuC836_SPIDefaultIni(unsigned char chMasterMode,unsigned char *pRecBuffer);
extern void 	ADuC836_SPIEnable(bit bEnable);
extern char 	ADuC836_SPIGetRecBuffer(char* pDest);
extern void 	ADuC836_SPIIni(unsigned char byMode,bit bEnableSPI,char byHighPriority,unsigned char *pRecBuffer,unsigned char chBufferSize);

extern char 	ADuC836_SPIIsAcknowledge(char byWithTimeoutControl);
extern char 	ADuC836_SPIIsCommunicationInProcess(void);
extern char 	ADuC836_SPIIsNewCommand(void);

/*~I:36*/
#ifdef MOF
/*~T*/
extern char 	ADuC836_SPIIsNewCommand(char byWithTimeoutControl);
/*~-1*/
#endif
/*~E:I36*/
/*~T*/
extern char 	ADuC836_SPIReadChar(unsigned char* pchData);
extern char 	ADuC836_SPIReadPtr(unsigned char* pchData,unsigned int nNbChars);
extern char 	ADuC836_SPIReadPtrUntil(unsigned char* pchData,unsigned char chStopChar);
extern void 	ADuC836_SPIReleaseReception(void);
extern char 	ADuC836_SPISendChar(unsigned char chData);
extern char 	ADuC836_SPISendPtr(unsigned char* pchData,unsigned int nNbChars);
extern void 	ADuC836_SPISetNewCommandFlag(unsigned char bSetClear);
extern void 	ADuC836_SPISwitch2Mode(unsigned char chMode);
extern char* 	ADuC836_SPIVersion(void);
extern char 	ADuC836_SPIWait4Response(unsigned long ulTimeout);

/*~E:A35*/
/*~A:37*/
/*~+:Timer*/
/*~T*/
extern void 			ADuC836_TimerDelay(unsigned int uTimeMS);
extern void 			ADuC836_TimerCalcNewDestinationTime(unsigned char chWhichTimer,unsigned char chMode);

extern unsigned char 	ADuC836_TimerCheckTime(unsigned char chWhichTimer,unsigned char chMode);
extern bit 				ADuC836_TimerCheckTimeout(void);
extern char			 	ADuC836_TimerCorrectDestinationTime(unsigned char chWhichTimer,long lCorrectionValue);

extern void 			ADuC836_TimerIni(unsigned char chTimerInterfaceOnOff,char byHighPriority);

extern void 			ADuC836_TimerSetTimeout(unsigned int uTimeMS);
extern char 			ADuC836_TimerSetTimer(unsigned char chWhichTimer,unsigned int uTimeMS);
extern char* 			ADuC836_TimerVersion(void);
//extern void 			ADuC836_TimerWait(unsigned long ulTime) large reentrant;
extern void 			ADuC836_TimerWait(long lTime);
/*~T*/
extern void				Timer_Interface(void);
/*~E:A37*/
/*~A:38*/
/*~+:Watchdog*/
/*~T*/
extern void 			ADuC836_WatchdogClearAddress(void);
extern void 			ADuC836_WatchdogDefaultIni(void);
extern void 			ADuC836_WatchdogEnable(char chEnable);
extern void 			ADuC836_WatchdogIni(unsigned char chMode);
extern unsigned int 	ADuC836_WatchdogReadAddress(void);
extern void 			ADuC836_WatchdogReset(void);
extern void 			ADuC836_WatchdogRetrigger(void);
extern char*			ADuC836_WatchdogVersion(void);
/*~E:A38*/
/*~E:A29*/
/*~A:39*/
/*~+:Variablendeklarationen*/
/*~A:40*/
/*~+:RS232*/
/*~T*/
extern RS232_T RS232;
/*~E:A40*/
/*~A:41*/
/*~+:SPI*/
/*~T*/

/*~E:A41*/
/*~A:42*/
/*~+:Timer*/
/*~T*/
extern TIMER Timer;
/*~E:A42*/
/*~E:A39*/
/*~-1*/
#endif
/*~E:I2*/
