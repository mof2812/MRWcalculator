/*~-1*/
/*~XSF_LANGUAGE: C/C++*/
/*~A:1*/
/*~+:Versions-Beschreibung*/
/*~A:2*/
/*~+:Version und Versionsdatum*/
/*~T*/
/*!
\mainpage "Modul-Beschreibung"
\author Michael Offenbach
\date 09.02.2022
\version V1.002
\warning
*/
/*~E:A2*/
/*~A:3*/
/*~+:Lifecycle*/
/*~T*/
/*!\page LifeCyclePage Lifecycle

\section sec_LifeCyclePage_Load_Save_Modul 'Datenablage im Eeprom'

<table border=1 width=100% height=1% rules=rows cellspacing=0 bgcolor="#E0E0F0">

<tr align=left valign=top>
	<th>Version</th>
	<th>Datum</th>
	<th>Programmierer</th>
	<th>�nderungen</th>
</tr>

<tr>
	<td>1.001</td>
	<td>03.06.05</td>
	<td>Michael Offenbach</td>
	<td>Erste lauff�hige Version</td>
</tr>

<tr>
	<td>1.002</td>
	<td>29.11.21</td>
	<td>Michael Offenbach</td>
	<td>Die Funktion 'Diagnosis_SecurityCurrentInterface()' �berf�hrt nun das System im Falle einer erkannten Stromabweichung in den sicherheitsgerichteten Zustand.</td>
</tr>

</table>

*/
/*~E:A3*/
/*~E:A1*/
/*~I:4*/
#ifndef __DIAGNOSIS_H

/*~T*/
#define __DIAGNOSIS_H

/*~A:5*/
/*~+:Includes*/
/*~T*/

/*~E:A5*/
/*~A:6*/
/*~+:Definitionen*/
/*~T*/
// Spezifikation des Diagnosespeichers

#define DIAGNOSISMEMORYSIZE		500	///< Gr��e des Diagnosespeichers (maximal 500 !)
#define FLASHADR_MEMPOINTER		1001	///< Page des Pointers auf den n�chsten Speichereintrag
#define FLASHADR_MEMOVERRUN		1002	///< Merker, auf einen Speicher�berlauf 
/*~T*/
#define DO_NOT_REGISTER_SYSTEMSTART		0	///< Systemstart wird nicht registriert
#define REGISTER_SYSTEMSTART				1	///< Systemstart wird registriert

/*~T*/
#define DIAGNOSIS_CLEAR_ACTUAL_ALARM			0	///< Aktuellen Alarm l�schen
#define DIAGNOSIS_CLEAR_ALL						1	///< L�schen des Diagnosespeichers 
#define DIAGNOSIS_CLEAR_ALL_BY_INITITALISATION	2	///< L�schen des Diagnosespeichers wegen Initialisierung
/*~A:7*/
/*~+:Fehler*/
/*~T*/
// Eintr�ge (von 0x00000000 bis 0x3FFFFFFF)
#define DIAGNOSIS_CATEGORY_ERROR							0x00000000		///< Kategorie: Alarme


// #define DIAGNOSIS_ERROR_KEINER								0x00000000
// #define DIAGNOSIS_ERROR_MESSWERT							0x00000001		///< Messwert zu gross
// #define DIAGNOSIS_ERROR_NETZTEIL							0x00000002		///< Spannung au�er Bereich
#define DIAGNOSIS_ERROR_POWERSUPPLY_OUT_OF_LIMITS			0x00000002		///< Spannung au�er Bereich
#define DIAGNOSIS_ERROR_INTERNAL_COMMUNICATION				0x00000003		///< Partner meldet sich nicht mehr (Synchronisation ist nicht mehr gegeben)
// #define DIAGNOSIS_ERROR_KANALABWEICHUNG						0x00000004		///< Kanalabweichung (MRW-Limit)
// #define DIAGNOSIS_ERROR_VENTILSTROM							0x00000005		///< Fehler 'Ventilstrom' (MRW-Limit)
// #define DIAGNOSIS_ERROR_ABSCHALTWEG							0x00000006		///< Fehler 'Abschaltweg' (MRW-Limit) 
// #define DIAGNOSIS_ERROR_MEMORY_IDATA						0x00000007		///< IDATA defekt (MRW-Limit) 
// #define DIAGNOSIS_ERROR_MEMORY_XDATA						0x00000008		///< XDATA defekt (MRW-Limit) 
// #define DIAGNOSIS_ERROR_MEMORY_CODE							0x00000009		///< CODE defekt (MRW-Limit) 
// #define DIAGNOSIS_ERROR_MEMORY_EEPROM						0x0000000A		///< EEPROM defekt (MRW-Limit) 
// #define DIAGNOSIS_ERROR_BEFEHLSDEKODER						0x0000000B		///< Fehler 'Befehlsdekoder' (MRW-Limit) 	
// #define DIAGNOSIS_ERROR_CODE_ISLAND							0x0000000C		///< Fehler 'Code Island' (MRW-Limit) 				
// #define DIAGNOSIS_ERROR_INTERRUPT							0x0000000D		///< Fehler 'Interruptsystem' (MRW-Limit) 
// #define DIAGNOSIS_ERROR_SAFEACCESS_WR_XDATA					0x0000000E		///< Fehler beim Beschreiben von XDATA (MRW-Limit) 
// #define DIAGNOSIS_ERROR_SAFEACCESS_RD_XDATA					0x0000000F		///< Fehler beim Auslesen von XDATA 
// #define DIAGNOSIS_ERROR_SAFEACCESS_WR_EEPROM				0x00000010		///< Fehler beim Beschreiben vom EEPROM (MRW-Limit) 
// #define DIAGNOSIS_ERROR_SAFEACCESS_RD_EEPROM				0x00000011		///< Fehler beim Auslesen vom EEPROM (MRW-Limit) 
// #define DIAGNOSIS_ERROR_SICHERHEITSZUSTAND_PARTNER			0x00000012		///< Partner im Sicherheitszustand 
// #define DIAGNOSIS_ERROR_GRENZWERT							0x00000013		///< Grenzwert�berschreitung 
#define DIAGNOSIS_ERROR_SOFTWARE_INCOMPATIBILITY			0x00000014		///< Slave- und Master-Software inkompatibel 
#define DIAGNOSIS_ERROR_MEMORY_DYNAMIC_VARIABLES			0x00000015		///< Speicherbereich f�r dynamische Variablen zu klein	// Texte noch in UART.C einf�gen
#define DIAGNOSIS_ERROR_ID									0x00000016		///< System-ID nicht vergeben oder fehlerhaft 
#define DIAGNOSIS_ERROR_INITIALIZATION						0x00000017		///< Fehler w�hrend der Initialisierungsphase
#define DIAGNOSIS_ERROR_MEMORY_WRITE_EEPROM					0x00000020		///< Fehler beim Beschreiben des Eeproms // Texte noch in UART.C einf�gen
#define DIAGNOSIS_ERROR_MEMORY_WRITE_FLASH					0x00000021		///< Fehler beim Beschreiben des Flashss 	// Texte noch in UART.C einf�gen
#define DIAGNOSIS_ERROR_MEMORY_READ_EEPROM					0x00000022		///< Fehler beim Auslesen des Eeproms // Texte noch in UART.C einf�gen
#define DIAGNOSIS_ERROR_MEMORY_READ_FLASH					0x00000023		///< Fehler beim Auslesen des Flashs	// Texte noch in UART.C einf�gen
#define DIAGNOSIS_ERROR_WATCHDOG							0x00000025		///< Es ist ein Watchdog aufgetreten
#define DIAGNOSIS_ERROR_CURRENT_DEVIATION					0x00000040		///< Abweichung zwischen Soll- und Iststrom ist zu gro�
#define DIAGNOSIS_ERROR_PARTNER_IN_SYSTEMERROR				0x00000060		///< Partner im Sicherheitszustand
#define DIAGNOSIS_ERROR_POWERSUPPLY_STATE					0x00000070		///< Fehler 'Netzteilstatus'



/*~E:A7*/
/*~A:8*/
/*~+:Warnungen*/
/*~T*/
// Eintr�ge (von 0x80000000 bis 0xBFFFFFFF)
#define DIAGNOSIS_CATEGORY_WARNING							0x80000000		///< Kategorie: Warnungen


#define DIAGNOSIS_WARNING_NONE								0x80000000
#define DIAGNOSIS_WARNING_TEMPCOMP_OFF						0x80000001		///< Temperaturkompensation wurde ausgeschaltet
#define DIAGNOSIS_WARNING_TEMPCOMP_ON						0x80000002		///< Temperaturkompensation wurde eingeschaltet
#define DIAGNOSIS_WARNING_ID_CLEARED						0x80000003		///< System-ID gel�scht
#define DIAGNOSIS_WARNING_EMODULCOMP_OFF					0x80000006		///< E-Modul-Kompensation ausgeschaltet
#define DIAGNOSIS_WARNING_EMODULCOMP_ON						0x80000007		///< E-Modul-Kompensation eingeschaltet
#define DIAGNOSIS_WARNING_DAC_FEEDBACK_SWITCHED_OFF			0x80000020		///< Stromr�ckf�hrung ausgeschaltet
#define DIAGNOSIS_WARNING_DAC_FEEDBACK_SWITCHED_ON			0x80000021		///< Stromr�ckf�hrung eingeschaltet
#define DIAGNOSIS_WARNING_COMPENSATION_VALUE_SET_MANUALLY	0x80000022		///< Korrekturwerte der Temperaturkompensation manuell gesetzt
/*~E:A8*/
/*~A:9*/
/*~+:Meldungen*/
/*~T*/
// Eintr�ge (von 0x40000000 bis 0x7FFFFFFF) 
#define DIAGNOSIS_CATEGORY_MESSAGE						0x40000000		///< Kategorie: Meldung


// #define DIAGNOSIS_MESSAGE_KEINE							0x40000000
#define DIAGNOSIS_MESSAGE_SYSTEMSTART					0x40000001		///< Neustart
#define DIAGNOSIS_MESSAGE_LIMITTEACH					0x40000002		///< Grenzwert-Teach ausgef�hrt
#define DIAGNOSIS_MESSAGE_TARATEACH						0x40000003		///< Tara-Teach ausgef�hrt
#define DIAGNOSIS_MESSAGE_ZERO							0x40000004		///< Nullpunkt gesetzt
#define DIAGNOSIS_MESSAGE_ZERO_TO_VALUE					0x40000005		///< Nullpunkt auf einen festen Wert gesetzt
#define DIAGNOSIS_MESSAGE_CALIBRATION					0x40000006		///< Kalibrierung durchgef�hrt
#define DIAGNOSIS_MESSAGE_CALIBRATION_TO_VALUE			0x40000007		///< Kalibrierfaktor auf einen festen Wert gesetzt
#define DIAGNOSIS_MESSAGE_DIAGNOSISBUFFER_CLEARED		0x40000008		///< Diagnosespeicher gel�scht
#define DIAGNOSIS_MESSAGE_ALARMSTATUS_CLEARED			0x40000009		///< Alarmstatus gel�scht 
// #define DIAGNOSIS_MESSAGE_CODE_CRC_NEU					0x4000000A		///< CRC �ber den Codespeicher neu gebildet (MRW-Limit)
// #define DIAGNOSIS_MESSAGE_ABSOLUTSTATISTIK_GELOESCHT	0x4000000B		///< Absolutstatistik gel�scht
// #define DIAGNOSIS_MESSAGE_RELATIVSTATISTIK_GELOESCHT	0x4000000C		///< Relativstatistik gel�scht
// #define DIAGNOSIS_MESSAGE_ALARMGRENZWERT				0x4000000D		///< Alarmgrenzwert gesetzt 
// #define DIAGNOSIS_MESSAGE_VORALARM_BLINKEN_GRENZWERT	0x4000000E		///< Voralarm 'Blinken'- Grenzwert gesetzt (MRW-Limit)
// #define DIAGNOSIS_MESSAGE_VORALARMGRENZWERT				0x4000000F		///< Voralarmgrenzwert gesetzt (MRW-Limit)
// #define DIAGNOSIS_MESSAGE_AUFSETZALARMGRENZWERT			0x40000010		///< Aufsetzalarmgrenzwert gesetzt
#define DIAGNOSIS_MESSAGE_TARE_MANUAL					0x40000011		///< Tara manuell gesetzt
#define DIAGNOSIS_MESSAGE_TEMPCOMPENSATION_STARTED		0x40000012		///< Start der Kennlinienaufnahme
#define DIAGNOSIS_MESSAGE_INITIALISATION				0x40000013		///< Systeminitialisierung gestartet
// #define DIAGNOSIS_MESSAGE_EEPROM_GELOESCHT				0x40000014		///< Eeprom gel�scht
#define DIAGNOSIS_MESSAGE_OPERATINGHOURS_CLEARED		0x40000015		///< Betriebsstundenz�hler gel�scht
#define DIAGNOSIS_MESSAGE_DAC_CALIBRATION_FINISHED		0x40000018		///< Stromschnittstellen-Kalibrierung abgeschlossen
#define DIAGNOSIS_MESSAGE_DAC_CALIBRATION_FINISHED_2	0x40000019		///< Stromschnittstellen-Kalibrierung abgeschlossen und Sicherung angelegt
#define DIAGNOSIS_MESSAGE_DAC_CALIBRATION_CLEARED		0x4000001A		///< Stromschnittstellen-Kalibrierung gel�scht
#define DIAGNOSIS_MESSAGE_DAC_1ST_POINT_CALIBRATION_SET	0x4000001B		///< erster Kalibrierpunkt gesetzt
#define DIAGNOSIS_MESSAGE_DAC_2ND_POINT_CALIBRATION_SET	0x4000001C		///< zweiter Kalibrierpunkt gesetzt
#define DIAGNOSIS_MESSAGE_OPERATINGHOURS_2_CLEARED		0x4000001E		///< Relativen Betriebsstundenz�hler gel�scht
#define DIAGNOSIS_MESSAGE_RESET_BY_INI_COMMAND			0x4000001F		///< Reset aufgrund eines INI-Befehls ausgef�hrt
#define DIAGNOSIS_MESSAGE_MEASUREMENT_DEPTH_RMW_SET		0x40000020		///< Messwerttiefe zur Gewichtsermittlung gesetzt
#define DIAGNOSIS_MESSAGE_MEASUREMENT_DEPTH_CURRENT_SET	0x40000021		///< Messwerttiefe zur Gewichtsermittlung gesetzt
#define DIAGNOSIS_MESSAGE_TEMPCOMPENSATION_STOPPED		0x40000022		///< Kennlinienaufnahme gestoppt
#define DIAGNOSIS_MESSAGE_CLEAR_WATCHDOG				0x40000023		///< Watchdogadresse gel�scht
#define DIAGNOSIS_MESSAGE_TEMPCOMPENSATION_FINISHED_OK	0x40000024		///< Temperaturkompensation erfolgreich abgeschlossen
#define DIAGNOSIS_MESSAGE_TEMPCOMPENSATION_FINISHED_NOK	0x40000025		///< Temperaturkompensation fehlerhaft abgeschlossen
#define DIAGNOSIS_MESSAGE_TARE_CLEARED					0x40000026		///< Tara gel�scht
#define DIAGNOSIS_MESSAGE_WEIGHT_CONVERSIONRATE_CHANGED	0x40000030		///< Die ADC-Wandlerrate zur Gewichtsermittlung wurde ver�ndert		


/*~E:A9*/
/*~A:10*/
/*~+:Sonstiges*/
/*~T*/
// Eintr�ge (von 0xC0000000 bis 0xFFFFFFFF)
#define DIAGNOSIS_CATEGORY_MISC							0xC0000000		///< Kategorie: Sonstige



// #define DIAGNOSIS_MISC_KEINE							0xC0000000
/*~E:A10*/
/*~K*/
/*~+:*/
/*~A:11*/
/*~+:Klassifizierung der Spannungsversorgungsfehler*/
/*~+:*/
/*~T*/
#define POWERSUPPLY_OUT_OF_LIMITS		1
#define POWERSUPPLY_VCC_NOK				2
/*~E:A11*/
/*~A:12*/
/*~+:Klassifizierung der Speicherfehler*/
/*~T*/
#define DYNAMIC_VARIABLES							0	
#define WRITE_EEPROM								1
#define READ_EEPROM									2
#define WRITE_FLASH									3
#define READ_FLASH									4 
/*~E:A12*/
/*~A:13*/
/*~+:Klassifizierung der Stromschnittstellenfehler*/
/*~+:*/
/*~T*/
#define CURRENT_DEVIATION		1 
/*~E:A13*/
/*~A:14*/
/*~+:Klassifizierung der Synchronisationsfehler*/
/*~+:*/
/*~T*/
#define SYTEM_ERROR_INTERNAL_COMMUNICATION		1
/*~E:A14*/
/*~A:15*/
/*~+:Klassifizierung der Partner-Systemfehler*/
/*~T*/
#define SYSTEM_PARTNER_IN_SYSTEMERROR				1
/*~E:A15*/
/*~A:16*/
/*~+:Klassifizierung der Initialisierungsfehler*/
/*~+:*/
/*~T*/
#define SYTEM_ERROR_INITIALIZATION		1
/*~E:A16*/
/*~E:A6*/
/*~A:17*/
/*~+:Struktur-Definitionen*/
/*~T*/
typedef struct
{
//   unsigned char ucSicherheitszustand;	///< 1 = System ist im sicherheitsgerichetetem Zustand
//   unsigned char ucMasterSlave;     ///< Gegenstelle befindet sich im Sicherheitszustand 
//   unsigned char ucMesswert;        ///< Status der Messwertgenerierung
//   unsigned char ucGrenzwert;       ///< Status der Grenzwertabfrage
//   unsigned char ucNetzteil;        ///< Status der Spannungsabfrage im Netzteil
//   unsigned char ucSynchronisation; ///< Status der Kanalsynchronisation
	unsigned char ucID;					///< 1 = ID fehlerhaft oder 0
	unsigned long ulBlockMask;			///< Maske zur Sperrung der Speicherung div. Alarme
	unsigned long ulTimeSystemStart;	///< Zeitpunkt des Systemstarts
	unsigned int uiMemoryPointer;	///< Zeiger auf die n�chste Speicherzelle
	unsigned char byOverrunFlag;		///< Speicher wurde bereits einmal vollst�ndig gef�llt
	unsigned char byReadInitFlag;		///< Flag zur Initialisierung des Lese-Prozesses
	unsigned int nReadPointer;			///< Pointer des Lese-Prozesses
	unsigned int nReadEntries;			///< Anzahl der verbleibenden Diagnose-Eintr�ge
}DIAGNOSIS;


/*~E:A17*/
/*~A:18*/
/*~+:Funktionsdeklarationen*/
/*~T*/
extern void Diagnosis_ClearDiagnosis(unsigned char byMode);
extern void Diagnosis_Ini(void);
extern void Diagnosis_InitReadProcedure(void);

/*~I:19*/
#ifdef TERMINALBETRIEB 
/*~T*/
extern char Diagnosis_GetText(unsigned long ulErrorID,char* szErrorText);
/*~-1*/
#endif
/*~E:I19*/
/*~T*/
extern void Diagnosis_PrintFreeMemory(void);
extern void Diagnosis_PrintMemory(void);
extern char Diagnosis_ReadMessageFromFlash(unsigned long *ulTime, unsigned long *ulMessage);
extern void Diagnosis_SetSystemStart(void);
extern void Diagnosis_WriteMessage2Flash(unsigned long ulMessage);

/*~T*/
// Stromschnittstellenfehler
extern void Diagnosis_SecurityCurrentInterface(unsigned char chError);
// Speicherfehler
extern void Diagnosis_SecurityInitialization(unsigned char chError);	// Fehler w�hrend der Systeminitialisierung
extern void Diagnosis_SecurityInternalCommunication(unsigned char chError);	// Fehler der SPI-Kommunikation
extern void Diagnosis_SecurityMemory(unsigned char chError);
// Powersupply-Fehler
extern void Diagnosis_SecurityPartnerSystemError(unsigned char chError);	// Partner im Sicherheitszustand
extern void Diagnosis_SecurityPowerSupply(unsigned char chError);
// Synchronisations-Fehler

/*~E:A18*/
/*~A:20*/
/*~+:Variablen*/
/*~T*/
extern DIAGNOSIS Diagnosis;
extern unsigned char g_bDiagnosis_Systemneustart;
/*~E:A20*/
/*~-1*/
#endif
/*~E:I4*/
