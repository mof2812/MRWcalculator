/*~-1*/
/*~XSF_LANGUAGE: C/C++*/
/*~K*/
/*~+:File :        Texte.c*/
/*~+:*/
/*~+:Version :     V1.0*/
/*~+:*/
/*~+:Date :        107.06.2005*/
/*~+:*/
/*~+:Time :        10:23*/
/*~+:*/
/*~+:Author :      MOF*/
/*~+:*/
/*~+:Hardware :*/
/*~+:*/
/*~+:Description :*/
/*~+:*/
/*~+:*/
/*~A:1*/
/*~+:Includes*/
/*~T*/
#include "Texte.h"
/*~E:A1*/
/*~A:2*/
/*~+:Funktionseigene Definitionen*/
/*~T*/

/*~E:A2*/
/*~A:3*/
/*~+:Funktionseigene Struktur-Definitionen*/
/*~T*/

/*~E:A3*/
/*~A:4*/
/*~+:Funktionsprototypen*/
/*~T*/


/*~E:A4*/
/*~A:5*/
/*~+:Globale Variablen*/
/*~T*/
unsigned char code TEXT_MAX_LOAD[] =           {" 1000"};	///< maximale Nennlast

/*~I:6*/
#ifdef CHANNEL_0
/*~T*/
unsigned char code TEXT_E001[] =               {"E001"};	///< angegebener Kanal ung�ltig
unsigned char code TEXT_E002[] =               {"E002"};	///< angegebener Parameter ung�ltig
unsigned char code TEXT_E003[] =               {"E003"};	///< Parameter kann nicht beschrieben werden
unsigned char code TEXT_E004[] =               {"E004"};	///< unbekanntes Kommando
unsigned char code TEXT_E005[] =               {"E005"};	///< Fehler in Befehlsausf�hrung
unsigned char code TEXT_E006[] =               {"E006"};	///< Kommando noch nicht implementiert
unsigned char code TEXT_E007[] =               {"E007"};	///< Parameter fehlt
unsigned char code TEXT_E008[] =               {"E008"};	///< Unerwartetes Zeichen im Kommandostring
unsigned char code TEXT_E009[] =               {"E009"};	///< Wert au�erhalb des Grenzwertes
unsigned char code TEXT_E010[] =               {"E010"};	///< Drifterkennung l�uft (nur SLC)
unsigned char code TEXT_E011[] =               {"E011"};	///< Parameter der Partner unterschiedlich
unsigned char code TEXT_E012[] =               {"E012"};	///< frei
/*~-1*/
#endif
/*~E:I6*/
/*~I:7*/
#ifdef CHANNEL_1
/*~T*/
unsigned char code TEXT_E001[] =               {"E001"};	///< angegebener Kanal ung�ltig
unsigned char code TEXT_E002[] =               {"E002"};	///< angegebener Parameter ung�ltig
unsigned char code TEXT_E003[] =               {"E003"};	///< Parameter kann nicht beschrieben werden
unsigned char code TEXT_E004[] =               {"E004"};	///< unbekanntes Kommando
unsigned char code TEXT_E005[] =               {"E005"};	///< Fehler in Befehlsausf�hrung
unsigned char code TEXT_E006[] =               {"E006"};	///< Kommando noch nicht implementiert
unsigned char code TEXT_E007[] =               {"E007"};	///< Parameter fehlt
unsigned char code TEXT_E008[] =               {"E008"};	///< Unerwartetes Zeichen im Kommandostring
unsigned char code TEXT_E009[] =               {"E009"};	///< Wert au�erhalb des Grenzwertes
unsigned char code TEXT_E010[] =               {"E010"};	///< Drifterkennung l�uft (nur SLC)
unsigned char code TEXT_E011[] =               {"E011"};	///< Parameter der Partner unterschiedlich
unsigned char code TEXT_E012[] =               {"E012"};	///< frei
/*~A:8*/
/*~+:alt*/
/*~I:9*/
#ifdef MOF
/*~T*/
unsigned char code TEXT_E101[] =               {"E101"};	///< angegebener Kanal ung�ltig
unsigned char code TEXT_E102[] =               {"E102"};	///< angegebener Parameter ung�ltig
unsigned char code TEXT_E103[] =               {"E103"};	///< Parameter kann nicht beschrieben werden
unsigned char code TEXT_E104[] =               {"E104"};	///< unbekanntes Kommando
unsigned char code TEXT_E105[] =               {"E105"};	///< Fehler in Befehlsausf�hrung
unsigned char code TEXT_E106[] =               {"E106"};	///< Kommando noch nicht implementiert
unsigned char code TEXT_E107[] =               {"E107"};	///< Parameter fehlt
unsigned char code TEXT_E108[] =               {"E108"};	///< Unerwartetes Zeichen im Kommandostring
unsigned char code TEXT_E109[] =               {"E109"};	///< Wert au�erhalb des Grenzwertes
unsigned char code TEXT_E110[] =               {"E110"};	///< Drifterkennung l�uft (nur SLC)
unsigned char code TEXT_E111[] =               {"E111"};	///< Parameter der Partner unterschiedlich
unsigned char code TEXT_E112[] =               {"E112"};	///< 
/*~-1*/
#endif
/*~E:I9*/
/*~E:A8*/
/*~-1*/
#endif
/*~E:I7*/
/*~E:A5*/
