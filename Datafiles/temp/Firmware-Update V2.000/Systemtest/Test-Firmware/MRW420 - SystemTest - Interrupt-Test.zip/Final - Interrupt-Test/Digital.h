/*~-1*/
/*~XSF_LANGUAGE: C/C++*/
/*~I:1*/
#ifndef __DIGITAL_H

/*~T*/
#define __DIGITAL_H

/*~A:2*/
/*~+:Includes*/
/*~T*/
#include "System.cnd"
/*~E:A2*/
/*~A:3*/
/*~+:Versions-Beschreibung*/
/*~A:4*/
/*~+:�bersicht*/
/*~T*/
/*!
\addtogroup overview
@cond FOR_APPLICATION_DOCS
@{
\section DescritionSec_Digital 'Digitale Ausg�nge'

<table border=1 width=100% height=1% rules=rows cellspacing=0 bgcolor="#E0E0F0">
<tr>
	<td>Digital.c</td>
	<td>Digital.h</td>
</tr>
</table>
@}
@endcond
*/
/*~E:A4*/
/*~A:5*/
/*~+:Version und Versionsdatum*/
/*~T*/
/*!
\addtogroup versions
@{
<tr>
	<td>Digital.h</td>
	<td>Michael Offenbach</td>
	<td>1.000</td>
	<td>24.07.2008</td>
	<td></td>
</tr>
@}
*/
/*~E:A5*/
/*~A:6*/
/*~+:Ressourcen*/
/*~T*/
/*!
\addtogroup ressources
@cond FOR_APPLICATION_DOCS
@{
<tr>
	<td>Digital.h</td>
	<td>--- <B>Bytes</B></td>
	<td>--- <B>Bytes</B></td>
	<td>--- <B>Bytes</B></td>
	<td>--- <B>Bytes</B></td>
</tr>
@}
@endcond
*/
/*~E:A6*/
/*~A:7*/
/*~+:Zykluszeiten*/
/*~T*/
/*!
\addtogroup cycletimes
@cond FOR_APPLICATION_DOCS
@{
<tr>
	<td>Digital.h</td>
	<td>--- <B>ms</B></td>
	<td>--- <B>ms</B></td>
</tr>
@}
@endcond
*/
/*~E:A7*/
/*~A:8*/
/*~+:Verschiedenes*/
/*~T*/
/*!
\addtogroup misc
@cond FOR_APPLICATION_DOCS
@{
<tr>
	<td>Digital.h</td>
	<td>---</td>
	<td>---</td>
</tr>
@}
@endcond
*/
/*~E:A8*/
/*~A:9*/
/*~+:Lifecycle*/
/*~T*/
/*!
\addtogroup lifecycle
@cond FOR_APPLICATION_DOCS
@{
<tr>
	<td>Digital.h</td>
	<td>1.000</td>
	<td>24.07.08</td>
	<td>Michael Offenbach</td>
	<td>Erste lauff�hige Version</td>
	<td>----</td>
</tr>
<tr>
	<td></td>
	<td>1.001</td>
	<td>06.10.08</td>
	<td>Michael Offenbach</td>
	<td>Einbau einer LED-Testroutine</td>
	<td>----</td>
</tr>
@}
@endcond
*/
/*~E:A9*/
/*~A:10*/
/*~+:�ffentliche Funktionen*/
/*~T*/
/*#LJ:1=187*/
/*!
\addtogroup public_functions
@cond FOR_APPLICATION_DOCS
@{

<tr bgcolor="#E0E0F0">
	<td><b>Digitale Ausg�nge</b></td>
</tr>
<tr bgcolor="#F0F0FF">
	<td>void Digital(void);</td>
</tr>
<tr bgcolor="#F0F0FF">
	<td>unsigned char Digital_GetLED(unsigned char chLed2Get);</td>
</tr>
<tr bgcolor="#F0F0FF">
	<td>void Digital_Init(void);</td>
</tr>
<tr bgcolor="#F0F0FF">
	<td>void Digital_SetLED(unsigned char chLed2Set,unsigned char chStatus);</td>
</tr>
@}
@endcond
*/
/*~E:A10*/
/*~A:11*/
/*~+:allgemeine Modul-Beschreibung*/
/*~T*/
/*!
@cond FOR_APPLICATION_DOCS
\page DescriptionPages
\section DescritionSec_Digital 'Digitale Ausg�nge'

In diesem Funktionsmodul werden die digitalen Ausg�nge zur Steuerung der Platinen-Leds gesteuert. Hierzu wird in Abh�ngigkeit des Systemstatus der Ausgang in verschieden Modi gesetzt : aus, blinkend, permanent an. 

<table border=1 width=100% height=1% rules=rows cellspacing=0 valign="TOP" bgcolor="#E0E0F0">
<tr>
	<td width=20%><b>Status</b></td>
	<td width=20%><b>Led 'gr�n'</b></td>
	<td width=20%><b>Led 'gelb'</b></td>
	<td width=20%><b>Led 'rot - innen'</b></td>
	<td width=20%><b>Led 'rot - au�en'</b></td>
</tr>

<tr bgcolor="#F0F0FF">
	<td bgcolor="#E0E0F0"><b>Normal</b></td>
	<td>blinkend</td>
	<td>Led an wenn Absolutgewicht kleiner 15kg</td>
	<td>aus</td>
	<td>aus</td>
</tr>

<tr bgcolor="#F0F0FF">
	<td bgcolor="#E0E0F0"><b>�berlast</b></td>
	<td>blinkend</td>
	<td>aus</td>
	<td>blinkend bei �berlast Kanal 0</td>
	<td>blinkend bei �berlast Kanal 0</td>
</tr>

<tr bgcolor="#F0F0FF">
	<td bgcolor="#E0E0F0"><b>Systemfehler</b></td>
	<td>blinkend</td>
	<td>Led an wenn Absolutgewicht kleiner 15kg</td>
	<td>Kanal 0: an</td>
	<td>Kanal 1: an</td>
</tr>

<tr bgcolor="#F0F0FF">
	<td bgcolor="#E0E0F0"><b>Aufnahme der Temperaturkennlinie gestartet</b></td>
	<td>Kanal 0: an</td>
	<td>Kanal 0: an</td>
	<td>Kanal 1: an</td>
	<td>Kanal 1: an</td>
</tr>

<tr bgcolor="#F0F0FF">
	<td bgcolor="#E0E0F0"><b>Temperaturkennlinienaufnahme: 1.Driftwert ermittelt</b></td>
	<td>Kanal 0: blinkend (1Hz)</td>
	<td>Kanal 0: invers blinkend (1Hz)</td>
	<td>Kanal 1: blinkend (1Hz)</td>
	<td>Kanal 1: invers blinkend (1Hz)</td>
</tr>

<tr bgcolor="#F0F0FF">
	<td bgcolor="#E0E0F0"><b>Temperaturkennlinienaufnahme: Fehler</b></td>
	<td>Kanal 0: aus</td>
	<td>Kanal 0: aus</td>
	<td>Kanal 1: aus</td>
	<td>Kanal 1: aus</td>
</tr>

<tr bgcolor="#F0F0FF">
	<td bgcolor="#E0E0F0"><b>Temperaturkennlinienaufnahme: Okay</b></td>
	<td>Kanal 0: blinkend (1Hz)</td>
	<td>Kanal 0: blinkend (1Hz)</td>
	<td>Kanal 1: blinkend (1Hz)</td>
	<td>Kanal 1: blinkend (1Hz)</td>
</tr>


</table>  

Dateien : Digital.c , Digital.h

@endcond
*/

/*~E:A11*/
/*~A:12*/
/*~+:Beispiel*/
/*~T*/
/*!
@cond FOR_APPLICATION_DOCS
\page ExamplePages
\section ExampleSec_Digital 'Digitalsignale'
\code


//Modulbeschreibung:
//Demo-Programm zur Demonstration der Einbindung der Befehle zur Ansteuerung der Digitalsignale.


//Includes

main()
{
	---	kein Beispiel verf�gbar !!! ---
}


\endcode
\endcond
*/

/*~E:A12*/
/*~E:A3*/
/*~A:13*/
/*~+:Definitionen*/
/*~T*/
// LED-Bezeichnungen

#define DIGITAL_LED_ST_OUT				0	///<
#define DIGITAL_LED_ST_IN				1	///<
#define DIGITAL_LED_P_OK				2	///<
#define DIGITAL_LED_ST_OUT_CH1			3	///<
/*~T*/
#define DIGITAL_LED_RUN					0x01	///< Gr�ne Programmlauf LED
#define DIGITAL_LED_ZEROCHECK			0x02	///< Gelbe Nullpunkt-LED
#define DIGITAL_LED_ERROR_CH0			0x04	///< Rote Error-/�berlast-LED CH0 (innen)
#define DIGITAL_LED_ERROR_CH1			0x08	///< Rote Error-/�berlast-LED CH1 (au�en)
/*~T*/
// IO-Status (ACHTUNG ! das oberste Bit dient als Initialisierungsanforderung, das Bit darunter als Invertierung im Toggle-Betrieb) 
#define DIGITAL_OFF						0	///< Das am digitaler IO angeschlossene Ger�t ausgeschalten 
#define DIGITAL_ON						1	///< Das am digitaler IO angeschlossene Ger�t eingeschalten
#define DIGITAL_TOGGLE_100				2	///< Ausgang schaltet alle 100ms in den anderen Zustand um.
#define DIGITAL_TOGGLE_300				3	///< Ausgang schaltet alle 300ms in den anderen Zustand um.
#define DIGITAL_TOGGLE_500				4	///< Ausgang schaltet alle 500ms in den anderen Zustand um.
#define DIGITAL_TOGGLE_1000				5	///< Ausgang schaltet alle 1000ms in den anderen Zustand um.
#define DIGITAL_TOGGLE_2000				6	///< Ausgang schaltet alle 2000ms in den anderen Zustand um.
#define DIGITAL_TOGGLE_10000			7	///< Ausgang schaltet alle 10000ms in den anderen Zustand um.
#define DIGITAL_TOGGLE_100_INV			66	///< Ausgang schaltet alle 100ms in den anderen Zustand um.
#define DIGITAL_TOGGLE_300_INV			67	///< Ausgang schaltet alle 300ms in den anderen Zustand um.
#define DIGITAL_TOGGLE_500_INV			68	///< Ausgang schaltet alle 500ms in den anderen Zustand um.
#define DIGITAL_TOGGLE_1000_INV			69	///< Ausgang schaltet alle 1000ms in den anderen Zustand um.
#define DIGITAL_TOGGLE_2000_INV			70	///< Ausgang schaltet alle 2000ms in den anderen Zustand um.
#define DIGITAL_TOGGLE_10000_INV		71	///< Ausgang schaltet alle 10000ms in den anderen Zustand um.
#define DIGITAL_FLASH_MODE_1			14	///< Ausgang schaltet nur kurzzeitig ein um dann wieder f�r eine l�ngere Zeit abgeschaltet zu bleiben.
/*~E:A13*/
/*~A:14*/
/*~+:Struktur-Definitionen*/
/*~T*/
typedef struct
{
	unsigned char bLEDTestMode;		///< LED-Test ein-/ausgeschaltet
	unsigned char byLEDTestMask;	///< Maske der zu setzenden LED-Ausg�nge
}DIGITAL;
/*~E:A14*/
/*~A:15*/
/*~+:Funktionsdeklarationen*/
/*~T*/
/*#LJ:0=8*/
extern void 			Digital(void);

/*~I:16*/
#ifdef CHANNEL_0
/*~T*/
extern void 			Digital_ClearLEDTestMode(void);
extern unsigned char 	Digital_GetLED(unsigned char chLed2Get);

/*~-1*/
#endif
/*~E:I16*/
/*~T*/
extern void 			Digital_Init(void);
/*~I:17*/
#ifdef MOF
/*~T*/
extern unsigned char 	Digital_GetLEDOnOffStatus(unsigned char chLed2Get);

/*~-1*/
#endif
/*~E:I17*/
/*~I:18*/
#ifdef CHANNEL_0
/*~T*/
extern void 			Digital_SetLED(unsigned char chLed2Set,unsigned char chStatus);

extern void 			Digital_SetLEDManually(unsigned char chLed2Set,unsigned char bOn);
/*~-1*/
#endif
/*~E:I18*/
/*~E:A15*/
/*~A:19*/
/*~+:Variablen*/
/*~T*/

/*~E:A19*/
/*~-1*/
#endif
/*~E:I1*/
