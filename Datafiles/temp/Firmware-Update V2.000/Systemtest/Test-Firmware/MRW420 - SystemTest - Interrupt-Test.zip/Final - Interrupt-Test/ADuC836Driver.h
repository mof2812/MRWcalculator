/*~-1*/
/*~XSF_LANGUAGE: C/C++*/
/*~K*/
/*~+:File :        ADuC836Driver.h*/
/*~+:*/
/*~+:Version :     V1.000*/
/*~+:*/
/*~+:Date :		  09.02.2022*/
/*~+:Time :        */
/*~+:*/
/*~+:Author :      MOF*/
/*~+:*/
/*~+:Hardware :*/
/*~+:*/
/*~+:Description :*/
/*~A:1*/
/*~+:Versions-Beschreibung*/
/*~A:2*/
/*~+:Version und Versionsdatum*/
/*~T*/
/*!
\mainpage "Modul-Beschreibung"
\author Michael Offenbach
\date 16.11.2016
\version V1.003
\warning
*/
/*~E:A2*/
/*~A:3*/
/*~+:Ziel-Hardware*/
/*~T*/
/*!\page HardwarePage Ziel-Hardware

\section sec_HardwarePage_ADuC836Driver 'ADuC836-Treiber'

<table border=1 width=100% height=1% rules=rows cellspacing=0 bgcolor="#E0E0F0">

<tr align=left valign=top>
	<th>Motherboard</th>
	<th>Prozessor</th>
	<th>ROM</th>
	<th>RAM</th>
</tr>

<tr>
	<td>MRW420 </td>
	<td>8051-Core</td>
	<td>62 <B>kByte</B></td>
	<td>2 <B>kByte</B></td>
</tr></table>

*/
/*~E:A3*/
/*~A:4*/
/*~+:Compiler-Einstellungen*/
/*~T*/
/*!\page CompilerPage Compiler-Einstellungen

\section sec_CompilerPage_ADuC836Driver 'ADuC836-Treiber'

<table border=1 width=100% height=1% rules=rows cellspacing=0 bgcolor="#E0E0F0">

<tr align=left valign=top>
	<th>Compiler</th>
	<th>Betriebssystem</th>
	<th>Speichermodell</th>
	<th>Code-Speicher-Gr��e</th>
	<th>Optimierungen</th>
	<th>Sonstiges</th>
</tr>

<tr>
	<td>Keil uVision2 V2.40<BR>C51 V7.08<BR>A51 V7.08a</td>
	<td>Kein Betriebssystem</td>
	<td>Large: variables in XDATA</td>
	<td>Large: 64k program</td>
	<td>
	[ ] 0 Constant Folding<BR>
	[ ] 1 Dead Code Elimination<BR>
	[ ] 2 Data Overlaying<BR>
	[ ] 3 Peephole Optimization<BR>
	[ ] 4 Register Variables<BR>
	[ ] 5 Common Subexpression Elimination<BR>
	[X] 6 Loop Rotation<BR>
	[ ] 7 Extended Index Access Optimizing<BR>
	[ ] 8 Reuse Common Entry Code<BR>
	[ ] 9 Common Block Subroutines<BR>
	<BR>
	[X]Favor size<BR>
	[ ]Favor speed</td>
	<td>---</td>
</tr></table>

*/
/*~E:A4*/
/*~A:5*/
/*~+:Ressourcen*/
/*~T*/
/*!\page RessourcePage Ressourcen

\section sec_RessourcePage_ADuC836Driver 'ADuC836-Treiber'

<table border=1 width=100% height=1% rules=rows cellspacing=0 bgcolor="#E0E0F0">

<tr align=left valign=top>
	<th>CODE</th>
	<th>IDATA</th>
	<th>XDATA</th>
	<th>Dynamische Variablen</th>
</tr>

<tr>
	<td>--- <B>Bytes</B></td>
	<td>--- <B>Bytes</B></td>
	<td>--- <B>Bytes</B></td>
	<td>(2*(Anzahl der Sequenzeintr�ge+1)+46) * Anzahl der Messwertkan�le <B>Bytes</B></td>
</tr></table>

*/
/*~E:A5*/
/*~A:6*/
/*~+:Zykluszeiten*/
/*~T*/
/*!\page CycletimePage Zykluszeiten

\section sec_CycletimePage_ADuC836Driver 'ADuC836-Treiber'

<table border=1 width=100% height=1% rules=rows cellspacing=0 bgcolor="#E0E0F0">

<tr align=left valign=top>
	<th>Minimale Durchlaufzeit</th>
	<th>Maximale Durchlaufzeit</th>
</tr>

<tr>
	<td>--- <B>ms</B></td>
	<td>--- <B>ms</B></td>
</tr></table>

*/
/*~E:A6*/
/*~A:7*/
/*~+:Verschiedenes*/
/*~T*/
/*!\page MiscPage Verschiedenes

\section sec_MiscPage_ADuC836Driver 'ADuC836-Treiber'

<table border=1 width=100% height=1% rules=rows cellspacing=0 bgcolor="#E0E0F0">

<tr align=left valign=top>
	<th>Benutzte Interrups</th>
	<th>Benutzte Registerb�nke</th>
</tr>

<tr>
	<td>---</td>
	<td>---</td>
</tr></table>

*/
/*~E:A7*/
/*~A:8*/
/*~+:Lifecycle*/
/*~T*/
/*!\page LifeCyclePage Lifecycle

\section sec_LifeCyclePage_ADuC836Driver 'ADuC836-Treiber'

<table border=1 width=100% height=1% rules=rows cellspacing=0 bgcolor="#E0E0F0">

<tr align=left valign=top>
	<th>Version</th>
	<th>Datum</th>
	<th>Programmierer</th>
	<th>�nderungen</th>
</tr>

<tr>
	<td>1.000</td>
	<td>14.06.05</td>
	<td>Michael Offenbach</td>
	<td>Erste lauff�hige Version</td>
</tr>

<tr>
	<td>1.001</td>
	<td>28.06.05</td>
	<td>Michael Offenbach</td>
	<td>- Die Ausgangsgr��e des DAC's kann nun direkt gesetzt werden.</td>
</tr>

<tr>
	<td>1.002</td>
	<td>14.10.16</td>
	<td>Michael Offenbach</td>
	<td>- Komplett�berarbeitung der ADuc(36-Bibliothek wg. Probleme in der SPI-Kommunikation.</td>
</tr>

<tr>
	<td>1.003</td>
	<td>16.11.16</td>
	<td>Michael Offenbach</td>
	<td>- Per Define (ADuC836_FAST_ADC) kann die Wandlerrate von 5.35Hz auf 19.79 Hz erh�ht werden.</td>
</tr>
</table>

*/
/*~E:A8*/
/*~A:9*/
/*~+:Beispiel*/
/*~T*/
/*!\page ExamplePage_ADuC836Driver Beispiel 'ADuC836-Treiber'
\code


//Modulbeschreibung:
//Demo-Programm zur Demonstration der Einbindung der ADuC836-Treiber-Befehle 


// Includes
#include "ADuC836.h"
#include "ADuC836Driver.h"
#include "Flash.h"
#include <String.h>

// Direktive f�r ADuC836
#pragma NOAREGS

// Funktionsdeklarationen

main()
{
   // Timing

   unsigned long ulDestinationTime;
   // Flash-Routinen
   char szText[32];

   // ADC-Routinen
   long lADC_Resultat_0;	// Ergebnis der AD-Wandlung des Hauptkanals
   long lADC_Resultat_1;	// Ergebnis der AD-Wandlung des Hilfskanals

   // DAC-Routinen
   unsigned int uDigital;

   // SPI-Routinen
   unsigned char chReturn;
   unsigned char chData;

   // Systemvariablen ADuC836 setzen
   CFG836 |= 1;
   PLLCON &= 0xF8;
   T0 = 0;
   ulDestinationTime = Timer.ulOperatingTime + 250;
   strcpy(szText,"Hallo");

   chData = 0x30;
   // *************************************************************************************** //
   // * Demonstartion der ADC-Routinen														* //
   // *************************************************************************************** //


   // ADC mit Defaultwerten initialsieren
   ADuC836_ADCDefaultIni();
   // Messwerttiefe vorgeben.
   ADuC836_ADCSetMeasurementDepth(ADuC836_ADC_PRIMARY,2);
   // Messwertoffset vorgeben
   ADuC836_ADCSetZeroOffset(ADuC836_ADC_PRIMARY,0x8000);
   // Filterfrequenz einstellen
   ADuC836_ADCSetSincFilter(1,ADuC836_ADC_FREQUENCY_32KHZ);

   // *************************************************************************************** //
   // * Demonstartion der DAC-Routinen														* //
   // *************************************************************************************** //


   // DAC initialsieren
   ADuC836_DACIni(ADUC836_DAC_OUTPUTPIN_3,ADUC836_DAC_RESOLUTION_12BIT,ADUC836_DAC_RANGE_2_REF,ADUC836_DAC_ENABLE);
   // Offset vorgeben
   ADuC836_DACSetOffset(0,ADUC836_DAC_RMV,256);

   // Verst�rkung vorgeben
   ADuC836_DACSetGain(0.75);

   // Unteres Limit setzen
   ADuC836_DACSetLimit(ADUC836_DAC_LOWER_LIMIT,50,ADUC836_DAC_KEEP_OUTPUT);
   // Oberes Limit setzen
   ADuC836_DACSetLimit(ADUC836_DAC_UPPER_LIMIT,4050,ADUC836_DAC_SET2ZERO);



   // DAC auf ersten Kalibrierpunkt fahren
   // ADuC836_DACConvert(0);
   ADuC836_DACConvert(100);
   // und diesem Punkt den Ist- und Sollwert zuweisen
   // ADuC836_DACCalibrationSetPoint(0,1.140,2.5);
   ADuC836_DACCalibrationSetPoint(0,1.505,2.5);

   // DAC auf zweiten Kalibrierpunkt fahren
   // ADuC836_DACConvert(4095);
   ADuC836_DACConvert(4000);
   // und diesem Punkt den Ist- und Sollwert zuweisen
   // ADuC836_DACCalibrationSetPoint(1,18.874,23);
   ADuC836_DACCalibrationSetPoint(1,17.795,23);

   // Kalibrierfaktor berechnen
   ADuC836_DACCalcCalibration();
   // Kalibrierung �berpr�fen

   // 1.Punkt -> 2.5mA
   ADuC836_DACConvert(100);

   // 2.Punkt -> 23mA
   ADuC836_DACConvert(4000);

   // Unteren Grenzwert unterschreiten
   ADuC836_DACConvert(51);
   ADuC836_DACConvert(0);

   // Oberen Grenzwert �berschreiten
   ADuC836_DACConvert(4049);
   ADuC836_DACConvert(4095);

   // Stromwert in Digitalwert wandeln 
   uDigital = ADuC836_DACGetDigital(2.5);

   uDigital = ADuC836_DACGetDigital(23);
   // *************************************************************************************** //
   // * Demonstartion der Flash-Routinen													* //
   // *************************************************************************************** //


   ADuC836_FlashDataWritePtr(szText,0,sizeof(szText));

   memset(szText,0,sizeof(szText));

   ADuC836_FlashDataReadPtr(szText,0,5);
   // *************************************************************************************** //
   // * Demonstartion der SPI-Routinen														* //
   // *************************************************************************************** //

#ifdef SPI_MASTER
   ADuC836_SPIDefaultIni(1); 	// Master-Mode
#endif
#ifdef SPI_SLAVE
   // Der Slave-Kanal darf erst nach dem Master-Kanal initialisieren. Aus diesem Grund wird hier gewartet, bis der Master den Port SPICONTROL (/SS) nach LOW zieht. 
   while (SPICONTROL)
   {

   }
   ADuC836_SPIDefaultIni(0);	// Slave-Mode
#endif
   while (1)
   {
   	  // ************************************************************************************ //
      // * Demonstartion der ADC-Routinen													* //
   	  // ************************************************************************************ //

      lADC_Resultat_0 = ADuC836_ADCGetConversionValue(ADuC836_ADC_PRIMARY,0);
      lADC_Resultat_1 = ADuC836_ADCGetConversionValue(ADuC836_ADC_AUXILIARY,0);
   	  // ************************************************************************************ //
      // * Demonstartion der SPI-Routinen													* //
   	  // ************************************************************************************ //


      if (ulDestinationTime <= Timer.ulOperatingTime)
      {
         ulDestinationTime = Timer.ulOperatingTime + 250;
#ifdef SPI_MASTER
         // Kanal 0 (SPI-Master) liest 4mal pro Sekunde einen String vom Slave aus.
         chReturn =  ADuC836_SPIReadPtr(szText,0);
#endif
      }
#ifdef SPI_SLAVE
      // Kanal 1 (SPI-Slave) stellt einen String zum Auslesen bereit und wartet auf dessen Abschlu�.
      chReturn = ADuC836_SPISendPtr(szText,0);
#endif
   }
}

\endcode
*/
/*~E:A9*/
/*~I:10*/
#ifdef MOF
/*~A:11*/
/*~+:Beschreibungen extern definierter Funktionen*/
/*~T*/
/*!\page ExternalFunctionsPage Extern zu definierende Funktionen

\section sec_ExternalFunctionsPage_ADuC836Driver 'ADuC836-Treiber'

char Filter_Interface(MEASUREMENT_FILTERPARAMETERS *pFilterParameters)<br>
char Correction_Interface(MEASUREMENT_CORRECTIONPARAMETERS *pCorrectionParameters)

*/ 
/*~E:A11*/
/*~-1*/
#endif
/*~E:I10*/
/*~E:A1*/
/*~I:12*/
#ifndef __ADUC836DRIVER_H 
/*~T*/
#define __ADUC836DRIVER_H
/*~A:13*/
/*~+:Konfiguration*/
/*~A:14*/
/*~+:ADC*/
/*~T*/
// ADC
//#define ADuC836_FAST_ADC			// AD-Wandlung mit 19.79Hz
#undef ADuC836_FAST_ADC			// AD-Wandlung mit 19.79Hz
/*~E:A14*/
/*~A:15*/
/*~+:Portbits*/
/*~T*/
// Portbits
sbit P00 = 0x80;
sbit P01 = 0x81;
sbit P02 = 0x82;
sbit P03 = 0x83;
sbit P04 = 0x84;
sbit P05 = 0x85;
sbit P06 = 0x86;
sbit P07 = 0x87;

sbit P10 = 0x90;
sbit P11 = 0x91;
sbit P12 = 0x92;
sbit P13 = 0x93;
sbit P14 = 0x94;
sbit P15 = 0x95;
sbit P16 = 0x96;
sbit P17 = 0x97;

sbit P20 = 0xA0;
sbit P21 = 0xA1;
sbit P22 = 0xA2;
sbit P23 = 0xA3;
sbit P24 = 0xA4;
sbit P25 = 0xA5;
sbit P26 = 0xA6;
sbit P27 = 0xA7;

sbit P30 = 0xB0;
sbit P31 = 0xB1;
sbit P32 = 0xB2;
sbit P33 = 0xB3;
sbit P34 = 0xB4;
sbit P35 = 0xB5;
sbit P36 = 0xB6;
sbit P37 = 0xB7; 
/*~E:A15*/
/*~A:16*/
/*~+:Flash*/
/*~T*/
#define MAX_FLASH_PAGE 1023

// Definitionen zum Ablauf
#define FLASH_COMMAND_READ_PAGE      		1
#define FLASH_COMMAND_WRITE_PAGE      		2
#define FLASH_COMMAND_VERIFY_PAGE     		4
#define FLASH_COMMAND_ERASE_PAGE      		5
#define FLASH_COMMAND_ERASE_ALL_PAGES 		6

/*~E:A16*/
/*~A:17*/
/*~+:Timer*/
/*~T*/
#define TIMER_NB_TIMERS			6			///< Anzahl der zu initialisierenden Timer
/*~T*/
#define TIMER_TIMEBASE_10MS
// #define TIMER_TIMEBASE_1MS
/*~E:A17*/
/*~A:18*/
/*~+:RS232*/
/*~T*/
#define RS232_WITH_STATISTICS
//#undef RS232_WITH_STATISTICS
/*~E:A18*/
/*~A:19*/
/*~+:SPI*/
/*~T*/

/*~E:A19*/
/*~E:A13*/
/*~A:20*/
/*~+:Includes*/
/*~T*/
#include "ADuC836.h"

/*~E:A20*/
/*~A:21*/
/*~+:Definitionen*/
/*~A:22*/
/*~+:ADC*/
/*~A:23*/
/*~+:ADC-Frequenz*/
/*~T*/
#define ADuC836_ADC_FREQUENCY_32KHZ		32768
/*~E:A23*/
/*~T*/
#define ADuC836_ADC_PRIMARY				0		///< Haupt-ADC
#define ADuC836_ADC_AUXILIARY			1		///< Hilfs-ADC
#define ADuC836_ADC_PRIMARY_TOGGLE		2		///< 2.Haupt-ADC (Toggle)
#define ADuC836_ADC_AUXILIARY_TOGGLE	3		///< 2.Hilfs-ADC(Toggle)
/*~A:24*/
/*~+:Hauptkanal-Konfiguration*/
/*~T*/
// Eingangsspannungsbereiche
#define ADuC836_ADC_RANGE_20MV		0x00	///< Eingangsspannungsbereich +/-20mV.
#define ADuC836_ADC_RANGE_40MV		0x01	///< Eingangsspannungsbereich +/-40mV.
#define ADuC836_ADC_RANGE_80MV		0x02	///< Eingangsspannungsbereich +/-80mV.
#define ADuC836_ADC_RANGE_160MV		0x03	///< Eingangsspannungsbereich +/-160mV.
#define ADuC836_ADC_RANGE_320MV		0x04	///< Eingangsspannungsbereich +/-320mV.
#define ADuC836_ADC_RANGE_640MV		0x05	///< Eingangsspannungsbereich +/-640mV.
#define ADuC836_ADC_RANGE_1280MV	0x06	///< Eingangsspannungsbereich +/-1,28V.
#define ADuC836_ADC_RANGE_2560MV	0x07	///< Eingangsspannungsbereich +/-2,56V.

/*~T*/
// Uni-/Bipolar-Modus
#define ADuC836_ADC_UNIPOLAR		0x08	///< Unipolare Betriebsart. D.h. ein kurgeschlossener Eingang entspricht 0x000000h.
#define ADuC836_ADC_BIPOLAR			0x00	///< Bipolare Betriebsart. D.h. ein kurgeschlossener Eingang entspricht 0x800000h.
/*~T*/
// Eingangspins des Differenzeingangs
#define ADuC836_ADC_INPUT_AIN1_AIN2	0x00	///< AIN1 und AIN2 bilden den Differenzeingang.
#define ADuC836_ADC_INPUT_AIN3_AIN4	0x10	///< AIN3 und AIN4 bilden den Differenzeingang.
#define ADuC836_ADC_INPUT_AIN2_AIN2	0x20	///< AIN2 und AIN2 bilden den Differenzeingang (=> interner Kurzschluss.
#define ADuC836_ADC_INPUT_AIN3_AIN2	0x30	///< AIN3 und AIN2 bilden den Differenzeingang.	
/*~T*/
// Referenzquelle
#define ADuC836_ADC_INTERNAL_REFERENCE	0x00	///< interne Referenzquelle w�hlen.
#define ADuC836_ADC_EXTERNAL_REFERENCE	0x40	///< externe Referenzquelle zwischen REFIN(+) und REFIN(-) w�hlen. 	 
/*~E:A24*/
/*~A:25*/
/*~+:Hilfskanal-Konfiguration*/
/*~T*/
// Uni-/Bipolar-Modus	s. Hauptkanal-Konfiguration
/*~T*/
// Eingangspins des ADC-Eingangs
#define ADuC836_ADC_INPUT_AIN3		0x00	///< AIN3 und AGND bilden den ADC-Eingang.
#define ADuC836_ADC_INPUT_AIN4		0x10	///< AIN4 und AGND bilden den ADC-Eingang.
#define ADuC836_ADC_INPUT_TEMP		0x20	///< Der interne Temperatursensor bildet die Eingangsquelle.
#define ADuC836_ADC_INPUT_AIN5		0x30	///< AIN5 und AGND bilden den ADC-Eingang.	
/*~T*/
// Referenzquelle	s. Hauptkanal-Konfiguration

/*~E:A25*/
/*~A:26*/
/*~+:Modi setzen*/
/*~T*/
// Betriebsmodi
#define ADuC836_ADC_POWER_DOWN				0x00	///< ADC im Power-Down-Modus.
#define ADuC836_ADC_IDLE_MODE				0x01 	///< ADC im Idle-Modus.
#define ADuC836_ADC_SINGLE_CONVERTION		0x02	///< ADC f�hrt eine einzelne Wandlung durch.
#define ADuC836_ADC_CONT_CONVERSION			0x03	///< ADC wandelt kontinuierlich den Eingangswert.
#define ADuC836_ADC_INT_ZERO_CALIBRATION	0x04	///< Interne Nullpunkt-Kalibrierung durchf�hren.
#define ADuC836_ADC_INT_SCALE_CALIBRATION	0x05	///< Interne Messbereichskalibrierung.
#define ADuC836_ADC_SYS_ZERO_CALIBRATION	0x06	///< System-Nullpunkt-Kalibrierung durchf�hren.
#define ADuC836_ADC_SYS_SCALE_CALIBRATION	0x07	///< System-Messbereichskalibrierung.
/*~T*/
// Freigabe des Hilfs-ADC's
#define ADuC836_ADC_ENABLE_AUXILIARY		0x10	///< Hilfs-ADC freigeben.

// Freigabe des Haupt-ADC's
#define ADuC836_ADC_ENABLE_PRIMARY			0x20	///< Haupt-ADC freigeben.

/*~E:A26*/
/*~A:27*/
/*~+:Default-Settings*/
/*~I:28*/
#ifndef ADuC836_FAST_ADC 
/*~T*/
// Default-Ini-Settings

///< Defaultparameter f�r den Hauptkanal
#define ADuC836_ADC_DEFAULT_PRIMARY_SETTING				ADuC836_ADC_PRIMARY,ADuC836_ADC_CONT_CONVERSION|ADuC836_ADC_ENABLE_PRIMARY,ADuC836_ADC_RANGE_20MV|ADuC836_ADC_BIPOLAR|ADuC836_ADC_INPUT_AIN1_AIN2|ADuC836_ADC_EXTERNAL_REFERENCE,5.35,ADuC836_ADC_FREQUENCY_32KHZ	

#define ADuC836_ADC_DEFAULT_PRIMARY_TOGGLE_SETTING		ADuC836_ADC_PRIMARY_TOGGLE,ADuC836_ADC_CONT_CONVERSION|ADuC836_ADC_ENABLE_PRIMARY,ADuC836_ADC_RANGE_20MV|ADuC836_ADC_BIPOLAR|ADuC836_ADC_INPUT_AIN1_AIN2|ADuC836_ADC_EXTERNAL_REFERENCE,5.35,ADuC836_ADC_FREQUENCY_32KHZ
/*~T*/
///< Defaultparameter f�r den Hilfskanal
#define ADuC836_ADC_DEFAULT_AUXILIARY_SETTING			ADuC836_ADC_AUXILIARY,ADuC836_ADC_CONT_CONVERSION|ADuC836_ADC_ENABLE_AUXILIARY,ADuC836_ADC_INPUT_TEMP|ADuC836_ADC_BIPOLAR|ADuC836_ADC_INTERNAL_REFERENCE,5.35,ADuC836_ADC_FREQUENCY_32KHZ	

#define ADuC836_ADC_DEFAULT_AUXILIARY_TOGGLE_SETTING	ADuC836_ADC_AUXILIARY_TOGGLE,ADuC836_ADC_CONT_CONVERSION|ADuC836_ADC_ENABLE_AUXILIARY,ADuC836_ADC_INPUT_AIN3|ADuC836_ADC_BIPOLAR|ADuC836_ADC_EXTERNAL_REFERENCE,5.35,ADuC836_ADC_FREQUENCY_32KHZ
/*~O:I28*/
/*~-1*/
#else
/*~T*/
// Default-Ini-Settings

///< Defaultparameter f�r den Hauptkanal
#define ADuC836_ADC_DEFAULT_PRIMARY_SETTING				ADuC836_ADC_PRIMARY,ADuC836_ADC_CONT_CONVERSION|ADuC836_ADC_ENABLE_PRIMARY,ADuC836_ADC_RANGE_20MV|ADuC836_ADC_BIPOLAR|ADuC836_ADC_INPUT_AIN1_AIN2|ADuC836_ADC_EXTERNAL_REFERENCE,19.79,ADuC836_ADC_FREQUENCY_32KHZ	

#define ADuC836_ADC_DEFAULT_PRIMARY_TOGGLE_SETTING		ADuC836_ADC_PRIMARY_TOGGLE,ADuC836_ADC_CONT_CONVERSION|ADuC836_ADC_ENABLE_PRIMARY,ADuC836_ADC_RANGE_20MV|ADuC836_ADC_BIPOLAR|ADuC836_ADC_INPUT_AIN1_AIN2|ADuC836_ADC_EXTERNAL_REFERENCE,19.79,ADuC836_ADC_FREQUENCY_32KHZ
/*~T*/
///< Defaultparameter f�r den Hilfskanal
#define ADuC836_ADC_DEFAULT_AUXILIARY_SETTING			ADuC836_ADC_AUXILIARY,ADuC836_ADC_CONT_CONVERSION|ADuC836_ADC_ENABLE_AUXILIARY,ADuC836_ADC_INPUT_TEMP|ADuC836_ADC_BIPOLAR|ADuC836_ADC_INTERNAL_REFERENCE,19.79,ADuC836_ADC_FREQUENCY_32KHZ	

#define ADuC836_ADC_DEFAULT_AUXILIARY_TOGGLE_SETTING	ADuC836_ADC_AUXILIARY_TOGGLE,ADuC836_ADC_CONT_CONVERSION|ADuC836_ADC_ENABLE_AUXILIARY,ADuC836_ADC_INPUT_AIN3|ADuC836_ADC_BIPOLAR|ADuC836_ADC_EXTERNAL_REFERENCE,19.79,ADuC836_ADC_FREQUENCY_32KHZ
/*~-1*/
#endif
/*~E:I28*/
/*~E:A27*/
/*~A:29*/
/*~+:Kalibrierung*/
/*~T*/
#define ADuC836_ADC_INTERNALZEROSCALE_CALIBRATION			1	///< interne Nullpunktkalibrierung
#define ADuC836_ADC_INTERNALFULLSCALE_CALIBRATION			2	///< interne Verst�rkungskalibrierung
#define ADuC836_ADC_SYSTEMZEROSCALE_CALIBRATION				3	///< externe Nullpunktkalibrierung
#define ADuC836_ADC_SYSTEMFULLSCALE_CALIBRATION				4	///< externe Verst�rkungskalibrierung
/*~E:A29*/
/*~E:A22*/
/*~A:30*/
/*~+:DAC*/
/*~T*/
#define ADUC836_DAC_REGREAD				2		///< Lesen der DAC-Register
/*~T*/
#define ADUC836_DAC_NORM_OP				0		///< Normale DAC-Betriebsart
#define ADUC836_DAC_CLEAR_DAC			1		///< DAC powered-down

/*~T*/
#define ADUC836_DAC_DISABLE				0		///< DAC gesperrt
#define ADUC836_DAC_ENABLE				1		///< DAC freigegeben
/*~T*/
#define ADUC836_DAC_RANGE_2_REF			0		///< DAC-Bereich von 0 bis 2.5V (Vref)
#define ADUC836_DAC_RANGE_2_VDD			1		///< DAC-Bereich von 0 bis Vanalog
/*~T*/
#define ADUC836_DAC_RESOLUTION_12BIT	0		///< DAC-Aufl�sung 12 Bit
#define ADUC836_DAC_RESOLUTION_8BIT		1		///< DAC-Aufl�sung 8 Bit
/*~T*/
#define ADUC836_DAC_OUTPUTPIN_3			0 		///< DAC-Ausgang an Pin 3
#define ADUC836_DAC_OUTPUTPIN_12		1		///< DAC-Ausgang an Pin 12
/*~T*/
#define ADUC836_DAC_RMV					0
#define ADUC836_DAC_NORM				1
#define ADUC836_DAC						2
/*~K*/
/*~+:*/
/*~T*/
// Grenzwertbetrachtung

#define ADUC836_DAC_LOWER_LIMIT			0		///< Unterer Grenzwert
#define ADUC836_DAC_UPPER_LIMIT			1		///< Oberer Grenzwert

// Verhalten bei Grenzwert�berschreitungen
#define ADUC836_DAC_KEEP_OUTPUT			0		///< bei einer Grenzwert�berschreitung soll der DAC-Ausgang auf dem Ausgangswert des Grenzwertes eingestellt werden.

#define ADUC836_DAC_IGNORE				1		///< bei einer Grenzwert�berschreitung soll der DAC-Ausgang auf dem letzten Ausgangswert verharren.

#define ADUC836_DAC_SET2ZERO			2		///< bei einer Grenzwert�berschreitung soll der DAC-Ausgang auf 0 Digit eingestellt werden

#define ADUC836_DAC_SET2MAXIMUM			3		///< bei einer Grenzwert�berschreitung soll der DAC-Ausgang auf Maximum eingestellt werden
/*~E:A30*/
/*~A:31*/
/*~+:External*/
/*~T*/
#define EXTERNAL_INTERRUPT_0					0x00	///< Externer Interrupt 0 
#define EXTERNAL_INTERRUPT_1					0x01	///< Externer Interrupt 1 
/*~T*/
#define EXTERNAL_LEVEL_CONTROLLED				0x00	///< Interrupt ist pegelgesteuert
#define EXTERNAL_EDGE_CONTROLLED				0x01	///< Interrupt ist flankengesteuert
#define EXTERNAL_LOW_PRIORITY					0x00	///< niedrige Interrupt-Priorit�t 
#define EXTERNAL_HIGH_PRIORITY					0x02	///< hohe Interrupt-Priorit�t

/*~E:A31*/
/*~A:32*/
/*~+:Flash*/
/*~T*/

/*~E:A32*/
/*~A:33*/
/*~+:SPI*/
/*~T*/
// #define ADUC836_SPI_HANDSHAKE_LINE	P37	///< Handshake-Leitung der SPI-Kommunikation
/*~T*/
// Master oder Slave-Betriebsmode
#define ADUC836_SPI_MASTER_MODE				0x10		///< SFR SPICON.SPIM = 1
#define ADUC836_SPI_SLAVE_MODE				0x00		///< SFR SPICON.SPIM = 0

// Aktive Clock-Flanke
#define ADUC836_SPI_CLOCKPOLARITY_HIGH		0x08		///< SFR SPICON.CPOL = 1
#define ADUC836_SPI_CLOCKPOLARITY_LOW		0x00		///< SFR SPICON.CPOL = 0

// Ort der 'Clockphase'
#define ADUC836_SPI_CLOCKPHASE_LEADING		0x04		///< SFR SPICON.CPHA = 1
#define ADUC836_SPI_CLOCKPHASE_TRAILING		0x00		///< SFR SPICON.CPHA = 0

// Bit-�bertragungsrate
#define ADUC836_SPI_BITRATE_FCORE_16		0x03		///< SFR SPICON.SPR0 = 1 , SPICON.SPR1 = 1
#define ADUC836_SPI_BITRATE_FCORE_8			0x02		///< SFR SPICON.SPIM = 0 , SPICON.SPR1 = 1
#define ADUC836_SPI_BITRATE_FCORE_4			0x01		///< SFR SPICON.SPIM = 1 , SPICON.SPR1 = 0
#define ADUC836_SPI_BITRATE_FCORE_2			0x00		///< SFR SPICON.SPIM = 0 , SPICON.SPR1 = 0
/*~T*/
// Sonstige Einstellungen

// SPI-Freigabe
#define ADUC836_SPI_DISABLE					0x00		///< SPI-Schnittstelle gesperrt
#define ADUC836_SPI_ENABLE					0x01		///< SPI-Schnittstelle freigegeben

// Interrupt-Priorit�t
#define ADUC836_SPI_LOW_INTERRUPT_PRIORITY	0x00		///< Niedrige Interrupt-Priorit�t
#define ADUC836_SPI_HIGH_INTERRUPT_PRIORITY	0x01		///< Hohe Interrupt-Priorit�t
/*~E:A33*/
/*~A:34*/
/*~+:Versionsabfragen*/
/*~T*/
#define ADUC836_PROJECT_VERSION					0
#define ADUC836_ADC_VERSION						1
#define ADUC836_DAC_VERSION						2
#define ADUC836_EXTERNAL_VERSION				3
#define ADUC836_FLASH_VERSION					4
#define ADUC836_RS232_VERSION					5
#define ADUC836_SPI_VERSION						6
#define ADUC836_TIMER_VERSION					7
#define ADUC836_WATCHDOG_VERSION				8
/*~E:A34*/
/*~A:35*/
/*~+:Watchdog*/
/*~T*/
#define ADuC836_WATCHDOG_ENABLE								0x02	///< Watchdog freischalten
#define ADuC836_WATCHDOG_DISABLE							0x00	///< Watchdog sperren

#define ADuC836_WATCHDOG_ENABLE_INTERRUPT					0x08	///< Watchdog-Interrupt freischalten
#define ADuC836_WATCHDOG_DISABLE_INTERRUPT					0x00	///< Watchdog-Interrupt sperren
#define ADuC836_WATCHDOG_IMMEDIATE_RESET					0x80	///< Sofortiger Reset
#define ADuC836_WATCHDOG_2000MS_RESET						0x70	///< Watchdog-Timeout nach 2000ms
#define ADuC836_WATCHDOG_1000MS_RESET						0x60	///< Watchdog-Timeout nach 1000ms
#define ADuC836_WATCHDOG_500MS_RESET						0x50	///< Watchdog-Timeout nach 500ms
#define ADuC836_WATCHDOG_250MS_RESET						0x40	///< Watchdog-Timeout nach 250ms
#define ADuC836_WATCHDOG_125MS_RESET						0x30	///< Watchdog-Timeout nach 125ms
#define ADuC836_WATCHDOG_62_5MS_RESET						0x20	///< Watchdog-Timeout nach 62.5ms
#define ADuC836_WATCHDOG_31_2MS_RESET						0x10	///< Watchdog-Timeout nach 31.2ms
#define ADuC836_WATCHDOG_15_6MS_RESET						0x00	///< Watchdog-Timeout nach 15.6ms

#define ADuC836_WATCHDOG_DEFAULT_SETTING			ADuC836_WATCHDOG_ENABLE | ADuC836_WATCHDOG_ENABLE_INTERRUPT | ADuC836_WATCHDOG_2000MS_RESET		 	

/*~T*/
// Aktionen der externen Watchdog-Interface-Funktion
#define ADuC836_WATCHDOG_WRITEADDRESS						0		///< Adresse an der der Watchdog ausgel�st wurde abspeichern
#define ADuC836_WATCHDOG_READADDRESS						1		///< Adresse an der der Watchdog ausgel�st wurde auslesen
#define ADuC836_WATCHDOG_CLEARADDRESS						2		///< Adresse an der der Watchdog ausgel�st wurde l�schen
/*~E:A35*/
/*~E:A21*/
/*~A:36*/
/*~+:Strukturdefinitionen*/
/*~A:37*/
/*~+:DAC*/
/*~T*/
typedef struct{
	long			lLowerLimit;					///< unterer Grenzwert
	long			lUpperLimit;					///< oberer Grenzwert
	unsigned char	byLowerLimitBehavior;			///< Verhalten im unteren Grenzwert
	unsigned char	byUpperLimitBehavior;			///< Verhalten im oberen Grenzwert
	unsigned int 	uHysteresisLowerLimit;			///< Zeithysteres unterer Grenzwert
	unsigned int 	uHysteresisUpperLimit;			///< Zeithysteres oberer Grenzwert
	unsigned char	byLimitSet;						///< Flags f�r gesetzte Grenzwerte

	unsigned char	byLimitState;					///< Grenzwert-Status
	unsigned int 	uLimitHysteresisCounter;		///< Z�hler f�r Zeithysterese 	
}DAC_LIMITS;
/*~T*/
typedef struct{
	unsigned char 	byPointsSet;					///< Kenn-Nummer des Referenzpunktes
	float 			fTrueValue;						///< Istwert dieses Referenzpunktes
	float 			fDesiredValue;					///< Sollwert dieses Referenzpunktes
	long 			lConvertionValue;				///< Digitalwert des Referenzpunktes inklusive Normierung
	long 			lRMV;							///< Digitalwert Rohmesswert zur DA-Wandlung
}DAC_CALIBRATIONPOINT;

/*~T*/
typedef struct
{
	float 					fOffset_RMV;			///< Offset der RMV-Normierung
	float 					fGain_RMV;				///< Verst�rkung der RMV-Normierung
	float 					fOffset_Norm;			///< Offset der DAC-Normierung
	float 					fGain_Norm;				///< Verst�rkung der DAC-Normierung 
	DAC_LIMITS				Limits;					///< DAV-Grenzwerte
	DAC_CALIBRATIONPOINT 	CalibrationPoint[2];	///< DAC-Kalibrierpunkte
	unsigned char 			bCorrectionOn;			///< Additive Korrektur eingeschaltet			
}DAC_SETTINGS;
/*~E:A37*/
/*~A:38*/
/*~+:RS232*/
/*~I:39*/
#ifdef RS232_WITH_STATISTICS
/*~T*/
typedef struct
{
	unsigned long 	ulETXCount;						///< Anzahl der empfangenen ETX-Steuerzeichen
	unsigned long 	ulSTXCount;						///< Anzahl der empfangenen STX-Steuerzeichen
}RS232_STATISTICS_T;
/*~-1*/
#endif
/*~E:I39*/
/*~T*/
typedef struct
{
	unsigned char	chNewCommandReceived;	///< Neues Kommando empfangen
	unsigned char*	pchRecBuffer;			///< Empfangsbuffer
	unsigned char*	pchRecBufferIndex;
	unsigned int 	nTransPointer;			///< Zeiger auf das zu sendende Zeichen
	unsigned char*	pchTransBuffer;			///< Sendebuffer
	char 			bEOT;					///< 1 = Daten sind gesendet
	unsigned char	chBufferSize;			///< Eingangspuffergr��e pro Befehl
	char			bESC;					///< es wurde ein ESC (0x1B) empfanhen
	unsigned char 	bTransmissionReleased;	///< RS232-Ausgabe freigegeben
	unsigned long 	ulTimeoutRS232Release;	///< Timeout der RS232-Freigabe
/*~I:40*/
#ifdef RS232_WITH_STATISTICS
/*~T*/
	RS232_STATISTICS_T Statistics;

/*~-1*/
#endif
/*~E:I40*/
/*~T*/
}RS232_T;

/*~E:A38*/
/*~A:41*/
/*~+:SPI*/
/*~T*/
typedef struct
{
	unsigned char	chNewCommandReceived;	///< Neues Kommando empfangen
	char 			byRecPointer;			///< Zeiger auf das zu sendende Zeichen
	unsigned char*	pchRecBuffer;			///< Zeiger auf den Empfangsbuffer
	unsigned char*	pchRecBufferIndex;
	unsigned char 	chSPIDataReceived;		///< Datum empfangen
	unsigned long 	ulTimeout;				///< Timeout-Zeit
	unsigned char	chBufferSize;			///< Eingangspuffergr��e pro Befehl
}SPI_T;

typedef struct
{
	unsigned char	bEnable;
	unsigned char 	bNewError;
	unsigned int 	uiErrorCounterSPI_RecChar;
	unsigned int 	uiErrorCounterSPI_SendChar;
	unsigned int 	uiErrorCounterSPI_WaitForFrame;
	unsigned int 	uiErrorCounterSPI_Misc_1;
	unsigned int 	uiErrorCounterSPI_Misc_2;
}SPI_ERRORBUFFER_T;

typedef enum
{
	SPI_ERROR_RECCHAR = 	0,
	SPI_ERROR_SENDCHAR,
	SPI_ERROR_WAIT4CHAR,
	SPI_ERROR_MISC_1,
	SPI_ERROR_MISC_2
}SPI_ERRORS_T;

/*~E:A41*/
/*~A:42*/
/*~+:Timer*/
/*~T*/
typedef struct
{
	unsigned long 	ulOperatingTime;			///< Betriebszeit (kein Betriebsstundenz�hler!)
	unsigned int 	uTimebase[TIMER_NB_TIMERS];	///< Zeitbasis jedes einzelnen Timers
	unsigned long	ulDestinationTime[TIMER_NB_TIMERS];		///< Zielzeit eine jeden Timers
	unsigned long 	ulDestinationTimeout;		///< Zielzeit 'Timeout'
	unsigned char	chTimerInterfaceOnOff;		///< Schalter f�r den Aufruf der Timer-Interface-Funktion
}TIMER;
/*~E:A42*/
/*~E:A36*/
/*~A:43*/
/*~+:Funktionsdeklarationen*/
/*~T*/
// Diese Funktionen m�ssen (!!!) extern bereitgestellt werden
extern void				Communication_Receive(unsigned char chCommunicationLine,unsigned char chCharReceived);
extern void 			Debug(long lLong_1,long lLong_2,long lLong_3,long lLong_4);
extern void 			External_Interface(unsigned char chNbOfExtInterrupt);
extern unsigned char	WatchdogInterface(unsigned char chWhat2Do,unsigned int *nWatchdogAddress);
/*~T*/
extern void 			ADuC836_Ini(unsigned char byMode);
extern char* 			ADuC836_Version(unsigned char byModul);
/*~A:44*/
/*~+:ADuC836 - Library task*/
/*~T*/
void ADuC836(void);
/*~E:A44*/
/*~A:45*/
/*~+:ADC*/
/*~T*/
extern unsigned char 	ADuC836_ADCCalibration(unsigned char byCalibrationMode);
extern void 			ADuC836_ADCClearNewConversationFlag(unsigned char byADC_Chanel);
extern void 			ADuC836_ADCDefaultIni(void);
extern float 			ADuC836_ADCGetConversionRate(float fProcessorFrequency);
/*~I:46*/
#ifdef ADC_MIT_WANDLERRATENERMITTLUNG
/*~T*/
extern unsigned int 	ADuC836_ADCGetConversionTime(unsigned char byChanel);

/*~-1*/
#endif
/*~E:I46*/
/*~T*/
extern long 			ADuC836_ADCGetConversionValue(unsigned char byADC_Chanel,unsigned char byIgnoreNewConversionFlag);

extern unsigned char 	ADuC836_ADCGetMeasurementDepth(unsigned char byADC_Chanel, unsigned char *p_byMeasurementDepth);

extern long 			ADuC836_ADCGetZeroOffset(unsigned char byADC_Chanel);
extern unsigned char 	ADuC836_ADCIni(unsigned char byADC_Chanel, unsigned char byADC_Mode, unsigned char byADC_Configuration,float fOutputUpdateRate,float fProcessorFrequency,char chHighPriority);

extern unsigned char 	ADuC836_ADCIsNewConversionValue(unsigned char byADC_Chanel);
extern unsigned char 	ADuC836_ADCSetMeasurementDepth(unsigned char byADC_Chanel, unsigned char byMeasurementDepth);
extern unsigned char 	ADuC836_ADCSetSincFilter(float fOutputUpdateRate,float fProcessorFrequency);
extern void ADC_SetToggleMode(unsigned char byADC_Chanel,bit bOnOff);
extern unsigned char 	ADuC836_ADCSetZeroOffset(unsigned char byADC_Chanel, long lZeroOffset);
extern unsigned char 	ADuC836_ADCToggle(unsigned char byADC);
extern void 			ADuC836_ADCToggleEx(unsigned char byADC,unsigned char byConversionChanel);

extern char* 			ADuC836_ADCVersion(void);

/*~E:A45*/
/*~A:47*/
/*~+:DAC*/
/*~T*/
extern unsigned char 			ADuC836_DACCalcCalibration(void);
extern void 					ADuC836_DACCalibrationClearPoints(void);
extern unsigned char			ADuC836_DACCalibrationSetPoint(unsigned char chPoint,float fTrueValue, float fDesiredValue);

extern float 					ADuC836_DACChangeGainbyStep(float fPercent);
extern long 					ADuC836_DACChangeOffsetbyStep(long lStep);
extern void 					ADuC836_DACClearCurrentDeviation(void);
extern void 					ADuC836_DACClearLimit(unsigned char chWhichLimit);
extern unsigned char 			ADuC836_DACClearOutput(char byMode);
extern unsigned char 			ADuC836_DACConvert(long *plValue2Convert, unsigned char chPass);

extern unsigned char 			ADuC836_DACConvertByOutputCurrent(float fOutputCurrent);
extern void 					ADuC836_DACDefaultIni(void);
extern unsigned char 			ADuC836_DACEnable(char byMode);
extern void 					ADuC836_DACEnableLimit(unsigned char chWhichLimit,bit bOnOff);

extern DAC_CALIBRATIONPOINT 	ADuC836_DACGetCalibrationPoint(unsigned char chPointId);
extern char 					ADuC836_DACGetCurrentDeviationCorrectionState(void);
extern long 					ADuC836_DACGetDigital(float fAnalog);
extern long 					ADuC836_DACGetDigitalNorm(float fAnalog);
extern float 					ADuC836_DACGetGain(unsigned char chWhat2Get);
extern float 					ADuC836_DACGetLastConvertedCurrent(void);
extern long 					ADuC836_DACGetLastConvertedValue(void);
extern long 					ADuC836_DACGetLimit(unsigned char chWhichLimit);
extern unsigned char 			ADuC836_DACGetLimitBehaviour(unsigned char chWhichLimit);
extern unsigned int 			ADuC836_DACGetLimitHysteresis(unsigned char byWhichLimit);
extern unsigned char 			ADuC836_DACGetLimitState(unsigned char chWhichLimit);
extern float 					ADuC836_DACGetOffset(unsigned char chWhat2Get);
extern long 					ADuC836_DACGetValue2Convert(void);
extern void 					ADuC836_DACIni(char byOutput,char byResolution,char byRange,char byEnable);

extern unsigned char 			ADuC836_DACIsLimit(unsigned char chWhichLimit);
extern unsigned char 			ADuC836_DACIsOutputCleared(void);
extern unsigned char 			ADuC836_DACLoadCalibrationPoint(unsigned char chPointId,DAC_CALIBRATIONPOINT DAC_CalibrationPoint2Set);

extern void 					ADuC836_DACLoadSettings(DAC_SETTINGS DAC_Settings2Load);
extern DAC_SETTINGS 			ADuC836_DACSaveSettings(void);
extern void 					ADuC836_DACSetCurrentDeviation(float fDeviation2Set);
extern void 					ADuC836_DACSetCurrentDeviationCorrectionOn(unsigned char byOn);
extern void						ADuC836_DACSetDigital2Value(long lConversioValue,float fOutputValue,float fFixedOutputValue);

extern void 					ADuC836_DACSetGain(float fGain2Set);
extern void 					ADuC836_DACSetGainNorm(float fGain2Set);
extern void 					ADuC836_DACSetLimit(unsigned char chWhichLimit,long lLimitValue,unsigned char chBehaviour);

extern void 					ADuC836_DACSetLimitHysteresis(unsigned char byWhichLimit,unsigned int uHysteresis);

extern void 					ADuC836_DACSetOffset(unsigned char chWhat2Get,float fOffset2Set);
extern unsigned char 			ADuC836_DACSetOutput(char byMode);
extern unsigned char 			ADuC836_DACSetRange(char byMode);
extern unsigned char 			ADuC836_DACSetResolution(char byMode);
extern char* 					ADuC836_DACVersion(void);
/*~E:A47*/
/*~A:48*/
/*~+:External*/
/*~T*/
extern void 	ADuC836_ExternalClearInterrupt(unsigned char chInterrupt2Clear);
extern void 	ADuC836_ExternalIni(unsigned char chModeExt0,unsigned char bOnOffExt0,unsigned char chModeExt1,unsigned char bOnOffExt1);

extern void 	ADuC836_ExternalSetInterrupt(unsigned char chInterrupt2Set);
extern char* 	ADuC836_ExternalVersion(void);
/*~E:A48*/
/*~A:49*/
/*~+:Flash*/
/*~T*/
// public-Funktionen

extern char 	ADuC836_FlashCheckResult(void);
extern char 	ADuC836_FlashClear(unsigned int nStartPage, unsigned int nEndPage);
extern char 	ADuC836_FlashDataSetPage(int nPageNr);
extern char 	ADuC836_FlashDataReadChar(char* pucData, int nPageNr, unsigned int nAnzahl);
extern char 	ADuC836_FlashDataReadFloat(float* pfData, int nPageNr, unsigned int nAnzahl);
extern char 	ADuC836_FlashDataReadInteger(int* pnData, int nPageNr, unsigned int nAnzahl);
extern char 	ADuC836_FlashDataReadLong(long* plData, int nPageNr, unsigned int nAnzahl);
extern char 	ADuC836_FlashDataReadPtr(void* pData, int nPageNr, unsigned int nAnzahl);
extern char 	ADuC836_FlashDataWriteChar(char* pucData, int nPageNr, unsigned int nAnzahl);
extern char 	ADuC836_FlashDataWriteFloat(float* pfData, int nPageNr, unsigned int nAnzahl);
extern char 	ADuC836_FlashDataWriteInteger(int* pnData, int nPageNr, unsigned int nAnzahl);
extern char 	ADuC836_FlashDataWriteLong(long* plData, int nPageNr, unsigned int nAnzahl);
extern char 	ADuC836_FlashDataWritePtr(void* pData, int nPageNr, unsigned int nAnzahl);
extern char 	ADuC836_FlashEraseAll(void);
extern char 	ADuC836_FlashErasePage(void);
extern char 	ADuC836_FlashReadPage(void);
extern char* 	ADuC836_FlashVersion(void);
extern char 	ADuC836_FlashWritePage(void);
/*~E:A49*/
/*~A:50*/
/*~+:RS232*/
/*~I:51*/
#ifdef RS232_WITH_STATISTICS 
/*~T*/
extern void 				ADuC836_RS232ClearStatistics(void);
/*~-1*/
#endif
/*~E:I51*/
/*~T*/
extern char 				ADuC836_RS232GetRecBuffer(char* pDest);

/*~I:52*/
#ifdef RS232_WITH_STATISTICS
/*~T*/
extern RS232_STATISTICS_T 	ADuC836_RS232GetStatistics(void);

/*~-1*/
#endif
/*~E:I52*/
/*~T*/
extern char 				ADuC836_RS232Ini(unsigned char chDatabits,unsigned long ulBaudrate,unsigned char* pchRecBuffer,unsigned char chBufferSize,unsigned char* pchTransBuffer,char byHighPriority);

extern char 				ADuC836_RS232IsCommunicationInProcess(void);
extern char 				ADuC836_RS232IsEscape(void);
extern char 				ADuC836_RS232IsNewCommand(void);
extern char 				ADuC836_RS232IsTransmissionReady(void);
extern char 				ADuC836_RS232Send(unsigned long ulTimeoutMS);
extern char 				ADuC836_RS232SetBaudrate(unsigned long ulBaudrate);
extern char 				ADuC836_RS232SetDataBits(unsigned char chDatabits);
extern void 				ADuC836_RS232SetNewCommandFlag(unsigned char bSetClear);
extern void 				ADuC836_RS232SetRelease(unsigned char byOnOff,unsigned long ulTimeout);

extern char* 				ADuC836_RS232Version(void);

/*~E:A50*/
/*~A:53*/
/*~+:SPI*/
/*~T*/
extern char 				ADuC836_SPICheckTimeout(void);
extern void 				ADuC836_SPIClearErrors(void);
extern void 				ADuC836_SPIDefaultIni(unsigned char chMasterMode,unsigned char *pRecBuffer,unsigned char byRecBufferSize);
extern void 				ADuC836_SPIEnable(bit bEnable);
extern void 				ADuC836_SPIEnableErrorCounter(unsigned char bOnOff);
extern SPI_ERRORBUFFER_T 	ADuC836_SPIGetErrors(void);
extern char 				ADuC836_SPIGetRecBuffer(char* pDest);
extern void 				ADuC836_SPIIncErrors(SPI_ERRORS_T Error);
extern void 				ADuC836_SPIIni(unsigned char byMode,bit bEnableSPI,char byHighPriority,unsigned char *pRecBuffer,unsigned char chBufferSize);

extern char 				ADuC836_SPIIsAcknowledge(char byWithTimeoutControl);
extern char 				ADuC836_SPIIsCommunicationInProcess(void);
extern char 				ADuC836_SPIIsNewCommand(void);
extern void 				ADuC836_SPIPrintErrorCounters(void);
extern char 				ADuC836_SPIReadChar(unsigned char* pchData);
extern char 				ADuC836_SPIReadPtr(unsigned char* pchData,unsigned int nNbChars);

extern char 				ADuC836_SPIReadPtrUntil(unsigned char* pchData,unsigned char chStopChar);

extern void 				ADuC836_SPIReleaseReception(void);
extern char 				ADuC836_SPISendChar(unsigned char chData);
extern char 				ADuC836_SPISendPtr(unsigned char* pchData,unsigned int nNbChars);

extern void 				ADuC836_SPISetNewCommandFlag(unsigned char bSetClear);
extern void 				ADuC836_SPISwitch2Mode(unsigned char chMode);
extern char* 				ADuC836_SPIVersion(void);
extern char 				ADuC836_SPIWait4Response(unsigned long ulTimeout);

/*~E:A53*/
/*~A:54*/
/*~+:Timer*/
/*~T*/
extern void 			ADuC836_TimerDelay(unsigned int uTimeMS);
extern void 			ADuC836_TimerCalcNewDestinationTime(unsigned char chWhichTimer,unsigned char chMode);

extern unsigned char 	ADuC836_TimerCheckTime(unsigned char chWhichTimer,unsigned char chMode);
extern bit 				ADuC836_TimerCheckTimeout(void);
extern char			 	ADuC836_TimerCorrectDestinationTime(unsigned char chWhichTimer,long lCorrectionValue);

extern void 			ADuC836_TimerIni(unsigned char chTimerInterfaceOnOff,char byHighPriority);

extern void 			ADuC836_TimerSetTimeout(unsigned int uTimeMS);
extern char 			ADuC836_TimerSetTimer(unsigned char chWhichTimer,unsigned int uTimeMS);
extern char* 			ADuC836_TimerVersion(void);
//extern void 			ADuC836_TimerWait(unsigned long ulTime) large reentrant;
extern void 			ADuC836_TimerWait(long lTime);
/*~T*/
extern void				Timer_Interface(void);
/*~E:A54*/
/*~A:55*/
/*~+:Watchdog*/
/*~T*/
extern void 			ADuC836_WatchdogClearAddress(void);
extern void 			ADuC836_WatchdogDefaultIni(void);
extern void 			ADuC836_WatchdogEnable(char chEnable);
extern void 			ADuC836_WatchdogIni(unsigned char chMode);
extern unsigned int 	ADuC836_WatchdogReadAddress(void);
extern void 			ADuC836_WatchdogReset(void);
extern void 			ADuC836_WatchdogRetrigger(void);
extern char*			ADuC836_WatchdogVersion(void);
/*~E:A55*/
/*~E:A43*/
/*~A:56*/
/*~+:Variablendeklarationen*/
/*~A:57*/
/*~+:RS232*/
/*~T*/
extern RS232_T RS232;
/*~E:A57*/
/*~A:58*/
/*~+:SPI*/
/*~T*/

/*~E:A58*/
/*~A:59*/
/*~+:Timer*/
/*~T*/
extern TIMER Timer;
/*~E:A59*/
/*~E:A56*/
/*~-1*/
#endif
/*~E:I12*/
