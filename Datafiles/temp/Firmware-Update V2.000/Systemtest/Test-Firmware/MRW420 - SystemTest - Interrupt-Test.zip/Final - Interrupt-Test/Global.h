/*~-1*/
/*~XSF_LANGUAGE: C/C++*/
/*~K*/
/*~+:File :        Global.h*/
/*~+:*/
/*~+:Version :     V1.0*/
/*~+:*/
/*~+:Date :        17.05.2005*/
/*~+:*/
/*~+:Time :        10:23*/
/*~+:*/
/*~+:Author :      MOF*/
/*~+:*/
/*~+:Hardware :*/
/*~+:*/
/*~+:Description :*/
/*~I:1*/
#ifndef __GLOBAL_H

/*~T*/
#define __GLOBAL_H

/*~T*/
// Wegen Fehler im ADuC836
#pragma NOAREGS

/*~A:2*/
/*~+:Includes*/
/*~T*/
// System-Konfiguration
#include "System.cnd"
/*~T*/
// ADuC836 - Systemheader
#include "ADuC836.h"
// ADuC836 - Hardwaretreiber
#include "ADuC836Driver.h"
// Analogeing�nge
#include "Analog.h"
// Filterung (Mittelwertfilter)
#include "AverageFilter.h"
// Kommunikationsroutinen
#include "Communication.h"
// Temperaturkompensation
#include "Compensation.h"
// Korrekturroutinen
#include "Correction.h"

/*~I:3*/
#ifdef MIT_CRC16
/*~T*/
// CRC16-Pr�fsumme
#include "CRC16.h"

/*~-1*/
#endif
/*~E:I3*/
/*~T*/
// Stromschnittstelle
#include "CurrentInterface.h"

/*~I:4*/
#ifdef SYSTEM_CND_WITH_DEADBAND_FILTER
/*~T*/
// Totband-Filter
#include "DeadBandFilter.h"

/*~-1*/
#endif
/*~E:I4*/
/*~I:5*/
#ifdef MIT_DEBUG
/*~T*/
// Debug-Funktionen
#include "Debug.h"

/*~-1*/
#endif
/*~E:I5*/
/*~T*/
// Fehlerbehandlungsroutinen
#include "Diagnosis.h"
// Digitale Ein-/Ausg�nge
#include "Digital.h"
//Eeprom-Treiber
#include "Ee24C64.h"
// Filterroutinen
#include "Filter.h"
// Befehlsdekoder
#include "InstructionDecoder.h"
// Grenzwertroutinen
#include "Limit.h"
// Speicherung ins Eeprom
#include "Load_Save.h"
// Messwertaufbereitung
#include "Measurement.h"
// Temperaturkompensation
#include "MRW_Compensation.h"
// Statistik

/*~T*/
#include "Statistics.h"
// Statistik-Bibliothek
#include "StatisticsLibrary.h"
// Strukturdefinitionen
#include "Structdef.h"
// Systemfunktionen
#include "System.h"
/*~I:6*/
#ifdef CHANNEL_0
/*~T*/
// TeachIn-Modul-Treiber
#include "TeachIn.h"

/*~-1*/
#endif
/*~E:I6*/
/*~T*/
// TeachIn-Task
#include "TeachInModul.h"
// Vordefinierte Texte
#include "Texte.h"
// Betriebsstundenz�hler und interner Timer
// #include "Timer.h"
// erweiterte Dateitypen
#include <Var_Types.h>
// Versionsverwaltung
#include "Version.h"
// Watchdog-�berwachung
#include "Watchdog.h"
// Gewichtsermittlung
#include "Weight.h"


/*~E:A2*/
/*~A:7*/
/*~+:Definitionen*/
/*~+:*/
/*~T*/
// Systemeinstellungen

// Dynamische Variablen

/*~I:8*/
#ifdef CHANNEL_0
/*~T*/
#define SIZE_DYNAMIC_VARIABLES		0x40
/*~-1*/
#endif
/*~E:I8*/
/*~I:9*/
#ifdef CHANNEL_1
/*~T*/
#define SIZE_DYNAMIC_VARIABLES		0x40

/*~-1*/
#endif
/*~E:I9*/
/*~A:10*/
/*~+:ADC*/
/*~A:11*/
/*~+:Defaultparameter*/
/*~I:12*/
#ifndef OHNE_STROMRUECKFUEHRUNG 
/*~T*/
///< Defaultparameter f�r den Hauptkanal
// Messbereich +/-20mV
// Bipolare Betriebsart
// Eingangspins A1 und A2
// Externe Referenzquelle
// 19.79Hz Abtastrate
#define DEFAULT_PRIMARY_ADC_SETTING				ADuC836_ADC_PRIMARY,ADuC836_ADC_CONT_CONVERSION|ADuC836_ADC_ENABLE_PRIMARY,ADuC836_ADC_RANGE_20MV|ADuC836_ADC_BIPOLAR|ADuC836_ADC_INPUT_AIN1_AIN2|ADuC836_ADC_EXTERNAL_REFERENCE,19.79,ADuC836_ADC_FREQUENCY_32KHZ

///< Defaultparameter f�r den Hauptkanal
// Messbereich +/-1280mV
// Unipolare Betriebsart
// Eingangspins A3 und A4
// Externe Referenzquelle
// 19.79Hz Abtastrate
#define DEFAULT_PRIMARY_TOGGLE_ADC_SETTING		ADuC836_ADC_PRIMARY_TOGGLE,ADuC836_ADC_CONT_CONVERSION|ADuC836_ADC_ENABLE_PRIMARY,ADuC836_ADC_RANGE_1280MV|ADuC836_ADC_UNIPOLAR|ADuC836_ADC_INPUT_AIN3_AIN4|ADuC836_ADC_EXTERNAL_REFERENCE,19.79,ADuC836_ADC_FREQUENCY_32KHZ


///< Defaultparameter f�r den 1.Hilfskanal
// Bipolare Betriebsart
// Temperatursensor als Messeingang
// Interne Referenzquelle
// 19.79Hz Abtastrate
#define DEFAULT_AUXILIARY_ADC_SETTING			ADuC836_ADC_AUXILIARY,ADuC836_ADC_CONT_CONVERSION|ADuC836_ADC_ENABLE_AUXILIARY,ADuC836_ADC_INPUT_TEMP|ADuC836_ADC_BIPOLAR|ADuC836_ADC_INTERNAL_REFERENCE,19.79,ADuC836_ADC_FREQUENCY_32KHZ	

///< Defaultparameter f�r den 2.Hilfskanal
// Bipolare Betriebsart
// AIN5 als Messeingang
// Interne Referenzquelle
// 19.79Hz Abtastrate
#define DEFAULT_AUXILIARY_TOGGLE_ADC_SETTING	ADuC836_ADC_AUXILIARY_TOGGLE,ADuC836_ADC_CONT_CONVERSION|ADuC836_ADC_ENABLE_AUXILIARY,ADuC836_ADC_INPUT_AIN5|ADuC836_ADC_UNIPOLAR|ADuC836_ADC_INTERNAL_REFERENCE,19.79,ADuC836_ADC_FREQUENCY_32KHZ
/*~A:13*/
/*~+:ausgeklammert - 5.35HZ-Abtastung*/
/*~I:14*/
#ifdef MOF
/*~T*/
///< Defaultparameter f�r den Hauptkanal
// Messbereich +/-20mV
// Bipolare Betriebsart
// Eingangspins A1 und A2
// Externe Referenzquelle
// 5.35Hz Abtastrate
#define DEFAULT_PRIMARY_ADC_SETTING				ADuC836_ADC_PRIMARY,ADuC836_ADC_CONT_CONVERSION|ADuC836_ADC_ENABLE_PRIMARY,ADuC836_ADC_RANGE_20MV|ADuC836_ADC_BIPOLAR|ADuC836_ADC_INPUT_AIN1_AIN2|ADuC836_ADC_EXTERNAL_REFERENCE,5.35,ADuC836_ADC_FREQUENCY_32KHZ

///< Defaultparameter f�r den Hauptkanal
// Messbereich +/-1280mV
// Unipolare Betriebsart
// Eingangspins A3 und A4
// Externe Referenzquelle
// 5.35Hz Abtastrate
#define DEFAULT_PRIMARY_TOGGLE_ADC_SETTING		ADuC836_ADC_PRIMARY_TOGGLE,ADuC836_ADC_CONT_CONVERSION|ADuC836_ADC_ENABLE_PRIMARY,ADuC836_ADC_RANGE_1280MV|ADuC836_ADC_UNIPOLAR|ADuC836_ADC_INPUT_AIN3_AIN4|ADuC836_ADC_EXTERNAL_REFERENCE,5.35,ADuC836_ADC_FREQUENCY_32KHZ


///< Defaultparameter f�r den 1.Hilfskanal
// Bipolare Betriebsart
// Temperatursensor als Messeingang
// Interne Referenzquelle
// 5.35Hz Abtastrate
#define DEFAULT_AUXILIARY_ADC_SETTING			ADuC836_ADC_AUXILIARY,ADuC836_ADC_CONT_CONVERSION|ADuC836_ADC_ENABLE_AUXILIARY,ADuC836_ADC_INPUT_TEMP|ADuC836_ADC_BIPOLAR|ADuC836_ADC_INTERNAL_REFERENCE,5.35,ADuC836_ADC_FREQUENCY_32KHZ	

///< Defaultparameter f�r den 2.Hilfskanal
// Bipolare Betriebsart
// AIN5 als Messeingang
// Externe Referenzquelle
// 5.35Hz Abtastrate
#define DEFAULT_AUXILIARY_TOGGLE_ADC_SETTING	ADuC836_ADC_AUXILIARY_TOGGLE,ADuC836_ADC_CONT_CONVERSION|ADuC836_ADC_ENABLE_AUXILIARY,ADuC836_ADC_INPUT_AIN5|ADuC836_ADC_UNIPOLAR|ADuC836_ADC_EXTERNAL_REFERENCE,5.35,ADuC836_ADC_FREQUENCY_32KHZ
/*~-1*/
#endif
/*~E:I14*/
/*~E:A13*/
/*~O:I12*/
/*~-1*/
#else
/*~T*/
///< Defaultparameter f�r den Hauptkanal
// Messbereich +/-20mV
// Bipolare Betriebsart
// Eingangspins A1 und A2
// Externe Referenzquelle
// 5.35Hz Abtastrate
#define DEFAULT_PRIMARY_ADC_SETTING				ADuC836_ADC_PRIMARY,ADuC836_ADC_CONT_CONVERSION|ADuC836_ADC_ENABLE_PRIMARY,ADuC836_ADC_RANGE_20MV|ADuC836_ADC_BIPOLAR|ADuC836_ADC_INPUT_AIN1_AIN2|ADuC836_ADC_EXTERNAL_REFERENCE,5.35,ADuC836_ADC_FREQUENCY_32KHZ

///< Defaultparameter f�r den 1.Hilfskanal
// Bipolare Betriebsart
// Temperatursensor als Messeingang
// Interne Referenzquelle
// 5.35Hz Abtastrate
#define DEFAULT_AUXILIARY_ADC_SETTING			ADuC836_ADC_AUXILIARY,ADuC836_ADC_CONT_CONVERSION|ADuC836_ADC_ENABLE_AUXILIARY,ADuC836_ADC_INPUT_TEMP|ADuC836_ADC_BIPOLAR|ADuC836_ADC_INTERNAL_REFERENCE,5.35,ADuC836_ADC_FREQUENCY_32KHZ	

///< Defaultparameter f�r den 2.Hilfskanal
// Bipolare Betriebsart
// AIN5 als Messeingang
// Externe Referenzquelle
// 5.35Hz Abtastrate
#define DEFAULT_AUXILIARY_TOGGLE_ADC_SETTING	ADuC836_ADC_AUXILIARY_TOGGLE,ADuC836_ADC_CONT_CONVERSION|ADuC836_ADC_ENABLE_AUXILIARY,ADuC836_ADC_INPUT_AIN5|ADuC836_ADC_UNIPOLAR|ADuC836_ADC_INTERNAL_REFERENCE,5.35,ADuC836_ADC_FREQUENCY_32KHZ
/*~-1*/
#endif
/*~E:I12*/
/*~E:A11*/
/*~E:A10*/
/*~T*/
// Administratorcode
#define ADMINCODE					Global.ulAdminCode
/*~T*/
// Definitionen zur Initialisierung
#define BYDEFAULT					0			///< Initialisierung mit Default-Werten
#define BYMEMORY					1			///< Initialisierung mit abgespeicherten Werten
#define REINITIALISATION			2			///< Neuinitialisierung mit Defaultwerten
/*~T*/
// Rohmesswert
#define MIN_NULLPUNKT				-32000		///< minimal zul�ssiger Nullpunkt
#define MAX_NULLPUNKT				32000		///< maximal zul�ssiger Nullpunkt

#define MIN_KALIBRIERFAKTOR        0.00001		///< minimal zul�ssiger Kalibrierfaktor  
#define MAX_KALIBRIERFAKTOR          100.0		///< maximal zul�ssiger Kalibrierfaktor

/*~T*/
// Status des Gesamtsystems
#define SYSTEMSTATE					Global.ulSystemstatus
#define SYSTEMSTATE_PARTNER			Global.ulSystemstatus_Partner
#define SYSTEM_RUNNING							1	///< System l�uft
#define SYSTEM_REC_CHARACTERISTICS_ON			10	///< Kennlinienaufnahme l�uft
#define SYSTEM_REC_CHARACTERISTICS_1ST_DRIFT	12	///< 1.Driftpunkt aufgenommen
#define SYSTEM_REC_CHARACTERISTICS_ERROR		14	///< Kennlinienaufnahme ERROR
#define SYSTEM_REC_CHARACTERISTICS_OKAY			16	///< Kennlinienaufnahme OKAY
#define SYSTEM_ERROR_CURRENT_DEVIATION			32	///< Abweichung Soll-/Iststrom zu gro�
#define SYSTEM_ERROR							255	///< Systemfehler
/*~T*/
// Timing
#define T100MS						0			///< 100ms-Timer
#define T300MS						1			///< 300ms-Timer
#define T500MS						2			///< 500ms-Timer
#define T1000MS						3			///< 1000ms-Timer
#define T2000MS						4			///< 2000ms-Timer
#define T10000MS					5			///< 10000ms-Timer
/*~A:15*/
/*~+:Temperaturkompensation*/
/*~T*/
#define TEMPERATURE_COMPENSATION_HI				75	///< oberer Kompensationspunkt
#define TEMPERATURE_COMPENSATION_LO				-25	///< unterer Kompensationspunkt
#define TEMPERATURE_COMPENSATION_SPAN			5	///< Temperaturspanne zwischen den Kompensationspunkten
/*~E:A15*/
/*~A:16*/
/*~+:Netzteilpr�fung*/
/*~T*/
#define UNTERE_GRENZE_NETZTEIL 		21400	//11000	// VCC - 10%
#define OBERE_GRENZE_NETZTEIL		26200	//14000	// VCC +10%
/*~E:A16*/
/*~A:17*/
/*~+:E-Modul-Kompensation*/
/*~T*/
#define FACTOR_E_MODUL			-0.0005			// -0.05%
/*~E:A17*/
/*~A:18*/
/*~+:Timing*/
/*~T*/
// Parametrierung
#define SYSTEM_TIMEOUT_SPI							100//100	//50					///< Originalwert : 50	///< Timeout SPI-Kommunikation

#define SYSTEM_TIMEOUT_SPI_LAST_COMMAND_EXECUTION	500
/*~T*/
#define SYSTEM_TIMEOUT_RS232						200//100			///< Originalwert : 200	///< Timeout SPI-Kommunikation
/*~E:A18*/
/*~E:A7*/
/*~A:19*/
/*~+:Makros*/
/*~T*/
#define MIN(A,B) A>B?B:A
#define MAX(A,B) A>B?A:B
/*~T*/
#define DAC_TESTMODE		Global.Mode.uTestMode&0x0001?1:0
#define SET_DAC_TESTMODE(A)	A?(Global.Mode.uTestMode |= 0x0001):(Global.Mode.uTestMode &= 0xFFFE)
/*~E:A19*/
/*~A:20*/
/*~+:Struktur-Definitionen*/
/*~T*/

/*~E:A20*/
/*~A:21*/
/*~+:Funktionsdeklarationen*/
/*~T*/


/*~E:A21*/
/*~A:22*/
/*~+:Variablen*/
/*~A:23*/
/*~+:Speicherplatz f�r Dynamische Variablen*/
/*~T*/
extern unsigned char ptrDynVar[SIZE_DYNAMIC_VARIABLES];
/*~E:A23*/
/*~A:24*/
/*~+:Timerflags*/
/*~T*/
extern bit Flag100ms;
extern bit Flag300ms;
extern bit Flag500ms;
extern bit Flag1000ms;
extern bit Flag2000ms;
extern bit Flag10000ms;
/*~E:A24*/
/*~A:25*/
/*~+:Allgemeine globalen Variablen*/
/*~T*/
extern GLOBAL Global;
extern long g_lWeightOffset4Limitest;

/*~E:A25*/
/*~E:A22*/
/*~-1*/
#endif
/*~E:I1*/
