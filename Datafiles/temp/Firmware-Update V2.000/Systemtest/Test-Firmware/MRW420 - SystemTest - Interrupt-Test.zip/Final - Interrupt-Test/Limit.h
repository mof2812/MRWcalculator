/*~-1*/
/*~XSF_LANGUAGE: C/C++*/
/*~A:1*/
/*~+:Versions-Beschreibung*/
/*~A:2*/
/*~+:Version und Versionsdatum*/
/*~T*/
/*!
\mainpage "Modul-Beschreibung"
\author Michael Offenbach
\date 08.06.2005 
\version V1.000
\warning
*/
/*~E:A2*/
/*~A:3*/
/*~+:Lifecycle*/
/*~T*/
/*!\page LifeCyclePage Lifecycle

\section sec_LifeCyclePage_ADuC836Driver 'ADuC836-Treiber'

<table border=1 width=100% height=1% rules=rows cellspacing=0 bgcolor="#E0E0F0">

<tr align=left valign=top>
	<th>Version</th>
	<th>Datum</th>
	<th>Programmierer</th>
	<th>�nderungen</th>
</tr>

<tr>
	<td>1.000</td>
	<td>08.06.2005</td>
	<td>Michael Offenbach</td>
	<td>Erste lauff�hige Version</td>
</tr>
</table>

*/
/*~E:A3*/
/*~E:A1*/
/*~I:4*/
#ifndef __LIMIT_H

/*~T*/
#define __LIMIT_H

/*~A:5*/
/*~+:Includes*/
/*~T*/

/*~E:A5*/
/*~A:6*/
/*~+:Definitionen*/
/*~T*/
#define LIMIT_ZERODRIFT_DETECTION				15	// ex. 10
#define LIMIT_ZERODRIFT_DETECTION_XL			30	// ex. 20
/*~T*/
#define LIMIT_NO_LIMIT_REACHED					0x00
#define LIMIT_HANGINGLIMT_EXCEEDED				0x01
#define LIMIT_TARALIMIT_EXCEEDED				0x02
#define LIMIT_ALARMLIMIT_EXCEEDED				0x80				
/*~E:A6*/
/*~A:7*/
/*~+:Struktur-Definitionen*/
/*~T*/
/*#LJ:1=158*/
typedef struct
{
	unsigned char chLimitState;		///< Status der Limit�berwachung
	unsigned char chLimitCheckFlag;	///< Flag f�r �berpr�fung der Limits
	float fLimitZeroPointCheck;		///< Grenzwert 'TaraLimit' bzw. 'ZeroPointCheck' 
}LIMIT;
/*~E:A7*/
/*~A:8*/
/*~+:Funktionsdeklarationen*/
/*~T*/
extern void 			Limit(void);
extern void 			Limit_ClearLimitState(unsigned char chLimitState2Clear);
extern void 			Limit_EnableAlarmLimits(bit bOnOff);
extern void 			Limit_Init(unsigned char byMode);
extern float 			Limit_GetAlarmLimit(unsigned char byWhichLimit);
extern unsigned char 	Limit_GetLimitCheckFlag(void);
extern unsigned char 	Limit_GetLimitState(void);
extern void 			Limit_GetPartnerLimitstate(void);
extern char 			Limit_SetAlarmLimits(void);
extern char 			Limit_SetAlarmLimitByWeight(unsigned char byActualWeight,float fWeight);

extern void 			Limit_SetLimitCheckFlag(unsigned char byFlag2Set);
extern void 			Limit_SetLimitState(unsigned char LimitState2Set);
extern char 			Limit_TeachTara(void);
/*~E:A8*/
/*~A:9*/
/*~+:Variablen*/
/*~T*/
extern LIMIT g_Limit;
/*~E:A9*/
/*~-1*/
#endif
/*~E:I4*/
