/*~-1*/
/*~XSF_LANGUAGE: C/C++*/
/*~T*/
/*
   (1) MODULNAME             :  WatchDog_Global.c
   (2) VERSION               :  1.00
   (3) DATUM                 :  11.08.2004

   (4) LETZTE �NDERUNG       :
   (5) PROJEKT (Vers.)       :  MRW Master / MRW Slave
   (6) PROGRAMMIERER         :  MOF
*/

/*~A:1*/
/*~+:Includes*/
/*~T*/
#include "ADuC836.h"
#include "ADuC836Driver.h"
/*~E:A1*/
/*~A:2*/
/*~+:Defines*/
/*~T*/

/*~E:A2*/
/*~A:3*/
/*~+:Funktionsprototypen*/
/*~T*/

/*~E:A3*/
/*~A:4*/
/*~+:Modulvariablen*/
/*~T*/
unsigned int g_nWatchDogAddress;		///< Adresse, an der der Watchdog auftrat.
/*~E:A4*/
