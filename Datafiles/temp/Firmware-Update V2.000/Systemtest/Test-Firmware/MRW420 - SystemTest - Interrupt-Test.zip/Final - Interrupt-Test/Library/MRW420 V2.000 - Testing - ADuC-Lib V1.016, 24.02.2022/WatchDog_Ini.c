/*~-1*/
/*~XSF_LANGUAGE: C/C++*/
/*~T*/
/*
   (1) MODULNAME             :  WatchDog_Ini.c
   (2) VERSION               :  1.00
   (3) DATUM                 :  11.08.2004

   (4) LETZTE �NDERUNG       :
   (5) PROJEKT (Vers.)       :  MRW Master / MRW Slave
   (6) PROGRAMMIERER         :  MOF
*/


/*~A:1*/
/*~+:Includes*/
/*~T*/
#include "ADuC836.h"
#include "ADuC836Driver.h"
/*~E:A1*/
/*~A:2*/
/*~+:Defines*/
/*~T*/

/*~E:A2*/
/*~A:3*/
/*~+:Funktionsprototypen*/
/*~T*/
void ADuC836_WatchdogIni(unsigned char chMode);
/*~E:A3*/
/*~A:4*/
/*~+:Modulvariablen*/
/*~T*/
extern unsigned int g_nWatchDogAddress;		///< Adresse, an der der Watchdog auftrat.
/*~E:A4*/
/*~A:5*/
/*~+:void ADuC836_WatchdogIni(unsigned char chMode)*/
/*~F:6*/
void ADuC836_WatchdogIni(unsigned char chMode)
/*~-1*/
{
   /*~A:7*/
   /*~+:Beschreibung*/
   /*~T*/
   /*!
   \fn void ADuC836_WatchdogIni(unsigned char chMode)
   
   <b>Beschreibung:</b><br>
   Initialisierung der Watchdog-Funktion.
   
   \param
   chMode: Beschreibung der Funktionsweise der Watchdog-Funktion. Zur Einstellung sind mehrer Definitionen vorbereitet.
   
   \return
   ./.
   
   <b>Zugriff:</b><br>
   [X] �ffentlich / [ ] Privat
   
   \ref
   ExamplePage_ADuC836Driver "Beispiel 'ADuC836-Treiber'"
   */

   /*~E:A7*/
   /*~A:8*/
   /*~+:Variablendeklarationen*/
   /*~T*/
   bit bEACopy;
   /*~E:A8*/
   /*~A:9*/
   /*~+:Variableninitialisierungen*/
   /*~T*/
   bEACopy = EA;
   /*~E:A9*/
   /*~T*/
   // Watchdog-Timer initialisieren
   EA = 0;
   WDWR = 1;

   /*~T*/
   WDCON = chMode; // 2 sec-Interval

   /*~T*/
   EA = bEACopy;

/*~-1*/
}
/*~E:F6*/
/*~E:A5*/
