/*~-1*/
/*~XSF_LANGUAGE: C/C++*/
/*~T*/
/*

   (1) MODULNAME             :  DAC_GetLastConvertedValue.c
   (2) VERSION               :  1.00
   (3) DATUM                 :  

   (4) LETZTE �NDERUNG       :  
   (5) PROJEKT (Vers.)       :  MRW Limit
   (6) PROGRAMMIERER         :  MOF

*/
/*~A:1*/
/*~+:Includes*/
/*~T*/
#include "DAC_Global.h"
/*~E:A1*/
/*~A:2*/
/*~+:Defines */
/*~T*/

/*~E:A2*/
/*~A:3*/
/*~+:Funktionsprototypen*/
/*~T*/
long ADuC836_DACGetLastConvertedValue(void);
/*~E:A3*/
/*~A:4*/
/*~+:Globale Variablen*/
/*~T*/

/*~E:A4*/
/*~A:5*/
/*~+:long ADuC836_DACGetLastConvertedValue(void);*/
/*~F:6*/
long ADuC836_DACGetLastConvertedValue(void)
/*~-1*/
{
   /*~T*/
   return g_DAC.Results.lActualConvertionValue;
/*~-1*/
}
/*~E:F6*/
/*~E:A5*/
