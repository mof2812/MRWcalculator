/*~-1*/
/*~XSF_LANGUAGE: C/C++*/
/*~K*/
/*~+:File :        RS232_SetDataBits.c*/
/*~+:*/
/*~+:Version :     V1.0*/
/*~+:*/
/*~+:Date :        03.06.2005*/
/*~+:*/
/*~+:Time :        10:23*/
/*~+:*/
/*~+:Author :      MOF*/
/*~+:*/
/*~+:Hardware :*/
/*~+:*/
/*~+:Description :*/
/*~+:*/
/*~+:*/
/*~A:1*/
/*~+:Includes*/
/*~T*/
#include "ADuC836.h"
#include "ADuC836Driver.h"
/*~E:A1*/
/*~A:2*/
/*~+:Funktionseigene Definitionen*/
/*~T*/

/*~E:A2*/
/*~A:3*/
/*~+:Funktionseigene Struktur-Definitionen*/
/*~T*/

/*~E:A3*/
/*~A:4*/
/*~+:Funktionsprototypen*/
/*~T*/
char ADuC836_RS232SetDataBits(unsigned char chDatabits);
/*~E:A4*/
/*~A:5*/
/*~+:Globale Variablen*/
/*~T*/

/*~E:A5*/
/*~A:6*/
/*~+:char ADuC836_RS232SetDataBits(unsigned char chDatabits)*/
/*~F:7*/
char ADuC836_RS232SetDataBits(unsigned char chDatabits)
/*~-1*/
{
   /*~A:8*/
   /*~+:Beschreibung*/
   /*~T*/
   /*!
   \fn unsigned char RS232_SetDataBits(unsigned char chDatabits)
   
   <b>Beschreibung:</b><br>
   Setzen der Datenbreite der RS232-Kommunikation. Es sind die Werte 8 und 9 m�glich.
   
   \param
   chDatabits: Anzahl der Bits pro Datum.
   
   \return
   Status der Funktionsausf�hrung
   
   \retval
   0: Alles okay.
   
   \retval
   1: Ung�ltiger Parameterwert - Datenbreite konnte nicht eingestellt werden.
   
   <b>Zugriff:</b><br>
   [X] �ffentlich / [ ] Privat
   
   \ref
   ExamplePage_RS232Kommunikation "RS232-Kommunikation"
   */

   /*~E:A8*/
   /*~T*/
   // Bits zur Bestimmung der Datenbreite ausklammern
   SCON &= 0x3F;
   /*~I:9*/
   if (chDatabits == 9)
   /*~-1*/
   {
      /*~T*/
      // 9-Bit Datenbreite einstellen und Empf�nger freigeben
      SCON |= 0xD0;
   /*~-1*/
   }
   /*~O:I9*/
   /*~-2*/
   else
   {
      /*~I:10*/
      if (chDatabits == 8)
      /*~-1*/
      {
         /*~T*/
         // 8-Bit Datenbreite einstellen und Empf�nger freigeben
         SCON |= 0x50;  
      /*~-1*/
      }
      /*~O:I10*/
      /*~-2*/
      else
      {
         /*~T*/
         return 1;
      /*~-1*/
      }
      /*~E:I10*/
   /*~-1*/
   }
   /*~E:I9*/
   /*~T*/
   return 0;
/*~-1*/
}
/*~E:F7*/
/*~E:A6*/
