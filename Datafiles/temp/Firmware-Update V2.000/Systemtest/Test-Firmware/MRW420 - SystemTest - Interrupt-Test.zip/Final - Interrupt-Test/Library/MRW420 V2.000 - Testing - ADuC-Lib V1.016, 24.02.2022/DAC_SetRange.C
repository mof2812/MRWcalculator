/*~-1*/
/*~XSF_LANGUAGE: C/C++*/
/*~T*/
/*

   (1) MODULNAME             :  DAC_SetRange.c
   (2) VERSION               :  1.00
   (3) DATUM                 :  

   (4) LETZTE �NDERUNG       :  
   (5) PROJEKT (Vers.)       :  MRW Limit
   (6) PROGRAMMIERER         :  MOF

*/
/*~A:1*/
/*~+:Includes*/
/*~T*/
#include "DAC_Global.h"
#include "string.h"
/*~E:A1*/
/*~A:2*/
/*~+:Defines */
/*~T*/

/*~E:A2*/
/*~A:3*/
/*~+:Funktionsprototypen*/
/*~T*/
unsigned char ADuC836_DACSetRange(char chMode);
/*~E:A3*/
/*~A:4*/
/*~+:Globale Variablen*/
/*~T*/

/*~E:A4*/
/*~A:5*/
/*~+:unsigned char ADuC836_DACSetRange(char chMode)*/
/*~A:6*/
/*~+:Beschreibung*/
/*~T*/
/*!
\fn unsigned char ADuC836_DACSetRange(char chMode)

<b>Beschreibung:</b><br>
Setzen des DAC-Ausgangsspannungsbereichs.

\param
chMode:
\param
0 = Ausgangsspannungsbereich von 0 bis AVDD.
\param
1 = Ausgangsspannungsbereich von 0 bis VRef.
\param
>1 = Nur R�ckgabe.

\return
Zustand des SFR-Bits DACCON.DACRN

<b>Zugriff:</b><br>
[X] �ffentlich / [ ] Privat

\ref
ExamplePage_ADuC836Driver "Beispiel 'ADuC836-Treiber'"
*/

/*~E:A6*/
/*~F:7*/
unsigned char ADuC836_DACSetRange(char chMode)
/*~-1*/
{
   /*~I:8*/
   if (chMode < 2)
   /*~-1*/
   {
      /*~T*/
      chMode <<= 2;
      DACCON &= 0xFB;
      DACCON |= chMode;
   /*~-1*/
   }
   /*~E:I8*/
   /*~T*/
   return ((DACCON & 0x04)>>2);
/*~-1*/
}
/*~E:F7*/
/*~E:A5*/
