/*~-1*/
/*~XSF_LANGUAGE: C/C++*/
/*~K*/
/*~+:File :        CRC16_Global.h*/
/*~+:*/
/*~+:Version :     V1.000*/
/*~+:*/
/*~+:Date :        10.05.2016*/
/*~+:Time :        */
/*~+:*/
/*~+:Author :      MOF*/
/*~+:*/
/*~+:Hardware :*/
/*~+:*/
/*~+:Description :*/
/*~I:1*/
#ifndef __CRC16_GLOBAL_H 
/*~T*/
#define __CRC16_GLOBAL_H
/*~A:2*/
/*~+:Includes*/
/*~T*/
#include "CRC16.h"
/*~E:A2*/
/*~A:3*/
/*~+:Konfiguration*/
/*~T*/

/*~E:A3*/
/*~A:4*/
/*~+:Definitionen*/
/*~T*/

/*~E:A4*/
/*~A:5*/
/*~+:Strukturdefinitionen*/
/*~T*/

/*~E:A5*/
/*~A:6*/
/*~+:Funktionsdeklarationen*/
/*~T*/

/*~E:A6*/
/*~A:7*/
/*~+:Variablendeklarationen*/
/*~T*/

/*~E:A7*/
/*~-1*/
#endif
/*~E:I1*/
