/*~-1*/
/*~XSF_LANGUAGE: C/C++*/
/*~T*/
/*

   (1) MODULNAME             :  DAC_Convert.c
   (2) VERSION               :  1.00
   (3) DATUM                 :  

   (4) LETZTE �NDERUNG       :  
   (5) PROJEKT (Vers.)       :  MRW Limit
   (6) PROGRAMMIERER         :  MOF

*/
/*~A:1*/
/*~+:Includes*/
/*~T*/
#include "DAC_Global.h"
#include "string.h"
/*~E:A1*/
/*~A:2*/
/*~+:Defines */
/*~T*/
#define LIMIT_HYSTERESIS_HIGH		0.16	// 0.16mA = 10kg
#define LIMIT_HYSTERESIS_LOW		0.03	// 0.03mA =  2kg
/*~E:A2*/
/*~A:3*/
/*~+:Funktionsprototypen*/
/*~T*/
unsigned char ADuC836_DACConvert(long *plValue2Convert, unsigned char byPass);
/*~E:A3*/
/*~A:4*/
/*~+:Globale Variablen*/
/*~T*/

/*~E:A4*/
/*~A:5*/
/*~+:unsigned char ADuC836_DACConvert(long *plValue2Convert, unsigned char byPass)*/
/*~F:6*/
unsigned char ADuC836_DACConvert(long *plValue2Convert, unsigned char byPass)
/*~-1*/
{
   /*~A:7*/
   /*~+:Beschreibung*/
   /*~T*/
   /*!
   \fn unsigned char ADuC836_DACConvert(long lConvertionValue,unsigned char byPass)
   
   <b>Beschreibung:</b><br>
   F�hrt eine Digital-Analogwandlung des �bergebenen Wertes durch. Vor der Wandlung wird jedoch noch gepr�ft, ob eine Grenzwert�berschreitung vorliegt. In diesem Falle wird der zu wandelnde Wert gem�� der Vorgaben f�r Grenzwert�berschreitungen gesetzt.
   
   \param
   lValue2Convert: Digitalwert, welcher gewandelt werden soll.
   
   \param
   byPass: Ist diese Flag gesetzt, wird die Grenzwertuntersuchung sowie die Verrechnung von Offset und Verst�rkung �bersprungen.
   
   \return
   Status der Funktionsausf�hrung.
   
   \retval
   0: Wandlung wurde ordnungsgem�� durchgef�hrt.
   \retval
   Bit 0 gesetzt: zu konvertierender Wert zu gro� - Analogausgang auf Maximalwert gesetzt.
   \retval
   Bit 1 gesetzt: unterer Grenzwert unterschritten.
   \retval
   Bit 2 gesetzt: unterer Grenzwert unterschritten - keine neue Wandlung durchgef�hrt.
   \retval
   Bit 5 gesetzt: oberer Grenzwert �berschritten.
   \retval
   Bit 6 gesetzt: oberer Grenzwert �berschritten - keine neue Wandlung durchgef�hrt.
   
   <b>Zugriff:</b><br>
   [X] �ffentlich / [ ] Privat
   
   \ref
   ExamplePage_ADuC836Driver "Beispiel 'ADuC836-Treiber'"
   */
   /*~E:A7*/
   /*~A:8*/
   /*~+:Variablendeklarationen*/
   /*~T*/
   unsigned char byRetVal;
   long lConvertionValue;
   long lHysteresis_High;
   long lHysteresis_Low;
   /*~E:A8*/
   /*~A:9*/
   /*~+:Variableninitialisierungen*/
   /*~T*/
   byRetVal = 0;
   lHysteresis_High = LIMIT_HYSTERESIS_HIGH / g_DAC.Settings.fGain_RMV / g_DAC.Settings.fGain_Norm;
   lHysteresis_Low = LIMIT_HYSTERESIS_LOW / g_DAC.Settings.fGain_RMV / g_DAC.Settings.fGain_Norm;

   /*~E:A9*/
   /*~I:10*/
   if (!(byPass & 0x01))
   /*~-1*/
   {
      /*~A:11*/
      /*~+:Untersuchung auf Grenzwert�berschreitungen*/
      /*~I:12*/
      if (g_DAC.Settings.Limits.byLimitSet & 0x01)
      /*~-1*/
      {
         /*~I:13*/
         if (((*plValue2Convert <= g_DAC.Settings.Limits.lLowerLimit)||((*plValue2Convert < g_DAC.Settings.Limits.lLowerLimit + lHysteresis_Low)&&(g_DAC.Results.byLimitReached & 0x01))&&(g_DAC.Settings.Limits.byLimitState != DAC_LOWER_UPPER_REACHED)))
         /*~-1*/
         {
            /*~A:14*/
            /*~+:Unterer Grenzwert unterschritten*/
            /*~T*/
            byRetVal |= 0x02;
            g_DAC.Results.byLimitReached |= 0x01;
            /*~C:15*/
            switch (g_DAC.Settings.Limits.byLowerLimitBehavior)
            /*~-1*/
            {
               /*~F:16*/
               case ADUC836_DAC_KEEP_OUTPUT:
               /*~-1*/
               {
                  /*~T*/
                  *plValue2Convert = g_DAC.Settings.Limits.lLowerLimit;
                  /*~T*/
                  break;
               /*~-1*/
               }
               /*~E:F16*/
               /*~F:17*/
               case ADUC836_DAC_IGNORE:
               /*~-1*/
               {
                  /*~T*/
                  byRetVal |= 0x04;
                  /*~T*/
                  return byRetVal;
               /*~-1*/
               }
               /*~E:F17*/
               /*~F:18*/
               case ADUC836_DAC_SET2ZERO:
               /*~-1*/
               {
                  /*~T*/
                  *plValue2Convert = 0x00000000;
                  byPass = 0x02;
                  /*~T*/
                  break;
               /*~-1*/
               }
               /*~E:F18*/
               /*~F:19*/
               case ADUC836_DAC_SET2MAXIMUM:
               /*~-1*/
               {
                  /*~T*/
                  *plValue2Convert = 0x00000FFF;		/// gilt f�r 8-Bit und 12-Bit-Mode
                  byPass = 0x02;
                  /*~T*/
                  break;
               /*~-1*/
               }
               /*~E:F19*/
            /*~-1*/
            }
            /*~E:C15*/
            /*~E:A14*/
         /*~-1*/
         }
         /*~O:I13*/
         /*~-2*/
         else
         {
            /*~I:20*/
            if (g_DAC.Settings.Limits.byLimitSet & 0x10)
            /*~-1*/
            {
               /*~I:21*/
               if ((*plValue2Convert >= g_DAC.Settings.Limits.lUpperLimit)||((*plValue2Convert > g_DAC.Settings.Limits.lUpperLimit - lHysteresis_High)&&(g_DAC.Results.byLimitReached & 0x10)))
               /*~-1*/
               {
                  /*~A:22*/
                  /*~+:Oberer Grenzwert �berschritten*/
                  /*~T*/
                  byRetVal |= 0x20;
                  g_DAC.Results.byLimitReached |= 0x10;
                  /*~T*/
                  // R�ckw�rtsz�hler f�r Zeithysterese setzen
                  g_DAC.Settings.Limits.uLimitHysteresisCounter = g_DAC.Settings.Limits.uHysteresisUpperLimit;
                  // Grenzwertstatus setzen
                  g_DAC.Settings.Limits.byLimitState = DAC_LOWER_UPPER_REACHED;
                  /*~C:23*/
                  switch (g_DAC.Settings.Limits.byUpperLimitBehavior)
                  /*~-1*/
                  {
                     /*~F:24*/
                     case ADUC836_DAC_KEEP_OUTPUT:
                     /*~-1*/
                     {
                        /*~T*/
                        *plValue2Convert = g_DAC.Settings.Limits.lUpperLimit;
                        /*~T*/
                        break;
                     /*~-1*/
                     }
                     /*~E:F24*/
                     /*~F:25*/
                     case ADUC836_DAC_IGNORE:
                     /*~-1*/
                     {
                        /*~T*/
                        byRetVal |= 0x40;
                        /*~T*/
                        return byRetVal;
                     /*~-1*/
                     }
                     /*~E:F25*/
                     /*~F:26*/
                     case ADUC836_DAC_SET2ZERO:
                     /*~-1*/
                     {
                        /*~T*/
                        *plValue2Convert = 0x00000000;
                        byPass = 0x02;
                        /*~T*/
                        break;
                     /*~-1*/
                     }
                     /*~E:F26*/
                     /*~F:27*/
                     case ADUC836_DAC_SET2MAXIMUM:
                     /*~-1*/
                     {
                        /*~T*/
                        *plValue2Convert = 0x00000FFF;		/// gilt f�r 8-Bit und 12-Bit-Mode
                        byPass = 0x02;
                        /*~T*/
                        break;
                     /*~-1*/
                     }
                     /*~E:F27*/
                  /*~-1*/
                  }
                  /*~E:C23*/
                  /*~E:A22*/
               /*~-1*/
               }
               /*~O:I21*/
               /*~-2*/
               else
               {
                  /*~T*/
                  // Innerhalb der Grenzwerte
                  /*~I:28*/
                  if (g_DAC.Settings.Limits.uLimitHysteresisCounter > 0)
                  /*~-1*/
                  {
                     /*~T*/
                     g_DAC.Settings.Limits.uLimitHysteresisCounter--;
                     /*~I:29*/
                     if (g_DAC.Settings.Limits.byLimitState == DAC_LOWER_UPPER_REACHED)
                     /*~-1*/
                     {
                        /*~T*/
                        byRetVal |= 0x20;
                        g_DAC.Results.byLimitReached |= 0x10;
                     /*~-1*/
                     }
                     /*~O:I29*/
                     /*~-2*/
                     else
                     {
                        /*~T*/
                        byRetVal |= 0x02;
                        g_DAC.Results.byLimitReached |= 0x01;
                     /*~-1*/
                     }
                     /*~E:I29*/
                     /*~T*/
                     // Abbruch - es erfolgt keine Wandlung
                     return byRetVal;
                  /*~-1*/
                  }
                  /*~O:I28*/
                  /*~-2*/
                  else
                  {
                     /*~T*/
                     g_DAC.Results.byLimitReached = 0;

                     g_DAC.Settings.Limits.byLimitState = DAC_NO_LIMIT_REACHED; 
                  /*~-1*/
                  }
                  /*~E:I28*/
               /*~-1*/
               }
               /*~E:I21*/
            /*~-1*/
            }
            /*~O:I20*/
            /*~-2*/
            else
            {
               /*~T*/
               g_DAC.Results.byLimitReached = 0;

               g_DAC.Settings.Limits.byLimitState = DAC_NO_LIMIT_REACHED; 
            /*~-1*/
            }
            /*~E:I20*/
         /*~-1*/
         }
         /*~E:I13*/
      /*~-1*/
      }
      /*~O:I12*/
      /*~-2*/
      else
      {
         /*~T*/
         g_DAC.Results.byLimitReached = 0;

         g_DAC.Settings.Limits.byLimitState = DAC_NO_LIMIT_REACHED; 
      /*~-1*/
      }
      /*~E:I12*/
      /*~E:A11*/
      /*~T*/
      // Letzten Rohmesswert zwischenspeichern
      g_DAC.Results.lRMV_DAC = *plValue2Convert;


   /*~-1*/
   }
   /*~E:I10*/
   /*~I:30*/
   // Achtung - der Variableninhalt von byPass kann sich ge�ndert haben
   if (!(byPass & 0x02))
   /*~-1*/
   {
      /*~T*/
      lConvertionValue = *plValue2Convert  * g_DAC.Settings.fGain_RMV + g_DAC.Settings.fOffset_RMV;
   /*~-1*/
   }
   /*~O:I30*/
   /*~-2*/
   else
   {
      /*~T*/
      lConvertionValue = *plValue2Convert;
   /*~-1*/
   }
   /*~E:I30*/
   /*~T*/
   g_DAC.Results.lActualConvertionValue = lConvertionValue;
   /*~T*/
   // R�ckrechnung des zu erwartenden Ausgangsstroms
   g_DAC.Results.fLastCurrent = (float)lConvertionValue * g_DAC.Settings.fGain_Norm + g_DAC.Settings.fOffset_Norm;   
   /*~I:31*/
   if (g_DAC.Results.fLastCurrent < 0)
   /*~-1*/
   {
      /*~T*/
      g_DAC.Results.fLastCurrent = 0;
   /*~-1*/
   }
   /*~O:I31*/
   /*~-2*/
   else
   {
      /*~I:32*/
      if (g_DAC.Results.fLastCurrent >= 100)
      /*~-1*/
      {
         /*~T*/
         g_DAC.Results.fLastCurrent = 99.9;
      /*~-1*/
      }
      /*~E:I32*/
   /*~-1*/
   }
   /*~E:I31*/
   /*~I:33*/
   if (g_DAC.Settings.bCorrectionOn)
   /*~-1*/
   {
      /*~T*/
      // Korrekturoffset hinzuaddieren sofern der DAC nicht auf einen Endwert gesetzt wird
      lConvertionValue += g_DAC.lOffset;
   /*~-1*/
   }
   /*~E:I33*/
   /*~I:34*/
   if (DACCON & 0x08)
   /*~-1*/
   {
      /*~A:35*/
      /*~+:8-Bit-Mode*/
      /*~I:36*/
      if (lConvertionValue & 0x80000000)
      /*~-1*/
      {
         /*~T*/
         lConvertionValue = 0x00000000;
         /*~T*/
         byRetVal |= 0x01;	
      /*~-1*/
      }
      /*~O:I36*/
      /*~-2*/
      else
      {
         /*~I:37*/
         if (lConvertionValue > 0x000000FF)
         /*~-1*/
         {
            /*~T*/
            lConvertionValue = 0x000000FF;
            /*~T*/
            byRetVal |= 0x01;	
         /*~-1*/
         }
         /*~E:I37*/
      /*~-1*/
      }
      /*~E:I36*/
      /*~E:A35*/
   /*~-1*/
   }
   /*~O:I34*/
   /*~-2*/
   else
   {
      /*~A:38*/
      /*~+:12-Bit-Mode*/
      /*~I:39*/
      if (lConvertionValue & 0x80000000)
      /*~-1*/
      {
         /*~T*/
         lConvertionValue = 0x00000000;
         /*~T*/
         byRetVal |= 0x01;	
      /*~-1*/
      }
      /*~O:I39*/
      /*~-2*/
      else
      {
         /*~I:40*/
         if (lConvertionValue > 0x00000FFF)
         /*~-1*/
         {
            /*~T*/
            lConvertionValue = 0x00000FFF;
            /*~T*/
            byRetVal |= 0x01;	
         /*~-1*/
         }
         /*~E:I40*/
      /*~-1*/
      }
      /*~E:I39*/
      /*~T*/
      DACH = (char)(lConvertionValue / 256); 
      /*~E:A38*/
   /*~-1*/
   }
   /*~E:I34*/
   /*~T*/
   DACL = (char)lConvertionValue;
   /*~T*/
   return byRetVal;
/*~-1*/
}
/*~E:F6*/
/*~E:A5*/
