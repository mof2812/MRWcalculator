/*~-1*/
/*~XSF_LANGUAGE: C/C++*/
/*~K*/
/*~+:File :        Timer_WaitMS.c*/
/*~+:*/
/*~+:Version :     V1.000*/
/*~+:*/
/*~+:Date :        03.06.2005*/
/*~+:*/
/*~+:Time :        */
/*~+:*/
/*~+:Author :      MOF*/
/*~+:*/
/*~+:Hardware :*/
/*~+:*/
/*~+:Description :*/
/*~A:1*/
/*~+:Includes*/
/*~T*/
#include "ADuC836Driver.h"

/*~E:A1*/
/*~A:2*/
/*~+:Funktionseigene Definitionen*/
/*~T*/

/*~E:A2*/
/*~A:3*/
/*~+:Funktionseigene Struktur-Definitionen*/
/*~T*/

/*~E:A3*/
/*~A:4*/
/*~+:Funktionsprototypen*/
/*~T*/
// void ADuC836_TimerWait(unsigned long ulTime) reentrant;
void ADuC836_TimerWait(long lTime);
/*~E:A4*/
/*~A:5*/
/*~+:Globale Variablen*/
/*~T*/
extern TIMER Timer;
/*~E:A5*/
/*~A:6*/
/*~+:void ADuC836_TimerWait(unsigned long ulTime) reentrant */
/*~F:7*/
// void ADuC836_TimerWait(unsigned long ulTime) reentrant	// in 1/10ms
void ADuC836_TimerWait(long lTime)	// in 1/10ms
/*~-1*/
{
   /*~A:8*/
   /*~+:Variablendeklarationen*/
   /*~T*/
   unsigned int i;
   long lTimeIndex;

   /*~E:A8*/
   /*~A:9*/
   /*~+:Variableninitialisierungen*/
   /*~T*/
   lTimeIndex = lTime;
   /*~E:A9*/
   /*~L:10*/
   while ( lTimeIndex-- > 0 )

   /*~-1*/
   {
      /*~L:11*/
      for ( i = 2; i != 0; --i)			// 118 f�r 1ms-Raster
      /*~-1*/
      {
         /*~T*/
         ;

      /*~-1*/
      }
      /*~E:L11*/
   /*~-1*/
   }
   /*~E:L10*/
/*~-1*/
}
/*~E:F7*/
/*~E:A6*/
