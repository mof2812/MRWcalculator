/*~-1*/
/*~XSF_LANGUAGE: C/C++*/
/*~A:1*/
/*~+:Version und Versionsdatum*/
/*~T*/
/*#LH:0F"Doxygen_ADuC836Driver.h"=66-88*/
/* Aktuelle Version in Doxygen_ADuC836Driver.h eintragen !!! */

Doxygen_ADuC836Driver.h
/*~E:A1*/
/*~A:2*/
/*~+:Zykluszeiten*/
/*~T*/
/*!
\~german
\page SUBPAGE_SOFTWARE_CYCLE_TIMES_ADUC836_DRIVER_SPI 'SPI-Treiber'

<table border=1 width=100% height=1% rules=rows cellspacing=0 bgcolor="#E0E0F0">

<tr align=left valign=top>
	<th>Minimale Durchlaufzeit</th>
	<th>Maximale Durchlaufzeit</th>
</tr>

<tr>
	<td>--- <B>ms</B></td>
	<td>--- <B>ms</B></td>
</tr></table>
\~
*/
/*~T*/
/*!
\~english
\page SUBPAGE_SOFTWARE_CYCLE_TIMES_ADUC836_DRIVER_SPI 'spi-driver'

<table border=1 width=100% height=1% rules=rows cellspacing=0 bgcolor="#E0E0F0">

<tr align=left valign=top>
	<th>minimal cycle time</th>
	<th>maximum cycle time</th>
</tr>

<tr>
	<td>--- <B>ms</B></td>
	<td>--- <B>ms</B></td>
</tr></table>
\~
*/
/*~E:A2*/
/*~A:3*/
/*~+:Interrupts und Registerb�nke*/
/*~T*/
/*!
\~german
\page SUBPAGE_SOFTWARE_INTERRUPTS_REGISTERBANKS_ADUC836_DRIVER_SPI 'SPI-Treiber'
\~english
\page SUBPAGE_SOFTWARE_INTERRUPTS_REGISTERBANKS_ADUC836_DRIVER_SPI 'spi-driver'
\~
<table width=100% rules=all bgcolor="#E0E0F0">
\~german
<tr align=center valign=top><th><b>Benutzte Interrupts</b></th><th><b>Priorit�t</b></th><th><b>Benutzte Registerb�nke</b></th></tr>
\~english
<tr align=center valign=top><th><b>used interrupts</b></th><th><b>priority</b></th><th><b>used registerbanks</b></th></tr>
\~
<tr align=left valign=top><th>[ ] Power Supply Monitor Interrupt</th><th align=center>[ ] High [ ] Low</th><th align=center>[ ] Bank 0</th></tr>
<tr align=left valign=top><th>[ ] Watchdog Interrupt</th><th align=center>[ ] High [ ] Low</th><th align=center>[ ] Bank 1</th></tr>
<tr align=left valign=top><th>[ ] External Interrupt 0</th><th align=center>[ ] High [ ] Low</th><th align=center>[ ] Bank 2</th></tr>
<tr align=left valign=top><th>[ ] ADC Interrupt</th><th align=center>[ ] High [ ] Low</th><th align=center>[ ] Bank 3</th></tr>
<tr align=left valign=top><th>[ ] Timer/Counter 0 Interrupt</th><th align=center>[ ] High [ ] Low</th><th></th></tr>
<tr align=left valign=top><th>[ ] External Interrupt 1</th><th align=center>[ ] High [ ] Low</th><th></th></tr>
<tr align=left valign=top><th>[ ] Timer/Counter 1 Interrupt</th><th align=center>[ ] High [ ] Low</th><th></th></tr>
<tr align=left valign=top><th>[ ] SPI Interrupt</th><th align=center>[ ] High [ ] Low</th><th></th></tr>
<tr align=left valign=top><th>[ ] Serial Interrupt</th><th align=center>[ ] High [ ] Low</th><th></th></tr>
<tr align=left valign=top><th>[ ] Timer/Counter 2 Interrupt</th><th align=center>[ ] High [ ] Low</th><th></th></tr>
<tr align=left valign=top><th>[ ] Time Interval Counter Interrupt</th><th align=center>[ ] High [ ] Low</th><th></th></tr>
</table>
*/
/*~E:A3*/
/*~I:4*/
#ifdef MOF
/*~A:5*/
/*~+:Lifecycle*/
/*~T*/
/*!
\~german
\page SUBPAGE_SOFTWARE_LIFECYCLE_ADUC836_DRIVER 'ADuC836-Treiber'

<table border=1 width=100% height=1% rules=rows cellspacing=0 bgcolor="#E0E0F0">

<tr align=left valign=top>
	<th>Version</th>
	<th>Datum</th>
	<th>Programmierer</th>
	<th>�nderungen</th>
</tr>

<tr>
	<td>1.000</td>
	<td>14.06.05</td>
	<td>Michael Offenbach</td>
	<td>Erste lauff�hige Version</td>
</tr>

<tr>
	<td>1.001</td>
	<td>28.06.05</td>
	<td>Michael Offenbach</td>
	<td>Die Ausgangsgr��e des DAC's kann nun direkt gesetzt werden.</td>
</tr>
</table>

*/
/*~T*/
/*!
\~english
\page SUBPAGE_SOFTWARE_LIFECYCLE_ADUC836_DRIVER 'ADuC836-driver'

<table border=1 width=100% height=1% rules=rows cellspacing=0 bgcolor="#E0E0F0">

<tr align=left valign=top>
	<th>version</th>
	<th>date</th>
	<th>programmer</th>
	<th>changes</th>
</tr>

<tr>
	<td>1.000</td>
	<td>14.06.05</td>
	<td>Michael Offenbach</td>
	<td>first running version</td>
</tr>

<tr>
	<td>1.001</td>
	<td>28.06.05</td>
	<td>Michael Offenbach</td>
	<td>the output of the DAC's can be set directly.</td>
</tr>
</table>

*/
/*~E:A5*/
/*~A:6*/
/*~+:Beispiel*/
/*~T*/
/*!
\~german 
\page SUBPAGE_SOFTWARE_EXAMPLES_ADUC836_DRIVER 'ADuC836-Treiber'
\~english
\page SUBPAGE_SOFTWARE_EXAMPLES_ADUC836_DRIVER 'ADuC836-drivers'
\~

\code


//Modulbeschreibung:
//Demo-Programm zur Demonstration der Einbindung der ADuC836-Treiber-Befehle 


// Includes
#include "ADuC836.h"
#include "ADuC836Driver.h"
#include "Flash.h"
#include <String.h>

// Direktive f�r ADuC836
#pragma NOAREGS

// Funktionsdeklarationen

main()
{
   // Timing

   unsigned long ulDestinationTime;
   // Flash-Routinen
   char szText[32];

   // ADC-Routinen
   long lADC_Resultat_0;	// Ergebnis der AD-Wandlung des Hauptkanals
   long lADC_Resultat_1;	// Ergebnis der AD-Wandlung des Hilfskanals

   // DAC-Routinen
   unsigned int uDigital;

   // SPI-Routinen
   unsigned char chReturn;
   unsigned char chData;

   // Systemvariablen ADuC836 setzen
   CFG836 |= 1;
   PLLCON &= 0xF8;
   T0 = 0;
   ulDestinationTime = Timer.ulOperatingTime + 250;
   strcpy(szText,"Hallo");

   chData = 0x30;
   // *************************************************************************************** //
   // * Demonstartion der ADC-Routinen														* //
   // *************************************************************************************** //


   // ADC mit Defaultwerten initialsieren
   ADuC836_ADCDefaultIni();
   // Messwerttiefe vorgeben.
   ADuC836_ADCSetMeasurementDepth(ADuC836_ADC_PRIMARY,2);
   // Messwertoffset vorgeben
   ADuC836_ADCSetZeroOffset(ADuC836_ADC_PRIMARY,0x8000);
   // Filterfrequenz einstellen
   ADuC836_ADCSetSincFilter(1,ADuC836_ADC_FREQUENCY_32KHZ);

   // *************************************************************************************** //
   // * Demonstartion der DAC-Routinen														* //
   // *************************************************************************************** //


   // DAC initialsieren
   ADuC836_DACIni(ADUC836_DAC_OUTPUTPIN_3,ADUC836_DAC_RESOLUTION_12BIT,ADUC836_DAC_RANGE_2_REF,ADUC836_DAC_ENABLE);
   // Offset vorgeben
   ADuC836_DACSetOffset(0,ADUC836_DAC_RMV,256);

   // Verst�rkung vorgeben
   ADuC836_DACSetGain(0.75);

   // Unteres Limit setzen
   ADuC836_DACSetLimit(ADUC836_DAC_LOWER_LIMIT,50,ADUC836_DAC_KEEP_OUTPUT);
   // Oberes Limit setzen
   ADuC836_DACSetLimit(ADUC836_DAC_UPPER_LIMIT,4050,ADUC836_DAC_SET2ZERO);



   // DAC auf ersten Kalibrierpunkt fahren
   // ADuC836_DACConvert(0);
   ADuC836_DACConvert(100);
   // und diesem Punkt den Ist- und Sollwert zuweisen
   // ADuC836_DACCalibrationSetPoint(0,1.140,2.5);
   ADuC836_DACCalibrationSetPoint(0,1.505,2.5);

   // DAC auf zweiten Kalibrierpunkt fahren
   // ADuC836_DACConvert(4095);
   ADuC836_DACConvert(4000);
   // und diesem Punkt den Ist- und Sollwert zuweisen
   // ADuC836_DACCalibrationSetPoint(1,18.874,23);
   ADuC836_DACCalibrationSetPoint(1,17.795,23);

   // Kalibrierfaktor berechnen
   ADuC836_DACCalcCalibration();
   // Kalibrierung �berpr�fen

   // 1.Punkt -> 2.5mA
   ADuC836_DACConvert(100);

   // 2.Punkt -> 23mA
   ADuC836_DACConvert(4000);

   // Unteren Grenzwert unterschreiten
   ADuC836_DACConvert(51);
   ADuC836_DACConvert(0);

   // Oberen Grenzwert �berschreiten
   ADuC836_DACConvert(4049);
   ADuC836_DACConvert(4095);

   // Stromwert in Digitalwert wandeln 
   uDigital = ADuC836_DACGetDigital(2.5);

   uDigital = ADuC836_DACGetDigital(23);
   // *************************************************************************************** //
   // * Demonstartion der Flash-Routinen													* //
   // *************************************************************************************** //


   ADuC836_FlashDataWritePtr(szText,0,sizeof(szText));

   memset(szText,0,sizeof(szText));

   ADuC836_FlashDataReadPtr(szText,0,5);
   // *************************************************************************************** //
   // * Demonstartion der SPI-Routinen														* //
   // *************************************************************************************** //

#ifdef SPI_MASTER
   ADuC836_SPIDefaultIni(1); 	// Master-Mode
#endif
#ifdef SPI_SLAVE
   // Der Slave-Kanal darf erst nach dem Master-Kanal initialisieren. Aus diesem Grund wird hier gewartet, bis der Master den Port SPICONTROL (/SS) nach LOW zieht. 
   while (SPICONTROL)
   {

   }
   ADuC836_SPIDefaultIni(0);	// Slave-Mode
#endif
   while (1)
   {
   	  // ************************************************************************************ //
      // * Demonstartion der ADC-Routinen													* //
   	  // ************************************************************************************ //

      lADC_Resultat_0 = ADuC836_ADCGetConversionValue(ADuC836_ADC_PRIMARY,0);
      lADC_Resultat_1 = ADuC836_ADCGetConversionValue(ADuC836_ADC_AUXILIARY,0);
   	  // ************************************************************************************ //
      // * Demonstartion der SPI-Routinen													* //
   	  // ************************************************************************************ //


      if (ulDestinationTime <= Timer.ulOperatingTime)
      {
         ulDestinationTime = Timer.ulOperatingTime + 250;
#ifdef SPI_MASTER
         // Kanal 0 (SPI-Master) liest 4mal pro Sekunde einen String vom Slave aus.
         chReturn =  ADuC836_SPIReadPtr(szText,0);
#endif
      }
#ifdef SPI_SLAVE
      // Kanal 1 (SPI-Slave) stellt einen String zum Auslesen bereit und wartet auf dessen Abschlu�.
      chReturn = ADuC836_SPISendPtr(szText,0);
#endif
   }
}

\endcode
*/
/*~E:A6*/
/*~-1*/
#endif
/*~E:I4*/
