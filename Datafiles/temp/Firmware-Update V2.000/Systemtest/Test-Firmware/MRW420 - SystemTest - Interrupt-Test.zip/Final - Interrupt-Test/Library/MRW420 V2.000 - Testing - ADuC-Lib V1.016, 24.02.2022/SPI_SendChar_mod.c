/*~-1*/
/*~XSF_LANGUAGE: C/C++*/
/*~K*/
/*~+:File :        SPI_SendChar.c*/
/*~+:*/
/*~+:Version :     V1.0*/
/*~+:*/
/*~+:Date :        14.06.2005*/
/*~+:*/
/*~+:Time :        10:23*/
/*~+:*/
/*~+:Author :      MOF*/
/*~+:*/
/*~+:Hardware :*/
/*~+:*/
/*~+:Description :*/
/*~A:1*/
/*~+:Includes*/
/*~T*/
#include "ADuC836Driver.h"
#include "SPI_Global.h"
/*~E:A1*/
/*~T*/
// #define TEST_SPI_SENDCHAR
/*~A:2*/
/*~+:Funktionseigene Definitionen*/
/*~T*/
#
/*~E:A2*/
/*~A:3*/
/*~+:Funktionseigene Struktur-Definitionen*/
/*~T*/

/*~E:A3*/
/*~A:4*/
/*~+:Funktionsprototypen*/
/*~T*/
char ADuC836_SPISendChar(unsigned char chData);
/*~E:A4*/
/*~A:5*/
/*~+:Globale Variablen*/
/*~T*/

/*~E:A5*/
/*~A:6*/
/*~+:char ADuC836_SPISendChar(unsigned char chData)*/
/*~F:7*/
char ADuC836_SPISendChar(unsigned char chData)
/*~-1*/
{
   /*~A:8*/
   /*~+:Beschreibung*/
   /*~T*/
   /*!
   \fn char ADuC836_SPISendChar(unsigned char chData)
   
   <b>Beschreibung:</b><br>
   Sendet ein Zeichen �ber die SPI-Schnittstelle.
   
   \param
   chData: zu sendendes Zeichen.
   
   \return
   Status der Funktionsausf�hrung.
   
   \retval
   0 : Alles okay.
   \retval
   1 : Timeout
   \retval
   2 : Datenkollision(z.Z.nicht aktiv)
   
   <b>Zugriff:</b><br>
   [X] �ffentlich / [ ] Privat
   
   \ref
   ExamplePage_ADuC836Driver "Beispiel 'ADuC836-Treiber'"
   */

   /*~E:A8*/
   /*~A:9*/
   /*~+:Variablendeklarationen*/
   /*~T*/
   unsigned int uTimeoutTimer;

   /*~E:A9*/
   /*~A:10*/
   /*~+:Variableninitialisierungen*/
   /*~T*/
   uTimeoutTimer = 0;

   /*~E:A10*/
   /*~T*/
   ISPI = 0;

   // Datum ins SPI-Senderegister eintragen 
   SPIDAT = chData;

   /*~K*/
   /*~+:Warte bis die Daten gesendet sind - Timeout liefert 2 zur�ck*/
   /*~T*/
   uTimeoutTimer = 2500;
   /*~L:11*/
   while ((!ISPI)&&(--uTimeoutTimer))
   /*~-1*/
   {
      /*~T*/

   /*~-1*/
   }
   /*~E:L11*/
   /*~I:12*/
   if (ISPI)
   /*~-1*/
   {
      /*~T*/
      ISPI = 0;
      /*~T*/
      return 0;
   /*~-1*/
   }
   /*~O:I12*/
   /*~-2*/
   else
   {
      /*~T*/
      return 1;
   /*~-1*/
   }
   /*~E:I12*/
/*~-1*/
}
/*~E:F7*/
/*~E:A6*/
