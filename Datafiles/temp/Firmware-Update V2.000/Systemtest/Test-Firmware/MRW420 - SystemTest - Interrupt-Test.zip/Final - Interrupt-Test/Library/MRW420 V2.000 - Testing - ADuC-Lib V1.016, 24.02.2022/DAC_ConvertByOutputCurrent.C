/*~-1*/
/*~XSF_LANGUAGE: C/C++*/
/*~T*/
/*

   (1) MODULNAME             :  DAC_ConvertByOutputCurrent.c
   (2) VERSION               :  1.00
   (3) DATUM                 :  

   (4) LETZTE �NDERUNG       :  
   (5) PROJEKT (Vers.)       :  MRW Limit
   (6) PROGRAMMIERER         :  MOF

*/
/*~A:1*/
/*~+:Includes*/
/*~T*/
#include "DAC_Global.h"
#include "string.h"
/*~E:A1*/
/*~A:2*/
/*~+:Defines */
/*~T*/

/*~E:A2*/
/*~A:3*/
/*~+:Funktionsprototypen*/
/*~T*/
unsigned char ADuC836_DACConvertByOutputCurrent(float fOutputCurrent);
/*~E:A3*/
/*~A:4*/
/*~+:Globale Variablen*/
/*~T*/

/*~E:A4*/
/*~A:5*/
/*~+:unsigned char ADuC836_DACConvertByOutputCurrent(float fOutputCurrent)*/
/*~F:6*/
unsigned char ADuC836_DACConvertByOutputCurrent(float fOutputCurrent)
/*~-1*/
{
   /*~A:7*/
   /*~+:Variablendeklarationen*/
   /*~T*/
   long lConversionValue;
   /*~E:A7*/
   /*~A:8*/
   /*~+:Variableninitialisierungen*/
   /*~T*/

   /*~E:A8*/
   /*~T*/
   lConversionValue = (fOutputCurrent-g_DAC.Settings.fOffset_Norm) / g_DAC.Settings.fGain_Norm;
   /*~T*/
   return ADuC836_DACConvert(&lConversionValue,2);
/*~-1*/
}
/*~E:F6*/
/*~E:A5*/
