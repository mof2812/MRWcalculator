/*~-1*/
/*~XSF_LANGUAGE: C/C++*/
/*~T*/
/*

   (1) MODULNAME             :  DAC_CalibrationSetPoint.c
   (2) VERSION               :  1.00
   (3) DATUM                 :  

   (4) LETZTE �NDERUNG       :  
   (5) PROJEKT (Vers.)       :  MRW Limit
   (6) PROGRAMMIERER         :  MOF

*/
/*~A:1*/
/*~+:Includes*/
/*~T*/
#include "DAC_Global.h"
#include "string.h"
/*~E:A1*/
/*~A:2*/
/*~+:Defines */
/*~T*/

/*~E:A2*/
/*~A:3*/
/*~+:Funktionsprototypen*/
/*~T*/
unsigned char ADuC836_DACCalibrationSetPoint(unsigned char byPoint,float fTrueValue, float fDesiredValue);
/*~E:A3*/
/*~A:4*/
/*~+:Globale Variablen*/
/*~T*/

/*~E:A4*/
/*~A:5*/
/*~+:unsigned char ADuC836_DACCalibrationSetPoint(unsigned char byPoint,float fTrueValue, float fDesiredValue)*/
/*~F:6*/
unsigned char ADuC836_DACCalibrationSetPoint(unsigned char byPoint,float fTrueValue, float fDesiredValue)
/*~-1*/
{
   /*~A:7*/
   /*~+:Beschreibung*/
   /*~T*/
   /*!
   \fn unsigned char ADuC836_DACCalibrationSetPoint(unsigned char byPoint,float fTrueValue, float fDesiredValue)
   
   <b>Beschreibung:</b><br>
   Setzen eines Referenzpunktes zur Berechnung der DAC-Normierungswerte.
   
   \param
   byPoint: Angabe, um welchen Punkt es sich handelt (0 oder 1).
   
   \param
   fTrueValue: Istwert des DAC-Ausgangs.
   
   \param
   fDesiredValue: Sollwert des DAC-Ausgangs.
   
   \return
   Status der Funktionsausf�hrung.
   
   \retval
   0: Referenzpunkt erfolgreich gesetzt.
   
   \retval
   1: F�r byPoint wurde ein Wert gr��er 1 angegeben.
   
   <b>Zugriff:</b><br>
   [X] �ffentlich / [ ] Privat
   
   \ref
   
   ExamplePage_ADuC836Driver "Beispiel 'ADuC836-Treiber'"
   */

   /*~E:A7*/
   /*~A:8*/
   /*~+:Variablendeklarationen*/
   /*~T*/
   unsigned char byPointSet;
   /*~E:A8*/
   /*~A:9*/
   /*~+:Variableninitialisierungen*/
   /*~T*/
   byPointSet = 1;
   /*~E:A9*/
   /*~I:10*/
   if (byPoint < 2)
   /*~-1*/
   {
      /*~T*/
      g_DAC.Settings.CalibrationPoint[byPoint].fTrueValue = fTrueValue;

      g_DAC.Settings.CalibrationPoint[byPoint].lConvertionValue = g_DAC.Results.lActualConvertionValue;

      g_DAC.Settings.CalibrationPoint[byPoint].lRMV = g_DAC.Results.lRMV_DAC;

      g_DAC.Settings.CalibrationPoint[byPoint].fDesiredValue = fDesiredValue;

      byPointSet <<= byPoint;
      g_DAC.Settings.CalibrationPoint[0].byPointsSet |= byPointSet;  
      /*~I:11*/
      if ((g_DAC.Settings.CalibrationPoint[0].byPointsSet & 0x03) == 0x03)
      /*~-1*/
      {
         /*~T*/
         return ADuC836_DACCalcCalibration();
      /*~-1*/
      }
      /*~O:I11*/
      /*~-2*/
      else
      {
         /*~T*/
         return 0;
      /*~-1*/
      }
      /*~E:I11*/
   /*~-1*/
   }
   /*~O:I10*/
   /*~-2*/
   else
   {
      /*~T*/
      return 1;
   /*~-1*/
   }
   /*~E:I10*/
/*~-1*/
}
/*~E:F6*/
/*~E:A5*/
