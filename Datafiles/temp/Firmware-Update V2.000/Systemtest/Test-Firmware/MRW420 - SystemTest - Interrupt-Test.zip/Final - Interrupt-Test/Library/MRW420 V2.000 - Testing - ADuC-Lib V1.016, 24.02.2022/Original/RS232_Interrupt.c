/*~-1*/
/*~XSF_LANGUAGE: C/C++*/
/*~K*/
/*~+:File :        RS232_Interrupt.c*/
/*~+:*/
/*~+:Version :     V1.008*/
/*~+:*/
/*~+:Date :        09.02.2022*/
/*~+:*/
/*~+:Time :        10:23*/
/*~+:*/
/*~+:Author :      MOF*/
/*~+:*/
/*~+:Hardware :*/
/*~+:*/
/*~+:Description :*/
/*~+:*/
/*~+:*/
/*~A:1*/
/*~+:Includes*/
/*~T*/
#include "ADuC836.h"
#include "ADuC836Driver.h"
#include <string.h>
/*~E:A1*/
/*~A:2*/
/*~+:Funktionseigene Definitionen*/
/*~T*/

/*~E:A2*/
/*~A:3*/
/*~+:Funktionseigene Struktur-Definitionen*/
/*~T*/

/*~E:A3*/
/*~A:4*/
/*~+:Funktionsprototypen*/
/*~T*/

/*~E:A4*/
/*~A:5*/
/*~+:Globale Variablen*/
/*~T*/

/*~E:A5*/
/*~A:6*/
/*~+:void ADuC836_RS232Interrupt() interrupt 4*/
/*~F:7*/
void ADuC836_RS232Interrupt() interrupt 4 // using 3

/*~-1*/
{
   /*~A:8*/
   /*~+:Beschreibung*/
   /*~T*/
   /*!
   \fn void RS232_Interrupt() interrupt 4
   
   <b>Beschreibung:</b><br>
   Interruptroutine zum Empfangen oder Senden einzelner Zeichen �ber die RS232-Schnittstelle.
   
   \return
   ./.
   
   <b>Zugriff:</b><br>
   [] �ffentlich / [X] Privat
   
   \ref
   ExamplePage_RS232Kommunikation "RS232-Kommunikation"
   */

   /*~E:A8*/
   /*~A:9*/
   /*~+:Variablendeklarationen*/
   /*~T*/
   unsigned char 			chRS232Data;
   /*~E:A9*/
   /*~A:10*/
   /*~+:Variableninitialisierungen*/
   /*~T*/

   /*~E:A10*/
   /*~I:11*/
   if (RI)
   /*~-1*/
   {
      /*~A:12*/
      /*~+:Empfangs-Interrupt*/
      /*~I:13*/
      if (!RS232.chNewCommandReceived)
      /*~-1*/
      {
         /*~T*/
         chRS232Data = SBUF;
         /*~I:14*/
         if (chRS232Data == 0x02)	// STX
         /*~-1*/
         {
            /*~T*/
            /* STX empfangen */
            RS232.pchRecBufferIndex = RS232.pchRecBuffer;
            /*~I:15*/
#ifdef RS232_WITH_STATISTICS
            /*~T*/
            RS232.Statistics.ulSTXCount++;
            /*~-1*/
#endif
            /*~E:I15*/
         /*~-1*/
         }
         /*~O:I14*/
         /*~-2*/
         else
         {
            /*~I:16*/
            if (RS232.pchRecBufferIndex != 0)
            /*~-1*/
            {
               /*~I:17*/
               /* STX bereits empfangen - bereit f�r die n�chsten Zeichen */
               if (chRS232Data == 0x03)	// ETX)
               /*~-1*/
               {
                  /*~T*/
                  /* ETX bereits empfangen - Empfangsstring abschlie�en und den Empfangsindex auf 0 setzen */

                  *RS232.pchRecBufferIndex = 0;

                  RS232.pchRecBufferIndex = 0;
                  /*~I:18*/
                  if (*RS232.pchRecBuffer == 0x1B)
                  /*~-1*/
                  {
                     /*~T*/
                     /* Vermerk setzen, dass der Empfangsstring ein ESC-Zeichen war */
                     RS232.bESC = 1;
                  /*~-1*/
                  }
                  /*~O:I18*/
                  /*~-2*/
                  else
                  {
                     /*~T*/
                     /* Flag f�r empfangenen Befehlsstring setzen */
                     RS232.chNewCommandReceived = 1;
                  /*~-1*/
                  }
                  /*~E:I18*/
                  /*~I:19*/
#ifdef RS232_WITH_STATISTICS
                  /*~T*/
                  RS232.Statistics.ulETXCount++;
                  /*~-1*/
#endif
                  /*~E:I19*/
               /*~-1*/
               }
               /*~O:I17*/
               /*~-2*/
               else
               {
                  /*~I:20*/
                  if (RS232.pchRecBufferIndex - RS232.pchRecBuffer < RS232.chBufferSize - 1)
                  /*~-1*/
                  {
                     /*~T*/
                     /* Ausreichend Speicher vorhanden - Daten im Speicher eintragen und Index inkrementieren */

                     *RS232.pchRecBufferIndex = chRS232Data;

                     RS232.pchRecBufferIndex++;
                  /*~-1*/
                  }
                  /*~O:I20*/
                  /*~-2*/
                  else
                  {
                     /*~T*/
                     /* Speicher voll - Empfangsindex auf 0 setzen - jetzt muss es wieder mit STX losgehen */

                     RS232.pchRecBufferIndex = 0;
                  /*~-1*/
                  }
                  /*~E:I20*/
               /*~-1*/
               }
               /*~E:I17*/
            /*~-1*/
            }
            /*~O:I16*/
            /*~-2*/
            else
            {
               /*~T*/
               // Es kommt ein Zeichen, ohne dass zuvor ein STX empfangen wurde - oder Buffer ist voll
            /*~-1*/
            }
            /*~E:I16*/
         /*~-1*/
         }
         /*~E:I14*/
      /*~-1*/
      }
      /*~E:I13*/
      /*~E:A12*/
      /*~T*/
      RI = 0;
   /*~-1*/
   }
   /*~O:I11*/
   /*~-2*/
   else
   {
      /*~A:21*/
      /*~+:Sende-Interrupt*/
      /*~T*/
      chRS232Data = *(RS232.pchTransBuffer+RS232.nTransPointer);
      *(RS232.pchTransBuffer+RS232.nTransPointer) = 0;
      /*~I:22*/
      if (chRS232Data)
      /*~-1*/
      {
         /*~T*/
         RS232.nTransPointer++;
         SBUF = chRS232Data;
         /*~I:23*/
         if (RS232.ulTimeoutRS232Release != -1)
         /*~-1*/
         {
            /*~T*/
            // f�r l�ngere Daten, die Timeoutzeit erweitern

            RS232.ulTimeoutRS232Release = Timer.ulOperatingTime + 50; 
         /*~-1*/
         }
         /*~E:I23*/
      /*~-1*/
      }
      /*~O:I22*/
      /*~-2*/
      else
      {
         /*~T*/
         // Sendestring-Pointer zur�cksetzen
         RS232.nTransPointer = 0;

         // �bertragung beendet
         RS232.bEOT = 1;
         /*~T*/
         TXD = 1;
      /*~-1*/
      }
      /*~E:I22*/
      /*~E:A21*/
      /*~T*/
      TI = 0;
   /*~-1*/
   }
   /*~E:I11*/
/*~-1*/
}
/*~E:F7*/
/*~E:A6*/
