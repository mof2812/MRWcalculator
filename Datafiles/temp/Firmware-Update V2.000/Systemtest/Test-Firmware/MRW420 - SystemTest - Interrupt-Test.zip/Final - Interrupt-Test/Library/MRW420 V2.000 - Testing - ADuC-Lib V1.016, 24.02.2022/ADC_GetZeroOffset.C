/*~-1*/
/*~XSF_LANGUAGE: C/C++*/
/*~T*/
/*

   (1) MODULNAME             :  ADC_GetZeroOffset.c
   (2) VERSION               :  1.00
   (3) DATUM                 :  

   (4) LETZTE �NDERUNG       :  
   (5) PROJEKT (Vers.)       :  MRW Limit
   (6) PROGRAMMIERER         :  MOF

*/
/*~A:1*/
/*~+:Includes*/
/*~T*/
#include "ADC_Global.h"
/*~E:A1*/
/*~A:2*/
/*~+:Defines */
/*~T*/

/*~E:A2*/
/*~A:3*/
/*~+:Funktionsprototypen*/
/*~T*/
long ADuC836_ADCGetZeroOffset(unsigned char byADC_Chanel);
/*~E:A3*/
/*~A:4*/
/*~+:Modulvariablen*/
/*~T*/
extern ADC_SETTINGS ADC_Settings[];		///< ADC-Parameter f�r Haupt- und Hilfs-ADC
extern ADC_RESULTS 	ADC_Results[];			///< Ergebnisse der AD-Wandlungen
/*~E:A4*/
/*~A:5*/
/*~+:long ADuC836_ADCGetZeroOffset(unsigned char byADC_Chanel)*/
/*~F:6*/
long ADuC836_ADCGetZeroOffset(unsigned char byADC_Chanel)
/*~-1*/
{
   /*~A:7*/
   /*~+:Beschreibung*/
   /*~T*/
   /*!
   \fn unsigned char ADuC836_ADCSetZeroOffset(unsigned char byADC_Chanel, long lZeroOffset)
   
   <b>Beschreibung:</b><br>
   Setzen des ADC-Offsets. Dieser Wert wird zum eigentlichen Wandlerergebnis hinzuaddiert.
   
   \param
   byADC_Chanel: Kanal, zu welchem der �bergebene Offset zugeh�rig ist.
   
   \param
   lZeroOffset: zu setzender Offset-Wert.
   
   \return
   Status der Funktionsausf�hrung.
   
   \retval
   0: Alles okay.
   \retval
   1: Angegebener Kanal existiert nicht.
   
   <b>Zugriff:</b><br>
   [X] �ffentlich / [ ] Privat
   
   \ref
   ExamplePage_ADuC836Driver "Beispiel 'ADuC836-Treiber'"
   */

   /*~E:A7*/
   /*~I:8*/
   if (byADC_Chanel < ADC_MAX_CHANELS)
   /*~-1*/
   {
      /*~T*/
      return g_ADC.Settings[byADC_Chanel].lZeroOffset;
   /*~-1*/
   }
   /*~O:I8*/
   /*~-2*/
   else
   {
      /*~T*/
      return 0x80000000;
   /*~-1*/
   }
   /*~E:I8*/
/*~-1*/
}
/*~E:F6*/
/*~E:A5*/
