/*~-1*/
/*~XSF_LANGUAGE: C/C++*/
/*~T*/
/*

   (1) MODULNAME             :  DAC_GetLimitState.c
   (2) VERSION               :  1.00
   (3) DATUM                 :  

   (4) LETZTE �NDERUNG       :  
   (5) PROJEKT (Vers.)       :  MRW Limit
   (6) PROGRAMMIERER         :  MOF

*/
/*~A:1*/
/*~+:Includes*/
/*~T*/
#include "DAC_Global.h"
#include "string.h"
/*~E:A1*/
/*~A:2*/
/*~+:Defines */
/*~T*/

/*~E:A2*/
/*~A:3*/
/*~+:Funktionsprototypen*/
/*~T*/
unsigned char ADuC836_DACGetLimitState(unsigned char byWhichLimit);
/*~E:A3*/
/*~A:4*/
/*~+:Globale Variablen*/
/*~T*/

/*~E:A4*/
/*~A:5*/
/*~+:unsigned char ADuC836_DACGetLimitState(unsigned char byWhichLimit)*/
/*~F:6*/
unsigned char ADuC836_DACGetLimitState(unsigned char byWhichLimit)
/*~-1*/
{
   /*~A:7*/
   /*~+:Beschreibung*/
   /*~T*/
   /*!
   \fn unsigned char ADuC836_DACGetLimitStatus(unsigned char byWhichLimit)
   
   <b>Beschreibung:</b><br>
   Ausgabe des Status der Grenzwert�berwachung.
   
   \param
   byWhichLimit: Angabe zu dem Grenzwert, von welchem das Datum ausgegeben werden soll. (0 = unterer Grenzwert, 1 = oberer Grenzwert, anderer Wert = bitcodierte Angabe zu beiden Grenzwerten)
   
   \return
   Status der Grenzwert�berwachung
   
   \retval
   0 = Grenzwert wird nicht untersucht.
   
   \retval
   1 = Grenzwertuntersuchung eingeschaltet.
   
   \retval
   Bei bitcodierter Ausgabe: Bit 0 gesetzt = unterer Grenzwert wird untersucht.
   \retval
   Bit 4 gesetzt = oberer Grenzwert wird untersucht.
   
   <b>Zugriff:</b><br>
   [X] �ffentlich / [ ] Privat
   
   \ref
   ExamplePage_ADuC836Driver "Beispiel 'ADuC836-Treiber'"
   */

   /*~E:A7*/
   /*~C:8*/
   switch (byWhichLimit)
   /*~-1*/
   {
      /*~F:9*/
      case ADUC836_DAC_LOWER_LIMIT:
      /*~I:10*/
      if (g_DAC.Settings.Limits.byLimitSet & 0x01)
      /*~-1*/
      {
         /*~T*/
         return 1;
      /*~-1*/
      }
      /*~O:I10*/
      /*~-2*/
      else
      {
         /*~T*/
         return 0;
      /*~-1*/
      }
      /*~E:I10*/
      /*~E:F9*/
      /*~F:11*/
      case ADUC836_DAC_UPPER_LIMIT:
      /*~I:12*/
      if (g_DAC.Settings.Limits.byLimitSet & 0x10)
      /*~-1*/
      {
         /*~T*/
         return 1;
      /*~-1*/
      }
      /*~O:I12*/
      /*~-2*/
      else
      {
         /*~T*/
         return 0;
      /*~-1*/
      }
      /*~E:I12*/
      /*~E:F11*/
      /*~O:C8*/
      /*~-2*/
      default:
      {
         /*~T*/
         return g_DAC.Settings.Limits.byLimitSet;
      /*~-1*/
      }
   /*~-1*/
   }
   /*~E:C8*/
/*~-1*/
}
/*~E:F6*/
/*~E:A5*/
