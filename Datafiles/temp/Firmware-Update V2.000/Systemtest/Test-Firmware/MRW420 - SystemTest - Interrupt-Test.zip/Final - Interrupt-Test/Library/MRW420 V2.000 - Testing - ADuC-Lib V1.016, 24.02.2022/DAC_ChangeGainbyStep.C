/*~-1*/
/*~XSF_LANGUAGE: C/C++*/
/*~T*/
/*

   (1) MODULNAME             :  DAC_ChangeGainbyStep.c
   (2) VERSION               :  1.00
   (3) DATUM                 :  

   (4) LETZTE �NDERUNG       :  
   (5) PROJEKT (Vers.)       :  MRW Limit
   (6) PROGRAMMIERER         :  MOF

*/
/*~A:1*/
/*~+:Includes*/
/*~T*/
#include "DAC_Global.h"
#include "string.h"
/*~E:A1*/
/*~A:2*/
/*~+:Defines */
/*~T*/

/*~E:A2*/
/*~A:3*/
/*~+:Funktionsprototypen*/
/*~T*/
float ADuC836_DACChangeGainbyStep(float fPercent);
/*~E:A3*/
/*~A:4*/
/*~+:Globale Variablen*/
/*~T*/

/*~E:A4*/
/*~A:5*/
/*~+:float ADuC836_DACChangeGainbyStep(float fPercent)*/
/*~F:6*/
float ADuC836_DACChangeGainbyStep(float fPercent)

/*~-1*/
{
   /*~A:7*/
   /*~+:Beschreibung*/
   /*~T*/
   /*!
   \fn float ADuC836_DACChangeGainbyStep(float fPercent)
   
   <b>Beschreibung:</b><br>
   Ver�ndern des Verst�rkungsfaktors um einen bestimmten Wert.
   
   \param
   fPercent: Faktor in Prozent, um die der Verst�rkungsfaktor ver�ndert werden soll.
   
   \return
   Neuer Verst�rkungsfaktor.
   
   <b>Zugriff:</b><br>
   [X] �ffentlich / [ ] Privat
   
   \ref
   ExamplePage_ADuC836Driver "Beispiel 'ADuC836-Treiber'"
   */
   /*~E:A7*/
   /*~T*/
   fPercent = 1+(fPercent/100);
   /*~T*/
   g_DAC.Settings.fGain_Norm *= fPercent;

   return(g_DAC.Settings.fGain_RMV *= fPercent);
/*~-1*/
}
/*~E:F6*/
/*~E:A5*/
