/*~-1*/
/*~XSF_LANGUAGE: C/C++*/
/*~T*/
/*

   (1) MODULNAME             :  DAC_IsOutputCleared.c
   (2) VERSION               :  1.00
   (3) DATUM                 :  14.12.2007

   (4) LETZTE �NDERUNG       :  
   (5) PROJEKT (Vers.)       :  ADuC836-Treiberbibliotheke
   (6) PROGRAMMIERER         :  MOF

*/
/*~A:1*/
/*~+:Includes*/
/*~T*/
#include "DAC_Global.h"
#include "string.h"
/*~E:A1*/
/*~A:2*/
/*~+:Defines */
/*~T*/

/*~E:A2*/
/*~A:3*/
/*~+:Funktionsprototypen*/
/*~T*/
unsigned char ADuC836_DACIsOutputCleared(void);
/*~E:A3*/
/*~A:4*/
/*~+:Globale Variablen*/
/*~T*/

/*~E:A4*/
/*~A:5*/
/*~+:unsigned char ADuC836_DACIsOutputCleared(void)*/
/*~F:6*/
unsigned char ADuC836_DACIsOutputCleared(void)
/*~-1*/
{
   /*~A:7*/
   /*~+:Beschreibung*/
   /*~T*/
   /*!
   \fn unsigned char ADuC836_DACIsOutputCleared(void)
   
   <b>Beschreibung:</b><br>
   Diese Funktion gibt Auskunft dar�ber, ob der Ausgang des DACs gesperrt/zur�ckgesetzt ist.
   
   \param
   ./.
   
   \return
   Status des DAC-Ausgangs;
   
   \retval
   0: DAC im normalen Betriebsmodus.
   \retval
   1: DAC-Ausgang ist zur�ckgesetzt - die DAC-Daten-Register DACL und DACH beinhalten eine 0. 
   
   <b>Zugriff:</b><br>
   [X] �ffentlich / [ ] Privat
   
   \ref
   ExamplePage_ADuC836Driver "Beispiel 'ADuC836-Treiber'"
   */

   /*~E:A7*/
   /*~I:8*/
   if (DACCON & 0x02)
   /*~-1*/
   {
      /*~T*/
      return 0;
   /*~-1*/
   }
   /*~O:I8*/
   /*~-2*/
   else
   {
      /*~T*/
      return 1;
   /*~-1*/
   }
   /*~E:I8*/
/*~-1*/
}
/*~E:F6*/
/*~E:A5*/
