/*~-1*/
/*~XSF_LANGUAGE: C/C++*/
/*~T*/
/*

   (1) MODULNAME             :  Flash_DataSetPage.c
   (2) VERSION               :  1.00
   (3) DATUM                 :  17.06.2003

   (4) LETZTE �NDERUNG       :  17.05.2005
   (5) PROJEKT (Vers.)       :  
   (6) PROGRAMMIERER         :  n.l./MOF

*/


/*~A:1*/
/*~+:Includes*/
/*~T*/
#include "ADuC836Driver.h"
/*~E:A1*/
/*~A:2*/
/*~+:Moduleigene Definitionen */
/*~T*/

/*~E:A2*/
/*~A:3*/
/*~+:Funktionsprototypen*/
/*~T*/
char ADuC836_FlashDataSetPage(int nPageNr);
/*~E:A3*/
/*~A:4*/
/*~+:Modulvariablen*/
/*~T*/

/*~E:A4*/
/*~A:5*/
/*~+:char ADuC836_FlashDataSetPage(int nPageNr)*/
/*~F:6*/
char ADuC836_FlashDataSetPage(int nPageNr)
/*~-1*/
{
   /*~A:7*/
   /*~+:Beschreibung*/
   /*~T*/
   /*
   Setze den Pagepointer auf die angegebene Nummer (1....1023)
   
   R�ckgabe:
   - 0 Funktion konnte erfolgreich durchgef�hrt werden
   -1 Pagenummer ung�ltig
   -2 Allgemeiner Fehler 
   */
   /*~E:A7*/
   /*~A:8*/
   /*~+:Variablendeklarationen*/
   /*~T*/
   signed char cErgebnis = 0;
   /*~E:A8*/
   /*~A:9*/
   /*~+:Variableninitialisierungen*/
   /*~T*/

   /*~E:A9*/
   /*~I:10*/
   if (nPageNr <= MAX_FLASH_PAGE)
   /*~-1*/
   {
      /*~T*/
      EADRH = (char)(nPageNr >> 8);
      EADRL = (char)nPageNr;
   /*~-1*/
   }
   /*~O:I10*/
   /*~-2*/
   else
   {
      /*~T*/
      cErgebnis = -1;
   /*~-1*/
   }
   /*~E:I10*/
   /*~T*/
   return (cErgebnis);
/*~-1*/
}
/*~E:F6*/
/*~E:A5*/
