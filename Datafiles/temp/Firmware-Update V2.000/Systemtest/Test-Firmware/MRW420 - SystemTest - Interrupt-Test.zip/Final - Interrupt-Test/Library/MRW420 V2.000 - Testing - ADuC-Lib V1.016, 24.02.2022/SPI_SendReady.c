/*~-1*/
/*~XSF_LANGUAGE: C/C++*/
/*~K*/
/*~+:File :        SPI_SendReady.c*/
/*~+:*/
/*~+:Version :     V1.0*/
/*~+:*/
/*~+:Date :        14.06.2005*/
/*~+:*/
/*~+:Time :        10:23*/
/*~+:*/
/*~+:Author :      MOF*/
/*~+:*/
/*~+:Hardware :*/
/*~+:*/
/*~+:Description :*/
/*~A:1*/
/*~+:Includes*/
/*~T*/
#include "ADuC836Driver.h"
#include "SPI_Global.h"
/*~E:A1*/
/*~A:2*/
/*~+:Funktionseigene Definitionen*/
/*~T*/
#
/*~E:A2*/
/*~A:3*/
/*~+:Funktionseigene Struktur-Definitionen*/
/*~T*/

/*~E:A3*/
/*~A:4*/
/*~+:Funktionsprototypen*/
/*~T*/
void ADuC836_SPISendReady(void);
/*~E:A4*/
/*~A:5*/
/*~+:Globale Variablen*/
/*~T*/

/*~E:A5*/
/*~A:6*/
/*~+:void ADuC836_SPISendReady(void)*/
/*~F:7*/
void ADuC836_SPISendReady(void)
/*~-1*/
{
   /*~A:8*/
   /*~+:Variablendeklarationen*/
   /*~T*/
   char ch;
   /*~E:A8*/
   /*~A:9*/
   /*~+:Variableninitialisierungen*/
   /*~T*/
   ch = 0;
   /*~E:A9*/
   /*~A:10*/
   /*~+:Schnittstelle neu initialisieren*/
   /*~T*/
   SPE = 0;
   SPE = 1;
   /*~E:A10*/
   /*~T*/
   // Vorbereitung zur Ausl�sung des Interrupts
   ADUC836_SPI_HANDSHAKE_LINE = 1;
   /*~L:11*/
   while (ch < 5)
   /*~-1*/
   {
      /*~T*/
      ch++;
   /*~-1*/
   }
   /*~E:L11*/
   /*~T*/
   // Ausl�sung des Interrupts
   ADUC836_SPI_HANDSHAKE_LINE = 0;
/*~-1*/
}
/*~E:F7*/
/*~E:A6*/
