/*~-1*/
/*~XSF_LANGUAGE: C/C++*/
/*~T*/
/*

   (1) MODULNAME             :  DAC_IsLimit.c
   (2) VERSION               :  1.00
   (3) DATUM                 :  

   (4) LETZTE �NDERUNG       :  
   (5) PROJEKT (Vers.)       :  MRW Limit
   (6) PROGRAMMIERER         :  MOF

*/
/*~A:1*/
/*~+:Includes*/
/*~T*/
#include "DAC_Global.h"
#include "string.h"
/*~E:A1*/
/*~A:2*/
/*~+:Defines */
/*~T*/

/*~E:A2*/
/*~A:3*/
/*~+:Funktionsprototypen*/
/*~T*/
unsigned char ADuC836_DACIsLimit(unsigned char byWhichLimit);
/*~E:A3*/
/*~A:4*/
/*~+:Globale Variablen*/
/*~T*/

/*~E:A4*/
/*~A:5*/
/*~+:unsigned char ADuC836_DACIsLimit(unsigned char byWhichLimit)*/
/*~F:6*/
unsigned char ADuC836_DACIsLimit(unsigned char byWhichLimit)
/*~-1*/
{
   /*~A:7*/
   /*~+:Beschreibung*/
   /*~T*/
   /*!
   \fn unsigned char ADuC836_DACIsLimit(unsigned char byWhichLimit)
   
   <b>Beschreibung:</b><br>
   Diese Funktion gibt auskunft dar�ber, ob ein Grenzwert erreicht wurde.
   
   \param
   byWhichLimit: Kennzeichner des zu untersuchenden Grenzwertes
   
   \return
   Status der Grenzwertuntersuchung;
   
   \retval
   0: Grenzwert wurde nicht erreicht.
   \retval
   1: Grenzwert wurde erreicht pder �berschritten
   \retval
   andere Werte: Bei der Abfrage �ber alle Grenzwerte, wird der Merker zur Speicherung aller Grenzwertstatus zur�ckgeliefert. Dies bedeutet: Bit 0 f�r unteren Grenzwert, Bit 4 f�r oberen Grenzwert.
   
   <b>Zugriff:</b><br>
   [X] �ffentlich / [ ] Privat
   
   \ref
   ExamplePage_ADuC836Driver "Beispiel 'ADuC836-Treiber'"
   */

   /*~E:A7*/
   /*~C:8*/
   switch (byWhichLimit)
   /*~-1*/
   {
      /*~F:9*/
      case ADUC836_DAC_LOWER_LIMIT:
      /*~I:10*/
      if (g_DAC.Results.byLimitReached & 0x01)
      /*~-1*/
      {
         /*~T*/
         return 1;
      /*~-1*/
      }
      /*~O:I10*/
      /*~-2*/
      else
      {
         /*~T*/
         return 0;
      /*~-1*/
      }
      /*~E:I10*/
      /*~E:F9*/
      /*~F:11*/
      case ADUC836_DAC_UPPER_LIMIT:
      /*~I:12*/
      if (g_DAC.Results.byLimitReached & 0x10)
      /*~-1*/
      {
         /*~T*/
         return 1;
      /*~-1*/
      }
      /*~O:I12*/
      /*~-2*/
      else
      {
         /*~T*/
         return 0;
      /*~-1*/
      }
      /*~E:I12*/
      /*~E:F11*/
      /*~O:C8*/
      /*~-2*/
      default:
      {
         /*~T*/
         return g_DAC.Results.byLimitReached;
      /*~-1*/
      }
   /*~-1*/
   }
   /*~E:C8*/
/*~-1*/
}
/*~E:F6*/
/*~E:A5*/
