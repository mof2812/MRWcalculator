/*~-1*/
/*~XSF_LANGUAGE: C/C++*/
/*~T*/
/*

   (1) MODULNAME             :  ADC_IsNewConversionValue.c
   (2) VERSION               :  1.00
   (3) DATUM                 :  

   (4) LETZTE �NDERUNG       :  
   (5) PROJEKT (Vers.)       :  MRW Limit
   (6) PROGRAMMIERER         :  MOF

*/
/*~A:1*/
/*~+:Includes*/
/*~T*/
#include "ADC_Global.h"
/*~E:A1*/
/*~A:2*/
/*~+:Defines */
/*~T*/

/*~E:A2*/
/*~A:3*/
/*~+:Funktionsprototypen*/
/*~T*/
unsigned char ADuC836_ADCIsNewConversionValue(unsigned char byADC_Chanel);
/*~E:A3*/
/*~A:4*/
/*~+:Modulvariablen*/
/*~T*/

/*~E:A4*/
/*~A:5*/
/*~+:unsigned char ADuC836_ADCIsNewConversionValue(unsigned char byADC_Chanel)*/
/*~F:6*/
unsigned char ADuC836_ADCIsNewConversionValue(unsigned char byADC_Chanel)
/*~-1*/
{
   /*~A:7*/
   /*~+:Beschreibung*/
   /*~T*/
   /*!
   \fn unsigned char ADuC836_ADCIsNewConversionValue(unsigned char byADC_Chanel)
   
   <b>Beschreibung:</b><br>
   Liefert als Ergebnis, ob ein neuer gewandelter Wert vorliegt.
    
   \param
   byADC_Chanel: Kanal, der auf einen neuen gewandelten Wert �berpr�ft werden soll. 
   
   \return
   Status der �berpr�fung.
   
   \retval
   0: Es gibt keinen neuen gewandelten Wert.
   \retval
   1: Es gibt einen neuen gewandelten Wert.
   
   <b>Zugriff:</b><br>
   [X] �ffentlich / [ ] Privat
   
   \ref
   ExamplePage_ADuC836Driver "Beispiel 'ADuC836-Treiber'"
   */

   /*~E:A7*/
   /*~T*/
   return g_ADC.Results[byADC_Chanel].byNewConversionValueFlag;
/*~-1*/
}
/*~E:F6*/
/*~E:A5*/
