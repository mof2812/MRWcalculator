/*~-1*/
/*~XSF_LANGUAGE: C/C++*/
/*~T*/
/*

   (1) MODULNAME             :  ADC_SetMeasurementDepth.c
   (2) VERSION               :  1.00
   (3) DATUM                 :  

   (4) LETZTE �NDERUNG       :  
   (5) PROJEKT (Vers.)       :  MRW Limit
   (6) PROGRAMMIERER         :  MOF

*/
/*~A:1*/
/*~+:Includes*/
/*~T*/
#include "ADC_Global.h"
/*~E:A1*/
/*~A:2*/
/*~+:Defines */
/*~T*/

/*~E:A2*/
/*~A:3*/
/*~+:Funktionsprototypen*/
/*~T*/
unsigned char ADuC836_ADCSetMeasurementDepth(unsigned char byADC_Chanel, unsigned char byMeasurementDepth);
/*~E:A3*/
/*~A:4*/
/*~+:Modulvariablen*/
/*~T*/

/*~E:A4*/
/*~A:5*/
/*~+:unsigned char ADuC836_ADCSetMeasurementDepth(unsigned char byADC_Chanel, unsigned char byMeasurementDepth)*/
/*~F:6*/
unsigned char ADuC836_ADCSetMeasurementDepth(unsigned char byADC_Chanel, unsigned char byMeasurementDepth)
/*~-1*/
{
   /*~A:7*/
   /*~+:Beschreibung*/
   /*~T*/
   /*!
   \fn unsigned char ADuC836_ADCSetMeasurementDepth(unsigned char byADC_Chanel, unsigned char byMeasurementDepth)
   
   <b>Beschreibung:</b><br>
   Setzen einer Messwerttiefe. Diese gibt an, �ber wieviele Wandelergebnisse eine Summe gebildet werden soll, welche dann das Ergebnis representiert.
    
   \param
   byADC_Chanel: Kanal, f�r welchen die Messwerttiefe gesetzt werden soll.
   
   \param
   byMeasurementDepth: Zu setzende Messwerttiefe.
   
   \return
   Status der Funktionsausf�hrung.
   
   \retval
   0: Alles okay.
   \retval
   1: Angegebener Kanal existiert nicht.
   
   <b>Zugriff:</b><br>
   [X] �ffentlich / [ ] Privat
   
   \ref
   ExamplePage_ADuC836Driver "Beispiel 'ADuC836-Treiber'"
   */
   /*~E:A7*/
   /*~I:8*/
   if ((byADC_Chanel < ADC_MAX_CHANELS) && (byMeasurementDepth))
   /*~-1*/
   {
      /*~T*/
      g_ADC.byMeasurementCounter[byADC_Chanel] = 0;
      g_ADC.Settings[byADC_Chanel].byMeasurementDepth = byMeasurementDepth;
      /*~T*/
      return 0;
   /*~-1*/
   }
   /*~O:I8*/
   /*~-2*/
   else
   {
      /*~T*/
      return 1;
   /*~-1*/
   }
   /*~E:I8*/
/*~-1*/
}
/*~E:F6*/
/*~E:A5*/
