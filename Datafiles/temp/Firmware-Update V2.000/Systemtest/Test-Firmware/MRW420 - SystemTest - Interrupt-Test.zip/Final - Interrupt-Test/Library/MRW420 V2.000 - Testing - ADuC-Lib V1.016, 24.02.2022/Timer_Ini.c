/*~-1*/
/*~XSF_LANGUAGE: C/C++*/
/*~K*/
/*~+:File :        Timer_Ini.c*/
/*~+:*/
/*~+:Version :     V1.000*/
/*~+:*/
/*~+:Date :        03.06.2005*/
/*~+:*/
/*~+:Time :        */
/*~+:*/
/*~+:Author :      MOF*/
/*~+:*/
/*~+:Hardware :*/
/*~+:*/
/*~+:Description :*/
/*~A:1*/
/*~+:Includes*/
/*~T*/
#include "ADuC836Driver.h"
#include <String.h>
/*~E:A1*/
/*~A:2*/
/*~+:Funktionseigene Definitionen*/
/*~T*/

/*~E:A2*/
/*~A:3*/
/*~+:Funktionseigene Struktur-Definitionen*/
/*~T*/

/*~E:A3*/
/*~A:4*/
/*~+:Funktionsprototypen*/
/*~T*/
void ADuC836_TimerIni(unsigned char chTimerInterfaceOnOff,char byHighPriority);
/*~E:A4*/
/*~A:5*/
/*~+:Globale Variablen*/
/*~T*/
extern TIMER Timer;
/*~E:A5*/
/*~A:6*/
/*~+:void ADuC836_TimerIni(unsigned char chTimerInterfaceOnOff,char byPriority)*/
/*~F:7*/
void ADuC836_TimerIni(unsigned char chTimerInterfaceOnOff,char byHighPriority)
/*~-1*/
{
   /*~A:8*/
   /*~+:Beschreibung*/
   /*~T*/
   /*!
   \fn void ADuC836_TimerIni(unsigned char chTimerInterfaceOnOff)
   
   <b>Beschreibung:</b><br>
   Initialisierungsroutine der Timer.
   
   \param
   chNbTimers: Anzahl der zu verwaltenden Timer.
   
   \param
   chTimerInterfaceOnOff: entscheidet dar�ber, ob die Timer-Interface-Funktion aufgerufen wird.
   
   \param
   byHighPriority: 0 = niedrige Priorit�t , 1 = hohe Priorit�t
   
   \return
   ./.
   
   <b>Zugriff:</b><br>
   [X] �ffentlich / [ ] Privat
   
   \ref
   ExamplePage_ADuC836Driver "Beispiel 'ADuC836-Treiber'"
   */

   /*~E:A8*/
   /*~T*/
   TMOD = 0x01;  // M0 = 0  M1 = 1 (16-Bit Timer)

   /*~I:9*/
#ifdef TIMER_TIMEBASE_10MS
   /*~T*/
   TL0 = 0x0B;
   TH0 = 0xD7;	// Atomzeit = 10msec
   /*~O:I9*/
   /*~-1*/
#else
   /*~I:10*/
#ifdef TIMER_TIMEBASE_1MS
   /*~T*/
   TL0 = 0x18;
   TH0 = 0xFC; // Atomzeit = 1ms
   /*~-1*/
#endif
   /*~E:I10*/
   /*~-1*/
#endif
   /*~E:I9*/
   /*~I:11*/
   if (byHighPriority)
   /*~-1*/
   {
      /*~T*/
      PT0 = 1;
   /*~-1*/
   }
   /*~O:I11*/
   /*~-2*/
   else
   {
      /*~T*/
      PT0 = 0;
   /*~-1*/
   }
   /*~E:I11*/
   /*~T*/
   ET0 = 1;      // Gebe Interrupt frei
   TR0= 1;       // Starte Timer 0

   EA = 1;

   // Timer-Struktur zun�chst l�schen
   memset(&Timer,0,sizeof(TIMER));

   Timer.chTimerInterfaceOnOff = chTimerInterfaceOnOff;

/*~-1*/
}
/*~E:F7*/
/*~E:A6*/
