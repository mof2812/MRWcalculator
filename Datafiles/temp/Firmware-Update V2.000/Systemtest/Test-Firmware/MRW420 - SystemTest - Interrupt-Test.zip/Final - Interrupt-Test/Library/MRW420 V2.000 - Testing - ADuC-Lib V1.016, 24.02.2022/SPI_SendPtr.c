/*~-1*/
/*~XSF_LANGUAGE: C/C++*/
/*~K*/
/*~+:File :        SPI_SendPtr.c*/
/*~+:*/
/*~+:Version :     V1.0*/
/*~+:*/
/*~+:Date :        14.06.2005*/
/*~+:*/
/*~+:Time :        10:23*/
/*~+:*/
/*~+:Author :      MOF*/
/*~+:*/
/*~+:Hardware :*/
/*~+:*/
/*~+:Description :*/
/*~T*/
// #define MIT_WIEDERHOLUNG
/*~A:1*/
/*~+:Includes*/
/*~T*/
#include "ADuC836Driver.h"
#include "SPI_Global.h"
#include "stdio.h"
#include "string.h"
/*~E:A1*/
/*~A:2*/
/*~+:Funktionseigene Definitionen*/
/*~T*/
#
/*~E:A2*/
/*~A:3*/
/*~+:Funktionseigene Struktur-Definitionen*/
/*~T*/

/*~E:A3*/
/*~A:4*/
/*~+:Funktionsprototypen*/
/*~T*/
char ADuC836_SPISendPtr(unsigned char* pchData,unsigned int nNbChars);
/*~E:A4*/
/*~A:5*/
/*~+:Globale Variablen*/
/*~T*/

/*~E:A5*/
/*~A:6*/
/*~+:char ADuC836_SPISendPtr(unsigned char* pchData,unsigned int nNbChars)*/
/*~F:7*/
char ADuC836_SPISendPtr(unsigned char* pchData,unsigned int nNbChars)
/*~-1*/
{
   /*~A:8*/
   /*~+:Beschreibung*/
   /*~T*/
   /*!
   \fn char ADuC836_SPISendPtr(unsigned char* pchData,unsigned int nNbChars)
   
   <b>Beschreibung:</b><br>
   Sendet eine beliebige Anzahl (bis 65535) Zeichen �ber die SPI-Schnittstelle.
   
   \param
   pchData: Pointer auf die zu sendenden Zeichen.
   
   \param
   nNbChars: Anzahl der zu sendenden Zeichen. Wird dieser Parameter auf 0 gesetzt, werden alle Daten bis zu einem Nullzeichen �bertragen.
   
   \return
   Status der Funktionsausf�hrung.
   
   \retval
   0 : Alles okay.
   \retval
   1 : Timeout
   
   <b>Zugriff:</b><br>
   [X] �ffentlich / [ ] Privat
   
   \ref
   ExamplePage_ADuC836Driver "Beispiel 'ADuC836-Treiber'"
   */

   /*~E:A8*/
   /*~A:9*/
   /*~+:Variablendeklarationen*/
   /*~T*/
   char byRetVal;
   unsigned int i;

   /*~I:10*/
#ifdef ADUC836_SPI_GLOBALS_SEND_WITH_BYTEPAUSE
   /*~T*/
   unsigned int j;
   /*~-1*/
#endif
   /*~E:I10*/
   /*~E:A9*/
   /*~A:11*/
   /*~+:Variableninitialisierungen*/
   /*~T*/
   byRetVal = 0;
   /*~E:A11*/
   /*~I:12*/
   if (!nNbChars)
   /*~-1*/
   {
      /*~T*/
      nNbChars = strlen(pchData);
   /*~-1*/
   }
   /*~E:I12*/
   /*~A:13*/
   /*~+:FOR_DEBUGGING_ONLY*/
   /*~I:14*/
#ifdef SPI_SLAVE
   /*~I:15*/
#ifdef SPI_DEBUG_SLAVE_COMMUNICATION
   /*~I:16*/
   if (nNbChars <= 0)
   /*~-1*/
   {
      /*~T*/
      strcat(RS232.pchTransBuffer,"(S)>Nc");
      /*~T*/
      TI = 1;
   /*~-1*/
   }
   /*~E:I16*/
   /*~-1*/
#endif
   /*~E:I15*/
   /*~O:I14*/
   /*~-1*/
#else
   /*~I:17*/
#ifdef SPI_DEBUG_MASTER_COMMUNICATION
   /*~I:18*/
   if (nNbChars <= 0)
   /*~-1*/
   {
      /*~T*/
      strcat(RS232.pchTransBuffer,"(M)>Nc");
      /*~T*/
      TI = 1;
   /*~-1*/
   }
   /*~E:I18*/
   /*~-1*/
#endif
   /*~E:I17*/
   /*~-1*/
#endif
   /*~E:I14*/
   /*~E:A13*/
   /*~T*/
   // Vorbereitungen f�r den anschlie�enden Empfang treffen
   ADuC836_SPIReleaseReception();
   /*~T*/
   ADuC836_SPISwitch2Mode(ADUC836_SPI_MASTER_MODE);
   /*~L:19*/
   for (i=0;(i<nNbChars)&&(!byRetVal);i++)
   /*~-1*/
   {
      /*~T*/
      byRetVal = ADuC836_SPISendChar(*(pchData + i));
      /*~I:20*/
#ifdef ADUC836_SPI_GLOBALS_SEND_WITH_BYTEPAUSE
      /*~T*/
      /* Pausendauer ist ungef�hr: 3 + (ADUC836_SPI_GLOBALS_BYTEPAUSE * 10) us */
      /* In der jetzigen Konfiguration macht das 203us */
      /*~T*/
      j = 0;
      /*~U:21*/
      /*~-2*/
      do
      {
         /*~T*/
         j++;
      /*~-1*/
      }
      /*~O:U21*/
      while (j < ADUC836_SPI_GLOBALS_BYTEPAUSE);
      /*~E:U21*/
      /*~-1*/
#endif
      /*~E:I20*/
   /*~-1*/
   }
   /*~E:L19*/
   /*~T*/
   ADuC836_SPISwitch2Mode(ADUC836_SPI_SLAVE_MODE);
   /*~T*/
   return byRetVal;
/*~-1*/
}
/*~E:F7*/
/*~E:A6*/
