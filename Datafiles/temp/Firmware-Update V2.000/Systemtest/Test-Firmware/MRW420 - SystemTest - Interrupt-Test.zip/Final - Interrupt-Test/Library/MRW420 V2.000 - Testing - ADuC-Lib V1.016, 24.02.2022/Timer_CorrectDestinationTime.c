/*~-1*/
/*~XSF_LANGUAGE: C/C++*/
/*~K*/
/*~+:File :        Timer_CorrectDestinationTime.c*/
/*~+:*/
/*~+:Version :     V1.000*/
/*~+:*/
/*~+:Date :        03.06.2005*/
/*~+:*/
/*~+:Time :        */
/*~+:*/
/*~+:Author :      MOF*/
/*~+:*/
/*~+:Hardware :*/
/*~+:*/
/*~+:Description :*/
/*~A:1*/
/*~+:Includes*/
/*~T*/
#include "ADuC836Driver.h"

/*~E:A1*/
/*~A:2*/
/*~+:Funktionseigene Definitionen*/
/*~T*/

/*~E:A2*/
/*~A:3*/
/*~+:Funktionseigene Struktur-Definitionen*/
/*~T*/

/*~E:A3*/
/*~A:4*/
/*~+:Funktionsprototypen*/
/*~T*/
char ADuC836_TimerCorrectDestinationTime(unsigned char chWhichTimer,long lCorrectionValue);
/*~E:A4*/
/*~A:5*/
/*~+:Globale Variablen*/
/*~T*/
extern TIMER Timer;
/*~E:A5*/
/*~A:6*/
/*~+:char ADuC836_TimerCorrectDestinationTime(unsigned char chWhichTimer,long lCorrectionValue)*/
/*~F:7*/
char ADuC836_TimerCorrectDestinationTime(unsigned char chWhichTimer,long lCorrectionValue)
/*~-1*/
{
   /*~K*/
   /*~+:// Korrigiert die aktuelle Timer-Zielzeit um einen �bergebenen Wert*/
   /*~I:8*/
   if (chWhichTimer < TIMER_NB_TIMERS)
   /*~-1*/
   {
      /*~T*/
      Timer.ulDestinationTime[chWhichTimer] -= lCorrectionValue;
   /*~-1*/
   }
   /*~O:I8*/
   /*~-2*/
   else
   {
      /*~I:9*/
      if (chWhichTimer == 0xFF)
      /*~-1*/
      {
         /*~K*/
         /*~+:// alle Timer*/
         /*~L:10*/
         for (chWhichTimer = 0;chWhichTimer < TIMER_NB_TIMERS;chWhichTimer++)
         /*~-1*/
         {
            /*~T*/
            Timer.ulDestinationTime[chWhichTimer] -= lCorrectionValue;
         /*~-1*/
         }
         /*~E:L10*/
      /*~-1*/
      }
      /*~O:I9*/
      /*~-2*/
      else
      {
         /*~T*/
         // Timer existiert nicht
         return 1;
      /*~-1*/
      }
      /*~E:I9*/
   /*~-1*/
   }
   /*~E:I8*/
   /*~T*/
   return 0;
/*~-1*/
}
/*~E:F7*/
/*~E:A6*/
