/*~-1*/
/*~XSF_LANGUAGE: C/C++*/
/*~K*/
/*~+:File :        SPI_Interrupt.c*/
/*~+:*/
/*~+:Version :     V1.005*/
/*~+:*/
/*~+:Date :        09.02.2022*/
/*~+:*/
/*~+:Time :        10:23*/
/*~+:*/
/*~+:Author :      MOF*/
/*~+:*/
/*~+:Hardware :*/
/*~+:*/
/*~+:Description :*/
/*~A:1*/
/*~+:Includes*/
/*~T*/
#include "ADuC836Driver.h"
#include "SPI_Global.h"
#include "string.h"
/*~E:A1*/
/*~A:2*/
/*~+:Funktionseigene Definitionen*/
/*~T*/

/*~E:A2*/
/*~A:3*/
/*~+:Funktionseigene Struktur-Definitionen*/
/*~T*/

/*~E:A3*/
/*~A:4*/
/*~+:Funktionsprototypen*/
/*~T*/

/*~E:A4*/
/*~A:5*/
/*~+:Globale Variablen*/
/*~T*/

/*~E:A5*/
/*~A:6*/
/*~+:void ADuC836_SPIInterrupt() interrupt 7 using 2*/
/*~F:7*/
void ADuC836_SPIInterrupt() interrupt 7  // using 2
/*~-1*/
{
   /*~A:8*/
   /*~+:Beschreibung*/
   /*~T*/
   /*!
   \fn void ADuC836_SPIInterrupt() interrupt 7
   
   <b>Beschreibung:</b><br>
   Interruptroutine zum Empfang der Master-Daten �ber die SPI-Schnittstelle. Gleichzeitig werden im Falle eines Datentransfers zum Master, die Daten ausgegeben.
   Alle eingehenden Daten werden analog der RS232-Schnittstelle an die externe Funktion 'Communication_Receive()' weitergegeben.
   
   \return
   ./.
   
   <b>Zugriff:</b><br>
   [X] �ffentlich / [ ] Privat
   
   \ref
   ExamplePage_ADuC836Driver "Beispiel 'ADuC836-Treiber'"
   */

   /*~E:A8*/
   /*~A:9*/
   /*~+:Variablendeklarationen*/
   /*~T*/
   unsigned char 			chSPIData;
   /*~I:10*/
#ifdef DEVELOPMENT_SW
   /*~I:11*/
#ifdef DEVELOPMENT_SW_TEST_IRQS
   /*~T*/
   static unsigned char chDataBehindBuffer;
   /*~-1*/
#endif
   /*~E:I11*/
   /*~-1*/
#endif
   /*~E:I10*/
   /*~E:A9*/
   /*~A:12*/
   /*~+:Variableninitialisierungen*/
   /*~T*/

   /*~E:A12*/
   /*~T*/
   chSPIData = SPIDAT;
   /*~I:13*/
   if (!SPI.chNewCommandReceived)
   /*~-1*/
   {
      /*~I:14*/
      if (chSPIData == 0x02)	// STX
      /*~-1*/
      {
         /*~T*/
         /* STX empfangen */
         SPI.pchRecBufferIndex = SPI.pchRecBuffer;
         /*~I:15*/
#ifdef DEVELOPMENT_SW
         /*~I:16*/
#ifdef DEVELOPMENT_SW_TEST_IRQS
         /*~T*/
         /* Kennung an die letzte Stelle im Empfangspuffer schreiben */
         *(SPI.pchRecBuffer + SPI.chBufferSize - 1) = 0xAA;
         /*~-1*/
#endif
         /*~E:I16*/
         /*~-1*/
#endif
         /*~E:I15*/
      /*~-1*/
      }
      /*~O:I14*/
      /*~-2*/
      else
      {
         /*~I:17*/
         if (SPI.pchRecBufferIndex != 0)
         /*~-1*/
         {
            /*~I:18*/
            /* STX bereits empfangen - bereit f�r die n�chsten Zeichen */
            if (chSPIData == 0x03)	// ETX
            /*~-1*/
            {
               /*~T*/
               /* ETX bereits empfangen - Empfangsstring abschlie�en und den Empfangsindex auf 0 setzen */

               *(SPI.pchRecBufferIndex) =
               0;

               SPI.pchRecBufferIndex = 0;

               /* Flag f�r empfangenen Befehlsstring setzen */
               SPI.chNewCommandReceived = 1;

            /*~-1*/
            }
            /*~O:I18*/
            /*~-2*/
            else
            {
               /*~I:19*/
               if (SPI.pchRecBufferIndex - SPI.pchRecBuffer < SPI.chBufferSize - 1)
               /*~-1*/
               {
                  /*~T*/
                  /* Ausreichend Speicher vorhanden - Daten im Speicher eintragen und Index inkrementieren */

                  *(SPI.pchRecBufferIndex++) = chSPIData;

               /*~-1*/
               }
               /*~O:I19*/
               /*~-2*/
               else
               {
                  /*~T*/
                  /* Speicher voll - Empfangsindex auf 0 setzen - jetzt muss es wieder mit STX losgehen */

                  SPI.pchRecBufferIndex = 0;

               /*~-1*/
               }
               /*~E:I19*/
            /*~-1*/
            }
            /*~E:I18*/
         /*~-1*/
         }
         /*~E:I17*/
         /*~I:20*/
#ifdef DEVELOPMENT_SW
         /*~I:21*/
#ifdef DEVELOPMENT_SW_TEST_IRQS
         /*~I:22*/
         //         if ((chSPIData == 0x03)&&(*(SPI.pchRecBuffer) >= 0x30)&&(*(SPI.pchRecBuffer) <= 0x4F))
         if ((chSPIData == 0x03)&&(*(SPI.pchRecBuffer - 1) == 0x55))
         /*~-1*/
         {
            /*~T*/
            chDataBehindBuffer = *(SPI.pchRecBuffer + SPI.chBufferSize);
         /*~-1*/
         }
         /*~E:I22*/
         /*~-1*/
#endif
         /*~E:I21*/
         /*~-1*/
#endif
         /*~E:I20*/
      /*~-1*/
      }
      /*~E:I14*/
   /*~-1*/
   }
   /*~E:I13*/
/*~-1*/
}
/*~E:F7*/
/*~E:A6*/
