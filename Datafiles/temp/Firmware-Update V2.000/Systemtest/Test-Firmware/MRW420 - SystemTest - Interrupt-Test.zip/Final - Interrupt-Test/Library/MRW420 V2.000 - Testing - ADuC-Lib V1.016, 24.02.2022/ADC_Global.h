/*~-1*/
/*~XSF_LANGUAGE: C/C++*/
/*~K*/
/*~+:File :        ADC_Global.h*/
/*~+:*/
/*~+:Version :     V1.000*/
/*~+:*/
/*~+:Date :        */
/*~+:Time :        */
/*~+:*/
/*~+:Author :      MOF*/
/*~+:*/
/*~+:Hardware :*/
/*~+:*/
/*~+:Description :*/
/*~I:1*/
#ifndef __ADC_GLOBAL_H 
/*~T*/
#define __ADC_GLOBAL_H
/*~A:2*/
/*~+:Includes*/
/*~T*/
#include "ADuC836Driver.h"
/*~E:A2*/
/*~A:3*/
/*~+:Konfiguration*/
/*~T*/
#define ADC_MAX_CHANELS				4
/*~T*/
// #define ADC_MIT_WANDLERRATENERMITTLUNG
// #define ADC_MIT_EINSTELLBARER_MESSWERTTIEFE
/*~E:A3*/
/*~A:4*/
/*~+:Definitionen*/
/*~T*/

/*~E:A4*/
/*~A:5*/
/*~+:Strukturdefinitionen*/
/*~T*/
typedef struct
{
	unsigned char 	byMeasurementDepth;		///< beschreibt die Anzahl der aufaddierten Einzel-Messwerte, die den Gesamtmesswert ergeben.
	long 			lZeroOffset;			///< Nullpunkt-Offset.
	unsigned char	byADCCON;				///< ADC-Konfigurationsbyte
	unsigned char	byToggleMode;			///< Toggle-Betrieb Ein/Aus
}ADC_SETTINGS;
/*~T*/
typedef struct
{
	long 			lResult;						///< gewandelter Wert des ADC's.
	long 			lProvisionalResult;				///< vorl�ufiges Zwischenergebnis des ADC's.
	unsigned char 	byNewConversionValueFlag;		///< Es liegt ein neuer gewandelter Wert vor.
/*~I:6*/
#ifdef ADC_MIT_WANDLERRATENERMITTLUNG
/*~T*/
	unsigned int	uConversionTimeMS;					///< Wandlungszeit in ms

/*~-1*/
#endif
/*~E:I6*/
/*~T*/
	unsigned char	byADCxM;
	unsigned char	byADCxH;
	unsigned char	bDataConverted;
/*~T*/
}ADC_RESULTS;

/*~T*/
typedef struct
{
	ADC_SETTINGS	Settings[4];
	ADC_RESULTS		Results[4];
	unsigned char 	byMeasurementCounter[4];		///< Z�hler der aufaddierten Messwerte.
	unsigned char	byActualConversionChanel[2];	///< aktueller Konvertierungskanal
													///< 0 = Nicht-Toggle-Kanal , 1 = Toggle-Kanal
	unsigned char	bySincFilter;					///< dieser Wert bestimmt die Wandlerrate
	unsigned char 	bDisableInterrupt;				///< Sperre den ADC-Interrupt (im Verlauf der Auswertung der Messwrte)
/*~I:7*/
#ifdef ADC_MIT_WANDLERRATENERMITTLUNG
/*~T*/
	long			lConversionStartTime[4];		///< Startzeitpunkt der Wandlung
/*~-1*/
#endif
/*~E:I7*/
/*~T*/
}ADC;
/*~E:A5*/
/*~A:8*/
/*~+:Funktionsdeklarationen*/
/*~T*/
extern void 			ADuC836_ADC(void);

/*~E:A8*/
/*~A:9*/
/*~+:Variablendeklarationen*/
/*~T*/
extern ADC 				g_ADC;						///< ADC-Struktur
extern unsigned char 	g_byDisableRDY0NextTime;
/*~E:A9*/
/*~-1*/
#endif
/*~E:I1*/
