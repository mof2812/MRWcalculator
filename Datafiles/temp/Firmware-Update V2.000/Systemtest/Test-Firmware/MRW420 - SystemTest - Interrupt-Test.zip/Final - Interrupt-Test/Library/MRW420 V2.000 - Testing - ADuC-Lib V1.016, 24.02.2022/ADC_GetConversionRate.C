/*~-1*/
/*~XSF_LANGUAGE: C/C++*/
/*~T*/
/*

   (1) MODULNAME             :  ADC_GetConversionRate.c
   (2) VERSION               :  1.00
   (3) DATUM                 :  

   (4) LETZTE �NDERUNG       :  
   (5) PROJEKT (Vers.)       :  MRW Limit
   (6) PROGRAMMIERER         :  MOF

*/
/*~A:1*/
/*~+:Includes*/
/*~T*/
#include "ADC_Global.h"
/*~E:A1*/
/*~A:2*/
/*~+:Defines */
/*~T*/

/*~E:A2*/
/*~A:3*/
/*~+:Funktionsprototypen*/
/*~T*/
float ADuC836_ADCGetConversionRate(float fProcessorFrequency);
/*~E:A3*/
/*~A:4*/
/*~+:Modulvariablen*/
/*~T*/

/*~E:A4*/
/*~A:5*/
/*~+:float ADuC836_ADCGetConversionRate(float fProcessorFrequency)*/
/*~F:6*/
float ADuC836_ADCGetConversionRate(float fProcessorFrequency)
/*~-1*/
{
   /*~A:7*/
   /*~+:Beschreibung*/
   /*~T*/
   /*!
   \fn float ADuC836_ADCGetConversionRate(void)
   
   <b>Beschreibung:</b><br>
   Ausgabe der ADC-Sampling-Rate.
   
   \param
   ./.
   
   \return
   R�ckgabe der Wandlungsrate in Hz
   
   <b>Zugriff:</b><br>
   [X] �ffentlich / [ ] Privat
   
   \ref
   ExamplePage_ADuC836Driver "Beispiel 'ADuC836-Treiber'"
   */
   /*~E:A7*/
   /*~A:8*/
   /*~+:Variablendeklarationen*/
   /*~T*/

   /*~E:A8*/
   /*~A:9*/
   /*~+:Variableninitialisierungen*/
   /*~T*/

   /*~E:A9*/
   /*~C:10*/
   switch (SF)
   /*~-1*/
   {
      /*~F:11*/
      case 0x0D:
      /*~I:12*/
      if (g_ADC.Settings[ADuC836_ADC_PRIMARY].byToggleMode)
      /*~-1*/
      {
         /*~T*/
         return 26.33;
      /*~-1*/
      }
      /*~O:I12*/
      /*~-2*/
      else
      {
         /*~T*/
         return 105.3;
      /*~-1*/
      }
      /*~E:I12*/
      /*~E:F11*/
      /*~F:13*/
      case 0x45:
      /*~I:14*/
      if (g_ADC.Settings[ADuC836_ADC_PRIMARY].byToggleMode)
      /*~-1*/
      {
         /*~T*/
         return 4.95;
      /*~-1*/
      }
      /*~O:I14*/
      /*~-2*/
      else
      {
         /*~T*/
         return 19.79;
      /*~-1*/
      }
      /*~E:I14*/
      /*~E:F13*/
      /*~F:15*/
      case 0xFF:
      /*~I:16*/
      if (g_ADC.Settings[ADuC836_ADC_PRIMARY].byToggleMode)
      /*~-1*/
      {
         /*~T*/
         return 1.34;
      /*~-1*/
      }
      /*~O:I16*/
      /*~-2*/
      else
      {
         /*~T*/
         return 5.35;
      /*~-1*/
      }
      /*~E:I16*/
      /*~E:F15*/
      /*~O:C10*/
      /*~-2*/
      default:
      {
         /*~I:17*/
         if (g_ADC.Settings[ADuC836_ADC_PRIMARY].byToggleMode)
         /*~-1*/
         {
            /*~T*/
            return fProcessorFrequency/96/SF;
         /*~-1*/
         }
         /*~O:I17*/
         /*~-2*/
         else
         {
            /*~T*/
            return fProcessorFrequency/24/SF;
         /*~-1*/
         }
         /*~E:I17*/
      /*~-1*/
      }
   /*~-1*/
   }
   /*~E:C10*/
/*~-1*/
}
/*~E:F6*/
/*~E:A5*/
