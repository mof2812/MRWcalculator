/*~-1*/
/*~XSF_LANGUAGE: C/C++*/
/*~K*/
/*~+:File :        SPI_Global.h*/
/*~+:*/
/*~+:Version :     V1.000*/
/*~+:*/
/*~+:Date :        */
/*~+:Time :        */
/*~+:*/
/*~+:Author :      MOF*/
/*~+:*/
/*~+:Hardware :*/
/*~+:*/
/*~+:Description :*/
/*~I:1*/
#ifndef __SPI_GLOBAL_H 
/*~T*/
#define __SPI_GLOBAL_H
/*~A:2*/
/*~+:Konfiguration*/
/*~T*/
// #define ADUC836_SPI_GLOBALS_DEBUG_COM
#undef ADUC836_SPI_GLOBALS_DEBUG_COM
/*~T*/
#define ADUC836_SPI_GLOBALS_SEND_WITH_BYTEPAUSE
// #undef ADUC836_SPI_GLOBALS_SEND_WITH_BYTEPAUSE
/*~I:3*/
#ifdef ADUC836_SPI_GLOBALS_SEND_WITH_BYTEPAUSE 
/*~T*/
#define ADUC836_SPI_GLOBALS_BYTEPAUSE		20
/*~-1*/
#endif
/*~E:I3*/
/*~E:A2*/
/*~A:4*/
/*~+:Includes*/
/*~T*/

/*~E:A4*/
/*~A:5*/
/*~+:Definitionen*/
/*~T*/
#define SPI_DATAREAD				1
#define SPI_DATAWRITE				2
/*~T*/
#define CHECKTIMEOUT		ADuC836_SPICheckTimeout()
#define SETTIMEOUT(A)		ADuC836_SPISetTimeout(A)			
/*~T*/
//#define SPI_DEBUG_SLAVE_COMMUNICATION
#undef SPI_DEBUG_SLAVE_COMMUNICATION
/*~I:6*/
#ifndef SPI_DEBUG_SLAVE_COMMUNICATION 
/*~T*/
//#define SPI_DEBUG_MASTER_COMMUNICATION
#undef SPI_DEBUG_MASTER_COMMUNICATION
/*~O:I6*/
/*~-1*/
#else
/*~T*/
#undef SPI_DEBUG_MASTER_COMMUNICATION
/*~-1*/
#endif
/*~E:I6*/
/*~E:A5*/
/*~A:7*/
/*~+:Strukturdefinitionen*/
/*~T*/

/*~E:A7*/
/*~A:8*/
/*~+:Funktionsdeklarationen*/
/*~T*/

/*~E:A8*/
/*~A:9*/
/*~+:Variablendeklarationen*/
/*~T*/
extern SPI_T 				SPI;
extern SPI_ERRORBUFFER_T 	SPI_ErrorBuffer;
/*~E:A9*/
/*~-1*/
#endif
/*~E:I1*/
