/*~-1*/
/*~XSF_LANGUAGE: C/C++*/
/*~T*/
/*

   (1) MODULNAME             :  DAC_SetCurrentDeviation.c
   (2) VERSION               :  1.00
   (3) DATUM                 :  

   (4) LETZTE �NDERUNG       :  
   (5) PROJEKT (Vers.)       :  MRW Limit
   (6) PROGRAMMIERER         :  MOF

*/
/*~A:1*/
/*~+:Includes*/
/*~T*/
#include "DAC_Global.h"
#include "string.h"
/*~E:A1*/
/*~A:2*/
/*~+:Defines */
/*~T*/

/*~E:A2*/
/*~A:3*/
/*~+:Funktionsprototypen*/
/*~T*/
void ADuC836_DACSetCurrentDeviation(float fDeviation2Set);
/*~E:A3*/
/*~A:4*/
/*~+:Globale Variablen*/
/*~T*/

/*~E:A4*/
/*~A:5*/
/*~+:void ADuC836_DACSetCurrentDeviation(float fDeviation2Set)*/
/*~F:6*/
void ADuC836_DACSetCurrentDeviation(float fDeviation2Set)
/*~-1*/
{
   /*~A:7*/
   /*~+:Beschreibung*/
   /*~T*/
   /*!
   \fn void ADuC836_DACSetCurrentDeviation(float fDeviation2Set)
   
   <b>Beschreibung:</b><br>
   Setzen eines Korrekturwertes des DAC-Ausgangs.
   
   \param
   fDeviation2Set: Abweichung des DAC-Ausgangs.
   
   \return
   ./.
   
   <b>Zugriff:</b><br>
   [X] �ffentlich / [ ] Privat
   
   \ref
   ExamplePage_ADuC836Driver "Beispiel 'ADuC836-Treiber'"
   */
   /*~E:A7*/
   /*~T*/
   g_DAC.lOffset += (long)(fDeviation2Set / g_DAC.Settings.fGain_Norm + 0.5);
   /*~F:8*/
   /* Neu ab V1.007 */

   /*~-1*/
   {
      /*~I:9*/
      if (g_DAC.lOffset > 0x0FFF)
      /*~-1*/
      {
         /*~T*/
         g_DAC.lOffset = 0x0FFF;
      /*~-1*/
      }
      /*~E:I9*/
   /*~-1*/
   }
   /*~E:F8*/
/*~-1*/
}
/*~E:F6*/
/*~E:A5*/
