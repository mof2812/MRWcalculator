/*~-1*/
/*~XSF_LANGUAGE: C/C++*/
/*~T*/
/*

   (1) MODULNAME             :  ADC_SetBurnOutMode.c
   (2) VERSION               :  1.00
   (3) DATUM                 :  12.08.2015

   (4) LETZTE �NDERUNG       :  
   (5) PROJEKT (Vers.)       :  ADuc836-Driver
   (6) PROGRAMMIERER         :  MOF

*/
/*~A:1*/
/*~+:Includes*/
/*~T*/
#include "ADC_Global.h"
/*~E:A1*/
/*~A:2*/
/*~+:Defines */
/*~T*/

/*~E:A2*/
/*~A:3*/
/*~+:Funktionsprototypen*/
/*~T*/
unsigned char 	ADuC836_ADCSetBurnOutMode(unsigned char byOnOff);
/*~E:A3*/
/*~A:4*/
/*~+:Modulvariablen*/
/*~T*/

/*~E:A4*/
/*~A:5*/
/*~+:unsigned char 	ADuC836_ADCSetBurnOutMode(unsigned char byOnOff)*/
/*~F:6*/
unsigned char ADuC836_ADCSetBurnOutMode(unsigned char byOnOff)
/*~-1*/
{
   /*~I:7*/
   if (byOnOff)
   /*~-1*/
   {
      /*~T*/
      ICON |= 0x40;
   /*~-1*/
   }
   /*~O:I7*/
   /*~-2*/
   else
   {
      /*~T*/
      ICON &= 0xBF;
   /*~-1*/
   }
   /*~E:I7*/
   /*~T*/
   return byOnOff;
/*~-1*/
}
/*~E:F6*/
/*~E:A5*/
