/*~-1*/
/*~XSF_LANGUAGE: C/C++*/
/*~T*/
/*

   (1) MODULNAME             :  ADuC836_DACSetCurrentDeviationCorrectionOn.c
   (2) VERSION               :  1.00
   (3) DATUM                 :  

   (4) LETZTE �NDERUNG       :  
   (5) PROJEKT (Vers.)       :  MRW Limit
   (6) PROGRAMMIERER         :  MOF

*/
/*~A:1*/
/*~+:Includes*/
/*~T*/
#include "DAC_Global.h"
#include "string.h"
/*~E:A1*/
/*~A:2*/
/*~+:Defines */
/*~T*/

/*~E:A2*/
/*~A:3*/
/*~+:Funktionsprototypen*/
/*~T*/
void ADuC836_DACSetCurrentDeviationCorrectionOn(unsigned char byOn);
/*~E:A3*/
/*~A:4*/
/*~+:Globale Variablen*/
/*~T*/

/*~E:A4*/
/*~A:5*/
/*~+:void ADuC836_DACSetCurrentDeviationCorrectionOn(unsigned char byOn)*/
/*~F:6*/
void ADuC836_DACSetCurrentDeviationCorrectionOn(unsigned char byOn)
/*~-1*/
{
   /*~A:7*/
   /*~+:Beschreibung*/
   /*~T*/
   /*!
   \fn void ADuC836_DACSetCurrentDeviation(float fDeviation2Set)
   
   <b>Beschreibung:</b><br>
   Setzen eines Korrekturwertes des DAC-Ausgangs.
   
   \param
   fDeviation2Set: Abweichung des DAC-Ausgangs.
   
   \return
   ./.
   
   <b>Zugriff:</b><br>
   [X] �ffentlich / [ ] Privat
   
   \ref
   ExamplePage_ADuC836Driver "Beispiel 'ADuC836-Treiber'"
   */
   /*~E:A7*/
   /*~I:8*/
   if (byOn)
   /*~-1*/
   {
      /*~T*/
      g_DAC.Settings.bCorrectionOn = 1;
   /*~-1*/
   }
   /*~O:I8*/
   /*~-2*/
   else
   {
      /*~T*/
      g_DAC.Settings.bCorrectionOn = 0;
   /*~-1*/
   }
   /*~E:I8*/
/*~-1*/
}
/*~E:F6*/
/*~E:A5*/
