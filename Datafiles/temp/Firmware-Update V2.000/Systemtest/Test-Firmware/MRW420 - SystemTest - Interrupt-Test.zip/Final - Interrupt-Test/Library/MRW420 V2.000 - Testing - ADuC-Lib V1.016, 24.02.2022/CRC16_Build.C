/*~-1*/
/*~XSF_LANGUAGE: C/C++*/
/*~T*/
/*

   (1) MODULNAME             :  CRC16_Build.c
   (2) VERSION               :  1.00
   (3) DATUM                 :  

   (4) LETZTE �NDERUNG       :  
   (5) PROJEKT (Vers.)       :  MRW Limit
   (6) PROGRAMMIERER         :  MOF

*/
/*~A:1*/
/*~+:Includes*/
/*~T*/
#include "CRC16.h"
/*~E:A1*/
/*~A:2*/
/*~+:Defines */
/*~T*/

/*~E:A2*/
/*~A:3*/
/*~+:Funktionsprototypen*/
/*~T*/
unsigned int CRC16_Build(unsigned char byData);
/*~E:A3*/
/*~A:4*/
/*~+:Globale Variablen*/
/*~T*/

/*~E:A4*/
/*~A:5*/
/*~+:unsigned int CRC16_Build(unsigned char byData)*/
/*~F:6*/
unsigned int CRC16_Build(unsigned char byData)
/*~-1*/
{
   /*~A:7*/
   /*~+:Beschreibung*/
   /*~T*/
   /*!
   \fn unsigned int CRC16_Build(unsigned char byData)
   
   <b>Beschreibung:</b><br>
   Berechnet die CRC16-Pr�fsummen aus einem �bergebenen Zeichen und aktualisiert die Pr�fsumme 
   
   \param
   byData: Byte, von dem die Pr�fsumme gebildet werden soll.
   
   \return
   Aktualisierte Pr�fsumme.
   
   <b>Zugriff:</b><br>
   [X] �ffentlich / [ ] Privat
   
   \ref
   */

   /*~E:A7*/
   /*~A:8*/
   /*~+:Variablendeklarationen*/
   /*~T*/
   int 			i;

   /*~E:A8*/
   /*~A:9*/
   /*~+:Variableninitialisierungen*/
   /*~T*/

   /*~E:A9*/
   /*~T*/
   g_uiCRC16 ^= byData;
   /*~L:10*/
   for (i = 8; i; i--)
   /*~-1*/
   {
      /*~T*/
      g_uiCRC16 = (g_uiCRC16 >> 1) ^ ((g_uiCRC16 & 1) ? 0xA001 : 0 );
   /*~-1*/
   }
   /*~E:L10*/
   /*~T*/
   return g_uiCRC16;
/*~-1*/
}
/*~E:F6*/
/*~E:A5*/
