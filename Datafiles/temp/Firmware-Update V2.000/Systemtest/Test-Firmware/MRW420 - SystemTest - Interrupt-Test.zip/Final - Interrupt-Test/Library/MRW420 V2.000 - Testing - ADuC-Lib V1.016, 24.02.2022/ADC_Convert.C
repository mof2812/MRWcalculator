/*~-1*/
/*~XSF_LANGUAGE: C/C++*/
/*~T*/
/*

   (1) MODULNAME             :  ADC_Convert.c
   (2) VERSION               :  1.00
   (3) DATUM                 :  

   (4) LETZTE �NDERUNG       :  
   (5) PROJEKT (Vers.)       :  MRW Limit
   (6) PROGRAMMIERER         :  MOF

*/
/*~A:1*/
/*~+:Includes*/
/*~T*/
#include "ADC_Global.h"
/*~E:A1*/
/*~A:2*/
/*~+:Defines */
/*~T*/

/*~E:A2*/
/*~A:3*/
/*~+:Funktionsprototypen*/
/*~T*/

/*~E:A3*/
/*~A:4*/
/*~+:Modulvariablen*/
/*~T*/

/*~E:A4*/
/*~A:5*/
/*~+:// Modifizierte Version*/
/*~+:void ADuC836_ADCConvert(void) interrupt 6*/
/*~F:6*/
void ADuC836_ADCConvert(void) interrupt 6	// using 1
/*~-1*/
{
   /*~A:7*/
   /*~+:Beschreibung*/
   /*~T*/
   /*!
   \fn void ADuC836_ADCConvert(void) interrupt 6
   
   <b>Beschreibung:</b><br>
   Interruptroutine zur Verarbeitung der Rohmesswerte vom ADC. Hierzu z�hlt die Verrechnung des manuell gesetzten Offsets und die Aufaddierung ggf. mehrerer Messwerte (=> Messwerttiefe) zu einem endg�ltigem Ergebnis.
   F�r den Kanal 2 des ADCs gibt das Flag zur Kennzeichnung eines neuen Wertes noch die Auskunft zur�ck, an welchem Multiplexereingang das Signal lag (beginnend mit 1!).
   
   \param
   void:
   
   \retval
   ./.
   
   \par Zugriff:
   [X] �ffentlich / [ ] Privat
   
   \ref
   ExamplePage_ADuC836Driver "Beispiel 'ADuC836-Treiber'"
   */

   /*~E:A7*/
   /*~A:8*/
   /*~+:Variablendeklarationen*/
   /*~T*/
   static unsigned char byActualConversionChannel_Primary = ADuC836_ADC_PRIMARY;
   static unsigned char byActualConversionChannel_Auxiliary = ADuC836_ADC_AUXILIARY;
   /*~E:A8*/
   /*~A:9*/
   /*~+:Variableninitialisierungen*/
   /*~T*/
   //  byDoNotSetADCCON = 0; 
   /*~E:A9*/
   /*~I:10*/
   if ((RDY0)||(RDY1))
   /*~-1*/
   {
      /*~I:11*/
      if ((RDY0)&&(!g_byDisableRDY0NextTime))
      /*~-1*/
      {
         /*~A:12*/
         /*~+:Ma�nahmen schaffen, dass der Hilfs-ADC auch mal zum Zuge kommt*/
         /*~I:13*/
         if (RDY1)
         /*~-1*/
         {
            /*~T*/
            g_byDisableRDY0NextTime = 1;
         /*~-1*/
         }
         /*~E:I13*/
         /*~E:A12*/
         /*~T*/
         // Nur wenn die letzten Daten verarbeitet wurden

         // Registerinhalte ablegen
         g_ADC.Results[byActualConversionChannel_Primary].byADCxM = ADC0M;
         g_ADC.Results[byActualConversionChannel_Primary].byADCxH = ADC0H;
         g_ADC.Results[byActualConversionChannel_Primary].bDataConverted = 1;
         /*~A:14*/
         /*~+:ggf.Umschaltung f�r Toggle-Modus*/
         /*~T*/
         // ggf.Umschaltung f�r Toggle-Modus
         /*~I:15*/
         if (g_ADC.Settings[ADuC836_ADC_PRIMARY].byToggleMode)
         /*~-1*/
         {
            /*~T*/
            // Toggle-Mode ist aktiv
            /*~I:16*/
            if (byActualConversionChannel_Primary == ADuC836_ADC_PRIMARY)
            /*~-1*/
            {
               /*~T*/
               byActualConversionChannel_Primary = ADuC836_ADC_PRIMARY_TOGGLE;
            /*~-1*/
            }
            /*~O:I16*/
            /*~-2*/
            else
            {
               /*~T*/
               byActualConversionChannel_Primary = ADuC836_ADC_PRIMARY;
            /*~-1*/
            }
            /*~E:I16*/
            /*~T*/
            ADC0CON = g_ADC.Settings[byActualConversionChannel_Primary].byADCCON;
            /*~T*/
            // Sinc-Filter neu setzen
            SF = g_ADC.bySincFilter;
         /*~-1*/
         }
         /*~E:I15*/
         /*~E:A14*/
         /*~A:17*/
         /*~+:ggf. Ermittlung der Wandlungszeit*/
         /*~I:18*/
#ifdef ADC_MIT_WANDLERRATENERMITTLUNG
         /*~T*/
         g_ADC.Results[byChannel].uConversionTimeMS = Timer.ulOperatingTime - g_ADC.lConversionStartTime[byChannel];

         g_ADC.lConversionStartTime[byChannel] = Timer.ulOperatingTime;
         /*~-1*/
#endif
         /*~E:I18*/
         /*~E:A17*/
         /*~T*/
         RDY0 = 0;
      /*~-1*/
      }
      /*~O:I11*/
      /*~-2*/
      else
      {
         /*~I:19*/
         if (RDY1)
         /*~-1*/
         {
            /*~T*/
            // RDY0 f�r den n�chsten Durchgang wieder freigeben
            g_byDisableRDY0NextTime = 0;

            // Registerinhalte ablegen
            g_ADC.Results[byActualConversionChannel_Auxiliary].byADCxM = ADC1L;
            g_ADC.Results[byActualConversionChannel_Auxiliary].byADCxH = ADC1H;
            g_ADC.Results[byActualConversionChannel_Auxiliary].bDataConverted = 1;
            /*~A:20*/
            /*~+:ggf.Umschaltung f�r Toggle-Modus*/
            /*~T*/
            // ggf.Umschaltung f�r Toggle-Modus
            /*~I:21*/
            if (g_ADC.Settings[ADuC836_ADC_AUXILIARY].byToggleMode)
            /*~-1*/
            {
               /*~T*/
               // Toggle-Mode ist aktiv
               /*~I:22*/
               if (byActualConversionChannel_Auxiliary == ADuC836_ADC_AUXILIARY)
               /*~-1*/
               {
                  /*~T*/
                  byActualConversionChannel_Auxiliary = ADuC836_ADC_AUXILIARY_TOGGLE;
               /*~-1*/
               }
               /*~O:I22*/
               /*~-2*/
               else
               {
                  /*~T*/
                  byActualConversionChannel_Auxiliary = ADuC836_ADC_AUXILIARY;
               /*~-1*/
               }
               /*~E:I22*/
               /*~T*/
               ADC1CON = g_ADC.Settings[byActualConversionChannel_Auxiliary].byADCCON;
               /*~T*/
               // Sinc-Filter neu setzen
               SF = g_ADC.bySincFilter;
            /*~-1*/
            }
            /*~E:I21*/
            /*~E:A20*/
            /*~A:23*/
            /*~+:ggf. Ermittlung der Wandlungszeit*/
            /*~I:24*/
#ifdef ADC_MIT_WANDLERRATENERMITTLUNG
            /*~T*/
            g_ADC.Results[byChannel].uConversionTimeMS = Timer.ulOperatingTime - g_ADC.lConversionStartTime[byChannel];

            g_ADC.lConversionStartTime[byChannel] = Timer.ulOperatingTime;
            /*~-1*/
#endif
            /*~E:I24*/
            /*~E:A23*/
            /*~T*/
            RDY1 = 0;
         /*~-1*/
         }
         /*~E:I19*/
      /*~-1*/
      }
      /*~E:I11*/
   /*~-1*/
   }
   /*~E:I10*/
/*~-1*/
}
/*~E:F6*/
/*~E:A5*/
