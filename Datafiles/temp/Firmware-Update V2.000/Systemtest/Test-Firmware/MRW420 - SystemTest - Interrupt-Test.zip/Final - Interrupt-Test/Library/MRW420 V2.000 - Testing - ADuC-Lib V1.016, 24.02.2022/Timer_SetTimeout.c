/*~-1*/
/*~XSF_LANGUAGE: C/C++*/
/*~K*/
/*~+:File :        Timer_SetTimeout.c*/
/*~+:*/
/*~+:Version :     V1.000*/
/*~+:*/
/*~+:Date :        03.06.2005*/
/*~+:*/
/*~+:Time :        */
/*~+:*/
/*~+:Author :      MOF*/
/*~+:*/
/*~+:Hardware :*/
/*~+:*/
/*~+:Description :*/
/*~A:1*/
/*~+:Includes*/
/*~T*/
#include "ADuC836Driver.h"

/*~E:A1*/
/*~A:2*/
/*~+:Funktionseigene Definitionen*/
/*~T*/

/*~E:A2*/
/*~A:3*/
/*~+:Funktionseigene Struktur-Definitionen*/
/*~T*/

/*~E:A3*/
/*~A:4*/
/*~+:Funktionsprototypen*/
/*~T*/
void ADuC836_TimerSetTimeout(unsigned int uTimeMS);
/*~E:A4*/
/*~A:5*/
/*~+:Globale Variablen*/
/*~T*/
extern TIMER Timer;
/*~E:A5*/
/*~A:6*/
/*~+:void ADuC836_TimerSetTimeout(unsigned int uTimeMS)*/
/*~F:7*/
void ADuC836_TimerSetTimeout(unsigned int uTimeMS)

/*~-1*/
{
   /*~A:8*/
   /*~+:Beschreibung*/
   /*~T*/
   /*!
   \fn void ADuC836_TimerSetTimeout(unsigned int uTimeMS)
   
   <b>Beschreibung:</b><br>
   Setzen der Timeout-Zielzeit.
   
   \param
   uTimeMS: Zeit, nach der ein Timeout erfolgen soll.
   
   \return
   ./.
   
   <b>Zugriff:</b><br>
   [X] �ffentlich / [ ] Privat
   
   \ref
   ExamplePage_ADuC836Driver "Beispiel 'ADuC836-Treiber'"
   */
   /*~E:A8*/
   /*~T*/
   // Zielzeit setzen
   Timer.ulDestinationTimeout = Timer.ulOperatingTime + uTimeMS; 
/*~-1*/
}
/*~E:F7*/
/*~E:A6*/
