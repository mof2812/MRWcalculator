/*~-1*/
/*~XSF_LANGUAGE: C/C++*/
/*~K*/
/*~+:File :        Timer_SetTimer.c*/
/*~+:*/
/*~+:Version :     V1.000*/
/*~+:*/
/*~+:Date :        03.06.2005*/
/*~+:*/
/*~+:Time :        */
/*~+:*/
/*~+:Author :      MOF*/
/*~+:*/
/*~+:Hardware :*/
/*~+:*/
/*~+:Description :*/
/*~A:1*/
/*~+:Includes*/
/*~T*/
#include "ADuC836Driver.h"

/*~E:A1*/
/*~A:2*/
/*~+:Funktionseigene Definitionen*/
/*~T*/

/*~E:A2*/
/*~A:3*/
/*~+:Funktionseigene Struktur-Definitionen*/
/*~T*/

/*~E:A3*/
/*~A:4*/
/*~+:Funktionsprototypen*/
/*~T*/
char ADuC836_TimerSetTimer(unsigned char chWhichTimer,unsigned int uTimeMS);
/*~E:A4*/
/*~A:5*/
/*~+:Globale Variablen*/
/*~T*/
extern TIMER Timer;
/*~E:A5*/
/*~A:6*/
/*~+:char ADuC836_TimerSetTimer(unsigned char chWhichTimer,unsigned int uTimeMS)*/
/*~F:7*/
char ADuC836_TimerSetTimer(unsigned char chWhichTimer,unsigned int uTimeMS)
/*~-1*/
{
   /*~A:8*/
   /*~+:Beschreibung*/
   /*~T*/
   /*!
   \fn char ADuC836_TimerSetTimer(unsigned char chWhichTimer,unsigned int uTimeMS)
   
   <b>Beschreibung:</b><br>
   Setzen der Zeitbasis eines Timers.
   
   \param
   chWhichTimer: Kennziffer des Timers, dessen Zeitbasis gesetzt werden soll.
   
   \param
   uTimeMS: Zeitbasis in Millisekunden.
   
   \return
   Status der Funktionsausf�hrung.
    
   \retval
   0: Alles okay.
   \retval
   1: Timer existiert nicht.
   
   <b>Zugriff:</b><br>
   [X] �ffentlich / [ ] Privat
   
   \ref
   ExamplePage_ADuC836Driver "Beispiel 'ADuC836-Treiber'"
   */

   /*~E:A8*/
   /*~I:9*/
   if (chWhichTimer < TIMER_NB_TIMERS)
   /*~-1*/
   {
      /*~T*/
      Timer.uTimebase[chWhichTimer] = uTimeMS;
      /*~T*/
      return 0;
   /*~-1*/
   }
   /*~O:I9*/
   /*~-2*/
   else
   {
      /*~T*/
      // Timer existiert nicht
      return 1;
   /*~-1*/
   }
   /*~E:I9*/
/*~-1*/
}
/*~E:F7*/
/*~E:A6*/
