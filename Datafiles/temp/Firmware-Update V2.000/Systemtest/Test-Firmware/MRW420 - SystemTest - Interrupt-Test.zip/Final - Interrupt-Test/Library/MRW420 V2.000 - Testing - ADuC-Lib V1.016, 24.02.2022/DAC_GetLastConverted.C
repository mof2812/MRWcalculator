/*~-1*/
/*~XSF_LANGUAGE: C/C++*/
/*~T*/
/*

   (1) MODULNAME             :  DAC_GetLastConverted.c
   (2) VERSION               :  1.00
   (3) DATUM                 :  

   (4) LETZTE �NDERUNG       :  
   (5) PROJEKT (Vers.)       :  MRW Limit
   (6) PROGRAMMIERER         :  MOF

*/
/*~A:1*/
/*~+:Includes*/
/*~T*/
#include "ADuC836Driver.h"
/*~E:A1*/
/*~A:2*/
/*~+:Defines */
/*~T*/

/*~E:A2*/
/*~A:3*/
/*~+:Funktionsprototypen*/
/*~T*/
float ADuC836_DACGetLastConverted(void);
/*~E:A3*/
/*~A:4*/
/*~+:Modulvariablen*/
/*~T*/
extern DAC_SETTINGS DAC_Settings;						///< DAC-Parameter
extern long lRMV_DAC;									///< aktueller digitaler Wert der Wandlung ohne Offset- und Gain-Verrechnung

extern long lActualConvertionValue;						///< aktueller digitaler Wert der Wandlung inklusive Offset- und Gain-Verrechnung

extern unsigned char chLimitReached;					///< Merker f�r erreichte Grenzwert�berschreitungen

/*~E:A4*/
/*~A:5*/
/*~+:float ADuC836_DACGetLastConverted(void)*/
/*~F:6*/
float ADuC836_DACGetLastConverted(void)
/*~-1*/
{
   /*~T*/
   return DAC_Settings.fLastCurrent;
/*~-1*/
}
/*~E:F6*/
/*~E:A5*/
