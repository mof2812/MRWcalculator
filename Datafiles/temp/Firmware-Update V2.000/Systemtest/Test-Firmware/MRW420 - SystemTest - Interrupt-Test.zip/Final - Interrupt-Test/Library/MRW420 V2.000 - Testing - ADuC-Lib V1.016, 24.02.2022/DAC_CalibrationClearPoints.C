/*~-1*/
/*~XSF_LANGUAGE: C/C++*/
/*~T*/
/*

   (1) MODULNAME             :  DAC_CalibrationClearPoints.c
   (2) VERSION               :  1.00
   (3) DATUM                 :  

   (4) LETZTE �NDERUNG       :  
   (5) PROJEKT (Vers.)       :  MRW Limit
   (6) PROGRAMMIERER         :  MOF

*/
/*~A:1*/
/*~+:Includes*/
/*~T*/
#include "DAC_Global.h"
#include "string.h"
/*~E:A1*/
/*~A:2*/
/*~+:Defines */
/*~T*/

/*~E:A2*/
/*~A:3*/
/*~+:Funktionsprototypen*/
/*~T*/
void ADuC836_DACCalibrationClearPoints(void);
/*~E:A3*/
/*~A:4*/
/*~+:Globale Variablen*/
/*~T*/

/*~E:A4*/
/*~A:5*/
/*~+:void ADuC836_DACCalibrationClearPoints(void)*/
/*~F:6*/
void ADuC836_DACCalibrationClearPoints(void)
/*~-1*/
{
   /*~A:7*/
   /*~+:Beschreibung*/
   /*~T*/
   /*!
   \fn void ADuC836_DACCalibrationClearPoints(void)
   
   <b>Beschreibung:</b><br>
   L�scht alle Kalibrierpunkte.
   
   \param
   ./.
   
   \return
   ./.
   
   <b>Zugriff:</b><br>
   [X] �ffentlich / [ ] Privat
   
   \ref
   ExamplePage_ADuC836Driver "Beispiel 'ADuC836-Treiber'
   */
   /*~E:A7*/
   /*~T*/
   memset(&g_DAC.Settings.CalibrationPoint,0,2*sizeof(DAC_CALIBRATIONPOINT));
/*~-1*/
}
/*~E:F6*/
/*~E:A5*/
