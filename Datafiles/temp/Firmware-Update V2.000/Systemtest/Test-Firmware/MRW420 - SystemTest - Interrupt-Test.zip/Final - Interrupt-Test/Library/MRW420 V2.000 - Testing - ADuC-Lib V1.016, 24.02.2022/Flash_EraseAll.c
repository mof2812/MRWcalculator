/*~-1*/
/*~XSF_LANGUAGE: C/C++*/
/*~T*/
/*

   (1) MODULNAME             :  Flash_EraseAll.c
   (2) VERSION               :  1.00
   (3) DATUM                 :  17.06.2003

   (4) LETZTE �NDERUNG       :  17.05.2005
   (5) PROJEKT (Vers.)       :  
   (6) PROGRAMMIERER         :  n.l./MOF

*/


/*~A:1*/
/*~+:Includes*/
/*~T*/
#include "ADuC836Driver.h"
/*~E:A1*/
/*~A:2*/
/*~+:Moduleigene Definitionen */
/*~T*/

/*~E:A2*/
/*~A:3*/
/*~+:Funktionsprototypen*/
/*~T*/
char ADuC836_FlashEraseAll(void);
/*~E:A3*/
/*~A:4*/
/*~+:Modulvariablen*/
/*~T*/

/*~E:A4*/
/*~A:5*/
/*~+:char ADuC836_FlashEraseAll(void)*/
/*~F:6*/
char ADuC836_FlashEraseAll(void)
/*~-1*/
{
   /*~A:7*/
   /*~+:Beschreibung*/
   /*~T*/
   /*
   L�sche die aktuelle Page
   
   R�ckgabe:
   - 0 Funktion konnte erfolgreich durchgef�hrt werden
   - 1 Allgemeiner Fehler 
   */
   /*~E:A7*/
   /*~A:8*/
   /*~+:Variablendeklarationen*/
   /*~T*/

   /*~E:A8*/
   /*~A:9*/
   /*~+:Variableninitialsierungen*/
   /*~T*/

   /*~E:A9*/
   /*~T*/
   ECON = FLASH_COMMAND_ERASE_ALL_PAGES;
   /*~T*/
   return 0;
/*~-1*/
}
/*~E:F6*/
/*~E:A5*/
