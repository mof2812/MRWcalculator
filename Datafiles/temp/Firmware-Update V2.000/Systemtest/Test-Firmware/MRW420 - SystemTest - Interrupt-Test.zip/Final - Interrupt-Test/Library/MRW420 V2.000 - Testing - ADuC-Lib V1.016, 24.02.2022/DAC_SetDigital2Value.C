/*~-1*/
/*~XSF_LANGUAGE: C/C++*/
/*~T*/
/*

   (1) MODULNAME             :  DAC_SetDigital2Value.c
   (2) VERSION               :  1.00
   (3) DATUM                 :  

   (4) LETZTE �NDERUNG       :  
   (5) PROJEKT (Vers.)       :  MRW Limit
   (6) PROGRAMMIERER         :  MOF

*/
/*~A:1*/
/*~+:Includes*/
/*~T*/
#include "DAC_Global.h"
#include "string.h"
/*~E:A1*/
/*~A:2*/
/*~+:Defines */
/*~T*/

/*~E:A2*/
/*~A:3*/
/*~+:Funktionsprototypen*/
/*~T*/
void ADuC836_DACSetDigital2Value(long lConversioValue,float fOutputValue,float fFixedOutputValue);
/*~E:A3*/
/*~A:4*/
/*~+:Globale Variablen*/
/*~T*/

/*~E:A4*/
/*~A:5*/
/*~+:void ADuC836_DACSetDigital2Value(long lConversioValue,float fOutputValue,float fFixedOutputValue)*/
/*~F:6*/
/*#LJ:ADuC836_DACSetDigital2Value=6*/
void ADuC836_DACSetDigital2Value(long lConversioValue,float fOutputValue,float fFixedOutputValue)
/*~-1*/
{
   /*~A:7*/
   /*~+:Beschreibung*/
   /*~T*/
   /*!
   \fn void ADuC836_DACSetDigital2Value(long lConversioValue,float fOutputValue,float fFixedOutputValue)
   
   <b>Beschreibung:</b><br>
   Lage der Normierungskurve �ber einen ver�nderten Punkt verlagern.
   
   \param
   lConversioValue: Zugeordneter Digitalwert des neuen Kurvenpunktes. 
   
   \param
   fOutputValue: DAC-Ausgangswert des neuen Kurvenpunktes.
   
   \param
   fFixedOutputValue: DAC-Ausgangswert, um den die Kennlinie gedreht wird.
   
   \return
   ./.
   
   <b>Zugriff:</b><br>
   [X] �ffentlich / [ ] Privat
   
   \ref
   ExamplePage_ADuC836Driver "Beispiel 'ADuC836-Treiber'"
   */
   /*~E:A7*/
   /*~A:8*/
   /*~+:Variablendeklarationen*/
   /*~T*/
   long lDigital[2];
   long lDigitalRMV[2];
   /*~E:A8*/
   /*~A:9*/
   /*~+:Variableninitialisierungen*/
   /*~T*/

   /*~E:A9*/
   /*~T*/
   // zun�chst einmal den Digitalwert der beiden Eckpunkte festhalten
   lDigital[0] = ADuC836_DACGetDigitalNorm(fFixedOutputValue);
   lDigital[1] = ADuC836_DACGetDigitalNorm(fOutputValue);

   /*~T*/
   // Messwert-Normierung

   g_DAC.Settings.fGain_Norm = (fOutputValue - fFixedOutputValue) / (lDigital[1] - lDigital[0]);

   g_DAC.Settings.fOffset_Norm = g_DAC.Settings.CalibrationPoint[0].fTrueValue - g_DAC.Settings.fGain_Norm * g_DAC.Settings.CalibrationPoint[0].lConvertionValue;

   /*~K*/
   /*~+:*/
   /*~T*/
   // RMW-Normierung
   // DAC-Sollwerte digital berechnen

   lDigitalRMV[0] = ADuC836_DACGetDigital(fFixedOutputValue);
   lDigitalRMV[1] = ADuC836_DACGetDigital(fOutputValue);

   g_DAC.Settings.fGain_RMV = (lDigital[1] - lDigital[0]) / (float)(lConversioValue - lDigitalRMV[0]);
   g_DAC.Settings.fOffset_RMV = lDigital[0] - g_DAC.Settings.fGain_RMV * lDigitalRMV[0];

/*~-1*/
}
/*~E:F6*/
/*~E:A5*/
