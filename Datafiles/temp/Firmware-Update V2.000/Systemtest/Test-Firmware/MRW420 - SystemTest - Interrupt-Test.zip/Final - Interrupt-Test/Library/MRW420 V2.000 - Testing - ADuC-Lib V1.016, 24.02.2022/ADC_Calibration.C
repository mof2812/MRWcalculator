/*~-1*/
/*~XSF_LANGUAGE: C/C++*/
/*~T*/
/*

   (1) MODULNAME             :  ADC_Calibration.c
   (2) VERSION               :  1.00
   (3) DATUM                 :  

   (4) LETZTE �NDERUNG       :  
   (5) PROJEKT (Vers.)       :  MRW Limit
   (6) PROGRAMMIERER         :  MOF

*/
/*~A:1*/
/*~+:Includes*/
/*~T*/
#include "ADC_Global.h"
/*~E:A1*/
/*~A:2*/
/*~+:Defines */
/*~T*/

/*~E:A2*/
/*~A:3*/
/*~+:Funktionsprototypen*/
/*~T*/
unsigned char ADuC836_ADCCalibration(unsigned char byCalibrationMode);
/*~E:A3*/
/*~A:4*/
/*~+:Modulvariablen*/
/*~T*/

/*~E:A4*/
/*~A:5*/
/*~+:unsigned char ADuC836_ADCCalibration(unsigned char byCalibrationMode)*/
/*~F:6*/
unsigned char ADuC836_ADCCalibration(unsigned char byCalibrationMode)
/*~-1*/
{
   /*~A:7*/
   /*~+:Beschreibung*/
   /*~T*/
   /*!
   \fn unsigned char ADuC836_ADCCalibration(unsigned char byCalibrationMode)
   
   <b>Beschreibung:</b><br>
   F�hrt eine der vier m�glichen Kalibrierungen des ADC's durch.
   
   \param
   byCalibrationMode: Angabe �ber die auszuf�hrende Kalibrierung.
   
   \return
   Status der Funktionsausf�hrung.
   
   \retval
   0: Alles okay
   
   \retval
   1: Fehler bei der Kalibrierung des Hauptkanals. 
   
   \retval
   2: Fehler bei der Kalibrierung des Hilfskanals.
   
   <b>Zugriff:</b><br>
   [X] �ffentlich / [ ] Privat
   
   \ref
   ExamplePage_ADuC836Driver "Beispiel 'ADuC836-Treiber'"
   */
   /*~E:A7*/
   /*~A:8*/
   /*~+:Variablendeklarationen*/
   /*~T*/
   unsigned char byInitEADC;
   unsigned char byInitEA;
   unsigned char byADCMODE;
   unsigned char byRetVal;
   /*~E:A8*/
   /*~A:9*/
   /*~+:Variableninitialisierungen*/
   /*~T*/
   // Eingangszustand zwischenspeichern.
   byInitEADC = EADC;
   byInitEA = EA;
   byADCMODE = ADCMODE;

   /*~T*/
   byRetVal = 0;
   /*~E:A9*/
   /*~T*/
   // Freigabe des ADC's l�schen
   EADC = 0;
   ADCMODE &= 0xF8; 
   /*~C:10*/
   switch (byCalibrationMode)
   /*~-1*/
   {
      /*~A:11*/
      /*~+:ADuC836_ADC_INTERNALZEROSCALE_CALIBRATION*/
      /*~F:12*/
      case ADuC836_ADC_INTERNALZEROSCALE_CALIBRATION:
      /*~-1*/
      {
         /*~T*/
         ADCMODE |= 0x04;
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F12*/
      /*~E:A11*/
      /*~A:13*/
      /*~+:ADuC836_ADC_INTERNALFULLSCALE_CALIBRATION*/
      /*~F:14*/
      case ADuC836_ADC_INTERNALFULLSCALE_CALIBRATION:
      /*~-1*/
      {
         /*~T*/
         ADCMODE |= 0x05;
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F14*/
      /*~E:A13*/
      /*~A:15*/
      /*~+:ADuC836_ADC_SYSTEMZEROSCALE_CALIBRATION*/
      /*~F:16*/
      case ADuC836_ADC_SYSTEMZEROSCALE_CALIBRATION:
      /*~-1*/
      {
         /*~T*/
         ADCMODE |= 0x06;
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F16*/
      /*~E:A15*/
      /*~A:17*/
      /*~+:ADuC836_ADC_SYSTEMFULLSCALE_CALIBRATION*/
      /*~F:18*/
      case ADuC836_ADC_SYSTEMFULLSCALE_CALIBRATION:
      /*~-1*/
      {
         /*~T*/
         ADCMODE |= 0x07;
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F18*/
      /*~E:A17*/
   /*~-1*/
   }
   /*~E:C10*/
   /*~T*/
   // Freigabe des ADC's setzen
   EADC = 1;
   EA = 1;
   /*~L:19*/
   // Warten bis die Kalibrierung beendet ist
   while ((!RDY0)||(!RDY1))
   /*~-1*/
   {
      /*~T*/

   /*~-1*/
   }
   /*~E:L19*/
   /*~T*/
   // Freigaben auf alten Zustand setzen
   EADC = byInitEADC;
   EA = byInitEA;
   /*~A:20*/
   /*~+:Fehlerauswertung*/
   /*~I:21*/
   if (ERR0)
   /*~-1*/
   {
      /*~T*/
      byRetVal |= 0x01;
   /*~-1*/
   }
   /*~E:I21*/
   /*~I:22*/
   if (ERR1)
   /*~-1*/
   {
      /*~T*/
      byRetVal |= 0x02;
   /*~-1*/
   }
   /*~E:I22*/
   /*~E:A20*/
   /*~T*/
   return byRetVal;
/*~-1*/
}
/*~E:F6*/
/*~E:A5*/
