/*~-1*/
/*~XSF_LANGUAGE: C/C++*/
/*~T*/
/*

   (1) MODULNAME             :  CRC16_ToASCII.c
   (2) VERSION               :  1.00
   (3) DATUM                 :  

   (4) LETZTE �NDERUNG       :  
   (5) PROJEKT (Vers.)       :  MRW Limit
   (6) PROGRAMMIERER         :  MOF

*/
/*~A:1*/
/*~+:Includes*/
/*~T*/
#include "CRC16.h"
#include <stdio.h>
/*~E:A1*/
/*~A:2*/
/*~+:Defines */
/*~T*/

/*~E:A2*/
/*~A:3*/
/*~+:Funktionsprototypen*/
/*~T*/
unsigned char* CRC16_ToASCII(void);
/*~E:A3*/
/*~A:4*/
/*~+:Globale Variablen*/
/*~T*/

/*~E:A4*/
/*~A:5*/
/*~+:unsigned char* CRC16_ToASCII(void)*/
/*~F:6*/
unsigned char* CRC16_ToASCII(void)
/*~-1*/
{
   /*~A:7*/
   /*~+:Beschreibung*/
   /*~T*/
   /*!
   \fn unsigned char* CRC16_ToASCII(void)
   
   <b>Beschreibung:</b><br>
   Wandelt die aktuelle CRC16-Pr�fsumme in einen String um 
   
   \param
   ./.
   
   \return
   CRC16-Pr�fsumme als ASCII-String.
   
   <b>Zugriff:</b><br>
   [X] �ffentlich / [ ] Privat
   
   \ref
   */

   /*~E:A7*/
   /*~A:8*/
   /*~+:Variablendeklarationen*/
   /*~T*/
   unsigned char szChecksum[6];

   /*~E:A8*/
   /*~A:9*/
   /*~+:Variableninitialisierungen*/
   /*~T*/

   /*~E:A9*/
   /*~T*/
   sprintf(szChecksum,"%04X",g_uiCRC16);
   /*~T*/
   return szChecksum;
/*~-1*/
}
/*~E:F6*/
/*~E:A5*/
