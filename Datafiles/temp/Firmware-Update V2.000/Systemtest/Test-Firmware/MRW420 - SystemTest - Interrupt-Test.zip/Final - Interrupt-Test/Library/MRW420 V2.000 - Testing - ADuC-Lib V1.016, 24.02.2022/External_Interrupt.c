/*~-1*/
/*~XSF_LANGUAGE: C/C++*/
/*~K*/
/*~+:File :        External_Interrupt.c*/
/*~+:*/
/*~+:Version :     V1.0*/
/*~+:*/
/*~+:Date :        03.06.2005*/
/*~+:*/
/*~+:Time :        10:23*/
/*~+:*/
/*~+:Author :      MOF*/
/*~+:*/
/*~+:Hardware :*/
/*~+:*/
/*~+:Description :*/
/*~+:*/
/*~+:*/
/*~A:1*/
/*~+:Includes*/
/*~T*/
#include "ADuC836.h"
#include "ADuC836Driver.h"
#include "SPI_Global.h"
/*~E:A1*/
/*~A:2*/
/*~+:Funktionseigene Definitionen*/
/*~T*/

/*~E:A2*/
/*~A:3*/
/*~+:Funktionseigene Struktur-Definitionen*/
/*~T*/

/*~E:A3*/
/*~A:4*/
/*~+:Funktionsprototypen*/
/*~T*/

/*~E:A4*/
/*~A:5*/
/*~+:Globale Variablen*/
/*~T*/

/*~E:A5*/
/*~A:6*/
/*~+:void ADuC836_ExternalInterrupt0() interrupt 0*/
/*~F:7*/
void ADuC836_ExternalInterrupt0() interrupt 0 // using 3

/*~-1*/
{
   /*~T*/
   // externe Routine zum Interrupt aufrufen
   External_Interface(0);
   /*~T*/
   IE0 = 0;
/*~-1*/
}
/*~E:F7*/
/*~E:A6*/
/*~A:8*/
/*~+:void ADuC836_ExternalInterrupt1() interrupt 2*/
/*~F:9*/
void ADuC836_ExternalInterrupt1() interrupt 2

/*~-1*/
{
   /*~T*/
   // externe Routine zum Interrupt aufrufen
   External_Interface(1);
   /*~T*/
   IE1 = 0;
/*~-1*/
}
/*~E:F9*/
/*~E:A8*/
