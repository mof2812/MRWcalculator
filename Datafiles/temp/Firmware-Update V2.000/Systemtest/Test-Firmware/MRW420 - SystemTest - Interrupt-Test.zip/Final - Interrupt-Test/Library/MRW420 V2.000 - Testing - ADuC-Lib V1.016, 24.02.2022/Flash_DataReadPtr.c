/*~-1*/
/*~XSF_LANGUAGE: C/C++*/
/*~T*/
/*

   (1) MODULNAME             :  Flash_DataReadPtr.c
   (2) VERSION               :  1.00
   (3) DATUM                 :  17.06.2003

   (4) LETZTE �NDERUNG       :  17.05.2005
   (5) PROJEKT (Vers.)       :  
   (6) PROGRAMMIERER         :  n.l./MOF

*/

/*~A:1*/
/*~+:Includes*/
/*~T*/
#include "ADuC836Driver.h"
/*~E:A1*/
/*~A:2*/
/*~+:Moduleigene Definitionen */
/*~T*/

/*~E:A2*/
/*~A:3*/
/*~+:Funktionsprototypen*/
/*~T*/
char ADuC836_FlashDataReadPtr(void* pData, int nPageNr, unsigned int nAnzahl);
/*~E:A3*/
/*~A:4*/
/*~+:Modulvariablen*/
/*~T*/

/*~E:A4*/
/*~A:5*/
/*~+:char ADuC836_FlashDataReadPtr(void* pData, int nPageNr, unsigned int nAnzahl)*/
/*~F:6*/
char ADuC836_FlashDataReadPtr(void* pData, int nPageNr, unsigned int nAnzahl)
/*~-1*/
{
   /*~A:7*/
   /*~+:Beschreibung*/
   /*~T*/
   /*
   Lese ein Byte aus der angegebenen Page (0...1023). Das 1. Byte der Page wird zur�ckgegeben
   
   R�ckgabe:
   - 0 Funktion konnte erfolgreich durchgef�hrt werden
   -1 Pagenummer ung�ltig
   -2 Allgemeiner Lesefehler 
   
   
   */
   /*~E:A7*/
   /*~A:8*/
   /*~+:Variablendeklarationen*/
   /*~T*/
   signed char cErgebnis = 0;

   unsigned char* pC;
   /*~E:A8*/
   /*~A:9*/
   /*~+:Variableninitialisierungen*/
   /*~T*/

   /*~E:A9*/
   /*~I:10*/
   if (nAnzahl > 0)
   /*~-1*/
   {
      /*~T*/
      // Startadresse sichern
      pC = (unsigned char*)pData;
      /*~L:11*/
      while ((nAnzahl)&&(!cErgebnis))
      /*~-1*/
      {
         /*~I:12*/
         if (ADuC836_FlashDataSetPage(nPageNr) == 0)
         /*~-1*/
         {
            /*~T*/
            ADuC836_FlashReadPage();

            /*~A:13*/
            /*~+:1.Page-Byte lesen*/
            /*~T*/
            *pC = EDATA1;
            pC++;

            /*~E:A13*/
            /*~I:14*/
            if (--nAnzahl)
            /*~-1*/
            {
               /*~A:15*/
               /*~+:2.Page-Byte lesen*/
               /*~T*/
               *pC = EDATA2;
               pC++;

               /*~E:A15*/
               /*~I:16*/
               if (--nAnzahl)
               /*~-1*/
               {
                  /*~A:17*/
                  /*~+:3.Page-Byte lesen*/
                  /*~T*/
                  *pC = EDATA3;
                  pC++;

                  /*~E:A17*/
                  /*~I:18*/
                  if (--nAnzahl)
                  /*~-1*/
                  {
                     /*~A:19*/
                     /*~+:4.Page-Byte lesen*/
                     /*~T*/
                     *pC = EDATA4;
                     pC++;

                     nAnzahl--;

                     /*~E:A19*/
                     /*~T*/
                     nPageNr++;
                  /*~-1*/
                  }
                  /*~E:I18*/
               /*~-1*/
               }
               /*~E:I16*/
            /*~-1*/
            }
            /*~E:I14*/
         /*~-1*/
         }
         /*~O:I12*/
         /*~-2*/
         else
         {
            /*~T*/
            cErgebnis = -1;
         /*~-1*/
         }
         /*~E:I12*/
      /*~-1*/
      }
      /*~E:L11*/
   /*~-1*/
   }
   /*~E:I10*/
   /*~T*/
   return (cErgebnis);
/*~-1*/
}
/*~E:F6*/
/*~E:A5*/
