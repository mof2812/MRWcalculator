/*~-1*/
/*~XSF_LANGUAGE: C/C++*/
/*~K*/
/*~+:File :        ADuC836_Version.c*/
/*~+:*/
/*~+:Version :     V1.000*/
/*~+:*/
/*~+:Date :        21.11.2006*/
/*~+:*/
/*~+:Time :        */
/*~+:*/
/*~+:Author :      MOF*/
/*~+:*/
/*~+:Hardware :*/
/*~+:*/
/*~+:Description :*/
/*~A:1*/
/*~+:Includes*/
/*~T*/
#include "ADuC836Driver.h"
#include "ADuC836_Version.h"
/*~E:A1*/
/*~A:2*/
/*~+:Funktionseigene Definitionen*/
/*~T*/

/*~E:A2*/
/*~A:3*/
/*~+:Funktionseigene Struktur-Definitionen*/
/*~T*/

/*~E:A3*/
/*~A:4*/
/*~+:Funktionsprototypen*/
/*~T*/
char* ADuC836_Version(unsigned char byModul);
/*~E:A4*/
/*~A:5*/
/*~+:Globale Variablen*/
/*~T*/

/*~E:A5*/
/*~A:6*/
/*~+:char* ADuC836_Version(unsigned char byModul)*/
/*~F:7*/
char* ADuC836_Version(unsigned char byModul)
/*~-1*/
{
   /*~C:8*/
   switch (byModul)
   /*~-1*/
   {
      /*~F:9*/
      case ADUC836_ADC_VERSION:
      /*~-1*/
      {
         /*~T*/
         return ADuC836_ADCVersion();
      /*~-1*/
      }
      /*~E:F9*/
      /*~F:10*/
      case ADUC836_DAC_VERSION:
      /*~-1*/
      {
         /*~T*/
         return ADuC836_DACVersion();
      /*~-1*/
      }
      /*~E:F10*/
      /*~F:11*/
      case ADUC836_EXTERNAL_VERSION:
      /*~-1*/
      {
         /*~T*/
         return ADuC836_ExternalVersion();
      /*~-1*/
      }
      /*~E:F11*/
      /*~F:12*/
      case ADUC836_FLASH_VERSION:
      /*~-1*/
      {
         /*~T*/
         return ADuC836_FlashVersion();
      /*~-1*/
      }
      /*~E:F12*/
      /*~F:13*/
      case ADUC836_PROJECT_VERSION:
      /*~-1*/
      {
         /*~T*/
         return ADUC836_SOFTWAREVERSION;
      /*~-1*/
      }
      /*~E:F13*/
      /*~F:14*/
      case ADUC836_RS232_VERSION:
      /*~-1*/
      {
         /*~T*/
         return ADuC836_RS232Version();
      /*~-1*/
      }
      /*~E:F14*/
      /*~F:15*/
      case ADUC836_SPI_VERSION:
      /*~-1*/
      {
         /*~T*/
         return ADuC836_SPIVersion();
      /*~-1*/
      }
      /*~E:F15*/
      /*~F:16*/
      case ADUC836_TIMER_VERSION:
      /*~-1*/
      {
         /*~T*/
         return ADuC836_TimerVersion();
      /*~-1*/
      }
      /*~E:F16*/
      /*~F:17*/
      case ADUC836_WATCHDOG_VERSION:
      /*~-1*/
      {
         /*~T*/
         return ADuC836_WatchdogVersion();
      /*~-1*/
      }
      /*~E:F17*/
      /*~O:C8*/
      /*~-2*/
      default:
      {
         /*~T*/
         return "";
      /*~-1*/
      }
   /*~-1*/
   }
   /*~E:C8*/
/*~-1*/
}
/*~E:F7*/
/*~E:A6*/
