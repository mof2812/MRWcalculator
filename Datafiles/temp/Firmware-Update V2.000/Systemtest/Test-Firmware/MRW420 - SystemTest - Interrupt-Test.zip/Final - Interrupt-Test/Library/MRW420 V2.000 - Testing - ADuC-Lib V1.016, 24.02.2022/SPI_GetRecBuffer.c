/*~-1*/
/*~XSF_LANGUAGE: C/C++*/
/*~K*/
/*~+:File :        SPI_GetRecBuffer.c*/
/*~+:*/
/*~+:Version :     V1.0*/
/*~+:*/
/*~+:Date :        14.06.2005*/
/*~+:*/
/*~+:Time :        10:23*/
/*~+:*/
/*~+:Author :      MOF*/
/*~+:*/
/*~+:Hardware :*/
/*~+:*/
/*~+:Description :*/
/*~A:1*/
/*~+:Includes*/
/*~T*/
#include "ADuC836Driver.h"
#include "SPI_Global.h"
#include <string.h>
/*~E:A1*/
/*~A:2*/
/*~+:Funktionseigene Definitionen*/
/*~T*/
#
/*~E:A2*/
/*~A:3*/
/*~+:Funktionseigene Struktur-Definitionen*/
/*~T*/

/*~E:A3*/
/*~A:4*/
/*~+:Funktionsprototypen*/
/*~T*/
char ADuC836_SPIGetRecBuffer(char* pDest);
/*~E:A4*/
/*~A:5*/
/*~+:Globale Variablen*/
/*~T*/

/*~E:A5*/
/*~A:6*/
/*~+:char ADuC836_SPIGetRecBuffer(char* pDest)*/
/*~F:7*/
char ADuC836_SPIGetRecBuffer(char* pDest)
/*~-1*/
{
   /*~A:8*/
   /*~+:Beschreibung*/
   /*~K*/
   /*~+:/~* ADuC836_SPIGetRecBuffer(char* pDest)*/
   /*~+: */
   /*~+:Ausgabe des Empfangspuffers der SPI-Schnittstelle*/
   /*~+:*/
   /*~+:*/
   /*~+:pDest : Ziel der Ausgabe*/
   /*~+:*/
   /*~+:*/
   /*~+:R�ckgaben :		Daten des Empfangspuffers*/
   /*~+:*~/*/
   /*~+:*/
   /*~E:A8*/
   /*~A:9*/
   /*~+:Variablendeklarationen*/
   /*~T*/
   unsigned int uTimeoutTimer;
   /*~E:A9*/
   /*~A:10*/
   /*~+:Variableninitialisierungen*/
   /*~T*/
   uTimeoutTimer = 0;
   /*~E:A10*/
   /*~I:11*/
   if (SPI.pchRecBuffer[0] != 0)
   /*~-1*/
   {
      /*~T*/
      strcpy(pDest,SPI.pchRecBuffer);

      // Empfangspuffer l�schen und freigeben
      SPI.pchRecBuffer[0] = 0;
      SPI.chNewCommandReceived = 0;
      /*~T*/
      return 0;
   /*~-1*/
   }
   /*~O:I11*/
   /*~-2*/
   else
   {
      /*~T*/
      *(pDest) = 0;
      /*~T*/
      return 1;
   /*~-1*/
   }
   /*~E:I11*/
/*~-1*/
}
/*~E:F7*/
/*~E:A6*/
