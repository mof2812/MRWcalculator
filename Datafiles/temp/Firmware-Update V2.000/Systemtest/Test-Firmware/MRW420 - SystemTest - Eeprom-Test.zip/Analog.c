/*~-1*/
/*~XSF_LANGUAGE: C/C++*/
/*~K*/
/*~+:File :        Analog.c*/
/*~+:*/
/*~+:Version :     V1.0*/
/*~+:*/
/*~+:Date :        25.08.2005*/
/*~+:*/
/*~+:Time :        13:11*/
/*~+:*/
/*~+:Author :      MOF*/
/*~+:*/
/*~+:Hardware :*/
/*~+:*/
/*~+:Description :*/
/*~+:*/
/*~+:*/
/*~A:1*/
/*~+:Includes*/
/*~T*/
// #include "Analog.h"
// #include "ADuC836Driver.h"
#include "Diagnosis.h"
#include "Global.h" 
#include "math.h"
/*~E:A1*/
/*~A:2*/
/*~+:Funktionseigene Definitionen*/
/*~T*/
/// @cond PROGRAMMERS_MANUAL
/*~T*/
/// @endcond
/*~E:A2*/
/*~A:3*/
/*~+:Funktionseigene Struktur-Definitionen*/
/*~T*/
/// @cond PROGRAMMERS_MANUAL
/*~T*/
/// @endcond
/*~E:A3*/
/*~A:4*/
/*~+:Funktionsprototypen*/
/*~T*/
void Analog(void);
void Analog_CheckPowerSupply(long lRMW_PowerSupply );
void Analog_CheckPowerSupplyStatus(void);
char Analog_GetTemperatureOffset(void);
void Analog_Ini(unsigned char chMode);
void Analog_SetTemperatureOffset(char byOffset2Set,char byMode);
/*~E:A4*/
/*~A:5*/
/*~+:Globale Variablen*/
/*~T*/
/// @cond PROGRAMMERS_MANUAL
/*~T*/
/// @endcond
/*~E:A5*/
/*~A:6*/
/*~+:void Analog(void)*/
/*~F:7*/
void Analog(void)
/*~-1*/
{
   /*~A:8*/
   /*~+:Variablendeklarationen*/
   /*~T*/
   unsigned char chADCFlag;
   long lADC_Measurement;
   /*~E:A8*/
   /*~A:9*/
   /*~+:Variableninitialisierungen*/
   /*~T*/

   /*~E:A9*/
   /*~T*/
   chADCFlag = ADuC836_ADCIsNewConversionValue(ADuC836_ADC_AUXILIARY);
   /*~I:10*/
   if (chADCFlag)
   /*~-1*/
   {
      /*~T*/
      lADC_Measurement = ADuC836_ADCGetConversionValue(ADuC836_ADC_AUXILIARY,0);
   /*~-1*/
   }
   /*~O:I10*/
   /*~-2*/
   else
   {
      /*~A:11*/
      /*~+:Kanal 0*/
      /*~I:12*/
#ifdef CHANNEL_0
      /*~T*/
      chADCFlag = ADuC836_ADCIsNewConversionValue(ADuC836_ADC_AUXILIARY_TOGGLE);
      /*~I:13*/
      if (chADCFlag)
      /*~-1*/
      {
         /*~T*/
         lADC_Measurement = ADuC836_ADCGetConversionValue(ADuC836_ADC_AUXILIARY_TOGGLE,0);
      /*~-1*/
      }
      /*~O:I13*/
      /*~-2*/
      else
      {
         /*~T*/
         // Abbruch
         return;
      /*~-1*/
      }
      /*~E:I13*/
      /*~-1*/
#endif
      /*~E:I12*/
      /*~E:A11*/
   /*~-1*/
   }
   /*~E:I10*/
   /*~I:14*/
   if (lADC_Measurement != 0x80000000)
   /*~-1*/
   {
      /*~C:15*/
      switch (chADCFlag)
      /*~-1*/
      {
         /*~F:16*/
         case ANALOG_INPUT_AIN3:
         /*~-1*/
         {
            /*~T*/
            break;
         /*~-1*/
         }
         /*~E:F16*/
         /*~F:17*/
         case ANALOG_INPUT_AIN4:
         /*~-1*/
         {
            /*~T*/
            break;
         /*~-1*/
         }
         /*~E:F17*/
         /*~F:18*/
         case ANALOG_INPUT_TEMPERATURE:
         /*~-1*/
         {
            /*~I:19*/
            if (!(g_SystemControl.bySimulate & 0x02))
            /*~-1*/
            {
               /*~T*/
               Global.byTemperature = (char)((lADC_Measurement / 256 - 128) - Global.byTemperatureOffset);
               /*~A:20*/
               /*~+:Die Temperatur darf sich von einer zur n�chsten Messung um maximal ein Grad �ndern !*/
               /*~I:21*/
               if (Global.byLastTemperature > -128)
               /*~-1*/
               {
                  /*~I:22*/
                  if (Global.byTemperature > Global.byLastTemperature)
                  /*~-1*/
                  {
                     /*~T*/
                     Global.byTemperature = Global.byLastTemperature + 1;
                  /*~-1*/
                  }
                  /*~O:I22*/
                  /*~-2*/
                  else
                  {
                     /*~I:23*/
                     if (Global.byTemperature < Global.byLastTemperature)
                     /*~-1*/
                     {
                        /*~T*/
                        Global.byTemperature = Global.byLastTemperature - 1;
                     /*~-1*/
                     }
                     /*~E:I23*/
                  /*~-1*/
                  }
                  /*~E:I22*/
               /*~-1*/
               }
               /*~O:I21*/
               /*~-2*/
               else
               {
                  /*~T*/
                  // der letzte Temperaturwert ist noch nicht initialisiert
               /*~-1*/
               }
               /*~E:I21*/
               /*~E:A20*/
               /*~T*/
               Global.byLastTemperature = Global.byTemperature; 
            /*~-1*/
            }
            /*~O:I19*/
            /*~-2*/
            else
            {
               /*~A:24*/
               /*~+:Simulation der Temperatur*/
               /*~T*/
               Global.byTemperature = Global.bySimulatedTemperature;
               /*~E:A24*/
            /*~-1*/
            }
            /*~E:I19*/
            /*~T*/
            break;
         /*~-1*/
         }
         /*~E:F18*/
         /*~F:25*/
         case ANALOG_INPUT_AIN5:	// Netzteilspannung
         /*~-1*/
         {
            /*~T*/
            Analog_CheckPowerSupplyStatus();
            /*~A:26*/
            /*~+:Kanal 0*/
            /*~I:27*/
#ifdef CHANNEL_0
            /*~T*/
            // Netzteil pr�fen
            Analog_CheckPowerSupply(lADC_Measurement);
            /*~-1*/
#endif
            /*~E:I27*/
            /*~E:A26*/
            /*~I:28*/
#ifdef VCC_CHECK_ON_BOTH_CHANELS
            /*~A:29*/
            /*~+:Kanal 1*/
            /*~I:30*/
#ifdef CHANNEL_1
            /*~T*/
            // Netzteil pr�fen
            Analog_CheckPowerSupply(lADC_Measurement);
            /*~-1*/
#endif
            /*~E:I30*/
            /*~E:A29*/
            /*~-1*/
#endif
            /*~E:I28*/
            /*~T*/
            break;
         /*~-1*/
         }
         /*~E:F25*/
      /*~-1*/
      }
      /*~E:C15*/
   /*~-1*/
   }
   /*~E:I14*/
/*~-1*/
}
/*~E:F7*/
/*~E:A6*/
/*~A:31*/
/*~+:void Analog_CheckPowerSupply(long lRMW_PowerSupply)*/
/*~F:32*/
void Analog_CheckPowerSupply(long lRMW_PowerSupply)
/*~-1*/
{
   /*~T*/
   Global.lRMW_PowerSupply = lRMW_PowerSupply;
   /*~I:33*/
   if ((lRMW_PowerSupply > OBERE_GRENZE_NETZTEIL)||(lRMW_PowerSupply < UNTERE_GRENZE_NETZTEIL))
   /*~-1*/
   {
      /*~I:34*/
      if (Global.byErrorPowerSupplyCounter > 20)
      /*~-1*/
      {
         /*~A:35*/
         /*~+:Sicherheitsfunktion 'Netzteilspannung' aufrufen*/
         /*~+:*/
         /*~T*/
         // Sicherheitsfunktion 'Netzteilspannung' aufrufen
         Diagnosis_SecurityPowerSupply(POWERSUPPLY_OUT_OF_LIMITS);
         /*~E:A35*/
      /*~-1*/
      }
      /*~O:I34*/
      /*~-2*/
      else
      {
         /*~T*/
         Global.byErrorPowerSupplyCounter++;
      /*~-1*/
      }
      /*~E:I34*/
   /*~-1*/
   }
   /*~O:I33*/
   /*~-2*/
   else
   {
      /*~T*/
      Global.byErrorPowerSupplyCounter= 0;
   /*~-1*/
   }
   /*~E:I33*/
/*~-1*/
}
/*~E:F32*/
/*~E:A31*/
/*~A:36*/
/*~+:void Analog_CheckPowerSupplyStatus(void)*/
/*~F:37*/
void Analog_CheckPowerSupplyStatus(void)
/*~-1*/
{
   /*~I:38*/
   if (!ANALOG_VCC_OK)
   /*~-1*/
   {
      /*~I:39*/
      if (Global.byErrorPowerSupplyStateCounter > 20)
      /*~-1*/
      {
         /*~A:40*/
         /*~+:Sicherheitsfunktion 'Netzteilstatus' aufrufen*/
         /*~+:*/
         /*~T*/
         // Sicherheitsfunktion 'Netzteilstatus' aufrufen
         Diagnosis_SecurityPowerSupply(POWERSUPPLY_VCC_NOK);
         /*~E:A40*/
      /*~-1*/
      }
      /*~O:I39*/
      /*~-2*/
      else
      {
         /*~T*/
         Global.byErrorPowerSupplyStateCounter++;
      /*~-1*/
      }
      /*~E:I39*/
   /*~-1*/
   }
   /*~O:I38*/
   /*~-2*/
   else
   {
      /*~T*/
      Global.byErrorPowerSupplyStateCounter= 0;
   /*~-1*/
   }
   /*~E:I38*/
/*~-1*/
}
/*~E:F37*/
/*~E:A36*/
/*~A:41*/
/*~+:char Analog_GetTemperatureOffset(void)*/
/*~F:42*/
char Analog_GetTemperatureOffset(void)
/*~-1*/
{
   /*~T*/
   return Global.byTemperatureOffset;
/*~-1*/
}
/*~E:F42*/
/*~E:A41*/
/*~A:43*/
/*~+:void Analog_Ini(unsigned char chMode)*/
/*~F:44*/
void Analog_Ini(unsigned char chMode)
/*~-1*/
{
   /*~A:45*/
   /*~+:Variablendeklarationen*/
   /*~T*/
   // Variablendeklarationen
   float fConversationRate;
   /*~E:A45*/
   /*~A:46*/
   /*~+:Variableninitialisierungen*/
   /*~T*/
   // Variableninitialisierungen

   /*~E:A46*/
   /*~I:47*/
   if (!chMode)
   /*~-1*/
   {
      /*~T*/
      Analog_SetTemperatureOffset(0,ANALOG_TEMPERATURE_CALIBRATION_CLEAR_OFFSET);
      /*~T*/
      /* Wandlungsrate abspeichern */
      fConversationRate = SYSTEM_CND_DEFAULT_CONVERSION_RATE_WEIGHT;

      Save_Parameter(LOAD_SAVE_MEASUREMENT_CONVERSIONRATE,&fConversationRate,4);

   /*~-1*/
   }
   /*~O:I47*/
   /*~-2*/
   else
   {
      /*~T*/
      Load_Parameter(LOAD_SAVE_TEMPERATURE_OFFSET,&Global.byTemperatureOffset,1);
      /*~T*/
      /* Wandlungsrate auslesen */
      Load_Parameter(LOAD_SAVE_MEASUREMENT_CONVERSIONRATE,&fConversationRate,4);
      /*~I:48*/
      if ((fConversationRate > 105.3)||(fConversationRate < 5.35))
      /*~-1*/
      {
         /*~T*/
         /* Wandlungsrate abspeichern */
         fConversationRate = SYSTEM_CND_DEFAULT_CONVERSION_RATE_WEIGHT;

         Save_Parameter(LOAD_SAVE_MEASUREMENT_CONVERSIONRATE,&fConversationRate,4);

      /*~-1*/
      }
      /*~E:I48*/
   /*~-1*/
   }
   /*~E:I47*/
   /*~T*/
   /* AD-Wandler initialisieren */
   ADuC836_ADCSetSincFilter(fConversationRate,ADuC836_ADC_FREQUENCY_32KHZ);
   /*~T*/
   Global.byLastTemperature = -128;
   Global.byErrorPowerSupplyCounter = 0;
   Global.byErrorPowerSupplyStateCounter = 0;
/*~-1*/
}
/*~E:F44*/
/*~E:A43*/
/*~A:49*/
/*~+:void Analog_SetTemperatureOffset(char byOffset2Set,char byMode)*/
/*~F:50*/
void Analog_SetTemperatureOffset(char byOffset2Set,char byMode)
/*~-1*/
{
   /*~C:51*/
   switch (byMode)
   /*~-1*/
   {
      /*~F:52*/
      case ANALOG_TEMPERATURE_CALIBRATION_CLEAR_OFFSET:
      /*~-1*/
      {
         /*~T*/
         Global.byTemperatureOffset = 0;
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F52*/
      /*~F:53*/
      case ANALOG_TEMPERATURE_CALIBRATION_SET_OFFSET_MANUALY:
      /*~-1*/
      {
         /*~T*/
         Global.byTemperatureOffset = byOffset2Set;
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F53*/
      /*~F:54*/
      case ANALOG_TEMPERATURE_CALIBRATION_SET_OFFSET_AUTOMATICLY:
      /*~-1*/
      {
         /*~T*/
         /* alt - bis 03.11.2011*/
         /* Global.byTemperatureOffset = Global.byTemperature - byOffset2Set; */
         /* ga�ndert: 03.11.2011 */
         Global.byTemperatureOffset = Global.byTemperatureOffset + Global.byTemperature - byOffset2Set;
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F54*/
   /*~-1*/
   }
   /*~E:C51*/
   /*~T*/
   // 04.11.2016
   Global.byLastTemperature = -128;
   /*~I:55*/
   // 04.11.2016
#ifdef MOF 
   /*~T*/
   // Temperaturen abgleichen
   Global.byTemperature = Global.byTemperature - Global.byTemperatureOffset;
   Global.byLastTemperature = Global.byTemperature;
   /*~-1*/
#endif
   /*~E:I55*/
   /*~T*/
   Save_Parameter(LOAD_SAVE_TEMPERATURE_OFFSET,&Global.byTemperatureOffset,1);
/*~-1*/
}
/*~E:F50*/
/*~E:A49*/
