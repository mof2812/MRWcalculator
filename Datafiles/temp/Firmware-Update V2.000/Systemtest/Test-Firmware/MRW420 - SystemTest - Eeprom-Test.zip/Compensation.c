/*~-1*/
/*~XSF_LANGUAGE: C/C++*/
/*~K*/
/*~+:File :        Compensation.c*/
/*~+:*/
/*~+:Version :     V1.0*/
/*~+:*/
/*~+:Date :        18.10.2005*/
/*~+:*/
/*~+:Time :        10:23*/
/*~+:*/
/*~+:Author :      MOF*/
/*~+:*/
/*~+:Hardware :*/
/*~+:*/
/*~+:Description : Routinen zur Temperaturkompensationsaufnahme. */
/*~+:*/
/*~+:*/
/*~A:1*/
/*~+:Includes*/
/*~T*/
#include "Compensation.h"
#include <stdio.h>
#include <string.h>
/*~E:A1*/
/*~A:2*/
/*~+:Funktionseigene Definitionen*/
/*~T*/
// #define COMPENSATION_OUTPUT_ALL_DATAS		// nur zu Testzwecken

/*~E:A2*/
/*~A:3*/
/*~+:Funktionseigene Struktur-Definitionen*/
/*~T*/

/*~E:A3*/
/*~A:4*/
/*~+:Funktionsprototypen*/
/*~T*/
void 			Compensation(void);
int  			Compensation_GetCompensationValue(char byTemperature);
void 			Compensation_Ini(unsigned char byMode);
void 			Compensation_PrintCompensationValues(unsigned char chWhat2Print,unsigned char chSelection,char chAddParameter,unsigned char byPrintChannelHeader);

char 			Compensation_SetCompensationValues(char chTemperature, int nValue2Set);
void 			Compensation_SuppressOutput(unsigned char bSuppress);
/*~E:A4*/
/*~A:5*/
/*~+:Globale Variablen*/
/*~T*/
unsigned char	g_chCompensationState;
unsigned long 	g_ulCompensationStarted;
unsigned char	g_bySuppressOutput;
/*~I:6*/
#ifdef CHANNEL_0
/*~T*/
unsigned char	g_byPrintState;
unsigned char 	bySelection;
/*~-1*/
#endif
/*~E:I6*/
/*~E:A5*/
/*~A:7*/
/*~+:void 			Compensation(void)*/
/*~F:8*/
void Compensation(void)
/*~-1*/
{
   /*~A:9*/
   /*~+:Beschreibung*/
   /*~T*/
   /*!
   \fn void Compensation(void)
   
   <b>Beschreibung:</b><br>
   Funktion zur Kennlinienaufnahme.
   Aufgrund der vielen Ausgaben, mu� diese in mehreren Zyklen abgearbeitet werden.
   
   \param
   ./.
   
   \return
   ./.
   
   <b>Zugriff:</b><br>
   [X] �ffentlich / [ ] Privat
   */
   /*~E:A9*/
   /*~A:10*/
   /*~+:Variablendeklarationen*/
   /*~T*/
   char byInitPhase;
   static char	bTemperatureCalibrationSet;
   unsigned char byCounter;
   /*~I:11*/
#ifdef CHANNEL_0
   /*~T*/
   unsigned char byStopOutput;
   /*~-1*/
#endif
   /*~E:I11*/
   /*~E:A10*/
   /*~A:12*/
   /*~+:Variableninitialisierungen*/
   /*~T*/
   byCounter = 3;
   /*~I:13*/
#ifdef CHANNEL_0
   /*~T*/
   byStopOutput = 0x00;
   /*~-1*/
#endif
   /*~E:I13*/
   /*~E:A12*/
   /*~I:14*/
   // fragt 'g_TemperatureCompensation.byRecCharacteristicsOn' ab
   if (MRW_Compensation_GetRecCharacteristicsOnOffStatus())
   /*~-1*/
   {
      /*~I:15*/
      if (Flag1000ms)
      /*~-1*/
      {
         /*~K*/
         /*~+:// Aufnahme der Kennlinie gestartet*/
         /*~I:16*/
#ifdef MIT_TEMPERATURSIMULATION 
         /*~T*/
         Simulator_Simulate();

         Global.byTemperature = (int)Simulator_GetSimulatedValue() - Global.byTemperatureOffset;
         /*~-1*/
#endif
         /*~E:I16*/
         /*~T*/
         // Kennlinienaufnahme gestartet

         // Status auslesen
         MRW_Compensation_GetData(MRW_COMPENSATION_GET_STATUS,0,&COMPENSATION_STATE);
         /*~A:17*/
         /*~+:Kompensation gerade gestartet ?*/
         /*~I:18*/
         // if (chRecCharacteristicsStatus == MRW_COMPENSATION_STATE_INIT)
         if (COMPENSATION_STATE == MRW_COMPENSATION_STATE_INIT)
         /*~-1*/
         {
            /*~I:19*/
#ifdef SYSTEM_CND_WITH_DEADBAND_FILTER
            /*~T*/
            // Totbandfilter deaktivieren
            DeadBandFilter_SetFilterOn(0);
            /*~-1*/
#endif
            /*~E:I19*/
            /*~T*/
            // Merker f�r Initialisierungsphase
            byInitPhase = 1;

            // Merker f�r gesetzte Temperaturkalibrierung l�schen
            bTemperatureCalibrationSet = 0;

            //	Startzeitpunkt merken
            g_ulCompensationStarted = SYSTEMTIME;

            // Temperaturkalibrierung l�schen
            Analog_SetTemperatureOffset(0,ANALOG_TEMPERATURE_CALIBRATION_CLEAR_OFFSET);
            /*~I:20*/
#ifdef CHANNEL_0
            /*~T*/
            // Ausgabe starten
            /*~I:21*/
            if (g_bySuppressOutput == 0)
            /*~-1*/
            {
               /*~T*/
               // zyklische Ausgabe starten
               g_byPrintState = 1;


            /*~-1*/
            }
            /*~E:I21*/
            /*~-1*/
#endif
            /*~E:I20*/
         /*~-1*/
         }
         /*~O:I18*/
         /*~-2*/
         else
         {
            /*~T*/
            // Merker f�r Initialisierungsphase l�schen
            byInitPhase = 0;

         /*~-1*/
         }
         /*~E:I18*/
         /*~E:A17*/
         /*~T*/
         COMPENSATION_STATE = MRW_Compensation_RecCharacteristics(Weight_FilteredMeasurement.nLong,Global.byTemperature);
         /*~A:22*/
         /*~+:Zeit zur Temperaturkalibrierung ?*/
         /*~I:23*/
         // if (chRecCharacteristicsStatus == MRW_COMPENSATION_STATE_REC_1ST_RMW20)
         if (COMPENSATION_STATE == MRW_COMPENSATION_STATE_REC_1ST_RMW20)
         /*~-1*/
         {
            /*~I:24*/
            if (!bTemperatureCalibrationSet)
            /*~-1*/
            {
               /*~T*/
               // Temperaturkompensation durchf�hren - Isttemperatur sei 20�C
               Analog_SetTemperatureOffset(20,ANALOG_TEMPERATURE_CALIBRATION_SET_OFFSET_AUTOMATICLY);

               // Merker f�r erfolgte Temperaturkalibrierung setzen
               bTemperatureCalibrationSet = 1;

            /*~-1*/
            }
            /*~E:I24*/
         /*~-1*/
         }
         /*~E:I23*/
         /*~E:A22*/
         /*~A:25*/
         /*~+:Zeit zum L�schen der Absolut- und Relativ-Statistik ?*/
         /*~I:26*/
         // if (chRecCharacteristicsStatus  == MRW_COMPENSATION_STATE_ANALYSIS)
         if (COMPENSATION_STATE == MRW_COMPENSATION_STATE_ANALYSIS)
         /*~-1*/
         {
            /*~T*/
            // Zeit zum L�schen der Absolut- und Relativ-Statistik
            Statistics_Clear(15);
         /*~-1*/
         }
         /*~E:I26*/
         /*~E:A25*/
         /*~A:27*/
         /*~+:Systemstatus setzen*/
         /*~I:28*/
         //Systemstatus setzen

         // if (chRecCharacteristicsStatus <= MRW_COMPENSATION_STATE_REC_1ST_RMW20)
         if(COMPENSATION_STATE <= MRW_COMPENSATION_STATE_REC_1ST_RMW20)
         /*~-1*/
         {
            /*~T*/
            System_SetSystemState(SYSTEM_REC_CHARACTERISTICS_ON);
         /*~-1*/
         }
         /*~O:I28*/
         /*~-2*/
         else
         {
            /*~I:29*/
            // if (chRecCharacteristicsStatus <= MRW_COMPENSATION_STATE_ANALYSIS)
            if (COMPENSATION_STATE <= MRW_COMPENSATION_STATE_ANALYSIS)
            /*~-1*/
            {
               /*~T*/
               System_SetSystemState(SYSTEM_REC_CHARACTERISTICS_1ST_DRIFT);
            /*~-1*/
            }
            /*~O:I29*/
            /*~-2*/
            else
            {
               /*~I:30*/
               // if (chRecCharacteristicsStatus == MRW_COMPENSATION_STATE_READY)
               if (COMPENSATION_STATE == MRW_COMPENSATION_STATE_READY)
               /*~-1*/
               {
                  /*~I:31*/
                  if (SYSTEMSTATE != SYSTEM_REC_CHARACTERISTICS_OKAY)
                  /*~-1*/
                  {
                     /*~T*/
                     System_SetSystemState(SYSTEM_REC_CHARACTERISTICS_OKAY);
                     /*~A:32*/
                     /*~+:Eintrag in Diagnosespeicher vornehmen*/
                     /*~T*/
                     Diagnosis_WriteMessage2Flash(DIAGNOSIS_MESSAGE_TEMPCOMPENSATION_FINISHED_OK);
                     /*~E:A32*/
                  /*~-1*/
                  }
                  /*~E:I31*/
               /*~-1*/
               }
               /*~O:I30*/
               /*~-2*/
               else
               {
                  /*~I:33*/
                  if (SYSTEMSTATE != SYSTEM_REC_CHARACTERISTICS_ERROR)
                  /*~-1*/
                  {
                     /*~T*/
                     System_SetSystemState(SYSTEM_REC_CHARACTERISTICS_ERROR);
                     /*~A:34*/
                     /*~+:Eintrag in Diagnosespeicher vornehmen*/
                     /*~T*/
                     Diagnosis_WriteMessage2Flash(DIAGNOSIS_MESSAGE_TEMPCOMPENSATION_FINISHED_NOK);
                     /*~E:A34*/
                  /*~-1*/
                  }
                  /*~E:I33*/
               /*~-1*/
               }
               /*~E:I30*/
            /*~-1*/
            }
            /*~E:I29*/
         /*~-1*/
         }
         /*~E:I28*/
         /*~E:A27*/
         /*~I:35*/
#ifdef CHANNEL_0
         /*~I:36*/
         if (!byInitPhase)
         /*~-1*/
         {
            /*~I:37*/
            if
            (
            	(SYSTEMSTATE >= SYSTEM_REC_CHARACTERISTICS_ERROR)
            	&&
            	(SYSTEMSTATE_PARTNER >= SYSTEM_REC_CHARACTERISTICS_ERROR)
            )
            /*~-1*/
            {
               /*~T*/
               g_byPrintState |= 0x10;
               /*~I:38*/
#ifdef SYSTEM_CND_WITH_DEADBAND_FILTER
               /*~T*/
               // Totbandfilter wieder aktivieren
               DeadBandFilter_SetFilterOn(1);
               /*~-1*/
#endif
               /*~E:I38*/
            /*~-1*/
            }
            /*~E:I37*/
         /*~-1*/
         }
         /*~E:I36*/
         /*~A:39*/
         /*~+:Ausgabe*/
         /*~F:40*/
         // neu ab Version V1.006
         /*~-1*/
         {
            /*~I:41*/
#ifdef CHANNEL_0
            /*~K*/
            /*~+:Ausgabe Kanal 0*/
            /*~C:42*/
            switch (g_byPrintState & 0x0F)
            /*~-1*/
            {
               /*~F:43*/
               case 1:
               /*~-1*/
               {
                  /*~T*/
                  Compensation_PrintCompensationValues(0,0xFF,0,1);
                  /*~T*/
                  g_byPrintState++;
                  /*~I:44*/
                  if (g_byPrintState & 0x10)
                  /*~-1*/
                  {
                     /*~T*/
                     g_byPrintState |= 0x20;
                  /*~-1*/
                  }
                  /*~E:I44*/
                  /*~T*/
                  break;
               /*~-1*/
               }
               /*~E:F43*/
               /*~K*/
               /*~+:Ausgabe Kanal 1*/
               /*~F:45*/
               case 2:
               /*~-1*/
               {
                  /*~I:46*/
                  if (Communication_IsSPICommuncationDisabled() == FALSE)
                  /*~-1*/
                  {
                     /*~T*/
                     Communication_SendSPICommand("iACS");
                     /*~I:47*/
                     if (g_byPrintState & 0x20)
                     /*~-1*/
                     {
                        /*~T*/
                        // Ausgabe stoppen
                        g_byPrintState = 0x00;
                     /*~-1*/
                     }
                     /*~O:I47*/
                     /*~-2*/
                     else
                     {
                        /*~T*/
                        g_byPrintState = 0x01;
                     /*~-1*/
                     }
                     /*~E:I47*/
                  /*~-1*/
                  }
                  /*~E:I46*/
                  /*~T*/
                  break;
               /*~-1*/
               }
               /*~E:F45*/
            /*~-1*/
            }
            /*~E:C42*/
            /*~-1*/
#endif
            /*~E:I41*/
         /*~-1*/
         }
         /*~E:F40*/
         /*~E:A39*/
         /*~-1*/
#endif
         /*~E:I35*/
      /*~-1*/
      }
      /*~E:I15*/
   /*~-1*/
   }
   /*~E:I14*/
   /*~T*/
   return;
/*~-1*/
}
/*~E:F8*/
/*~E:A7*/
/*~A:48*/
/*~+:int  			Compensation_GetCompensationValue(char byTemperature)*/
/*~F:49*/
int Compensation_GetCompensationValue(char byTemperature)
/*~-1*/
{
   /*~I:50*/
   if (byTemperature == 20)
   /*~-1*/
   {
      /*~T*/
      // Offset bei 20�C
      /*~T*/
      return MRW_Compensation_GetCompensationValue(MRW_COMPENSATION_GET_OFFSET_20,byTemperature);
   /*~-1*/
   }
   /*~O:I50*/
   /*~-2*/
   else
   {
      /*~T*/
      // Kennlinienpunkte
      /*~T*/
      return MRW_Compensation_GetCompensationValue(MRW_COMPENSATION_GET_CHARACTERISTICS,byTemperature);
   /*~-1*/
   }
   /*~E:I50*/
/*~-1*/
}
/*~E:F49*/
/*~E:A48*/
/*~A:51*/
/*~+:void 			Compensation_Ini(unsigned char byMode)*/
/*~F:52*/
void Compensation_Ini(unsigned char byMode)
/*~-1*/
{
   /*~A:53*/
   /*~+:Beschreibung*/
   /*~T*/
   /*!
   \fn unsigned char Correction_Ini(unsigned char byMode)
   
   <b>Beschreibung:</b><br>
   Initialisierung der Korrektur-Funktion.
   
   \param
   byMode:
   \param
   0 = Initialisierung mit Defaultwerten, 
   \param
   1 = Initialisierung mit abgespeicherten Werten.
   
   \return
   
   \retval
   
   
   <b>Zugriff:</b><br>
   [ ] �ffentlich / [X] Privat
   */
   /*~E:A53*/
   /*~T*/
   MRW_Compensation_Init(byMode);
/*~-1*/
}
/*~E:F52*/
/*~E:A51*/
/*~A:54*/
/*~+:void 			Compensation_PrintCompensationValues(unsigned char chWhat2Print,unsigned char chSelection,char chAddParameter,unsigned char byPrintChannelHeader)*/
/*~F:55*/
void Compensation_PrintCompensationValues(unsigned char chWhat2Print,unsigned char chSelection,char chAddParameter,unsigned char byPrintChannelHeader)
/*~-1*/
{
   /*~A:56*/
   /*~+:Variablendeklarationen*/
   /*~T*/
   GLOBAL_UNIVALUE ParameterRead;
   //   char byDocklightModus;
   /*~E:A56*/
   /*~A:57*/
   /*~+:Variableninitialisierungen*/
   /*~T*/

   /*~E:A57*/
   /*~A:58*/
   /*~+:Automatische Umschaltung in den Docklight-Modus - ausgeklammert*/
   /*~I:59*/
#ifdef MOF
   /*~I:60*/
   if (SYSTEM_MRW_MANAGER)
   /*~-1*/
   {
      /*~T*/
      byDocklightModus = 0;
      /*~T*/
      // Automatisch in den Docklight-Modus schalten
      System_Connect2MRW_Manager(0);
   /*~-1*/
   }
   /*~O:I60*/
   /*~-2*/
   else
   {
      /*~T*/
      byDocklightModus = 1;
   /*~-1*/
   }
   /*~E:I60*/
   /*~-1*/
#endif
   /*~E:I59*/
   /*~E:A58*/
   /*~C:61*/
   switch (chWhat2Print)
   /*~-1*/
   {
      /*~I:62*/
#ifdef MOF
      /*~A:63*/
      /*~+:Werte w�hrend der Kennlinienaufnahme und -�berpr�fung (nur �ber Docklight)*/
      /*~F:64*/
      // Werte w�hrend der Kennlinienaufnahme und -�berpr�fung 
      case 0:
      /*~-1*/
      {
         /*~A:65*/
         /*~+:Variablendeklarationen*/
         /*~T*/
         char szString2Send[20];
         unsigned long ulSecondsPast;
         unsigned char chSelectionCopy;
         /*~E:A65*/
         /*~A:66*/
         /*~+:Variableninitialisierungen*/
         /*~T*/
         chSelectionCopy = chSelection;
         /*~A:67*/
         /*~+:ausgeklammert*/
         /*~I:68*/
#ifdef MOF
         /*~I:69*/
         if (g_bySuppressOutput)
         /*~-1*/
         {
            /*~T*/
            chSelectionCopy = chSelection;
         /*~-1*/
         }
         /*~O:I69*/
         /*~-2*/
         else
         {
            /*~T*/
            // Vorbereitung f�r zyklische Ausgabe
            chSelectionCopy = 0;
         /*~-1*/
         }
         /*~E:I69*/
         /*~-1*/
#endif
         /*~E:I68*/
         /*~E:A67*/
         /*~E:A66*/
         /*~T*/
         ulSecondsPast = (SYSTEMTIME - g_ulCompensationStarted) / 1000; 
         /*~I:70*/
#ifdef CHANNEL_0
         /*~C:71*/
         switch (chSelection)
         /*~-1*/
         {
            /*~F:72*/
            case 0:
            /*~-1*/
            {
               /*~A:73*/
               /*~+:Kopf und verstrichene Zeit*/
               /*~I:74*/
               if (!SYSTEM_MRW_MANAGER)
               /*~-1*/
               {
                  /*~I:75*/
                  if (byPrintChannelHeader)
                  /*~-1*/
                  {
                     /*~T*/
                     // Textausgabe Kanal 0
                     Communication_SendString(COMMUNICATION_RS232,T_TEXT_CHANNEL_0,3,0);		// Kanal 0
                     Communication_SendString(COMMUNICATION_RS232,T_TEXT_DOUBLE_LINE,1,1);		// Unterstreichen
                  /*~-1*/
                  }
                  /*~E:I75*/
                  /*~I:76*/
                  if (SYSTEMSTATE < SYSTEM_REC_CHARACTERISTICS_ERROR)
                  /*~-1*/
                  {
                     /*~T*/
                     // Vergangene Zeit seit Start der Aufnahme 
                     sprintf(szString2Send,"%ld (%ld:%02ld:%02ld)",ulSecondsPast,ulSecondsPast / 3600,(ulSecondsPast%3600)/60,ulSecondsPast%60);

                     Communication_SendString(COMMUNICATION_RS232,T_TEXT_COMPENSATION_TIME_LEFT_CHANNEL_0,0,0);

                     Communication_SendString(COMMUNICATION_RS232,szString2Send,0,1);
                  /*~-1*/
                  }
                  /*~E:I76*/
               /*~-1*/
               }
               /*~O:I74*/
               /*~-2*/
               else
               {
                  /*~I:77*/
                  if (SYSTEMSTATE < SYSTEM_REC_CHARACTERISTICS_ERROR)
                  /*~-1*/
                  {
                     /*~T*/
                     // Vergangene Zeit seit Start der Aufnahme 
                     Communication_SendLong(COMMUNICATION_RS232,0,ulSecondsPast,TEXT_COMPENSATION_TIME_LEFT_CHANNEL_0,1);
                  /*~-1*/
                  }
                  /*~E:I77*/
               /*~-1*/
               }
               /*~E:I74*/
               /*~E:A73*/
               /*~T*/
               break;
            /*~-1*/
            }
            /*~E:F72*/
            /*~F:78*/
            case 1:
            /*~-1*/
            {
               /*~I:79*/
               if (SYSTEMSTATE < SYSTEM_REC_CHARACTERISTICS_ERROR)
               /*~-1*/
               {
                  /*~A:80*/
                  /*~+:Status der Kennlinienaufnahme*/
                  /*~+:Temperatur*/
                  /*~+:Rohmesswert vom ADC*/
                  /*~T*/
                  // Status der Kennlinienaufnahme
                  Communication_SendLong(COMMUNICATION_RS232,TEXT_COMPENSATION_STATUS_REC_CHARACTERISTICS_CHANNEL_0,COMPENSATION_STATE,0,1);

                  /*~T*/
                  // Temperatur
                  Communication_SendLong(COMMUNICATION_RS232,TEXT_ACTUAL_TEMPERATURE_CHANNEL_0,Global.byTemperature,0,1);

                  /*~T*/
                  // Rohmesswert vom ADC
                  Communication_SendLong(COMMUNICATION_RS232,TEXT_ADC_ACTUAL_MEASUREMENT_CHANNEL_0,Weight_MeasurementFromADC.nLong,0,1);
                  /*~E:A80*/
               /*~-1*/
               }
               /*~O:I79*/
               /*~-2*/
               else
               {
                  /*~A:81*/
                  /*~+:Ergebnis der Kennlinienaufnahme*/
                  /*~I:82*/
                  if (SYSTEMSTATE == SYSTEM_REC_CHARACTERISTICS_OKAY)
                  /*~-1*/
                  {
                     /*~T*/
                     Communication_SendString(COMMUNICATION_RS232,T_TEXT_COMPENSATION_EVERYTHING_IS_OKAY_CHANNEL_0,2,1);
                  /*~-1*/
                  }
                  /*~O:I82*/
                  /*~-2*/
                  else
                  {
                     /*~T*/
                     Communication_SendString(COMMUNICATION_RS232,T_TEXT_COMPENSATION_FAULTY_CHANNEL_0,2,1);
                  /*~-1*/
                  }
                  /*~E:I82*/
                  /*~E:A81*/
               /*~-1*/
               }
               /*~E:I79*/
               /*~T*/
               break;
            /*~-1*/
            }
            /*~E:F78*/
            /*~F:83*/
            case 2:
            /*~-1*/
            {
               /*~I:84*/
               if (SYSTEMSTATE < SYSTEM_REC_CHARACTERISTICS_ERROR)
               /*~-1*/
               {
                  /*~A:85*/
                  /*~+:gefilterter RMW ohne Nullpunktkorrektur*/
                  /*~+:gefilterter RMW mit Nullpunktkorrektur*/
                  /*~T*/
                  // gefilterter RMW ohne Nullpunktkorrektur
                  Communication_SendLong(COMMUNICATION_RS232,TEXT_MEASUREMENT_ACTUAL_FILTERED_MEASUREMENT_CHANNEL_0,Weight_FilteredMeasurement.nLong,0,1);

                  /*~T*/
                  // gefilterter RMW mit Nullpunktkorrektur
                  Communication_SendLong(COMMUNICATION_RS232,TEXT_ACTUAL_MEASUREMENT_CHANNEL_0,Weight_ZeroCorrectedMeasurement.nLong,0,1);
                  /*~E:A85*/
               /*~-1*/
               }
               /*~E:I84*/
               /*~T*/
               break;
            /*~-1*/
            }
            /*~E:F83*/
            /*~F:86*/
            case 3:
            /*~-1*/
            {
               /*~I:87*/
               if (SYSTEMSTATE < SYSTEM_REC_CHARACTERISTICS_ERROR)
               /*~-1*/
               {
                  /*~A:88*/
                  /*~+:Korrekturwert*/
                  /*~+:Anzahl der aufgenommenen Kennlinienpunkte*/
                  /*~I:89*/
#ifdef COMPENSATION_OUTPUT_ALL_DATAS
                  	if(1)
#else
                  	if ((COMPENSATION_STATE >= MRW_COMPENSATION_STATE_INIT_GET_POINT)&&(COMPENSATION_STATE < 	MRW_COMPENSATION_STATE_SWITCH_COMPENSATION_ON))
#endif
                  /*~-1*/
                  {
                     /*~T*/
                     // Korrekturwert
                     MRW_Compensation_GetData(MRW_COMPENSATION_GET_LAST_CORRVAL,0,&ParameterRead.nInt);

                     Communication_SendLong(COMMUNICATION_RS232,TEXT_COMPENSATION_LAST_CORRECTION_VALUE_CHANNEL_0,ParameterRead.nInt,0,1);
                     /*~T*/
                     // Anzahl der aufgenommenen Kennlinienpunkte
                     MRW_Compensation_GetData(MRW_COMPENSATION_GET_POINTS_RECORDED,0,&ParameterRead.byChar);
                     Communication_SendLong(COMMUNICATION_RS232,TEXT_COMPENSATION_POINTS_RECORDED_CHANNEL_0,ParameterRead.byChar,0,1);
                  /*~-1*/
                  }
                  /*~E:I89*/
                  /*~E:A88*/
               /*~-1*/
               }
               /*~E:I87*/
               /*~T*/
               break;
            /*~-1*/
            }
            /*~E:F86*/
            /*~F:90*/
            case 4:
            /*~-1*/
            {
               /*~I:91*/
               if (SYSTEMSTATE < SYSTEM_REC_CHARACTERISTICS_ERROR)
               /*~-1*/
               {
                  /*~A:92*/
                  /*~+:Maximale Abweichung (Gewicht)*/
                  /*~+:Maximale Abweichung (Temperatur)*/
                  /*~+:Minimale Abweichung (Gewicht)*/
                  /*~+:Minimale Abweichung (Temperatur)*/
                  /*~+:Aktuelle Abweichung*/
                  /*~I:93*/
#ifdef COMPENSATION_OUTPUT_ALL_DATAS
                  	if(1)
#else
                  	if ((COMPENSATION_STATE >= MRW_COMPENSATION_STATE_INIT_TEST_COMPENSATION)&&(COMPENSATION_STATE < MRW_COMPENSATION_STATE_WAIT_TEMP_4_REC_2ND_RMW20))
#endif
                  /*~-1*/
                  {
                     /*~T*/
                     // Maximale Abweichung (Gewicht)
                     MRW_Compensation_GetData(MRW_COMPENSATION_GET_MAXIMUM_KG,0,&ParameterRead.fFloat);
                     Communication_SendFloat(COMMUNICATION_RS232,TEXT_COMPENSATION_MAXIMUM_DEVIATION_CHANNEL_0,ParameterRead.fFloat,2,0,1);

                     /*~T*/
                     // Maximale Abweichung (Temperatur)
                     MRW_Compensation_GetData(MRW_COMPENSATION_GET_MAXIMUM_TEMP,0,&ParameterRead.byChar);

                     /*~T*/
                     Communication_SendLong(COMMUNICATION_RS232,TEXT_COMPENSATION_MAXIMUM_DEVIATION_TEMPERATURE_CHANNEL_0,ParameterRead.byChar,0,1);
                     /*~T*/
                     // Minimale Abweichung (Gewicht)
                     MRW_Compensation_GetData(MRW_COMPENSATION_GET_MINIMUM_KG,0,&ParameterRead.fFloat);
                     Communication_SendFloat(COMMUNICATION_RS232,TEXT_COMPENSATION_MINIMUM_DEVIATION_CHANNEL_0,ParameterRead.fFloat,2,0,1);
                     /*~T*/
                     // Minimale Abweichung (Temperatur)
                     MRW_Compensation_GetData(MRW_COMPENSATION_GET_MINIMUM_TEMP,0,&ParameterRead.byChar);
                     /*~T*/
                     Communication_SendLong(COMMUNICATION_RS232,TEXT_COMPENSATION_MINIMUM_DEVIATION_TEMPERATURE_CHANNEL_0,ParameterRead.byChar,0,1);
                     /*~T*/
                     // Aktuelle Abweichung
                     MRW_Compensation_GetData(MRW_COMPENSATION_GET_DEVIATION_KG,0,&ParameterRead.fFloat);
                     Communication_SendFloat(COMMUNICATION_RS232,TEXT_COMPENSATION_ACTUAL_DEVIATION_CHANNEL_0,ParameterRead.fFloat,2,0,1);
                  /*~-1*/
                  }
                  /*~E:I93*/
                  /*~E:A92*/
               /*~-1*/
               }
               /*~E:I91*/
               /*~T*/
               break;
            /*~-1*/
            }
            /*~E:F90*/
            /*~F:94*/
            case 5:
            /*~-1*/
            {
               /*~I:95*/
               if (SYSTEMSTATE < SYSTEM_REC_CHARACTERISTICS_ERROR)
               /*~-1*/
               {
                  /*~A:96*/
                  /*~+:Soll-Ausgangsstrom*/
                  /*~+:Ist-Ausgangsstrom*/
                  /*~+:Versorgungsspannung*/
                  /*~T*/
                  // Soll-Ausgangsstrom
                  Communication_SendFloat(COMMUNICATION_RS232,TEXT_CURRENT_INTERFACE_ACTUAL_CURRENT_CHANNEL_0,CurrentInterface_GetCurrent(0),3,0,1);
                  /*~T*/
                  // Ist-Ausgangsstrom
                  Communication_SendFloat(COMMUNICATION_RS232,TEXT_CURRENT_INTERFACE_ACTUAL_CURRENT_MEASURED_CHANNEL_0,CurrentInterface_GetCurrent(1),3,0,1);
                  /*~T*/
                  // Spannung der Versorgungsspannung
                  Communication_SendLong(COMMUNICATION_RS232,TEXT_POWERSUPPLY_CHANNEL_0,Global.lRMW_PowerSupply,0,1);

                  /*~E:A96*/
               /*~-1*/
               }
               /*~E:I95*/
               /*~T*/
               break;
            /*~-1*/
            }
            /*~E:F94*/
            /*~F:97*/
            case 6:	// letzter Status !!!
            /*~-1*/
            {
               /*~A:98*/
               /*~+:Partner-Status der Kennlinienaufnahme*/
               /*~T*/
               // Partner-Status der Kennlinienaufnahme
               Communication_SendLong(COMMUNICATION_RS232,TEXT_COMPENSATION_STATUS_REC_CHARACTERISTICS_CHANNEL_1,SYSTEMSTATE_PARTNER,0,1);
               /*~E:A98*/
               /*~T*/
               break;
            /*~-1*/
            }
            /*~E:F97*/
            /*~O:C71*/
            /*~-2*/
            default:
            {
               /*~A:99*/
               /*~+:Fehler - E001 senden*/
               /*~T*/
               Communication_SendString(COMMUNICATION_RS232,TEXT_E001,1,0);
               /*~E:A99*/
            /*~-1*/
            }
         /*~-1*/
         }
         /*~E:C71*/
         /*~-1*/
#endif
         /*~E:I70*/
         /*~I:100*/
#ifdef CHANNEL_1
         /*~C:101*/
         switch (chSelectionCopy)
         /*~-1*/
         {
            /*~F:102*/
            case 0:
            /*~-1*/
            {
               /*~A:103*/
               /*~+:Kopf und verstrichene Zeit*/
               /*~I:104*/
               if (!SYSTEM_MRW_MANAGER)
               /*~-1*/
               {
                  /*~I:105*/
                  if (byPrintChannelHeader)
                  /*~-1*/
                  {
                     /*~T*/
                     // Textausgabe Kanal 0
                     Communication_SendString(COMMUNICATION_RS232,T_TEXT_CHANNEL_1,3,0);		// Kanal 0
                     Communication_SendString(COMMUNICATION_RS232,T_TEXT_DOUBLE_LINE,1,1);		// Unterstreichen
                  /*~-1*/
                  }
                  /*~E:I105*/
                  /*~I:106*/
                  if (SYSTEMSTATE < SYSTEM_REC_CHARACTERISTICS_ERROR)
                  /*~-1*/
                  {
                     /*~T*/
                     // Vergangene Zeit seit Start der Aufnahme 
                     sprintf(szString2Send,"%ld (%ld:%02ld:%02ld)",ulSecondsPast,ulSecondsPast / 3600,(ulSecondsPast%3600)/60,ulSecondsPast%60);

                     Communication_SendString(COMMUNICATION_RS232,T_TEXT_COMPENSATION_TIME_LEFT_CHANNEL_1,0,0);

                     Communication_SendString(COMMUNICATION_RS232,szString2Send,0,1);
                  /*~-1*/
                  }
                  /*~E:I106*/
               /*~-1*/
               }
               /*~O:I104*/
               /*~-2*/
               else
               {
                  /*~I:107*/
                  if (SYSTEMSTATE < SYSTEM_REC_CHARACTERISTICS_ERROR)
                  /*~-1*/
                  {
                     /*~T*/
                     // Vergangene Zeit seit Start der Aufnahme 
                     Communication_SendLong(COMMUNICATION_RS232,0,ulSecondsPast,TEXT_COMPENSATION_TIME_LEFT_CHANNEL_1,1);
                  /*~-1*/
                  }
                  /*~E:I107*/
               /*~-1*/
               }
               /*~E:I104*/
               /*~E:A103*/
               /*~T*/
               break;
            /*~-1*/
            }
            /*~E:F102*/
            /*~F:108*/
            case 1:
            /*~-1*/
            {
               /*~I:109*/
               if (SYSTEMSTATE < SYSTEM_REC_CHARACTERISTICS_ERROR)
               /*~-1*/
               {
                  /*~A:110*/
                  /*~+:Status der Kennlinienaufnahme*/
                  /*~+:Temperatur*/
                  /*~+:Rohmesswert vom ADC*/
                  /*~T*/
                  // Status der Kennlinienaufnahme
                  Communication_SendLong(COMMUNICATION_RS232,TEXT_COMPENSATION_STATUS_REC_CHARACTERISTICS_CHANNEL_1,COMPENSATION_STATE,0,1);

                  /*~T*/
                  // Temperatur
                  Communication_SendLong(COMMUNICATION_RS232,TEXT_ACTUAL_TEMPERATURE_CHANNEL_1,Global.byTemperature,0,1);

                  /*~T*/
                  // Rohmesswert vom ADC
                  Communication_SendLong(COMMUNICATION_RS232,TEXT_ADC_ACTUAL_MEASUREMENT_CHANNEL_1,Weight_MeasurementFromADC.nLong,0,1);
                  /*~E:A110*/
               /*~-1*/
               }
               /*~O:I109*/
               /*~-2*/
               else
               {
                  /*~A:111*/
                  /*~+:Ergebnis der Kennlinienaufnahme*/
                  /*~I:112*/
                  if (SYSTEMSTATE == SYSTEM_REC_CHARACTERISTICS_OKAY)
                  /*~-1*/
                  {
                     /*~T*/
                     Communication_SendString(COMMUNICATION_RS232,T_TEXT_COMPENSATION_EVERYTHING_IS_OKAY_CHANNEL_1,0,1);
                  /*~-1*/
                  }
                  /*~O:I112*/
                  /*~-2*/
                  else
                  {
                     /*~T*/
                     Communication_SendString(COMMUNICATION_RS232,T_TEXT_COMPENSATION_FAULTY_CHANNEL_0,0,1);
                  /*~-1*/
                  }
                  /*~E:I112*/
                  /*~E:A111*/
               /*~-1*/
               }
               /*~E:I109*/
               /*~T*/
               break;
            /*~-1*/
            }
            /*~E:F108*/
            /*~F:113*/
            case 2:
            /*~-1*/
            {
               /*~I:114*/
               if (SYSTEMSTATE < SYSTEM_REC_CHARACTERISTICS_ERROR)
               /*~-1*/
               {
                  /*~A:115*/
                  /*~+:gefilterter RMW ohne Nullpunktkorrektur*/
                  /*~+:gefilterter RMW mit Nullpunktkorrektur*/
                  /*~T*/
                  // gefilterter RMW ohne Nullpunktkorrektur
                  Communication_SendLong(COMMUNICATION_RS232,TEXT_MEASUREMENT_ACTUAL_FILTERED_MEASUREMENT_CHANNEL_1,Weight_FilteredMeasurement.nLong,0,1);

                  /*~T*/
                  // gefilterter RMW mit Nullpunktkorrektur
                  Communication_SendLong(COMMUNICATION_RS232,TEXT_ACTUAL_MEASUREMENT_CHANNEL_1,Weight_ZeroCorrectedMeasurement.nLong,0,1);
                  /*~E:A115*/
               /*~-1*/
               }
               /*~E:I114*/
               /*~T*/
               break;
            /*~-1*/
            }
            /*~E:F113*/
            /*~F:116*/
            case 3:
            /*~-1*/
            {
               /*~I:117*/
               if (SYSTEMSTATE < SYSTEM_REC_CHARACTERISTICS_ERROR)
               /*~-1*/
               {
                  /*~A:118*/
                  /*~+:Korrekturwert*/
                  /*~+:Anzahl der aufgenommenen Kennlinienpunkte*/
                  /*~I:119*/
#ifdef COMPENSATION_OUTPUT_ALL_DATAS
                  	if(1)
#else
                  	if ((COMPENSATION_STATE >= MRW_COMPENSATION_STATE_INIT_GET_POINT)&&(COMPENSATION_STATE < 	MRW_COMPENSATION_STATE_SWITCH_COMPENSATION_ON))
#endif
                  /*~-1*/
                  {
                     /*~T*/
                     // Korrekturwert
                     MRW_Compensation_GetData(MRW_COMPENSATION_GET_LAST_CORRVAL,0,&ParameterRead.nInt);

                     Communication_SendLong(COMMUNICATION_RS232,TEXT_COMPENSATION_LAST_CORRECTION_VALUE_CHANNEL_1,ParameterRead.nInt,0,1);
                     /*~T*/
                     // Anzahl der aufgenommenen Kennlinienpunkte
                     MRW_Compensation_GetData(MRW_COMPENSATION_GET_POINTS_RECORDED,0,&ParameterRead.byChar);
                     Communication_SendLong(COMMUNICATION_RS232,TEXT_COMPENSATION_POINTS_RECORDED_CHANNEL_1,ParameterRead.byChar,0,1);
                  /*~-1*/
                  }
                  /*~E:I119*/
                  /*~E:A118*/
               /*~-1*/
               }
               /*~E:I117*/
               /*~T*/
               break;
            /*~-1*/
            }
            /*~E:F116*/
            /*~F:120*/
            case 4:
            /*~-1*/
            {
               /*~I:121*/
               if (SYSTEMSTATE < SYSTEM_REC_CHARACTERISTICS_ERROR)
               /*~-1*/
               {
                  /*~A:122*/
                  /*~+:Maximale Abweichung (Gewicht)*/
                  /*~+:Maximale Abweichung (Temperatur)*/
                  /*~+:Minimale Abweichung (Gewicht)*/
                  /*~+:Minimale Abweichung (Temperatur)*/
                  /*~+:Aktuelle Abweichung*/
                  /*~I:123*/
#ifdef COMPENSATION_OUTPUT_ALL_DATAS
                  	if(1)
#else
                  	if ((COMPENSATION_STATE >= MRW_COMPENSATION_STATE_INIT_TEST_COMPENSATION)&&(COMPENSATION_STATE < MRW_COMPENSATION_STATE_WAIT_TEMP_4_REC_2ND_RMW20))
#endif
                  /*~-1*/
                  {
                     /*~T*/
                     // Maximale Abweichung (Gewicht)
                     MRW_Compensation_GetData(MRW_COMPENSATION_GET_MAXIMUM_KG,0,&ParameterRead.fFloat);
                     Communication_SendFloat(COMMUNICATION_RS232,TEXT_COMPENSATION_MAXIMUM_DEVIATION_CHANNEL_1,ParameterRead.fFloat,2,0,1);

                     /*~T*/
                     // Maximale Abweichung (Temperatur)
                     MRW_Compensation_GetData(MRW_COMPENSATION_GET_MAXIMUM_TEMP,0,&ParameterRead.byChar);

                     /*~T*/
                     Communication_SendLong(COMMUNICATION_RS232,TEXT_COMPENSATION_MAXIMUM_DEVIATION_TEMPERATURE_CHANNEL_1,ParameterRead.byChar,0,1);
                     /*~T*/
                     // Minimale Abweichung (Gewicht)
                     MRW_Compensation_GetData(MRW_COMPENSATION_GET_MINIMUM_KG,0,&ParameterRead.fFloat);
                     Communication_SendFloat(COMMUNICATION_RS232,TEXT_COMPENSATION_MINIMUM_DEVIATION_CHANNEL_1,ParameterRead.fFloat,2,0,1);
                     /*~T*/
                     // Minimale Abweichung (Temperatur)
                     MRW_Compensation_GetData(MRW_COMPENSATION_GET_MINIMUM_TEMP,0,&ParameterRead.byChar);
                     /*~T*/
                     Communication_SendLong(COMMUNICATION_RS232,TEXT_COMPENSATION_MINIMUM_DEVIATION_TEMPERATURE_CHANNEL_1,ParameterRead.byChar,0,1);
                     /*~T*/
                     // Aktuelle Abweichung
                     MRW_Compensation_GetData(MRW_COMPENSATION_GET_DEVIATION_KG,0,&ParameterRead.fFloat);
                     Communication_SendFloat(COMMUNICATION_RS232,TEXT_COMPENSATION_ACTUAL_DEVIATION_CHANNEL_1,ParameterRead.fFloat,2,0,1);
                  /*~-1*/
                  }
                  /*~E:I123*/
                  /*~E:A122*/
               /*~-1*/
               }
               /*~E:I121*/
               /*~T*/
               break;
            /*~-1*/
            }
            /*~E:F120*/
            /*~F:124*/
            case 5:
            /*~-1*/
            {
               /*~I:125*/
               if (SYSTEMSTATE < SYSTEM_REC_CHARACTERISTICS_ERROR)
               /*~-1*/
               {
                  /*~A:126*/
                  /*~+:Soll-Ausgangsstrom*/
                  /*~+:Ist-Ausgangsstrom*/
                  /*~+:Versorgungsspannung*/
                  /*~T*/
                  // Soll-Ausgangsstrom
                  Communication_SendFloat(COMMUNICATION_RS232,TEXT_CURRENT_INTERFACE_ACTUAL_CURRENT_CHANNEL_1,CurrentInterface_GetCurrent(0),3,0,1);
                  /*~T*/
                  // Ist-Ausgangsstrom
                  Communication_SendFloat(COMMUNICATION_RS232,TEXT_CURRENT_INTERFACE_ACTUAL_CURRENT_MEASURED_CHANNEL_1,CurrentInterface_GetCurrent(1),3,0,1);
                  /*~I:127*/
#ifdef VCC_CHECK_ON_BOTH_CHANELS
                  /*~T*/
                  // Spannung der Versorgungsspannung
                  Communication_SendLong(COMMUNICATION_RS232,TEXT_POWERSUPPLY_CHANNEL_1,Global.lRMW_PowerSupply,0,1);

                  /*~-1*/
#endif
                  /*~E:I127*/
                  /*~E:A126*/
               /*~-1*/
               }
               /*~E:I125*/
               /*~T*/
               break;
            /*~-1*/
            }
            /*~E:F124*/
            /*~F:128*/
            case 6:	// letzter Status !!!
            /*~-1*/
            {
               /*~A:129*/
               /*~+:Partner-Status der Kennlinienaufnahme*/
               /*~T*/
               // Da die Ausgabe l�nger dauern kann, Watchdog retriggern
               Watchdog();
               /*~T*/
               // Partner-Status der Kennlinienaufnahme
               Communication_SendLong(COMMUNICATION_RS232,TEXT_COMPENSATION_STATUS_REC_CHARACTERISTICS_CHANNEL_0,SYSTEMSTATE_PARTNER,0,1);
               /*~E:A129*/
               /*~T*/
               break;
            /*~-1*/
            }
            /*~E:F128*/
         /*~-1*/
         }
         /*~E:C101*/
         /*~-1*/
#endif
         /*~E:I100*/
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F64*/
      /*~E:A63*/
      /*~-1*/
#endif
      /*~E:I62*/
      /*~A:130*/
      /*~+:Werte w�hrend der Kennlinienaufnahme und -�berpr�fung (nur �ber Docklight)*/
      /*~F:131*/
      // Werte w�hrend der Kennlinienaufnahme und -�berpr�fung 
      case 0:
      /*~-1*/
      {
         /*~A:132*/
         /*~+:Variablendeklarationen*/
         /*~T*/
         char szString2Send[20];
         unsigned long ulSecondsPast;
         unsigned char chSelectionCopy;
         /*~E:A132*/
         /*~A:133*/
         /*~+:Variableninitialisierungen*/
         /*~T*/
         chSelectionCopy = chSelection;
         /*~A:134*/
         /*~+:ausgeklammert*/
         /*~I:135*/
#ifdef MOF
         /*~I:136*/
         if (g_bySuppressOutput)
         /*~-1*/
         {
            /*~T*/
            chSelectionCopy = chSelection;
         /*~-1*/
         }
         /*~O:I136*/
         /*~-2*/
         else
         {
            /*~T*/
            // Vorbereitung f�r zyklische Ausgabe
            chSelectionCopy = 0;
         /*~-1*/
         }
         /*~E:I136*/
         /*~-1*/
#endif
         /*~E:I135*/
         /*~E:A134*/
         /*~E:A133*/
         /*~T*/
         ulSecondsPast = (SYSTEMTIME - g_ulCompensationStarted) / 1000; 
         /*~I:137*/
#ifdef CHANNEL_0
         /*~C:138*/
         switch (chSelection)
         /*~-1*/
         {
            /*~F:139*/
            case 17:
            case 0xFF:
            /*~-1*/
            {
               /*~A:140*/
               /*~+:Erfolg oder Misserfolg der Kennlinienaufnahme*/
               /*~I:141*/
               if (COMPENSATION_STATE == MRW_COMPENSATION_STATE_ERROR)
               /*~-1*/
               {
                  /*~T*/
                  Communication_SendString(COMMUNICATION_RS232,T_TEXT_COMPENSATION_FAULTY_CHANNEL_0,2,1);
                  /*~T*/
                  break;
               /*~-1*/
               }
               /*~O:I141*/
               /*~-2*/
               else
               {
                  /*~I:142*/
                  if (COMPENSATION_STATE == MRW_COMPENSATION_STATE_READY)
                  /*~-1*/
                  {
                     /*~T*/
                     Communication_SendString(COMMUNICATION_RS232,T_TEXT_COMPENSATION_EVERYTHING_IS_OKAY_CHANNEL_0,2,1);
                     /*~T*/
                     break;
                  /*~-1*/
                  }
                  /*~O:I142*/
                  /*~-2*/
                  else
                  {
                     /*~I:143*/
                     if (chSelection != 0xFF)
                     /*~-1*/
                     {
                        /*~T*/
                        break;
                     /*~-1*/
                     }
                     /*~E:I143*/
                  /*~-1*/
                  }
                  /*~E:I142*/
               /*~-1*/
               }
               /*~E:I141*/
               /*~E:A140*/
            /*~-1*/
            }
            /*~E:F139*/
            /*~F:144*/
            case 0:
            /*~-1*/
            {
               /*~A:145*/
               /*~+:Kopf und verstrichene Zeit*/
               /*~I:146*/
               if (!SYSTEM_MRW_MANAGER)
               /*~-1*/
               {
                  /*~I:147*/
                  if (byPrintChannelHeader)
                  /*~-1*/
                  {
                     /*~T*/
                     // Textausgabe Kanal 0
                     Communication_SendString(COMMUNICATION_RS232,T_TEXT_CHANNEL_0,3,0);		// Kanal 0
                     Communication_SendString(COMMUNICATION_RS232,T_TEXT_DOUBLE_LINE,1,1);		// Unterstreichen
                  /*~-1*/
                  }
                  /*~E:I147*/
                  /*~A:148*/
                  /*~+:ausgeklammert*/
                  /*~I:149*/
#ifdef MOF
                  /*~I:150*/
                  if (!g_bySuppressOutput)
                  /*~-1*/
                  {
                     /*~T*/
                     // Textausgabe Kanal 0
                     Communication_SendString(COMMUNICATION_RS232,T_TEXT_CHANNEL_0,3,0);		// Kanal 0
                     Communication_SendString(COMMUNICATION_RS232,T_TEXT_DOUBLE_LINE,1,1);		// Unterstreichen
                  /*~-1*/
                  }
                  /*~E:I150*/
                  /*~-1*/
#endif
                  /*~E:I149*/
                  /*~E:A148*/
                  /*~T*/
                  // Vergangene Zeit seit Start der Aufnahme 
                  sprintf(szString2Send,"%ld (%ld:%02ld:%02ld)",ulSecondsPast,ulSecondsPast / 3600,(ulSecondsPast%3600)/60,ulSecondsPast%60);

                  Communication_SendString(COMMUNICATION_RS232,T_TEXT_COMPENSATION_TIME_LEFT_CHANNEL_0,0,0);

                  Communication_SendString(COMMUNICATION_RS232,szString2Send,0,1);
               /*~-1*/
               }
               /*~O:I146*/
               /*~-2*/
               else
               {
                  /*~T*/
                  // Vergangene Zeit seit Start der Aufnahme 
                  Communication_SendLong(COMMUNICATION_RS232,0,ulSecondsPast,TEXT_COMPENSATION_TIME_LEFT_CHANNEL_0,1);
               /*~-1*/
               }
               /*~E:I146*/
               /*~I:151*/
               if (chSelection != 0xFF)
               /*~-1*/
               {
                  /*~T*/
                  break;
               /*~-1*/
               }
               /*~E:I151*/
               /*~E:A145*/
            /*~-1*/
            }
            /*~E:F144*/
            /*~F:152*/
            case 1:
            /*~-1*/
            {
               /*~A:153*/
               /*~+:Status der Kennlinienaufnahme*/
               /*~T*/
               // Status der Kennlinienaufnahme
               Communication_SendLong(COMMUNICATION_RS232,TEXT_COMPENSATION_STATUS_REC_CHARACTERISTICS_CHANNEL_0,COMPENSATION_STATE,0,1);

               /*~I:154*/
               if (chSelection != 0xFF)
               /*~-1*/
               {
                  /*~T*/
                  break;
               /*~-1*/
               }
               /*~E:I154*/
               /*~E:A153*/
            /*~-1*/
            }
            /*~E:F152*/
            /*~F:155*/
            case 2:
            /*~-1*/
            {
               /*~A:156*/
               /*~+:Temperatur*/
               /*~T*/
               // Temperatur
               Communication_SendLong(COMMUNICATION_RS232,TEXT_ACTUAL_TEMPERATURE_CHANNEL_0,Global.byTemperature,0,1);

               /*~I:157*/
               if (chSelection != 0xFF)
               /*~-1*/
               {
                  /*~T*/
                  break;
               /*~-1*/
               }
               /*~E:I157*/
               /*~E:A156*/
            /*~-1*/
            }
            /*~E:F155*/
            /*~F:158*/
            case 3:
            /*~-1*/
            {
               /*~A:159*/
               /*~+:Rohmesswert vom ADC*/
               /*~T*/
               // Rohmesswert vom ADC
               Communication_SendLong(COMMUNICATION_RS232,TEXT_ADC_ACTUAL_MEASUREMENT_CHANNEL_0,Weight_MeasurementFromADC.nLong,0,1);
               /*~I:160*/
               if (chSelection != 0xFF)
               /*~-1*/
               {
                  /*~T*/
                  break;
               /*~-1*/
               }
               /*~E:I160*/
               /*~E:A159*/
            /*~-1*/
            }
            /*~E:F158*/
            /*~F:161*/
            case 4:
            /*~-1*/
            {
               /*~A:162*/
               /*~+:gefilterter RMW ohne Nullpunktkorrektur*/
               /*~T*/
               // gefilterter RMW ohne Nullpunktkorrektur
               Communication_SendLong(COMMUNICATION_RS232,TEXT_MEASUREMENT_ACTUAL_FILTERED_MEASUREMENT_CHANNEL_0,Weight_FilteredMeasurement.nLong,0,1);

               /*~I:163*/
               if (chSelection != 0xFF)
               /*~-1*/
               {
                  /*~T*/
                  break;
               /*~-1*/
               }
               /*~E:I163*/
               /*~E:A162*/
            /*~-1*/
            }
            /*~E:F161*/
            /*~F:164*/
            case 5:
            /*~-1*/
            {
               /*~A:165*/
               /*~+:gefilterter RMW mit Nullpunktkorrektur*/
               /*~T*/
               // gefilterter RMW mit Nullpunktkorrektur
               Communication_SendLong(COMMUNICATION_RS232,TEXT_ACTUAL_MEASUREMENT_CHANNEL_0,Weight_ZeroCorrectedMeasurement.nLong,0,1);
               /*~I:166*/
               if (chSelection != 0xFF)
               /*~-1*/
               {
                  /*~T*/
                  break;
               /*~-1*/
               }
               /*~E:I166*/
               /*~E:A165*/
            /*~-1*/
            }
            /*~E:F164*/
            /*~F:167*/
            case 6:
            /*~-1*/
            {
               /*~A:168*/
               /*~+:Korrekturwert*/
               /*~I:169*/
#ifdef COMPENSATION_OUTPUT_ALL_DATAS
               	if(1)
#else
               	if ((COMPENSATION_STATE >= MRW_COMPENSATION_STATE_INIT_GET_POINT)&&(COMPENSATION_STATE < 	MRW_COMPENSATION_STATE_SWITCH_COMPENSATION_ON))
#endif
               /*~-1*/
               {
                  /*~T*/
                  // Korrekturwert
                  MRW_Compensation_GetData(MRW_COMPENSATION_GET_LAST_CORRVAL,0,&ParameterRead.nInt);

                  Communication_SendLong(COMMUNICATION_RS232,TEXT_COMPENSATION_LAST_CORRECTION_VALUE_CHANNEL_0,ParameterRead.nInt,0,1);
               /*~-1*/
               }
               /*~E:I169*/
               /*~I:170*/
               if (chSelection != 0xFF)
               /*~-1*/
               {
                  /*~T*/
                  break;
               /*~-1*/
               }
               /*~E:I170*/
               /*~E:A168*/
            /*~-1*/
            }
            /*~E:F167*/
            /*~F:171*/
            case 7:
            /*~-1*/
            {
               /*~A:172*/
               /*~+:Anzahl der aufgenommenen Kennlinienpunkte*/
               /*~I:173*/
#ifdef COMPENSATION_OUTPUT_ALL_DATAS
               	if(1)
#else
               	if ((COMPENSATION_STATE >= MRW_COMPENSATION_STATE_INIT_GET_POINT)&&(COMPENSATION_STATE < 	MRW_COMPENSATION_STATE_SWITCH_COMPENSATION_ON))
#endif
               /*~-1*/
               {
                  /*~T*/
                  // Anzahl der aufgenommenen Kennlinienpunkte
                  MRW_Compensation_GetData(MRW_COMPENSATION_GET_POINTS_RECORDED,0,&ParameterRead.byChar);
                  Communication_SendLong(COMMUNICATION_RS232,TEXT_COMPENSATION_POINTS_RECORDED_CHANNEL_0,ParameterRead.byChar,0,1);
               /*~-1*/
               }
               /*~E:I173*/
               /*~I:174*/
               if (chSelection != 0xFF)
               /*~-1*/
               {
                  /*~T*/
                  break;
               /*~-1*/
               }
               /*~E:I174*/
               /*~E:A172*/
            /*~-1*/
            }
            /*~E:F171*/
            /*~F:175*/
            case 8:
            /*~-1*/
            {
               /*~A:176*/
               /*~+:Maximale Abweichung (Gewicht)*/
               /*~I:177*/
#ifdef COMPENSATION_OUTPUT_ALL_DATAS
               	if(1)
#else
               	if ((COMPENSATION_STATE >= MRW_COMPENSATION_STATE_INIT_TEST_COMPENSATION)&&(COMPENSATION_STATE < MRW_COMPENSATION_STATE_WAIT_TEMP_4_REC_2ND_RMW20))
#endif
               /*~-1*/
               {
                  /*~T*/
                  // Maximale Abweichung (Gewicht)
                  MRW_Compensation_GetData(MRW_COMPENSATION_GET_MAXIMUM_KG,0,&ParameterRead.fFloat);
                  Communication_SendFloat(COMMUNICATION_RS232,TEXT_COMPENSATION_MAXIMUM_DEVIATION_CHANNEL_0,ParameterRead.fFloat,2,0,1);

               /*~-1*/
               }
               /*~E:I177*/
               /*~I:178*/
               if (chSelection != 0xFF)
               /*~-1*/
               {
                  /*~T*/
                  break;
               /*~-1*/
               }
               /*~E:I178*/
               /*~E:A176*/
            /*~-1*/
            }
            /*~E:F175*/
            /*~F:179*/
            case 9:
            /*~-1*/
            {
               /*~A:180*/
               /*~+:Maximale Abweichung (Temperatur)*/
               /*~I:181*/
#ifdef COMPENSATION_OUTPUT_ALL_DATAS
               	if(1)
#else
               	if ((COMPENSATION_STATE >= MRW_COMPENSATION_STATE_INIT_TEST_COMPENSATION)&&(COMPENSATION_STATE < MRW_COMPENSATION_STATE_WAIT_TEMP_4_REC_2ND_RMW20))
#endif
               /*~-1*/
               {
                  /*~T*/
                  // Maximale Abweichung (Temperatur)
                  MRW_Compensation_GetData(MRW_COMPENSATION_GET_MAXIMUM_TEMP,0,&ParameterRead.byChar);

                  /*~T*/
                  Communication_SendLong(COMMUNICATION_RS232,TEXT_COMPENSATION_MAXIMUM_DEVIATION_TEMPERATURE_CHANNEL_0,ParameterRead.byChar,0,1);
               /*~-1*/
               }
               /*~E:I181*/
               /*~I:182*/
               if (chSelection != 0xFF)
               /*~-1*/
               {
                  /*~T*/
                  break;
               /*~-1*/
               }
               /*~E:I182*/
               /*~E:A180*/
            /*~-1*/
            }
            /*~E:F179*/
            /*~F:183*/
            case 10:
            /*~-1*/
            {
               /*~A:184*/
               /*~+:Minimale Abweichung (Gewicht)*/
               /*~I:185*/
#ifdef COMPENSATION_OUTPUT_ALL_DATAS
               	if(1)
#else
               	if ((COMPENSATION_STATE >= MRW_COMPENSATION_STATE_INIT_TEST_COMPENSATION)&&(COMPENSATION_STATE < MRW_COMPENSATION_STATE_WAIT_TEMP_4_REC_2ND_RMW20))
#endif
               /*~-1*/
               {
                  /*~T*/
                  // Minimale Abweichung (Gewicht)
                  MRW_Compensation_GetData(MRW_COMPENSATION_GET_MINIMUM_KG,0,&ParameterRead.fFloat);
                  Communication_SendFloat(COMMUNICATION_RS232,TEXT_COMPENSATION_MINIMUM_DEVIATION_CHANNEL_0,ParameterRead.fFloat,2,0,1);
               /*~-1*/
               }
               /*~E:I185*/
               /*~I:186*/
               if (chSelection != 0xFF)
               /*~-1*/
               {
                  /*~T*/
                  break;
               /*~-1*/
               }
               /*~E:I186*/
               /*~E:A184*/
            /*~-1*/
            }
            /*~E:F183*/
            /*~F:187*/
            case 11:
            /*~-1*/
            {
               /*~A:188*/
               /*~+:Minimale Abweichung (Temperatur)*/
               /*~I:189*/
#ifdef COMPENSATION_OUTPUT_ALL_DATAS
               	if(1)
#else
               	if ((COMPENSATION_STATE >= MRW_COMPENSATION_STATE_INIT_TEST_COMPENSATION)&&(COMPENSATION_STATE < MRW_COMPENSATION_STATE_WAIT_TEMP_4_REC_2ND_RMW20))
#endif
               /*~-1*/
               {
                  /*~T*/
                  // Minimale Abweichung (Temperatur)
                  MRW_Compensation_GetData(MRW_COMPENSATION_GET_MINIMUM_TEMP,0,&ParameterRead.byChar);
                  /*~T*/
                  Communication_SendLong(COMMUNICATION_RS232,TEXT_COMPENSATION_MINIMUM_DEVIATION_TEMPERATURE_CHANNEL_0,ParameterRead.byChar,0,1);
               /*~-1*/
               }
               /*~E:I189*/
               /*~I:190*/
               if (chSelection != 0xFF)
               /*~-1*/
               {
                  /*~T*/
                  break;
               /*~-1*/
               }
               /*~E:I190*/
               /*~E:A188*/
            /*~-1*/
            }
            /*~E:F187*/
            /*~F:191*/
            case 12:
            /*~-1*/
            {
               /*~A:192*/
               /*~+:Aktuelle Abweichung*/
               /*~I:193*/
#ifdef COMPENSATION_OUTPUT_ALL_DATAS
               	if(1)
#else
               	if ((COMPENSATION_STATE >= MRW_COMPENSATION_STATE_INIT_TEST_COMPENSATION)&&(COMPENSATION_STATE < MRW_COMPENSATION_STATE_WAIT_TEMP_4_REC_2ND_RMW20))
#endif
               /*~-1*/
               {
                  /*~T*/
                  // Aktuelle Abweichung
                  MRW_Compensation_GetData(MRW_COMPENSATION_GET_DEVIATION_KG,0,&ParameterRead.fFloat);
                  Communication_SendFloat(COMMUNICATION_RS232,TEXT_COMPENSATION_ACTUAL_DEVIATION_CHANNEL_0,ParameterRead.fFloat,2,0,1);
               /*~-1*/
               }
               /*~E:I193*/
               /*~I:194*/
               if (chSelection != 0xFF)
               /*~-1*/
               {
                  /*~T*/
                  break;
               /*~-1*/
               }
               /*~E:I194*/
               /*~E:A192*/
            /*~-1*/
            }
            /*~E:F191*/
            /*~F:195*/
            case 13:
            /*~-1*/
            {
               /*~A:196*/
               /*~+:Soll-Ausgangsstrom*/
               /*~T*/
               // Soll-Ausgangsstrom
               Communication_SendFloat(COMMUNICATION_RS232,TEXT_CURRENT_INTERFACE_ACTUAL_CURRENT_CHANNEL_0,CurrentInterface_GetCurrent(0),3,0,1);
               /*~I:197*/
               if (chSelection != 0xFF)
               /*~-1*/
               {
                  /*~T*/
                  break;
               /*~-1*/
               }
               /*~E:I197*/
               /*~E:A196*/
            /*~-1*/
            }
            /*~E:F195*/
            /*~F:198*/
            case 14:
            /*~-1*/
            {
               /*~A:199*/
               /*~+:Ist-Ausgangsstrom*/
               /*~T*/
               // Ist-Ausgangsstrom
               Communication_SendFloat(COMMUNICATION_RS232,TEXT_CURRENT_INTERFACE_ACTUAL_CURRENT_MEASURED_CHANNEL_0,CurrentInterface_GetCurrent(1),3,0,1);
               /*~I:200*/
               if (chSelection != 0xFF)
               /*~-1*/
               {
                  /*~T*/
                  break;
               /*~-1*/
               }
               /*~E:I200*/
               /*~E:A199*/
            /*~-1*/
            }
            /*~E:F198*/
            /*~F:201*/
            case 15:
            /*~-1*/
            {
               /*~A:202*/
               /*~+:Versorgungsspannung*/
               /*~T*/
               // Spannung der Versorgungsspannung
               Communication_SendLong(COMMUNICATION_RS232,TEXT_POWERSUPPLY_CHANNEL_0,Global.lRMW_PowerSupply,0,1);

               /*~I:203*/
               if (chSelection != 0xFF)
               /*~-1*/
               {
                  /*~T*/
                  break;
               /*~-1*/
               }
               /*~E:I203*/
               /*~E:A202*/
            /*~-1*/
            }
            /*~E:F201*/
            /*~F:204*/
            case 16:	// letzter Status !!!
            /*~-1*/
            {
               /*~A:205*/
               /*~+:Partner-Status der Kennlinienaufnahme*/
               /*~T*/
               // Partner-Status der Kennlinienaufnahme
               Communication_SendLong(COMMUNICATION_RS232,TEXT_COMPENSATION_STATUS_REC_CHARACTERISTICS_CHANNEL_1,SYSTEMSTATE_PARTNER,0,1);
               /*~T*/
               break;
               /*~E:A205*/
            /*~-1*/
            }
            /*~E:F204*/
            /*~O:C138*/
            /*~-2*/
            default:
            {
               /*~A:206*/
               /*~+:Fehler - E001 senden*/
               /*~T*/
               Communication_SendString(COMMUNICATION_RS232,TEXT_E001,1,0);
               /*~E:A206*/
            /*~-1*/
            }
         /*~-1*/
         }
         /*~E:C138*/
         /*~-1*/
#endif
         /*~E:I137*/
         /*~I:207*/
#ifdef CHANNEL_1
         /*~C:208*/
         switch (chSelectionCopy)
         /*~-1*/
         {
            /*~F:209*/
            case 17:
            case 0xFF:
            /*~-1*/
            {
               /*~A:210*/
               /*~+:Erfolg oder Misserfolg der Kennlinienaufnahme*/
               /*~I:211*/
               if (COMPENSATION_STATE == MRW_COMPENSATION_STATE_ERROR)
               /*~-1*/
               {
                  /*~T*/
                  /*#LJ:0=0*/
                  Communication_SendString(COMMUNICATION_RS232,T_TEXT_COMPENSATION_FAULTY_CHANNEL_1,2,1);
                  /*~T*/
                  break;
               /*~-1*/
               }
               /*~O:I211*/
               /*~-2*/
               else
               {
                  /*~I:212*/
                  if (COMPENSATION_STATE == MRW_COMPENSATION_STATE_READY)
                  /*~-1*/
                  {
                     /*~T*/
                     Communication_SendString(COMMUNICATION_RS232,T_TEXT_COMPENSATION_EVERYTHING_IS_OKAY_CHANNEL_1,2,1);
                     /*~T*/
                     break;
                  /*~-1*/
                  }
                  /*~O:I212*/
                  /*~-2*/
                  else
                  {
                     /*~I:213*/
                     if (chSelection != 0xFF)
                     /*~-1*/
                     {
                        /*~T*/
                        break;
                     /*~-1*/
                     }
                     /*~E:I213*/
                  /*~-1*/
                  }
                  /*~E:I212*/
               /*~-1*/
               }
               /*~E:I211*/
               /*~E:A210*/
            /*~-1*/
            }
            /*~E:F209*/
            /*~F:214*/
            case 0:
            /*~-1*/
            {
               /*~A:215*/
               /*~+:Kopf und verstrichene Zeit*/
               /*~I:216*/
               if (!SYSTEM_MRW_MANAGER)
               /*~-1*/
               {
                  /*~I:217*/
                  if (byPrintChannelHeader)
                  /*~-1*/
                  {
                     /*~T*/
                     // Textausgabe Kanal 0
                     Communication_SendString(COMMUNICATION_RS232,T_TEXT_CHANNEL_1,3,0);		// Kanal 0
                     Communication_SendString(COMMUNICATION_RS232,T_TEXT_DOUBLE_LINE,1,1);		// Unterstreichen
                  /*~-1*/
                  }
                  /*~E:I217*/
                  /*~T*/
                  // Vergangene Zeit seit Start der Aufnahme 
                  sprintf(szString2Send,"%ld (%ld:%02ld:%02ld)",ulSecondsPast,ulSecondsPast / 3600,(ulSecondsPast%3600)/60,ulSecondsPast%60);

                  Communication_SendString(COMMUNICATION_RS232,T_TEXT_COMPENSATION_TIME_LEFT_CHANNEL_1,0,0);

                  Communication_SendString(COMMUNICATION_RS232,szString2Send,0,1);
               /*~-1*/
               }
               /*~O:I216*/
               /*~-2*/
               else
               {
                  /*~T*/
                  // Vergangene Zeit seit Start der Aufnahme 
                  Communication_SendLong(COMMUNICATION_RS232,0,ulSecondsPast,TEXT_COMPENSATION_TIME_LEFT_CHANNEL_1,1);
               /*~-1*/
               }
               /*~E:I216*/
               /*~I:218*/
               if (chSelectionCopy != 0xFF)
               /*~-1*/
               {
                  /*~T*/
                  break;
               /*~-1*/
               }
               /*~E:I218*/
               /*~E:A215*/
            /*~-1*/
            }
            /*~E:F214*/
            /*~F:219*/
            case 1:
            /*~-1*/
            {
               /*~A:220*/
               /*~+:Status der Kennlinienaufnahme*/
               /*~T*/
               // Status der Kennlinienaufnahme
               Communication_SendLong(COMMUNICATION_RS232,TEXT_COMPENSATION_STATUS_REC_CHARACTERISTICS_CHANNEL_1,COMPENSATION_STATE,0,1);

               /*~I:221*/
               if (chSelectionCopy != 0xFF)
               /*~-1*/
               {
                  /*~T*/
                  break;
               /*~-1*/
               }
               /*~E:I221*/
               /*~E:A220*/
            /*~-1*/
            }
            /*~E:F219*/
            /*~F:222*/
            case 2:
            /*~-1*/
            {
               /*~A:223*/
               /*~+:Temperatur*/
               /*~T*/
               // Temperatur
               Communication_SendLong(COMMUNICATION_RS232,TEXT_ACTUAL_TEMPERATURE_CHANNEL_1,Global.byTemperature,0,1);

               /*~I:224*/
               if (chSelectionCopy != 0xFF)
               /*~-1*/
               {
                  /*~T*/
                  break;
               /*~-1*/
               }
               /*~E:I224*/
               /*~E:A223*/
            /*~-1*/
            }
            /*~E:F222*/
            /*~F:225*/
            case 3:
            /*~-1*/
            {
               /*~A:226*/
               /*~+:Rohmesswert vom ADC*/
               /*~T*/
               // Rohmesswert vom ADC
               Communication_SendLong(COMMUNICATION_RS232,TEXT_ADC_ACTUAL_MEASUREMENT_CHANNEL_1,Weight_MeasurementFromADC.nLong,0,1);
               /*~I:227*/
               if (chSelectionCopy != 0xFF)
               /*~-1*/
               {
                  /*~T*/
                  break;
               /*~-1*/
               }
               /*~E:I227*/
               /*~E:A226*/
            /*~-1*/
            }
            /*~E:F225*/
            /*~F:228*/
            case 4:
            /*~-1*/
            {
               /*~A:229*/
               /*~+:gefilterter RMW ohne Nullpunktkorrektur*/
               /*~T*/
               // gefilterter RMW ohne Nullpunktkorrektur
               Communication_SendLong(COMMUNICATION_RS232,TEXT_MEASUREMENT_ACTUAL_FILTERED_MEASUREMENT_CHANNEL_1,Weight_FilteredMeasurement.nLong,0,1);

               /*~I:230*/
               if (chSelectionCopy != 0xFF)
               /*~-1*/
               {
                  /*~T*/
                  break;
               /*~-1*/
               }
               /*~E:I230*/
               /*~E:A229*/
            /*~-1*/
            }
            /*~E:F228*/
            /*~F:231*/
            case 5:
            /*~-1*/
            {
               /*~A:232*/
               /*~+:gefilterter RMW mit Nullpunktkorrektur*/
               /*~T*/
               // gefilterter RMW mit Nullpunktkorrektur
               Communication_SendLong(COMMUNICATION_RS232,TEXT_ACTUAL_MEASUREMENT_CHANNEL_1,Weight_ZeroCorrectedMeasurement.nLong,0,1);
               /*~I:233*/
               if (chSelectionCopy != 0xFF)
               /*~-1*/
               {
                  /*~T*/
                  break;
               /*~-1*/
               }
               /*~E:I233*/
               /*~E:A232*/
            /*~-1*/
            }
            /*~E:F231*/
            /*~F:234*/
            case 6:
            /*~-1*/
            {
               /*~A:235*/
               /*~+:Korrekturwert*/
               /*~I:236*/
#ifdef COMPENSATION_OUTPUT_ALL_DATAS
               	if(1)
#else
               	if ((COMPENSATION_STATE >= MRW_COMPENSATION_STATE_INIT_GET_POINT)&&(COMPENSATION_STATE < 	MRW_COMPENSATION_STATE_SWITCH_COMPENSATION_ON))
#endif
               /*~-1*/
               {
                  /*~T*/
                  // Korrekturwert
                  MRW_Compensation_GetData(MRW_COMPENSATION_GET_LAST_CORRVAL,0,&ParameterRead.nInt);

                  Communication_SendLong(COMMUNICATION_RS232,TEXT_COMPENSATION_LAST_CORRECTION_VALUE_CHANNEL_1,ParameterRead.nInt,0,1);
               /*~-1*/
               }
               /*~E:I236*/
               /*~I:237*/
               if (chSelectionCopy != 0xFF)
               /*~-1*/
               {
                  /*~T*/
                  break;
               /*~-1*/
               }
               /*~E:I237*/
               /*~E:A235*/
            /*~-1*/
            }
            /*~E:F234*/
            /*~F:238*/
            case 7:
            /*~-1*/
            {
               /*~A:239*/
               /*~+:Anzahl der aufgenommenen Kennlinienpunkte*/
               /*~I:240*/
#ifdef COMPENSATION_OUTPUT_ALL_DATAS
               	if(1)
#else
               	if ((COMPENSATION_STATE >= MRW_COMPENSATION_STATE_INIT_GET_POINT)&&(COMPENSATION_STATE < 	MRW_COMPENSATION_STATE_SWITCH_COMPENSATION_ON))
#endif
               /*~-1*/
               {
                  /*~T*/
                  // Anzahl der aufgenommenen Kennlinienpunkte
                  MRW_Compensation_GetData(MRW_COMPENSATION_GET_POINTS_RECORDED,0,&ParameterRead.byChar);
                  Communication_SendLong(COMMUNICATION_RS232,TEXT_COMPENSATION_POINTS_RECORDED_CHANNEL_1,ParameterRead.byChar,0,1);
               /*~-1*/
               }
               /*~E:I240*/
               /*~I:241*/
               if (chSelectionCopy != 0xFF)
               /*~-1*/
               {
                  /*~T*/
                  break;
               /*~-1*/
               }
               /*~E:I241*/
               /*~E:A239*/
            /*~-1*/
            }
            /*~E:F238*/
            /*~F:242*/
            case 8:
            /*~-1*/
            {
               /*~A:243*/
               /*~+:Maximale Abweichung (Gewicht)*/
               /*~I:244*/
#ifdef COMPENSATION_OUTPUT_ALL_DATAS
               	if(1)
#else
               	if ((COMPENSATION_STATE >= MRW_COMPENSATION_STATE_INIT_TEST_COMPENSATION)&&(COMPENSATION_STATE < MRW_COMPENSATION_STATE_WAIT_TEMP_4_REC_2ND_RMW20))
#endif
               /*~-1*/
               {
                  /*~T*/
                  // Maximale Abweichung (Gewicht)
                  MRW_Compensation_GetData(MRW_COMPENSATION_GET_MAXIMUM_KG,0,&ParameterRead.fFloat);
                  Communication_SendFloat(COMMUNICATION_RS232,TEXT_COMPENSATION_MAXIMUM_DEVIATION_CHANNEL_1,ParameterRead.fFloat,2,0,1);

               /*~-1*/
               }
               /*~E:I244*/
               /*~I:245*/
               if (chSelectionCopy != 0xFF)
               /*~-1*/
               {
                  /*~T*/
                  break;
               /*~-1*/
               }
               /*~E:I245*/
               /*~E:A243*/
            /*~-1*/
            }
            /*~E:F242*/
            /*~F:246*/
            case 9:
            /*~-1*/
            {
               /*~A:247*/
               /*~+:Maximale Abweichung (Temperatur)*/
               /*~I:248*/
#ifdef COMPENSATION_OUTPUT_ALL_DATAS
               	if(1)
#else
               	if ((COMPENSATION_STATE >= MRW_COMPENSATION_STATE_INIT_TEST_COMPENSATION)&&(COMPENSATION_STATE < MRW_COMPENSATION_STATE_WAIT_TEMP_4_REC_2ND_RMW20))
#endif
               /*~-1*/
               {
                  /*~T*/
                  // Maximale Abweichung (Temperatur)
                  MRW_Compensation_GetData(MRW_COMPENSATION_GET_MAXIMUM_TEMP,0,&ParameterRead.byChar);

                  /*~T*/
                  Communication_SendLong(COMMUNICATION_RS232,TEXT_COMPENSATION_MAXIMUM_DEVIATION_TEMPERATURE_CHANNEL_1,ParameterRead.byChar,0,1);
                  /*~A:249*/
                  /*~+:ausgeklammert*/
                  /*~I:250*/
#ifdef MOF
                  /*~I:251*/
                  if (!g_bySuppressOutput)
                  /*~-1*/
                  {
                     /*~T*/
                     Communication_SendLong(COMMUNICATION_RS232,TEXT_AT,ParameterRead.byChar,0,1);
                  /*~-1*/
                  }
                  /*~O:I251*/
                  /*~-2*/
                  else
                  {
                     /*~T*/
                     Communication_SendLong(COMMUNICATION_RS232,TEXT_COMPENSATION_MAXIMUM_DEVIATION_TEMPERATURE_CHANNEL_1,ParameterRead.byChar,0,1);
                  /*~-1*/
                  }
                  /*~E:I251*/
                  /*~-1*/
#endif
                  /*~E:I250*/
                  /*~E:A249*/
               /*~-1*/
               }
               /*~E:I248*/
               /*~I:252*/
               if (chSelectionCopy != 0xFF)
               /*~-1*/
               {
                  /*~T*/
                  break;
               /*~-1*/
               }
               /*~E:I252*/
               /*~E:A247*/
            /*~-1*/
            }
            /*~E:F246*/
            /*~F:253*/
            case 10:
            /*~-1*/
            {
               /*~A:254*/
               /*~+:Minimale Abweichung (Gewicht)*/
               /*~I:255*/
#ifdef COMPENSATION_OUTPUT_ALL_DATAS
               	if(1)
#else
               	if ((COMPENSATION_STATE >= MRW_COMPENSATION_STATE_INIT_TEST_COMPENSATION)&&(COMPENSATION_STATE < MRW_COMPENSATION_STATE_WAIT_TEMP_4_REC_2ND_RMW20))
#endif
               /*~-1*/
               {
                  /*~T*/
                  // Minimale Abweichung (Gewicht)
                  MRW_Compensation_GetData(MRW_COMPENSATION_GET_MINIMUM_KG,0,&ParameterRead.fFloat);
                  Communication_SendFloat(COMMUNICATION_RS232,TEXT_COMPENSATION_MINIMUM_DEVIATION_CHANNEL_1,ParameterRead.fFloat,2,0,1);
               /*~-1*/
               }
               /*~E:I255*/
               /*~I:256*/
               if (chSelectionCopy != 0xFF)
               /*~-1*/
               {
                  /*~T*/
                  break;
               /*~-1*/
               }
               /*~E:I256*/
               /*~E:A254*/
            /*~-1*/
            }
            /*~E:F253*/
            /*~F:257*/
            case 11:
            /*~-1*/
            {
               /*~A:258*/
               /*~+:Minimale Abweichung (Temperatur)*/
               /*~I:259*/
#ifdef COMPENSATION_OUTPUT_ALL_DATAS
               	if(1)
#else
               	if ((COMPENSATION_STATE >= MRW_COMPENSATION_STATE_INIT_TEST_COMPENSATION)&&(COMPENSATION_STATE < MRW_COMPENSATION_STATE_WAIT_TEMP_4_REC_2ND_RMW20))
#endif
               /*~-1*/
               {
                  /*~T*/
                  // Minimale Abweichung (Temperatur)
                  MRW_Compensation_GetData(MRW_COMPENSATION_GET_MINIMUM_TEMP,0,&ParameterRead.byChar);
                  /*~T*/
                  Communication_SendLong(COMMUNICATION_RS232,TEXT_COMPENSATION_MINIMUM_DEVIATION_TEMPERATURE_CHANNEL_1,ParameterRead.byChar,0,1);
               /*~-1*/
               }
               /*~E:I259*/
               /*~I:260*/
               if (chSelectionCopy != 0xFF)
               /*~-1*/
               {
                  /*~T*/
                  break;
               /*~-1*/
               }
               /*~E:I260*/
               /*~E:A258*/
            /*~-1*/
            }
            /*~E:F257*/
            /*~F:261*/
            case 12:
            /*~-1*/
            {
               /*~A:262*/
               /*~+:Aktuelle Abweichung*/
               /*~I:263*/
#ifdef COMPENSATION_OUTPUT_ALL_DATAS
               	if(1)
#else
               	if ((COMPENSATION_STATE >= MRW_COMPENSATION_STATE_INIT_TEST_COMPENSATION)&&(COMPENSATION_STATE < MRW_COMPENSATION_STATE_WAIT_TEMP_4_REC_2ND_RMW20))
#endif
               /*~-1*/
               {
                  /*~T*/
                  // Aktuelle Abweichung
                  MRW_Compensation_GetData(MRW_COMPENSATION_GET_DEVIATION_KG,0,&ParameterRead.fFloat);
                  Communication_SendFloat(COMMUNICATION_RS232,TEXT_COMPENSATION_ACTUAL_DEVIATION_CHANNEL_1,ParameterRead.fFloat,2,0,1);
               /*~-1*/
               }
               /*~E:I263*/
               /*~I:264*/
               if (chSelectionCopy != 0xFF)
               /*~-1*/
               {
                  /*~T*/
                  break;
               /*~-1*/
               }
               /*~E:I264*/
               /*~E:A262*/
            /*~-1*/
            }
            /*~E:F261*/
            /*~F:265*/
            case 13:
            /*~-1*/
            {
               /*~A:266*/
               /*~+:Soll-Ausgangsstrom*/
               /*~T*/
               // Soll-Ausgangsstrom
               Communication_SendFloat(COMMUNICATION_RS232,TEXT_CURRENT_INTERFACE_ACTUAL_CURRENT_CHANNEL_1,CurrentInterface_GetCurrent(0),3,0,1);
               /*~I:267*/
               if (chSelectionCopy != 0xFF)
               /*~-1*/
               {
                  /*~T*/
                  break;
               /*~-1*/
               }
               /*~E:I267*/
               /*~E:A266*/
            /*~-1*/
            }
            /*~E:F265*/
            /*~F:268*/
            case 14:
            /*~-1*/
            {
               /*~A:269*/
               /*~+:Ist-Ausgangsstrom*/
               /*~T*/
               // Ist-Ausgangsstrom
               Communication_SendFloat(COMMUNICATION_RS232,TEXT_CURRENT_INTERFACE_ACTUAL_CURRENT_MEASURED_CHANNEL_1,CurrentInterface_GetCurrent(1),3,0,1);
               /*~I:270*/
               if (chSelectionCopy != 0xFF)
               /*~-1*/
               {
                  /*~T*/
                  break;
               /*~-1*/
               }
               /*~E:I270*/
               /*~E:A269*/
            /*~-1*/
            }
            /*~E:F268*/
            /*~F:271*/
            case 15:
            /*~-1*/
            {
               /*~A:272*/
               /*~+:Versorgungsspannung*/
               /*~T*/
               // Spannung der Versorgungsspannung
               Communication_SendLong(COMMUNICATION_RS232,TEXT_POWERSUPPLY_CHANNEL_1,Global.lRMW_PowerSupply,0,1);

               /*~I:273*/
               if (chSelectionCopy != 0xFF)
               /*~-1*/
               {
                  /*~T*/
                  break;
               /*~-1*/
               }
               /*~E:I273*/
               /*~E:A272*/
            /*~-1*/
            }
            /*~E:F271*/
            /*~F:274*/
            case 16:	// letzter Status !!!
            /*~-1*/
            {
               /*~A:275*/
               /*~+:Partner-Status der Kennlinienaufnahme*/
               /*~T*/
               // Da die Ausgabe l�nger dauern kann, Watchdog retriggern
               Watchdog();
               /*~T*/
               // Partner-Status der Kennlinienaufnahme
               Communication_SendLong(COMMUNICATION_RS232,TEXT_COMPENSATION_STATUS_REC_CHARACTERISTICS_CHANNEL_0,SYSTEMSTATE_PARTNER,0,1);
               /*~T*/
               break;
               /*~E:A275*/
            /*~-1*/
            }
            /*~E:F274*/
         /*~-1*/
         }
         /*~E:C208*/
         /*~-1*/
#endif
         /*~E:I207*/
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F131*/
      /*~E:A130*/
      /*~A:276*/
      /*~+:Kennlinie und Ergebnisse der �berpr�fung*/
      /*~F:277*/
      // Kennlinie und Ergebnisse der �berpr�fung
      case 1:
      /*~-1*/
      {
         /*~A:278*/
         /*~+:Variablendeklarationen*/
         /*~T*/
         char byTemperature;
         int nCorrVal[2];
         char szString2Send[32];
         /*~E:A278*/
         /*~A:279*/
         /*~+:Variableninitialisierungen*/
         /*~T*/

         /*~E:A279*/
         /*~T*/
         // Kompensationswerte einlesen
         MRW_Compensation_Init(1);
         /*~I:280*/
         if (!SYSTEM_MRW_MANAGER)
         /*~-1*/
         {
            /*~I:281*/
#ifdef CHANNEL_0
            /*~I:282*/
            if (chSelection == 255)
            /*~-1*/
            {
               /*~A:283*/
               /*~+:Formularkopf bei kompletter Ausgabe*/
               /*~K*/
               /*~+:// Formularkopf bei kompletter Ausgabe*/
               /*~T*/
               // Syste,-ID
               Communication_SendLong(COMMUNICATION_RS232,TEXT_SYSTEM_ID,Global.ulSystemID,0,1);
               // Versionen ausgeben
               Communication_SendString(COMMUNICATION_RS232,T_TEXT_HARDWAREVERSION,1,0);
               Communication_SendString(COMMUNICATION_RS232,TEXT_HARDWARE_VERSION,0,0);
               Communication_SendString(COMMUNICATION_RS232,T_TEXT_SOFTWAREVERSION,1,0);
               Communication_SendString(COMMUNICATION_RS232,TEXT_SOFTWARE_VERSION,0,1);
               /*~E:A283*/
            /*~-1*/
            }
            /*~E:I282*/
            /*~A:284*/
            /*~+:Kanalnummer*/
            /*~T*/
            // Kanalnummer
            Communication_SendString(COMMUNICATION_RS232,T_TEXT_CHANNEL_0,1,0);
            /*~E:A284*/
            /*~-1*/
#endif
            /*~E:I281*/
            /*~I:285*/
#ifdef CHANNEL_1
            /*~A:286*/
            /*~+:Kanalnummer*/
            /*~T*/
            // Kanalnummer
            Communication_SendString(COMMUNICATION_RS232,T_TEXT_CHANNEL_1,1,0);
            /*~E:A286*/
            /*~-1*/
#endif
            /*~E:I285*/
            /*~A:287*/
            /*~+:Kanalnummer unterstreichen*/
            /*~T*/
            // Doppellinie
            Communication_SendString(COMMUNICATION_RS232,T_TEXT_DOUBLE_LINE,1,1);
            /*~E:A287*/
         /*~-1*/
         }
         /*~E:I280*/
         /*~C:288*/
         switch (chSelection)
         /*~-1*/
         {
            /*~A:289*/
            /*~+:Kennlinienpunkte*/
            /*~F:290*/
            // Kennlinienpunkte
            case 0:
            case 255:
            /*~-1*/
            {
               /*~I:291*/
               if (!SYSTEM_MRW_MANAGER)
               /*~-1*/
               {
                  /*~T*/
                  Communication_SendString(COMMUNICATION_RS232,T_TEXT_CHARACTERISTICS,1,1);
                  // Tabellenkopf
                  Communication_SendString(COMMUNICATION_RS232,T_TEXT_HEADER_CHARACTERISTICS,1,0);
                  /*~L:292*/
                  for (byTemperature = MRW_COMPENSATION_CORR_TEMP_HI;byTemperature >= MRW_COMPENSATION_CORR_TEMP_LO;byTemperature -= MRW_COMPENSATION_CORR_TEMP_SPAN)
                  /*~-1*/
                  {
                     /*~T*/
                     // Da die Ausgabe l�nger dauern kann, Watchdog retriggern
                     Watchdog();
                     /*~T*/
                     MRW_Compensation_GetData(MRW_COMPENSATION_GET_CHARACTERISTICS,byTemperature,&nCorrVal[0]);
                     MRW_Compensation_GetData(MRW_COMPENSATION_GET_CHARACTERISTICS_WITH_OFFSET,byTemperature,&nCorrVal[1]);
                     /*~T*/
                     sprintf(szString2Send,"%16bd",byTemperature);
                     Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);

                     sprintf(szString2Send,"%17d",nCorrVal[0]);
                     Communication_SendString(COMMUNICATION_RS232,szString2Send,0,0);

                     sprintf(szString2Send," (%5d)",nCorrVal[1]);
                     Communication_SendString(COMMUNICATION_RS232,szString2Send,0,0);
                  /*~-1*/
                  }
                  /*~E:L292*/
               /*~-1*/
               }
               /*~O:I291*/
               /*~-2*/
               else
               {
                  /*~I:293*/
                  if ((chAddParameter <= MRW_COMPENSATION_CORR_TEMP_HI)&&(chAddParameter >= MRW_COMPENSATION_CORR_TEMP_LO))
                  /*~-1*/
                  {
                     /*~T*/
                     MRW_Compensation_GetData(MRW_COMPENSATION_GET_CHARACTERISTICS,chAddParameter,&nCorrVal[0]);

                     MRW_Compensation_GetData(MRW_COMPENSATION_GET_CHARACTERISTICS_WITH_OFFSET,chAddParameter,&nCorrVal[1]);
                     /*~T*/
                     sprintf(szString2Send,"%bd;%d;%d",chAddParameter,nCorrVal[0],nCorrVal[1]);
                  /*~-1*/
                  }
                  /*~O:I293*/
                  /*~-2*/
                  else
                  {
                     /*~A:294*/
                     /*~+:Parameter au�erhalb des Bereichs - E002*/
                     /*~T*/
                     // Parameter au�erhalb des Bereichs - E002

                     strcpy(szString2Send,"E002");
                     /*~E:A294*/
                  /*~-1*/
                  }
                  /*~E:I293*/
                  /*~T*/
                  Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
               /*~-1*/
               }
               /*~E:I291*/
               /*~I:295*/
               if ((chSelection != 255)||(SYSTEM_MRW_MANAGER))
               /*~-1*/
               {
                  /*~T*/
                  break;
               /*~-1*/
               }
               /*~O:I295*/
               /*~-2*/
               else
               {
                  /*~T*/
                  Communication_SendCR(1);
               /*~-1*/
               }
               /*~E:I295*/
            /*~-1*/
            }
            /*~E:F290*/
            /*~A:296*/
            /*~+:alt*/
            /*~I:297*/
#ifdef MOF
            /*~F:298*/
            // Kennlinienpunkte
            case 0:
            case 255:
            /*~-1*/
            {
               /*~I:299*/
               if (!SYSTEM_MRW_MANAGER)
               /*~-1*/
               {
                  /*~T*/
                  Communication_SendString(COMMUNICATION_RS232,T_TEXT_CHARACTERISTICS,1,1);
                  // Tabellenkopf
                  Communication_SendString(COMMUNICATION_RS232,T_TEXT_HEADER_CHARACTERISTICS,1,0);
               /*~-1*/
               }
               /*~E:I299*/
               /*~L:300*/
               for (byTemperature = MRW_COMPENSATION_CORR_TEMP_HI;byTemperature >= MRW_COMPENSATION_CORR_TEMP_LO;byTemperature -= MRW_COMPENSATION_CORR_TEMP_SPAN)
               /*~-1*/
               {
                  /*~T*/
                  // Da die Ausgabe l�nger dauern kann, Watchdog retriggern
                  Watchdog();
                  /*~T*/
                  MRW_Compensation_GetData(MRW_COMPENSATION_GET_CHARACTERISTICS,byTemperature,&nCorrVal[0]);
                  MRW_Compensation_GetData(MRW_COMPENSATION_GET_CHARACTERISTICS_WITH_OFFSET,byTemperature,&nCorrVal[1]);
                  /*~I:301*/
                  if (!SYSTEM_MRW_MANAGER)
                  /*~-1*/
                  {
                     /*~T*/
                     sprintf(szString2Send,"%16bd",byTemperature);
                     Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);

                     sprintf(szString2Send,"%17d",nCorrVal[0]);
                     Communication_SendString(COMMUNICATION_RS232,szString2Send,0,0);

                     sprintf(szString2Send," (%5d)",nCorrVal[1]);
                     Communication_SendString(COMMUNICATION_RS232,szString2Send,0,0);
                  /*~-1*/
                  }
                  /*~O:I301*/
                  /*~-2*/
                  else
                  {
                     /*~I:302*/
                     if (byTemperature == MRW_COMPENSATION_CORR_TEMP_HI)
                     /*~-1*/
                     {
                        /*~I:303*/
#ifdef CHANNEL_0
                        /*~T*/
                        sprintf(szString2Send,"%c%bd;%d;%d",STX,byTemperature,nCorrVal[0],nCorrVal[0]);

                        /*~O:I303*/
                        /*~-1*/
#else
                        /*~I:304*/
#ifdef CHANNEL_1
                        /*~T*/
                        sprintf(szString2Send,";%bd;%d;%d",byTemperature,nCorrVal[0],nCorrVal[0]);
                        /*~-1*/
#endif
                        /*~E:I304*/
                        /*~-1*/
#endif
                        /*~E:I303*/
                     /*~-1*/
                     }
                     /*~O:I302*/
                     /*~-2*/
                     else
                     {
                        /*~T*/
                        sprintf(szString2Send,";%bd;%d;%d",byTemperature,nCorrVal[0],nCorrVal[0]);
                     /*~-1*/
                     }
                     /*~E:I302*/
                     /*~T*/
                     // und senden
                     Communication_SendRawString(COMMUNICATION_RS232,szString2Send);
                  /*~-1*/
                  }
                  /*~E:I301*/
               /*~-1*/
               }
               /*~E:L300*/
               /*~I:305*/
#ifdef CHANNEL_1 
               /*~I:306*/
               if (SYSTEM_MRW_MANAGER)
               /*~-1*/
               {
                  /*~T*/
                  // abschlie�end noch ein ETX senden
                  szString2Send[0] = 0x03;
                  szString2Send[1] = 0x00;
                  Communication_SendRawString(COMMUNICATION_RS232,szString2Send);
               /*~-1*/
               }
               /*~E:I306*/
               /*~-1*/
#endif
               /*~E:I305*/
               /*~I:307*/
               if ((chSelection != 255)||(SYSTEM_MRW_MANAGER))
               /*~-1*/
               {
                  /*~T*/
                  break;
               /*~-1*/
               }
               /*~O:I307*/
               /*~-2*/
               else
               {
                  /*~T*/
                  Communication_SendCR(1);
               /*~-1*/
               }
               /*~E:I307*/
            /*~-1*/
            }
            /*~E:F298*/
            /*~-1*/
#endif
            /*~E:I297*/
            /*~E:A296*/
            /*~E:A289*/
            /*~A:308*/
            /*~+:Extremwerte*/
            /*~F:309*/
            // Extremwerte Kanal 0
            case 1:
            /*~-1*/
            {
               /*~A:310*/
               /*~+:Variablendeklarationen*/
               /*~T*/
               char chTemperature;
               float fExtrema;
               long lExtrema;
               /*~E:A310*/
               /*~A:311*/
               /*~+:Variableninitialisierungen*/
               /*~T*/

               /*~E:A311*/
               /*~T*/
               // Da die Ausgabe l�nger dauern kann, Watchdog retriggern
               Watchdog();
               /*~I:312*/
               if (!SYSTEM_MRW_MANAGER)
               /*~-1*/
               {
                  /*~T*/
                  Communication_SendString(COMMUNICATION_RS232,T_TEXT_COMPENSATION_CHECK,1,1);
               /*~-1*/
               }
               /*~E:I312*/
               /*~A:313*/
               /*~+:Temperatur bei Maximalwert*/
               /*~T*/
               // Temperatur bei Maximalwert
               MRW_Compensation_GetData(MRW_COMPENSATION_GET_MAXIMUM_TEMP,0,&chTemperature);
               /*~I:314*/
               if (!SYSTEM_MRW_MANAGER)
               /*~-1*/
               {
                  /*~T*/
                  Communication_SendLong(COMMUNICATION_RS232,TEXT_MAXIMUM_AT_TEMPERATURE,chTemperature,0,1);
               /*~-1*/
               }
               /*~O:I314*/
               /*~-2*/
               else
               {
                  /*~T*/
                  sprintf(szString2Send,"%c%bd",STX,chTemperature);
                  /*~T*/
                  // und senden
                  Communication_SendRawString(COMMUNICATION_RS232,szString2Send);
               /*~-1*/
               }
               /*~E:I314*/
               /*~E:A313*/
               /*~A:315*/
               /*~+:Maximalwert*/
               /*~T*/
               // Maximalwert
               MRW_Compensation_GetData(MRW_COMPENSATION_GET_MAXIMUM_KG,0,&fExtrema);
               MRW_Compensation_GetData(MRW_COMPENSATION_GET_MAXIMUM_DIGIT,0,&lExtrema);
               /*~I:316*/
               if (!SYSTEM_MRW_MANAGER)
               /*~-1*/
               {
                  /*~T*/
                  sprintf(szString2Send,"%.2fkg (%ld)",fExtrema,lExtrema);
                  Communication_SendString(COMMUNICATION_RS232,T_TEXT_MAXIMUM,0,0);
                  Communication_SendString(COMMUNICATION_RS232,szString2Send,0,1);
               /*~-1*/
               }
               /*~O:I316*/
               /*~-2*/
               else
               {
                  /*~T*/
                  sprintf(szString2Send,";%f;%ld",fExtrema,lExtrema);
                  /*~T*/
                  // und senden
                  Communication_SendRawString(COMMUNICATION_RS232,szString2Send);
               /*~-1*/
               }
               /*~E:I316*/
               /*~E:A315*/
               /*~A:317*/
               /*~+:Temperatur bei Minimalwert*/
               /*~T*/
               // Temperatur bei Minimalwert
               MRW_Compensation_GetData(MRW_COMPENSATION_GET_MINIMUM_TEMP,0,&chTemperature);
               /*~I:318*/
               if (!SYSTEM_MRW_MANAGER)
               /*~-1*/
               {
                  /*~T*/
                  Communication_SendLong(COMMUNICATION_RS232,TEXT_MINIMUM_AT_TEMPERATURE,chTemperature,0,1);
               /*~-1*/
               }
               /*~O:I318*/
               /*~-2*/
               else
               {
                  /*~T*/
                  sprintf(szString2Send,";%bd",chTemperature);
                  /*~T*/
                  // und senden
                  Communication_SendRawString(COMMUNICATION_RS232,szString2Send);
               /*~-1*/
               }
               /*~E:I318*/
               /*~E:A317*/
               /*~A:319*/
               /*~+:Minimalwert*/
               /*~+:*/
               /*~T*/
               // Minimalwert
               MRW_Compensation_GetData(MRW_COMPENSATION_GET_MINIMUM_KG,0,&fExtrema);
               MRW_Compensation_GetData(MRW_COMPENSATION_GET_MINIMUM_DIGIT,0,&lExtrema);
               /*~I:320*/
               if (!SYSTEM_MRW_MANAGER)
               /*~-1*/
               {
                  /*~T*/
                  sprintf(szString2Send,"%.2fkg (%ld)",fExtrema,lExtrema);
                  Communication_SendString(COMMUNICATION_RS232,T_TEXT_MINIMUM,0,0);
                  Communication_SendString(COMMUNICATION_RS232,szString2Send,0,1);
               /*~-1*/
               }
               /*~O:I320*/
               /*~-2*/
               else
               {
                  /*~T*/
                  sprintf(szString2Send,";%f;%ld%c",fExtrema,lExtrema,ETX);
                  /*~T*/
                  // und senden
                  Communication_SendRawString(COMMUNICATION_RS232,szString2Send);
               /*~-1*/
               }
               /*~E:I320*/
               /*~E:A319*/
               /*~I:321*/
               if ((chSelection != 255)||(SYSTEM_MRW_MANAGER))
               /*~-1*/
               {
                  /*~T*/
                  break;
               /*~-1*/
               }
               /*~O:I321*/
               /*~-2*/
               else
               {
                  /*~T*/
                  Communication_SendCR(1);
               /*~-1*/
               }
               /*~E:I321*/
            /*~-1*/
            }
            /*~E:F309*/
            /*~E:A308*/
            /*~A:322*/
            /*~+:Nullpunktdrift*/
            /*~F:323*/
            // Nullpunktdrift Kanal 0
            case 3:
            /*~-1*/
            {
               /*~A:324*/
               /*~+:Variablendeklarationen*/
               /*~T*/
               long lDrift;
               float fDrift;
               /*~E:A324*/
               /*~A:325*/
               /*~+:Variableninitialisierungen*/
               /*~T*/

               /*~E:A325*/
               /*~T*/
               // Da die Ausgabe l�nger dauern kann, Watchdog retriggern
               Watchdog();
               /*~I:326*/
               if (!SYSTEM_MRW_MANAGER)
               /*~-1*/
               {
                  /*~T*/
                  Communication_SendString(COMMUNICATION_RS232,T_TEXT_DRIFT_CHECK,1,1);
               /*~-1*/
               }
               /*~E:I326*/
               /*~A:327*/
               /*~+:erster RMW bei Nenntemperatur*/
               /*~T*/
               // erster RMW bei Nenntemperatur
               MRW_Compensation_GetData(MRW_COMPENSATION_GET_1ST_REF_DRIFT,0,&lDrift);

               /*~I:328*/
               if (!SYSTEM_MRW_MANAGER)
               /*~-1*/
               {
                  /*~T*/
                  Communication_SendLong(COMMUNICATION_RS232,TEXT_1ST_DRIFT_MEASUREMENT,lDrift,0,1);

               /*~-1*/
               }
               /*~O:I328*/
               /*~-2*/
               else
               {
                  /*~T*/
                  sprintf(szString2Send,"%c%ld",STX,lDrift);
                  /*~T*/
                  // und senden
                  Communication_SendRawString(COMMUNICATION_RS232,szString2Send);
               /*~-1*/
               }
               /*~E:I328*/
               /*~E:A327*/
               /*~A:329*/
               /*~+:zweiter RMW bei Nenntemperatur*/
               /*~T*/
               // zweiter RMW bei Nenntemperatur
               MRW_Compensation_GetData(MRW_COMPENSATION_GET_2ND_REF_DRIFT,0,&lDrift);

               /*~I:330*/
               if (!SYSTEM_MRW_MANAGER)
               /*~-1*/
               {
                  /*~T*/
                  Communication_SendLong(COMMUNICATION_RS232,TEXT_2ND_DRIFT_MEASUREMENT,lDrift,0,1);
               /*~-1*/
               }
               /*~O:I330*/
               /*~-2*/
               else
               {
                  /*~T*/
                  sprintf(szString2Send,";%ld",lDrift);
                  /*~T*/
                  // und senden
                  Communication_SendRawString(COMMUNICATION_RS232,szString2Send);
               /*~-1*/
               }
               /*~E:I330*/
               /*~E:A329*/
               /*~A:331*/
               /*~+:daraus resultierender Drift*/
               /*~T*/
               // daraus resultierender Drift
               MRW_Compensation_GetData(MRW_COMPENSATION_GET_DRIFT_DIGIT,0,&lDrift);
               MRW_Compensation_GetData(MRW_COMPENSATION_GET_DRIFT_KG,0,&fDrift);
               /*~I:332*/
               if (!SYSTEM_MRW_MANAGER)
               /*~-1*/
               {
                  /*~T*/
                  sprintf(szString2Send,"%ld (%.2fkg)",lDrift,fDrift);
                  Communication_SendString(COMMUNICATION_RS232,T_TEXT_DRIFT,0,0);
                  Communication_SendString(COMMUNICATION_RS232,szString2Send,0,2);

               /*~-1*/
               }
               /*~O:I332*/
               /*~-2*/
               else
               {
                  /*~T*/
                  sprintf(szString2Send,";%ld;%f%c",lDrift,fDrift,ETX);
                  /*~T*/
                  // und senden
                  Communication_SendRawString(COMMUNICATION_RS232,szString2Send);
               /*~-1*/
               }
               /*~E:I332*/
               /*~E:A331*/
               /*~I:333*/
               if ((chSelection != 255)||(SYSTEM_MRW_MANAGER))
               /*~-1*/
               {
                  /*~T*/
                  break;
               /*~-1*/
               }
               /*~E:I333*/
            /*~-1*/
            }
            /*~E:F323*/
            /*~E:A322*/
            /*~A:334*/
            /*~+:Letzter abgearbeiteter Status*/
            /*~F:335*/
            // Letzter abgearbeiteter Status Kanal 0
            case 5:
            /*~-1*/
            {
               /*~A:336*/
               /*~+:Variablendeklarationen*/
               /*~T*/
               unsigned char byLastState;
               /*~E:A336*/
               /*~A:337*/
               /*~+:Variableninitialisierungen*/
               /*~T*/

               /*~E:A337*/
               /*~T*/
               // Da die Ausgabe l�nger dauern kann, Watchdog retriggern
               Watchdog();
               /*~T*/
               MRW_Compensation_GetData(MRW_COMPENSATION_GET_STATUS,0,&byLastState);
               /*~I:338*/
               if ((byLastState == 0xFF)&&(!SYSTEM_MRW_MANAGER))
               /*~-1*/
               {
                  /*~T*/
                  Communication_SendString(COMMUNICATION_RS232,T_TEXT_REC_CHARACTERISTICS_FINISHED,0,1);
               /*~-1*/
               }
               /*~O:I338*/
               /*~-2*/
               else
               {
                  /*~T*/
                  Communication_SendLong(COMMUNICATION_RS232,TEXT_LAST_EXECUTED_STATE_REC_CHARACTERISTICS,byLastState,0,1);
               /*~-1*/
               }
               /*~E:I338*/
               /*~I:339*/
               if ((chSelection != 255)||(SYSTEM_MRW_MANAGER))
               /*~-1*/
               {
                  /*~T*/
                  break;
               /*~-1*/
               }
               /*~E:I339*/
            /*~-1*/
            }
            /*~E:F335*/
            /*~E:A334*/
            /*~A:340*/
            /*~+:Fehler-Status*/
            /*~F:341*/
            // Fehler-Status Kanal 0
            case 7:
            /*~-1*/
            {
               /*~A:342*/
               /*~+:Variablendeklarationen*/
               /*~T*/
               unsigned char byErrorState;
               /*~E:A342*/
               /*~A:343*/
               /*~+:Variableninitialisierungen*/
               /*~T*/

               /*~E:A343*/
               /*~T*/
               // Da die Ausgabe l�nger dauern kann, Watchdog retriggern
               Watchdog();
               /*~T*/
               MRW_Compensation_GetData(MRW_COMPENSATION_GET_ANALYSIS,0,&byErrorState);

               /*~I:344*/
               if (!SYSTEM_MRW_MANAGER)
               /*~-1*/
               {
                  /*~I:345*/
                  if (byErrorState)
                  /*~-1*/
                  {
                     /*~I:346*/
                     if (byErrorState & 0x01)
                     /*~-1*/
                     {
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,T_TEXT_DRIFT_FAULT,0,1);
                     /*~-1*/
                     }
                     /*~E:I346*/
                     /*~I:347*/
                     if (byErrorState & 0x02)
                     /*~-1*/
                     {
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,T_TEXT_COMPENSATION_CHECK_FAULT_MINIMUM,0,1);
                     /*~-1*/
                     }
                     /*~E:I347*/
                     /*~I:348*/
                     if (byErrorState & 0x04)
                     /*~-1*/
                     {
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,T_TEXT_COMPENSATION_CHECK_FAULT_MAXIMUM,0,1);
                     /*~-1*/
                     }
                     /*~E:I348*/
                     /*~I:349*/
                     if (byErrorState & 0x10)
                     /*~-1*/
                     {
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,T_TEXT_DRIFT_CHECK_NOT_EXECUTED,0,1);
                     /*~-1*/
                     }
                     /*~E:I349*/
                     /*~I:350*/
                     if (byErrorState & 0x20)
                     /*~-1*/
                     {
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,T_TEXT_CHARACTERISTICS_NOT_RECORDED,0,1);
                     /*~-1*/
                     }
                     /*~E:I350*/
                     /*~I:351*/
                     if (byErrorState & 0x40)
                     /*~-1*/
                     {
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,T_TEXT_EXTREMES_NOT_RECORDED,0,1);
                     /*~-1*/
                     }
                     /*~E:I351*/
                     /*~I:352*/
                     if (byErrorState & 0x80)
                     /*~-1*/
                     {
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,T_TEXT_NOTHING_DONE,0,1);
                     /*~-1*/
                     }
                     /*~E:I352*/
                  /*~-1*/
                  }
                  /*~O:I345*/
                  /*~-2*/
                  else
                  {
                     /*~I:353*/
#ifdef CHANNEL_0
                     /*~T*/
                     Communication_SendString(COMMUNICATION_RS232,T_TEXT_COMPENSATION_EVERYTHING_IS_OKAY_CHANNEL_0,0,1);
                     /*~-1*/
#endif
                     /*~E:I353*/
                     /*~I:354*/
#ifdef CHANNEL_1
                     /*~T*/
                     Communication_SendString(COMMUNICATION_RS232,T_TEXT_COMPENSATION_EVERYTHING_IS_OKAY_CHANNEL_1,0,1);
                     /*~-1*/
#endif
                     /*~E:I354*/
                  /*~-1*/
                  }
                  /*~E:I345*/
               /*~-1*/
               }
               /*~O:I344*/
               /*~-2*/
               else
               {
                  /*~T*/
                  Communication_SendLong(COMMUNICATION_RS232,0,byErrorState,0,1);
               /*~-1*/
               }
               /*~E:I344*/
               /*~I:355*/
               if ((chSelection != 255)||(SYSTEM_MRW_MANAGER))
               /*~-1*/
               {
                  /*~T*/
                  break;
               /*~-1*/
               }
               /*~O:I355*/
               /*~-2*/
               else
               {
                  /*~T*/
                  Communication_SendCR(1);
               /*~-1*/
               }
               /*~E:I355*/
            /*~-1*/
            }
            /*~E:F341*/
            /*~E:A340*/
            /*~I:356*/
#ifdef CHANNEL_1
            /*~A:357*/
            /*~+:Formularfu�*/
            /*~F:358*/
            case 8:
            /*~-1*/
            {
               /*~I:359*/
               if ((chSelection == 255)&&(!SYSTEM_MRW_MANAGER))
               /*~-1*/
               {
                  /*~T*/
                  Communication_SendCR(4);
                  Communication_SendString(COMMUNICATION_RS232,T_TEXT_FEEDER_CHARACTERISTICS,1,1);
               /*~-1*/
               }
               /*~E:I359*/
               /*~T*/
               break;
            /*~-1*/
            }
            /*~E:F358*/
            /*~E:A357*/
            /*~-1*/
#endif
            /*~E:I356*/
         /*~-1*/
         }
         /*~E:C288*/
         /*~I:360*/
         if (chSelection == 255)
         /*~-1*/
         {
            /*~K*/
            /*~+:// da wg. der langen Zeitdauer ggf. die Synchronistationspr�fung ausgeschaltet wurde, diese wieder einschalten*/
            /*~T*/
            System_SetCheckSynchronisation(1);
         /*~-1*/
         }
         /*~E:I360*/
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F277*/
      /*~E:A276*/
   /*~-1*/
   }
   /*~E:C61*/
   /*~A:361*/
   /*~+:R�ckschaltung MRW-Manager-/Docklight-Modus - ausgeklammert*/
   /*~I:362*/
#ifdef MOF
   /*~I:363*/
   if (!byDocklightModus)
   /*~-1*/
   {
      /*~T*/
      // Docklight-Modus verlassen
      System_Connect2MRW_Manager(1);
   /*~-1*/
   }
   /*~E:I363*/
   /*~-1*/
#endif
   /*~E:I362*/
   /*~E:A361*/
/*~-1*/
}
/*~E:F55*/
/*~E:A54*/
/*~A:364*/
/*~+:char 			Compensation_SetCompensationValues(char chTemperature, int nValue2Set)*/
/*~F:365*/
char Compensation_SetCompensationValues(char chTemperature, int nValue2Set)
/*~-1*/
{
   /*~T*/
   return MRW_Compensation_SetRefPoints(chTemperature,nValue2Set);
/*~-1*/
}
/*~E:F365*/
/*~E:A364*/
/*~A:366*/
/*~+:void 			Compensation_SuppressOutput(unsigned char bSuppress)*/
/*~F:367*/
void Compensation_SuppressOutput(unsigned char bSuppress)
/*~-1*/
{
   /*~T*/
   g_bySuppressOutput = bSuppress; 
/*~-1*/
}
/*~E:F367*/
/*~E:A366*/
/*~K*/
/*~+:*/
/*~A:368*/
/*~+:unsigned char 	Load_MRW_Compensation(MRW_COMPENSATION_TEMPERATURE_COMPENSATION* pMRW_Compensation)*/
/*~F:369*/
unsigned char Load_MRW_Compensation(MRW_COMPENSATION_TEMPERATURE_COMPENSATION* pMRW_Compensation)
/*~-1*/
{
   /*~T*/
   Load_Parameter(LOAD_SAVE_COMPENSATION,pMRW_Compensation,sizeof(MRW_COMPENSATION_TEMPERATURE_COMPENSATION));
   /*~T*/
   return 0;
/*~-1*/
}
/*~E:F369*/
/*~E:A368*/
/*~A:370*/
/*~+:unsigned char 	Load_MRW_CompensationLimits(MRW_COMPENSATION_LIMITS* pMRW_CompensationLimits)*/
/*~F:371*/
unsigned char Load_MRW_CompensationLimits(MRW_COMPENSATION_LIMITS* pMRW_CompensationLimits)
/*~-1*/
{
   /*~T*/
   Load_Parameter(LOAD_SAVE_COMPENSATIONLIMITS,pMRW_CompensationLimits,sizeof(MRW_COMPENSATION_LIMITS));
   /*~T*/
   return 0;
/*~-1*/
}
/*~E:F371*/
/*~E:A370*/
/*~A:372*/
/*~+:unsigned char 	Save_MRW_Compensation(MRW_COMPENSATION_TEMPERATURE_COMPENSATION MRW_Compensation)*/
/*~F:373*/
unsigned char Save_MRW_Compensation(MRW_COMPENSATION_TEMPERATURE_COMPENSATION MRW_Compensation)
/*~-1*/
{
   /*~T*/
   // Da das Speichern der Daten ins Eeprom etwas l�nger dauern kann, hier den Watchdog neu anstossen
   Watchdog();
   /*~T*/
   return Save_Parameter(LOAD_SAVE_COMPENSATION,&MRW_Compensation,sizeof(MRW_COMPENSATION_TEMPERATURE_COMPENSATION));
   /*~T*/
   // Da das Speichern der Daten ins Eeprom etwas l�nger dauern kann, hier den Watchdog neu anstossen
   Watchdog();
/*~-1*/
}
/*~E:F373*/
/*~E:A372*/
/*~A:374*/
/*~+:unsigned char 	Save_MRW_CompensationLimits(MRW_COMPENSATION_LIMITS MRW_CompensationLimits)*/
/*~F:375*/
unsigned char Save_MRW_CompensationLimits(MRW_COMPENSATION_LIMITS MRW_CompensationLimits)
/*~-1*/
{
   /*~T*/
   return Save_Parameter(LOAD_SAVE_COMPENSATIONLIMITS,&MRW_CompensationLimits,sizeof(MRW_COMPENSATION_LIMITS));
/*~-1*/
}
/*~E:F375*/
/*~E:A374*/
