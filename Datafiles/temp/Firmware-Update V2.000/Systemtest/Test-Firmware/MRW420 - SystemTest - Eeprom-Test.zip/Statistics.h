/*~-1*/
/*~XSF_LANGUAGE: C/C++*/
/*~A:1*/
/*~+:Versions-Beschreibung*/
/*~T*/
/*!
\mainpage "Modul-Beschreibung"
\author Michael Offenbach
\date Erstellung :     07.02.2006
\date Letzte �nderung:  
\version V1.000
\warning
*/
/*~E:A1*/
/*~A:2*/
/*~+:Manual*/
/*~A:3*/
/*~+:char Muster_Funktion(unsigned char byVariable_1, int nVariable_2)*/
/*~T*/
/*!
\fn char Muster_Funktion(unsigned char byVariable_1, int nVariable_2)

<b>Beschreibung:</b><br>
Funktionsbeschreibung hier einf�gen.
 
\param
byVariable_1: Beschreibung des Parameters 1.

\param
byVariable_2: Beschreibung des Parameters 2.

\return
Allgemeine Beschreibung der R�ckgabe.

\retval
0: Beschreibung des R�ckgabewertes 0 

\retval
1: Beschreibung des R�ckgabewertes 1 

<b>Zugriff:</b><br>
[X] �ffentlich / [ ] Privat

\ref
ExamplePage_Muster "Beispiel 'Musterprojekt'"
*/
/*~E:A3*/
/*~K*/
/*~+:*/
/*~A:4*/
/*~+:Ziel-Hardware*/
/*~T*/
/*!\page HardwarePage Ziel-Hardware

\section sec_HardwarePage_Muster 'Muster'

<table border=1 width=100% height=1% rules=rows cellspacing=0 bgcolor="#E0E0F0">

<tr align=left valign=top>
	<th>Motherboard</th>
	<th>Prozessor</th>
	<th>ROM</th>
	<th>RAM</th>
</tr>

<tr>
	<td>MRW-Limit V1.2B 2/2004</td>
	<td>8051-Core</td>
	<td>62 <B>kByte</B></td>
	<td>2 <B>kByte</B></td>
</tr></table>

*/
/*~E:A4*/
/*~A:5*/
/*~+:Compiler-Einstellungen*/
/*~T*/
/*!\page CompilerPage Compiler-Einstellungen

\section sec_CompilerPage_Muster 'Musterprojekt'

<table border=1 width=100% height=1% rules=rows cellspacing=0 bgcolor="#E0E0F0">

<tr align=left valign=top>
	<th>Compiler</th>
	<th>Betriebssystem</th>
	<th>Speichermodell</th>
	<th>Code-Speicher-Gr��e</th>
	<th>Optimierungen</th>
	<th>Sonstiges</th>
</tr>

<tr>
	<td>Keil uVision2 V2.40<BR>C51 V7.08<BR>A51 V7.08a</td>
	<td>Kein Betriebssystem</td>
	<td>Large: variables in XDATA</td>
	<td>Large: 64k program</td>
	<td>6 Loop rotation<BR>Favor speed</td>
	<td>---</td>
</tr></table>

*/
/*~E:A5*/
/*~A:6*/
/*~+:Ressourcen*/
/*~T*/
/*!\page RessourcePage Ressourcen

\section sec_RessourcePage_Musterr 'Musterprojekt'

<table border=1 width=100% height=1% rules=rows cellspacing=0 bgcolor="#E0E0F0">

<tr align=left valign=top>
	<th>CODE</th>
	<th>IDATA</th>
	<th>XDATA</th>
	<th>Dynamische Variablen</th>
</tr>

<tr>
	<td>--- <B>Bytes</B></td>
	<td>--- <B>Bytes</B></td>
	<td>--- <B>Bytes</B></td>
	<td>--- <B>Bytes</B></td>
</tr></table>

*/
/*~E:A6*/
/*~A:7*/
/*~+:Zykluszeiten*/
/*~T*/
/*!\page CycletimePage Zykluszeiten

\section sec_CycletimePage_Muster 'Musterprojekt'

<table border=1 width=100% height=1% rules=rows cellspacing=0 bgcolor="#E0E0F0">

<tr align=left valign=top>
	<th>Minimale Durchlaufzeit</th>
	<th>Maximale Durchlaufzeit</th>
</tr>

<tr>
	<td>--- <B>ms</B></td>
	<td>--- <B>ms</B></td>
</tr></table>

*/
/*~E:A7*/
/*~A:8*/
/*~+:Verschiedenes*/
/*~T*/
/*!\page MiscPage Verschiedenes

\section sec_MiscPage_Muster 'Musterprojekt'

<table border=1 width=100% height=1% rules=rows cellspacing=0 bgcolor="#E0E0F0">

<tr align=left valign=top>
	<th>Benutzte Interrups</th>
	<th>Benutzte Registerb�nke</th>
</tr>

<tr>
	<td>---</td>
	<td>---</td>
</tr></table>

*/
/*~E:A8*/
/*~A:9*/
/*~+:Lifecycle*/
/*~T*/
/*!\page LifeCyclePage Lifecycle

\section sec_LifeCyclePage_Muster 'Musterprojekt'

<table border=1 width=100% height=1% rules=rows cellspacing=0 bgcolor="#E0E0F0">

<tr align=left valign=top>
	<th>Version</th>
	<th>Datum</th>
	<th>Programmierer</th>
	<th>�nderungen</th>
</tr>

<tr>
	<td>1.000</td>
	<td>18.03.05</td>
	<td>Michael Offenbach</td>
	<td>Erste lauff�hige Version</td>
</tr>

</table>
*/
/*~E:A9*/
/*~A:10*/
/*~+:Beispiel*/
/*~T*/
/*!\page ExamplePage_Muster Beispiel 'Musterprojekt'
\code

main()
{
	Muster_Funktion(1,2);
}
\endcode
*/ 
/*~E:A10*/
/*~E:A2*/
/*~I:11*/
#ifndef __STATISTICS_H

/*~T*/
#define __STATISTICS_H

/*~A:12*/
/*~+:Includes*/
/*~T*/
#include "StatisticsLibrary.h"
/*~E:A12*/
/*~A:13*/
/*~+:Definitionen*/
/*~T*/

/*~E:A13*/
/*~A:14*/
/*~+:Struktur-Definitionen*/
/*~T*/

/*~E:A14*/
/*~A:15*/
/*~+:Funktionsdeklarationen*/
/*~T*/
extern void 					Statistics(void);
extern void 					Statistics_Clear(unsigned char chWhat2Clear);
extern STATISTICSLIBRARY_SETUP 	Statistics_GetSetup(void);
extern void 					Statistics_Ini(char byClearResults);
extern void 					Statistics_PrintData(unsigned char chWhat2Print);
extern void 					Statistics_SetSetup(STATISTICSLIBRARY_SETUP StatisticsSetup);

extern void 					Statistics_Setup(char byDefault);
/*~E:A15*/
/*~A:16*/
/*~+:Variablen*/
/*~T*/

/*~E:A16*/
/*~-1*/
#endif
/*~E:I11*/
