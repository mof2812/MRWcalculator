/*~-1*/
/*~XSF_LANGUAGE: C/C++*/
/*~K*/
/*~+:File :        Watchdog.c*/
/*~+:*/
/*~+:Version :     V1.0*/
/*~+:*/
/*~+:Date :        04.07.2005*/
/*~+:*/
/*~+:Time :        10:23*/
/*~+:*/
/*~+:Author :      MOF*/
/*~+:*/
/*~+:Hardware :*/
/*~+:*/
/*~+:Description : Routinen zur Watchdog�berwachung.*/
/*~A:1*/
/*~+:Includes*/
/*~T*/
#include "Watchdog.h"
/*~E:A1*/
/*~A:2*/
/*~+:Funktionseigene Definitionen*/
/*~T*/
#define WATCHDOG_COUNTER_SET		5			///< 500ms zus�tzlich
/*~T*/
#define WD_ENANBLE  	P20			///< Watchdog-Enable-Pin
#define WD_INTERRUPT 	P34			///< WDI-Pin 
/*~E:A2*/
/*~A:3*/
/*~+:Funktionseigene Struktur-Definitionen*/
/*~T*/

/*~E:A3*/
/*~A:4*/
/*~+:Funktionsprototypen*/
/*~T*/
void Watchdog(void);
void Watchdog_Ini(void);
void Watchdog_Retrigger(void);
unsigned char WatchdogInterface(unsigned char chWhat2Do,unsigned int *pnWatchdogAddress);
/*~E:A4*/
/*~A:5*/
/*~+:Globale Variablen*/
/*~T*/

/*~E:A5*/
/*~A:6*/
/*~+:void 			Watchdog(void)*/
/*~F:7*/
void Watchdog(void)
/*~-1*/
{
   /*~I:8*/
#ifndef NO_WATCHDOG 
   /*~T*/
   Watchdog_Retrigger();
   /*~-1*/
#endif
   /*~E:I8*/
/*~-1*/
}
/*~E:F7*/
/*~E:A6*/
/*~A:9*/
/*~+:void 			Watchdog_Ini(void)*/
/*~F:10*/
void Watchdog_Ini(void)
/*~-1*/
{
   /*~I:11*/
#ifdef SW_WATCHDOG
   /*~A:12*/
   /*~+:Software-Watchdog initialisieren*/
   /*~I:13*/
   // Software-Watchdog initialisieren
#ifndef NO_WATCHDOG 
   /*~T*/
   ADuC836_WatchdogDefaultIni();
   /*~-1*/
#endif
   /*~E:I13*/
   /*~E:A12*/
   /*~-1*/
#endif
   /*~E:I11*/
   /*~I:14*/
#ifdef HW_WATCHDOG 
   /*~A:15*/
   /*~+:Hardware-Watchdog initialisieren*/
   /*~I:16*/
   // Hardware-Watchdog initialisieren
#ifdef NO_WATCHDOG
   /*~T*/
   WD_ENANBLE = 1;
   /*~O:I16*/
   /*~-1*/
#else
   /*~T*/
   WD_ENANBLE = 0;
   /*~-1*/
#endif
   /*~E:I16*/
   /*~E:A15*/
   /*~-1*/
#endif
   /*~E:I14*/
/*~-1*/
}
/*~E:F10*/
/*~E:A9*/
/*~A:17*/
/*~+:void 			Watchdog_Retrigger(void)*/
/*~F:18*/
void Watchdog_Retrigger(void)
/*~-1*/
{
   /*~I:19*/
#ifndef NO_WATCHDOG 
   /*~I:20*/
#ifdef SW_WATCHDOG
   /*~A:21*/
   /*~+:Software-Watchdog neu antriggern*/
   /*~T*/
   // Software-Watchdog neu antriggern
   ADuC836_WatchdogRetrigger();
   /*~E:A21*/
   /*~-1*/
#endif
   /*~E:I20*/
   /*~I:22*/
#ifdef HW_WATCHDOG 
   /*~A:23*/
   /*~+:Hardware-Watchdog neu antriggern*/
   /*~T*/
   // Hardware-Watchdog neu antriggern
   WD_INTERRUPT = !WD_INTERRUPT;
   /*~E:A23*/
   /*~-1*/
#endif
   /*~E:I22*/
   /*~-1*/
#endif
   /*~E:I19*/
/*~-1*/
}
/*~E:F18*/
/*~E:A17*/
/*~A:24*/
/*~+:unsigned char 	WatchdogInterface(unsigned char chWhat2Do,unsigned int *pnWatchdogAddress)*/
/*~F:25*/
unsigned char WatchdogInterface(unsigned char chWhat2Do,unsigned int *pnWatchdogAddress)
/*~-1*/
{
   /*~C:26*/
   switch (chWhat2Do)
   /*~-1*/
   {
      /*~F:27*/
      case ADuC836_WATCHDOG_READADDRESS:	///< R�ckgabe der letzten Adresse an der ein WD eintrat
      /*~-1*/
      {
         /*~T*/
         // Adresse des letzten Interrupts auslesen
         Load_Parameter(LOAD_SAVE_WATCHDOG_ADDRESS,pnWatchdogAddress,2);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F27*/
      /*~F:28*/
      case ADuC836_WATCHDOG_WRITEADDRESS:	///< Adresse des aktuell anstehenden Interrups ablegen
      /*~-1*/
      {
         /*~T*/
         // Adresse des aktuell anstehenden Interrups im Eeprom speichern 
         Save_Parameter(LOAD_SAVE_WATCHDOG_ADDRESS,pnWatchdogAddress,2);

         /*~A:29*/
         /*~+:Eintrag im Diagnosespeicher vornehmen*/
         /*~T*/
         // Eintrag im Diagnosespeicher vornehmen
         Diagnosis_WriteMessage2Flash(DIAGNOSIS_ERROR_WATCHDOG);
         /*~E:A29*/
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F28*/
      /*~F:30*/
      case ADuC836_WATCHDOG_CLEARADDRESS:
      /*~-1*/
      {
         /*~T*/
         // Watchdogadresse auf 0 setzen
         *pnWatchdogAddress = 0;
         // Adresse des aktuell anstehenden Interrups im Eeprom speichern 
         Save_Parameter(LOAD_SAVE_WATCHDOG_ADDRESS,pnWatchdogAddress,2);

         /*~A:31*/
         /*~+:Eintrag im Diagnosespeicher vornehmen*/
         /*~T*/
         // Eintrag im Diagnosespeicher vornehmen
         Diagnosis_WriteMessage2Flash(DIAGNOSIS_MESSAGE_CLEAR_WATCHDOG);
         /*~E:A31*/
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F30*/
   /*~-1*/
   }
   /*~E:C26*/
   /*~T*/
   return 0;
/*~-1*/
}
/*~E:F25*/
/*~E:A24*/
