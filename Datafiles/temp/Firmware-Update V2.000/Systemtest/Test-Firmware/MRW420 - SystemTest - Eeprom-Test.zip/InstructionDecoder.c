/*~-1*/
/*~XSF_LANGUAGE: C/C++*/
/*~K*/
/*~+:File :        InstuctionDecoder.c*/
/*~+:*/
/*~+:Version :     V1.002*/
/*~+:*/
/*~+:Date :        21.11.2021*/
/*~+:*/
/*~+:Time :        10:23*/
/*~+:*/
/*~+:Author :      MOF*/
/*~+:*/
/*~+:Hardware :*/
/*~+:*/
/*~+:Description :*/
/*~+:*/
/*~+:*/
/*~A:1*/
/*~+:Includes*/
/*~T*/
#include "global.h"
#include "InstructionDecoder.h"
#include "ADuc836Driver.h"
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
/*~E:A1*/
/*~A:2*/
/*~+:Funktionseigene Definitionen und Makros*/
/*~T*/
#define DATATYPE_CHAR									0
#define DATATYPE_UNSIGNED_CHAR							1
#define DATATYPE_INT									2
#define DATATYPE_UNSIGNED_INT							3
#define DATATYPE_LONG									4
#define DATATYPE_UNSIGNED_LONG							5
#define DATATYPE_FLOAT									6
/*~T*/
#define SHOW_ERRORS_BY_NONE								0x00
#define SHOW_ERRORS_BY_CH0								0x01
#define SHOW_ERRORS_BY_CH1								0x02
#define SHOW_ERRORS_BY_ALL								0x03
/*~T*/
#define HANDSHAKING_TIMEOUT								500
/*~I:3*/
#ifdef CHANNEL_0
/*~T*/
#define GET_RESPONSE				Communication_GetSPIResponse()
#define RELEASE_INSTRUCTIONDECODER	System_ReleaseExternalInterrupt()
/*~-1*/
#endif
/*~E:I3*/
/*~I:4*/
#ifdef CHANNEL_1
/*~T*/
#define GET_RESPONSE		(bDoNotWriteResult2Buffer = 0)
/*~-1*/
#endif
/*~E:I4*/
/*~E:A2*/
/*~A:5*/
/*~+:Funktionseigene Struktur-Definitionen*/
/*~T*/

/*~E:A5*/
/*~A:6*/
/*~+:Funktionsprototypen*/
/*~T*/
void 			InstructionDecoder(void);
char 			InstructionDecoder_CheckLimits(void *pParameter2Check, void *pLimitLow, void *pLimitHigh,unsigned char chDataType);

char 			InstructionDecoder_CheckNbParameters(unsigned char byNbParametersExpected,char byShowErrorsBy,unsigned char *pStatus);

void 			InstructionDecoder_SendStoredValue(unsigned char byValue2Get);

void 			InstructionDecoder_StoreValue(unsigned char byValue2Store,GLOBAL_UNIVALUE_SHORT* pValue);

/*~K*/
/*~+:/~* Hinzugef�gt am 09.02.2022 *~/*/
/*~T*/
extern unsigned long 	Main_UpdateRetains(unsigned long ulFromVersion);
/*~K*/
/*~+:/~* Ende - Hinzugef�gt am 09.02.2022 *~/*/
/*~T*/


/*~E:A6*/
/*~A:7*/
/*~+:Globale Variablen*/
/*~T*/
unsigned char g_chRCWLast;
/*~I:8*/
#ifdef CHANNEL_1
/*~T*/
unsigned char g_byLastCommandExecutionResult = 0xA5;		///< Letztes Ergebnis einer Funktionsausf�hrung. Es ist noch nichts eingetragen
/*~T*/
unsigned char 			g_byValueStored = 0;		///< Angabe zum gespeicherten Wert
GLOBAL_UNIVALUE_SHORT 	g_Value;					///< zu �bergebender Wert
unsigned long 			g_ulTimeoutValue;			///< Zeit, zu der der Wert sp�testens gel�scht wird
/*~-1*/
#endif
/*~E:I8*/
/*~E:A7*/
/*~A:9*/
/*~+:void 			InstructionDecoder(void)*/
/*~F:10*/
void InstructionDecoder(void)
/*~-1*/
{
   /*~A:11*/
   /*~+:Variablendeklarationen*/
   /*~T*/
   unsigned char 		szCommand[80];
   unsigned char 		byChecksumError = FALSE;
   unsigned char 		byCommandStatus;
   unsigned long 		lText2Send;
   unsigned long		ulDiagnosisEntry2Set;

   /*~I:12*/
#ifdef CHANNEL_1
   /*~T*/
   static unsigned long		ulDiagnosisEntry2SetAtiGRS = 0;

   /*~-1*/
#endif
   /*~E:I12*/
   /*~T*/
   GLOBAL_UNIVALUE 	Parameter[4];
   unsigned char 		byTemp;
   float fTemp;
   unsigned char 		byRetVal;
   MEASUREMENT_VALUE 	MVTemp;
   unsigned char 		byLoopCounter;
   char 				szString2Send[24];

   /*~I:13*/
#ifdef CHANNEL_0
   /*~T*/
   unsigned char 		byStartPartnerInstructionDecoder;
   unsigned char		byStatelineStatus;
   /*~-1*/
#endif
   /*~E:I13*/
   /*~I:14*/
#ifdef CHANNEL_1
   /*~T*/
   // GLOBAL_UNIVALUE 	ParameterRead;
   unsigned char 		bDoNotWriteResult2Buffer;
   /*~I:15*/
#ifdef SYSTEM_CND_ENABLE_SPI_DEBUGGING
   /*~T*/
   // Nur zu Testzwecken
   char achString[24];
   /*~-1*/
#endif
   /*~E:I15*/
   /*~K*/
   /*~+:/~* Hinzugef�gt am 09.02.2022 *~/*/
   /*~T*/
   static unsigned char 	bDoReset = 0;
   /*~K*/
   /*~+:/~* Ende - Hinzugef�gt am 09.02.2022 *~/*/
   /*~-1*/
#endif
   /*~E:I14*/
   /*~E:A11*/
   /*~A:16*/
   /*~+:Variableninitialisierungen*/
   /*~I:17*/
#ifdef CHANNEL_0
   /*~T*/
   byCommandStatus = INSTRUCTIONDECODER_SEND_E004;

   /*~-1*/
#endif
   /*~E:I17*/
   /*~I:18*/
#ifdef CHANNEL_1
   /*~T*/
   byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
   bDoNotWriteResult2Buffer = 1;

   /*~-1*/
#endif
   /*~E:I18*/
   /*~T*/
   ulDiagnosisEntry2Set = 0;
   lText2Send = 0;
   byRetVal = 0;
   byLoopCounter = 5;
   byChecksumError = FALSE;

   /*~I:19*/
#ifdef CHANNEL_0
   /*~T*/
   byStartPartnerInstructionDecoder = 0;
   /*~-1*/
#endif
   /*~E:I19*/
   /*~E:A16*/
   /*~A:20*/
   /*~+:Befehlsauswertung und -ausf�hrung*/
   /*~A:21*/
   /*~+:Kanal 0 - Zugangssteuerung*/
   /*~I:22*/
#ifdef CHANNEL_0
   /*~I:23*/
   if (ADuC836_RS232IsNewCommand())
   /*~-1*/
   {
      /*~K*/
      /*~+:// �ber die RS232 kam ein Kommando rein */
      /*~T*/
      CommunicationControl.chLine2Interprete = COMMUNICATION_RS232;
      /*~T*/
      // R�ckleitung des Handshakings auf HIGH legen
      COMMUNICATION_INSTUCTIONDECODER_STATE_LINE = TRUE;
      /*~T*/
      // Status der Instuction-Decoder - Leitung abfragen und den Status zwischenspeichern

      byStatelineStatus = COMMUNICATION_INSTUCTIONDECODER_STATE_LINE;
      /*~T*/
      // Freigabeleitung f�r Start des Instruction-Decoders auf Partner-Seite setzen

      COMMUNICATION_INSTUCTIONDECODER_RELEASE_LINE = 1;	
   /*~-1*/
   }
   /*~O:I23*/
   /*~-2*/
   else
   {
      /*~K*/
      /*~+:// Es gibt nichts zu tun*/
      /*~T*/
      return;
   /*~-1*/
   }
   /*~E:I23*/
   /*~-1*/
#endif
   /*~E:I22*/
   /*~E:A21*/
   /*~A:24*/
   /*~+:Kanal 1 - Zugangssteuerung*/
   /*~I:25*/
#ifdef CHANNEL_1
   /*~I:26*/
   if (ADuC836_SPIIsNewCommand())
   /*~-1*/
   {
      /*~K*/
      /*~+:// �ber die SPI kam ein Kommando rein */
      /*~T*/
      CommunicationControl.chLine2Interprete = COMMUNICATION_SPI;
   /*~-1*/
   }
   /*~O:I26*/
   /*~-2*/
   else
   {
      /*~I:27*/
      if (COMMUNICATION_INSTUCTIONDECODER_STATE_LINE)
      /*~-1*/
      {
         /*~T*/
         // Partner hat die RS232-Abarbeitung des Instruction-Decoders freigegeben
         /*~I:28*/
         if (ADuC836_RS232IsNewCommand())
         /*~-1*/
         {
            /*~T*/
            // R�ckleitung des Handshakings auf HIGH legen
            COMMUNICATION_INSTUCTIONDECODER_STATE_LINE = TRUE;
            /*~K*/
            /*~+:// �ber die RS232 kam ein Kommando rein */
            /*~T*/
            CommunicationControl.chLine2Interprete = COMMUNICATION_RS232;
            /*~A:29*/
            /*~+:Das Ergebnis der letzten Ausf�hrung zur�cksetzen*/
            /*~T*/
            // Das Ergebnis der letzten Ausf�hrung zur�cksetzen

            g_byLastCommandExecutionResult = 0xA5;
            /*~E:A29*/
         /*~-1*/
         }
         /*~O:I28*/
         /*~-2*/
         else
         {
            /*~K*/
            /*~+:// Es gibt nichts zu tun*/
            /*~T*/
            return;
         /*~-1*/
         }
         /*~E:I28*/
      /*~-1*/
      }
      /*~O:I27*/
      /*~-2*/
      else
      {
         /*~T*/
         return;
      /*~-1*/
      }
      /*~E:I27*/
   /*~-1*/
   }
   /*~E:I26*/
   /*~-1*/
#endif
   /*~E:I25*/
   /*~E:A24*/
   /*~A:30*/
   /*~+:Befehl holen, auswerten und ggf. Pr�fsumme bilden*/
   /*~T*/
   Communication_GetRecBuffer(CommunicationControl.chLine2Interprete,szCommand);
   /*~I:31*/
#ifdef MIT_CRC16
   /*~I:32*/
   if ((CommunicationControl.chLine2Interprete == COMMUNICATION_RS232)&&(strncmp(szCommand,"CDL",3) != 0))
   /*~-1*/
   {
      /*~T*/
      byChecksumError = Communication_CheckReceiveFrame(szCommand);

   /*~-1*/
   }
   /*~E:I32*/
   /*~-1*/
#endif
   /*~E:I31*/
   /*~T*/
   strcpy(szCommand,Communication_Interpret(szCommand));
   /*~E:A30*/
   /*~I:33*/
#ifdef MIT_CRC16
   /*~A:34*/
   /*~+:Nur bei CRC16-Pr�fung*/
   /*~I:35*/
#ifdef CHANNEL_0
   /*~I:36*/
   if (CommunicationControl.chLine2Interprete == COMMUNICATION_RS232)
   /*~-1*/
   {
      /*~A:37*/
      /*~+:Ausgabe Teil 1 - Fehlermeldung wg. fehlerhafter CRC*/
      /*~A:38*/
      /*~+:Warte bis Kanal 1 die Freigabe wieder zur�ckgibt*/
      /*~F:39*/
      // Warte bis Kanal 1 die Freigabe wieder zur�ckgibt
      /*~-1*/
      {
         /*~T*/
         ulTimeout = SYSTEMTIME + HANDSHAKING_TIMEOUT; 
         /*~L:40*/
         while ((byStatelineStatus == COMMUNICATION_INSTUCTIONDECODER_STATE_LINE)&&(ulTimeout >= SYSTEMTIME))
         /*~-1*/
         {
            /*~T*/

         /*~-1*/
         }
         /*~E:L40*/
      /*~-1*/
      }
      /*~E:F39*/
      /*~E:A38*/
      /*~A:41*/
      /*~+:Kanal 1 hat die Freigabe wieder zur�ckgegeben. jetzt kann eine CRC16-Fehlermeldung erfolgen*/
      /*~T*/
      // Kanal 1 hat die Freigabe wieder zur�ckgegeben. jetzt kann eine CRC16-Fehlermeldung erfolgen
      COMMUNICATION_INSTUCTIONDECODER_RELEASE_LINE = FALSE;	
      /*~A:42*/
      /*~+:Im Fehlerfall eine Fehlermeldung (E012) ausgeben - ansonsten 1ms warten*/
      /*~I:43*/
      if (byChecksumError)
      /*~-1*/
      {
         /*~T*/
         Communication_SendString(COMMUNICATION_RS232,TEXT_E012,1,0);
         /*~T*/
         ulTimeout = SYSTEMTIME + HANDSHAKING_TIMEOUT; 
         /*~L:44*/
         while ((ADuC836_RS232IsTransmissionReady() == FALSE)&&(ulTimeout >= SYSTEMTIME))
         /*~-1*/
         {
            /*~T*/

         /*~-1*/
         }
         /*~E:L44*/
      /*~-1*/
      }
      /*~O:I43*/
      /*~-2*/
      else
      {
         /*~T*/
         System_Wait(1);
      /*~-1*/
      }
      /*~E:I43*/
      /*~E:A42*/
      /*~E:A41*/
      /*~A:45*/
      /*~+:Kanal 1 wieder die Freigabe zur Datanausgabe �bergeben*/
      /*~T*/
      // Status der Instuction-Decoder - Leitung abfragen und den umgekehrten Status zwischenspeichern
      byStatelineStatus = COMMUNICATION_INSTUCTIONDECODER_STATE_LINE;
      /*~T*/
      // Kanal 1 wieder die Freigabe zur Datanausgabe �bergeben
      COMMUNICATION_INSTUCTIONDECODER_RELEASE_LINE = TRUE;
      /*~E:A45*/
      /*~E:A37*/
   /*~-1*/
   }
   /*~E:I36*/
   /*~-1*/
#endif
   /*~E:I35*/
   /*~I:46*/
#ifdef CHANNEL_1
   /*~I:47*/
   if (CommunicationControl.chLine2Interprete == COMMUNICATION_RS232)
   /*~-1*/
   {
      /*~A:48*/
      /*~+:Ausgabe Teil 1 - Fehlermeldung wg. fehlerhafter CRC*/
      /*~A:49*/
      /*~+:Im Fehlerfall eine Fehlermeldung (E012) ausgeben*/
      /*~I:50*/
      if (byChecksumError)
      /*~-1*/
      {
         /*~T*/
         Communication_SendString(COMMUNICATION_RS232,TEXT_E012,1,0);
         /*~T*/
         ulTimeout = SYSTEMTIME + HANDSHAKING_TIMEOUT; 
         /*~L:51*/
         while ((ADuC836_RS232IsTransmissionReady() == FALSE)&&(ulTimeout >= SYSTEMTIME))
         /*~-1*/
         {
            /*~T*/

         /*~-1*/
         }
         /*~E:L51*/
      /*~-1*/
      }
      /*~E:I50*/
      /*~E:A49*/
      /*~T*/
      ulTimeout = SYSTEMTIME + HANDSHAKING_TIMEOUT; 
      /*~A:52*/
      /*~+:Fehlerausgabe erfolgt - Handshakeleitung umschalten*/
      /*~T*/
      // Fehlerausgabe erfolgt - Handshakeleitung umschalten
      COMMUNICATION_INSTUCTIONDECODER_RELEASE_LINE = !COMMUNICATION_INSTUCTIONDECODER_RELEASE_LINE;
      /*~E:A52*/
      /*~A:53*/
      /*~+:Warte auf einen Pegelwechsel von LOW nach HIGH. Wenn dieser erfolgt ist, kann Kanal 1 beginnen, das Datum zu senden*/
      /*~F:54*/
      // Warte auf einen Pegelwechsel von LOW nach HIGH. Wenn dieser erfolgt ist, kann Kanal 1 beginnen, das Datum zu senden
      /*~-1*/
      {
         /*~L:55*/
         while ((COMMUNICATION_INSTUCTIONDECODER_STATE_LINE)&&(ulTimeout >= SYSTEMTIME))
         /*~-1*/
         {
            /*~T*/

         /*~-1*/
         }
         /*~E:L55*/
         /*~L:56*/
         while ((!COMMUNICATION_INSTUCTIONDECODER_STATE_LINE)&&(ulTimeout >= SYSTEMTIME))
         /*~-1*/
         {
            /*~T*/

         /*~-1*/
         }
         /*~E:L56*/
      /*~-1*/
      }
      /*~E:F54*/
      /*~E:A53*/
      /*~E:A48*/
   /*~-1*/
   }
   /*~E:I47*/
   /*~-1*/
#endif
   /*~E:I46*/
   /*~E:A34*/
   /*~-1*/
#endif
   /*~E:I33*/
   /*~I:57*/
   if (szCommand[0])

   /*~-1*/
   {
      /*~I:58*/
#ifdef CHANNEL_1
      	if (strcmp(szCommand,"GPA"))
#endif
      /*~-1*/
      {
         /*~I:59*/
         if ((byChecksumError == FALSE)||(strcmp(szCommand,"CDL") == 0)) 
         /*~-1*/
         {
            /*~K*/
            /*~+:/~* Ge�ndert am 09.02.2022 *~/*/
            /*~I:60*/
            if ((Communication_IsCommunicationEnabled() != 0)||(strcmp(szCommand,"ENA") == 0)||(strcmp(szCommand,"CDL") == 0)||(CommunicationControl.chLine2Interprete != COMMUNICATION_RS232))
            /*~-1*/
            {
               /*~K*/
               /*~+:/~* Ende - Ge�ndert am 09.02.2022 *~/*/
               /*~C:61*/
               // switch (*(char*)szCommand)
               switch (szCommand[0])
               /*~-1*/
               {
                  /*~A:62*/
                  /*~+:A*/
                  /*~F:63*/
                  case 'A':
                  /*~-1*/
                  {
                     /*~A:64*/
                     /*~+:ACR - AutomaticCompensationResults*/
                     /*~I:65*/
                     if (!strcmp(szCommand,"ACR"))
                     /*~-1*/
                     {
                        /*~A:66*/
                        /*~+:Variablendeklarationen*/
                        /*~T*/
                        unsigned char byCounter;
                        /*~E:A66*/
                        /*~A:67*/
                        /*~+:Variableninitialisierungen*/
                        /*~T*/
                        byCounter = 3;
                        /*~E:A67*/
                        /*~T*/
                        // Text wurde bereits gesendet
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:68*/
#ifdef CHANNEL_0
                        /*~I:69*/
                        if (!InstructionDecoder_CheckNbParameters(3,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           // Parameter einlesen
                           // Kanal
                           Parameter[0].nLong = Communication_GetLongParameter(0);
                           // Welche Ausgabe
                           Parameter[1].nLong = Communication_GetLongParameter(1);
                           // zus�tzliche Angabe
                           Parameter[2].nLong = Communication_GetLongParameter(2);

                           /*~I:70*/
                           if (((Parameter[1].nLong > 7)&&(Parameter[1].nLong != 255))||(Parameter[0].nLong > 1))
                           /*~-1*/
                           {
                              /*~A:71*/
                              /*~+:Parameter au�erhalb des Bereichs*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~E:A71*/
                           /*~-1*/
                           }
                           /*~O:I70*/
                           /*~-2*/
                           else
                           {
                              /*~I:72*/
                              if ((!SYSTEM_MRW_MANAGER)||(Parameter[0].nLong == 0))
                              /*~-1*/
                              {
                              /*~A:73*/
                              /*~+:Ausgabe 'Kanal 0'*/
                              /*~T*/
                              // Synchronisationspr�fung wg. der langen Ausf�hrungsdauer abschalten
                              /*~A:74*/
                              /*~+:ausgeklammert*/
                              /*~I:75*/
#ifdef MOF
                              /*~U:76*/
                              /*~-2*/
                              do
                              {
                              /*~T*/
                              Communication_SendSPICommand("iSCS 0");
                              /*~-1*/
                              }
                              /*~O:U76*/
                              while (!Communication_IsOK() && --byCounter);
                              /*~E:U76*/
                              /*~-1*/
#endif
                              /*~E:I75*/
                              /*~E:A74*/
                              /*~I:77*/
#ifdef MOF
                              /*~T*/
                              Communication_SendSPICommand("iSCS 0");
                              /*~I:78*/
                              if (Communication_IsOK())
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendSPICommand("iSCS 1");
                              /*~-1*/
                              }
                              /*~E:I78*/
                              /*~-1*/
#endif
                              /*~E:I77*/
                              /*~T*/
                              Compensation_PrintCompensationValues(1,Parameter[1].nLong,(char)Parameter[2].nLong,0);
                              /*~E:A73*/
                              /*~-1*/
                              }
                              /*~E:I72*/
                           /*~-1*/
                           }
                           /*~E:I70*/
                           /*~I:79*/
                           if ((!SYSTEM_MRW_MANAGER)||(Parameter[0].nLong == 1))
                           /*~-1*/
                           {
                              /*~A:80*/
                              /*~+:Ausgabe Kanal '1' veranlassen*/
                              /*~T*/
                              // Frame zusammensetzen
                              sprintf(szString2Send,"iACR %ld %ld",Parameter[1].nLong,Parameter[2].nLong);
                              /*~I:81*/
                              if (!Communication_SendSPICommand(szString2Send))
                              /*~-1*/
                              {
                              /*~I:82*/
                              if (Communication_IsOK())
                              /*~-1*/
                              {
                              /*~T*/
                              // Alles okay

                              // Wg. der langen Dauer der Ausgabe die Synchronisationspr�fung ausschalten
                              System_SetCheckSynchronisation(0);
                              /*~-1*/
                              }
                              /*~O:I82*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~-1*/
                              }
                              /*~E:I82*/
                              /*~-1*/
                              }
                              /*~O:I81*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~-1*/
                              }
                              /*~E:I81*/
                              /*~E:A80*/
                           /*~-1*/
                           }
                           /*~E:I79*/
                        /*~-1*/
                        }
                        /*~O:I69*/
                        /*~-2*/
                        else
                        {
                           /*~A:83*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A83*/
                        /*~-1*/
                        }
                        /*~E:I69*/
                        /*~-1*/
#endif
                        /*~E:I68*/
                     /*~-1*/
                     }
                     /*~E:I65*/
                     /*~E:A64*/
                     /*~A:84*/
                     /*~+:ACV - AutomaticCompensationValues*/
                     /*~I:85*/
                     if (!strcmp(szCommand,"ACV"))
                     /*~-1*/
                     {
                        /*~T*/
                        // Text wurde bereits gesendet
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:86*/
                        if (!InstructionDecoder_CheckNbParameters(2,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           // Parameter einlesen
                           // Kanal
                           Parameter[0].nLong = Communication_GetLongParameter(0);
                           // Welche Ausgabe
                           Parameter[1].nLong = Communication_GetLongParameter(1);

                           /*~I:87*/
                           if (Parameter[0].nLong < 2)
                           /*~-1*/
                           {
                              /*~I:88*/
                              if (!Parameter[0].nLong)
                              /*~-1*/
                              {
                              /*~I:89*/
#ifdef CHANNEL_1
                              /*~T*/
                              return;
                              /*~-1*/
#endif
                              /*~E:I89*/
                              /*~-1*/
                              }
                              /*~O:I88*/
                              /*~-2*/
                              else
                              {
                              /*~I:90*/
#ifdef CHANNEL_0
                              /*~T*/
                              return;
                              /*~-1*/
#endif
                              /*~E:I90*/
                              /*~-1*/
                              }
                              /*~E:I88*/
                              /*~T*/
                              // Zyklische Ausgabe unterdr�cken
                              Compensation_SuppressOutput(1);
                              /*~T*/
                              // Wert ausgeben
                              Compensation_PrintCompensationValues(0,Parameter[1].nLong,0,0);
                           /*~-1*/
                           }
                           /*~O:I87*/
                           /*~-2*/
                           else
                           {
                              /*~A:91*/
                              /*~+:Parameter au�erhalb des Bereichs*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~E:A91*/
                           /*~-1*/
                           }
                           /*~E:I87*/
                        /*~-1*/
                        }
                        /*~O:I86*/
                        /*~-2*/
                        else
                        {
                           /*~A:92*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A92*/
                        /*~-1*/
                        }
                        /*~E:I86*/
                     /*~-1*/
                     }
                     /*~E:I85*/
                     /*~E:A84*/
                     /*~A:93*/
                     /*~+:ART - AutomaticRecordTemperaturecompensation*/
                     /*~I:94*/
                     if (!strcmp(szCommand,"ART"))
                     /*~-1*/
                     {
                        /*~A:95*/
                        /*~+:Variablendeklarationen*/
                        /*~T*/
                        float fCalibrationFactor;
                        unsigned char chError;
                        unsigned char byCounter;
                        /*~E:A95*/
                        /*~A:96*/
                        /*~+:Variableninitialisierungen*/
                        /*~T*/
                        chError = 0;
                        byCounter = 3;

                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~E:A96*/
                        /*~I:97*/
                        if (!InstructionDecoder_CheckNbParameters(2,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0);
                           Parameter[1].nLong = Communication_GetLongParameter(1);
                           /*~I:98*/
                           if (Parameter[0].nLong < 6)
                           /*~-1*/
                           {
                              /*~A:99*/
                              /*~+:Kalibrierfaktor auslesen*/
                              /*~T*/
                              // Kalibrierfaktor auslesen
                              Measurement_GetCalibrationFactor(WEIGHT_WEIGHTCHANNEL,&fCalibrationFactor);
                              /*~E:A99*/
                              /*~C:100*/
                              switch (Parameter[0].nLong)
                              /*~-1*/
                              {
                              /*~A:101*/
                              /*~+:Kennlinienaufnahme stoppen*/
                              /*~F:102*/
                              case 0x00:
                              /*~-1*/
                              {
                              /*~T*/
                              // Synchronistaionspr�fung einschalten
                              System_SetCheckSynchronisation(TRUE);
                              /*~T*/
                              Digital_Init();
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F102*/
                              /*~E:A101*/
                              /*~A:103*/
                              /*~+:komplette Kennlinienaufnahme*/
                              /*~F:104*/
                              case 0x01:	// komplette Kennlinienaufnahme
                              /*~-1*/
                              {
                              /*~T*/
                              // Synchronistaionspr�fung ausschalten
                              System_SetCheckSynchronisation(FALSE);
                              /*~T*/
                              MRW_Compensation_InitRecCharacteristics(fCalibrationFactor,MRW_COMPENSATION_MODE_REC_DRIFT|MRW_COMPENSATION_MODE_REC_CHARACTERISTICS|MRW_COMPENSATION_MODE_TEST_COMPENSATION);
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F104*/
                              /*~E:A103*/
                              /*~A:105*/
                              /*~+:komplette Kennlinienaufnahme ohne �berpr�fung*/
                              /*~F:106*/
                              case 0x02:	// komplette Kennlinienaufnahme ohne �berpr�fung
                              /*~-1*/
                              {
                              /*~T*/
                              // Synchronistaionspr�fung ausschalten
                              System_SetCheckSynchronisation(FALSE);
                              /*~T*/
                              MRW_Compensation_InitRecCharacteristics(fCalibrationFactor,MRW_COMPENSATION_MODE_REC_DRIFT|MRW_COMPENSATION_MODE_REC_CHARACTERISTICS);
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F106*/
                              /*~E:A105*/
                              /*~A:107*/
                              /*~+:Kennlinienaufnahme ohne Drift und ohne �berpr�fung*/
                              /*~F:108*/
                              case 0x03:	// Kennlinienaufnahme ohne Drift und ohne �berpr�fung
                              /*~-1*/
                              {
                              /*~T*/
                              // Synchronistaionspr�fung ausschalten
                              System_SetCheckSynchronisation(FALSE);
                              /*~T*/
                              MRW_Compensation_InitRecCharacteristics(fCalibrationFactor,MRW_COMPENSATION_MODE_REC_CHARACTERISTICS);
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F108*/
                              /*~E:A107*/
                              /*~A:109*/
                              /*~+:�berpr�fung der Temperaturkompensation*/
                              /*~F:110*/
                              case 4:
                              /*~-1*/
                              {
                              /*~T*/
                              // Synchronistaionspr�fung ausschalten
                              System_SetCheckSynchronisation(FALSE);
                              /*~T*/
                              MRW_Compensation_InitRecCharacteristics(fCalibrationFactor,MRW_COMPENSATION_MODE_TEST_COMPENSATION);
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F110*/
                              /*~E:A109*/
                              /*~A:111*/
                              /*~+:�berpr�fung der Temperaturkompensation - nur f�r SW-Entwicklung*/
                              /*~F:112*/
                              case 5:
                              /*~-1*/
                              {
                              /*~T*/
                              // Synchronistaionspr�fung ausschalten
                              System_SetCheckSynchronisation(FALSE);
                              /*~T*/
                              MRW_Compensation_InitRecCharacteristics(fCalibrationFactor,MRW_COMPENSATION_TEST_1);
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F112*/
                              /*~E:A111*/
                              /*~-1*/
                              }
                              /*~E:C100*/
                              /*~I:113*/
                              if (Parameter[1].nLong)
                              /*~-1*/
                              {
                              /*~T*/
                              // mit zyklischer Ausgabe
                              Compensation_SuppressOutput(0);
                              /*~-1*/
                              }
                              /*~O:I113*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              // Zyklische Ausgabe unterdr�cken
                              Compensation_SuppressOutput(1);
                              /*~-1*/
                              }
                              /*~E:I113*/
                              /*~I:114*/
                              if (!GET_RESPONSE)
                              /*~-1*/
                              {
                              /*~I:115*/
                              if (!Parameter[0].nLong)
                              /*~-1*/
                              {
                              /*~T*/
                              // Kennlinienaufnahme stoppen
                              MRW_Compensation_SetRecCharacteristicsOn(0);

                              System_SetSystemState(SYSTEM_RUNNING);
                              /*~A:116*/
                              /*~+:Eintrag in Diagnosespeicher vornehmen*/
                              /*~T*/
                              ulDiagnosisEntry2Set = DIAGNOSIS_MESSAGE_TEMPCOMPENSATION_STOPPED;
                              /*~E:A116*/
                              /*~-1*/
                              }
                              /*~O:I115*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              // Kennlinienaufnahme starten
                              MRW_Compensation_SetRecCharacteristicsOn(1);

                              System_SetSystemState(SYSTEM_REC_CHARACTERISTICS_ON);

                              /*~A:117*/
                              /*~+:Eintrag in Diagnosespeicher vornehmen*/
                              /*~T*/
                              ulDiagnosisEntry2Set = DIAGNOSIS_MESSAGE_TEMPCOMPENSATION_STARTED;
                              /*~E:A117*/
                              /*~-1*/
                              }
                              /*~E:I115*/
                              /*~A:118*/
                              /*~+:Ausf�hrungsstatus auf 'OKAY' setzen*/
                              /*~+:*/
                              /*~T*/
                              // Ausf�hrungsstatus auf 'OKAY' setzen
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              /*~E:A118*/
                              /*~A:119*/
                              /*~+:Kanal 0*/
                              /*~I:120*/
#ifdef CHANNEL_0
                              /*~I:121*/
                              if (!Parameter[0].nLong)
                              /*~-1*/
                              {
                              /*~T*/
                              // Textausgabe vornehmen
                              lText2Send = TEXT_STOP_REC_CHARACTERISTICS;
                              /*~-1*/
                              }
                              /*~O:I121*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              // Textausgabe vornehmen
                              lText2Send = TEXT_START_REC_CHARACTERISTICS;
                              /*~-1*/
                              }
                              /*~E:I121*/
                              /*~-1*/
#endif
                              /*~E:I120*/
                              /*~E:A119*/
                              /*~-1*/
                              }
                              /*~O:I114*/
                              /*~-2*/
                              else
                              {
                              /*~K*/
                              /*~+:Fehler !!!*/
                              /*~I:122*/
#ifdef CHANNEL_0
                              /*~A:123*/
                              /*~+:Kennlinienaufnahme im Kanal 1 zus�tzlich stoppen*/
                              /*~U:124*/
                              /*~-2*/
                              do
                              {
                              /*~T*/
                              Communication_SendSPICommand("iART");
                              /*~-1*/
                              }
                              /*~O:U124*/
                              while (!Communication_IsOK() && --byCounter);
                              /*~E:U124*/
                              /*~E:A123*/
                              /*~A:125*/
                              /*~+:Ausf�hrungsstatus auf 'E005' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A125*/
                              /*~-1*/
#endif
                              /*~E:I122*/
                              /*~-1*/
                              }
                              /*~E:I114*/
                           /*~-1*/
                           }
                           /*~O:I98*/
                           /*~-2*/
                           else
                           {
                              /*~A:126*/
                              /*~+:Kanal 0*/
                              /*~I:127*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I127*/
                              /*~E:A126*/
                           /*~-1*/
                           }
                           /*~E:I98*/
                        /*~-1*/
                        }
                        /*~O:I97*/
                        /*~-2*/
                        else
                        {
                           /*~A:128*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A128*/
                        /*~-1*/
                        }
                        /*~E:I97*/
                     /*~-1*/
                     }
                     /*~E:I94*/
                     /*~E:A93*/
                     /*~T*/
                     break;
                  /*~-1*/
                  }
                  /*~E:F63*/
                  /*~E:A62*/
                  /*~A:129*/
                  /*~+:C*/
                  /*~F:130*/
                  case 'C':
                  /*~-1*/
                  {
                     /*~A:131*/
                     /*~+:CAA - ClearActualAlarmstatus*/
                     /*~I:132*/
                     if (!strcmp(szCommand,"CAA"))
                     /*~-1*/
                     {
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:133*/
                        if (!InstructionDecoder_CheckNbParameters(0,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~I:134*/
                           if (!GET_RESPONSE)
                           /*~-1*/
                           {
                              /*~T*/
                              // System in den normalen Betriebsmodus versetzen
                              System_ClearSystemError();
                              /*~A:135*/
                              /*~+:Ausf�hrungsstatus auf 'OKAY' setzen*/
                              /*~+:*/
                              /*~T*/
                              // Ausf�hrungsstatus auf 'OKAY' setzen
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              /*~E:A135*/
                              /*~A:136*/
                              /*~+:Kanal 0*/
                              /*~I:137*/
#ifdef CHANNEL_0
                              /*~A:138*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              lText2Send = TEXT_ALARM_STATUS_CLEARED;
                              /*~E:A138*/
                              /*~-1*/
#endif
                              /*~E:I137*/
                              /*~E:A136*/
                           /*~-1*/
                           }
                           /*~O:I134*/
                           /*~-2*/
                           else
                           {
                              /*~K*/
                              /*~+:Fehler !!!*/
                              /*~A:139*/
                              /*~+:Ausf�hrungsstatus auf 'E005' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A139*/
                           /*~-1*/
                           }
                           /*~E:I134*/
                        /*~-1*/
                        }
                        /*~O:I133*/
                        /*~-2*/
                        else
                        {
                           /*~A:140*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A140*/
                        /*~-1*/
                        }
                        /*~E:I133*/
                     /*~-1*/
                     }
                     /*~E:I132*/
                     /*~E:A131*/
                     /*~A:141*/
                     /*~+:CAS - ClearAlarmStatus*/
                     /*~I:142*/
                     if (!strcmp(szCommand,"CAS"))
                     /*~-1*/
                     {
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:143*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0);
                           /*~A:144*/
                           /*~+:Kanal 1 - ADMINCODE automatisch vorgeben*/
                           /*~I:145*/
#ifdef CHANNEL_1
                           /*~T*/
                           Parameter[0].nLong = ADMINCODE;
                           /*~-1*/
#endif
                           /*~E:I145*/
                           /*~E:A144*/
                           /*~I:146*/
                           if (
                           	(Parameter[0].nLong == ADMINCODE)			// Passwort
                           	||
                           	(Parameter[0].nLong = 1399)
                           )
                           /*~-1*/
                           {
                              /*~I:147*/
                              if (!GET_RESPONSE)
                              /*~-1*/
                              {
                              /*~T*/
                              Diagnosis_ClearDiagnosis(DIAGNOSIS_CLEAR_ALL);
                              /*~T*/
                              // System in den normalen Betriebsmodus versetzen
                              System_ClearSystemError();
                              /*~A:148*/
                              /*~+:Ausf�hrungsstatus auf 'OKAY' setzen*/
                              /*~+:*/
                              /*~T*/
                              // Ausf�hrungsstatus auf 'OKAY' setzen
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              /*~E:A148*/
                              /*~A:149*/
                              /*~+:Kanal 0 - Textausgabe*/
                              /*~I:150*/
#ifdef CHANNEL_0 
                              /*~A:151*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              lText2Send = TEXT_DIAGNOSIS_MEMORY_CLEARED;
                              /*~E:A151*/
                              /*~-1*/
#endif
                              /*~E:I150*/
                              /*~E:A149*/
                              /*~-1*/
                              }
                              /*~O:I147*/
                              /*~-2*/
                              else
                              {
                              /*~K*/
                              /*~+:Fehler !!!*/
                              /*~A:152*/
                              /*~+:Ausf�hrungsstatus auf 'E005' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A152*/
                              /*~-1*/
                              }
                              /*~E:I147*/
                           /*~-1*/
                           }
                           /*~O:I146*/
                           /*~-2*/
                           else
                           {
                              /*~K*/
                              /*~+:// Parameterfehler*/
                              /*~A:153*/
                              /*~+:Kanal 0*/
                              /*~I:154*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E002;
                              /*~-1*/
#endif
                              /*~E:I154*/
                              /*~E:A153*/
                              /*~A:155*/
                              /*~+:Kanal 1 - NAK ausgeben*/
                              /*~I:156*/
#ifdef CHANNEL_1
                              /*~T*/
                              Communication_SendMessage(COMMUNICATION_SPI,COMMUNICATION_NAK);
                              /*~-1*/
#endif
                              /*~E:I156*/
                              /*~E:A155*/
                           /*~-1*/
                           }
                           /*~E:I146*/
                        /*~-1*/
                        }
                        /*~O:I143*/
                        /*~-2*/
                        else
                        {
                           /*~A:157*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A157*/
                        /*~-1*/
                        }
                        /*~E:I143*/
                     /*~-1*/
                     }
                     /*~E:I142*/
                     /*~E:A141*/
                     /*~A:158*/
                     /*~+:CDB - ClearDeBug*/
                     /*~I:159*/
#ifdef MIT_DEBUG
                     /*~I:160*/
                     if (!strcmp(szCommand,"CDB"))
                     /*~-1*/
                     {
                        /*~A:161*/
                        /*~+:Variablendeklarationen*/
                        /*~T*/
                        long lDebVar[DEBUG_NB_DEBUGVARIABLES];
                        /*~E:A161*/
                        /*~A:162*/
                        /*~+:Variableninitialisierungen*/
                        /*~T*/

                        /*~E:A162*/
                        /*~T*/
                        // Text wurde bereits gesendet
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:163*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0);
                           Parameter[1].nLong = Communication_GetLongParameter(1);
                           /*~C:164*/
                           switch (Parameter[0].nLong)
                           /*~-1*/
                           {
                              /*~F:165*/
                              case 0:
                              /*~-1*/
                              {
                              /*~A:166*/
                              /*~+:Kanal 0*/
                              /*~I:167*/
#ifdef CHANNEL_0
                              /*~I:168*/
                              if (Parameter[1].nLong == 255)
                              /*~-1*/
                              {
                              /*~T*/
                              memset(lDebVar,0,32);
                              /*~T*/
                              Communication_SendString(COMMUNICATION_RS232,T_TEXT_CONTENT_DEBUG_VARIABLES_CLEARED_ALL_CHANNEL_0,1,0);
                              /*~-1*/
                              }
                              /*~O:I168*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              // Debug-Variablen aus dem Eeprom laden
                              Load_Parameter(LOAD_SAVE_DEBUG_VARIABLES,lDebVar,4*DEBUG_NB_DEBUGVARIABLES);
                              /*~T*/
                              lDebVar[Parameter[1].nLong] = 0;
                              /*~T*/
                              // Text
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_CONFIRMATION_DEBUG_VARIABLES_CLEARED_CHANNEL_0,Parameter[1].nLong,1,0);
                              /*~-1*/
                              }
                              /*~E:I168*/
                              /*~T*/
                              // Debug-Variablen in das Eeprom schreiben
                              Save_Parameter(LOAD_SAVE_DEBUG_VARIABLES,lDebVar,4*DEBUG_NB_DEBUGVARIABLES);
                              /*~-1*/
#endif
                              /*~E:I167*/
                              /*~E:A166*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F165*/
                              /*~F:169*/
                              case 1:
                              /*~-1*/
                              {
                              /*~A:170*/
                              /*~+:Kanal 1*/
                              /*~I:171*/
#ifdef CHANNEL_1
                              /*~I:172*/
                              if (Parameter[1].nLong == 255)
                              /*~-1*/
                              {
                              /*~T*/
                              memset(lDebVar,0,32);
                              /*~T*/
                              Communication_SendString(COMMUNICATION_RS232,T_TEXT_CONTENT_DEBUG_VARIABLES_CLEARED_ALL_CHANNEL_1,1,0);
                              /*~-1*/
                              }
                              /*~O:I172*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              // Debug-Variablen aus dem Eeprom laden
                              Load_Parameter(LOAD_SAVE_DEBUG_VARIABLES,lDebVar,4*DEBUG_NB_DEBUGVARIABLES);
                              /*~T*/
                              lDebVar[Parameter[1].nLong] = 0;
                              /*~T*/
                              // Text
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_CONFIRMATION_DEBUG_VARIABLES_CLEARED_CHANNEL_1,Parameter[1].nLong,1,0);
                              /*~-1*/
                              }
                              /*~E:I172*/
                              /*~T*/
                              // Debug-Variablen in das Eeprom schreiben
                              Save_Parameter(LOAD_SAVE_DEBUG_VARIABLES,lDebVar,4*DEBUG_NB_DEBUGVARIABLES);
                              /*~-1*/
#endif
                              /*~E:I171*/
                              /*~E:A170*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F169*/
                              /*~O:C164*/
                              /*~-2*/
                              default:
                              {
                              /*~A:173*/
                              /*~+:Kanal 0*/
                              /*~I:174*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I174*/
                              /*~E:A173*/
                              /*~-1*/
                              }
                           /*~-1*/
                           }
                           /*~E:C164*/
                        /*~-1*/
                        }
                        /*~O:I163*/
                        /*~-2*/
                        else
                        {
                           /*~A:175*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A175*/
                        /*~-1*/
                        }
                        /*~E:I163*/
                     /*~-1*/
                     }
                     /*~E:I160*/
                     /*~-1*/
#endif
                     /*~E:I159*/
                     /*~E:A158*/
                     /*~I:176*/
#ifdef MOF
                     /*~A:177*/
                     /*~+:CDG - ClearDiaGnosis*/
                     /*~I:178*/
                     if ((!strcmp(szCommand,"CAS"))||(!strcmp(szCommand,"CDG")))
                     /*~-1*/
                     {
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:179*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0);
                           /*~A:180*/
                           /*~+:Kanal 1 - ADMINCODE automatisch vorgeben*/
                           /*~I:181*/
#ifdef CHANNEL_1
                           /*~T*/
                           Parameter[0].nLong = ADMINCODE;
                           /*~-1*/
#endif
                           /*~E:I181*/
                           /*~E:A180*/
                           /*~I:182*/
                           if (
                           	(Parameter[0].nLong == ADMINCODE)			// Passwort
                           	||
                           	(Parameter[0].nLong = 1399)
                           )
                           /*~-1*/
                           {
                              /*~I:183*/
                              if (!GET_RESPONSE)
                              /*~-1*/
                              {
                              /*~T*/
                              Diagnosis_ClearDiagnosis(DIAGNOSIS_CLEAR_ALL);
                              /*~T*/
                              // System in den normalen Betriebsmodus versetzen
                              System_ClearSystemError();
                              /*~A:184*/
                              /*~+:Ausf�hrungsstatus auf 'OKAY' setzen*/
                              /*~+:*/
                              /*~T*/
                              // Ausf�hrungsstatus auf 'OKAY' setzen
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              /*~E:A184*/
                              /*~A:185*/
                              /*~+:Kanal 0 - Textausgabe*/
                              /*~I:186*/
#ifdef CHANNEL_0 
                              /*~A:187*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              lText2Send = TEXT_DIAGNOSIS_MEMORY_CLEARED;
                              /*~E:A187*/
                              /*~-1*/
#endif
                              /*~E:I186*/
                              /*~E:A185*/
                              /*~-1*/
                              }
                              /*~O:I183*/
                              /*~-2*/
                              else
                              {
                              /*~K*/
                              /*~+:Fehler !!!*/
                              /*~A:188*/
                              /*~+:Ausf�hrungsstatus auf 'E005' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A188*/
                              /*~-1*/
                              }
                              /*~E:I183*/
                           /*~-1*/
                           }
                           /*~O:I182*/
                           /*~-2*/
                           else
                           {
                              /*~K*/
                              /*~+:// Parameterfehler*/
                              /*~A:189*/
                              /*~+:Kanal 0*/
                              /*~I:190*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E002;
                              /*~-1*/
#endif
                              /*~E:I190*/
                              /*~E:A189*/
                              /*~A:191*/
                              /*~+:Kanal 1 - NAK ausgeben*/
                              /*~I:192*/
#ifdef CHANNEL_1
                              /*~T*/
                              Communication_SendMessage(COMMUNICATION_SPI,COMMUNICATION_NAK);
                              /*~-1*/
#endif
                              /*~E:I192*/
                              /*~E:A191*/
                           /*~-1*/
                           }
                           /*~E:I182*/
                        /*~-1*/
                        }
                        /*~O:I179*/
                        /*~-2*/
                        else
                        {
                           /*~A:193*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A193*/
                        /*~-1*/
                        }
                        /*~E:I179*/
                     /*~-1*/
                     }
                     /*~E:I178*/
                     /*~E:A177*/
                     /*~-1*/
#endif
                     /*~E:I176*/
                     /*~A:194*/
                     /*~+:CDL - Connect2DockLight*/
                     /*~I:195*/
                     if (!strcmp(szCommand,"CDL"))
                     /*~-1*/
                     {
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:196*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0);
                           /*~I:197*/
                           if (!Parameter[0].nLong)
                           /*~-1*/
                           {
                              /*~K*/
                              /*~+:// Docklight-Modus ausschalten*/
                              /*~T*/
                              System_Connect2MRW_Manager(1);
                              /*~A:198*/
                              /*~+:Textausgabe �ber Kanal 0*/
                              /*~I:199*/
#ifdef CHANNEL_0
                              /*~T*/
                              // Communication_SendString(COMMUNICATION_RS232,TEXT_DOCKLIGHT_MODE_CLEARED,0,1);
                              Communication_SendString(COMMUNICATION_RS232,T_TEXT_3_OKAY,0,1);
                              /*~-1*/
#endif
                              /*~E:I199*/
                              /*~E:A198*/
                           /*~-1*/
                           }
                           /*~O:I197*/
                           /*~-2*/
                           else
                           {
                              /*~K*/
                              /*~+:// Docklight-Modus einschalten*/
                              /*~T*/
                              System_Connect2MRW_Manager(0);
                              /*~A:200*/
                              /*~+:Textausgabe �ber Kanal 0*/
                              /*~I:201*/
#ifdef CHANNEL_0
                              /*~T*/
                              Communication_SendString(COMMUNICATION_RS232,T_TEXT_DOCKLIGHT_MODE_SET,1,1);
                              /*~-1*/
#endif
                              /*~E:I201*/
                              /*~E:A200*/
                           /*~-1*/
                           }
                           /*~E:I197*/
                        /*~-1*/
                        }
                        /*~O:I196*/
                        /*~-2*/
                        else
                        {
                           /*~A:202*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A202*/
                        /*~-1*/
                        }
                        /*~E:I196*/
                     /*~-1*/
                     }
                     /*~E:I195*/
                     /*~E:A194*/
                     /*~K*/
                     /*~+:/~* Hinzugef�gt am 09.02.2022 *~/*/
                     /*~I:203*/
#ifdef DEVELOPMENT_SW 
                     /*~A:204*/
                     /*~+:CEE - ClearEEprom*/
                     /*~I:205*/
                     /*#LJ:CEE=12*/
                     if (!strcmp(szCommand,"CEE"))
                     /*~-1*/
                     {
                        /*~A:206*/
                        /*~+:Variablendeklarationen*/
                        /*~T*/

                        /*~E:A206*/
                        /*~T*/

                        /*~A:207*/
                        /*~+:Variableninitialisierungen*/
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~E:A207*/
                        /*~I:208*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           // Parameter auslesen
                           Parameter[0].nLong = Communication_GetLongParameter(0);
                           /*~I:209*/
                           if (Parameter[0].nLong == 1234567890L)
                           /*~-1*/
                           {
                              /*~T*/
                              Ee24c64_ClearAll();
                              /*~I:210*/
                              if (!GET_RESPONSE)
                              /*~-1*/
                              {
                              /*~A:211*/
                              /*~+:Ausf�hrungsstatus auf 'OKAY' setzen*/
                              /*~+:*/
                              /*~T*/
                              // Ausf�hrungsstatus auf 'OKAY' setzen
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              /*~E:A211*/
                              /*~A:212*/
                              /*~+:Kanal 0 - Textausgabe*/
                              /*~I:213*/
#ifdef CHANNEL_0
                              /*~A:214*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              lText2Send = TEXT_EEPROM_CLEARED;
                              /*~E:A214*/
                              /*~-1*/
#endif
                              /*~E:I213*/
                              /*~E:A212*/
                              /*~-1*/
                              }
                              /*~O:I210*/
                              /*~-2*/
                              else
                              {
                              /*~K*/
                              /*~+:Fehler !!!*/
                              /*~A:215*/
                              /*~+:Ausf�hrungsstatus auf 'E005' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A215*/
                              /*~-1*/
                              }
                              /*~E:I210*/
                           /*~-1*/
                           }
                           /*~E:I209*/
                        /*~-1*/
                        }
                        /*~O:I208*/
                        /*~-2*/
                        else
                        {
                           /*~A:216*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A216*/
                        /*~-1*/
                        }
                        /*~E:I208*/
                     /*~-1*/
                     }
                     /*~E:I205*/
                     /*~E:A204*/
                     /*~-1*/
#endif
                     /*~E:I203*/
                     /*~K*/
                     /*~+:/~* Ende - Hinzugef�gt am 09.02.2022 *~/*/
                     /*~I:217*/
#ifdef MOF
                     /*~A:218*/
                     /*~+:CEI,CEK,CRI - ClearEepromId*/
                     /*~I:219*/
                     if ((!strcmp(szCommand,"CEI"))||(!strcmp(szCommand,"CEK"))||(!strcmp(szCommand,"CRI")))
                     /*~-1*/
                     {
                        /*~A:220*/
                        /*~+:Variablendeklarationen*/
                        /*~T*/
                        unsigned long ulID;
                        /*~E:A220*/
                        /*~A:221*/
                        /*~+:Variableninitialisierungen*/
                        /*~T*/
                        ulID = 0L;

                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~E:A221*/
                        /*~I:222*/
                        if (!InstructionDecoder_CheckNbParameters(0,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~I:223*/
                           if (!GET_RESPONSE)
                           /*~-1*/
                           {
                              /*~A:224*/
                              /*~+:ausgeklammert - hier besteht die M�glichkeit, das Eeprom als jungfr�ulich zu deklarieren - es wird auch die ID gel�scht !!!*/
                              /*~I:225*/
#ifdef MOF
                              /*~I:226*/
                              if (!strcmp(szCommand,"CRI"))
                              /*~-1*/
                              {
                              /*~T*/
                              // Kennung zur Neuinitialisierung setzen
                              ulID = 0xAAAA5555;
                              /*~-1*/
                              }
                              /*~O:I226*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              // Kennung l�schen - System jungfr�ulich
                              ulID = 0;
                              /*~-1*/
                              }
                              /*~E:I226*/
                              /*~-1*/
#endif
                              /*~E:I225*/
                              /*~E:A224*/
                              /*~T*/
                              Save_Parameter(LOAD_SAVE_INITIALIZE_IDENTIFICATION,&ulID,0);
                              /*~A:227*/
                              /*~+:Ausf�hrungsstatus auf 'OKAY' setzen*/
                              /*~+:*/
                              /*~T*/
                              // Ausf�hrungsstatus auf 'OKAY' setzen
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              /*~E:A227*/
                              /*~A:228*/
                              /*~+:Kanal 0 - Textausgabe*/
                              /*~I:229*/
#ifdef CHANNEL_0
                              /*~A:230*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              lText2Send = TEXT_RESTART_HARDWARE;
                              /*~E:A230*/
                              /*~-1*/
#endif
                              /*~E:I229*/
                              /*~E:A228*/
                           /*~-1*/
                           }
                           /*~O:I223*/
                           /*~-2*/
                           else
                           {
                              /*~K*/
                              /*~+:Fehler !!!*/
                              /*~A:231*/
                              /*~+:Ausf�hrungsstatus auf 'E005' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A231*/
                           /*~-1*/
                           }
                           /*~E:I223*/
                        /*~-1*/
                        }
                        /*~O:I222*/
                        /*~-2*/
                        else
                        {
                           /*~A:232*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A232*/
                        /*~-1*/
                        }
                        /*~E:I222*/
                     /*~-1*/
                     }
                     /*~E:I219*/
                     /*~E:A218*/
                     /*~-1*/
#endif
                     /*~E:I217*/
                     /*~A:233*/
                     /*~+:CEK - ClearEepromKennung*/
                     /*~I:234*/
                     if (!strcmp(szCommand,"CEK"))
                     /*~-1*/
                     {
                        /*~A:235*/
                        /*~+:Variablendeklarationen*/
                        /*~T*/
                        unsigned long ulID;
                        /*~E:A235*/
                        /*~A:236*/
                        /*~+:Variableninitialisierungen*/
                        /*~T*/
                        ulID = 0L;

                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~E:A236*/
                        /*~I:237*/
                        if (!InstructionDecoder_CheckNbParameters(0,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~I:238*/
                           if (!GET_RESPONSE)
                           /*~-1*/
                           {
                              /*~A:239*/
                              /*~+:ausgeklammert - hier besteht die M�glichkeit, das Eeprom als jungfr�ulich zu deklarieren - es wird auch die ID gel�scht !!!*/
                              /*~I:240*/
#ifdef MOF
                              /*~I:241*/
                              if (!strcmp(szCommand,"CRI"))
                              /*~-1*/
                              {
                              /*~T*/
                              // Kennung zur Neuinitialisierung setzen
                              ulID = 0xAAAA5555;
                              /*~-1*/
                              }
                              /*~O:I241*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              // Kennung l�schen - System jungfr�ulich
                              ulID = 0;
                              /*~-1*/
                              }
                              /*~E:I241*/
                              /*~-1*/
#endif
                              /*~E:I240*/
                              /*~E:A239*/
                              /*~T*/
                              Save_Parameter(LOAD_SAVE_INITIALIZE_IDENTIFICATION,&ulID,0);
                              /*~A:242*/
                              /*~+:Ausf�hrungsstatus auf 'OKAY' setzen*/
                              /*~+:*/
                              /*~T*/
                              // Ausf�hrungsstatus auf 'OKAY' setzen
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              /*~E:A242*/
                              /*~A:243*/
                              /*~+:Kanal 0 - Textausgabe*/
                              /*~I:244*/
#ifdef CHANNEL_0
                              /*~A:245*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              lText2Send = TEXT_RESTART_HARDWARE;
                              /*~E:A245*/
                              /*~-1*/
#endif
                              /*~E:I244*/
                              /*~E:A243*/
                           /*~-1*/
                           }
                           /*~O:I238*/
                           /*~-2*/
                           else
                           {
                              /*~K*/
                              /*~+:Fehler !!!*/
                              /*~A:246*/
                              /*~+:Ausf�hrungsstatus auf 'E005' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A246*/
                           /*~-1*/
                           }
                           /*~E:I238*/
                        /*~-1*/
                        }
                        /*~O:I237*/
                        /*~-2*/
                        else
                        {
                           /*~A:247*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A247*/
                        /*~-1*/
                        }
                        /*~E:I237*/
                     /*~-1*/
                     }
                     /*~E:I234*/
                     /*~E:A233*/
                     /*~A:248*/
                     /*~+:CIC - CurrentInterfaceCalibration*/
                     /*~I:249*/
                     if (!strcmp(szCommand,"CIC"))
                     /*~-1*/
                     {
                        /*~A:250*/
                        /*~+:Variablendeklarationen*/
                        /*~I:251*/
#ifdef SYSTEM_CND_WITH_DEADBAND_FILTER
                        /*~T*/
                        int nBandWidth;
                        /*~-1*/
#endif
                        /*~E:I251*/
                        /*~E:A250*/
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:252*/
                        if (!InstructionDecoder_CheckNbParameters(3,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           // Parameter einlesen
                           Parameter[0].nLong = Communication_GetLongParameter(0);
                           Parameter[1].nLong = Communication_GetLongParameter(1);

                           /*~T*/
                           Parameter[2].fFloat = Communication_GetFloatParameter(2);
                           /*~C:253*/
                           switch (Parameter[0].nLong)
                           /*~-1*/
                           {
                              /*~F:254*/
                              case 0:
                              /*~-1*/
                              {
                              /*~A:255*/
                              /*~+:Kanal 0*/
                              /*~I:256*/
#ifdef CHANNEL_0
                              /*~C:257*/
                              switch (Parameter[1].nLong)
                              /*~-1*/
                              {
                              /*~A:258*/
                              /*~+:Initialisierung */
                              /*~F:259*/
                              case 0:		// Initialisierung
                              /*~-1*/
                              {
                              /*~I:260*/
#ifndef OHNE_STROMRUECKFUEHRUNG 
                              /*~A:261*/
                              /*~+:Mitteilung, dass die Stromr�ckf�hrung ausgeschaltet wurde*/
                              /*~I:262*/
                              if (!SYSTEM_MRW_MANAGER)
                              /*~-1*/
                              {
                              /*~T*/
                              // Mitteilung, dass die Stromr�ckf�hrung ausgeschaltet wurde
                              Communication_SendString(COMMUNICATION_RS232,T_TEXT_FEEDBACK_STATE_OFF,1,0);

                              /*~-1*/
                              }
                              /*~E:I262*/
                              /*~E:A261*/
                              /*~T*/
                              // Stromr�ckf�hrung ausschalten
                              CurrentInterface_SetFeedBackOnOff(0,0);
                              /*~-1*/
#endif
                              /*~E:I260*/
                              /*~I:263*/
#ifdef SYSTEM_CND_WITH_DEADBAND_FILTER
                              /*~A:264*/
                              /*~+:Totbandfilter-Bandbreite f�r die Gewichtsermittlung ausschalten*/
                              /*~T*/
                              // Totbandfilter-Bandbreite f�r die Gewichtsermittlung ausschalten
                              DeadBandFilter_Setup(0,0,DEADBANDFILTER_LONGDATA);

                              /*~E:A264*/
                              /*~-1*/
#endif
                              /*~E:I263*/
                              /*~T*/
                              CurrentInterface_Ini(0);
                              /*~T*/
                              ulDiagnosisEntry2Set = DIAGNOSIS_MESSAGE_DAC_CALIBRATION_CLEARED;
                              /*~A:265*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              lText2Send = TEXT_CURRENT_INTERFACE_INITIALIZED_CHANNEL_0;
                              /*~E:A265*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F259*/
                              /*~E:A258*/
                              /*~A:266*/
                              /*~+:Vorbereitung f�r 1.Referenzpunkt*/
                              /*~F:267*/
                              case 1:		// Vorbereitung f�r 1.Referenzpunkt
                              /*~-1*/
                              {
                              /*~T*/
                              CurrentInterface_PrepareCalibration(1,Parameter[2].fFloat);
                              /*~A:268*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              lText2Send = TEXT_CURRENT_INTERFACE_PREPARE_4_CAL_1ST_POINT_CHANNEL_0;
                              /*~E:A268*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F267*/
                              /*~E:A266*/
                              /*~A:269*/
                              /*~+:Ersten Referenzpunkt setzen*/
                              /*~F:270*/
                              case 2:		// Ersten Referenzpunkt setzen
                              /*~-1*/
                              {
                              /*~T*/
                              CurrentInterface_Calibration(0,Parameter[2].fFloat);
                              /*~A:271*/
                              /*~+:Eintrag in Diagnosespeicher vornehmen*/
                              /*~T*/
                              ulDiagnosisEntry2Set = DIAGNOSIS_MESSAGE_DAC_1ST_POINT_CALIBRATION_SET;
                              /*~E:A271*/
                              /*~A:272*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              lText2Send = TEXT_CURRENT_INTERFACE_1ST_CAL_POINT_SET_CHANNEL_0;
                              /*~E:A272*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F270*/
                              /*~E:A269*/
                              /*~A:273*/
                              /*~+:Vorbereitung f�r 2.Referenzpunkt*/
                              /*~F:274*/
                              case 3:		// Vorbereitung f�r 2.Referenzpunkt
                              /*~-1*/
                              {
                              /*~T*/
                              CurrentInterface_PrepareCalibration(2,Parameter[2].fFloat);
                              /*~A:275*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              lText2Send = TEXT_CURRENT_INTERFACE_PREPARE_4_CAL_2ND_POINT_CHANNEL_0;
                              /*~E:A275*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F274*/
                              /*~E:A273*/
                              /*~A:276*/
                              /*~+:Zweiten Referenzpunkt setzen*/
                              /*~F:277*/
                              case 4:		// Zweiten Referenzpunkt setzen
                              /*~-1*/
                              {
                              /*~I:278*/
                              if(!CurrentInterface_Calibration(1,Parameter[2].fFloat))
                              /*~-1*/
                              {
                              /*~A:279*/
                              /*~+:Eintrag in Diagnosespeicher vornehmen*/
                              /*~T*/
                              ulDiagnosisEntry2Set = DIAGNOSIS_MESSAGE_DAC_2ND_POINT_CALIBRATION_SET;
                              /*~E:A279*/
                              /*~A:280*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              lText2Send = TEXT_CURRENT_INTERFACE_2ND_CAL_POINT_SET_CHANNEL_0;
                              /*~E:A280*/
                              /*~-1*/
                              }
                              /*~O:I278*/
                              /*~-2*/
                              else
                              {
                              /*~K*/
                              /*~+:Fehler*/
                              /*~A:281*/
                              /*~+:Text f�r Terminalbetrieb "E005"*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              lText2Send = TEXT_ERROR_1ST_REFPOINT_MISSING;
                              /*~E:A281*/
                              /*~-1*/
                              }
                              /*~E:I278*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F277*/
                              /*~E:A276*/
                              /*~A:282*/
                              /*~+:Kalibrierung speichern*/
                              /*~F:283*/
                              case 5:		// Kalibrierung speichern
                              /*~-1*/
                              {
                              /*~A:284*/
                              /*~+:Grenzwerte setzen*/
                              /*~T*/
                              // Grenzwerte setzen
                              Limit_SetAlarmLimits();
                              /*~E:A284*/
                              /*~I:285*/
#ifndef OHNE_STROMRUECKFUEHRUNG 
                              /*~A:286*/
                              /*~+:Strom-R�ckf�hrung aktivieren*/
                              /*~T*/
                              // Strom-R�ckf�hrung aktivieren
                              CurrentInterface_SetFeedBackOnOff(1,0);
                              /*~E:A286*/
                              /*~A:287*/
                              /*~+:Mitteilung, dass die Stromr�ckf�hrung eingeschaltet wurde*/
                              /*~I:288*/
                              if (!SYSTEM_MRW_MANAGER)
                              /*~-1*/
                              {
                              /*~T*/
                              // Mitteilung, dass die Stromr�ckf�hrung eingeschaltet wurde
                              Communication_SendString(COMMUNICATION_RS232,T_TEXT_FEEDBACK_STATE_ON,1,0);

                              /*~-1*/
                              }
                              /*~E:I288*/
                              /*~E:A287*/
                              /*~-1*/
#endif
                              /*~E:I285*/
                              /*~I:289*/
#ifdef SYSTEM_CND_WITH_DEADBAND_FILTER 
                              /*~A:290*/
                              /*~+:Totbandfilter-Bandbreite f�r die Gewichtsermittlung wieder in Ursprungszustand versetzen*/
                              /*~T*/
                              // Totbandfilter-Bandbreite f�r die Gewichtsermittlung laden
                              Load_Parameter(LOAD_SAVE_FILTER_BANDWIDTH_WEIGHT,&nBandWidth,0);

                              DeadBandFilter_Setup(0,(float)nBandWidth,DEADBANDFILTER_LONGDATA);

                              /*~E:A290*/
                              /*~-1*/
#endif
                              /*~E:I289*/
                              /*~A:291*/
                              /*~+:Eintrag in Diagnosespeicher vornehmen*/
                              /*~T*/
                              ulDiagnosisEntry2Set = DIAGNOSIS_MESSAGE_DAC_CALIBRATION_FINISHED;
                              /*~E:A291*/
                              /*~T*/
                              CurrentInterface_SaveDACSettings(CURRENTINTERFACE_ALL_SETTINGS);
                              /*~T*/
                              // Simulation des Rohmesswerts ausschalten
                              CurrentInterface_PrepareCalibration(0,0);
                              /*~A:292*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              /*~T*/
                              lText2Send = TEXT_CURRENT_INTERFACE_CALIBRATION_FINISHED_CHANNEL_0;
                              /*~E:A292*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F283*/
                              /*~E:A282*/
                              /*~O:C257*/
                              /*~-2*/
                              default:
                              {
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E002;
                              /*~-1*/
                              }
                              /*~-1*/
                              }
                              /*~E:C257*/
                              /*~-1*/
#endif
                              /*~E:I256*/
                              /*~T*/
                              break;
                              /*~E:A255*/
                              /*~-1*/
                              }
                              /*~E:F254*/
                              /*~F:293*/
                              case 1:
                              /*~-1*/
                              {
                              /*~A:294*/
                              /*~+:Kanal 1*/
                              /*~I:295*/
#ifdef CHANNEL_1 
                              /*~C:296*/
                              switch (Parameter[1].nLong)
                              /*~-1*/
                              {
                              /*~A:297*/
                              /*~+:Initialisierung*/
                              /*~F:298*/
                              case 0:		// Initialisierung
                              /*~-1*/
                              {
                              /*~I:299*/
#ifndef OHNE_STROMRUECKFUEHRUNG 
                              /*~A:300*/
                              /*~+:Mitteilung, dass die Stromr�ckf�hrung ausgeschaltet wurde*/
                              /*~I:301*/
                              if (!SYSTEM_MRW_MANAGER)
                              /*~-1*/
                              {
                              /*~T*/
                              // Mitteilung, dass die Stromr�ckf�hrung ausgeschaltet wurde
                              Communication_SendString(COMMUNICATION_RS232,T_TEXT_FEEDBACK_STATE_OFF,1,0);

                              /*~-1*/
                              }
                              /*~E:I301*/
                              /*~E:A300*/
                              /*~T*/
                              // Stromr�ckf�hrung ausschalten
                              CurrentInterface_SetFeedBackOnOff(0,0);
                              /*~-1*/
#endif
                              /*~E:I299*/
                              /*~I:302*/
#ifdef SYSTEM_CND_WITH_DEADBAND_FILTER
                              /*~A:303*/
                              /*~+:Totbandfilter-Bandbreite f�r die Gewichtsermittlung ausschalten*/
                              /*~T*/
                              // Totbandfilter-Bandbreite f�r die Gewichtsermittlung ausschalten
                              DeadBandFilter_Setup(0,0,DEADBANDFILTER_LONGDATA);

                              /*~E:A303*/
                              /*~-1*/
#endif
                              /*~E:I302*/
                              /*~T*/
                              CurrentInterface_Ini(0);
                              /*~A:304*/
                              /*~+:Eintrag in Diagnosespeicher vornehmen*/
                              /*~T*/
                              ulDiagnosisEntry2Set = DIAGNOSIS_MESSAGE_DAC_CALIBRATION_CLEARED;
                              /*~E:A304*/
                              /*~A:305*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              lText2Send = TEXT_CURRENT_INTERFACE_INITIALIZED_CHANNEL_1;
                              /*~E:A305*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F298*/
                              /*~E:A297*/
                              /*~A:306*/
                              /*~+:Vorbereitung f�r 1.Referenzpunkt*/
                              /*~F:307*/
                              case 1:		// Vorbereitung f�r 1.Referenzpunkt
                              /*~-1*/
                              {
                              /*~T*/
                              CurrentInterface_PrepareCalibration(1,Parameter[2].fFloat);
                              /*~A:308*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              lText2Send = TEXT_CURRENT_INTERFACE_PREPARE_4_CAL_1ST_POINT_CHANNEL_1;
                              /*~E:A308*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F307*/
                              /*~E:A306*/
                              /*~A:309*/
                              /*~+:Ersten Referenzpunkt setzen*/
                              /*~F:310*/
                              case 2:		// Ersten Referenzpunkt setzen
                              /*~-1*/
                              {
                              /*~I:311*/
                              if(!CurrentInterface_Calibration(0,Parameter[2].fFloat))
                              /*~-1*/
                              {
                              /*~A:312*/
                              /*~+:Eintrag in Diagnosespeicher vornehmen*/
                              /*~T*/
                              ulDiagnosisEntry2Set = DIAGNOSIS_MESSAGE_DAC_1ST_POINT_CALIBRATION_SET;
                              /*~E:A312*/
                              /*~A:313*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              lText2Send = TEXT_CURRENT_INTERFACE_1ST_CAL_POINT_SET_CHANNEL_1;
                              /*~E:A313*/
                              /*~-1*/
                              }
                              /*~O:I311*/
                              /*~-2*/
                              else
                              {
                              /*~K*/
                              /*~+:Fehler*/
                              /*~A:314*/
                              /*~+:Text f�r Terminalbetrieb "E005"*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              lText2Send = TEXT_ERROR_WEIGHT_INSTABILE;
                              /*~E:A314*/
                              /*~-1*/
                              }
                              /*~E:I311*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F310*/
                              /*~E:A309*/
                              /*~A:315*/
                              /*~+:Vorbereitung f�r 2.Referenzpunkt*/
                              /*~F:316*/
                              case 3:		// Vorbereitung f�r 2.Referenzpunkt
                              /*~-1*/
                              {
                              /*~T*/
                              CurrentInterface_PrepareCalibration(2,Parameter[2].fFloat);
                              /*~A:317*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              lText2Send = TEXT_CURRENT_INTERFACE_PREPARE_4_CAL_2ND_POINT_CHANNEL_1;
                              /*~E:A317*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F316*/
                              /*~E:A315*/
                              /*~A:318*/
                              /*~+:Zweiten Referenzpunkt setzen*/
                              /*~F:319*/
                              case 4:		// Zweiten Referenzpunkt setzen
                              /*~-1*/
                              {
                              /*~I:320*/
                              if(!CurrentInterface_Calibration(1,Parameter[2].fFloat))
                              /*~-1*/
                              {
                              /*~A:321*/
                              /*~+:Eintrag in Diagnosespeicher vornehmen*/
                              /*~T*/
                              ulDiagnosisEntry2Set = DIAGNOSIS_MESSAGE_DAC_2ND_POINT_CALIBRATION_SET;
                              /*~E:A321*/
                              /*~A:322*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              lText2Send = TEXT_CURRENT_INTERFACE_2ND_CAL_POINT_SET_CHANNEL_1;
                              /*~E:A322*/
                              /*~-1*/
                              }
                              /*~O:I320*/
                              /*~-2*/
                              else
                              {
                              /*~K*/
                              /*~+:Fehler*/
                              /*~A:323*/
                              /*~+:Text f�r Terminalbetrieb "E005"*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              lText2Send = TEXT_ERROR_WEIGHT_INSTABILE;
                              /*~E:A323*/
                              /*~-1*/
                              }
                              /*~E:I320*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F319*/
                              /*~E:A318*/
                              /*~A:324*/
                              /*~+:Kalibrierung speichern*/
                              /*~F:325*/
                              case 5:		// Kalibrierung speichern
                              /*~-1*/
                              {
                              /*~A:326*/
                              /*~+:Grenzwerte setzen*/
                              /*~T*/
                              // Grenzwerte setzen
                              Limit_SetAlarmLimits();
                              /*~E:A326*/
                              /*~I:327*/
#ifndef OHNE_STROMRUECKFUEHRUNG 
                              /*~A:328*/
                              /*~+:Stromr�ckf�hrung einschalten*/
                              /*~T*/
                              // Stromr�ckf�hrung einschalten
                              CurrentInterface_SetFeedBackOnOff(1,0);
                              /*~E:A328*/
                              /*~A:329*/
                              /*~+:Mitteilung, dass die Stromr�ckf�hrung eingeschaltet wurde*/
                              /*~I:330*/
                              if (!SYSTEM_MRW_MANAGER)
                              /*~-1*/
                              {
                              /*~T*/
                              // Mitteilung, dass die Stromr�ckf�hrung eingeschaltet wurde
                              Communication_SendString(COMMUNICATION_RS232,T_TEXT_FEEDBACK_STATE_ON,1,0);

                              /*~-1*/
                              }
                              /*~E:I330*/
                              /*~E:A329*/
                              /*~-1*/
#endif
                              /*~E:I327*/
                              /*~I:331*/
#ifdef SYSTEM_CND_WITH_DEADBAND_FILTER
                              /*~A:332*/
                              /*~+:Totbandfilter-Bandbreite f�r die Gewichtsermittlung wieder in Ursprungszustand versetzen*/
                              /*~T*/
                              // Totbandfilter-Bandbreite f�r die Gewichtsermittlung laden
                              Load_Parameter(LOAD_SAVE_FILTER_BANDWIDTH_WEIGHT,&nBandWidth,0);

                              DeadBandFilter_Setup(0,(float)nBandWidth,DEADBANDFILTER_LONGDATA);

                              /*~E:A332*/
                              /*~-1*/
#endif
                              /*~E:I331*/
                              /*~A:333*/
                              /*~+:Eintrag in Diagnosespeicher vornehmen*/
                              /*~T*/
                              ulDiagnosisEntry2Set = DIAGNOSIS_MESSAGE_DAC_CALIBRATION_FINISHED;
                              /*~E:A333*/
                              /*~T*/
                              CurrentInterface_SaveDACSettings(CURRENTINTERFACE_ALL_SETTINGS);
                              /*~T*/
                              // Simulation des Rohmesswerts ausschalten
                              CurrentInterface_PrepareCalibration(0,0);
                              /*~A:334*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              /*~T*/
                              lText2Send = TEXT_CURRENT_INTERFACE_CALIBRATION_FINISHED_CHANNEL_1;
                              /*~E:A334*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F325*/
                              /*~E:A324*/
                              /*~O:C296*/
                              /*~-2*/
                              default:
                              {
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E002;
                              /*~-1*/
                              }
                              /*~-1*/
                              }
                              /*~E:C296*/
                              /*~-1*/
#endif
                              /*~E:I295*/
                              /*~T*/
                              break;
                              /*~E:A294*/
                              /*~-1*/
                              }
                              /*~E:F293*/
                              /*~O:C253*/
                              /*~-2*/
                              default:
                              {
                              /*~A:335*/
                              /*~+:Kanal 0*/
                              /*~I:336*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I336*/
                              /*~E:A335*/
                              /*~-1*/
                              }
                           /*~-1*/
                           }
                           /*~E:C253*/
                        /*~-1*/
                        }
                        /*~O:I252*/
                        /*~-2*/
                        else
                        {
                           /*~A:337*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A337*/
                        /*~-1*/
                        }
                        /*~E:I252*/
                     /*~-1*/
                     }
                     /*~E:I249*/
                     /*~E:A248*/
                     /*~A:338*/
                     /*~+:CID - ClearsystemID*/
                     /*~I:339*/
                     if (!strcmp(szCommand,"CID"))
                     /*~-1*/
                     {
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~A:340*/
                        /*~+:Kanal 0*/
                        /*~I:341*/
#ifdef CHANNEL_0
                        /*~A:342*/
                        /*~+:Variablendeklarationen*/
                        /*~T*/

                        /*~E:A342*/
                        /*~I:343*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~I:344*/
                           if (Communication_GetLongParameter(0) == ADMINCODE)
                           /*~-1*/
                           {
                              /*~T*/
                              Global.ulSystemID = 0;

                              Save_Parameter(LOAD_SAVE_SYSTEM_ID,&Global.ulSystemID,4);
                              /*~A:345*/
                              /*~+:Eintrag im Diagnosespeicher vornehmen*/
                              /*~T*/
                              ulDiagnosisEntry2Set = DIAGNOSIS_WARNING_ID_CLEARED;
                              /*~E:A345*/
                              /*~A:346*/
                              /*~+:Textausgabe*/
                              /*~T*/
                              // Textausgabe
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              lText2Send = TEXT_ID_CLEARED;
                              /*~E:A346*/
                           /*~-1*/
                           }
                           /*~O:I344*/
                           /*~-2*/
                           else
                           {
                              /*~T*/
                              // Textausgabe
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;

                              lText2Send = TEXT_SYSTEM_CLEAR_ID_FAULT;
                           /*~-1*/
                           }
                           /*~E:I344*/
                        /*~-1*/
                        }
                        /*~O:I343*/
                        /*~-2*/
                        else
                        {
                           /*~A:347*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A347*/
                        /*~-1*/
                        }
                        /*~E:I343*/
                        /*~-1*/
#endif
                        /*~E:I341*/
                        /*~E:A340*/
                     /*~-1*/
                     }
                     /*~E:I339*/
                     /*~E:A338*/
                     /*~A:348*/
                     /*~+:CIF - CurrentInterfaceFeedback onoff*/
                     /*~I:349*/
                     if (!strcmp(szCommand,"CIF"))
                     /*~-1*/
                     {
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:350*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0); 
                           /*~I:351*/
                           if (!GET_RESPONSE)
                           /*~-1*/
                           {
                              /*~T*/
                              // Kanal best�tigte mit ACKNOWLEDGE
                              /*~I:352*/
                              if (Parameter[0].nLong)
                              /*~-1*/
                              {
                              /*~T*/
                              CurrentInterface_SetFeedBackOnOff(1,1);
                              /*~A:353*/
                              /*~+:Eintrag in Diagnosespeicher vornehmen*/
                              /*~T*/
                              ulDiagnosisEntry2Set = DIAGNOSIS_WARNING_DAC_FEEDBACK_SWITCHED_ON;
                              /*~E:A353*/
                              /*~A:354*/
                              /*~+:Ausf�hrungsstatus auf 'OKAY' setzen*/
                              /*~+:*/
                              /*~T*/
                              // Ausf�hrungsstatus auf 'OKAY' setzen
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              /*~E:A354*/
                              /*~A:355*/
                              /*~+:Kanal 0 - Textausgabe*/
                              /*~I:356*/
#ifdef CHANNEL_0 
                              /*~A:357*/
                              /*~+:Textausgabe �ber Kanal 0*/
                              /*~I:358*/
#ifdef CHANNEL_0
                              /*~T*/
                              lText2Send = TEXT_FEEDBACK_SWITCHED_ON;
                              /*~-1*/
#endif
                              /*~E:I358*/
                              /*~E:A357*/
                              /*~-1*/
#endif
                              /*~E:I356*/
                              /*~E:A355*/
                              /*~-1*/
                              }
                              /*~O:I352*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              CurrentInterface_SetFeedBackOnOff(0,1);
                              /*~A:359*/
                              /*~+:Eintrag in Diagnosespeicher vornehmen*/
                              /*~T*/
                              ulDiagnosisEntry2Set = DIAGNOSIS_WARNING_DAC_FEEDBACK_SWITCHED_OFF;
                              /*~E:A359*/
                              /*~A:360*/
                              /*~+:Ausf�hrungsstatus auf 'OKAY' setzen*/
                              /*~+:*/
                              /*~T*/
                              // Ausf�hrungsstatus auf 'OKAY' setzen
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              /*~E:A360*/
                              /*~A:361*/
                              /*~+:Kanal 0 - Textausgabe*/
                              /*~I:362*/
#ifdef CHANNEL_0 
                              /*~A:363*/
                              /*~+:Textausgabe �ber Kanal 0*/
                              /*~I:364*/
#ifdef CHANNEL_0
                              /*~T*/
                              lText2Send = TEXT_FEEDBACK_SWITCHED_OFF;
                              /*~-1*/
#endif
                              /*~E:I364*/
                              /*~E:A363*/
                              /*~-1*/
#endif
                              /*~E:I362*/
                              /*~E:A361*/
                              /*~-1*/
                              }
                              /*~E:I352*/
                           /*~-1*/
                           }
                           /*~O:I351*/
                           /*~-2*/
                           else
                           {
                              /*~K*/
                              /*~+:Fehler !!!*/
                              /*~A:365*/
                              /*~+:Ausf�hrungsstatus auf 'E005' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A365*/
                           /*~-1*/
                           }
                           /*~E:I351*/
                        /*~-1*/
                        }
                        /*~O:I350*/
                        /*~-2*/
                        else
                        {
                           /*~A:366*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A366*/
                        /*~-1*/
                        }
                        /*~E:I350*/
                     /*~-1*/
                     }
                     /*~E:I349*/
                     /*~E:A348*/
                     /*~A:367*/
                     /*~+:CIG - CurrentInterfacechangeGain*/
                     /*~I:368*/
                     if (!strcmp(szCommand,"CIG"))
                     /*~-1*/
                     {
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:369*/
                        if (!InstructionDecoder_CheckNbParameters(2,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0);
                           Parameter[1].fFloat = Communication_GetFloatParameter(1);
                           /*~C:370*/
                           switch (Parameter[0].nLong)
                           /*~-1*/
                           {
                              /*~F:371*/
                              case 0:
                              /*~-1*/
                              {
                              /*~A:372*/
                              /*~+:Kanal 0*/
                              /*~I:373*/
#ifdef CHANNEL_0
                              /*~T*/
                              // Offset in-/dekrementieren
                              ADuC836_DACChangeGainbyStep(Parameter[1].fFloat);
                              // und neue Einstellungen sichern
                              CurrentInterface_SaveDACSettings(CURRENTINTERFACE_ALL_SETTINGS);
                              /*~A:374*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              lText2Send = TEXT_CURRENT_INTERFACE_GAIN_CHANGED_CHANNEL_0;
                              /*~E:A374*/
                              /*~-1*/
#endif
                              /*~E:I373*/
                              /*~E:A372*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F371*/
                              /*~F:375*/
                              case 1:
                              /*~-1*/
                              {
                              /*~A:376*/
                              /*~+:Kanal 1*/
                              /*~I:377*/
#ifdef CHANNEL_1
                              /*~T*/
                              // Offset in-/dekrementieren
                              ADuC836_DACChangeGainbyStep(Parameter[1].fFloat);
                              // und neue Einstellungen sichern
                              CurrentInterface_SaveDACSettings(CURRENTINTERFACE_ALL_SETTINGS);
                              /*~A:378*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              lText2Send = TEXT_CURRENT_INTERFACE_GAIN_CHANGED_CHANNEL_1;
                              /*~E:A378*/
                              /*~-1*/
#endif
                              /*~E:I377*/
                              /*~E:A376*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F375*/
                              /*~O:C370*/
                              /*~-2*/
                              default:
                              {
                              /*~K*/
                              /*~+:// Parameterfehler*/
                              /*~A:379*/
                              /*~+:Kanal 0*/
                              /*~I:380*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I380*/
                              /*~E:A379*/
                              /*~-1*/
                              }
                           /*~-1*/
                           }
                           /*~E:C370*/
                        /*~-1*/
                        }
                        /*~O:I369*/
                        /*~-2*/
                        else
                        {
                           /*~A:381*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A381*/
                        /*~-1*/
                        }
                        /*~E:I369*/
                     /*~-1*/
                     }
                     /*~E:I368*/
                     /*~E:A367*/
                     /*~I:382*/
#ifndef OHNE_STROMRUECKFUEHRUNG
                     /*~A:383*/
                     /*~+:CII - CurrentInterfaceIntegralportion*/
                     /*~I:384*/
                     if (!strcmp(szCommand,"CII"))
                     /*~-1*/
                     {
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:385*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0); 
                           /*~I:386*/
                           if ((Parameter[0].nLong >= 0)&&(Parameter[0].nLong <= 100))
                           /*~-1*/
                           {
                              /*~T*/
                              // Parameter[0].nLong = 100 - Parameter[0].nLong;
                              /*~I:387*/
                              if (!GET_RESPONSE)
                              /*~-1*/
                              {
                              /*~T*/
                              // Kanal best�tigte mit ACKNOWLEDGE
                              /*~T*/
                              CurrentInterface_SetFeedBackIntegralPortion((char)Parameter[0].nLong);
                              /*~A:388*/
                              /*~+:Ausf�hrungsstatus auf 'OKAY' setzen*/
                              /*~+:*/
                              /*~T*/
                              // Ausf�hrungsstatus auf 'OKAY' setzen
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              /*~E:A388*/
                              /*~A:389*/
                              /*~+:Kanal 0 - Textausgabe*/
                              /*~I:390*/
#ifdef CHANNEL_0 
                              /*~A:391*/
                              /*~+:Textausgabe �ber Kanal 0*/
                              /*~I:392*/
#ifdef CHANNEL_0
                              /*~T*/
                              lText2Send = TEXT_FEEDBACK_INTEGRAL_PORTION_SET;
                              /*~-1*/
#endif
                              /*~E:I392*/
                              /*~E:A391*/
                              /*~-1*/
#endif
                              /*~E:I390*/
                              /*~E:A389*/
                              /*~-1*/
                              }
                              /*~O:I387*/
                              /*~-2*/
                              else
                              {
                              /*~K*/
                              /*~+:Fehler !!!*/
                              /*~A:393*/
                              /*~+:Ausf�hrungsstatus auf 'E005' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A393*/
                              /*~-1*/
                              }
                              /*~E:I387*/
                           /*~-1*/
                           }
                           /*~O:I386*/
                           /*~-2*/
                           else
                           {
                              /*~K*/
                              /*~+:Fehler - Wert au�erhalb des Bereichs !!!*/
                              /*~A:394*/
                              /*~+:Kanal 0 - Ausf�hrungsstatus auf 'E002' setzen*/
                              /*~I:395*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E002;
                              /*~-1*/
#endif
                              /*~E:I395*/
                              /*~E:A394*/
                           /*~-1*/
                           }
                           /*~E:I386*/
                        /*~-1*/
                        }
                        /*~O:I385*/
                        /*~-2*/
                        else
                        {
                           /*~A:396*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A396*/
                        /*~-1*/
                        }
                        /*~E:I385*/
                     /*~-1*/
                     }
                     /*~E:I384*/
                     /*~E:A383*/
                     /*~-1*/
#endif
                     /*~E:I382*/
                     /*~A:397*/
                     /*~+:CIM - CurrentInterfaceManualmode*/
                     /*~I:398*/
                     if (!strcmp(szCommand,"CIM"))
                     /*~-1*/
                     {
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:399*/
                        if (!InstructionDecoder_CheckNbParameters(2,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0);
                           Parameter[1].nLong = Communication_GetLongParameter(1);
                           /*~C:400*/
                           switch (Parameter[0].nLong)
                           /*~-1*/
                           {
                              /*~F:401*/
                              case 0:
                              /*~-1*/
                              {
                              /*~A:402*/
                              /*~+:Kanal 0*/
                              /*~I:403*/
#ifdef CHANNEL_0
                              /*~T*/
                              // Alles okay
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              /*~I:404*/
                              if (Parameter[1].nLong > -1)
                              /*~-1*/
                              {
                              /*~T*/
                              // DAC-Testmode aktiv setzen
                              CurrentInterface_SetManualMode(1,Parameter[1].nLong);
                              /*~A:405*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              lText2Send = TEXT_CURRENT_INTERFACE_MANUAL_MODE_ON_CHANNEL_0;
                              /*~E:A405*/
                              /*~-1*/
                              }
                              /*~O:I404*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              // DAC-Testmode inaktiv setzen
                              CurrentInterface_SetManualMode(0,Parameter[1].nLong);
                              /*~A:406*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              lText2Send = TEXT_CURRENT_INTERFACE_MANUAL_MODE_OFF_CHANNEL_0;
                              /*~E:A406*/
                              /*~-1*/
                              }
                              /*~E:I404*/
                              /*~-1*/
#endif
                              /*~E:I403*/
                              /*~E:A402*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F401*/
                              /*~F:407*/
                              case 1:
                              /*~-1*/
                              {
                              /*~A:408*/
                              /*~+:Kanal 1*/
                              /*~I:409*/
#ifdef CHANNEL_1
                              /*~T*/
                              // Alles okay
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              /*~I:410*/
                              if (Parameter[1].nLong > -1)
                              /*~-1*/
                              {
                              /*~T*/
                              // DAC-Testmode aktiv setzen
                              CurrentInterface_SetManualMode(1,Parameter[1].nLong);
                              /*~A:411*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              lText2Send = TEXT_CURRENT_INTERFACE_MANUAL_MODE_ON_CHANNEL_1;
                              /*~E:A411*/
                              /*~-1*/
                              }
                              /*~O:I410*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              // DAC-Testmode aktiv setzen
                              SET_DAC_TESTMODE(0);
                              /*~A:412*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              lText2Send = TEXT_CURRENT_INTERFACE_MANUAL_MODE_OFF_CHANNEL_1;
                              /*~E:A412*/
                              /*~-1*/
                              }
                              /*~E:I410*/
                              /*~-1*/
#endif
                              /*~E:I409*/
                              /*~E:A408*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F407*/
                              /*~O:C400*/
                              /*~-2*/
                              default:
                              {
                              /*~A:413*/
                              /*~+:Kanal 0*/
                              /*~I:414*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I414*/
                              /*~E:A413*/
                              /*~-1*/
                              }
                           /*~-1*/
                           }
                           /*~E:C400*/
                        /*~-1*/
                        }
                        /*~O:I399*/
                        /*~-2*/
                        else
                        {
                           /*~A:415*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A415*/
                        /*~-1*/
                        }
                        /*~E:I399*/
                     /*~-1*/
                     }
                     /*~E:I398*/
                     /*~E:A397*/
                     /*~A:416*/
                     /*~+:CIO - CurrentInterfacechangeOffset*/
                     /*~I:417*/
                     if (!strcmp(szCommand,"CIO"))
                     /*~-1*/
                     {
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:418*/
                        if (!InstructionDecoder_CheckNbParameters(2,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0);
                           Parameter[1].nLong = Communication_GetLongParameter(1);
                           /*~C:419*/
                           switch (Parameter[0].nLong)
                           /*~-1*/
                           {
                              /*~F:420*/
                              case 0:
                              /*~-1*/
                              {
                              /*~A:421*/
                              /*~+:Kanal 0*/
                              /*~I:422*/
#ifdef CHANNEL_0
                              /*~T*/
                              // Offset in-/dekrementieren
                              ADuC836_DACChangeOffsetbyStep(Parameter[1].nLong);
                              // und neue Einstellungen sichern
                              CurrentInterface_SaveDACSettings(CURRENTINTERFACE_ALL_SETTINGS);
                              /*~A:423*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              lText2Send = TEXT_CURRENT_INTERFACE_OFFSET_CHANGED_CHANNEL_0;
                              /*~E:A423*/
                              /*~-1*/
#endif
                              /*~E:I422*/
                              /*~E:A421*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F420*/
                              /*~F:424*/
                              case 1:
                              /*~-1*/
                              {
                              /*~A:425*/
                              /*~+:Kanal 1*/
                              /*~I:426*/
#ifdef CHANNEL_1
                              /*~T*/
                              // Offset in-/dekrementieren
                              ADuC836_DACChangeOffsetbyStep(Parameter[1].nLong);
                              // und neue Einstellungen sichern
                              CurrentInterface_SaveDACSettings(CURRENTINTERFACE_ALL_SETTINGS);
                              /*~A:427*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              lText2Send = TEXT_CURRENT_INTERFACE_OFFSET_CHANGED_CHANNEL_1;
                              /*~E:A427*/
                              /*~-1*/
#endif
                              /*~E:I426*/
                              /*~E:A425*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F424*/
                              /*~O:C419*/
                              /*~-2*/
                              default:
                              {
                              /*~A:428*/
                              /*~+:Kanal 0*/
                              /*~I:429*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I429*/
                              /*~E:A428*/
                              /*~-1*/
                              }
                           /*~-1*/
                           }
                           /*~E:C419*/
                        /*~-1*/
                        }
                        /*~O:I418*/
                        /*~-2*/
                        else
                        {
                           /*~A:430*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A430*/
                        /*~-1*/
                        }
                        /*~E:I418*/
                     /*~-1*/
                     }
                     /*~E:I417*/
                     /*~E:A416*/
                     /*~I:431*/
#ifndef OHNE_STROMRUECKFUEHRUNG
                     /*~A:432*/
                     /*~+:CIP - CurrentInterfaceProportionalportion*/
                     /*~I:433*/
                     if (!strcmp(szCommand,"CIP"))
                     /*~-1*/
                     {
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:434*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0); 
                           /*~I:435*/
                           if ((Parameter[0].nLong >= 0)&&(Parameter[0].nLong <= 100))
                           /*~-1*/
                           {
                              /*~I:436*/
                              if (!GET_RESPONSE)
                              /*~-1*/
                              {
                              /*~T*/
                              // Kanal best�tigte mit ACKNOWLEDGE
                              /*~T*/
                              CurrentInterface_SetFeedBackProportionalPortion((char)Parameter[0].nLong);
                              /*~A:437*/
                              /*~+:Ausf�hrungsstatus auf 'OKAY' setzen*/
                              /*~+:*/
                              /*~T*/
                              // Ausf�hrungsstatus auf 'OKAY' setzen
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              /*~E:A437*/
                              /*~A:438*/
                              /*~+:Kanal 0 - Textausgabe*/
                              /*~I:439*/
#ifdef CHANNEL_0 
                              /*~A:440*/
                              /*~+:Textausgabe �ber Kanal 0*/
                              /*~I:441*/
#ifdef CHANNEL_0
                              /*~T*/
                              lText2Send = TEXT_FEEDBACK_PROPORTIONAL_PORTION_SET;
                              /*~-1*/
#endif
                              /*~E:I441*/
                              /*~E:A440*/
                              /*~-1*/
#endif
                              /*~E:I439*/
                              /*~E:A438*/
                              /*~-1*/
                              }
                              /*~O:I436*/
                              /*~-2*/
                              else
                              {
                              /*~K*/
                              /*~+:Fehler !!!*/
                              /*~A:442*/
                              /*~+:Ausf�hrungsstatus auf 'E005' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A442*/
                              /*~-1*/
                              }
                              /*~E:I436*/
                           /*~-1*/
                           }
                           /*~O:I435*/
                           /*~-2*/
                           else
                           {
                              /*~K*/
                              /*~+:Fehler - Wert au�erhalb des Bereichs !!!*/
                              /*~A:443*/
                              /*~+:Kanal 0 - Ausf�hrungsstatus auf 'E002' setzen*/
                              /*~I:444*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E002;
                              /*~-1*/
#endif
                              /*~E:I444*/
                              /*~E:A443*/
                           /*~-1*/
                           }
                           /*~E:I435*/
                        /*~-1*/
                        }
                        /*~O:I434*/
                        /*~-2*/
                        else
                        {
                           /*~A:445*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A445*/
                        /*~-1*/
                        }
                        /*~E:I434*/
                     /*~-1*/
                     }
                     /*~E:I433*/
                     /*~E:A432*/
                     /*~-1*/
#endif
                     /*~E:I431*/
                     /*~A:446*/
                     /*~+:CIR - CurrentInterfaceRestorecalibration*/
                     /*~I:447*/
                     if (!strcmp(szCommand,"CIR"))
                     /*~-1*/
                     {
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:448*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0);
                           /*~C:449*/
                           switch (Parameter[0].nLong)
                           /*~-1*/
                           {
                              /*~F:450*/
                              case 0:
                              /*~-1*/
                              {
                              /*~A:451*/
                              /*~+:Kanal 0*/
                              /*~I:452*/
#ifdef CHANNEL_0
                              /*~T*/
                              CurrentInterface_LoadDACSettings(CURRENTINTERFACE_CALIBRATION_BACKUP);
                              /*~A:453*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              lText2Send = TEXT_CURRENT_INTERFACE_SET_2_DEFAULT_CHANNEL_0;
                              /*~E:A453*/
                              /*~-1*/
#endif
                              /*~E:I452*/
                              /*~E:A451*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F450*/
                              /*~F:454*/
                              case 1:
                              /*~-1*/
                              {
                              /*~A:455*/
                              /*~+:Kanal 1*/
                              /*~I:456*/
#ifdef CHANNEL_1
                              /*~T*/
                              CurrentInterface_LoadDACSettings(CURRENTINTERFACE_CALIBRATION_BACKUP);
                              /*~A:457*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              lText2Send = TEXT_CURRENT_INTERFACE_SET_2_DEFAULT_CHANNEL_1;
                              /*~E:A457*/
                              /*~-1*/
#endif
                              /*~E:I456*/
                              /*~E:A455*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F454*/
                              /*~O:C449*/
                              /*~-2*/
                              default:
                              {
                              /*~A:458*/
                              /*~+:Kanal 0*/
                              /*~I:459*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I459*/
                              /*~E:A458*/
                              /*~-1*/
                              }
                           /*~-1*/
                           }
                           /*~E:C449*/
                        /*~-1*/
                        }
                        /*~O:I448*/
                        /*~-2*/
                        else
                        {
                           /*~A:460*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A460*/
                        /*~-1*/
                        }
                        /*~E:I448*/
                     /*~-1*/
                     }
                     /*~E:I447*/
                     /*~E:A446*/
                     /*~A:461*/
                     /*~+:CIV - CurrentInterfaceVariousvalues*/
                     /*~I:462*/
                     if (!strcmp(szCommand,"CIV"))
                     /*~-1*/
                     {
                        /*~T*/
                        DAC_SETTINGS DAC_Settings;
                        /*~T*/
                        DAC_Settings = ADuC836_DACSaveSettings();
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:463*/
                        if (!InstructionDecoder_CheckNbParameters(2,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0);
                           Parameter[1].nLong = Communication_GetLongParameter(1);
                           /*~C:464*/
                           switch (Parameter[0].nLong)
                           /*~-1*/
                           {
                              /*~F:465*/
                              case 0:
                              /*~-1*/
                              {
                              /*~A:466*/
                              /*~+:Kanal 0*/
                              /*~I:467*/
#ifdef CHANNEL_0
                              /*~C:468*/
                              switch (Parameter[1].nLong)
                              /*~-1*/
                              {
                              /*~F:469*/
                              case 0:
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendFloat(COMMUNICATION_RS232,TEXT_CURRENT_INTERFACE_RMV_2_DAC_INPUT_OFFSET_CHANNEL_0,DAC_Settings.fOffset_RMV,-1,1,0);
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F469*/
                              /*~F:470*/
                              case 1:
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendFloat(COMMUNICATION_RS232,TEXT_CURRENT_INTERFACE_RMV_2_DAC_INPUT_GAIN_CHANNEL_0,DAC_Settings.fGain_RMV,-1,1,0);
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F470*/
                              /*~F:471*/
                              case 2:
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendFloat(COMMUNICATION_RS232,TEXT_CURRENT_INTERFACE_DAC_INPUT_2_CURRENT_OFFSET_CHANNEL_0,DAC_Settings.fOffset_Norm,-1,1,0);
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F471*/
                              /*~F:472*/
                              case 3:
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendFloat(COMMUNICATION_RS232,TEXT_CURRENT_INTERFACE_DAC_INPUT_2_CURRENT_GAIN_CHANNEL_0,DAC_Settings.fGain_Norm,-1,1,0);
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F472*/
                              /*~F:473*/
                              case 4:
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_CURRENT_INTERFACE_DAC_INPUT_CHANNEL_0,DACH * 256 + DACL,1,0);
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F473*/
                              /*~O:C468*/
                              /*~-2*/
                              default:
                              {
                              /*~T*/
                              sprintf(szCommand,"Kanal 0: %f;%f;%f;%f;%ld",DAC_Settings.fOffset_RMV,DAC_Settings.fGain_RMV,DAC_Settings.fOffset_Norm,DAC_Settings.fGain_Norm,DACH * 256 + DACL);
                              /*~T*/
                              Communication_SendString(COMMUNICATION_RS232,szCommand,1,0);
                              /*~-1*/
                              }
                              /*~-1*/
                              }
                              /*~E:C468*/
                              /*~-1*/
#endif
                              /*~E:I467*/
                              /*~T*/
                              break;
                              /*~E:A466*/
                              /*~-1*/
                              }
                              /*~E:F465*/
                              /*~F:474*/
                              case 1:
                              /*~-1*/
                              {
                              /*~A:475*/
                              /*~+:Kanal 1*/
                              /*~I:476*/
#ifdef CHANNEL_1
                              /*~T*/
                              // Alles okay
                              byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;

                              /*~C:477*/
                              switch (Parameter[1].nLong)
                              /*~-1*/
                              {
                              /*~F:478*/
                              case 0:
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendFloat(COMMUNICATION_RS232,TEXT_CURRENT_INTERFACE_RMV_2_DAC_INPUT_OFFSET_CHANNEL_1,DAC_Settings.fOffset_RMV,-1,1,0);
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F478*/
                              /*~F:479*/
                              case 1:
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendFloat(COMMUNICATION_RS232,TEXT_CURRENT_INTERFACE_RMV_2_DAC_INPUT_GAIN_CHANNEL_1,DAC_Settings.fGain_RMV,-1,1,0);
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F479*/
                              /*~F:480*/
                              case 2:
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendFloat(COMMUNICATION_RS232,TEXT_CURRENT_INTERFACE_DAC_INPUT_2_CURRENT_OFFSET_CHANNEL_1,DAC_Settings.fOffset_Norm,-1,1,0);
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F480*/
                              /*~F:481*/
                              case 3:
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendFloat(COMMUNICATION_RS232,TEXT_CURRENT_INTERFACE_DAC_INPUT_2_CURRENT_GAIN_CHANNEL_1,DAC_Settings.fGain_Norm,-1,1,0);
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F481*/
                              /*~F:482*/
                              case 4:
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_CURRENT_INTERFACE_DAC_INPUT_CHANNEL_1,DACH * 256 + DACL,1,0);
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F482*/
                              /*~O:C477*/
                              /*~-2*/
                              default:
                              {
                              /*~T*/
                              sprintf(szCommand,"Kanal 1: %f;%f;%f;%f;%ld",DAC_Settings.fOffset_RMV,DAC_Settings.fGain_RMV,DAC_Settings.fOffset_Norm,DAC_Settings.fGain_Norm,DACH * 256 + DACL);
                              /*~T*/
                              Communication_SendString(COMMUNICATION_RS232,szCommand,1,0);
                              /*~-1*/
                              }
                              /*~-1*/
                              }
                              /*~E:C477*/
                              /*~-1*/
#endif
                              /*~E:I476*/
                              /*~T*/
                              break;
                              /*~E:A475*/
                              /*~-1*/
                              }
                              /*~E:F474*/
                              /*~O:C464*/
                              /*~-2*/
                              default:
                              {
                              /*~A:483*/
                              /*~+:Kanal 0*/
                              /*~I:484*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I484*/
                              /*~E:A483*/
                              /*~-1*/
                              }
                           /*~-1*/
                           }
                           /*~E:C464*/
                        /*~-1*/
                        }
                        /*~O:I463*/
                        /*~-2*/
                        else
                        {
                           /*~A:485*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A485*/
                        /*~-1*/
                        }
                        /*~E:I463*/
                     /*~-1*/
                     }
                     /*~E:I462*/
                     /*~E:A461*/
                     /*~A:486*/
                     /*~+:CLI - ClearLImit*/
                     /*~I:487*/
                     if (!strcmp(szCommand,"CLI"))
                     /*~-1*/
                     {
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:488*/
                        if (!InstructionDecoder_CheckNbParameters(0,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~I:489*/
                           if (!GET_RESPONSE)
                           /*~-1*/
                           {
                              /*~T*/
                              CurrentInterface_LoadDACSettings(CURRENTINTERFACE_CALIBRATION_BACKUP);
                              /*~A:490*/
                              /*~+:Ausf�hrungsstatus auf 'OKAY' setzen*/
                              /*~+:*/
                              /*~T*/
                              // Ausf�hrungsstatus auf 'OKAY' setzen
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              /*~E:A490*/
                              /*~A:491*/
                              /*~+:Kanal 0 - Textausgabe*/
                              /*~I:492*/
#ifdef CHANNEL_0 
                              /*~A:493*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              lText2Send = TEXT_LIMITS_SET_2_DEFAULT;
                              /*~E:A493*/
                              /*~-1*/
#endif
                              /*~E:I492*/
                              /*~E:A491*/
                           /*~-1*/
                           }
                           /*~O:I489*/
                           /*~-2*/
                           else
                           {
                              /*~K*/
                              /*~+:Fehler !!!*/
                              /*~A:494*/
                              /*~+:Ausf�hrungsstatus auf 'E005' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A494*/
                           /*~-1*/
                           }
                           /*~E:I489*/
                        /*~-1*/
                        }
                        /*~O:I488*/
                        /*~-2*/
                        else
                        {
                           /*~A:495*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A495*/
                        /*~-1*/
                        }
                        /*~E:I488*/
                     /*~-1*/
                     }
                     /*~E:I487*/
                     /*~E:A486*/
                     /*~A:496*/
                     /*~+:CRC - ClearResetreplyCounter*/
                     /*~I:497*/
                     if (!strcmp(szCommand,"CRC"))
                     /*~-1*/
                     {
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:498*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0);
                           /*~T*/
                           Communication_ClearSPIFaultCounter((unsigned char)Parameter[0].nLong);
                           /*~I:499*/
#ifdef CHANNEL_0
                           /*~A:500*/
                           /*~+:Textausgabe*/
                           /*~T*/
                           byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                           lText2Send = TEXT_RESET_REPLIES_COUNTER_CLEARED;
                           /*~E:A500*/
                           /*~-1*/
#endif
                           /*~E:I499*/
                        /*~-1*/
                        }
                        /*~O:I498*/
                        /*~-2*/
                        else
                        {
                           /*~A:501*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A501*/
                        /*~-1*/
                        }
                        /*~E:I498*/
                     /*~-1*/
                     }
                     /*~E:I497*/
                     /*~E:A496*/
                     /*~A:502*/
                     /*~+:CRE - ClearResetEnableflag*/
                     /*~I:503*/
                     if (!strcmp(szCommand,"CRE"))
                     /*~-1*/
                     {
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:504*/
                        if (!InstructionDecoder_CheckNbParameters(0,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Communication_SetResetInhibitFlag(2);
                           /*~A:505*/
                           /*~+:Kanal 0 - Textausgabe*/
                           /*~I:506*/
#ifdef CHANNEL_0
                           /*~T*/
                           byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                           lText2Send = TEXT_RESET_INHIBIT_FLAG_SET;
                           /*~-1*/
#endif
                           /*~E:I506*/
                           /*~E:A505*/
                        /*~-1*/
                        }
                        /*~O:I504*/
                        /*~-2*/
                        else
                        {
                           /*~A:507*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A507*/
                        /*~-1*/
                        }
                        /*~E:I504*/
                     /*~-1*/
                     }
                     /*~E:I503*/
                     /*~E:A502*/
                     /*~I:508*/
#ifdef MOF
                     /*~A:509*/
                     /*~+:CRS - ClearRs232Statistics*/
                     /*~I:510*/
                     if (!strcmp(szCommand,"CRS"))
                     /*~-1*/
                     {
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:511*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0); 
                           /*~C:512*/
                           switch (Parameter[0].nLong)
                           /*~-1*/
                           {
                              /*~F:513*/
                              case 0:
                              /*~-1*/
                              {
                              /*~A:514*/
                              /*~+:Kanal 0*/
                              /*~I:515*/
#ifdef CHANNEL_0
                              /*~T*/
                              ADuC836_RS232ClearStatistics();
                              /*~A:516*/
                              /*~+:Textausgabe*/
                              /*~T*/
                              // Textausgabe
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              lText2Send = TEXT_RS232_STATISTICS_CLEARED_CHANNEL_0;
                              /*~E:A516*/
                              /*~-1*/
#endif
                              /*~E:I515*/
                              /*~E:A514*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F513*/
                              /*~F:517*/
                              case 1:
                              /*~-1*/
                              {
                              /*~A:518*/
                              /*~+:Kanal 1*/
                              /*~I:519*/
#ifdef CHANNEL_1
                              /*~T*/
                              ADuC836_RS232ClearStatistics();
                              /*~A:520*/
                              /*~+:Textausgabe*/
                              /*~T*/
                              // Textausgabe
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              lText2Send = TEXT_RS232_STATISTICS_CLEARED_CHANNEL_0;
                              /*~E:A520*/
                              /*~-1*/
#endif
                              /*~E:I519*/
                              /*~E:A518*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F517*/
                              /*~O:C512*/
                              /*~-2*/
                              default:
                              {
                              /*~A:521*/
                              /*~+:Kanal 0*/
                              /*~I:522*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I522*/
                              /*~E:A521*/
                              /*~-1*/
                              }
                           /*~-1*/
                           }
                           /*~E:C512*/
                        /*~-1*/
                        }
                        /*~O:I511*/
                        /*~-2*/
                        else
                        {
                           /*~A:523*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A523*/
                        /*~-1*/
                        }
                        /*~E:I511*/
                     /*~-1*/
                     }
                     /*~E:I510*/
                     /*~E:A509*/
                     /*~-1*/
#endif
                     /*~E:I508*/
                     /*~I:524*/
#ifdef DEVELOPMENT_SW
                     /*~A:525*/
                     /*~+:CSC - ClearSpicheckCounter*/
                     /*~I:526*/
                     if (!strcmp(szCommand,"CSC"))
                     /*~-1*/
                     {
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;

                        /*~I:527*/
                        if (!InstructionDecoder_CheckNbParameters(0,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~A:528*/
                           /*~+:Ausf�hrungsstatus auf 'OKAY' setzen*/
                           /*~+:*/
                           /*~I:529*/
#ifdef CHANNEL_0
                           /*~T*/
                           // Ausf�hrungsstatus auf 'OKAY' setzen
                           byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                           /*~-1*/
#endif
                           /*~E:I529*/
                           /*~E:A528*/
                           /*~T*/
                           // SPI-Test Z�hler l�schen
                           CommunicationControl.ulSPICounter = 0;

                           /*~I:530*/
#ifdef CHANNEL_0
                           /*~T*/
                           CommunicationControl.ulSPIE1Counter = 0;
                           CommunicationControl.ulSPIE1CounterLast = -1;
                           /*~-1*/
#endif
                           /*~E:I530*/
                           /*~A:531*/
                           /*~+:Kanal 0 - Textausgabe*/
                           /*~I:532*/
#ifdef CHANNEL_0
                           /*~T*/
                           lText2Send = TEXT_SYSTEM_CLEAR_SPI_CHECK_COUNTERS;
                           /*~-1*/
#endif
                           /*~E:I532*/
                           /*~E:A531*/
                        /*~-1*/
                        }
                        /*~O:I527*/
                        /*~-2*/
                        else
                        {
                           /*~A:533*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A533*/
                        /*~-1*/
                        }
                        /*~E:I527*/
                     /*~-1*/
                     }
                     /*~E:I526*/
                     /*~E:A525*/
                     /*~-1*/
#endif
                     /*~E:I524*/
                     /*~A:534*/
                     /*~+:CSD - ClearStatisticsData*/
                     /*~I:535*/
                     if (!strcmp(szCommand,"CSD"))
                     /*~-1*/
                     {
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:536*/
                        if (!InstructionDecoder_CheckNbParameters(2,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           // Parameter auslesen
                           Parameter[0].nLong = Communication_GetLongParameter(0);
                           Parameter[1].nLong = Communication_GetLongParameter(1);

                           /*~C:537*/
                           switch (Parameter[0].nLong)
                           /*~-1*/
                           {
                              /*~F:538*/
                              case 0:
                              /*~-1*/
                              {
                              /*~A:539*/
                              /*~+:Kanal 0*/
                              /*~I:540*/
#ifdef CHANNEL_0
                              /*~T*/
                              Statistics_Clear((unsigned char)Parameter[1].nLong);
                              /*~T*/
                              // Merker f�r ein interpretierbares Kommando setzen - keine Textausgabe
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              lText2Send = TEXT_STATITISTICS_CLEARED_CHANNEL_0; 
                              /*~-1*/
#endif
                              /*~E:I540*/
                              /*~E:A539*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F538*/
                              /*~F:541*/
                              case 1:
                              /*~-1*/
                              {
                              /*~A:542*/
                              /*~+:Kanal 1*/
                              /*~I:543*/
#ifdef CHANNEL_1
                              /*~T*/
                              Statistics_Clear((unsigned char)Parameter[1].nLong);
                              /*~T*/
                              // Merker f�r ein interpretierbares Kommando setzen - keine Textausgabe
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              lText2Send = TEXT_STATITISTICS_CLEARED_CHANNEL_1; 
                              /*~-1*/
#endif
                              /*~E:I543*/
                              /*~E:A542*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F541*/
                              /*~O:C537*/
                              /*~-2*/
                              default:
                              {
                              /*~A:544*/
                              /*~+:Kanal 0*/
                              /*~I:545*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I545*/
                              /*~E:A544*/
                              /*~-1*/
                              }
                           /*~-1*/
                           }
                           /*~E:C537*/
                        /*~-1*/
                        }
                        /*~O:I536*/
                        /*~-2*/
                        else
                        {
                           /*~A:546*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A546*/
                        /*~-1*/
                        }
                        /*~E:I536*/
                     /*~-1*/
                     }
                     /*~E:I535*/
                     /*~E:A534*/
                     /*~A:547*/
                     /*~+:CTM - ClearTiMer*/
                     /*~I:548*/
                     if (!strcmp(szCommand,"CTM"))
                     /*~-1*/
                     {
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~A:549*/
                        /*~+:Kanal 0*/
                        /*~I:550*/
#ifdef CHANNEL_0
                        /*~I:551*/
                        if (!InstructionDecoder_CheckNbParameters(2,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~I:552*/
                           if ((Communication_GetLongParameter(1) == ADMINCODE)||(Communication_GetLongParameter(0) == 1))
                           /*~-1*/
                           {
                              /*~T*/
                              // Relativen Betriebsstundenz�hler l�schen
                              System_ClearOperatingHours(1);
                              /*~A:553*/
                              /*~+:Eintrag im Diagnosespeicher*/
                              /*~T*/
                              Diagnosis_WriteMessage2Flash(DIAGNOSIS_MESSAGE_OPERATINGHOURS_2_CLEARED);
                              /*~E:A553*/
                              /*~A:554*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~I:555*/
                              if (!SYSTEM_MRW_MANAGER)
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendString(COMMUNICATION_RS232,T_TEXT_OPERATING_HOURS_RELATIVE_CLEARED,1,0);
                              /*~-1*/
                              }
                              /*~O:I555*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              Communication_SendMessage(COMMUNICATION_RS232,COMMUNICATION_OK);
                              /*~-1*/
                              }
                              /*~E:I555*/
                              /*~E:A554*/
                              /*~I:556*/
                              if (Communication_GetLongParameter(0) != 1)
                              /*~-1*/
                              {
                              /*~T*/
                              // Betriebsstundenz�hler l�schen
                              System_ClearOperatingHours(0);
                              /*~A:557*/
                              /*~+:Eintrag im Diagnosespeicher*/
                              /*~T*/
                              Diagnosis_WriteMessage2Flash(DIAGNOSIS_MESSAGE_OPERATINGHOURS_CLEARED);
                              /*~E:A557*/
                              /*~A:558*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              lText2Send = TEXT_OPERATING_HOURS_CLEARED;
                              /*~E:A558*/
                              /*~-1*/
                              }
                              /*~E:I556*/
                           /*~-1*/
                           }
                           /*~O:I552*/
                           /*~-2*/
                           else
                           {
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E002;
                           /*~-1*/
                           }
                           /*~E:I552*/
                        /*~-1*/
                        }
                        /*~O:I551*/
                        /*~-2*/
                        else
                        {
                           /*~A:559*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A559*/
                        /*~-1*/
                        }
                        /*~E:I551*/
                        /*~-1*/
#endif
                        /*~E:I550*/
                        /*~E:A549*/
                     /*~-1*/
                     }
                     /*~E:I548*/
                     /*~E:A547*/
                     /*~A:560*/
                     /*~+:CTR - ClearTaRa*/
                     /*~I:561*/
                     if (!strcmp(szCommand,"CTR"))
                     /*~-1*/
                     {
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;

                        /*~I:562*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           // Parameter auslesen
                           Parameter[0].nLong = Communication_GetLongParameter(0);
                           /*~C:563*/
                           switch (Parameter[0].nLong)
                           /*~-1*/
                           {
                              /*~F:564*/
                              case 0:
                              /*~-1*/
                              {
                              /*~A:565*/
                              /*~+:Kanal 0*/
                              /*~I:566*/
#ifdef CHANNEL_0
                              /*~I:567*/
                              // Tara setzen und speichern
                              if (!Weight_SetTareValue(0,1))
                              /*~-1*/
                              {
                              /*~A:568*/
                              /*~+:Eintrag in Diagnosespeicher vornehmen*/
                              /*~T*/
                              ulDiagnosisEntry2Set = DIAGNOSIS_MESSAGE_TARE_CLEARED;
                              /*~E:A568*/
                              /*~A:569*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              /*~T*/
                              lText2Send = TEXT_MEASUREMENT_TARA_CLEARED_CHANNEL_0;
                              /*~E:A569*/
                              /*~-1*/
                              }
                              /*~O:I567*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~-1*/
                              }
                              /*~E:I567*/
                              /*~-1*/
#endif
                              /*~E:I566*/
                              /*~E:A565*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F564*/
                              /*~F:570*/
                              case 1:
                              /*~-1*/
                              {
                              /*~A:571*/
                              /*~+:Kanal 1*/
                              /*~I:572*/
#ifdef CHANNEL_1
                              /*~I:573*/
                              // Tara setzen und speichern
                              if (!Weight_SetTareValue(0,1))
                              /*~-1*/
                              {
                              /*~A:574*/
                              /*~+:Eintrag in Diagnosespeicher vornehmen*/
                              /*~T*/
                              ulDiagnosisEntry2Set = DIAGNOSIS_MESSAGE_TARE_CLEARED;
                              /*~E:A574*/
                              /*~A:575*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              /*~T*/
                              lText2Send = TEXT_MEASUREMENT_TARA_CLEARED_CHANNEL_1;
                              /*~E:A575*/
                              /*~-1*/
                              }
                              /*~O:I573*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~-1*/
                              }
                              /*~E:I573*/
                              /*~-1*/
#endif
                              /*~E:I572*/
                              /*~E:A571*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F570*/
                              /*~O:C563*/
                              /*~-2*/
                              default:
                              {
                              /*~A:576*/
                              /*~+:Kanal 0*/
                              /*~I:577*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I577*/
                              /*~E:A576*/
                              /*~-1*/
                              }
                           /*~-1*/
                           }
                           /*~E:C563*/
                        /*~-1*/
                        }
                        /*~O:I562*/
                        /*~-2*/
                        else
                        {
                           /*~A:578*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A578*/
                        /*~-1*/
                        }
                        /*~E:I562*/
                     /*~-1*/
                     }
                     /*~E:I561*/
                     /*~E:A560*/
                     /*~A:579*/
                     /*~+:CWD - ClearWatchDogadress*/
                     /*~I:580*/
                     if (!strcmp(szCommand,"CWD"))
                     /*~-1*/
                     {
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:581*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~C:582*/
                           switch (Communication_GetLongParameter(0))
                           /*~-1*/
                           {
                              /*~F:583*/
                              case 0:
                              /*~-1*/
                              {
                              /*~A:584*/
                              /*~+:Kanal 0*/
                              /*~I:585*/
#ifdef CHANNEL_0
                              /*~T*/
                              ADuC836_WatchdogClearAddress();
                              /*~T*/
                              // Merker f�r ein interpretierbares Kommando setzen - keine Textausgabe
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              lText2Send = TEXT_WATCHDOG_ADDRESS_CLEARED_CHANNEL_0; 
                              /*~-1*/
#endif
                              /*~E:I585*/
                              /*~E:A584*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F583*/
                              /*~F:586*/
                              case 1:
                              /*~-1*/
                              {
                              /*~A:587*/
                              /*~+:Kanal 1*/
                              /*~I:588*/
#ifdef CHANNEL_1
                              /*~T*/
                              ADuC836_WatchdogClearAddress();
                              /*~T*/
                              // Merker f�r ein interpretierbares Kommando setzen - keine Textausgabe
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              lText2Send = TEXT_WATCHDOG_ADDRESS_CLEARED_CHANNEL_1; 
                              /*~-1*/
#endif
                              /*~E:I588*/
                              /*~E:A587*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F586*/
                              /*~O:C582*/
                              /*~-2*/
                              default:
                              {
                              /*~A:589*/
                              /*~+:Kanal 0*/
                              /*~I:590*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I590*/
                              /*~E:A589*/
                              /*~-1*/
                              }
                           /*~-1*/
                           }
                           /*~E:C582*/
                        /*~-1*/
                        }
                        /*~O:I581*/
                        /*~-2*/
                        else
                        {
                           /*~A:591*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A591*/
                        /*~-1*/
                        }
                        /*~E:I581*/
                     /*~-1*/
                     }
                     /*~E:I580*/
                     /*~E:A579*/
                     /*~T*/
                     break;
                  /*~-1*/
                  }
                  /*~E:F130*/
                  /*~E:A129*/
                  /*~K*/
                  /*~+:/~* Ge�ndert am 09.02.2022 *~/*/
                  /*~A:592*/
                  /*~+:D*/
                  /*~F:593*/
                  case 'D':
                  /*~-1*/
                  {
                     /*~A:594*/
                     /*~+:DIS - DISable RS232-Kommunikation*/
                     /*~I:595*/
                     if (!strcmp(szCommand,"DIS"))
                     /*~-1*/
                     {
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:596*/
                        if (!InstructionDecoder_CheckNbParameters(2,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0);
                           Parameter[1].nLong = Communication_GetLongParameter(1);
                           /*~C:597*/
                           switch (Parameter[0].nLong)
                           /*~-1*/
                           {
                              /*~F:598*/
                              case 0:
                              /*~-1*/
                              {
                              /*~A:599*/
                              /*~+:Kanal 0*/
                              /*~I:600*/
#ifdef CHANNEL_0
                              /*~I:601*/
                              if (Parameter[1].nLong == COMMUNICATION_DISABLE_CODE)
                              /*~-1*/
                              {
                              /*~T*/
                              byRetVal = Communication_EnableCommunication(0);
                              /*~I:602*/
                              if (byRetVal == 0)
                              /*~-1*/
                              {
                              /*~A:603*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              lText2Send = TEXT_RS232_COMMUNICATION_DISABLED_CHANNEL_0;
                              /*~E:A603*/
                              /*~-1*/
                              }
                              /*~O:I602*/
                              /*~-2*/
                              else
                              {
                              /*~K*/
                              /*~+:Fehler*/
                              /*~A:604*/
                              /*~+:Textausgabe "E005"*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A604*/
                              /*~-1*/
                              }
                              /*~E:I602*/
                              /*~-1*/
                              }
                              /*~O:I601*/
                              /*~-2*/
                              else
                              {
                              /*~K*/
                              /*~+:Fehler*/
                              /*~A:605*/
                              /*~+:Textausgabe "E005"*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A605*/
                              /*~-1*/
                              }
                              /*~E:I601*/
                              /*~-1*/
#endif
                              /*~E:I600*/
                              /*~E:A599*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F598*/
                              /*~F:606*/
                              case 1:
                              /*~-1*/
                              {
                              /*~A:607*/
                              /*~+:Kanal 1*/
                              /*~I:608*/
#ifdef CHANNEL_1
                              /*~I:609*/
                              if (Parameter[1].nLong == COMMUNICATION_DISABLE_CODE)
                              /*~-1*/
                              {
                              /*~T*/
                              byRetVal = Communication_EnableCommunication(0);
                              /*~I:610*/
                              if (byRetVal == 0)
                              /*~-1*/
                              {
                              /*~A:611*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              lText2Send = TEXT_RS232_COMMUNICATION_DISABLED_CHANNEL_1;
                              /*~E:A611*/
                              /*~-1*/
                              }
                              /*~O:I610*/
                              /*~-2*/
                              else
                              {
                              /*~K*/
                              /*~+:Fehler*/
                              /*~A:612*/
                              /*~+:Textausgabe "E005"*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A612*/
                              /*~-1*/
                              }
                              /*~E:I610*/
                              /*~-1*/
                              }
                              /*~O:I609*/
                              /*~-2*/
                              else
                              {
                              /*~K*/
                              /*~+:Fehler*/
                              /*~A:613*/
                              /*~+:Textausgabe "E005"*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A613*/
                              /*~-1*/
                              }
                              /*~E:I609*/
                              /*~-1*/
#endif
                              /*~E:I608*/
                              /*~E:A607*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F606*/
                              /*~O:C597*/
                              /*~-2*/
                              default:
                              {
                              /*~A:614*/
                              /*~+:Kanal 0*/
                              /*~I:615*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I615*/
                              /*~E:A614*/
                              /*~-1*/
                              }
                           /*~-1*/
                           }
                           /*~E:C597*/
                        /*~-1*/
                        }
                        /*~O:I596*/
                        /*~-2*/
                        else
                        {
                           /*~A:616*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A616*/
                        /*~-1*/
                        }
                        /*~E:I596*/
                     /*~-1*/
                     }
                     /*~E:I595*/
                     /*~E:A594*/
                     /*~T*/
                     break;
                  /*~-1*/
                  }
                  /*~E:F593*/
                  /*~E:A592*/
                  /*~A:617*/
                  /*~+:E*/
                  /*~F:618*/
                  case 'E':
                  /*~-1*/
                  {
                     /*~A:619*/
                     /*~+:ENA - ENAble RS232-Kommunikation*/
                     /*~I:620*/
                     if (!strcmp(szCommand,"ENA"))
                     /*~-1*/
                     {
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:621*/
                        if (!InstructionDecoder_CheckNbParameters(2,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0);
                           Parameter[1].nLong = Communication_GetLongParameter(1);
                           /*~C:622*/
                           switch (Parameter[0].nLong)
                           /*~-1*/
                           {
                              /*~F:623*/
                              case 0:
                              /*~-1*/
                              {
                              /*~A:624*/
                              /*~+:Kanal 0*/
                              /*~I:625*/
#ifdef CHANNEL_0
                              /*~I:626*/
                              if (Parameter[1].nLong == COMMUNICATION_DISABLE_CODE)
                              /*~-1*/
                              {
                              /*~T*/
                              byRetVal = Communication_EnableCommunication(1);
                              /*~I:627*/
                              if (byRetVal == 0)
                              /*~-1*/
                              {
                              /*~A:628*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              lText2Send = TEXT_RS232_COMMUNICATION_ENABLED_CHANNEL_0;
                              /*~E:A628*/
                              /*~-1*/
                              }
                              /*~O:I627*/
                              /*~-2*/
                              else
                              {
                              /*~K*/
                              /*~+:Fehler*/
                              /*~A:629*/
                              /*~+:Textausgabe "E005"*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A629*/
                              /*~-1*/
                              }
                              /*~E:I627*/
                              /*~-1*/
                              }
                              /*~O:I626*/
                              /*~-2*/
                              else
                              {
                              /*~K*/
                              /*~+:Fehler*/
                              /*~A:630*/
                              /*~+:Textausgabe "E005"*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A630*/
                              /*~-1*/
                              }
                              /*~E:I626*/
                              /*~-1*/
#endif
                              /*~E:I625*/
                              /*~E:A624*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F623*/
                              /*~F:631*/
                              case 1:
                              /*~-1*/
                              {
                              /*~A:632*/
                              /*~+:Kanal 1*/
                              /*~I:633*/
#ifdef CHANNEL_1
                              /*~I:634*/
                              if (Parameter[1].nLong == COMMUNICATION_DISABLE_CODE)
                              /*~-1*/
                              {
                              /*~T*/
                              byRetVal = Communication_EnableCommunication(1);
                              /*~I:635*/
                              if (byRetVal == 0)
                              /*~-1*/
                              {
                              /*~A:636*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              lText2Send = TEXT_RS232_COMMUNICATION_ENABLED_CHANNEL_1;
                              /*~E:A636*/
                              /*~-1*/
                              }
                              /*~O:I635*/
                              /*~-2*/
                              else
                              {
                              /*~K*/
                              /*~+:Fehler*/
                              /*~A:637*/
                              /*~+:Textausgabe "E005"*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A637*/
                              /*~-1*/
                              }
                              /*~E:I635*/
                              /*~-1*/
                              }
                              /*~O:I634*/
                              /*~-2*/
                              else
                              {
                              /*~K*/
                              /*~+:Fehler*/
                              /*~A:638*/
                              /*~+:Textausgabe "E005"*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A638*/
                              /*~-1*/
                              }
                              /*~E:I634*/
                              /*~-1*/
#endif
                              /*~E:I633*/
                              /*~E:A632*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F631*/
                              /*~O:C622*/
                              /*~-2*/
                              default:
                              {
                              /*~A:639*/
                              /*~+:Kanal 0*/
                              /*~I:640*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I640*/
                              /*~E:A639*/
                              /*~-1*/
                              }
                           /*~-1*/
                           }
                           /*~E:C622*/
                        /*~-1*/
                        }
                        /*~O:I621*/
                        /*~-2*/
                        else
                        {
                           /*~A:641*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A641*/
                        /*~-1*/
                        }
                        /*~E:I621*/
                     /*~-1*/
                     }
                     /*~E:I620*/
                     /*~E:A619*/
                     /*~T*/
                     break;
                  /*~-1*/
                  }
                  /*~E:F618*/
                  /*~E:A617*/
                  /*~K*/
                  /*~+:/~* Ende - Ge�ndert am 09.02.2022 *~/*/
                  /*~A:642*/
                  /*~+:G*/
                  /*~F:643*/
                  case 'G':
                  /*~-1*/
                  {
                     /*~A:644*/
                     /*~+:GAN - GetArticleNumber*/
                     /*~I:645*/
                     if (!strcmp(szCommand,"GAN"))
                     /*~-1*/
                     {
                        /*~T*/
                        // Text wurde bereits gesendet
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~A:646*/
                        /*~+:Kanal 0*/
                        /*~I:647*/
#ifdef CHANNEL_0
                        /*~I:648*/
                        if (!InstructionDecoder_CheckNbParameters(0,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~I:649*/
                           if (!SYSTEM_MRW_MANAGER)
                           /*~-1*/
                           {
                              /*~T*/
                              Communication_SendString(COMMUNICATION_RS232,T_TEXT_ITEM_NUMBER,1,0);

                           /*~-1*/
                           }
                           /*~E:I649*/
                           /*~T*/
                           Communication_SendString(COMMUNICATION_RS232,System_GetItemNumber(),0,0);
                        /*~-1*/
                        }
                        /*~O:I648*/
                        /*~-2*/
                        else
                        {
                           /*~A:650*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A650*/
                        /*~-1*/
                        }
                        /*~E:I648*/
                        /*~-1*/
#endif
                        /*~E:I647*/
                        /*~E:A646*/
                     /*~-1*/
                     }
                     /*~E:I645*/
                     /*~E:A644*/
                     /*~A:651*/
                     /*~+:GAL - GetAlarmLimit*/
                     /*~I:652*/
                     if (!strcmp(szCommand,"GAL"))
                     /*~-1*/
                     {
                        /*~T*/
                        // Text wurde bereits gesendet
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:653*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0);
                           /*~T*/
                           fTemp = Limit_GetAlarmLimit(1);
                           /*~C:654*/
                           switch (Parameter[0].nLong)
                           /*~-1*/
                           {
                              /*~F:655*/
                              case 0:
                              /*~-1*/
                              {
                              /*~A:656*/
                              /*~+:Kanal 0*/
                              /*~I:657*/
#ifdef CHANNEL_0
                              /*~T*/
                              Communication_SendFloat(COMMUNICATION_RS232,TEXT_ALARM_LIMIT_CHANNEL_0,fTemp,2,1,0);
                              /*~-1*/
#endif
                              /*~E:I657*/
                              /*~E:A656*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F655*/
                              /*~F:658*/
                              case 1:
                              /*~-1*/
                              {
                              /*~A:659*/
                              /*~+:Kanal 1*/
                              /*~I:660*/
#ifdef CHANNEL_1
                              /*~T*/
                              Communication_SendFloat(COMMUNICATION_RS232,TEXT_ALARM_LIMIT_CHANNEL_1,fTemp,2,1,0);
                              /*~-1*/
#endif
                              /*~E:I660*/
                              /*~E:A659*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F658*/
                              /*~O:C654*/
                              /*~-2*/
                              default:
                              {
                              /*~A:661*/
                              /*~+:Fehlerausgabe �ber Kanal 1 - E001*/
                              /*~I:662*/
#ifdef CHANNEL_0
                              /*~T*/
                              // Fehler
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I662*/
                              /*~E:A661*/
                              /*~-1*/
                              }
                           /*~-1*/
                           }
                           /*~E:C654*/
                        /*~-1*/
                        }
                        /*~O:I653*/
                        /*~-2*/
                        else
                        {
                           /*~A:663*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A663*/
                        /*~-1*/
                        }
                        /*~E:I653*/
                     /*~-1*/
                     }
                     /*~E:I652*/
                     /*~E:A651*/
                     /*~A:664*/
                     /*~+:GAP - GetAPplication*/
                     /*~I:665*/
                     if (!strcmp(szCommand,"GAP"))
                     /*~-1*/
                     {
                        /*~T*/
                        // Text wurde bereits gesendet
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~A:666*/
                        /*~+:Kanal 0*/
                        /*~I:667*/
#ifdef CHANNEL_0
                        /*~I:668*/
                        if (!InstructionDecoder_CheckNbParameters(0,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~I:669*/
                           if (!SYSTEM_MRW_MANAGER)
                           /*~-1*/
                           {
                              /*~T*/
                              Communication_SendString(COMMUNICATION_RS232,T_TEXT_APPLICATION,1,0);

                           /*~-1*/
                           }
                           /*~E:I669*/
                           /*~T*/
                           Communication_SendString(COMMUNICATION_RS232,TEXT_APPLICATION_TYPE,0,0);
                        /*~-1*/
                        }
                        /*~O:I668*/
                        /*~-2*/
                        else
                        {
                           /*~A:670*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A670*/
                        /*~-1*/
                        }
                        /*~E:I668*/
                        /*~-1*/
#endif
                        /*~E:I667*/
                        /*~E:A666*/
                     /*~-1*/
                     }
                     /*~E:I665*/
                     /*~E:A664*/
                     /*~A:671*/
                     /*~+:GAT - GetActualTemperature*/
                     /*~I:672*/
                     if (!strcmp(szCommand,"GAT"))
                     /*~-1*/
                     {
                        /*~T*/
                        // Text wurde bereits gesendet
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:673*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0); 
                           /*~C:674*/
                           switch (Parameter[0].nLong)
                           /*~-1*/
                           {
                              /*~F:675*/
                              case 0:
                              /*~-1*/
                              {
                              /*~A:676*/
                              /*~+:Kanal 0*/
                              /*~I:677*/
#ifdef CHANNEL_0
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_ACTUAL_TEMPERATURE_CHANNEL_0,Global.byTemperature,1,0);
                              /*~-1*/
#endif
                              /*~E:I677*/
                              /*~E:A676*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F675*/
                              /*~F:678*/
                              case 1:
                              /*~-1*/
                              {
                              /*~A:679*/
                              /*~+:Kanal 1*/
                              /*~I:680*/
#ifdef CHANNEL_1
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_ACTUAL_TEMPERATURE_CHANNEL_1,Global.byTemperature,1,0);
                              /*~-1*/
#endif
                              /*~E:I680*/
                              /*~E:A679*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F678*/
                              /*~O:C674*/
                              /*~-2*/
                              default:
                              {
                              /*~A:681*/
                              /*~+:Fehlerausgabe �ber Kanal 1 - E001*/
                              /*~I:682*/
#ifdef CHANNEL_0
                              /*~T*/
                              // Fehler
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I682*/
                              /*~E:A681*/
                              /*~-1*/
                              }
                           /*~-1*/
                           }
                           /*~E:C674*/
                        /*~-1*/
                        }
                        /*~O:I673*/
                        /*~-2*/
                        else
                        {
                           /*~A:683*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A683*/
                        /*~-1*/
                        }
                        /*~E:I673*/
                     /*~-1*/
                     }
                     /*~E:I672*/
                     /*~E:A671*/
                     /*~I:684*/
#ifdef SYSTEM_CND_VARIABLE_BAUDRATE
                     /*~A:685*/
                     /*~+:GBR - GetBaudRate*/
                     /*~I:686*/
                     if (!strcmp(szCommand,"GBR"))
                     /*~-1*/
                     {
                        /*~A:687*/
                        /*~+:Variablendeklarationen*/
                        /*~T*/
                        unsigned long ulBaudrate;
                        /*~I:688*/
#ifdef CHANNEL_0
                        /*~T*/
                        unsigned long ulBaudratePartner;

                        /*~-1*/
#endif
                        /*~E:I688*/
                        /*~E:A687*/
                        /*~T*/
                        // Text wurde bereits gesendet
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:689*/
                        if (!InstructionDecoder_CheckNbParameters(0,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Load_Parameter(LOAD_SAVE_RS232_BAUDRATE,&ulBaudrate,4);
                           /*~I:690*/
#ifdef CHANNEL_0
                           /*~I:691*/
                           if (!Communication_GetSPIValue(COMMUNICATION_RS232_BAUDRATE,&ulBaudratePartner))
                           /*~-1*/
                           {
                              /*~I:692*/
                              if (ulBaudratePartner == ulBaudrate)
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_RS232_BAUDRATE,ulBaudrate,1,0);
                              /*~-1*/
                              }
                              /*~O:I692*/
                              /*~-2*/
                              else
                              {
                              /*~A:693*/
                              /*~+:Fehler - Werte beider Kan�le sind nicht identisch - E011*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E011;
                              /*~E:A693*/
                              /*~-1*/
                              }
                              /*~E:I692*/
                           /*~-1*/
                           }
                           /*~O:I691*/
                           /*~-2*/
                           else
                           {
                              /*~A:694*/
                              /*~+:Fehler bei der Kommunikation - E005*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A694*/
                           /*~-1*/
                           }
                           /*~E:I691*/
                           /*~O:I690*/
                           /*~-1*/
#else
                           /*~I:695*/
#ifdef CHANNEL_1
                           /*~T*/
                           InstructionDecoder_StoreValue(COMMUNICATION_RS232_BAUDRATE,(GLOBAL_UNIVALUE_SHORT*)&ulBaudrate);
                           /*~-1*/
#endif
                           /*~E:I695*/
                           /*~-1*/
#endif
                           /*~E:I690*/
                        /*~-1*/
                        }
                        /*~O:I689*/
                        /*~-2*/
                        else
                        {
                           /*~A:696*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A696*/
                        /*~-1*/
                        }
                        /*~E:I689*/
                     /*~-1*/
                     }
                     /*~E:I686*/
                     /*~E:A685*/
                     /*~-1*/
#endif
                     /*~E:I684*/
                     /*~A:697*/
                     /*~+:GCD - GetmaxCurrentDeviation*/
                     /*~I:698*/
                     if (!strcmp(szCommand,"GCD"))
                     /*~-1*/
                     {
                        /*~T*/
                        // Text wurde bereits gesendet
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~A:699*/
                        /*~+:Kanal 0*/
                        /*~I:700*/
#ifdef CHANNEL_0
                        /*~I:701*/
                        if (!InstructionDecoder_CheckNbParameters(0,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Communication_SendFloat(COMMUNICATION_RS232,TEXT_CURRENT_INTERFACE_CURRENT_MAXDEVIATION,g_CurrentInterface.FeedBack.fMaxDeviation,3,1,0);
                        /*~-1*/
                        }
                        /*~O:I701*/
                        /*~-2*/
                        else
                        {
                           /*~A:702*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A702*/
                        /*~-1*/
                        }
                        /*~E:I701*/
                        /*~-1*/
#endif
                        /*~E:I700*/
                        /*~E:A699*/
                     /*~-1*/
                     }
                     /*~E:I698*/
                     /*~E:A697*/
                     /*~A:703*/
                     /*~+:GCF - GetCalibrationFactor*/
                     /*~I:704*/
                     if (!strcmp(szCommand,"GCF"))
                     /*~-1*/
                     {
                        /*~T*/
                        // Text wurde bereits gesendet
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:705*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0); 
                           /*~T*/
                           Measurement_GetCalibrationFactor(WEIGHT_WEIGHTCHANNEL,&fTemp);
                           /*~C:706*/
                           switch (Parameter[0].nLong)
                           /*~-1*/
                           {
                              /*~F:707*/
                              case 0:
                              /*~-1*/
                              {
                              /*~A:708*/
                              /*~+:Kanal 0*/
                              /*~I:709*/
#ifdef CHANNEL_0
                              /*~T*/
                              Communication_SendFloat(COMMUNICATION_RS232,TEXT_MEASUREMENT_ACTUAL_GAIN_CHANNEL_0,fTemp,-1,1,0);
                              /*~-1*/
#endif
                              /*~E:I709*/
                              /*~E:A708*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F707*/
                              /*~F:710*/
                              case 1:
                              /*~-1*/
                              {
                              /*~A:711*/
                              /*~+:Kanal 1*/
                              /*~I:712*/
#ifdef CHANNEL_1
                              /*~T*/
                              Communication_SendFloat(COMMUNICATION_RS232,TEXT_MEASUREMENT_ACTUAL_GAIN_CHANNEL_1,fTemp,-1,1,0);
                              /*~-1*/
#endif
                              /*~E:I712*/
                              /*~E:A711*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F710*/
                              /*~O:C706*/
                              /*~-2*/
                              default:
                              {
                              /*~A:713*/
                              /*~+:Kanal 0*/
                              /*~I:714*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I714*/
                              /*~E:A713*/
                              /*~-1*/
                              }
                           /*~-1*/
                           }
                           /*~E:C706*/
                        /*~-1*/
                        }
                        /*~O:I705*/
                        /*~-2*/
                        else
                        {
                           /*~A:715*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A715*/
                        /*~-1*/
                        }
                        /*~E:I705*/
                     /*~-1*/
                     }
                     /*~E:I704*/
                     /*~E:A703*/
                     /*~I:716*/
#ifdef MOF
                     /*~A:717*/
                     /*~+:GCG - GetCurrentinterfaceGain*/
                     /*~I:718*/
                     if (!strcmp(szCommand,"GCG"))
                     /*~-1*/
                     {
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:719*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0);
                           /*~I:720*/
                           if (Parameter[0].nLong < 2)
                           /*~-1*/
                           {
                              /*~C:721*/
                              switch (Parameter[0].nLong)
                              /*~-1*/
                              {
                              /*~F:722*/
                              case 0:
                              /*~-1*/
                              {
                              /*~A:723*/
                              /*~+:Kanal 0*/
                              /*~I:724*/
#ifdef CHANNEL_0
                              /*~T*/
                              Communication_SendFloat(COMMUNICATION_RS232,TEXT_CURRENT_INTERFACE_GAIN_NORM_CHANNEL_0,ADuC836_DACGetGain(0) * ADuC836_DACGetGain(1),-1,1,0);
                              /*~-1*/
#endif
                              /*~E:I724*/
                              /*~E:A723*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F722*/
                              /*~F:725*/
                              case 1:
                              /*~-1*/
                              {
                              /*~A:726*/
                              /*~+:Kanal 1*/
                              /*~I:727*/
#ifdef CHANNEL_1
                              /*~T*/
                              Communication_SendFloat(COMMUNICATION_RS232,TEXT_CURRENT_INTERFACE_GAIN_NORM_CHANNEL_1,ADuC836_DACGetGain(0) * ADuC836_DACGetGain(1),-1,1,0);
                              /*~-1*/
#endif
                              /*~E:I727*/
                              /*~E:A726*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F725*/
                              /*~O:C721*/
                              /*~-2*/
                              default:
                              {
                              /*~A:728*/
                              /*~+:Kanal 0*/
                              /*~I:729*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I729*/
                              /*~E:A728*/
                              /*~-1*/
                              }
                              /*~-1*/
                              }
                              /*~E:C721*/
                           /*~-1*/
                           }
                           /*~O:I720*/
                           /*~-2*/
                           else
                           {
                              /*~A:730*/
                              /*~+:Kanal 0*/
                              /*~I:731*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E002;
                              /*~-1*/
#endif
                              /*~E:I731*/
                              /*~E:A730*/
                           /*~-1*/
                           }
                           /*~E:I720*/
                        /*~-1*/
                        }
                        /*~O:I719*/
                        /*~-2*/
                        else
                        {
                           /*~A:732*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A732*/
                        /*~-1*/
                        }
                        /*~E:I719*/
                     /*~-1*/
                     }
                     /*~E:I718*/
                     /*~E:A717*/
                     /*~-1*/
#endif
                     /*~E:I716*/
                     /*~A:733*/
                     /*~+:GCL - GetCheckLimits*/
                     /*~I:734*/
                     if (!strcmp(szCommand,"GCL"))
                     /*~-1*/
                     {
                        /*~A:735*/
                        /*~+:Variablendeklarationen*/
                        /*~T*/
                        float fMaxDeviation;
                        float fMaxDrift;
                        /*~I:736*/
#ifdef CHANNEL_0
                        /*~T*/
                        float fLimitPartner;

                        /*~-1*/
#endif
                        /*~E:I736*/
                        /*~E:A735*/
                        /*~A:737*/
                        /*~+:Variableninitialisierungen*/
                        /*~T*/

                        /*~E:A737*/
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:738*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0);
                           /*~T*/
                           MRW_Compensation_GetCheckLimits(&fMaxDeviation,&fMaxDrift);
                           /*~C:739*/
                           switch (Parameter[0].nLong)
                           /*~-1*/
                           {
                              /*~F:740*/
                              case 0:		// Nullpunkt�berwachung
                              /*~-1*/
                              {
                              /*~I:741*/
#ifdef CHANNEL_0
                              /*~I:742*/
                              if (!Communication_GetSPIValue(COMMUNICATION_CHECKLIMIT_ZEROPOINTCHECK,&fLimitPartner))
                              /*~-1*/
                              {
                              /*~I:743*/
                              if (fLimitPartner == g_Limit.fLimitZeroPointCheck)
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendFloat(COMMUNICATION_RS232,TEXT_LIMIT_ZEROCHECK,g_Limit.fLimitZeroPointCheck,2,1,0);
                              /*~-1*/
                              }
                              /*~O:I743*/
                              /*~-2*/
                              else
                              {
                              /*~A:744*/
                              /*~+:Fehler - Werte beider Kan�le sind nicht identisch - E011*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E011;
                              /*~E:A744*/
                              /*~-1*/
                              }
                              /*~E:I743*/
                              /*~-1*/
                              }
                              /*~O:I742*/
                              /*~-2*/
                              else
                              {
                              /*~A:745*/
                              /*~+:Fehler bei der Kommunikation - E005*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A745*/
                              /*~-1*/
                              }
                              /*~E:I742*/
                              /*~O:I741*/
                              /*~-1*/
#else
                              /*~I:746*/
#ifdef CHANNEL_1 
                              /*~T*/
                              InstructionDecoder_StoreValue(COMMUNICATION_CHECKLIMIT_ZEROPOINTCHECK,(GLOBAL_UNIVALUE_SHORT*)&g_Limit.fLimitZeroPointCheck);
                              /*~-1*/
#endif
                              /*~E:I746*/
                              /*~-1*/
#endif
                              /*~E:I741*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F740*/
                              /*~F:747*/
                              case 1:
                              /*~-1*/
                              {
                              /*~I:748*/
#ifdef CHANNEL_0
                              /*~I:749*/
                              if (!Communication_GetSPIValue(COMMUNICATION_CHECKLIMIT_MAX_DEVIATION,&fLimitPartner))
                              /*~-1*/
                              {
                              /*~I:750*/
                              if (fLimitPartner == fMaxDeviation)
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendFloat(COMMUNICATION_RS232,TEXT_LIMIT_MAX_DEVIATION,fMaxDeviation,2,1,0);
                              /*~-1*/
                              }
                              /*~O:I750*/
                              /*~-2*/
                              else
                              {
                              /*~A:751*/
                              /*~+:Fehler - Werte beider Kan�le sind nicht identisch - E011*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E011;
                              /*~E:A751*/
                              /*~-1*/
                              }
                              /*~E:I750*/
                              /*~-1*/
                              }
                              /*~O:I749*/
                              /*~-2*/
                              else
                              {
                              /*~A:752*/
                              /*~+:Fehler bei der Kommunikation - E005*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A752*/
                              /*~-1*/
                              }
                              /*~E:I749*/
                              /*~O:I748*/
                              /*~-1*/
#else
                              /*~I:753*/
#ifdef CHANNEL_1 
                              /*~T*/
                              InstructionDecoder_StoreValue(COMMUNICATION_CHECKLIMIT_MAX_DEVIATION,(GLOBAL_UNIVALUE_SHORT*)&fMaxDeviation);
                              /*~-1*/
#endif
                              /*~E:I753*/
                              /*~-1*/
#endif
                              /*~E:I748*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F747*/
                              /*~F:754*/
                              case 2:
                              /*~-1*/
                              {
                              /*~I:755*/
#ifdef CHANNEL_0
                              /*~I:756*/
                              if (!Communication_GetSPIValue(COMMUNICATION_CHECKLIMIT_MAX_DRIFT,&fLimitPartner))
                              /*~-1*/
                              {
                              /*~I:757*/
                              if (fLimitPartner == fMaxDrift)
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendFloat(COMMUNICATION_RS232,TEXT_LIMIT_MAX_DRIFT,fMaxDrift,2,1,0);
                              /*~-1*/
                              }
                              /*~O:I757*/
                              /*~-2*/
                              else
                              {
                              /*~A:758*/
                              /*~+:Fehler - Werte beider Kan�le sind nicht identisch - E011*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E011;
                              /*~E:A758*/
                              /*~-1*/
                              }
                              /*~E:I757*/
                              /*~-1*/
                              }
                              /*~O:I756*/
                              /*~-2*/
                              else
                              {
                              /*~A:759*/
                              /*~+:Fehler bei der Kommunikation - E005*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A759*/
                              /*~-1*/
                              }
                              /*~E:I756*/
                              /*~O:I755*/
                              /*~-1*/
#else
                              /*~I:760*/
#ifdef CHANNEL_1 
                              /*~T*/
                              InstructionDecoder_StoreValue(COMMUNICATION_CHECKLIMIT_MAX_DRIFT,(GLOBAL_UNIVALUE_SHORT*)&fMaxDrift);
                              /*~-1*/
#endif
                              /*~E:I760*/
                              /*~-1*/
#endif
                              /*~E:I755*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F754*/
                              /*~O:C739*/
                              /*~-2*/
                              default:
                              {
                              /*~A:761*/
                              /*~+:Kanal 0*/
                              /*~I:762*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E002;
                              /*~-1*/
#endif
                              /*~E:I762*/
                              /*~E:A761*/
                              /*~-1*/
                              }
                           /*~-1*/
                           }
                           /*~E:C739*/
                        /*~-1*/
                        }
                        /*~O:I738*/
                        /*~-2*/
                        else
                        {
                           /*~A:763*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A763*/
                        /*~-1*/
                        }
                        /*~E:I738*/
                     /*~-1*/
                     }
                     /*~E:I734*/
                     /*~E:A733*/
                     /*~I:764*/
#ifdef MOF
                     /*~A:765*/
                     /*~+:GCO - GetCurrentinterfaceOffset*/
                     /*~I:766*/
                     if (!strcmp(szCommand,"GCO"))
                     /*~-1*/
                     {
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:767*/
                        if (!InstructionDecoder_CheckNbParameters(2,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0);
                           Parameter[1].nLong = Communication_GetLongParameter(1);
                           /*~I:768*/
                           if (Parameter[1].nLong < 2)
                           /*~-1*/
                           {
                              /*~C:769*/
                              switch (Parameter[0].nLong)
                              /*~-1*/
                              {
                              /*~F:770*/
                              case 0:
                              /*~-1*/
                              {
                              /*~A:771*/
                              /*~+:Kanal 0*/
                              /*~I:772*/
#ifdef CHANNEL_0
                              /*~I:773*/
                              if (Parameter[1].nLong)
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_CURRENT_INTERFACE_OFFSET_NORM_CHANNEL_0,ADuC836_DACGetOffset(1),1,0);
                              /*~-1*/
                              }
                              /*~O:I773*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_CURRENT_INTERFACE_OFFSET_RMW_CHANNEL_0,ADuC836_DACGetOffset(0),1,0);
                              /*~-1*/
                              }
                              /*~E:I773*/
                              /*~-1*/
#endif
                              /*~E:I772*/
                              /*~E:A771*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F770*/
                              /*~F:774*/
                              case 1:
                              /*~-1*/
                              {
                              /*~A:775*/
                              /*~+:Kanal 1*/
                              /*~I:776*/
#ifdef CHANNEL_1
                              /*~I:777*/
                              if (Parameter[1].nLong)
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_CURRENT_INTERFACE_OFFSET_NORM_CHANNEL_1,ADuC836_DACGetOffset(1),1,0);
                              /*~-1*/
                              }
                              /*~O:I777*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_CURRENT_INTERFACE_OFFSET_RMW_CHANNEL_1,ADuC836_DACGetOffset(0),1,0);
                              /*~-1*/
                              }
                              /*~E:I777*/
                              /*~-1*/
#endif
                              /*~E:I776*/
                              /*~E:A775*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F774*/
                              /*~O:C769*/
                              /*~-2*/
                              default:
                              {
                              /*~A:778*/
                              /*~+:Kanal 0*/
                              /*~I:779*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I779*/
                              /*~E:A778*/
                              /*~-1*/
                              }
                              /*~-1*/
                              }
                              /*~E:C769*/
                           /*~-1*/
                           }
                           /*~O:I768*/
                           /*~-2*/
                           else
                           {
                              /*~A:780*/
                              /*~+:Kanal 0*/
                              /*~I:781*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E002;
                              /*~-1*/
#endif
                              /*~E:I781*/
                              /*~E:A780*/
                           /*~-1*/
                           }
                           /*~E:I768*/
                        /*~-1*/
                        }
                        /*~O:I767*/
                        /*~-2*/
                        else
                        {
                           /*~A:782*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A782*/
                        /*~-1*/
                        }
                        /*~E:I767*/
                     /*~-1*/
                     }
                     /*~E:I766*/
                     /*~E:A765*/
                     /*~-1*/
#endif
                     /*~E:I764*/
                     /*~I:783*/
#ifdef SYSTEM_CND_ADC_MIT_WANDLERRATENERMITTLUNG
                     /*~A:784*/
                     /*~+:GCR - GetConvertionRate*/
                     /*~+:GCT - GetConversionTime*/
                     /*~I:785*/
                     if (!strcmp(szCommand,"GCT")||!strcmp(szCommand,"GCR"))
                     /*~-1*/
                     {
                        /*~T*/
                        unsigned char byTimeMode;
                        /*~I:786*/
                        if (!strcmp(szCommand,"GCT"))
                        /*~-1*/
                        {
                           /*~T*/
                           byTimeMode = 1;
                        /*~-1*/
                        }
                        /*~O:I786*/
                        /*~-2*/
                        else
                        {
                           /*~T*/
                           byTimeMode = 0;
                        /*~-1*/
                        }
                        /*~E:I786*/
                        /*~T*/
                        // Text wurde bereits gesendet
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:787*/
#ifndef MOF
                        /*~I:788*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0); 
                           /*~C:789*/
                           switch (Parameter[0].nLong)
                           /*~-1*/
                           {
                              /*~F:790*/
                              case 0:
                              /*~-1*/
                              {
                              /*~A:791*/
                              /*~+:Kanal 0*/
                              /*~I:792*/
#ifdef CHANNEL_0
                              /*~T*/
                              unsigned int uConversionTime = ADuC836_ADCGetConversionTime(Parameter[1].nLong);
                              /*~I:793*/
                              if (byTimeMode)
                              /*~-1*/
                              {
                              /*~A:794*/
                              /*~+:Zeitintervall bis zur Wandlung des Gewichts*/
                              /*~T*/
                              // Zeitintervall bis zur Wandlung des Gewichts
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_WEIGHT_CONVERSIONTIME_CHANNEL_0,uConversionTime,1,0);
                              /*~E:A794*/
                              /*~-1*/
                              }
                              /*~O:I793*/
                              /*~-2*/
                              else
                              {
                              /*~A:795*/
                              /*~+:Frequenz der Wandlung des Gewichts*/
                              /*~T*/
                              // Frequenz der Wandlung des Gewichts
                              /*~T*/
                              Communication_SendFloat(COMMUNICATION_RS232,TEXT_WEIGHT_CONVERSIONRATE_CHANNEL_0,1/((float)uConversionTime/1000),2,1,0);
                              /*~E:A795*/
                              /*~-1*/
                              }
                              /*~E:I793*/
                              /*~-1*/
#endif
                              /*~E:I792*/
                              /*~E:A791*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F790*/
                              /*~F:796*/
                              case 1:
                              /*~-1*/
                              {
                              /*~A:797*/
                              /*~+:Kanal 1*/
                              /*~I:798*/
#ifdef CHANNEL_1
                              /*~T*/
                              unsigned int uConversionTime = ADuC836_ADCGetConversionTime(Parameter[1].nLong);
                              /*~I:799*/
                              if (byTimeMode)
                              /*~-1*/
                              {
                              /*~A:800*/
                              /*~+:Zeitintervall bis zur Wandlung des Gewichts*/
                              /*~T*/
                              // Zeitintervall bis zur Wandlung des Gewichts
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_WEIGHT_CONVERSIONTIME_CHANNEL_1,uConversionTime,1,0);
                              /*~E:A800*/
                              /*~-1*/
                              }
                              /*~O:I799*/
                              /*~-2*/
                              else
                              {
                              /*~A:801*/
                              /*~+:Frequenz der Wandlung des Gewichts*/
                              /*~T*/
                              // Frequenz der Wandlung des Gewichts
                              /*~T*/
                              Communication_SendFloat(COMMUNICATION_RS232,TEXT_WEIGHT_CONVERSIONRATE_CHANNEL_1,1/((float)uConversionTime/1000),2,1,0);
                              /*~E:A801*/
                              /*~-1*/
                              }
                              /*~E:I799*/
                              /*~-1*/
#endif
                              /*~E:I798*/
                              /*~E:A797*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F796*/
                              /*~O:C789*/
                              /*~-2*/
                              default:
                              {
                              /*~A:802*/
                              /*~+:Kanal 0*/
                              /*~I:803*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I803*/
                              /*~E:A802*/
                              /*~-1*/
                              }
                           /*~-1*/
                           }
                           /*~E:C789*/
                        /*~-1*/
                        }
                        /*~O:I788*/
                        /*~-2*/
                        else
                        {
                           /*~A:804*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A804*/
                        /*~-1*/
                        }
                        /*~E:I788*/
                        /*~O:I787*/
                        /*~-1*/
#else
                        /*~A:805*/
                        /*~+:f�r sp�tere Verwendung*/
                        /*~I:806*/
                        if (!InstructionDecoder_CheckNbParameters(2,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0);
                           Parameter[1].nLong = Communication_GetLongParameter(1); 
                           /*~I:807*/
#ifndef OHNE_STROMRUECKFUEHRUNG
                           if (Parameter[1].nLong < 4)
#else
                           if ((Parameter[1].nLong < 4)&&(Parameter[1].nLong != 2))
#endif
                           /*~-1*/
                           {
                              /*~C:808*/
                              switch (Parameter[0].nLong)
                              /*~-1*/
                              {
                              /*~F:809*/
                              case 0:
                              /*~-1*/
                              {
                              /*~A:810*/
                              /*~+:Kanal 0*/
                              /*~I:811*/
#ifdef CHANNEL_0
                              /*~T*/
                              unsigned int uConversionTime = ADuC836_ADCGetConversionTime(Parameter[1].nLong);
                              /*~C:812*/
                              switch (Parameter[1].nLong)
                              /*~-1*/
                              {
                              /*~F:813*/
                              case 0:
                              /*~-1*/
                              {
                              /*~I:814*/
                              if (byTimeMode)
                              /*~-1*/
                              {
                              /*~A:815*/
                              /*~+:Zeitintervall bis zur Wandlung des Gewichts*/
                              /*~T*/
                              // Zeitintervall bis zur Wandlung des Gewichts
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_WEIGHT_CONVERSIONTIME_CHANNEL_0,uConversionTime,1,0);
                              /*~E:A815*/
                              /*~-1*/
                              }
                              /*~O:I814*/
                              /*~-2*/
                              else
                              {
                              /*~A:816*/
                              /*~+:Frequenz der Wandlung des Gewichts*/
                              /*~T*/
                              // Frequenz der Wandlung des Gewichts
                              /*~T*/
                              Communication_SendFloat(COMMUNICATION_RS232,TEXT_WEIGHT_CONVERSIONRATE_CHANNEL_0,1/((float)uConversionTime/1000),2,1,0);
                              /*~E:A816*/
                              /*~-1*/
                              }
                              /*~E:I814*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F813*/
                              /*~F:817*/
                              case 1:
                              /*~-1*/
                              {
                              /*~I:818*/
                              if (byTimeMode)
                              /*~-1*/
                              {
                              /*~A:819*/
                              /*~+:Zeitintervall bis zur Wandlung der Temperatur*/
                              /*~T*/
                              // Zeitintervall bis zur Wandlung der Temperatur
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_TEMPERATURE_CONVERSIONTIME_CHANNEL_0,uConversionTime,1,0);
                              /*~E:A819*/
                              /*~-1*/
                              }
                              /*~O:I818*/
                              /*~-2*/
                              else
                              {
                              /*~A:820*/
                              /*~+:Frequenz der Wandlung der Temperatur*/
                              /*~T*/
                              // Frequenz der Wandlung der Temperatur
                              /*~T*/
                              Communication_SendFloat(COMMUNICATION_RS232,TEXT_TEMPERATURE_CONVERSIONRATE_CHANNEL_0,1/((float)uConversionTime/1000),2,1,0);
                              /*~E:A820*/
                              /*~-1*/
                              }
                              /*~E:I818*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F817*/
                              /*~F:821*/
                              case 2:
                              /*~-1*/
                              {
                              /*~I:822*/
                              if (byTimeMode)
                              /*~-1*/
                              {
                              /*~A:823*/
                              /*~+:Zeitintervall bis zur Wandlung des Ausgangsstroms*/
                              /*~T*/
                              // Zeitintervall bis zur Wandlung des Ausgangsstroms
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_FEEDBACK_CONVERSIONTIME_CHANNEL_0,uConversionTime,1,0);
                              /*~E:A823*/
                              /*~-1*/
                              }
                              /*~O:I822*/
                              /*~-2*/
                              else
                              {
                              /*~A:824*/
                              /*~+:Frequenz der Wandlung des Ausgangsstroms*/
                              /*~T*/
                              // Frequenz der Wandlung des Ausgangsstroms
                              /*~T*/
                              Communication_SendFloat(COMMUNICATION_RS232,TEXT_FEEDBACK_CONVERSIONRATE_CHANNEL_0,1/((float)uConversionTime/1000),2,1,0);
                              /*~E:A824*/
                              /*~-1*/
                              }
                              /*~E:I822*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F821*/
                              /*~F:825*/
                              case 3:
                              /*~-1*/
                              {
                              /*~I:826*/
                              if (byTimeMode)
                              /*~-1*/
                              {
                              /*~A:827*/
                              /*~+:Zeitintervall bis zur Wandlung der Netzteilspannung*/
                              /*~T*/
                              // Zeitintervall bis zur Wandlung der Netzteilspannung
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_SUPPLY_CONVERSIONTIME_CHANNEL_0,uConversionTime,1,0);
                              /*~E:A827*/
                              /*~-1*/
                              }
                              /*~O:I826*/
                              /*~-2*/
                              else
                              {
                              /*~A:828*/
                              /*~+:Frequenz der Wandlung der Netzteilspannung*/
                              /*~T*/
                              // Frequenz der Wandlung der Netzteilspannung
                              /*~T*/
                              Communication_SendFloat(COMMUNICATION_RS232,TEXT_SUPPLY_CONVERSIONRATE_CHANNEL_0,1/((float)uConversionTime/1000),2,1,0);
                              /*~E:A828*/
                              /*~-1*/
                              }
                              /*~E:I826*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F825*/
                              /*~-1*/
                              }
                              /*~E:C812*/
                              /*~-1*/
#endif
                              /*~E:I811*/
                              /*~E:A810*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F809*/
                              /*~F:829*/
                              case 1:
                              /*~-1*/
                              {
                              /*~A:830*/
                              /*~+:Kanal 1*/
                              /*~I:831*/
#ifdef CHANNEL_1
                              /*~T*/
                              unsigned int uConversionTime = ADuC836_ADCGetConversionTime(Parameter[1].nLong);
                              /*~C:832*/
                              switch (Parameter[1].nLong)
                              /*~-1*/
                              {
                              /*~F:833*/
                              case 0:
                              /*~-1*/
                              {
                              /*~I:834*/
                              if (byTimeMode)
                              /*~-1*/
                              {
                              /*~A:835*/
                              /*~+:Zeitintervall bis zur Wandlung des Gewichts*/
                              /*~T*/
                              // Zeitintervall bis zur Wandlung des Gewichts
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_WEIGHT_CONVERSIONTIME_CHANNEL_1,uConversionTime,1,0);
                              /*~E:A835*/
                              /*~-1*/
                              }
                              /*~O:I834*/
                              /*~-2*/
                              else
                              {
                              /*~A:836*/
                              /*~+:Frequenz der Wandlung des Gewichts*/
                              /*~T*/
                              // Frequenz der Wandlung des Gewichts
                              /*~T*/
                              Communication_SendFloat(COMMUNICATION_RS232,TEXT_WEIGHT_CONVERSIONRATE_CHANNEL_1,1/((float)uConversionTime/1000),2,1,0);
                              /*~E:A836*/
                              /*~-1*/
                              }
                              /*~E:I834*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F833*/
                              /*~F:837*/
                              case 1:
                              /*~-1*/
                              {
                              /*~I:838*/
                              if (byTimeMode)
                              /*~-1*/
                              {
                              /*~A:839*/
                              /*~+:Zeitintervall bis zur Wandlung der Temperatur*/
                              /*~T*/
                              // Zeitintervall bis zur Wandlung der Temperatur
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_TEMPERATURE_CONVERSIONTIME_CHANNEL_1,uConversionTime,1,0);
                              /*~E:A839*/
                              /*~-1*/
                              }
                              /*~O:I838*/
                              /*~-2*/
                              else
                              {
                              /*~A:840*/
                              /*~+:Frequenz der Wandlung der Temperatur*/
                              /*~T*/
                              // Frequenz der Wandlung der Temperatur
                              /*~T*/
                              Communication_SendFloat(COMMUNICATION_RS232,TEXT_TEMPERATURE_CONVERSIONRATE_CHANNEL_1,1/((float)uConversionTime/1000),2,1,0);
                              /*~E:A840*/
                              /*~-1*/
                              }
                              /*~E:I838*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F837*/
                              /*~F:841*/
                              case 2:
                              /*~-1*/
                              {
                              /*~I:842*/
                              if (byTimeMode)
                              /*~-1*/
                              {
                              /*~A:843*/
                              /*~+:Zeitintervall bis zur Wandlung des Ausgangsstroms*/
                              /*~T*/
                              // Zeitintervall bis zur Wandlung des Ausgangsstroms
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_FEEDBACK_CONVERSIONTIME_CHANNEL_1,uConversionTime,1,0);
                              /*~E:A843*/
                              /*~-1*/
                              }
                              /*~O:I842*/
                              /*~-2*/
                              else
                              {
                              /*~A:844*/
                              /*~+:Frequenz der Wandlung des Ausgangsstroms*/
                              /*~T*/
                              // Frequenz der Wandlung des Ausgangsstroms
                              /*~T*/
                              Communication_SendFloat(COMMUNICATION_RS232,TEXT_FEEDBACK_CONVERSIONRATE_CHANNEL_1,1/((float)uConversionTime/1000),2,1,0);
                              /*~E:A844*/
                              /*~-1*/
                              }
                              /*~E:I842*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F841*/
                              /*~F:845*/
                              case 3:
                              /*~-1*/
                              {
                              /*~I:846*/
                              if (byTimeMode)
                              /*~-1*/
                              {
                              /*~A:847*/
                              /*~+:Zeitintervall bis zur Wandlung der Netzteilspannung*/
                              /*~T*/
                              // Zeitintervall bis zur Wandlung der Netzteilspannung
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_SUPPLY_CONVERSIONTIME_CHANNEL_1,uConversionTime,1,0);
                              /*~E:A847*/
                              /*~-1*/
                              }
                              /*~O:I846*/
                              /*~-2*/
                              else
                              {
                              /*~A:848*/
                              /*~+:Frequenz der Wandlung der Netzteilspannung*/
                              /*~T*/
                              // Frequenz der Wandlung der Netzteilspannung
                              /*~T*/
                              Communication_SendFloat(COMMUNICATION_RS232,TEXT_SUPPLY_CONVERSIONRATE_CHANNEL_1,1/((float)uConversionTime/1000),2,1,0);
                              /*~E:A848*/
                              /*~-1*/
                              }
                              /*~E:I846*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F845*/
                              /*~-1*/
                              }
                              /*~E:C832*/
                              /*~-1*/
#endif
                              /*~E:I831*/
                              /*~E:A830*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F829*/
                              /*~O:C808*/
                              /*~-2*/
                              default:
                              {
                              /*~A:849*/
                              /*~+:Kanal 0*/
                              /*~I:850*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I850*/
                              /*~E:A849*/
                              /*~-1*/
                              }
                              /*~-1*/
                              }
                              /*~E:C808*/
                           /*~-1*/
                           }
                           /*~O:I807*/
                           /*~-2*/
                           else
                           {
                              /*~A:851*/
                              /*~+:Kanal 0*/
                              /*~I:852*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E002;
                              /*~-1*/
#endif
                              /*~E:I852*/
                              /*~E:A851*/
                           /*~-1*/
                           }
                           /*~E:I807*/
                        /*~-1*/
                        }
                        /*~O:I806*/
                        /*~-2*/
                        else
                        {
                           /*~A:853*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A853*/
                        /*~-1*/
                        }
                        /*~E:I806*/
                        /*~E:A805*/
                        /*~-1*/
#endif
                        /*~E:I787*/
                     /*~-1*/
                     }
                     /*~E:I785*/
                     /*~E:A784*/
                     /*~O:I783*/
                     /*~-1*/
#else
                     /*~A:854*/
                     /*~+:GCR - GetConvertionRate*/
                     /*~I:855*/
                     if (!strcmp(szCommand,"GCR"))
                     /*~-1*/
                     {
                        /*~T*/
                        // Text wurde bereits gesendet
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:856*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0); 
                           /*~C:857*/
                           switch (Parameter[0].nLong)
                           /*~-1*/
                           {
                              /*~F:858*/
                              case 0:
                              /*~-1*/
                              {
                              /*~A:859*/
                              /*~+:Kanal 0*/
                              /*~I:860*/
#ifdef CHANNEL_0
                              /*~A:861*/
                              /*~+:Zeitintervall bis zur Wandlung des Gewichts*/
                              /*~T*/
                              // Frequenz der Wandlung des Gewichts
                              /*~T*/
                              Communication_SendFloat(COMMUNICATION_RS232,TEXT_WEIGHT_CONVERSIONRATE_CHANNEL_0,ADuC836_ADCGetConversionRate(ADuC836_ADC_FREQUENCY_32KHZ),2,1,0);
                              /*~E:A861*/
                              /*~-1*/
#endif
                              /*~E:I860*/
                              /*~E:A859*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F858*/
                              /*~F:862*/
                              case 1:
                              /*~-1*/
                              {
                              /*~A:863*/
                              /*~+:Kanal 1*/
                              /*~I:864*/
#ifdef CHANNEL_1
                              /*~A:865*/
                              /*~+:Zeitintervall bis zur Wandlung des Gewichts*/
                              /*~T*/
                              // Frequenz der Wandlung des Gewichts
                              /*~T*/
                              Communication_SendFloat(COMMUNICATION_RS232,TEXT_WEIGHT_CONVERSIONRATE_CHANNEL_1,ADuC836_ADCGetConversionRate(ADuC836_ADC_FREQUENCY_32KHZ),2,1,0);
                              /*~E:A865*/
                              /*~-1*/
#endif
                              /*~E:I864*/
                              /*~E:A863*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F862*/
                              /*~O:C857*/
                              /*~-2*/
                              default:
                              {
                              /*~A:866*/
                              /*~+:Kanal 0*/
                              /*~I:867*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I867*/
                              /*~E:A866*/
                              /*~-1*/
                              }
                           /*~-1*/
                           }
                           /*~E:C857*/
                        /*~-1*/
                        }
                        /*~O:I856*/
                        /*~-2*/
                        else
                        {
                           /*~A:868*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A868*/
                        /*~-1*/
                        }
                        /*~E:I856*/
                     /*~-1*/
                     }
                     /*~E:I855*/
                     /*~E:A854*/
                     /*~-1*/
#endif
                     /*~E:I783*/
                     /*~A:869*/
                     /*~+:GCS - GetCompensationState*/
                     /*~I:870*/
                     if (!strcmp(szCommand,"GCS"))
                     /*~-1*/
                     {
                        /*~A:871*/
                        /*~+:Variablendeklarationen*/
                        /*~I:872*/
#ifdef CHANNEL_0
                        /*~T*/
                        long lTempCompPartnerOn;

                        /*~-1*/
#endif
                        /*~E:I872*/
                        /*~E:A871*/
                        /*~T*/
                        // Text wurde bereits gesendet
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:873*/
                        if (!InstructionDecoder_CheckNbParameters(0,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           byTemp = MRW_Compensation_GetCompensationOnOffStatus();
                           /*~I:874*/
#ifdef CHANNEL_0
                           /*~I:875*/
                           if (!Communication_GetSPIValue(COMMUNICATION_COMPENSATION_STATE,&lTempCompPartnerOn))
                           /*~-1*/
                           {
                              /*~I:876*/
                              if ((char)lTempCompPartnerOn == byTemp)
                              /*~-1*/
                              {
                              /*~I:877*/
                              if (!SYSTEM_MRW_MANAGER)
                              /*~-1*/
                              {
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              /*~I:878*/
                              if (byTemp)
                              /*~-1*/
                              {
                              /*~T*/
                              lText2Send = TEXT_COMPENSATION_SWITCHED_ON;
                              /*~-1*/
                              }
                              /*~O:I878*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              lText2Send = TEXT_COMPENSATION_SWITCHED_OFF;
                              /*~-1*/
                              }
                              /*~E:I878*/
                              /*~-1*/
                              }
                              /*~O:I877*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,0,byTemp,1,0);
                              /*~-1*/
                              }
                              /*~E:I877*/
                              /*~-1*/
                              }
                              /*~O:I876*/
                              /*~-2*/
                              else
                              {
                              /*~A:879*/
                              /*~+:Fehler - Werte beider Kan�le sind nicht identisch - E011*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E011;
                              /*~E:A879*/
                              /*~-1*/
                              }
                              /*~E:I876*/
                           /*~-1*/
                           }
                           /*~O:I875*/
                           /*~-2*/
                           else
                           {
                              /*~A:880*/
                              /*~+:Fehler bei der Kommunikation - E005*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A880*/
                           /*~-1*/
                           }
                           /*~E:I875*/
                           /*~O:I874*/
                           /*~-1*/
#else
                           /*~I:881*/
#ifdef CHANNEL_1
                           /*~T*/
                           InstructionDecoder_StoreValue(COMMUNICATION_COMPENSATION_STATE,(GLOBAL_UNIVALUE_SHORT*)&byTemp);
                           /*~-1*/
#endif
                           /*~E:I881*/
                           /*~-1*/
#endif
                           /*~E:I874*/
                        /*~-1*/
                        }
                        /*~O:I873*/
                        /*~-2*/
                        else
                        {
                           /*~A:882*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A882*/
                        /*~-1*/
                        }
                        /*~E:I873*/
                     /*~-1*/
                     }
                     /*~E:I870*/
                     /*~E:A869*/
                     /*~A:883*/
                     /*~+:GCU - GetCUrrent*/
                     /*~I:884*/
                     if (!strcmp(szCommand,"GCU"))
                     /*~-1*/
                     {
                        /*~T*/
                        // Text wurde bereits gesendet
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:885*/
                        if (!InstructionDecoder_CheckNbParameters(2,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0);
                           Parameter[1].nLong = Communication_GetLongParameter(1);
                           /*~T*/
                           fTemp = CurrentInterface_GetCurrent((unsigned char)Parameter[1].nLong);
                           /*~C:886*/
                           switch (Parameter[0].nLong)
                           /*~-1*/
                           {
                              /*~F:887*/
                              case 0:
                              /*~-1*/
                              {
                              /*~A:888*/
                              /*~+:Kanal 0*/
                              /*~I:889*/
#ifdef CHANNEL_0
                              /*~I:890*/
#ifndef OHNE_STROMRUECKFUEHRUNG
                              /*~C:891*/
                              switch (Parameter[1].nLong)
                              /*~-1*/
                              {
                              /*~F:892*/
                              case 0:
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendFloat(COMMUNICATION_RS232,TEXT_CURRENT_INTERFACE_ACTUAL_CURRENT_CHANNEL_0,fTemp,3,1,0);
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F892*/
                              /*~F:893*/
                              case 1:
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendFloat(COMMUNICATION_RS232,TEXT_CURRENT_INTERFACE_ACTUAL_CURRENT_MEASURED_CHANNEL_0,fTemp,3,1,0);
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F893*/
                              /*~O:C891*/
                              /*~-2*/
                              default:
                              {
                              /*~T*/
                              Communication_SendFloat(COMMUNICATION_RS232,TEXT_CURRENT_INTERFACE_ACTUAL_DEVIATION_CHANNEL_0,g_CurrentInterface.FeedBack.Results.Deviation.fFloat,5,1,0);
                              /*~-1*/
                              }
                              /*~-1*/
                              }
                              /*~E:C891*/
                              /*~O:I890*/
                              /*~-1*/
#else
                              /*~T*/
                              Communication_SendFloat(COMMUNICATION_RS232,TEXT_CURRENT_INTERFACE_ACTUAL_CURRENT_CHANNEL_0,fTemp,3,1,0);
                              /*~-1*/
#endif
                              /*~E:I890*/
                              /*~-1*/
#endif
                              /*~E:I889*/
                              /*~E:A888*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F887*/
                              /*~F:894*/
                              case 1:
                              /*~-1*/
                              {
                              /*~A:895*/
                              /*~+:Kanal 1*/
                              /*~I:896*/
#ifdef CHANNEL_1
                              /*~I:897*/
#ifndef OHNE_STROMRUECKFUEHRUNG 
                              /*~C:898*/
                              switch (Parameter[1].nLong)
                              /*~-1*/
                              {
                              /*~F:899*/
                              case 0:
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendFloat(COMMUNICATION_RS232,TEXT_CURRENT_INTERFACE_ACTUAL_CURRENT_CHANNEL_1,fTemp,3,1,0);
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F899*/
                              /*~F:900*/
                              case 1:
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendFloat(COMMUNICATION_RS232,TEXT_CURRENT_INTERFACE_ACTUAL_CURRENT_MEASURED_CHANNEL_1,fTemp,3,1,0);
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F900*/
                              /*~O:C898*/
                              /*~-2*/
                              default:
                              {
                              /*~T*/
                              Communication_SendFloat(COMMUNICATION_RS232,TEXT_CURRENT_INTERFACE_ACTUAL_DEVIATION_CHANNEL_1,g_CurrentInterface.FeedBack.Results.Deviation.fFloat,5,1,0);
                              /*~-1*/
                              }
                              /*~-1*/
                              }
                              /*~E:C898*/
                              /*~O:I897*/
                              /*~-1*/
#else
                              /*~T*/
                              Communication_SendFloat(COMMUNICATION_RS232,TEXT_CURRENT_INTERFACE_ACTUAL_CURRENT_CHANNEL_1,fTemp,3,1,0);
                              /*~-1*/
#endif
                              /*~E:I897*/
                              /*~-1*/
#endif
                              /*~E:I896*/
                              /*~E:A895*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F894*/
                              /*~O:C886*/
                              /*~-2*/
                              default:
                              {
                              /*~A:901*/
                              /*~+:Kanal 0*/
                              /*~I:902*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I902*/
                              /*~E:A901*/
                              /*~-1*/
                              }
                           /*~-1*/
                           }
                           /*~E:C886*/
                        /*~-1*/
                        }
                        /*~O:I885*/
                        /*~-2*/
                        else
                        {
                           /*~A:903*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A903*/
                        /*~-1*/
                        }
                        /*~E:I885*/
                     /*~-1*/
                     }
                     /*~E:I884*/
                     /*~E:A883*/
                     /*~A:904*/
                     /*~+:GCV - GetCompensationValue*/
                     /*~I:905*/
                     if (!strcmp(szCommand,"GCV"))
                     /*~-1*/
                     {
                        /*~T*/
                        int nCorVal;
                        /*~T*/
                        // Text wurde bereits gesendet
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:906*/
                        if (!InstructionDecoder_CheckNbParameters(2,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0);
                           Parameter[1].nLong = Communication_GetLongParameter(1);
                           /*~C:907*/
                           switch (Parameter[0].nLong)
                           /*~-1*/
                           {
                              /*~F:908*/
                              case 0:
                              /*~-1*/
                              {
                              /*~A:909*/
                              /*~+:Kanal 0*/
                              /*~I:910*/
#ifdef CHANNEL_0
                              /*~T*/
                              nCorVal = Compensation_GetCompensationValue((char)Parameter[1].nLong);
                              /*~I:911*/
                              if ((char)Parameter[1].nLong == 20)
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_COMPENSATION_REFPOINT_OFFSET_CHANNEL_0,nCorVal,1,0);
                              /*~-1*/
                              }
                              /*~O:I911*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_COMPENSATION_REFPOINT_CHANNEL_0,nCorVal,1,0);
                              /*~-1*/
                              }
                              /*~E:I911*/
                              /*~-1*/
#endif
                              /*~E:I910*/
                              /*~E:A909*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F908*/
                              /*~F:912*/
                              case 1:
                              /*~-1*/
                              {
                              /*~A:913*/
                              /*~+:Kanal 1*/
                              /*~I:914*/
#ifdef CHANNEL_1
                              /*~T*/
                              nCorVal = Compensation_GetCompensationValue((char)Parameter[1].nLong);
                              /*~I:915*/
                              if ((char)Parameter[1].nLong == 20)
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_COMPENSATION_REFPOINT_OFFSET_CHANNEL_1,nCorVal,1,0);
                              /*~-1*/
                              }
                              /*~O:I915*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_COMPENSATION_REFPOINT_CHANNEL_1,nCorVal,1,0);
                              /*~-1*/
                              }
                              /*~E:I915*/
                              /*~-1*/
#endif
                              /*~E:I914*/
                              /*~E:A913*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F912*/
                              /*~O:C907*/
                              /*~-2*/
                              default:
                              {
                              /*~A:916*/
                              /*~+:Kanal 0*/
                              /*~I:917*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I917*/
                              /*~E:A916*/
                              /*~-1*/
                              }
                           /*~-1*/
                           }
                           /*~E:C907*/
                        /*~-1*/
                        }
                        /*~O:I906*/
                        /*~-2*/
                        else
                        {
                           /*~A:918*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A918*/
                        /*~-1*/
                        }
                        /*~E:I906*/
                     /*~-1*/
                     }
                     /*~E:I905*/
                     /*~E:A904*/
                     /*~A:919*/
                     /*~+:GDB - GetDeBugvariables*/
                     /*~I:920*/
#ifdef MIT_DEBUG
                     /*~I:921*/
                     if (!strcmp(szCommand,"GDB"))
                     /*~-1*/
                     {
                        /*~A:922*/
                        /*~+:Variablendeklarationen*/
                        /*~T*/
                        char byCounter;
                        /*~I:923*/
#ifdef CHANNEL_0
                        /*~T*/
                        long lDebVar[DEBUG_NB_DEBUGVARIABLES];

                        /*~-1*/
#endif
                        /*~E:I923*/
                        /*~E:A922*/
                        /*~A:924*/
                        /*~+:Variableninitialisierungen*/
                        /*~T*/
                        byCounter = 0;
                        /*~E:A924*/
                        /*~T*/
                        // Text wurde bereits gesendet
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:925*/
                        if (!InstructionDecoder_CheckNbParameters(2,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0);
                           Parameter[1].nLong = Communication_GetLongParameter(1);
                           /*~C:926*/
                           switch (Parameter[0].nLong)
                           /*~-1*/
                           {
                              /*~F:927*/
                              case 0:
                              /*~-1*/
                              {
                              /*~A:928*/
                              /*~+:Kanal 0*/
                              /*~I:929*/
#ifdef CHANNEL_0
                              /*~T*/
                              // Debug-Variablen aus dem Eeprom laden
                              Load_Parameter(LOAD_SAVE_DEBUG_VARIABLES,lDebVar,4*DEBUG_NB_DEBUGVARIABLES);
                              /*~U:930*/
                              /*~-2*/
                              do
                              {
                              /*~I:931*/
                              // Variablenindex ausgeben
                              if (Parameter[1].nLong == 255)
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_CONTENT_DEBUG_VARIABLES_CHANNEL_0,byCounter,1,0);

                              /*~-1*/
                              }
                              /*~O:I931*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_CONTENT_DEBUG_VARIABLES_CHANNEL_0,Parameter[1].nLong,1,0);

                              /*~-1*/
                              }
                              /*~E:I931*/
                              /*~T*/
                              // Doppelpunkt
                              Communication_SendString(COMMUNICATION_RS232," : ",0,0);
                              /*~I:932*/
                              // Variableninhalt ausgeben
                              if (Parameter[1].nLong == 255)
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,0,lDebVar[byCounter++],0,0);
                              /*~-1*/
                              }
                              /*~O:I932*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,0,lDebVar[Parameter[1].nLong],0,0);

                              byCounter = 8;
                              /*~-1*/
                              }
                              /*~E:I932*/
                              /*~-1*/
                              }
                              /*~O:U930*/
                              while (byCounter < 8);
                              /*~E:U930*/
                              /*~-1*/
#endif
                              /*~E:I929*/
                              /*~E:A928*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F927*/
                              /*~F:933*/
                              case 1:
                              /*~-1*/
                              {
                              /*~A:934*/
                              /*~+:Kanal 1*/
                              /*~I:935*/
#ifdef CHANNEL_1
                              /*~T*/
                              // Debug-Variablen aus dem Eeprom laden
                              Load_Parameter(LOAD_SAVE_DEBUG_VARIABLES,lDebVar,4*DEBUG_NB_DEBUGVARIABLES);
                              /*~U:936*/
                              /*~-2*/
                              do
                              {
                              /*~I:937*/
                              // Variablenindex ausgeben
                              if (Parameter[1].nLong == 255)
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_CONTENT_DEBUG_VARIABLES_CHANNEL_1,byCounter,1,0);

                              /*~-1*/
                              }
                              /*~O:I937*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_CONTENT_DEBUG_VARIABLES_CHANNEL_1,Parameter[1].nLong,1,0);

                              /*~-1*/
                              }
                              /*~E:I937*/
                              /*~T*/
                              // Doppelpunkt
                              Communication_SendString(COMMUNICATION_RS232," : ",0,0);
                              /*~I:938*/
                              // Variableninhalt ausgeben
                              if (Parameter[1].nLong == 255)
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,0,lDebVar[byCounter++],0,0);
                              /*~-1*/
                              }
                              /*~O:I938*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,0,lDebVar[Parameter[1].nLong],0,0);

                              byCounter = 8;
                              /*~-1*/
                              }
                              /*~E:I938*/
                              /*~-1*/
                              }
                              /*~O:U936*/
                              while (byCounter < 8);
                              /*~E:U936*/
                              /*~-1*/
#endif
                              /*~E:I935*/
                              /*~E:A934*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F933*/
                              /*~O:C926*/
                              /*~-2*/
                              default:
                              {
                              /*~A:939*/
                              /*~+:Kanal 0*/
                              /*~I:940*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I940*/
                              /*~E:A939*/
                              /*~-1*/
                              }
                           /*~-1*/
                           }
                           /*~E:C926*/
                        /*~-1*/
                        }
                        /*~O:I925*/
                        /*~-2*/
                        else
                        {
                           /*~A:941*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A941*/
                        /*~-1*/
                        }
                        /*~E:I925*/
                     /*~-1*/
                     }
                     /*~E:I921*/
                     /*~-1*/
#endif
                     /*~E:I920*/
                     /*~E:A919*/
                     /*~A:942*/
                     /*~+:GEC - GetE-modulCompensationstate*/
                     /*~I:943*/
                     if (!strcmp(szCommand,"GEC"))
                     /*~-1*/
                     {
                        /*~A:944*/
                        /*~+:Variablendeklarationen*/
                        /*~I:945*/
#ifdef CHANNEL_0
                        /*~T*/
                        long lECompPartnerOn;

                        /*~-1*/
#endif
                        /*~E:I945*/
                        /*~E:A944*/
                        /*~T*/
                        // Text wurde bereits gesendet
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:946*/
                        if (!InstructionDecoder_CheckNbParameters(0,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           byTemp = Weight_GetEModulCompensationOnOff();
                           /*~I:947*/
#ifdef CHANNEL_0
                           /*~I:948*/
                           if (!Communication_GetSPIValue(COMMUNICATION_E_COMPENSATION_STATE,&lECompPartnerOn))
                           /*~-1*/
                           {
                              /*~I:949*/
                              if ((char)lECompPartnerOn == byTemp)
                              /*~-1*/
                              {
                              /*~I:950*/
                              if (!SYSTEM_MRW_MANAGER)
                              /*~-1*/
                              {
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              /*~I:951*/
                              if (byTemp)
                              /*~-1*/
                              {
                              /*~T*/
                              lText2Send = TEXT_E_MODUL_COMPENSATION_SWITCHED_ON;
                              /*~-1*/
                              }
                              /*~O:I951*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              lText2Send = TEXT_E_MODUL_COMPENSATION_SWITCHED_OFF;
                              /*~-1*/
                              }
                              /*~E:I951*/
                              /*~-1*/
                              }
                              /*~O:I950*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,0,byTemp,1,0);
                              /*~-1*/
                              }
                              /*~E:I950*/
                              /*~-1*/
                              }
                              /*~O:I949*/
                              /*~-2*/
                              else
                              {
                              /*~A:952*/
                              /*~+:Fehler - Werte beider Kan�le sind nicht identisch - E011*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E011;
                              /*~E:A952*/
                              /*~-1*/
                              }
                              /*~E:I949*/
                           /*~-1*/
                           }
                           /*~O:I948*/
                           /*~-2*/
                           else
                           {
                              /*~A:953*/
                              /*~+:Fehler bei der Kommunikation - E005*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A953*/
                           /*~-1*/
                           }
                           /*~E:I948*/
                           /*~O:I947*/
                           /*~-1*/
#else
                           /*~I:954*/
#ifdef CHANNEL_1
                           /*~T*/
                           InstructionDecoder_StoreValue(COMMUNICATION_E_COMPENSATION_STATE,(GLOBAL_UNIVALUE_SHORT*)&byTemp);
                           /*~-1*/
#endif
                           /*~E:I954*/
                           /*~-1*/
#endif
                           /*~E:I947*/
                        /*~-1*/
                        }
                        /*~O:I946*/
                        /*~-2*/
                        else
                        {
                           /*~A:955*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A955*/
                        /*~-1*/
                        }
                        /*~E:I946*/
                     /*~-1*/
                     }
                     /*~E:I943*/
                     /*~E:A942*/
                     /*~A:956*/
                     /*~+:GFB - GetFeedBackstate*/
                     /*~I:957*/
                     if (!strcmp(szCommand,"GFB"))
                     /*~-1*/
                     {
                        /*~A:958*/
                        /*~+:Variablendeklarationen*/
                        /*~T*/
                        char byRetVal;

                        /*~I:959*/
#ifdef CHANNEL_0 
                        /*~T*/
                        long lFeedbackStatePartner;
                        /*~-1*/
#endif
                        /*~E:I959*/
                        /*~E:A958*/
                        /*~I:960*/
                        if (!InstructionDecoder_CheckNbParameters(0,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           byRetVal = CurrentInterface_GetFeedBackState();
                           /*~I:961*/
#ifdef CHANNEL_0
                           /*~I:962*/
                           if (!Communication_GetSPIValue(COMMUNICATION_CURRENTINTERFACE_FEEDBACK_STATE,&lFeedbackStatePartner))
                           /*~-1*/
                           {
                              /*~I:963*/
                              if ((char)lFeedbackStatePartner == byRetVal)
                              /*~-1*/
                              {
                              /*~I:964*/
                              if (!SYSTEM_MRW_MANAGER)
                              /*~-1*/
                              {
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              /*~I:965*/
                              if (byRetVal)
                              /*~-1*/
                              {
                              /*~T*/
                              lText2Send = TEXT_FEEDBACK_STATE_ON;
                              /*~-1*/
                              }
                              /*~O:I965*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              lText2Send = TEXT_FEEDBACK_STATE_OFF;
                              /*~-1*/
                              }
                              /*~E:I965*/
                              /*~-1*/
                              }
                              /*~O:I964*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,0,byRetVal,1,0);
                              /*~-1*/
                              }
                              /*~E:I964*/
                              /*~-1*/
                              }
                              /*~O:I963*/
                              /*~-2*/
                              else
                              {
                              /*~A:966*/
                              /*~+:Fehler - Werte beider Kan�le sind nicht identisch - E011*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E011;
                              /*~E:A966*/
                              /*~-1*/
                              }
                              /*~E:I963*/
                           /*~-1*/
                           }
                           /*~O:I962*/
                           /*~-2*/
                           else
                           {
                              /*~A:967*/
                              /*~+:Fehler bei der Kommunikation - E005*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A967*/
                           /*~-1*/
                           }
                           /*~E:I962*/
                           /*~O:I961*/
                           /*~-1*/
#else
                           /*~I:968*/
#ifdef CHANNEL_1 
                           /*~T*/
                           InstructionDecoder_StoreValue(COMMUNICATION_CURRENTINTERFACE_FEEDBACK_STATE,(GLOBAL_UNIVALUE_SHORT*)&byRetVal);
                           /*~-1*/
#endif
                           /*~E:I968*/
                           /*~-1*/
#endif
                           /*~E:I961*/
                        /*~-1*/
                        }
                        /*~O:I960*/
                        /*~-2*/
                        else
                        {
                           /*~A:969*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A969*/
                        /*~-1*/
                        }
                        /*~E:I960*/
                     /*~-1*/
                     }
                     /*~E:I957*/
                     /*~E:A956*/
                     /*~A:970*/
                     /*~+:GFD - GetFilterDepth*/
                     /*~I:971*/
                     if (!strcmp(szCommand,"GFD"))
                     /*~-1*/
                     {
                        /*~A:972*/
                        /*~+:Variablendeklarationen*/
                        /*~I:973*/
#ifdef CHANNEL_0
                        /*~T*/
                        long lFilterdepthPartner;

                        /*~-1*/
#endif
                        /*~E:I973*/
                        /*~E:A972*/
                        /*~T*/
                        // Text wurde bereits gesendet
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:974*/
                        if (!InstructionDecoder_CheckNbParameters(0,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           byTemp = AverageFilter_GetFilterDepth(WEIGHT_WEIGHTCHANNEL);
                           /*~I:975*/
#ifdef CHANNEL_0
                           /*~I:976*/
                           if (!Communication_GetSPIValue(COMMUNICATION_FILTER_DEPTH,&lFilterdepthPartner))
                           /*~-1*/
                           {
                              /*~I:977*/
                              if ((char)lFilterdepthPartner == byTemp)
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_AVERAGE_FILTER_ACTUAL_DEPTH,(char)byTemp,1,0);
                              /*~-1*/
                              }
                              /*~O:I977*/
                              /*~-2*/
                              else
                              {
                              /*~A:978*/
                              /*~+:Fehler - Werte beider Kan�le sind nicht identisch - E011*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E011;
                              /*~E:A978*/
                              /*~-1*/
                              }
                              /*~E:I977*/
                           /*~-1*/
                           }
                           /*~O:I976*/
                           /*~-2*/
                           else
                           {
                              /*~A:979*/
                              /*~+:Fehler bei der Kommunikation - E005*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A979*/
                           /*~-1*/
                           }
                           /*~E:I976*/
                           /*~O:I975*/
                           /*~-1*/
#else
                           /*~I:980*/
#ifdef CHANNEL_1
                           /*~T*/
                           InstructionDecoder_StoreValue(COMMUNICATION_FILTER_DEPTH,(GLOBAL_UNIVALUE_SHORT*)&byTemp);
                           /*~-1*/
#endif
                           /*~E:I980*/
                           /*~-1*/
#endif
                           /*~E:I975*/
                        /*~-1*/
                        }
                        /*~O:I974*/
                        /*~-2*/
                        else
                        {
                           /*~A:981*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A981*/
                        /*~-1*/
                        }
                        /*~E:I974*/
                     /*~-1*/
                     }
                     /*~E:I971*/
                     /*~E:A970*/
                     /*~I:982*/
#ifdef SYSTEM_CND_WITH_DEADBAND_FILTER
                     /*~A:983*/
                     /*~+:GFW - GetFilterWidth*/
                     /*~I:984*/
                     if (!strcmp(szCommand,"GFW"))
                     /*~-1*/
                     {
                        /*~A:985*/
                        /*~+:Variablendeklarationen*/
                        /*~T*/
                        int nFilterBandWidth;

                        /*~I:986*/
#ifdef CHANNEL_0
                        /*~T*/
                        long lFilterBandWidthPartner;
                        /*~-1*/
#endif
                        /*~E:I986*/
                        /*~E:A985*/
                        /*~A:987*/
                        /*~+:Variableninitialsierungen*/
                        /*~T*/

                        /*~E:A987*/
                        /*~T*/
                        // Text wurde bereits gesendet
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:988*/
                        if (!InstructionDecoder_CheckNbParameters(0,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           nFilterBandWidth = (int)DeadBandFilter_GetBandWidth(WEIGHT_WEIGHTCHANNEL); 
                           /*~I:989*/
#ifdef CHANNEL_0
                           /*~I:990*/
                           if (!Communication_GetSPIValue(COMMUNICATION_FILTER_WIDTH,&lFilterBandWidthPartner))

                           /*~-1*/
                           {
                              /*~I:991*/
                              if (lFilterBandWidthPartner == nFilterBandWidth)
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_DEADBAND_FILTER_ACTUAL_WIDTH_CHANNEL_0,(long)nFilterBandWidth,1,0);
                              /*~-1*/
                              }
                              /*~O:I991*/
                              /*~-2*/
                              else
                              {
                              /*~A:992*/
                              /*~+:Fehler - Werte beider Kan�le sind nicht identisch - E011*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E011;
                              /*~E:A992*/
                              /*~-1*/
                              }
                              /*~E:I991*/
                           /*~-1*/
                           }
                           /*~O:I990*/
                           /*~-2*/
                           else
                           {
                              /*~A:993*/
                              /*~+:Fehler bei der Kommunikation - E005*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A993*/
                           /*~-1*/
                           }
                           /*~E:I990*/
                           /*~O:I989*/
                           /*~-1*/
#else
                           /*~I:994*/
#ifdef CHANNEL_1
                           /*~T*/
                           InstructionDecoder_StoreValue(COMMUNICATION_FILTER_WIDTH,(GLOBAL_UNIVALUE_SHORT*)&nFilterBandWidth);
                           /*~-1*/
#endif
                           /*~E:I994*/
                           /*~-1*/
#endif
                           /*~E:I989*/
                        /*~-1*/
                        }
                        /*~O:I988*/
                        /*~-2*/
                        else
                        {
                           /*~A:995*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A995*/
                        /*~-1*/
                        }
                        /*~E:I988*/
                     /*~-1*/
                     }
                     /*~E:I984*/
                     /*~E:A983*/
                     /*~O:I982*/
                     /*~-1*/
#else
                     /*~A:996*/
                     /*~+:GFW - GetFilterWidth*/
                     /*~I:997*/
                     if (!strcmp(szCommand,"GFW"))
                     /*~-1*/
                     {
                        /*~A:998*/
                        /*~+:Variablendeklarationen*/
                        /*~T*/
                        int nFilterBandWidth;

                        /*~I:999*/
#ifdef CHANNEL_0
                        /*~T*/
                        long lFilterBandWidthPartner;
                        /*~-1*/
#endif
                        /*~E:I999*/
                        /*~E:A998*/
                        /*~A:1000*/
                        /*~+:Variableninitialsierungen*/
                        /*~T*/

                        /*~E:A1000*/
                        /*~T*/
                        // Text wurde bereits gesendet
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:1001*/
#ifdef CHANNEL_0
                        /*~T*/
                        Communication_SendLong(COMMUNICATION_RS232,TEXT_DEADBAND_FILTER_ACTUAL_WIDTH_CHANNEL_0,0L,1,0);
                        /*~-1*/
#endif
                        /*~E:I1001*/
                     /*~-1*/
                     }
                     /*~E:I997*/
                     /*~E:A996*/
                     /*~-1*/
#endif
                     /*~E:I982*/
                     /*~A:1002*/
                     /*~+:GID - GetsystemID*/
                     /*~I:1003*/
                     if (!strcmp(szCommand,"GID"))
                     /*~-1*/
                     {
                        /*~T*/
                        // Text wurde bereits gesendet
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:1004*/
                        if (!InstructionDecoder_CheckNbParameters(0,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~A:1005*/
                           /*~+:Kanal 0*/
                           /*~I:1006*/
#ifdef CHANNEL_0
                           /*~A:1007*/
                           /*~+:Variablendeklarationen*/
                           /*~T*/

                           /*~E:A1007*/
                           /*~T*/
                           Communication_SendLong(COMMUNICATION_RS232,TEXT_SYSTEM_ID,Global.ulSystemID,1,0);
                           /*~-1*/
#endif
                           /*~E:I1006*/
                           /*~E:A1005*/
                        /*~-1*/
                        }
                        /*~O:I1004*/
                        /*~-2*/
                        else
                        {
                           /*~A:1008*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1008*/
                        /*~-1*/
                        }
                        /*~E:I1004*/
                     /*~-1*/
                     }
                     /*~E:I1003*/
                     /*~E:A1002*/
                     /*~I:1009*/
#ifndef OHNE_STROMRUECKFUEHRUNG
                     /*~A:1010*/
                     /*~+:GIP - GetIntegralPortion (of Current Feedback)*/
                     /*~I:1011*/
                     if (!strcmp(szCommand,"GIP"))
                     /*~-1*/
                     {
                        /*~T*/
                        // Text wurde bereits gesendet
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:1012*/
                        if (!InstructionDecoder_CheckNbParameters(0,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           // Da in beiden Kan�len dieser Wert gleich sein muss, gen�gt die Ausgabe des Kanal 0 
                           /*~A:1013*/
                           /*~+:Kanal 0*/
                           /*~I:1014*/
#ifdef CHANNEL_0
                           /*~T*/
                           //Communication_SendLong(COMMUNICATION_RS232,TEXT_FEEDBACK_INTEGRAL_PORTION,100 - CurrentInterface_GetFeedBackIntegralPortion(),1,0);

                           Communication_SendLong(COMMUNICATION_RS232,TEXT_FEEDBACK_INTEGRAL_PORTION,CurrentInterface_GetFeedBackIntegralPortion(),1,0);
                           /*~-1*/
#endif
                           /*~E:I1014*/
                           /*~E:A1013*/
                        /*~-1*/
                        }
                        /*~O:I1012*/
                        /*~-2*/
                        else
                        {
                           /*~A:1015*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1015*/
                        /*~-1*/
                        }
                        /*~E:I1012*/
                     /*~-1*/
                     }
                     /*~E:I1011*/
                     /*~E:A1010*/
                     /*~-1*/
#endif
                     /*~E:I1009*/
                     /*~A:1016*/
                     /*~+:GLC - GetLoadCell*/
                     /*~I:1017*/
                     if (!strcmp(szCommand,"GLC"))
                     /*~-1*/
                     {
                        /*~A:1018*/
                        /*~+:Variablendeklarationen*/
                        /*~I:1019*/
#ifdef CHANNEL_0
                        /*~T*/
                        long lLoadCellTypePartner;
                        /*~-1*/
#endif
                        /*~E:I1019*/
                        /*~E:A1018*/
                        /*~A:1020*/
                        /*~+:Variableninitialisierungen*/
                        /*~T*/

                        /*~E:A1020*/
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:1021*/
                        if (!InstructionDecoder_CheckNbParameters(0,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~I:1022*/
#ifdef CHANNEL_0
                           /*~I:1023*/
                           if (!Communication_GetSPIValue(COMMUNICATION_LOADCELL,&lLoadCellTypePartner))
                           /*~-1*/
                           {
                              /*~I:1024*/
                              if (lLoadCellTypePartner == g_SystemControl.byLoadCellType)
                              /*~-1*/
                              {
                              /*~I:1025*/
                              if (!SYSTEM_MRW_MANAGER)
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendString(COMMUNICATION_RS232,T_TEXT_LOADCELL_TYPE,1,0);

                              /*~C:1026*/
                              switch (g_SystemControl.byLoadCellType)
                              /*~-1*/
                              {
                              /*~F:1027*/
                              case 1:
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendString(COMMUNICATION_RS232,T_TEXT_STANDARD_LOADCELL,0,0);

                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1027*/
                              /*~F:1028*/
                              case 2:
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendString(COMMUNICATION_RS232,T_TEXT_XL_LOADCELL,0,0);

                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1028*/
                              /*~O:C1026*/
                              /*~-2*/
                              default:
                              {
                              /*~T*/
                              Communication_SendString(COMMUNICATION_RS232,T_TEXT_CELLTYPE_NOT_DEFINED,0,0);

                              /*~-1*/
                              }
                              /*~-1*/
                              }
                              /*~E:C1026*/
                              /*~-1*/
                              }
                              /*~O:I1025*/
                              /*~-2*/
                              else
                              {
                              /*~I:1029*/
                              if (g_SystemControl.byLoadCellType < 3)
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_LOADCELL_TYPE,g_SystemControl.byLoadCellType,1,0);
                              /*~-1*/
                              }
                              /*~O:I1029*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_LOADCELL_TYPE,0,1,0);
                              /*~-1*/
                              }
                              /*~E:I1029*/
                              /*~-1*/
                              }
                              /*~E:I1025*/
                              /*~-1*/
                              }
                              /*~O:I1024*/
                              /*~-2*/
                              else
                              {
                              /*~A:1030*/
                              /*~+:Fehler - Wertebeider Kan�le sind nicht identisch - E011*/
                              /*~T*/
                              // Fehler - Wertebeider Kan�le sind nicht identisch
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E011;
                              /*~E:A1030*/
                              /*~-1*/
                              }
                              /*~E:I1024*/
                           /*~-1*/
                           }
                           /*~O:I1023*/
                           /*~-2*/
                           else
                           {
                              /*~A:1031*/
                              /*~+:Fehler bei der Kommunikation - E005*/
                              /*~T*/
                              // Fehler bei der Kommunikation - E005
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A1031*/
                           /*~-1*/
                           }
                           /*~E:I1023*/
                           /*~O:I1022*/
                           /*~-1*/
#else
                           /*~I:1032*/
#ifdef CHANNEL_1 
                           /*~T*/
                           InstructionDecoder_StoreValue(COMMUNICATION_LOADCELL,(GLOBAL_UNIVALUE_SHORT*)&g_SystemControl.byLoadCellType);
                           /*~-1*/
#endif
                           /*~E:I1032*/
                           /*~-1*/
#endif
                           /*~E:I1022*/
                        /*~-1*/
                        }
                        /*~O:I1021*/
                        /*~-2*/
                        else
                        {
                           /*~A:1033*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1033*/
                        /*~-1*/
                        }
                        /*~E:I1021*/
                     /*~-1*/
                     }
                     /*~E:I1017*/
                     /*~E:A1016*/
                     /*~A:1034*/
                     /*~+:GML - GetMaxLoad*/
                     /*~I:1035*/
                     if (!strcmp(szCommand,"GML"))
                     /*~-1*/
                     {
                        /*~T*/
                        // Text wurde bereits gesendet
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~A:1036*/
                        /*~+:Kanal 0*/
                        /*~I:1037*/
#ifdef CHANNEL_0
                        /*~I:1038*/
                        if (!InstructionDecoder_CheckNbParameters(0,1,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~I:1039*/
                           if (!SYSTEM_MRW_MANAGER)
                           /*~-1*/
                           {
                              /*~T*/
                              Communication_SendString(COMMUNICATION_RS232,T_TEXT_MAX_SYSTEMLOAD,1,0);

                           /*~-1*/
                           }
                           /*~E:I1039*/
                           /*~T*/
                           Communication_SendString(COMMUNICATION_RS232,TEXT_MAX_LOAD,0,0);
                        /*~-1*/
                        }
                        /*~O:I1038*/
                        /*~-2*/
                        else
                        {
                           /*~A:1040*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1040*/
                        /*~-1*/
                        }
                        /*~E:I1038*/
                        /*~-1*/
#endif
                        /*~E:I1037*/
                        /*~E:A1036*/
                     /*~-1*/
                     }
                     /*~E:I1035*/
                     /*~E:A1034*/
                     /*~I:1041*/
#ifdef MIT_EINSTELLBARER_MESSWERTTIEFE
                     /*~A:1042*/
                     /*~+:GNM - GetNumberMeasurements*/
                     /*~I:1043*/
                     if (!strcmp(szCommand,"GNM"))
                     /*~-1*/
                     {
                        /*~A:1044*/
                        /*~+:Variablendeklarationen*/
                        /*~I:1045*/
#ifdef CHANNEL_0
                        /*~T*/
                        long lMeasurementDepthPartner;
                        /*~-1*/
#endif
                        /*~E:I1045*/
                        /*~E:A1044*/
                        /*~A:1046*/
                        /*~+:Variableninitialsierungen*/
                        /*~T*/

                        /*~E:A1046*/
                        /*~T*/
                        // Text wurde bereits gesendet
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:1047*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0);
                           /*~K*/
                           /*~+:*/
                           /*~I:1048*/
                           if (Parameter[0].nLong < 2)
                           /*~-1*/
                           {
                              /*~I:1049*/
                              if (!Parameter[0].nLong)
                              /*~-1*/
                              {
                              /*~T*/
                              ADuC836_ADCGetMeasurementDepth(ADuC836_ADC_PRIMARY,&byTemp);
                              /*~-1*/
                              }
                              /*~O:I1049*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              ADuC836_ADCGetMeasurementDepth(ADuC836_ADC_PRIMARY_TOGGLE,&byTemp);
                              /*~-1*/
                              }
                              /*~E:I1049*/
                              /*~I:1050*/
#ifdef CHANNEL_0
                              /*~I:1051*/
                              if (!Communication_GetSPIValue(COMMUNICATION_NUMBER_OF_MEASUREMENTS,&lMeasurementDepthPartner))
                              /*~-1*/
                              {
                              /*~I:1052*/
                              if ((char)lMeasurementDepthPartner == byTemp)
                              /*~-1*/
                              {
                              /*~I:1053*/
                              if (!Parameter[0].nLong)
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_MEASUREMENT_DEPTH_RMW_CHANNEL_0,byTemp,1,0);
                              /*~-1*/
                              }
                              /*~O:I1053*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_MEASUREMENT_DEPTH_FEEDBACK_CHANNEL_0,byTemp,1,0);
                              /*~-1*/
                              }
                              /*~E:I1053*/
                              /*~-1*/
                              }
                              /*~O:I1052*/
                              /*~-2*/
                              else
                              {
                              /*~A:1054*/
                              /*~+:Fehler - Werte beider Kan�le sind nicht identisch - E011*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E011;
                              /*~E:A1054*/
                              /*~-1*/
                              }
                              /*~E:I1052*/
                              /*~-1*/
                              }
                              /*~O:I1051*/
                              /*~-2*/
                              else
                              {
                              /*~A:1055*/
                              /*~+:Fehler bei der Kommunikation - E005*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A1055*/
                              /*~-1*/
                              }
                              /*~E:I1051*/
                              /*~O:I1050*/
                              /*~-1*/
#else
                              /*~I:1056*/
#ifdef CHANNEL_1
                              /*~T*/
                              InstructionDecoder_StoreValue(COMMUNICATION_NUMBER_OF_MEASUREMENTS,(GLOBAL_UNIVALUE_SHORT*)&byTemp);
                              /*~-1*/
#endif
                              /*~E:I1056*/
                              /*~-1*/
#endif
                              /*~E:I1050*/
                           /*~-1*/
                           }
                           /*~O:I1048*/
                           /*~-2*/
                           else
                           {
                              /*~I:1057*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I1057*/
                           /*~-1*/
                           }
                           /*~E:I1048*/
                        /*~-1*/
                        }
                        /*~O:I1047*/
                        /*~-2*/
                        else
                        {
                           /*~A:1058*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1058*/
                        /*~-1*/
                        }
                        /*~E:I1047*/
                     /*~-1*/
                     }
                     /*~E:I1043*/
                     /*~E:A1042*/
                     /*~-1*/
#endif
                     /*~E:I1041*/
                     /*~I:1059*/
#ifndef OHNE_STROMRUECKFUEHRUNG
                     /*~A:1060*/
                     /*~+:GPP - GetProportionalPortion (of Current Feedback)*/
                     /*~I:1061*/
                     if (!strcmp(szCommand,"GPP"))
                     /*~-1*/
                     {
                        /*~T*/
                        // Text wurde bereits gesendet
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:1062*/
                        if (!InstructionDecoder_CheckNbParameters(0,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           // Da in beiden Kan�len dieser Wert gleich sein muss, gen�gt die Ausgabe des Kanal 0 
                           /*~A:1063*/
                           /*~+:Kanal 0*/
                           /*~I:1064*/
#ifdef CHANNEL_0
                           /*~T*/
                           Communication_SendLong(COMMUNICATION_RS232,TEXT_FEEDBACK_PROPORTIONAL_PORTION,100 - CurrentInterface_GetFeedBackProportionalPortion(),1,0);
                           /*~-1*/
#endif
                           /*~E:I1064*/
                           /*~E:A1063*/
                        /*~-1*/
                        }
                        /*~O:I1062*/
                        /*~-2*/
                        else
                        {
                           /*~A:1065*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1065*/
                        /*~-1*/
                        }
                        /*~E:I1062*/
                     /*~-1*/
                     }
                     /*~E:I1061*/
                     /*~E:A1060*/
                     /*~-1*/
#endif
                     /*~E:I1059*/
                     /*~A:1066*/
                     /*~+:GSU - GetpowerSUpply*/
                     /*~I:1067*/
                     if (!strcmp(szCommand,"GSU"))
                     /*~-1*/
                     {
                        /*~T*/
                        // Text wurde bereits gesendet
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:1068*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0);
                           /*~C:1069*/
                           switch (Parameter[0].nLong)
                           /*~-1*/
                           {
                              /*~F:1070*/
                              case 0:
                              /*~-1*/
                              {
                              /*~A:1071*/
                              /*~+:Kanal 0*/
                              /*~I:1072*/
#ifdef CHANNEL_0
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_POWERSUPPLY_CHANNEL_0,Global.lRMW_PowerSupply,1,0);
                              /*~-1*/
#endif
                              /*~E:I1072*/
                              /*~E:A1071*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1070*/
                              /*~I:1073*/
#ifdef VCC_CHECK_ON_BOTH_CHANELS
                              /*~F:1074*/
                              case 1:
                              /*~-1*/
                              {
                              /*~A:1075*/
                              /*~+:Kanal 1*/
                              /*~I:1076*/
#ifdef CHANNEL_1
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_POWERSUPPLY_CHANNEL_1,Global.lRMW_PowerSupply,1,0);
                              /*~-1*/
#endif
                              /*~E:I1076*/
                              /*~E:A1075*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1074*/
                              /*~-1*/
#endif
                              /*~E:I1073*/
                              /*~O:C1069*/
                              /*~-2*/
                              default:
                              {
                              /*~A:1077*/
                              /*~+:Kanal 0*/
                              /*~I:1078*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I1078*/
                              /*~E:A1077*/
                              /*~-1*/
                              }
                           /*~-1*/
                           }
                           /*~E:C1069*/
                        /*~-1*/
                        }
                        /*~O:I1068*/
                        /*~-2*/
                        else
                        {
                           /*~A:1079*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1079*/
                        /*~-1*/
                        }
                        /*~E:I1068*/
                     /*~-1*/
                     }
                     /*~E:I1067*/
                     /*~E:A1066*/
                     /*~A:1080*/
                     /*~+:GSD - GetStatisticsData*/
                     /*~I:1081*/
                     if (!strcmp(szCommand,"GSD"))
                     /*~-1*/
                     {
                        /*~T*/
                        // Text wurde bereits gesendet
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:1082*/
                        if (!InstructionDecoder_CheckNbParameters(2,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0);
                           Parameter[1].nLong = Communication_GetLongParameter(1);
                           /*~C:1083*/
                           switch (Parameter[0].nLong)
                           /*~-1*/
                           {
                              /*~F:1084*/
                              case 0:
                              case 2:
                              /*~-1*/
                              {
                              /*~I:1085*/
#ifdef CHANNEL_0
                              /*~A:1086*/
                              /*~+:Kanal 0 - Absolutstatistik(0) - Relativstatistik(2)*/
                              /*~I:1087*/
                              if (Parameter[0].nLong == 0)
                              /*~-1*/
                              {
                              /*~A:1088*/
                              /*~+:Absolutstatistik*/
                              /*~K*/
                              /*~+:// Absolutstatistik*/
                              /*~T*/
                              Statistics_PrintData(Parameter[1].nLong);
                              /*~E:A1088*/
                              /*~-1*/
                              }
                              /*~O:I1087*/
                              /*~-2*/
                              else
                              {
                              /*~A:1089*/
                              /*~+:Relativstatistik*/
                              /*~K*/
                              /*~+:// Relativstatistik*/
                              /*~T*/
                              Statistics_PrintData(Parameter[1].nLong | 0x40);
                              /*~E:A1089*/
                              /*~-1*/
                              }
                              /*~E:I1087*/
                              /*~E:A1086*/
                              /*~-1*/
#endif
                              /*~E:I1085*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1084*/
                              /*~F:1090*/
                              case 1:
                              case 3:
                              /*~-1*/
                              {
                              /*~I:1091*/
#ifdef CHANNEL_1
                              /*~A:1092*/
                              /*~+:Kanal 1 - Absolutstatistik(1) - Relativstatistik(3)*/
                              /*~I:1093*/
                              if (Parameter[0].nLong == 1)
                              /*~-1*/
                              {
                              /*~A:1094*/
                              /*~+:Absolutstatistik*/
                              /*~T*/
                              Statistics_PrintData(Parameter[1].nLong);
                              /*~E:A1094*/
                              /*~-1*/
                              }
                              /*~O:I1093*/
                              /*~-2*/
                              else
                              {
                              /*~A:1095*/
                              /*~+:Relativstatistik*/
                              /*~T*/
                              Statistics_PrintData((Parameter[1].nLong | 0x40));
                              /*~E:A1095*/
                              /*~-1*/
                              }
                              /*~E:I1093*/
                              /*~E:A1092*/
                              /*~-1*/
#endif
                              /*~E:I1091*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1090*/
                              /*~O:C1083*/
                              /*~-2*/
                              default:
                              {
                              /*~A:1096*/
                              /*~+:Kanal 0*/
                              /*~I:1097*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I1097*/
                              /*~E:A1096*/
                              /*~-1*/
                              }
                           /*~-1*/
                           }
                           /*~E:C1083*/
                        /*~-1*/
                        }
                        /*~O:I1082*/
                        /*~-2*/
                        else
                        {
                           /*~A:1098*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1098*/
                        /*~-1*/
                        }
                        /*~E:I1082*/
                     /*~-1*/
                     }
                     /*~E:I1081*/
                     /*~E:A1080*/
                     /*~A:1099*/
                     /*~+:GSN - GetSerialNumber*/
                     /*~I:1100*/
                     if (!strcmp(szCommand,"GSN"))
                     /*~-1*/
                     {
                        /*~T*/
                        // Text wurde bereits gesendet
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~A:1101*/
                        /*~+:Kanal 0*/
                        /*~I:1102*/
#ifdef CHANNEL_0
                        /*~I:1103*/
                        if (!InstructionDecoder_CheckNbParameters(0,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~I:1104*/
                           if (!SYSTEM_MRW_MANAGER)
                           /*~-1*/
                           {
                              /*~T*/
                              Communication_SendString(COMMUNICATION_RS232,T_TEXT_SERIAL_NUMBER,1,0);

                           /*~-1*/
                           }
                           /*~E:I1104*/
                           /*~T*/
                           Communication_SendString(COMMUNICATION_RS232,System_GetSerialNumber(),0,0);
                        /*~-1*/
                        }
                        /*~O:I1103*/
                        /*~-2*/
                        else
                        {
                           /*~A:1105*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1105*/
                        /*~-1*/
                        }
                        /*~E:I1103*/
                        /*~-1*/
#endif
                        /*~E:I1102*/
                        /*~E:A1101*/
                     /*~-1*/
                     }
                     /*~E:I1100*/
                     /*~E:A1099*/
                     /*~A:1106*/
                     /*~+:GSP - GetStatisticsParameter*/
                     /*~I:1107*/
                     if (!strcmp(szCommand,"GSP"))
                     /*~-1*/
                     {
                        /*~A:1108*/
                        /*~+:Variablendeklarationen*/
                        /*~T*/
                        STATISTICSLIBRARY_SETUP StatisticsSetup;
                        /*~E:A1108*/
                        /*~A:1109*/
                        /*~+:Variableninitialisierungen*/
                        /*~T*/
                        StatisticsSetup = Statistics_GetSetup();
                        /*~E:A1109*/
                        /*~T*/
                        // Text wurde bereits gesendet
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:1110*/
                        if (!InstructionDecoder_CheckNbParameters(2,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0);
                           Parameter[1].nLong = Communication_GetLongParameter(1);

                           /*~C:1111*/
                           switch (Parameter[0].nLong)
                           /*~-1*/
                           {
                              /*~F:1112*/
                              case 0:	// Parameter der Statistik des Kanal 0 lesen
                              /*~-1*/
                              {
                              /*~A:1113*/
                              /*~+:Kanal 0*/
                              /*~I:1114*/
#ifdef CHANNEL_0
                              /*~C:1115*/
                              switch (Parameter[1].nLong)
                              /*~-1*/
                              {
                              /*~F:1116*/
                              case 0:	// Filter Temperatur�berwachung
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_STATISTICS_FILTER_TEMPERATURE_CHANNEL_0,StatisticsSetup.chFilterCheckTemperature,1,0);
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1116*/
                              /*~F:1117*/
                              case 1:	// Filter Gewichts�berwachung
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_STATISTICS_FILTER_WEIGHT_CHANNEL_0,StatisticsSetup.chFilterCheckWeight,1,0);
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1117*/
                              /*~F:1118*/
                              case 2:	// MotionLimit Gewichts�berwachung
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendFloat(COMMUNICATION_RS232,TEXT_STATISTICS_MOTIONLIMIT_WEIGHT_CHANNEL_0,StatisticsSetup.fMotionLimitCheckWeight,2,1,0);
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1118*/
                              /*~F:1119*/
                              case 3:	// Filter Grenzwert�berschreitung und �berlast
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_STATISTICS_FILTER_OVERLIMIT_CHANNEL_0,StatisticsSetup.chFilterOverLimit,1,0);
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1119*/
                              /*~F:1120*/
                              case 4:	// Grenzwert
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendFloat(COMMUNICATION_RS232,TEXT_STATISTICS_LIMIT_OVERLIMIT_CHANNEL_0,StatisticsSetup.fLimitOverLimit,2,1,0);
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1120*/
                              /*~-1*/
                              }
                              /*~E:C1115*/
                              /*~-1*/
#endif
                              /*~E:I1114*/
                              /*~E:A1113*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1112*/
                              /*~F:1121*/
                              case 1:	// Parameter der Statistik des Kanal 1 lesen
                              /*~-1*/
                              {
                              /*~A:1122*/
                              /*~+:Kanal 1*/
                              /*~I:1123*/
#ifdef CHANNEL_1
                              /*~C:1124*/
                              switch (Parameter[1].nLong)
                              /*~-1*/
                              {
                              /*~F:1125*/
                              case 0:	// Filter Temperatur�berwachung
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_STATISTICS_FILTER_TEMPERATURE_CHANNEL_1,StatisticsSetup.chFilterCheckTemperature,1,0);
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1125*/
                              /*~F:1126*/
                              case 1:	// Filter Gewichts�berwachung
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_STATISTICS_FILTER_WEIGHT_CHANNEL_1,StatisticsSetup.chFilterCheckWeight,1,0);
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1126*/
                              /*~F:1127*/
                              case 2:	// MotionLimit Gewichts�berwachung
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_STATISTICS_FILTER_OVERLIMIT_CHANNEL_1,StatisticsSetup.chFilterOverLimit,1,0);
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1127*/
                              /*~F:1128*/
                              case 3:	// Filter Grenzwert�berschreitung und �berlast
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendFloat(COMMUNICATION_RS232,TEXT_STATISTICS_MOTIONLIMIT_WEIGHT_CHANNEL_1,StatisticsSetup.fMotionLimitCheckWeight,2,1,0);
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1128*/
                              /*~F:1129*/
                              case 4:	// Grenzwert
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendFloat(COMMUNICATION_RS232,TEXT_STATISTICS_LIMIT_OVERLIMIT_CHANNEL_1,StatisticsSetup.fLimitOverLimit,2,1,0);
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1129*/
                              /*~-1*/
                              }
                              /*~E:C1124*/
                              /*~-1*/
#endif
                              /*~E:I1123*/
                              /*~E:A1122*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1121*/
                              /*~O:C1111*/
                              /*~-2*/
                              default:
                              {
                              /*~I:1130*/
#ifdef CHANNEL_0
                              /*~T*/
                              // Fehler
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I1130*/
                              /*~-1*/
                              }
                           /*~-1*/
                           }
                           /*~E:C1111*/
                        /*~-1*/
                        }
                        /*~O:I1110*/
                        /*~-2*/
                        else
                        {
                           /*~A:1131*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1131*/
                        /*~-1*/
                        }
                        /*~E:I1110*/
                     /*~-1*/
                     }
                     /*~E:I1107*/
                     /*~E:A1106*/
                     /*~A:1132*/
                     /*~+:GSS - GetSystemState*/
                     /*~I:1133*/
                     if (!strcmp(szCommand,"GSS"))
                     /*~-1*/
                     {
                        /*~T*/
                        // Text wurde bereits gesendet
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:1134*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0); 
                           /*~C:1135*/
                           switch (Parameter[0].nLong)
                           /*~-1*/
                           {
                              /*~F:1136*/
                              case 0:
                              /*~-1*/
                              {
                              /*~A:1137*/
                              /*~+:Kanal 0*/
                              /*~I:1138*/
#ifdef CHANNEL_0
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_ACTUAL_SYSTEMSTATE_CHANNEL_0,(long)SYSTEMSTATE,1,0);
                              /*~-1*/
#endif
                              /*~E:I1138*/
                              /*~E:A1137*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1136*/
                              /*~F:1139*/
                              case 1:
                              /*~-1*/
                              {
                              /*~A:1140*/
                              /*~+:Kanal 1*/
                              /*~I:1141*/
#ifdef CHANNEL_1
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_ACTUAL_SYSTEMSTATE_CHANNEL_1,(long)SYSTEMSTATE,1,0);
                              /*~-1*/
#endif
                              /*~E:I1141*/
                              /*~E:A1140*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1139*/
                              /*~O:C1135*/
                              /*~-2*/
                              default:
                              {
                              /*~A:1142*/
                              /*~+:Kanal 0*/
                              /*~I:1143*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I1143*/
                              /*~E:A1142*/
                              /*~-1*/
                              }
                           /*~-1*/
                           }
                           /*~E:C1135*/
                        /*~-1*/
                        }
                        /*~O:I1134*/
                        /*~-2*/
                        else
                        {
                           /*~A:1144*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1144*/
                        /*~-1*/
                        }
                        /*~E:I1134*/
                     /*~-1*/
                     }
                     /*~E:I1133*/
                     /*~E:A1132*/
                     /*~A:1145*/
                     /*~+:GTH - GetTimeHysteresis*/
                     /*~I:1146*/
                     if (!strcmp(szCommand,"GTH"))
                     /*~-1*/
                     {
                        /*~A:1147*/
                        /*~+:Variablendeklarationen*/
                        /*~T*/
                        unsigned long ulTimeHysteresis;
                        /*~I:1148*/
#ifdef CHANNEL_0
                        /*~T*/
                        unsigned long ulTimeHysteresisPartner;
                        /*~-1*/
#endif
                        /*~E:I1148*/
                        /*~E:A1147*/
                        /*~T*/
                        // Text wurde bereits gesendet
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:1149*/
                        if (!InstructionDecoder_CheckNbParameters(0,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           ulTimeHysteresis = CurrentInterface_GetTimeHysteresis();
                           /*~I:1150*/
#ifdef CHANNEL_0
                           /*~I:1151*/
                           if (!Communication_GetSPIValue(COMMUNICATION_TIME_HYSTERESIS,&ulTimeHysteresisPartner))
                           /*~-1*/
                           {
                              /*~I:1152*/
                              if (ulTimeHysteresisPartner == ulTimeHysteresis)
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_CURRENT_INTERFACE_TIME_HYSTERESIS,ulTimeHysteresis,1,0);
                              /*~-1*/
                              }
                              /*~O:I1152*/
                              /*~-2*/
                              else
                              {
                              /*~A:1153*/
                              /*~+:Fehler - Werte beider Kan�le sind nicht identisch - E011*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E011;
                              /*~E:A1153*/
                              /*~-1*/
                              }
                              /*~E:I1152*/
                           /*~-1*/
                           }
                           /*~O:I1151*/
                           /*~-2*/
                           else
                           {
                              /*~A:1154*/
                              /*~+:Fehler bei der Kommunikation - E005*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A1154*/
                           /*~-1*/
                           }
                           /*~E:I1151*/
                           /*~O:I1150*/
                           /*~-1*/
#else
                           /*~I:1155*/
#ifdef CHANNEL_1
                           /*~T*/
                           InstructionDecoder_StoreValue(COMMUNICATION_TIME_HYSTERESIS,(GLOBAL_UNIVALUE_SHORT*)&ulTimeHysteresis);
                           /*~-1*/
#endif
                           /*~E:I1155*/
                           /*~-1*/
#endif
                           /*~E:I1150*/
                        /*~-1*/
                        }
                        /*~O:I1149*/
                        /*~-2*/
                        else
                        {
                           /*~A:1156*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1156*/
                        /*~-1*/
                        }
                        /*~E:I1149*/
                     /*~-1*/
                     }
                     /*~E:I1146*/
                     /*~E:A1145*/
                     /*~A:1157*/
                     /*~+:GTM - GetTiMer*/
                     /*~I:1158*/
                     if (!strcmp(szCommand,"GTM"))
                     /*~-1*/
                     {
                        /*~A:1159*/
                        /*~+:Variablendeklarationen*/
                        /*~T*/
                        long lTime;
                        /*~E:A1159*/
                        /*~A:1160*/
                        /*~+:Variableninitialisierungen*/
                        /*~T*/
                        lTime = 0;
                        /*~E:A1160*/
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:1161*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~I:1162*/
#ifdef CHANNEL_0
                           /*~I:1163*/
                           if (Communication_GetLongParameter(0) != 1)
                           /*~-1*/
                           {
                              /*~T*/
                              // Absoluter Betriebsstundenz�hler
                              /*~I:1164*/
                              if (!SYSTEM_MRW_MANAGER)
                              /*~-1*/
                              {
                              /*~A:1165*/
                              /*~+:Docklight-Modus : Zeit als String ausgeben*/
                              /*~T*/
                              Communication_SendString(COMMUNICATION_RS232,T_TEXT_OPERATING_HOURS,1,0);

                              /*~T*/
                              Communication_SendString(COMMUNICATION_RS232,System_GetOperatingHoursAsString(0),0,0);
                              /*~E:A1165*/
                              /*~-1*/
                              }
                              /*~O:I1164*/
                              /*~-2*/
                              else
                              {
                              /*~A:1166*/
                              /*~+:MRW-Manager-Mode : Stunden als Long ausgeben*/
                              /*~I:1167*/
                              if (!Communication_GetLongParameter(0))
                              /*~-1*/
                              {
                              /*~T*/
                              lTime = System_GetOperatingHours(0,0);
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_OPERATING_HOURS,lTime,1,0);

                              /*~-1*/
                              }
                              /*~O:I1167*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              Communication_SendString(COMMUNICATION_RS232,System_GetOperatingHoursAsString(0),0,0);
                              /*~-1*/
                              }
                              /*~E:I1167*/
                              /*~E:A1166*/
                              /*~-1*/
                              }
                              /*~E:I1164*/
                              /*~A:1168*/
                              /*~+:Administratorcode bilden*/
                              /*~T*/
                              // Administratorcode bilden
                              Global.ulAdminCode = System_BuildAdminCode();  
                              /*~E:A1168*/
                           /*~-1*/
                           }
                           /*~O:I1163*/
                           /*~-2*/
                           else
                           {
                              /*~T*/
                              // Relativer Betriebsstundenz�hler
                              /*~I:1169*/
                              if (!SYSTEM_MRW_MANAGER)
                              /*~-1*/
                              {
                              /*~A:1170*/
                              /*~+:Docklight-Modus : Zeit als String ausgeben*/
                              /*~T*/
                              Communication_SendString(COMMUNICATION_RS232,T_TEXT_OPERATING_HOURS_RELATIVE,1,0);
                              /*~T*/
                              Communication_SendString(COMMUNICATION_RS232,System_GetOperatingHoursAsString(1),0,0);
                              /*~E:A1170*/
                              /*~-1*/
                              }
                              /*~O:I1169*/
                              /*~-2*/
                              else
                              {
                              /*~A:1171*/
                              /*~+:MRW-Manager-Mode : Stunden als Long ausgeben*/
                              /*~T*/
                              lTime = System_GetOperatingHours(1,0);
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_OPERATING_HOURS_RELATIVE,lTime,1,0);

                              /*~E:A1171*/
                              /*~-1*/
                              }
                              /*~E:I1169*/
                           /*~-1*/
                           }
                           /*~E:I1163*/
                           /*~-1*/
#endif
                           /*~E:I1162*/
                        /*~-1*/
                        }
                        /*~O:I1161*/
                        /*~-2*/
                        else
                        {
                           /*~A:1172*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1172*/
                        /*~-1*/
                        }
                        /*~E:I1161*/
                     /*~-1*/
                     }
                     /*~E:I1158*/
                     /*~E:A1157*/
                     /*~A:1173*/
                     /*~+:GTO - GetTemperatureOffset*/
                     /*~I:1174*/
                     if (!strcmp(szCommand,"GTO"))
                     /*~-1*/
                     {
                        /*~T*/
                        // Text wurde bereits gesendet
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:1175*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0); 
                           /*~T*/
                           (char)byTemp = Analog_GetTemperatureOffset();
                           /*~C:1176*/
                           switch (Parameter[0].nLong)
                           /*~-1*/
                           {
                              /*~F:1177*/
                              case 0:
                              /*~-1*/
                              {
                              /*~A:1178*/
                              /*~+:Kanal 0*/
                              /*~I:1179*/
#ifdef CHANNEL_0
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_ACTUAL_TEMPERATURE_OFFSET_CHANNEL_0,(char)byTemp,1,0);
                              /*~-1*/
#endif
                              /*~E:I1179*/
                              /*~E:A1178*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1177*/
                              /*~F:1180*/
                              case 1:
                              /*~-1*/
                              {
                              /*~A:1181*/
                              /*~+:Kanal 1*/
                              /*~I:1182*/
#ifdef CHANNEL_1
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_ACTUAL_TEMPERATURE_OFFSET_CHANNEL_1,(char)byTemp,1,0);
                              /*~-1*/
#endif
                              /*~E:I1182*/
                              /*~E:A1181*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1180*/
                              /*~O:C1176*/
                              /*~-2*/
                              default:
                              {
                              /*~A:1183*/
                              /*~+:Kanal 0*/
                              /*~I:1184*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I1184*/
                              /*~E:A1183*/
                              /*~-1*/
                              }
                           /*~-1*/
                           }
                           /*~E:C1176*/
                        /*~-1*/
                        }
                        /*~O:I1175*/
                        /*~-2*/
                        else
                        {
                           /*~A:1185*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1185*/
                        /*~-1*/
                        }
                        /*~E:I1175*/
                     /*~-1*/
                     }
                     /*~E:I1174*/
                     /*~E:A1173*/
                     /*~A:1186*/
                     /*~+:GTR - GetTaRa*/
                     /*~I:1187*/
                     if (!strcmp(szCommand,"GTR"))
                     /*~-1*/
                     {
                        /*~T*/
                        // Text wurde bereits gesendet
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:1188*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0); 
                           /*~C:1189*/
                           switch (Parameter[0].nLong)
                           /*~-1*/
                           {
                              /*~F:1190*/
                              case 0:
                              /*~-1*/
                              {
                              /*~A:1191*/
                              /*~+:Kanal 0*/
                              /*~I:1192*/
#ifdef CHANNEL_0
                              /*~T*/
                              Communication_SendFloat(COMMUNICATION_RS232,TEXT_MEASUREMENT_ACTUAL_TARE_CHANNEL_0,Weight_TareWeight.fFloat,2,1,0);
                              /*~-1*/
#endif
                              /*~E:I1192*/
                              /*~E:A1191*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1190*/
                              /*~F:1193*/
                              case 1:
                              /*~-1*/
                              {
                              /*~A:1194*/
                              /*~+:Kanal 1*/
                              /*~I:1195*/
#ifdef CHANNEL_1
                              /*~T*/
                              Communication_SendFloat(COMMUNICATION_RS232,TEXT_MEASUREMENT_ACTUAL_TARE_CHANNEL_1,Weight_TareWeight.fFloat,2,1,0);
                              /*~-1*/
#endif
                              /*~E:I1195*/
                              /*~E:A1194*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1193*/
                              /*~O:C1189*/
                              /*~-2*/
                              default:
                              {
                              /*~A:1196*/
                              /*~+:Kanal 0*/
                              /*~I:1197*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I1197*/
                              /*~E:A1196*/
                              /*~-1*/
                              }
                           /*~-1*/
                           }
                           /*~E:C1189*/
                        /*~-1*/
                        }
                        /*~O:I1188*/
                        /*~-2*/
                        else
                        {
                           /*~A:1198*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1198*/
                        /*~-1*/
                        }
                        /*~E:I1188*/
                     /*~-1*/
                     }
                     /*~E:I1187*/
                     /*~E:A1186*/
                     /*~A:1199*/
                     /*~+:GVR - GetVeRsion*/
                     /*~I:1200*/
                     if (!strcmp(szCommand,"GVR"))
                     /*~-1*/
                     {
                        /*~T*/
                        // Text wurde bereits gesendet
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~A:1201*/
                        /*~+:Kanal 0*/
                        /*~I:1202*/
#ifdef CHANNEL_0
                        /*~I:1203*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0); 
                           /*~C:1204*/
                           switch (Parameter[0].nLong)
                           /*~-1*/
                           {
                              /*~F:1205*/
                              case 0:
                              /*~-1*/
                              {
                              /*~T*/
                              Version_PrintVersions(0);
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1205*/
                              /*~F:1206*/
                              case 1:
                              /*~-1*/
                              {
                              /*~T*/
                              Version_PrintVersions(1);
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1206*/
                              /*~O:C1204*/
                              /*~-2*/
                              default:
                              {
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
                              }
                           /*~-1*/
                           }
                           /*~E:C1204*/
                        /*~-1*/
                        }
                        /*~O:I1203*/
                        /*~-2*/
                        else
                        {
                           /*~A:1207*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1207*/
                        /*~-1*/
                        }
                        /*~E:I1203*/
                        /*~-1*/
#endif
                        /*~E:I1202*/
                        /*~E:A1201*/
                     /*~-1*/
                     }
                     /*~E:I1200*/
                     /*~E:A1199*/
                     /*~A:1208*/
                     /*~+:GWD - GetWatchDogadress*/
                     /*~I:1209*/
                     if (!strcmp(szCommand,"GWD"))
                     /*~-1*/
                     {
                        /*~T*/
                        // Text wurde bereits gesendet
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:1210*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0); 
                           /*~C:1211*/
                           switch (Parameter[0].nLong)
                           /*~-1*/
                           {
                              /*~F:1212*/
                              case 0:
                              /*~-1*/
                              {
                              /*~A:1213*/
                              /*~+:Kanal 0*/
                              /*~I:1214*/
#ifdef CHANNEL_0
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_WATCHDOG_ADDRESS_CHANNEL_0,ADuC836_WatchdogReadAddress(),1,0);
                              /*~-1*/
#endif
                              /*~E:I1214*/
                              /*~E:A1213*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1212*/
                              /*~F:1215*/
                              case 1:
                              /*~-1*/
                              {
                              /*~A:1216*/
                              /*~+:Kanal 1*/
                              /*~I:1217*/
#ifdef CHANNEL_1
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_WATCHDOG_ADDRESS_CHANNEL_1,ADuC836_WatchdogReadAddress(),1,0);
                              /*~-1*/
#endif
                              /*~E:I1217*/
                              /*~E:A1216*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1215*/
                              /*~O:C1211*/
                              /*~-2*/
                              default:
                              {
                              /*~A:1218*/
                              /*~+:Kanal 0*/
                              /*~I:1219*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I1219*/
                              /*~E:A1218*/
                              /*~-1*/
                              }
                           /*~-1*/
                           }
                           /*~E:C1211*/
                        /*~-1*/
                        }
                        /*~O:I1210*/
                        /*~-2*/
                        else
                        {
                           /*~A:1220*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1220*/
                        /*~-1*/
                        }
                        /*~E:I1210*/
                     /*~-1*/
                     }
                     /*~E:I1209*/
                     /*~E:A1208*/
                     /*~A:1221*/
                     /*~+:GZP - GetZeroPoint*/
                     /*~I:1222*/
                     if (!strcmp(szCommand,"GZP"))
                     /*~-1*/
                     {
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:1223*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0); 
                           /*~T*/
                           Measurement_GetZero(WEIGHT_WEIGHTCHANNEL,&MVTemp);
                           /*~C:1224*/
                           switch (Parameter[0].nLong)
                           /*~-1*/
                           {
                              /*~F:1225*/
                              case 0:
                              /*~-1*/
                              {
                              /*~A:1226*/
                              /*~+:Kanal 0*/
                              /*~I:1227*/
#ifdef CHANNEL_0
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_MEASUREMENT_ACTUAL_OFFSET_CHANNEL_0,MVTemp.nLong,1,0);
                              /*~-1*/
#endif
                              /*~E:I1227*/
                              /*~E:A1226*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1225*/
                              /*~F:1228*/
                              case 1:
                              /*~-1*/
                              {
                              /*~A:1229*/
                              /*~+:Kanal 1*/
                              /*~I:1230*/
#ifdef CHANNEL_1
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_MEASUREMENT_ACTUAL_OFFSET_CHANNEL_1,MVTemp.nLong,1,0);
                              /*~-1*/
#endif
                              /*~E:I1230*/
                              /*~E:A1229*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1228*/
                              /*~O:C1224*/
                              /*~-2*/
                              default:
                              {
                              /*~A:1231*/
                              /*~+:Kanal 0*/
                              /*~I:1232*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I1232*/
                              /*~E:A1231*/
                              /*~-1*/
                              }
                           /*~-1*/
                           }
                           /*~E:C1224*/
                        /*~-1*/
                        }
                        /*~O:I1223*/
                        /*~-2*/
                        else
                        {
                           /*~A:1233*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1233*/
                        /*~-1*/
                        }
                        /*~E:I1223*/
                     /*~-1*/
                     }
                     /*~E:I1222*/
                     /*~E:A1221*/
                     /*~T*/
                     break;
                  /*~-1*/
                  }
                  /*~E:F643*/
                  /*~E:A642*/
                  /*~A:1234*/
                  /*~+:I*/
                  /*~F:1235*/
                  case 'I':
                  /*~-1*/
                  {
                     /*~A:1236*/
                     /*~+:INI - INItialize*/
                     /*~I:1237*/
                     if (!strcmp(szCommand,"INI"))
                     /*~-1*/
                     {
                        /*~K*/
                        /*~+:/~**/
                        /*~+:1. 	Alamstatus l�schen*/
                        /*~+:2. 	1.Parameter = 0: Temperaturkompensation ausschalten*/
                        /*~+:	1.Parameter = 1: Temperaturkompensation einschalten*/
                        /*~+:3.	Statistikspeicher l�schen*/
                        /*~+:4.	2.Parameter = 0: kein Reset*/
                        /*~+:	2.Parameter = 1: Reset*/
                        /*~+:*~/*/
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:1238*/
                        if (!InstructionDecoder_CheckNbParameters(2,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0);
                           Parameter[1].nLong = Communication_GetLongParameter(1); 
                           /*~F:1239*/
                           // neu ab Version V1.006
                           /*~-1*/
                           {
                              /*~T*/
                              // Z�hler zur �berpr�fung der SPI-Kommunikation l�schen
                              Communication_ClearSPIFaultCounter(1);
                           /*~-1*/
                           }
                           /*~E:F1239*/
                           /*~T*/
                           Diagnosis_ClearDiagnosis(DIAGNOSIS_CLEAR_ALL_BY_INITITALISATION);
                           /*~A:1240*/
                           /*~+:1.Parameter:	0: Temperaturkompensation ausschalten*/
                           /*~+:				1: Temperaturkompensation einschalten*/
                           /*~C:1241*/
                           switch (Parameter[0].nLong)
                           /*~-1*/
                           {
                              /*~F:1242*/
                              case 0:		// Temperaturkompensation ausschalten
                              /*~-1*/
                              {
                              /*~T*/
                              MRW_Compensation_SetCompensationOn(0);
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1242*/
                              /*~F:1243*/
                              case 1:		// Temperaturkompensation einschalten
                              /*~-1*/
                              {
                              /*~T*/
                              MRW_Compensation_SetCompensationOn(1);
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1243*/
                              /*~O:C1241*/
                              /*~-2*/
                              default:
                              {
                              /*~A:1244*/
                              /*~+:Ausf�hrungsstatus auf 'E002' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E002;
                              /*~E:A1244*/
                              /*~-1*/
                              }
                           /*~-1*/
                           }
                           /*~E:C1241*/
                           /*~E:A1240*/
                           /*~I:1245*/
                           if (byCommandStatus == INSTRUCTIONDECODER_SEND_NOTHING)
                           /*~-1*/
                           {
                              /*~T*/
                              // Statistikspeicher l�schen - Implementierung sp�ter
                              /*~A:1246*/
                              /*~+:2.Parameter:	0: kein Reset*/
                              /*~+:				1: Reset*/
                              /*~C:1247*/
                              switch (Parameter[1].nLong)
                              /*~-1*/
                              {
                              /*~F:1248*/
                              case 0:		// kein Reset
                              /*~-1*/
                              {
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1248*/
                              /*~F:1249*/
                              case 1:		// Reset
                              /*~-1*/
                              {
                              /*~A:1250*/
                              /*~+:Eintrag im Diagnosespeicher*/
                              /*~T*/
                              Diagnosis_WriteMessage2Flash(DIAGNOSIS_MESSAGE_RESET_BY_INI_COMMAND);
                              /*~E:A1250*/
                              /*~T*/
                              System_SystemErrorSetWatchdog();
                              /*~-1*/
                              }
                              /*~E:F1249*/
                              /*~O:C1247*/
                              /*~-2*/
                              default:
                              {
                              /*~A:1251*/
                              /*~+:Ausf�hrungsstatus auf 'E002' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E002;
                              /*~E:A1251*/
                              /*~-1*/
                              }
                              /*~-1*/
                              }
                              /*~E:C1247*/
                              /*~E:A1246*/
                              /*~I:1252*/
                              if (byCommandStatus == INSTRUCTIONDECODER_SEND_NOTHING)
                              /*~-1*/
                              {
                              /*~I:1253*/
                              if (!GET_RESPONSE)
                              /*~-1*/
                              {
                              /*~A:1254*/
                              /*~+:Ausf�hrungsstatus auf 'OKAY' setzen*/
                              /*~+:*/
                              /*~T*/
                              // Ausf�hrungsstatus auf 'OKAY' setzen
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              /*~E:A1254*/
                              /*~A:1255*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~I:1256*/
#ifdef CHANNEL_0
                              /*~T*/
                              lText2Send = TEXT_INITIALIZATION;
                              /*~-1*/
#endif
                              /*~E:I1256*/
                              /*~E:A1255*/
                              /*~-1*/
                              }
                              /*~O:I1253*/
                              /*~-2*/
                              else
                              {
                              /*~K*/
                              /*~+:Fehler !!!*/
                              /*~A:1257*/
                              /*~+:Ausf�hrungsstatus auf 'E005' setzen*/
                              /*~I:1258*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~-1*/
#endif
                              /*~E:I1258*/
                              /*~E:A1257*/
                              /*~-1*/
                              }
                              /*~E:I1253*/
                              /*~-1*/
                              }
                              /*~O:I1252*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              // Fehler bei der Ausf�hrung eines Resets
                              /*~-1*/
                              }
                              /*~E:I1252*/
                           /*~-1*/
                           }
                           /*~O:I1245*/
                           /*~-2*/
                           else
                           {
                              /*~T*/
                              // Fehler beim einschalten der Temperaturkompensation
                           /*~-1*/
                           }
                           /*~E:I1245*/
                        /*~-1*/
                        }
                        /*~O:I1238*/
                        /*~-2*/
                        else
                        {
                           /*~A:1259*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1259*/
                        /*~-1*/
                        }
                        /*~E:I1238*/
                     /*~-1*/
                     }
                     /*~E:I1237*/
                     /*~E:A1236*/
                     /*~T*/
                     break;
                  /*~-1*/
                  }
                  /*~E:F1235*/
                  /*~E:A1234*/
                  /*~A:1260*/
                  /*~+:L*/
                  /*~F:1261*/
                  case 'L':
                  /*~-1*/
                  {
                     /*~A:1262*/
                     /*~+:LED - LED-testmode*/
                     /*~I:1263*/
                     if (!strcmp(szCommand,"LED"))
                     /*~-1*/
                     {
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:1264*/
#ifdef CHANNEL_0
                        /*~I:1265*/
                        if (!InstructionDecoder_CheckNbParameters(2,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~I:1266*/
                           if (!Communication_GetLongParameter(0))
                           /*~-1*/
                           {
                              /*~T*/
                              // Test-Mode f�r LEDs verlassen
                              Digital_ClearLEDTestMode();
                              /*~A:1267*/
                              /*~+:Textausgabe*/
                              /*~T*/
                              // Textausgabe
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              lText2Send = TEXT_LED_TESTMODE_CLEARED;
                              /*~E:A1267*/
                           /*~-1*/
                           }
                           /*~O:I1266*/
                           /*~-2*/
                           else
                           {
                              /*~T*/
                              Parameter[1].nLong = Communication_GetLongParameter(1);

                              // zun�chst alle LEDs l�schen
                              Digital_SetLEDManually(0xFF,FALSE);
                              // gew�nschte LEDs einschalten
                              Digital_SetLEDManually(Parameter[1].nLong,TRUE); 
                              /*~A:1268*/
                              /*~+:Textausgabe*/
                              /*~T*/
                              // Textausgabe
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              lText2Send = TEXT_LED_TESTMODE_SET;
                              /*~E:A1268*/
                           /*~-1*/
                           }
                           /*~E:I1266*/
                        /*~-1*/
                        }
                        /*~E:I1265*/
                        /*~-1*/
#endif
                        /*~E:I1264*/
                     /*~-1*/
                     }
                     /*~E:I1263*/
                     /*~T*/
                     break;
                     /*~E:A1262*/
                  /*~-1*/
                  }
                  /*~E:F1261*/
                  /*~E:A1260*/
                  /*~A:1269*/
                  /*~+:N*/
                  /*~F:1270*/
                  case 'N':
                  /*~-1*/
                  {
                     /*~A:1271*/
                     /*~+:NOP - NoOperation*/
                     /*~I:1272*/
                     if (!strcmp(szCommand,"NOP"))
                     /*~-1*/
                     {
                        /*~A:1273*/
                        /*~+:Kanal 0*/
                        /*~I:1274*/
#ifdef CHANNEL_0
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                        lText2Send = 0;
                        /*~I:1275*/
                        if (!InstructionDecoder_CheckNbParameters(0,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~I:1276*/
                           if (!SYSTEM_MRW_MANAGER)
                           /*~-1*/
                           {
                              /*~T*/
                              Communication_SendString(COMMUNICATION_RS232,"OK",0,0);
                           /*~-1*/
                           }
                           /*~E:I1276*/
                        /*~-1*/
                        }
                        /*~O:I1275*/
                        /*~-2*/
                        else
                        {
                           /*~A:1277*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1277*/
                        /*~-1*/
                        }
                        /*~E:I1275*/
                        /*~-1*/
#endif
                        /*~E:I1274*/
                        /*~E:A1273*/
                        /*~A:1278*/
                        /*~+:Kanal 1*/
                        /*~I:1279*/
#ifdef CHANNEL_1
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~-1*/
#endif
                        /*~E:I1279*/
                        /*~E:A1278*/
                     /*~-1*/
                     }
                     /*~E:I1272*/
                     /*~E:A1271*/
                     /*~T*/
                     break;
                  /*~-1*/
                  }
                  /*~E:F1270*/
                  /*~E:A1269*/
                  /*~A:1280*/
                  /*~+:R*/
                  /*~F:1281*/
                  case 'R':
                  /*~-1*/
                  {
                     /*~A:1282*/
                     /*~+:RCW - ReadChanelWeight*/
                     /*~I:1283*/
                     if ((!strcmp(szCommand,"RCW"))||(!strcmp(szCommand,"RDW")))
                     /*~-1*/
                     {
                        /*~I:1284*/
                        if (g_chRCWLast)
                        /*~-1*/
                        {
                           /*~T*/
                           g_chRCWLast = 0;
                        /*~-1*/
                        }
                        /*~O:I1284*/
                        /*~-2*/
                        else
                        {
                           /*~T*/
                           g_chRCWLast = 1;
                        /*~-1*/
                        }
                        /*~E:I1284*/
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:1285*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0); 
                           /*~C:1286*/
                           switch (Parameter[0].nLong)
                           /*~-1*/
                           {
                              /*~F:1287*/
                              case 0:
                              /*~-1*/
                              {
                              /*~A:1288*/
                              /*~+:Kanal 0*/
                              /*~I:1289*/
#ifdef CHANNEL_0
                              /*~T*/
                              Communication_SendFloat(COMMUNICATION_RS232,TEXT_MEASUREMENT_ACTUAL_WEIGHT_CHANNEL_0,Weight_NetWeight.fFloat,2,1,0);
                              /*~-1*/
#endif
                              /*~E:I1289*/
                              /*~E:A1288*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1287*/
                              /*~F:1290*/
                              case 1:
                              /*~-1*/
                              {
                              /*~A:1291*/
                              /*~+:Kanal 1*/
                              /*~I:1292*/
#ifdef CHANNEL_1
                              /*~T*/
                              Communication_SendFloat(COMMUNICATION_RS232,TEXT_MEASUREMENT_ACTUAL_WEIGHT_CHANNEL_1,Weight_NetWeight.fFloat,2,1,0);
                              /*~-1*/
#endif
                              /*~E:I1292*/
                              /*~E:A1291*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1290*/
                              /*~O:C1286*/
                              /*~-2*/
                              default:
                              {
                              /*~A:1293*/
                              /*~+:Kanal 0*/
                              /*~I:1294*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I1294*/
                              /*~E:A1293*/
                              /*~-1*/
                              }
                           /*~-1*/
                           }
                           /*~E:C1286*/
                        /*~-1*/
                        }
                        /*~O:I1285*/
                        /*~-2*/
                        else
                        {
                           /*~A:1295*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1295*/
                        /*~-1*/
                        }
                        /*~E:I1285*/
                     /*~-1*/
                     }
                     /*~E:I1283*/
                     /*~E:A1282*/
                     /*~I:1296*/
#ifdef MOF
                     /*~A:1297*/
                     /*~+:RCW - ReadChanelWeight*/
                     /*~I:1298*/
                     if (!strcmp(szCommand,"RCW"))
                     /*~-1*/
                     {
                        /*~I:1299*/
                        if (g_chRCWLast)
                        /*~-1*/
                        {
                           /*~T*/
                           g_chRCWLast = 0;
                        /*~-1*/
                        }
                        /*~O:I1299*/
                        /*~-2*/
                        else
                        {
                           /*~T*/
                           g_chRCWLast = 1;
                        /*~-1*/
                        }
                        /*~E:I1299*/
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:1300*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0); 
                           /*~C:1301*/
                           switch (Parameter[0].nLong)
                           /*~-1*/
                           {
                              /*~F:1302*/
                              case 0:
                              /*~-1*/
                              {
                              /*~A:1303*/
                              /*~+:Kanal 0*/
                              /*~I:1304*/
#ifdef CHANNEL_0
                              /*~T*/
                              Communication_SendFloat(COMMUNICATION_RS232,TEXT_MEASUREMENT_ACTUAL_WEIGHT_CHANNEL_0,Weight_NetWeight.fFloat,2,1,0);
                              /*~-1*/
#endif
                              /*~E:I1304*/
                              /*~E:A1303*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1302*/
                              /*~F:1305*/
                              case 1:
                              /*~-1*/
                              {
                              /*~A:1306*/
                              /*~+:Kanal 1*/
                              /*~I:1307*/
#ifdef CHANNEL_1
                              /*~T*/
                              Communication_SendFloat(COMMUNICATION_RS232,TEXT_MEASUREMENT_ACTUAL_WEIGHT_CHANNEL_1,Weight_NetWeight.fFloat,2,1,0);
                              /*~-1*/
#endif
                              /*~E:I1307*/
                              /*~E:A1306*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1305*/
                              /*~O:C1301*/
                              /*~-2*/
                              default:
                              {
                              /*~A:1308*/
                              /*~+:Kanal 0*/
                              /*~I:1309*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I1309*/
                              /*~E:A1308*/
                              /*~-1*/
                              }
                           /*~-1*/
                           }
                           /*~E:C1301*/
                        /*~-1*/
                        }
                        /*~O:I1300*/
                        /*~-2*/
                        else
                        {
                           /*~A:1310*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1310*/
                        /*~-1*/
                        }
                        /*~E:I1300*/
                     /*~-1*/
                     }
                     /*~E:I1298*/
                     /*~E:A1297*/
                     /*~-1*/
#endif
                     /*~E:I1296*/
                     /*~A:1311*/
                     /*~+:RDM - ReaDMeasurement*/
                     /*~I:1312*/
                     if (!strcmp(szCommand,"RDM"))
                     /*~-1*/
                     {
                        /*~T*/
                        g_chRCWLast = 0;
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:1313*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0); 
                           /*~C:1314*/
                           switch (Parameter[0].nLong)
                           /*~-1*/
                           {
                              /*~F:1315*/
                              case 0:
                              /*~-1*/
                              {
                              /*~A:1316*/
                              /*~+:Kanal 0*/
                              /*~I:1317*/
#ifdef CHANNEL_0
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_ACTUAL_MEASUREMENT_CHANNEL_0,Weight_ZeroCorrectedMeasurement.nLong,1,0);

                              /*~-1*/
#endif
                              /*~E:I1317*/
                              /*~E:A1316*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1315*/
                              /*~F:1318*/
                              case 1:
                              /*~-1*/
                              {
                              /*~A:1319*/
                              /*~+:Kanal 1*/
                              /*~I:1320*/
#ifdef CHANNEL_1
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_ACTUAL_MEASUREMENT_CHANNEL_1,Weight_ZeroCorrectedMeasurement.nLong,1,0);
                              /*~-1*/
#endif
                              /*~E:I1320*/
                              /*~E:A1319*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1318*/
                              /*~O:C1314*/
                              /*~-2*/
                              default:
                              {
                              /*~A:1321*/
                              /*~+:Kanal 0*/
                              /*~I:1322*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I1322*/
                              /*~E:A1321*/
                              /*~-1*/
                              }
                           /*~-1*/
                           }
                           /*~E:C1314*/
                        /*~-1*/
                        }
                        /*~O:I1313*/
                        /*~-2*/
                        else
                        {
                           /*~A:1323*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1323*/
                        /*~-1*/
                        }
                        /*~E:I1313*/
                     /*~-1*/
                     }
                     /*~E:I1312*/
                     /*~E:A1311*/
                     /*~A:1324*/
                     /*~+:RDS - ReaDStatus (nur aus Kompatibilit�tsgr�nden zur MRW-Manager-Software)*/
                     /*~I:1325*/
                     if (!strcmp(szCommand,"RDS"))
                     /*~-1*/
                     {
                        /*~A:1326*/
                        /*~+:Variablendeklarationen*/
                        /*~T*/
                        unsigned char byStatus2Set;
                        /*~E:A1326*/
                        /*~A:1327*/
                        /*~+:Variableninitialisierungen*/
                        /*~T*/
                        byStatus2Set = 0;
                        /*~E:A1327*/
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:1328*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~I:1329*/
                           if (SYSTEM_MRW_MANAGER)
                           /*~-1*/
                           {
                              /*~T*/
                              Parameter[0].nLong = Communication_GetLongParameter(0); 
                              /*~C:1330*/
                              switch (Parameter[0].nLong)
                              /*~-1*/
                              {
                              /*~F:1331*/
                              case 0:
                              /*~-1*/
                              {
                              /*~A:1332*/
                              /*~+:Kanal 0*/
                              /*~I:1333*/
#ifdef CHANNEL_0
                              /*~I:1334*/
#ifdef MIT_TARATEACH_VIA_RS232
                              /*~T*/
                              byStatus2Set |= 0x01;
                              /*~-1*/
#endif
                              /*~E:I1334*/
                              /*~I:1335*/
#ifdef MIT_LIMITTEACH_VIA_RS232
                              /*~T*/
                              byStatus2Set |= 0x02;
                              /*~-1*/
#endif
                              /*~E:I1335*/
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,0,byStatus2Set,0,0);

                              /*~-1*/
#endif
                              /*~E:I1333*/
                              /*~E:A1332*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1331*/
                              /*~F:1336*/
                              case 1:
                              /*~-1*/
                              {
                              /*~A:1337*/
                              /*~+:Kanal 1*/
                              /*~I:1338*/
#ifdef CHANNEL_1
                              /*~I:1339*/
#ifdef MIT_TARATEACH_VIA_RS232
                              /*~T*/
                              byStatus2Set |= 0x01;
                              /*~-1*/
#endif
                              /*~E:I1339*/
                              /*~I:1340*/
#ifdef MIT_LIMITTEACH_VIA_RS232
                              /*~T*/
                              byStatus2Set |= 0x02;
                              /*~-1*/
#endif
                              /*~E:I1340*/
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,0,byStatus2Set,0,0);

                              /*~-1*/
#endif
                              /*~E:I1338*/
                              /*~E:A1337*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1336*/
                              /*~O:C1330*/
                              /*~-2*/
                              default:
                              {
                              /*~A:1341*/
                              /*~+:Kanal 0*/
                              /*~I:1342*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I1342*/
                              /*~E:A1341*/
                              /*~-1*/
                              }
                              /*~-1*/
                              }
                              /*~E:C1330*/
                           /*~-1*/
                           }
                           /*~E:I1329*/
                        /*~-1*/
                        }
                        /*~O:I1328*/
                        /*~-2*/
                        else
                        {
                           /*~A:1343*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1343*/
                        /*~-1*/
                        }
                        /*~E:I1328*/
                     /*~-1*/
                     }
                     /*~E:I1325*/
                     /*~E:A1324*/
                     /*~A:1344*/
                     /*~+:RDW - ReaDWeight*/
                     /*~K*/
                     /*~+:RDW -> RCW*/
                     /*~E:A1344*/
                     /*~A:1345*/
                     /*~+:RDI - ReadDacInput*/
                     /*~I:1346*/
                     if (!strcmp(szCommand,"RDI"))
                     /*~-1*/
                     {
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:1347*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0); 
                           /*~C:1348*/
                           switch (Parameter[0].nLong)
                           /*~-1*/
                           {
                              /*~F:1349*/
                              case 0:
                              /*~-1*/
                              {
                              /*~A:1350*/
                              /*~+:Kanal 0*/
                              /*~I:1351*/
#ifdef CHANNEL_0
                              /*~T*/
                              // Communication_SendLong(COMMUNICATION_RS232,TEXT_CURRENT_INTERFACE_ACTUAL_DAC_INPUT_CHANNEL_0,Weight_ZeroCorrectedMeasurementWithTare.nLong  + g_lWeightOffset4Limitest,1,0);

                              Communication_SendLong(COMMUNICATION_RS232,TEXT_CURRENT_INTERFACE_ACTUAL_DAC_INPUT_CHANNEL_0,ADuC836_DACGetValue2Convert(),1,0);
                              /*~-1*/
#endif
                              /*~E:I1351*/
                              /*~E:A1350*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1349*/
                              /*~F:1352*/
                              case 1:
                              /*~-1*/
                              {
                              /*~A:1353*/
                              /*~+:Kanal 1*/
                              /*~I:1354*/
#ifdef CHANNEL_1
                              /*~T*/
                              // Communication_SendLong(COMMUNICATION_RS232,TEXT_CURRENT_INTERFACE_ACTUAL_DAC_INPUT_CHANNEL_1,Weight_ZeroCorrectedMeasurementWithTare.nLong + g_lWeightOffset4Limitest,1,0);

                              Communication_SendLong(COMMUNICATION_RS232,TEXT_CURRENT_INTERFACE_ACTUAL_DAC_INPUT_CHANNEL_1,ADuC836_DACGetValue2Convert(),1,0);
                              /*~-1*/
#endif
                              /*~E:I1354*/
                              /*~E:A1353*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1352*/
                              /*~O:C1348*/
                              /*~-2*/
                              default:
                              {
                              /*~A:1355*/
                              /*~+:Kanal 0*/
                              /*~I:1356*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I1356*/
                              /*~E:A1355*/
                              /*~-1*/
                              }
                           /*~-1*/
                           }
                           /*~E:C1348*/
                        /*~-1*/
                        }
                        /*~O:I1347*/
                        /*~-2*/
                        else
                        {
                           /*~A:1357*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1357*/
                        /*~-1*/
                        }
                        /*~E:I1347*/
                     /*~-1*/
                     }
                     /*~E:I1346*/
                     /*~E:A1345*/
                     /*~A:1358*/
                     /*~+:RMA - ReadMeasurementfromAdc*/
                     /*~I:1359*/
                     if (!strcmp(szCommand,"RMA"))
                     /*~-1*/
                     {
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:1360*/
                        if (!InstructionDecoder_CheckNbParameters(2,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0);
                           Parameter[1].nLong = Communication_GetLongParameter(1); 
                           /*~C:1361*/
                           switch (Parameter[0].nLong)
                           /*~-1*/
                           {
                              /*~F:1362*/
                              case 0:
                              /*~-1*/
                              {
                              /*~A:1363*/
                              /*~+:Kanal 0*/
                              /*~I:1364*/
#ifdef CHANNEL_0
                              /*~C:1365*/
                              switch (Parameter[1].nLong)
                              /*~-1*/
                              {
                              /*~F:1366*/
                              case 0:
                              case 2:
                              /*~-1*/
                              {
                              /*~I:1367*/
                              if (Parameter[1].nLong == 2)
                              /*~-1*/
                              {
                              /*~T*/
                              // aktuellen Rohmesswert vom ADC speichern
                              Save_Parameter(LOAD_SAVE_WEIGHT_MEASUREMENT_FROM_ADC,&Weight_MeasurementFromADC.nLong,4);
                              /*~-1*/
                              }
                              /*~E:I1367*/
                              /*~T*/
                              // und ausgeben
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_ADC_ACTUAL_MEASUREMENT_CHANNEL_0,Weight_MeasurementFromADC.nLong,0,1);

                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1366*/
                              /*~F:1368*/
                              case 1:
                              /*~-1*/
                              {
                              /*~T*/
                              // gespeicherten Rohmesswert vom ADC auslesen
                              /*~T*/
                              Load_Parameter(LOAD_SAVE_WEIGHT_MEASUREMENT_FROM_ADC,&Weight_MeasurementFromADC.nLong,4);
                              /*~T*/
                              // und ausgeben
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_ADC_STORED_MEASUREMENT_CHANNEL_0,Weight_MeasurementFromADC.nLong,0,1);

                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1368*/
                              /*~F:1369*/
                              case 3:
                              /*~-1*/
                              {
                              /*~T*/
                              // und ausgeben
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_ADC_ACTUAL_FB_MEASUREMENT_CHANNEL_0,g_CurrentInterface.FeedBack.Results.FilteredMeasurementFromADC.nLong,0,1);

                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1369*/
                              /*~O:C1365*/
                              /*~-2*/
                              default:
                              {
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E002;
                              /*~-1*/
                              }
                              /*~-1*/
                              }
                              /*~E:C1365*/
                              /*~-1*/
#endif
                              /*~E:I1364*/
                              /*~E:A1363*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1362*/
                              /*~F:1370*/
                              case 1:
                              /*~-1*/
                              {
                              /*~A:1371*/
                              /*~+:Kanal 1*/
                              /*~I:1372*/
#ifdef CHANNEL_1
                              /*~C:1373*/
                              switch (Parameter[1].nLong)
                              /*~-1*/
                              {
                              /*~F:1374*/
                              case 0:
                              case 2:
                              /*~-1*/
                              {
                              /*~I:1375*/
                              if (Parameter[1].nLong == 2)
                              /*~-1*/
                              {
                              /*~T*/
                              // aktuellen Rohmesswert vom ADC speichern
                              Save_Parameter(LOAD_SAVE_WEIGHT_MEASUREMENT_FROM_ADC,&Weight_MeasurementFromADC.nLong,4);
                              /*~-1*/
                              }
                              /*~E:I1375*/
                              /*~T*/
                              // und ausgeben
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_ADC_ACTUAL_MEASUREMENT_CHANNEL_1,Weight_MeasurementFromADC.nLong,0,1);

                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1374*/
                              /*~F:1376*/
                              case 1:
                              /*~-1*/
                              {
                              /*~T*/
                              // gespeicherten Rohmesswert vom ADC auslesen
                              /*~T*/
                              Load_Parameter(LOAD_SAVE_WEIGHT_MEASUREMENT_FROM_ADC,&Weight_MeasurementFromADC.nLong,4);
                              /*~T*/
                              // und ausgeben
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_ADC_STORED_MEASUREMENT_CHANNEL_1,Weight_MeasurementFromADC.nLong,0,1);

                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1376*/
                              /*~F:1377*/
                              case 3:
                              /*~-1*/
                              {
                              /*~T*/
                              // und ausgeben
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_ADC_ACTUAL_FB_MEASUREMENT_CHANNEL_1,g_CurrentInterface.FeedBack.Results.FilteredMeasurementFromADC.nLong,0,1);

                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1377*/
                              /*~O:C1373*/
                              /*~-2*/
                              default:
                              {
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E002;
                              /*~-1*/
                              }
                              /*~-1*/
                              }
                              /*~E:C1373*/
                              /*~-1*/
#endif
                              /*~E:I1372*/
                              /*~E:A1371*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1370*/
                              /*~O:C1361*/
                              /*~-2*/
                              default:
                              {
                              /*~A:1378*/
                              /*~+:Kanal 0*/
                              /*~I:1379*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I1379*/
                              /*~E:A1378*/
                              /*~-1*/
                              }
                           /*~-1*/
                           }
                           /*~E:C1361*/
                        /*~-1*/
                        }
                        /*~O:I1360*/
                        /*~-2*/
                        else
                        {
                           /*~A:1380*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1380*/
                        /*~-1*/
                        }
                        /*~E:I1360*/
                     /*~-1*/
                     }
                     /*~E:I1359*/
                     /*~E:A1358*/
                     /*~I:1381*/
#ifdef MOF
                     /*~A:1382*/
                     /*~+:RMF - ReadMotionFilter*/
                     /*~I:1383*/
                     if (!strcmp(szCommand,"RMF"))
                     /*~-1*/
                     {
                        /*~A:1384*/
                        /*~+:Variablendeklarationen*/
                        /*~T*/
                        MEASUREMENT_MOTIONPARAMETER MotionParameter;

                        /*~I:1385*/
#ifdef CHANNEL_0
                        /*~T*/
                        long lMotionFilterPartner;
                        /*~-1*/
#endif
                        /*~E:I1385*/
                        /*~E:A1384*/
                        /*~A:1386*/
                        /*~+:Variableninitialisierungen*/
                        /*~T*/

                        /*~E:A1386*/
                        /*~T*/
                        // Text wurde bereits gesendet
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:1387*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           // Parameter auslesen
                           Parameter[0].nLong = Communication_GetLongParameter(0);

                           // Motionparameter auslesen
                           Weight_GetMotionParameter(&MotionParameter);
                           /*~I:1388*/
                           if (Parameter[0].nLong <= 1)
                           /*~-1*/
                           {
                              /*~I:1389*/
#ifdef CHANNEL_0
                              /*~I:1390*/
                              if (!Communication_GetSPIValue(COMMUNICATION_MOTION_FILTER,&lMotionFilterPartner))
                              /*~-1*/
                              {
                              /*~C:1391*/
                              switch (Parameter[0].nLong)
                              /*~-1*/
                              {
                              /*~F:1392*/
                              case 0: // Filter f�r Gewichtsbewegung
                              /*~-1*/
                              {
                              /*~I:1393*/
                              if (lMotionFilterPartner == MotionParameter.byMotionFilter)
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_MEASUREMENT_MOTIONFILTER_CHANNEL_0,MotionParameter.byMotionFilter,1,0);
                              /*~-1*/
                              }
                              /*~O:I1393*/
                              /*~-2*/
                              else
                              {
                              /*~A:1394*/
                              /*~+:Fehler - Werte beider Kan�le sind nicht identisch - E011*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E011;
                              /*~E:A1394*/
                              /*~-1*/
                              }
                              /*~E:I1393*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1392*/
                              /*~F:1395*/
                              case 1: // Filter f�r Gewichtsberuhigung
                              /*~-1*/
                              {
                              /*~I:1396*/
                              if (lMotionFilterPartner == MotionParameter.byNoMotionFilter)
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_MEASUREMENT_NOMOTIONFILTER_CHANNEL_0,MotionParameter.byNoMotionFilter,1,0);
                              /*~-1*/
                              }
                              /*~O:I1396*/
                              /*~-2*/
                              else
                              {
                              /*~A:1397*/
                              /*~+:Fehler - Werte beider Kan�le sind nicht identisch - E011*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E011;
                              /*~E:A1397*/
                              /*~-1*/
                              }
                              /*~E:I1396*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1395*/
                              /*~-1*/
                              }
                              /*~E:C1391*/
                              /*~-1*/
                              }
                              /*~O:I1390*/
                              /*~-2*/
                              else
                              {
                              /*~A:1398*/
                              /*~+:Fehler bei der Kommunikation - E005*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A1398*/
                              /*~-1*/
                              }
                              /*~E:I1390*/
                              /*~O:I1389*/
                              /*~-1*/
#else
                              /*~I:1399*/
#ifdef CHANNEL_1
                              /*~C:1400*/
                              switch (Parameter[0].nLong)
                              /*~-1*/
                              {
                              /*~F:1401*/
                              case 0:
                              /*~-1*/
                              {
                              /*~T*/
                              InstructionDecoder_StoreValue(COMMUNICATION_MOTION_FILTER,(GLOBAL_UNIVALUE_SHORT*)&MotionParameter.byMotionFilter);
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1401*/
                              /*~F:1402*/
                              case 1:
                              /*~-1*/
                              {
                              /*~T*/
                              InstructionDecoder_StoreValue(COMMUNICATION_MOTION_FILTER,(GLOBAL_UNIVALUE_SHORT*)&MotionParameter.byNoMotionFilter);
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1402*/
                              /*~-1*/
                              }
                              /*~E:C1400*/
                              /*~-1*/
#endif
                              /*~E:I1399*/
                              /*~-1*/
#endif
                              /*~E:I1389*/
                           /*~-1*/
                           }
                           /*~O:I1388*/
                           /*~-2*/
                           else
                           {
                              /*~I:1403*/
#ifdef CHANNEL_0
                              /*~A:1404*/
                              /*~+:Parameter liegt au�erhalb der Grenzen - E002*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E002;
                              /*~E:A1404*/
                              /*~-1*/
#endif
                              /*~E:I1403*/
                           /*~-1*/
                           }
                           /*~E:I1388*/
                        /*~-1*/
                        }
                        /*~O:I1387*/
                        /*~-2*/
                        else
                        {
                           /*~A:1405*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1405*/
                        /*~-1*/
                        }
                        /*~E:I1387*/
                     /*~-1*/
                     }
                     /*~E:I1383*/
                     /*~E:A1382*/
                     /*~-1*/
#endif
                     /*~E:I1381*/
                     /*~A:1406*/
                     /*~+:RML - ReadMotionLimit*/
                     /*~I:1407*/
                     if (!strcmp(szCommand,"RML"))
                     /*~-1*/
                     {
                        /*~A:1408*/
                        /*~+:Variablendeklarationen*/
                        /*~T*/
                        MEASUREMENT_MOTIONPARAMETER MotionParameter;

                        /*~I:1409*/
#ifdef CHANNEL_0
                        /*~T*/
                        float fMotionLimitPartner;
                        /*~-1*/
#endif
                        /*~E:I1409*/
                        /*~E:A1408*/
                        /*~A:1410*/
                        /*~+:Variableninitialisierungen*/
                        /*~T*/

                        /*~E:A1410*/
                        /*~T*/
                        // Text wurde bereits gesendet
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:1411*/
                        if (!InstructionDecoder_CheckNbParameters(0,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           // Motionparameter auslesen
                           Weight_GetMotionParameter(&MotionParameter);
                           /*~I:1412*/
#ifdef CHANNEL_0
                           /*~I:1413*/
                           if (!Communication_GetSPIValue(COMMUNICATION_MOTION_LIMIT,&fMotionLimitPartner))
                           /*~-1*/
                           {
                              /*~I:1414*/
                              if (fMotionLimitPartner == MotionParameter.fMotionLimit)
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendFloat(COMMUNICATION_RS232,TEXT_MEASUREMENT_MOTIONLIMIT_CHANNEL_0,MotionParameter.fMotionLimit,2,1,0);
                              /*~-1*/
                              }
                              /*~O:I1414*/
                              /*~-2*/
                              else
                              {
                              /*~A:1415*/
                              /*~+:Fehler - Werte beider Kan�le sind nicht identisch - E011*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E011;
                              /*~E:A1415*/
                              /*~-1*/
                              }
                              /*~E:I1414*/
                           /*~-1*/
                           }
                           /*~O:I1413*/
                           /*~-2*/
                           else
                           {
                              /*~A:1416*/
                              /*~+:Fehler bei der Kommunikation - E005*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A1416*/
                           /*~-1*/
                           }
                           /*~E:I1413*/
                           /*~O:I1412*/
                           /*~-1*/
#else
                           /*~I:1417*/
#ifdef CHANNEL_1
                           /*~T*/
                           InstructionDecoder_StoreValue(COMMUNICATION_MOTION_LIMIT,(GLOBAL_UNIVALUE_SHORT*)&MotionParameter.fMotionLimit);
                           /*~-1*/
#endif
                           /*~E:I1417*/
                           /*~-1*/
#endif
                           /*~E:I1412*/
                        /*~-1*/
                        }
                        /*~O:I1411*/
                        /*~-2*/
                        else
                        {
                           /*~A:1418*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1418*/
                        /*~-1*/
                        }
                        /*~E:I1411*/
                     /*~-1*/
                     }
                     /*~E:I1407*/
                     /*~E:A1406*/
                     /*~A:1419*/
                     /*~+:RMT - ReadMotionTimer*/
                     /*~I:1420*/
                     if (!strcmp(szCommand,"RMT"))
                     /*~-1*/
                     {
                        /*~A:1421*/
                        /*~+:Variablendeklarationen*/
                        /*~T*/
                        MEASUREMENT_MOTIONPARAMETER MotionParameter;

                        /*~I:1422*/
#ifdef CHANNEL_0
                        /*~T*/
                        long lMotionFilterPartner;
                        /*~-1*/
#endif
                        /*~E:I1422*/
                        /*~E:A1421*/
                        /*~A:1423*/
                        /*~+:Variableninitialisierungen*/
                        /*~T*/

                        /*~E:A1423*/
                        /*~T*/
                        // Text wurde bereits gesendet
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:1424*/
                        if (!InstructionDecoder_CheckNbParameters(0,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           // Motionparameter auslesen
                           Weight_GetMotionParameter(&MotionParameter);
                           /*~I:1425*/
#ifdef CHANNEL_0
                           /*~I:1426*/
                           if (!Communication_GetSPIValue(COMMUNICATION_MOTION_FILTER,&lMotionFilterPartner))
                           /*~-1*/
                           {
                              /*~I:1427*/
                              if (lMotionFilterPartner == MotionParameter.byMotionFilter)
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_MEASUREMENT_MOTIONFILTER_CHANNEL_0,MotionParameter.byMotionFilter,1,0);
                              /*~-1*/
                              }
                              /*~O:I1427*/
                              /*~-2*/
                              else
                              {
                              /*~A:1428*/
                              /*~+:Fehler - Werte beider Kan�le sind nicht identisch - E011*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E011;
                              /*~E:A1428*/
                              /*~-1*/
                              }
                              /*~E:I1427*/
                           /*~-1*/
                           }
                           /*~O:I1426*/
                           /*~-2*/
                           else
                           {
                              /*~A:1429*/
                              /*~+:Fehler bei der Kommunikation - E005*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A1429*/
                           /*~-1*/
                           }
                           /*~E:I1426*/
                           /*~O:I1425*/
                           /*~-1*/
#else
                           /*~I:1430*/
#ifdef CHANNEL_1
                           /*~T*/
                           InstructionDecoder_StoreValue(COMMUNICATION_MOTION_FILTER,(GLOBAL_UNIVALUE_SHORT*)&MotionParameter.byMotionFilter);
                           /*~-1*/
#endif
                           /*~E:I1430*/
                           /*~-1*/
#endif
                           /*~E:I1425*/
                        /*~-1*/
                        }
                        /*~O:I1424*/
                        /*~-2*/
                        else
                        {
                           /*~A:1431*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1431*/
                        /*~-1*/
                        }
                        /*~E:I1424*/
                     /*~-1*/
                     }
                     /*~E:I1420*/
                     /*~E:A1419*/
                     /*~I:1432*/
#ifdef MOF
                     /*~A:1433*/
                     /*~+:RSS - ReaDrS232Statistics*/
                     /*~I:1434*/
                     if (!strcmp(szCommand,"RSS"))
                     /*~-1*/
                     {
                        /*~A:1435*/
                        /*~+:Variablendeklarationen*/
                        /*~T*/
                        RS232_STATISTICS_T Statistics;
                        unsigned char szString[32];
                        /*~E:A1435*/
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:1436*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0); 
                           /*~C:1437*/
                           switch (Parameter[0].nLong)
                           /*~-1*/
                           {
                              /*~F:1438*/
                              case 0:
                              /*~-1*/
                              {
                              /*~A:1439*/
                              /*~+:Kanal 0*/
                              /*~I:1440*/
#ifdef CHANNEL_0
                              /*~T*/
                              Statistics = ADuC836_RS232GetStatistics();
                              /*~I:1441*/
                              if (!SYSTEM_MRW_MANAGER)
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_RS232_STATISTICS_FRAMES_RECEIVED_CHANNEL_0,Statistics.ulETXCount,1,0);

                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_RS232_STATISTICS_ERRONEOUS_FRAMES_CHANNEL_0,Statistics.ulSTXCount - Statistics.ulETXCount,1,0);

                              /*~-1*/
                              }
                              /*~O:I1441*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              sprintf(szString,"%ld,%ld", Statistics.ulETXCount, Statistics.ulSTXCount - Statistics.ulETXCount);

                              Communication_SendString(COMMUNICATION_RS232,szString,0,0);
                              /*~-1*/
                              }
                              /*~E:I1441*/
                              /*~-1*/
#endif
                              /*~E:I1440*/
                              /*~E:A1439*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1438*/
                              /*~F:1442*/
                              case 1:
                              /*~-1*/
                              {
                              /*~A:1443*/
                              /*~+:Kanal 1*/
                              /*~I:1444*/
#ifdef CHANNEL_1
                              /*~T*/
                              Statistics = ADuC836_RS232GetStatistics();
                              /*~I:1445*/
                              if (!SYSTEM_MRW_MANAGER)
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_RS232_STATISTICS_FRAMES_RECEIVED_CHANNEL_1,Statistics.ulETXCount,1,0);

                              /*~T*/
                              Communication_SendLong(COMMUNICATION_RS232,TEXT_RS232_STATISTICS_ERRONEOUS_FRAMES_CHANNEL_1,Statistics.ulSTXCount - Statistics.ulETXCount,1,0);

                              /*~-1*/
                              }
                              /*~O:I1445*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              sprintf(szString,"%ld,%ld", Statistics.ulETXCount, Statistics.ulSTXCount - Statistics.ulETXCount);

                              Communication_SendString(COMMUNICATION_RS232,szString,0,0);
                              /*~-1*/
                              }
                              /*~E:I1445*/
                              /*~-1*/
#endif
                              /*~E:I1444*/
                              /*~E:A1443*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1442*/
                              /*~O:C1437*/
                              /*~-2*/
                              default:
                              {
                              /*~A:1446*/
                              /*~+:Kanal 0*/
                              /*~I:1447*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I1447*/
                              /*~E:A1446*/
                              /*~-1*/
                              }
                           /*~-1*/
                           }
                           /*~E:C1437*/
                        /*~-1*/
                        }
                        /*~O:I1436*/
                        /*~-2*/
                        else
                        {
                           /*~A:1448*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1448*/
                        /*~-1*/
                        }
                        /*~E:I1436*/
                     /*~-1*/
                     }
                     /*~E:I1434*/
                     /*~E:A1433*/
                     /*~-1*/
#endif
                     /*~E:I1432*/
                     /*~A:1449*/
                     /*~+:RST - ReSeT*/
                     /*~I:1450*/
                     if (!strcmp(szCommand,"RST"))
                     /*~-1*/
                     {
                        /*~T*/
                        // Text wurde bereits gesendet
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:1451*/
                        if (!InstructionDecoder_CheckNbParameters(0,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           System_Reset();
                        /*~-1*/
                        }
                        /*~O:I1451*/
                        /*~-2*/
                        else
                        {
                           /*~A:1452*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1452*/
                        /*~-1*/
                        }
                        /*~E:I1451*/
                     /*~-1*/
                     }
                     /*~E:I1450*/
                     /*~E:A1449*/
                     /*~T*/
                     break;
                  /*~-1*/
                  }
                  /*~E:F1281*/
                  /*~E:A1280*/
                  /*~A:1453*/
                  /*~+:S*/
                  /*~F:1454*/
                  case 'S':
                  /*~-1*/
                  {
                     /*~A:1455*/
                     /*~+:SAL - SetAlarmLimit*/
                     /*~I:1456*/
                     if (!strcmp(szCommand,"SAL"))
                     /*~-1*/
                     {
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;

                        /*~I:1457*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           // Parameter auslesen
                           Parameter[0].fFloat = Communication_GetFloatParameter(0);
                           /*~I:1458*/
                           if (!GET_RESPONSE)
                           /*~-1*/
                           {
                              /*~T*/
                              // Alles okay
                              // Alarmgrenzwert setzen
                              /*~I:1459*/
                              if (!Limit_SetAlarmLimitByWeight(0,Parameter[0].fFloat))
                              /*~-1*/
                              {
                              /*~A:1460*/
                              /*~+:Ausf�hrungsstatus auf 'OKAY' setzen*/
                              /*~+:*/
                              /*~T*/
                              // Ausf�hrungsstatus auf 'OKAY' setzen
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              /*~E:A1460*/
                              /*~A:1461*/
                              /*~+:Kanal 0 - Textausgabe*/
                              /*~I:1462*/
#ifdef CHANNEL_0
                              /*~T*/
                              // Textausgabe vornehmen
                              lText2Send = TEXT_LIMIT_TEACHED;
                              /*~-1*/
#endif
                              /*~E:I1462*/
                              /*~E:A1461*/
                              /*~-1*/
                              }
                              /*~O:I1459*/
                              /*~-2*/
                              else
                              {
                              /*~K*/
                              /*~+:Fehler !!!*/
                              /*~A:1463*/
                              /*~+:Ausf�hrungsstatus auf 'E005' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A1463*/
                              /*~-1*/
                              }
                              /*~E:I1459*/
                           /*~-1*/
                           }
                           /*~O:I1458*/
                           /*~-2*/
                           else
                           {
                              /*~K*/
                              /*~+:Fehler !!!*/
                              /*~A:1464*/
                              /*~+:Ausf�hrungsstatus auf 'E005' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A1464*/
                           /*~-1*/
                           }
                           /*~E:I1458*/
                        /*~-1*/
                        }
                        /*~O:I1457*/
                        /*~-2*/
                        else
                        {
                           /*~A:1465*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1465*/
                        /*~-1*/
                        }
                        /*~E:I1457*/
                     /*~-1*/
                     }
                     /*~E:I1456*/
                     /*~E:A1455*/
                     /*~A:1466*/
                     /*~+:SAN - SetAritcleNumber*/
                     /*~I:1467*/
                     if (!strcmp(szCommand,"SAN"))
                     /*~-1*/
                     {
                        /*~A:1468*/
                        /*~+:Variablendeklarationen*/
                        /*~T*/
                        char *szItemNumber;
                        /*~E:A1468*/
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:1469*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           szItemNumber = Communication_GetStringParameter(0);

                           /*~I:1470*/
                           if (!System_SetItemNumber(szItemNumber))
                           /*~-1*/
                           {
                              /*~A:1471*/
                              /*~+:Kanal 0 - Textausgabe*/
                              /*~I:1472*/
#ifdef CHANNEL_0 
                              /*~A:1473*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              lText2Send = TEXT_ITEM_NUMBER_SET;
                              /*~E:A1473*/
                              /*~-1*/
#endif
                              /*~E:I1472*/
                              /*~E:A1471*/
                           /*~-1*/
                           }
                           /*~O:I1470*/
                           /*~-2*/
                           else
                           {
                              /*~K*/
                              /*~+:Fehler !!!*/
                              /*~I:1474*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~-1*/
#endif
                              /*~E:I1474*/
                           /*~-1*/
                           }
                           /*~E:I1470*/
                        /*~-1*/
                        }
                        /*~O:I1469*/
                        /*~-2*/
                        else
                        {
                           /*~A:1475*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1475*/
                        /*~-1*/
                        }
                        /*~E:I1469*/
                     /*~-1*/
                     }
                     /*~E:I1467*/
                     /*~E:A1466*/
                     /*~I:1476*/
                     /* ab Version V1.008 v. 11.08.2015 */
#ifdef MIT_ADC_BURNOUT_TEST
                     /*~A:1477*/
                     /*~+:SBO - SetBurnOut_onoff*/
                     /*~I:1478*/
                     if (!strcmp(szCommand,"SBO"))
                     /*~-1*/
                     {
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;

                        /*~I:1479*/
                        if (!InstructionDecoder_CheckNbParameters(2,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           // Parameter auslesen
                           Parameter[0].nLong = Communication_GetLongParameter(0);
                           Parameter[1].nLong = Communication_GetLongParameter(1);
                           /*~C:1480*/
                           switch (Parameter[0].nLong)
                           /*~-1*/
                           {
                              /*~F:1481*/
                              case 0:
                              /*~-1*/
                              {
                              /*~A:1482*/
                              /*~+:Kanal 0*/
                              /*~I:1483*/
#ifdef CHANNEL_0
                              /*~T*/
                              // Current burnout mode setzen
                              byRetVal = ADuC836_ADCSetBurnOutMode((unsigned char)Parameter[1].nLong);
                              /*~I:1484*/
                              if (byRetVal != (unsigned char)Parameter[1].nLong)
                              /*~-1*/
                              {
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~-1*/
                              }
                              /*~O:I1484*/
                              /*~-2*/
                              else
                              {
                              /*~A:1485*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              /*~I:1486*/
                              if (byRetVal)
                              /*~-1*/
                              {
                              /*~T*/
                              lText2Send = TEXT_ADC_BURNOUTMODE_SET_CHANEL_0;
                              /*~-1*/
                              }
                              /*~O:I1486*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              lText2Send = TEXT_ADC_BURNOUTMODE_CLEARED_CHANEL_0;
                              /*~-1*/
                              }
                              /*~E:I1486*/
                              /*~E:A1485*/
                              /*~-1*/
                              }
                              /*~E:I1484*/
                              /*~-1*/
#endif
                              /*~E:I1483*/
                              /*~E:A1482*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1481*/
                              /*~F:1487*/
                              case 1:
                              /*~-1*/
                              {
                              /*~A:1488*/
                              /*~+:Kanal 1*/
                              /*~I:1489*/
#ifdef CHANNEL_1
                              /*~T*/
                              // Current burnout mode setzen
                              byRetVal = ADuC836_ADCSetBurnOutMode((unsigned char)Parameter[1].nLong);
                              /*~I:1490*/
                              if (byRetVal != (unsigned char)Parameter[1].nLong)
                              /*~-1*/
                              {
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~-1*/
                              }
                              /*~O:I1490*/
                              /*~-2*/
                              else
                              {
                              /*~A:1491*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              /*~I:1492*/
                              if (byRetVal)
                              /*~-1*/
                              {
                              /*~T*/
                              lText2Send = TEXT_ADC_BURNOUTMODE_SET_CHANEL_1;
                              /*~-1*/
                              }
                              /*~O:I1492*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              lText2Send = TEXT_ADC_BURNOUTMODE_CLEARED_CHANEL_1;
                              /*~-1*/
                              }
                              /*~E:I1492*/
                              /*~E:A1491*/
                              /*~-1*/
                              }
                              /*~E:I1490*/
                              /*~-1*/
#endif
                              /*~E:I1489*/
                              /*~E:A1488*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1487*/
                              /*~O:C1480*/
                              /*~-2*/
                              default:
                              {
                              /*~A:1493*/
                              /*~+:Kanal 0*/
                              /*~I:1494*/
#ifdef CHANEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I1494*/
                              /*~E:A1493*/
                              /*~-1*/
                              }
                           /*~-1*/
                           }
                           /*~E:C1480*/
                        /*~-1*/
                        }
                        /*~O:I1479*/
                        /*~-2*/
                        else
                        {
                           /*~A:1495*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1495*/
                        /*~-1*/
                        }
                        /*~E:I1479*/
                     /*~-1*/
                     }
                     /*~E:I1478*/
                     /*~E:A1477*/
                     /*~-1*/
#endif
                     /*~E:I1476*/
                     /*~I:1496*/
#ifdef SYSTEM_CND_VARIABLE_BAUDRATE
                     /*~A:1497*/
                     /*~+:SBR - SetBaudRate*/
                     /*~I:1498*/
                     if (!strcmp(szCommand,"SBR"))
                     /*~-1*/
                     {
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;

                        /*~I:1499*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0);

                           /*~I:1500*/
                           if ((Parameter[0].nLong == 9600)||(Parameter[0].nLong == 19200)||(Parameter[0].nLong == 38400)||(Parameter[0].nLong == 57600))
                           /*~-1*/
                           {
                              /*~I:1501*/
                              if (!GET_RESPONSE)
                              /*~-1*/
                              {
                              /*~T*/
                              // Alles okay
                              /*~K*/
                              /*~+:*/
                              /*~T*/
                              ADuC836_RS232SetBaudrate(Parameter[0].nLong);
                              /*~T*/
                              // Alles okay
                              // und Wert abspeichern
                              Save_Parameter(LOAD_SAVE_RS232_BAUDRATE,&Parameter[0].nLong,0);
                              /*~A:1502*/
                              /*~+:Ausf�hrungsstatus auf 'OKAY' setzen*/
                              /*~+:*/
                              /*~T*/
                              // Ausf�hrungsstatus auf 'OKAY' setzen
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              /*~E:A1502*/
                              /*~A:1503*/
                              /*~+:Kanal 0 - Textausgabe*/
                              /*~I:1504*/
#ifdef CHANNEL_0 
                              /*~A:1505*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              lText2Send = TEXT_RS232_BAUDRATE_SET;
                              /*~E:A1505*/
                              /*~-1*/
#endif
                              /*~E:I1504*/
                              /*~E:A1503*/
                              /*~-1*/
                              }
                              /*~O:I1501*/
                              /*~-2*/
                              else
                              {
                              /*~K*/
                              /*~+:Fehler !!!*/
                              /*~A:1506*/
                              /*~+:Ausf�hrungsstatus auf 'E005' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A1506*/
                              /*~-1*/
                              }
                              /*~E:I1501*/
                           /*~-1*/
                           }
                           /*~O:I1500*/
                           /*~-2*/
                           else
                           {
                              /*~K*/
                              /*~+:Fehler !!!*/
                              /*~A:1507*/
                              /*~+:Ausf�hrungsstatus auf 'E002' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E002;
                              /*~E:A1507*/
                           /*~-1*/
                           }
                           /*~E:I1500*/
                        /*~-1*/
                        }
                        /*~O:I1499*/
                        /*~-2*/
                        else
                        {
                           /*~A:1508*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1508*/
                        /*~-1*/
                        }
                        /*~E:I1499*/
                     /*~-1*/
                     }
                     /*~E:I1498*/
                     /*~E:A1497*/
                     /*~-1*/
#endif
                     /*~E:I1496*/
                     /*~I:1509*/
#ifndef MIT_KANALTEILUNG
                     /*~A:1510*/
                     /*~+:SCA - SetCalibrationfactortoActualweight*/
                     /*~I:1511*/
                     if (!strcmp(szCommand,"SCA"))
                     /*~-1*/
                     {
                        /*~A:1512*/
                        /*~+:Variablendeklarationen*/
                        /*~T*/
                        unsigned long ulRetVal;
                        /*~E:A1512*/
                        /*~A:1513*/
                        /*~+:Variableninitialisierungen*/
                        /*~T*/

                        /*~E:A1513*/
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;

                        /*~I:1514*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           // Parameter auslesen
                           Parameter[0].fFloat = Communication_GetFloatParameter(0);

                           /*~T*/
                           ulRetVal = Weight_SetCalibrationRegardingActualWeight(Parameter[0].fFloat);
                           /*~I:1515*/
                           if (!GET_RESPONSE)
                           /*~-1*/
                           {
                              /*~I:1516*/
                              if (!ulRetVal)
                              /*~-1*/
                              {
                              /*~T*/
                              // Alles okay
                              /*~A:1517*/
                              /*~+:Ausf�hrungsstatus auf 'OKAY' setzen*/
                              /*~+:*/
                              /*~T*/
                              // Ausf�hrungsstatus auf 'OKAY' setzen
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              /*~E:A1517*/
                              /*~A:1518*/
                              /*~+:Eintrag in Diagnosespeicher vornehmen*/
                              /*~T*/
                              ulDiagnosisEntry2Set = DIAGNOSIS_MESSAGE_CALIBRATION;
                              /*~E:A1518*/
                              /*~A:1519*/
                              /*~+:Kanal 0 - Textausgabe*/
                              /*~I:1520*/
#ifdef CHANNEL_0
                              /*~T*/
                              lText2Send = TEXT_MEASUREMENT_CALIBRATION_SET;
                              /*~-1*/
#endif
                              /*~E:I1520*/
                              /*~E:A1519*/
                              /*~-1*/
                              }
                              /*~O:I1516*/
                              /*~-2*/
                              else
                              {
                              /*~K*/
                              /*~+:Fehler !!!*/
                              /*~A:1521*/
                              /*~+:Ausf�hrungsstatus auf 'E005' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A1521*/
                              /*~-1*/
                              }
                              /*~E:I1516*/
                           /*~-1*/
                           }
                           /*~O:I1515*/
                           /*~-2*/
                           else
                           {
                              /*~K*/
                              /*~+:Fehler !!!*/
                              /*~A:1522*/
                              /*~+:Ausf�hrungsstatus auf 'E005' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A1522*/
                           /*~-1*/
                           }
                           /*~E:I1515*/
                        /*~-1*/
                        }
                        /*~O:I1514*/
                        /*~-2*/
                        else
                        {
                           /*~A:1523*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1523*/
                        /*~-1*/
                        }
                        /*~E:I1514*/
                     /*~-1*/
                     }
                     /*~E:I1511*/
                     /*~E:A1510*/
                     /*~O:I1509*/
                     /*~-1*/
#else
                     /*~A:1524*/
                     /*~+:SCA - SetCalibrationfactortoActualweight*/
                     /*~I:1525*/
                     if (!strcmp(szCommand,"SCA"))
                     /*~-1*/
                     {
                        /*~A:1526*/
                        /*~+:Variablendeklarationen*/
                        /*~T*/
                        char byRetVal;
                        /*~E:A1526*/
                        /*~A:1527*/
                        /*~+:Variableninitialisierungen*/
                        /*~T*/

                        /*~E:A1527*/
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:1528*/
                        if (!InstructionDecoder_CheckNbParameters(2,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           // Parameter auslesen
                           Parameter[0].nLong = Communication_GetLongParameter(0);
                           Parameter[1].fFloat = Communication_GetFloatParameter(1);
                           /*~C:1529*/
                           switch (Parameter[0].nLong)
                           /*~-1*/
                           {
                              /*~F:1530*/
                              case 0:
                              /*~-1*/
                              {
                              /*~A:1531*/
                              /*~+:Kanal 0*/
                              /*~I:1532*/
#ifdef CHANNEL_0
                              /*~T*/
                              byRetVal = Weight_SetCalibrationRegardingActualWeight(Parameter[1].fFloat);
                              /*~I:1533*/
                              if (!byRetVal)
                              /*~-1*/
                              {
                              /*~A:1534*/
                              /*~+:Eintrag in Diagnosespeicher vornehmen*/
                              /*~T*/
                              ulDiagnosisEntry2Set = DIAGNOSIS_MESSAGE_CALIBRATION;
                              /*~E:A1534*/
                              /*~A:1535*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              lText2Send = TEXT_MEASUREMENT_GAIN_SET_CHANNEL_0;
                              /*~E:A1535*/
                              /*~-1*/
                              }
                              /*~O:I1533*/
                              /*~-2*/
                              else
                              {
                              /*~K*/
                              /*~+:Fehler*/
                              /*~A:1536*/
                              /*~+:Textausgabe "E005"*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~I:1537*/
                              if (byRetVal == 2)
                              /*~-1*/
                              {
                              /*~T*/
                              lText2Send = TEXT_ERROR_WEIGHT_INSTABILE;
                              /*~-1*/
                              }
                              /*~E:I1537*/
                              /*~E:A1536*/
                              /*~-1*/
                              }
                              /*~E:I1533*/
                              /*~-1*/
#endif
                              /*~E:I1532*/
                              /*~E:A1531*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1530*/
                              /*~F:1538*/
                              case 1:
                              /*~-1*/
                              {
                              /*~A:1539*/
                              /*~+:Kanal 1*/
                              /*~I:1540*/
#ifdef CHANNEL_1
                              /*~T*/
                              byRetVal = Weight_SetCalibrationRegardingActualWeight(Parameter[1].fFloat);
                              /*~I:1541*/
                              if (!byRetVal)
                              /*~-1*/
                              {
                              /*~A:1542*/
                              /*~+:Eintrag in Diagnosespeicher vornehmen*/
                              /*~T*/
                              ulDiagnosisEntry2Set = DIAGNOSIS_MESSAGE_CALIBRATION;
                              /*~E:A1542*/
                              /*~A:1543*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              lText2Send = TEXT_MEASUREMENT_GAIN_SET_CHANNEL_1;
                              /*~E:A1543*/
                              /*~-1*/
                              }
                              /*~O:I1541*/
                              /*~-2*/
                              else
                              {
                              /*~K*/
                              /*~+:Fehler*/
                              /*~A:1544*/
                              /*~+:Textausgabe "E005"*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~I:1545*/
                              if (byRetVal == 2)
                              /*~-1*/
                              {
                              /*~T*/
                              lText2Send = TEXT_ERROR_WEIGHT_INSTABILE;
                              /*~-1*/
                              }
                              /*~E:I1545*/
                              /*~E:A1544*/
                              /*~-1*/
                              }
                              /*~E:I1541*/
                              /*~-1*/
#endif
                              /*~E:I1540*/
                              /*~E:A1539*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1538*/
                              /*~O:C1529*/
                              /*~-2*/
                              default:
                              {
                              /*~I:1546*/
#ifdef CHANNEL_0
                              /*~T*/
                              // Fehler
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I1546*/
                              /*~-1*/
                              }
                           /*~-1*/
                           }
                           /*~E:C1529*/
                        /*~-1*/
                        }
                        /*~O:I1528*/
                        /*~-2*/
                        else
                        {
                           /*~A:1547*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1547*/
                        /*~-1*/
                        }
                        /*~E:I1528*/
                     /*~-1*/
                     }
                     /*~E:I1525*/
                     /*~E:A1524*/
                     /*~-1*/
#endif
                     /*~E:I1509*/
                     /*~A:1548*/
                     /*~+:SCD - SetmaxCurrentDeviation*/
                     /*~I:1549*/
                     if (!strcmp(szCommand,"SCD"))	// SetmaxCurrentDeviation
                     /*~-1*/
                     {
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;

                        /*~I:1550*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].fFloat = Communication_GetFloatParameter(0);

                           /*~I:1551*/
                           if (!GET_RESPONSE)
                           /*~-1*/
                           {
                              /*~T*/
                              g_CurrentInterface.FeedBack.fMaxDeviation = Parameter[0].fFloat;
                              // und speichern
                              CurrentInterface_SaveDACSettings(CURRENTINTERFACE_MAXDEVIATION_FEEDBACK);

                              /*~A:1552*/
                              /*~+:Ausf�hrungsstatus auf 'OKAY' setzen*/
                              /*~+:*/
                              /*~T*/
                              // Ausf�hrungsstatus auf 'OKAY' setzen
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              /*~E:A1552*/
                              /*~A:1553*/
                              /*~+:Kanal 0 - Textausgabe*/
                              /*~I:1554*/
#ifdef CHANNEL_0
                              /*~A:1555*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              lText2Send = TEXT_MAX_CURRENT_DEVIATION_SET;
                              /*~E:A1555*/
                              /*~-1*/
#endif
                              /*~E:I1554*/
                              /*~E:A1553*/
                           /*~-1*/
                           }
                           /*~O:I1551*/
                           /*~-2*/
                           else
                           {
                              /*~K*/
                              /*~+:Fehler !!!*/
                              /*~A:1556*/
                              /*~+:Ausf�hrungsstatus auf 'E005' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A1556*/
                           /*~-1*/
                           }
                           /*~E:I1551*/
                        /*~-1*/
                        }
                        /*~O:I1550*/
                        /*~-2*/
                        else
                        {
                           /*~A:1557*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1557*/
                        /*~-1*/
                        }
                        /*~E:I1550*/
                     /*~-1*/
                     }
                     /*~E:I1549*/
                     /*~E:A1548*/
                     /*~A:1558*/
                     /*~+:SCF - SetCalibrationFactor*/
                     /*~I:1559*/
                     if (!strcmp(szCommand,"SCF"))
                     /*~-1*/
                     {
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;

                        /*~I:1560*/
                        if (!InstructionDecoder_CheckNbParameters(2,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           // Parameter auslesen
                           Parameter[0].nLong = Communication_GetLongParameter(0);
                           Parameter[1].fFloat = Communication_GetFloatParameter(1);
                           /*~C:1561*/
                           switch (Parameter[0].nLong)
                           /*~-1*/
                           {
                              /*~F:1562*/
                              case 0:
                              /*~-1*/
                              {
                              /*~A:1563*/
                              /*~+:Kanal 0*/
                              /*~I:1564*/
#ifdef CHANNEL_0
                              /*~T*/
                              // Kalibrierfaktor setzen
                              byRetVal = Weight_SetCalibrationFactor(Parameter[1].fFloat);
                              /*~I:1565*/
                              if (byRetVal)
                              /*~-1*/
                              {
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~-1*/
                              }
                              /*~O:I1565*/
                              /*~-2*/
                              else
                              {
                              /*~A:1566*/
                              /*~+:Eintrag in Diagnosespeicher vornehmen*/
                              /*~T*/
                              ulDiagnosisEntry2Set = DIAGNOSIS_MESSAGE_CALIBRATION_TO_VALUE;
                              /*~E:A1566*/
                              /*~A:1567*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              lText2Send = TEXT_MEASUREMENT_GAIN_SET_2_FIX_VALUE_CHANNEL_0;
                              /*~E:A1567*/
                              /*~-1*/
                              }
                              /*~E:I1565*/
                              /*~-1*/
#endif
                              /*~E:I1564*/
                              /*~E:A1563*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1562*/
                              /*~F:1568*/
                              case 1:
                              /*~-1*/
                              {
                              /*~A:1569*/
                              /*~+:Kanal 1*/
                              /*~I:1570*/
#ifdef CHANNEL_1
                              /*~T*/
                              // Kalibrierfaktor setzen
                              byRetVal = Weight_SetCalibrationFactor(Parameter[1].fFloat);
                              /*~I:1571*/
                              if (byRetVal)
                              /*~-1*/
                              {
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~-1*/
                              }
                              /*~O:I1571*/
                              /*~-2*/
                              else
                              {
                              /*~A:1572*/
                              /*~+:Eintrag in Diagnosespeicher vornehmen*/
                              /*~T*/
                              ulDiagnosisEntry2Set = DIAGNOSIS_MESSAGE_CALIBRATION_TO_VALUE;
                              /*~E:A1572*/
                              /*~A:1573*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              lText2Send = TEXT_MEASUREMENT_GAIN_SET_2_FIX_VALUE_CHANNEL_1;
                              /*~E:A1573*/
                              /*~-1*/
                              }
                              /*~E:I1571*/
                              /*~-1*/
#endif
                              /*~E:I1570*/
                              /*~E:A1569*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1568*/
                              /*~O:C1561*/
                              /*~-2*/
                              default:
                              {
                              /*~A:1574*/
                              /*~+:Kanal 0*/
                              /*~I:1575*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I1575*/
                              /*~E:A1574*/
                              /*~-1*/
                              }
                           /*~-1*/
                           }
                           /*~E:C1561*/
                        /*~-1*/
                        }
                        /*~O:I1560*/
                        /*~-2*/
                        else
                        {
                           /*~A:1576*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1576*/
                        /*~-1*/
                        }
                        /*~E:I1560*/
                     /*~-1*/
                     }
                     /*~E:I1559*/
                     /*~E:A1558*/
                     /*~A:1577*/
                     /*~+:SCL - SetCheckLimits*/
                     /*~I:1578*/
                     if (!strcmp(szCommand,"SCL"))
                     /*~-1*/
                     {
                        /*~A:1579*/
                        /*~+:Variablendeklarationen*/
                        /*~T*/
                        float fMaxDeviation;
                        float fMaxDrift;
                        /*~E:A1579*/
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;

                        /*~I:1580*/
                        if (!InstructionDecoder_CheckNbParameters(2,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0);
                           Parameter[1].fFloat = Communication_GetFloatParameter(1);

                           /*~I:1581*/
                           if (!GET_RESPONSE)
                           /*~-1*/
                           {
                              /*~T*/
                              // Alles okay
                              /*~C:1582*/
                              switch (Parameter[0].nLong)
                              /*~-1*/
                              {
                              /*~F:1583*/
                              case 0:	// Grenzwert 'Nullpunkt�berpr�fung' setzen
                              /*~-1*/
                              {
                              /*~T*/
                              g_Limit.fLimitZeroPointCheck = Parameter[1].fFloat;
                              // speichern
                              Save_Parameter(LOAD_SAVE_LIMIT_ZEROPOINTCHECK,&g_Limit.fLimitZeroPointCheck,4);
                              /*~A:1584*/
                              /*~+:Ausf�hrungsstatus auf 'OKAY' setzen*/
                              /*~+:*/
                              /*~T*/
                              // Ausf�hrungsstatus auf 'OKAY' setzen
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              /*~E:A1584*/
                              /*~A:1585*/
                              /*~+:Kanal 0 - Textausgabe*/
                              /*~I:1586*/
#ifdef CHANNEL_0 
                              /*~A:1587*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              lText2Send = TEXT_CHECKLIMIT_ZEROPOINTCHECK_SET;
                              /*~E:A1587*/
                              /*~-1*/
#endif
                              /*~E:I1586*/
                              /*~E:A1585*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1583*/
                              /*~F:1588*/
                              case 1:	// Grenzwert 'Temperaturgang' setzen
                              /*~-1*/
                              {
                              /*~T*/
                              MRW_Compensation_GetCheckLimits(&fMaxDeviation,&fMaxDrift);
                              MRW_Compensation_SetCheckLimits(Parameter[1].fFloat,fMaxDrift);
                              /*~A:1589*/
                              /*~+:Ausf�hrungsstatus auf 'OKAY' setzen*/
                              /*~+:*/
                              /*~T*/
                              // Ausf�hrungsstatus auf 'OKAY' setzen
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              /*~E:A1589*/
                              /*~A:1590*/
                              /*~+:Kanal 0 - Textausgabe*/
                              /*~I:1591*/
#ifdef CHANNEL_0 
                              /*~A:1592*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              lText2Send = TEXT_CHECKLIMIT_MAXDEVIATION_SET;
                              /*~E:A1592*/
                              /*~-1*/
#endif
                              /*~E:I1591*/
                              /*~E:A1590*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1588*/
                              /*~F:1593*/
                              case 2:	// Grenzwert 'Drift' setzen
                              /*~-1*/
                              {
                              /*~T*/
                              MRW_Compensation_GetCheckLimits(&fMaxDeviation,&fMaxDrift);
                              MRW_Compensation_SetCheckLimits(fMaxDeviation,Parameter[1].fFloat);
                              /*~A:1594*/
                              /*~+:Ausf�hrungsstatus auf 'OKAY' setzen*/
                              /*~+:*/
                              /*~T*/
                              // Ausf�hrungsstatus auf 'OKAY' setzen
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              /*~E:A1594*/
                              /*~A:1595*/
                              /*~+:Kanal 0 - Textausgabe*/
                              /*~I:1596*/
#ifdef CHANNEL_0 
                              /*~A:1597*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              lText2Send = TEXT_CHECKLIMIT_MAXDRIFT_SET;
                              /*~E:A1597*/
                              /*~-1*/
#endif
                              /*~E:I1596*/
                              /*~E:A1595*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1593*/
                              /*~O:C1582*/
                              /*~-2*/
                              default:
                              {
                              /*~K*/
                              /*~+:Fehler !!!*/
                              /*~A:1598*/
                              /*~+:Ausf�hrungsstatus auf 'E002' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E002;
                              /*~E:A1598*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~-1*/
                              }
                              /*~E:C1582*/
                           /*~-1*/
                           }
                           /*~O:I1581*/
                           /*~-2*/
                           else
                           {
                              /*~K*/
                              /*~+:Fehler !!!*/
                              /*~A:1599*/
                              /*~+:Ausf�hrungsstatus auf 'E005' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A1599*/
                           /*~-1*/
                           }
                           /*~E:I1581*/
                        /*~-1*/
                        }
                        /*~O:I1580*/
                        /*~-2*/
                        else
                        {
                           /*~A:1600*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1600*/
                        /*~-1*/
                        }
                        /*~E:I1580*/
                     /*~-1*/
                     }
                     /*~E:I1578*/
                     /*~E:A1577*/
                     /*~A:1601*/
                     /*~+:SCO - SetCompensationOnoff*/
                     /*~I:1602*/
                     if ((!strcmp(szCommand,"SCO")) || (!strcmp(szCommand,"SCE")))
                     /*~-1*/
                     {
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;

                        /*~I:1603*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~I:1604*/
                           if (!strcmp(szCommand,"SCO"))
                           /*~-1*/
                           {
                              /*~T*/
                              // Parameter auslesen
                              Parameter[0].nLong = Communication_GetLongParameter(0);
                           /*~-1*/
                           }
                           /*~O:I1604*/
                           /*~-2*/
                           else
                           {
                              /*~T*/
                              Parameter[0].nLong = 1;
                           /*~-1*/
                           }
                           /*~E:I1604*/
                           /*~I:1605*/
                           if (!GET_RESPONSE)
                           /*~-1*/
                           {
                              /*~I:1606*/
                              if (Parameter[0].nLong == 0)
                              /*~-1*/
                              {
                              /*~T*/
                              // Temperaturkompensation ausschalten
                              MRW_Compensation_SetCompensationOn(0);

                              /*~A:1607*/
                              /*~+:Eintrag im Diagnosespeicher vornehmen*/
                              /*~T*/
                              ulDiagnosisEntry2Set = DIAGNOSIS_WARNING_TEMPCOMP_OFF;
                              /*~E:A1607*/
                              /*~A:1608*/
                              /*~+:Kanal 0 - Textausgabe*/
                              /*~I:1609*/
#ifdef CHANNEL_0 
                              /*~I:1610*/
                              if (!SYSTEM_MRW_MANAGER)
                              /*~-1*/
                              {
                              /*~A:1611*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              lText2Send = TEXT_COMPENSATION_SWITCHED_OFF;
                              /*~E:A1611*/
                              /*~-1*/
                              }
                              /*~E:I1610*/
                              /*~-1*/
#endif
                              /*~E:I1609*/
                              /*~E:A1608*/
                              /*~-1*/
                              }
                              /*~O:I1606*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              // Temperaturkompensation einschalten
                              MRW_Compensation_SetCompensationOn(1);

                              /*~A:1612*/
                              /*~+:Eintrag im Diagnosespeicher vornehmen*/
                              /*~T*/
                              ulDiagnosisEntry2Set = DIAGNOSIS_WARNING_TEMPCOMP_ON;
                              /*~E:A1612*/
                              /*~A:1613*/
                              /*~+:Kanal 0 - Textausgabe*/
                              /*~I:1614*/
#ifdef CHANNEL_0 
                              /*~A:1615*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              lText2Send = TEXT_COMPENSATION_SWITCHED_ON;
                              /*~E:A1615*/
                              /*~-1*/
#endif
                              /*~E:I1614*/
                              /*~E:A1613*/
                              /*~-1*/
                              }
                              /*~E:I1606*/
                              /*~A:1616*/
                              /*~+:Ausf�hrungsstatus auf 'OKAY' setzen*/
                              /*~+:*/
                              /*~T*/
                              // Ausf�hrungsstatus auf 'OKAY' setzen
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              /*~E:A1616*/
                           /*~-1*/
                           }
                           /*~O:I1605*/
                           /*~-2*/
                           else
                           {
                              /*~K*/
                              /*~+:Fehler !!!*/
                              /*~A:1617*/
                              /*~+:Ausf�hrungsstatus auf 'E005' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A1617*/
                           /*~-1*/
                           }
                           /*~E:I1605*/
                        /*~-1*/
                        }
                        /*~O:I1603*/
                        /*~-2*/
                        else
                        {
                           /*~A:1618*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1618*/
                        /*~-1*/
                        }
                        /*~E:I1603*/
                     /*~-1*/
                     }
                     /*~E:I1602*/
                     /*~E:A1601*/
                     /*~A:1619*/
                     /*~+:SCR - SetConvertingRate*/
                     /*~A:1620*/
                     /*~+:Doxygen-Dokumentation*/
                     /*~T*/
                     /* Doxygen-Dokumentation */
                     /*~T*/
                     /*!
                     \page SUBPAGE_COMMANDS_SCR SCR
                     
                     
                     
                     
                     <table width=95% rules=all bgcolor="#E0E0F0">
                     \TABLE_COMMAND{1.,SCR,<Char><Float>,Wandlungsrate zur Gewichtsermittlung setzen, set the conversionrate of the weight-evaluation}
                     \TABLE_PARAMETER{2.,1,0\,1,Kanal,channel}
                     \TABLE_PARAMETER{2,,Wandlungsrate,conversionrate}
                     \TABLE_RETURN{3.,Text,text,OK / Mitteilung\, dass die Wandlungsrate gesetzt wurde,OK / message that the conversionrate was set}
                     \TABLE_RETURN_ADD{E002,Parameterfehler,parameterfault}
                     \TABLE_RETURN_ADD{E005,Ausf�hrungsfehler,execution-error}
                     \TABLE_RETURN_ADD{E007,Zuwenige Parameter,too less parameters}
                     \TABLE_RETURN_ADD{E008,Zuviele Parameter,too much parameters}
                     \TABLE_INTERFACE{4.,RS232}
                     \TABLE_CLOSE
                     \ref SUBPAGE_COMMANDS  \~german ">>> Befehls�bersicht " \~english ">>> Command-overview" \~ \n
                     
                     @cond FOR_PROGRAMMING_DOCS \ref SUBPAGE_SOFTWARE_CODESEGMENTS_COMMANDS_SCR \~german ">>> Code" \~english ">>> code" \~ @endcond
                     */
                     /*~T*/
                     /*!
                     \page SUBPAGE_COMMANDS_TABLE
                     \TABLE_COMMANDS{SUBPAGE_COMMANDS_SCR,<Char><Float>,Wandlungsrate zur Gewichtsermittlung setzen, set the conversionrate of the weight-evaluation}
                     */
                     /*~E:A1620*/
                     /*~A:1621*/
                     /*~+:Doxygen-Dokumentation - Codeausschnitt (Teil 1)*/
                     /*~T*/
                     /* Doxygen-Dokumentation - Codeausschnitt (Teil 1) */

                     /*~T*/
                     /*!
                     @cond FOR_PROGRAMMING_DOCS
                     \page SUBPAGE_SOFTWARE_CODESEGMENTS_COMMANDS_SCR SCR 
                     \code
                     @endcond
                     */

                     /*~E:A1621*/
                     /*~I:1622*/
                     if (!strcmp(szCommand,"SCR"))
                     /*~-1*/
                     {
                        /*~A:1623*/
                        /*~+:Variablendeklarationen*/
                        /*~T*/

                        /*~E:A1623*/
                        /*~A:1624*/
                        /*~+:Variableninitialisierungen*/
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;


                        /*~E:A1624*/
                        /*~I:1625*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           /* Parameter einlesen */
                           /* Wandlungsrate */
                           Parameter[0].fFloat = Communication_GetFloatParameter(0);
                           /*~I:1626*/
#ifdef MOF
                           /*~T*/
                           /* Parameter einlesen */
                           /* Wandlungsrate */
                           Parameter[0].fFloat = 4*Communication_GetFloatParameter(0);
                           /*~T*/
                           /* Die Wandlungsrate muss mal vier genommen werden, da der ADC im Togglebetrieb l�uft. D.h. es wird nur mit bei jeder zweiten Wandlung der DMS-Messwert ermittelt - bei der anderen Messung der Rohmesswert der Stromr�ckf�hrung. Zudem wird bei jeder Umschaltung ein Reset der ADCs ausgef�hrt, was zur Folge hat, dass der Messwert erst nach zweiten Wandlung zur Verf�gung steht.
                           /*~-1*/
#endif
                           /*~E:I1626*/
                           /*~I:1627*/
                           if ((Parameter[0].fFloat <= 105.3)&&(Parameter[0].fFloat >= 5.35))
                           /*~-1*/
                           {
                              /*~T*/
                              /* AD-Wandler initialisieren */
                              byRetVal = ADuC836_ADCSetSincFilter(Parameter[0].fFloat,ADuC836_ADC_FREQUENCY_32KHZ);
                              /*~I:1628*/
                              if (!GET_RESPONSE)
                              /*~-1*/
                              {
                              /*~I:1629*/
                              if (byRetVal == 0)
                              /*~-1*/
                              {
                              /*~T*/
                              // Alles okay
                              /*~A:1630*/
                              /*~+:Ausf�hrungsstatus auf 'OKAY' setzen*/
                              /*~+:*/
                              /*~T*/
                              // Ausf�hrungsstatus auf 'OKAY' setzen
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              /*~E:A1630*/
                              /*~A:1631*/
                              /*~+:Wandlungsrate abspeichern*/
                              /*~T*/
                              /* Wandlungsrate abspeichern */
                              Save_Parameter(LOAD_SAVE_MEASUREMENT_CONVERSIONRATE,&Parameter[0].fFloat,4);
                              /*~E:A1631*/
                              /*~A:1632*/
                              /*~+:Eintrag in Diagnosespeicher vornehmen*/
                              /*~T*/
                              ulDiagnosisEntry2Set = DIAGNOSIS_MESSAGE_WEIGHT_CONVERSIONRATE_CHANGED;
                              /*~E:A1632*/
                              /*~A:1633*/
                              /*~+:Textausgabe*/
                              /*~I:1634*/
#ifdef CHANNEL_0
                              /*~T*/
                              lText2Send = TEXT_MEASUREMENT_CONVERSIONRATE_CHANGED;
                              /*~-1*/
#endif
                              /*~E:I1634*/
                              /*~E:A1633*/
                              /*~-1*/
                              }
                              /*~O:I1629*/
                              /*~-2*/
                              else
                              {
                              /*~A:1635*/
                              /*~+:Ausf�hrungsfehler - E005*/
                              /*~T*/
                              /* Ausf�hrungsfehler - E005 */
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A1635*/
                              /*~-1*/
                              }
                              /*~E:I1629*/
                              /*~-1*/
                              }
                              /*~O:I1628*/
                              /*~-2*/
                              else
                              {
                              /*~K*/
                              /*~+:Fehler !!!*/
                              /*~A:1636*/
                              /*~+:Ausf�hrungsstatus auf 'E005' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A1636*/
                              /*~-1*/
                              }
                              /*~E:I1628*/
                           /*~-1*/
                           }
                           /*~O:I1627*/
                           /*~-2*/
                           else
                           {
                              /*~A:1637*/
                              /*~+:Parameterfehler - E002*/
                              /*~T*/
                              /* Parameterfehler - E002 */
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E002;
                              /*~E:A1637*/
                           /*~-1*/
                           }
                           /*~E:I1627*/
                        /*~-1*/
                        }
                        /*~O:I1625*/
                        /*~-2*/
                        else
                        {
                           /*~A:1638*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1638*/
                        /*~-1*/
                        }
                        /*~E:I1625*/
                     /*~-1*/
                     }
                     /*~E:I1622*/
                     /*~A:1639*/
                     /*~+:Doxygen-Dokumentation - Codeausschnitt (Teil 2)*/
                     /*~T*/
                     /* Doxygen-Dokumentation - Codeausschnitt (Teil 2) */

                     /*~T*/
                     /*!
                     @cond FOR_PROGRAMMING_DOCS
                     \page SUBPAGE_SOFTWARE_CODESEGMENTS_COMMANDS_SCR
                     \endcode 
                     \ref SUBPAGE_SOFTWARE_CODESEGMENTS_COMMANDS  \~german ">>> zur�ck" \~english ">>> back" \~
                     @endcond
                     */

                     /*~E:A1639*/
                     /*~E:A1619*/
                     /*~I:1640*/
#ifdef SPEZIALVERSION_FUER_TESTSYSTEME 
                     /*~A:1641*/
                     /*~+:SCU - SetCUrrent*/
                     /*~I:1642*/
                     if (!strcmp(szCommand,"SCU"))
                     /*~-1*/
                     {
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:1643*/
                        if (!InstructionDecoder_CheckNbParameters(2,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~C:1644*/
                           switch (Communication_GetLongParameter(0))
                           /*~-1*/
                           {
                              /*~F:1645*/
                              case 0:
                              /*~-1*/
                              {
                              /*~I:1646*/
#ifdef CHANNEL_0
                              /*~I:1647*/
                              if ((Communication_GetFloatParameter(1) >=  3)&&(Communication_GetFloatParameter(1) < 21))
                              /*~-1*/
                              {
                              /*~T*/
                              g_Weight_lSimulatedRMW = (long)(Communication_GetFloatParameter(1)* 1000);
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              /*~-1*/
                              }
                              /*~O:I1647*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_NOK;
                              /*~-1*/
                              }
                              /*~E:I1647*/
                              /*~-1*/
#endif
                              /*~E:I1646*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1645*/
                              /*~F:1648*/
                              case 1:
                              /*~-1*/
                              {
                              /*~I:1649*/
#ifdef CHANNEL_1
                              /*~I:1650*/
                              if ((Communication_GetFloatParameter(1) >=  3)&&(Communication_GetFloatParameter(1) < 21))
                              /*~-1*/
                              {
                              /*~T*/
                              g_Weight_lSimulatedRMW = (long)(Communication_GetFloatParameter(1)* 1000);
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK; 
                              /*~-1*/
                              }
                              /*~O:I1650*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_NOK;
                              /*~-1*/
                              }
                              /*~E:I1650*/
                              /*~-1*/
#endif
                              /*~E:I1649*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1648*/
                           /*~-1*/
                           }
                           /*~E:C1644*/
                        /*~-1*/
                        }
                        /*~O:I1643*/
                        /*~-2*/
                        else
                        {
                           /*~A:1651*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1651*/
                        /*~-1*/
                        }
                        /*~E:I1643*/
                     /*~-1*/
                     }
                     /*~E:I1642*/
                     /*~E:A1641*/
                     /*~-1*/
#endif
                     /*~E:I1640*/
                     /*~A:1652*/
                     /*~+:SCV - SetCompensationValues*/
                     /*~I:1653*/
                     if (!strcmp(szCommand,"SCV"))
                     /*~-1*/
                     {
                        /*~A:1654*/
                        /*~+:Variablendeklarationen*/
                        /*~T*/
                        unsigned char byChannel;
                        char chTemperature;
                        int nValue2Set;
                        /*~E:A1654*/
                        /*~A:1655*/
                        /*~+:Variableninitialisierungen*/
                        /*~T*/
                        byChannel = (char)Communication_GetLongParameter(0);
                        chTemperature = (char)Communication_GetLongParameter(1);
                        nValue2Set = (int)Communication_GetLongParameter(2);
                        /*~E:A1655*/
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:1656*/
                        if (!InstructionDecoder_CheckNbParameters(3,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~C:1657*/
                           switch (byChannel)
                           /*~-1*/
                           {
                              /*~F:1658*/
                              case 0:
                              /*~-1*/
                              {
                              /*~A:1659*/
                              /*~+:Kanal 0*/
                              /*~I:1660*/
#ifdef CHANNEL_0
                              /*~I:1661*/
                              if (!Compensation_SetCompensationValues(chTemperature,nValue2Set))
                              /*~-1*/
                              {
                              /*~A:1662*/
                              /*~+:Eintrag in Diagnosespeicher vornehmen*/
                              /*~T*/
                              ulDiagnosisEntry2Set = DIAGNOSIS_WARNING_COMPENSATION_VALUE_SET_MANUALLY;
                              /*~E:A1662*/
                              /*~A:1663*/
                              /*~+:Textausgabe f�r Terminalbetrieb*/
                              /*~T*/
                              lText2Send = TEXT_COMPENSATION_REFPOINT_MANUALLY_SET_CHANNEL_0;
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              /*~E:A1663*/
                              /*~-1*/
                              }
                              /*~O:I1661*/
                              /*~-2*/
                              else
                              {
                              /*~A:1664*/
                              /*~+:Fehler - E002 senden*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E002;
                              /*~E:A1664*/
                              /*~-1*/
                              }
                              /*~E:I1661*/
                              /*~-1*/
#endif
                              /*~E:I1660*/
                              /*~E:A1659*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1658*/
                              /*~F:1665*/
                              case 1:
                              /*~-1*/
                              {
                              /*~A:1666*/
                              /*~+:Kanal 1*/
                              /*~I:1667*/
#ifdef CHANNEL_1
                              /*~I:1668*/
                              if (!Compensation_SetCompensationValues(chTemperature,nValue2Set))
                              /*~-1*/
                              {
                              /*~A:1669*/
                              /*~+:Eintrag in Diagnosespeicher vornehmen*/
                              /*~T*/
                              ulDiagnosisEntry2Set = DIAGNOSIS_WARNING_COMPENSATION_VALUE_SET_MANUALLY;
                              /*~E:A1669*/
                              /*~A:1670*/
                              /*~+:Textausgabe f�r Terminalbetrieb*/
                              /*~T*/
                              lText2Send = TEXT_COMPENSATION_REFPOINT_MANUALLY_SET_CHANNEL_1;
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              /*~E:A1670*/
                              /*~-1*/
                              }
                              /*~O:I1668*/
                              /*~-2*/
                              else
                              {
                              /*~A:1671*/
                              /*~+:Fehler - E002 senden*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E002;
                              /*~E:A1671*/
                              /*~-1*/
                              }
                              /*~E:I1668*/
                              /*~-1*/
#endif
                              /*~E:I1667*/
                              /*~E:A1666*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1665*/
                              /*~O:C1657*/
                              /*~-2*/
                              default:
                              {
                              /*~A:1672*/
                              /*~+:Fehler - E001 senden*/
                              /*~I:1673*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I1673*/
                              /*~E:A1672*/
                              /*~-1*/
                              }
                           /*~-1*/
                           }
                           /*~E:C1657*/
                        /*~-1*/
                        }
                        /*~O:I1656*/
                        /*~-2*/
                        else
                        {
                           /*~A:1674*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1674*/
                        /*~-1*/
                        }
                        /*~E:I1656*/
                     /*~-1*/
                     }
                     /*~E:I1653*/
                     /*~E:A1652*/
                     /*~A:1675*/
                     /*~+:SEC - SetEmodulCompensation_onoff*/
                     /*~I:1676*/
                     if (!strcmp(szCommand,"SEC"))
                     /*~-1*/
                     {
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;

                        /*~I:1677*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           // Parameter auslesen
                           Parameter[0].nLong = Communication_GetLongParameter(0);
                           /*~I:1678*/
                           if (!GET_RESPONSE)
                           /*~-1*/
                           {
                              /*~I:1679*/
                              if (Parameter[0].nLong == 0)
                              /*~-1*/
                              {
                              /*~T*/
                              // E-Modul-Kompensation ausschalten
                              Weight_SetEModulCompensationOn(0);


                              /*~A:1680*/
                              /*~+:Eintrag im Diagnosespeicher vornehmen*/
                              /*~T*/
                              ulDiagnosisEntry2Set = DIAGNOSIS_WARNING_EMODULCOMP_OFF;
                              /*~E:A1680*/
                              /*~A:1681*/
                              /*~+:Kanal 0 - Textausgabe*/
                              /*~I:1682*/
#ifdef CHANNEL_0 
                              /*~A:1683*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              lText2Send = TEXT_E_MODUL_COMPENSATION_SWITCHED_OFF;
                              /*~E:A1683*/
                              /*~-1*/
#endif
                              /*~E:I1682*/
                              /*~E:A1681*/
                              /*~-1*/
                              }
                              /*~O:I1679*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              // E-Modul-Kompensation einschalten
                              Weight_SetEModulCompensationOn(1);


                              /*~A:1684*/
                              /*~+:Eintrag im Diagnosespeicher vornehmen*/
                              /*~T*/
                              ulDiagnosisEntry2Set = DIAGNOSIS_WARNING_EMODULCOMP_ON;
                              /*~E:A1684*/
                              /*~A:1685*/
                              /*~+:Kanal 0 - Textausgabe*/
                              /*~I:1686*/
#ifdef CHANNEL_0 
                              /*~A:1687*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              lText2Send = TEXT_E_MODUL_COMPENSATION_SWITCHED_ON;
                              /*~E:A1687*/
                              /*~-1*/
#endif
                              /*~E:I1686*/
                              /*~E:A1685*/
                              /*~-1*/
                              }
                              /*~E:I1679*/
                              /*~A:1688*/
                              /*~+:Ausf�hrungsstatus auf 'OKAY' setzen*/
                              /*~+:*/
                              /*~T*/
                              // Ausf�hrungsstatus auf 'OKAY' setzen
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              /*~E:A1688*/
                           /*~-1*/
                           }
                           /*~O:I1678*/
                           /*~-2*/
                           else
                           {
                              /*~K*/
                              /*~+:Fehler !!!*/
                              /*~A:1689*/
                              /*~+:Ausf�hrungsstatus auf 'E005' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A1689*/
                           /*~-1*/
                           }
                           /*~E:I1678*/
                        /*~-1*/
                        }
                        /*~O:I1677*/
                        /*~-2*/
                        else
                        {
                           /*~A:1690*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1690*/
                        /*~-1*/
                        }
                        /*~E:I1677*/
                     /*~-1*/
                     }
                     /*~E:I1676*/
                     /*~E:A1675*/
                     /*~A:1691*/
                     /*~+:SFD - SetFilterDepth*/
                     /*~I:1692*/
                     if (!strcmp(szCommand,"SFD"))
                     /*~-1*/
                     {
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;

                        /*~I:1693*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0);

                           /*~I:1694*/
                           if (!GET_RESPONSE)
                           /*~-1*/
                           {
                              /*~T*/
                              // Alles okay
                              /*~T*/
                              byTemp = Parameter[0].nLong;
                              /*~C:1695*/
                              switch (AverageFilter_SetFilterDepth(WEIGHT_WEIGHTCHANNEL,byTemp))
                              /*~-1*/
                              {
                              /*~F:1696*/
                              case 0:
                              /*~-1*/
                              {
                              /*~T*/
                              // Alles okay
                              // und Wert abspeichern
                              Save_Parameter(LOAD_SAVE_FILTER_DEPTH_WEIGHT,&byTemp,0);
                              /*~A:1697*/
                              /*~+:Ausf�hrungsstatus auf 'OKAY' setzen*/
                              /*~+:*/
                              /*~T*/
                              // Ausf�hrungsstatus auf 'OKAY' setzen
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              /*~E:A1697*/
                              /*~A:1698*/
                              /*~+:Kanal 0 - Textausgabe*/
                              /*~I:1699*/
#ifdef CHANNEL_0 
                              /*~A:1700*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              lText2Send = TEXT_AVERAGE_FILTER_FILTERDEPTH_SET;
                              /*~E:A1700*/
                              /*~-1*/
#endif
                              /*~E:I1699*/
                              /*~E:A1698*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1696*/
                              /*~F:1701*/
                              case 5:
                              /*~-1*/
                              {
                              /*~T*/
                              // Parameter au�erhalb der Grenzwerte
                              /*~T*/
                              // den gesetzen Wert abfragen
                              byTemp = AverageFilter_GetFilterDepth(WEIGHT_WEIGHTCHANNEL);
                              // und abspeichern
                              Save_Parameter(LOAD_SAVE_FILTER_DEPTH_WEIGHT,&byTemp,0);
                              /*~A:1702*/
                              /*~+:Ausf�hrungsstatus auf 'E002' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E002;
                              /*~E:A1702*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1701*/
                              /*~O:C1695*/
                              /*~-2*/
                              default:
                              {
                              /*~K*/
                              /*~+:Fehler !!!*/
                              /*~A:1703*/
                              /*~+:Ausf�hrungsstatus auf 'E005' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A1703*/
                              /*~-1*/
                              }
                              /*~-1*/
                              }
                              /*~E:C1695*/
                           /*~-1*/
                           }
                           /*~O:I1694*/
                           /*~-2*/
                           else
                           {
                              /*~K*/
                              /*~+:Fehler !!!*/
                              /*~A:1704*/
                              /*~+:Ausf�hrungsstatus auf 'E005' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A1704*/
                           /*~-1*/
                           }
                           /*~E:I1694*/
                        /*~-1*/
                        }
                        /*~O:I1693*/
                        /*~-2*/
                        else
                        {
                           /*~A:1705*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1705*/
                        /*~-1*/
                        }
                        /*~E:I1693*/
                     /*~-1*/
                     }
                     /*~E:I1692*/
                     /*~E:A1691*/
                     /*~A:1706*/
                     /*~+:SFE - SetFeedbackError*/
                     /*~I:1707*/
#ifdef MIT_STROM_ABWEICHUNGSSIMULATION
                     /*~I:1708*/
                     if (!strcmp(szCommand,"SFE"))	// SetFeedbackError
                     /*~-1*/
                     {
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;

                        /*~I:1709*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].fFloat = Communication_GetFloatParameter(0);

                           /*~I:1710*/
                           if (!GET_RESPONSE)
                           /*~-1*/
                           {
                              /*~T*/
                              g_CurrentInterface.FeedBack.fSimulatedDerivation = Parameter[0].fFloat;
                              /*~A:1711*/
                              /*~+:Ausf�hrungsstatus auf 'OKAY' setzen*/
                              /*~+:*/
                              /*~T*/
                              // Ausf�hrungsstatus auf 'OKAY' setzen
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              /*~E:A1711*/
                              /*~A:1712*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~I:1713*/
#ifdef CHANNEL_0
                              /*~T*/
                              lText2Send = TEXT_CURRENT_DEVIATION_SET;
                              /*~-1*/
#endif
                              /*~E:I1713*/
                              /*~E:A1712*/
                           /*~-1*/
                           }
                           /*~O:I1710*/
                           /*~-2*/
                           else
                           {
                              /*~K*/
                              /*~+:Fehler !!!*/
                              /*~A:1714*/
                              /*~+:Ausf�hrungsstatus auf 'E005' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A1714*/
                           /*~-1*/
                           }
                           /*~E:I1710*/
                        /*~-1*/
                        }
                        /*~O:I1709*/
                        /*~-2*/
                        else
                        {
                           /*~A:1715*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1715*/
                        /*~-1*/
                        }
                        /*~E:I1709*/
                     /*~-1*/
                     }
                     /*~E:I1708*/
                     /*~-1*/
#endif
                     /*~E:I1707*/
                     /*~E:A1706*/
                     /*~I:1716*/
#ifdef SYSTEM_CND_WITH_DEADBAND_FILTER
                     /*~A:1717*/
                     /*~+:SFW - SetFilterWidth*/
                     /*~I:1718*/
                     if (!strcmp(szCommand,"SFW"))
                     /*~-1*/
                     {
                        /*~A:1719*/
                        /*~+:Variablendeklarationen*/
                        /*~T*/
                        int nFilterBandWidth;
                        /*~E:A1719*/
                        /*~A:1720*/
                        /*~+:Variableninitialisierungen*/
                        /*~T*/

                        /*~E:A1720*/
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:1721*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           nFilterBandWidth = Communication_GetLongParameter(0);
                           /*~I:1722*/
                           if (!GET_RESPONSE)
                           /*~-1*/
                           {
                              /*~T*/
                              // Alles okay
                              /*~T*/
                              // Totbandfilter-Bandbreite setzen
                              DeadBandFilter_SetBandWidth(WEIGHT_WEIGHTCHANNEL,(float)nFilterBandWidth);

                              // und Wert abspeichern
                              Save_Parameter(LOAD_SAVE_FILTER_BANDWIDTH_WEIGHT,&nFilterBandWidth,0);
                              /*~A:1723*/
                              /*~+:Ausf�hrungsstatus auf 'OKAY' setzen*/
                              /*~+:*/
                              /*~T*/
                              // Ausf�hrungsstatus auf 'OKAY' setzen
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              /*~E:A1723*/
                              /*~A:1724*/
                              /*~+:Kanal 0 - Textausgabe*/
                              /*~I:1725*/
#ifdef CHANNEL_0
                              /*~A:1726*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              lText2Send = TEXT_DEADBAND_FILTER_FILTERWIDTH_SET;
                              /*~E:A1726*/
                              /*~-1*/
#endif
                              /*~E:I1725*/
                              /*~E:A1724*/
                           /*~-1*/
                           }
                           /*~O:I1722*/
                           /*~-2*/
                           else
                           {
                              /*~K*/
                              /*~+:Fehler !!!*/
                              /*~A:1727*/
                              /*~+:Ausf�hrungsstatus auf 'E005' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A1727*/
                           /*~-1*/
                           }
                           /*~E:I1722*/
                        /*~-1*/
                        }
                        /*~O:I1721*/
                        /*~-2*/
                        else
                        {
                           /*~A:1728*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1728*/
                        /*~-1*/
                        }
                        /*~E:I1721*/
                     /*~-1*/
                     }
                     /*~E:I1718*/
                     /*~E:A1717*/
                     /*~O:I1716*/
                     /*~-1*/
#else
                     /*~A:1729*/
                     /*~+:SFW - SetFilterWidth (Dummy)*/
                     /*~I:1730*/
                     if (!strcmp(szCommand,"SFW"))
                     /*~-1*/
                     {
                        /*~A:1731*/
                        /*~+:Variablendeklarationen*/
                        /*~T*/

                        /*~E:A1731*/
                        /*~A:1732*/
                        /*~+:Variableninitialisierungen*/
                        /*~T*/

                        /*~E:A1732*/
                        /*~A:1733*/
                        /*~+:Ausf�hrungsstatus auf 'OKAY' setzen*/
                        /*~+:*/
                        /*~T*/
                        // Ausf�hrungsstatus auf 'OKAY' setzen
                        byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                        /*~E:A1733*/
                        /*~A:1734*/
                        /*~+:Kanal 0 - Textausgabe*/
                        /*~I:1735*/
#ifdef CHANNEL_0
                        /*~A:1736*/
                        /*~+:Text f�r Terminalbetrieb*/
                        /*~T*/
                        lText2Send = TEXT_DEADBAND_FILTER_FILTERWIDTH_SET;
                        /*~E:A1736*/
                        /*~-1*/
#endif
                        /*~E:I1735*/
                        /*~E:A1734*/
                     /*~-1*/
                     }
                     /*~E:I1730*/
                     /*~E:A1729*/
                     /*~-1*/
#endif
                     /*~E:I1716*/
                     /*~A:1737*/
                     /*~+:SID - SetsystemID*/
                     /*~I:1738*/
                     if (!strcmp(szCommand,"SID"))
                     /*~-1*/
                     {
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:1739*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~I:1740*/
#ifdef CHANNEL_0
                           /*~I:1741*/
                           if (!Global.ulSystemID)
                           /*~-1*/
                           {
                              /*~T*/
                              Global.ulSystemID = Communication_GetLongParameter(0);

                              Save_Parameter(LOAD_SAVE_SYSTEM_ID,&Global.ulSystemID,4);
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              lText2Send = TEXT_ID_SET; 
                           /*~-1*/
                           }
                           /*~O:I1741*/
                           /*~-2*/
                           else
                           {
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;

                              lText2Send = TEXT_SYSTEM_ID_ALREADY_SET;
                           /*~-1*/
                           }
                           /*~E:I1741*/
                           /*~-1*/
#endif
                           /*~E:I1740*/
                        /*~-1*/
                        }
                        /*~O:I1739*/
                        /*~-2*/
                        else
                        {
                           /*~A:1742*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1742*/
                        /*~-1*/
                        }
                        /*~E:I1739*/
                     /*~-1*/
                     }
                     /*~E:I1738*/
                     /*~E:A1737*/
                     /*~I:1743*/
#ifdef MIT_GEWICHTSSIMULATION 
                     /*~A:1744*/
                     /*~+:SIW - SImulateWeight*/
                     /*~I:1745*/
                     if (!strcmp(szCommand,"SIW"))
                     /*~-1*/
                     {
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:1746*/
                        if (!InstructionDecoder_CheckNbParameters(2,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~C:1747*/
                           switch (Communication_GetLongParameter(0))
                           /*~-1*/
                           {
                              /*~F:1748*/
                              case 0:
                              /*~-1*/
                              {
                              /*~I:1749*/
#ifdef CHANNEL_0
                              /*~I:1750*/
                              if (Communication_GetLongParameter(1) < 65000)
                              /*~-1*/
                              {
                              /*~T*/
                              g_Weight_lSimulatedRMW = Communication_GetLongParameter(1);
                              /*~T*/
                              g_SystemControl.bySimulate |= 0x01;
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              lText2Send = TEXT_SIMULATED_RMW_SET_CH0; 
                              /*~-1*/
                              }
                              /*~O:I1750*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              g_SystemControl.bySimulate &= 0xFE;
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              lText2Send = TEXT_RMW_SIMULATION_STOPPED_CH0; 
                              /*~-1*/
                              }
                              /*~E:I1750*/
                              /*~-1*/
#endif
                              /*~E:I1749*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1748*/
                              /*~F:1751*/
                              case 1:
                              /*~-1*/
                              {
                              /*~I:1752*/
#ifdef CHANNEL_1
                              /*~I:1753*/
                              if (Communication_GetLongParameter(1) < 65000)
                              /*~-1*/
                              {
                              /*~T*/
                              g_Weight_lSimulatedRMW = Communication_GetLongParameter(1);
                              /*~T*/
                              g_SystemControl.bySimulate |= 0x01;
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              lText2Send = TEXT_SIMULATED_RMW_SET_CH1; 
                              /*~-1*/
                              }
                              /*~O:I1753*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              g_SystemControl.bySimulate &= 0xFE;
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              lText2Send = TEXT_RMW_SIMULATION_STOPPED_CH1; 
                              /*~-1*/
                              }
                              /*~E:I1753*/
                              /*~-1*/
#endif
                              /*~E:I1752*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1751*/
                           /*~-1*/
                           }
                           /*~E:C1747*/
                        /*~-1*/
                        }
                        /*~O:I1746*/
                        /*~-2*/
                        else
                        {
                           /*~A:1754*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1754*/
                        /*~-1*/
                        }
                        /*~E:I1746*/
                     /*~-1*/
                     }
                     /*~E:I1745*/
                     /*~E:A1744*/
                     /*~-1*/
#endif
                     /*~E:I1743*/
                     /*~A:1755*/
                     /*~+:SLC - SetLoadCelltype*/
                     /*~I:1756*/
                     if (!strcmp(szCommand,"SLC"))
                     /*~-1*/
                     {
                        /*~A:1757*/
                        /*~+:Variablendeklarationen*/
                        /*~T*/
                        BYTE byError;
                        /*~E:A1757*/
                        /*~A:1758*/
                        /*~+:Variableninitialisierungen*/
                        /*~T*/
                        byError = 0;
                        /*~E:A1758*/
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;

                        /*~I:1759*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           Parameter[0].nLong = Communication_GetLongParameter(0);
                           /*~I:1760*/
                           if (!GET_RESPONSE)
                           /*~-1*/
                           {
                              /*~T*/
                              // Alles okay
                              /*~C:1761*/
                              switch ((unsigned char)Parameter[0].nLong)
                              /*~-1*/
                              {
                              /*~F:1762*/
                              case 1:
                              /*~-1*/
                              {
                              /*~T*/
                              // Defaultparameter 'Standard-Zelle'
                              /*~I:1763*/
                              if ((g_SystemControl.byLoadCellType)&&(g_SystemControl.byLoadCellType != 1))
                              /*~-1*/
                              {
                              /*~T*/
                              // Zellentyp hat sich ge�ndert

                              // Kalibrierfaktor �ndern
                              Measurement_GetCalibrationFactor(WEIGHT_WEIGHTCHANNEL,&fTemp);
                              Weight_SetCalibrationFactor(fTemp / 5);

                              // Filtertiefe halbieren
                              byTemp = AverageFilter_GetFilterDepth(WEIGHT_WEIGHTCHANNEL) / 2;
                              AverageFilter_SetFilterDepth(WEIGHT_WEIGHTCHANNEL,byTemp);
                              // und speichern
                              Save_Parameter(LOAD_SAVE_FILTER_DEPTH_WEIGHT,&byTemp,0);


                              // Verst�rkungsfaktoren der Stromschnittstelle anpassen
                              fTemp = ADuC836_DACGetGain(0);
                              ADuC836_DACSetGain(fTemp / 5);

                              fTemp = ADuC836_DACGetGain(1);
                              ADuC836_DACSetGainNorm(fTemp / 5);

                              // und neue Einstellungen sichern
                              CurrentInterface_SaveDACSettings(CURRENTINTERFACE_ALL_SETTINGS);
                              /*~-1*/
                              }
                              /*~E:I1763*/
                              /*~T*/
                              g_Limit.fLimitZeroPointCheck = LIMIT_ZERODRIFT_DETECTION;
                              // speichern
                              Save_Parameter(LOAD_SAVE_LIMIT_ZEROPOINTCHECK,&g_Limit.fLimitZeroPointCheck,4);
                              /*~T*/
                              MRW_Compensation_SetCheckLimits(MRW_COMPENSATION_LIMIT_DEVIATIONS,MRW_COMPENSATION_LIMIT_DRIFT);
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1762*/
                              /*~F:1764*/
                              case 2:
                              /*~-1*/
                              {
                              /*~T*/
                              // Defaultparameter 'XL-Zelle'
                              /*~I:1765*/
                              if (g_SystemControl.byLoadCellType != 2)
                              /*~-1*/
                              {
                              /*~T*/
                              // Zellentyp hat sich ge�ndert

                              // Kalibrierfaktor �ndern
                              Measurement_GetCalibrationFactor(WEIGHT_WEIGHTCHANNEL,&fTemp);
                              Weight_SetCalibrationFactor(fTemp * 5);

                              // Filtertiefe verdoppeln
                              byTemp = AverageFilter_GetFilterDepth(WEIGHT_WEIGHTCHANNEL) * 2;
                              AverageFilter_SetFilterDepth(WEIGHT_WEIGHTCHANNEL,byTemp);
                              // und speichern
                              Save_Parameter(LOAD_SAVE_FILTER_DEPTH_WEIGHT,&byTemp,0);

                              // Verst�rkungsfaktoren der Stromschnittstelle anpassen
                              fTemp = ADuC836_DACGetGain(0);
                              ADuC836_DACSetGain(fTemp * 5);

                              fTemp = ADuC836_DACGetGain(1);
                              ADuC836_DACSetGainNorm(fTemp * 5);

                              // und neue Einstellungen sichern
                              CurrentInterface_SaveDACSettings(CURRENTINTERFACE_ALL_SETTINGS);
                              /*~-1*/
                              }
                              /*~E:I1765*/
                              /*~T*/
                              g_Limit.fLimitZeroPointCheck = LIMIT_ZERODRIFT_DETECTION_XL;
                              // speichern
                              Save_Parameter(LOAD_SAVE_LIMIT_ZEROPOINTCHECK,&g_Limit.fLimitZeroPointCheck,4);
                              /*~T*/
                              MRW_Compensation_SetCheckLimits(MRW_COMPENSATION_LIMIT_DEVIATIONS_XL,MRW_COMPENSATION_LIMIT_DRIFT_XL);
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1764*/
                              /*~O:C1761*/
                              /*~-2*/
                              default:
                              {
                              /*~T*/
                              byError = 1;
                              /*~A:1766*/
                              /*~+:Ausf�hrungsstatus auf 'E002' setzen*/
                              /*~K*/
                              /*~+:Parameter au�erhalb der Grenzen !!!*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E002;
                              /*~E:A1766*/
                              /*~-1*/
                              }
                              /*~-1*/
                              }
                              /*~E:C1761*/
                              /*~I:1767*/
                              if (!byError)
                              /*~-1*/
                              {
                              /*~T*/
                              // Wert setzen
                              g_SystemControl.byLoadCellType = (unsigned char)Parameter[0].nLong;
                              // und abspeichern
                              Save_Parameter(LOAD_SAVE_CELLTYPE,&g_SystemControl.byLoadCellType,0);
                              /*~A:1768*/
                              /*~+:Ausf�hrungsstatus auf 'OKAY' setzen*/
                              /*~+:*/
                              /*~T*/
                              // Ausf�hrungsstatus auf 'OKAY' setzen
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              /*~E:A1768*/
                              /*~A:1769*/
                              /*~+:Kanal 0 - Textausgabe*/
                              /*~I:1770*/
#ifdef CHANNEL_0 
                              /*~A:1771*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              lText2Send = TEXT_LOADCELL_TYPE_SET;
                              /*~E:A1771*/
                              /*~-1*/
#endif
                              /*~E:I1770*/
                              /*~E:A1769*/
                              /*~-1*/
                              }
                              /*~E:I1767*/
                           /*~-1*/
                           }
                           /*~O:I1760*/
                           /*~-2*/
                           else
                           {
                              /*~A:1772*/
                              /*~+:Ausf�hrungsstatus auf 'E005' setzen*/
                              /*~K*/
                              /*~+:Fehler !!!*/
                              /*~I:1773*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~-1*/
#endif
                              /*~E:I1773*/
                              /*~E:A1772*/
                           /*~-1*/
                           }
                           /*~E:I1760*/
                        /*~-1*/
                        }
                        /*~O:I1759*/
                        /*~-2*/
                        else
                        {
                           /*~A:1774*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1774*/
                        /*~-1*/
                        }
                        /*~E:I1759*/
                     /*~-1*/
                     }
                     /*~E:I1756*/
                     /*~E:A1755*/
                     /*~A:1775*/
                     /*~+:SLS - SetdacLimitStatus*/
                     /*~I:1776*/
                     if (!strcmp(szCommand,"SLS"))
                     /*~-1*/
                     {
                        /*~A:1777*/
                        /*~+:Variablendeklarationen*/
                        /*~T*/
                        unsigned long ulEepromClearID;
                        bit bOnOff;
                        /*~E:A1777*/
                        /*~A:1778*/
                        /*~+:Variableninitialisierungen*/
                        /*~T*/
                        ulEepromClearID = 0L;
                        /*~E:A1778*/
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:1779*/
                        if (!InstructionDecoder_CheckNbParameters(2,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           // Parameter auslesen
                           Parameter[0].nLong = Communication_GetLongParameter(0);
                           Parameter[1].nLong = Communication_GetLongParameter(1);
                           bOnOff = (bit) Communication_GetLongParameter(2); 
                           /*~C:1780*/
                           switch (Parameter[0].nLong)
                           /*~-1*/
                           {
                              /*~F:1781*/
                              case 0:
                              /*~-1*/
                              {
                              /*~A:1782*/
                              /*~+:Kanal 0*/
                              /*~I:1783*/
#ifdef CHANNEL_0
                              /*~T*/
                              ADuC836_DACEnableLimit(Parameter[1].nLong,bOnOff);
                              /*~A:1784*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              lText2Send = TEXT_LIMIT_STATE_CLEARED_CHANNEL_0;
                              /*~E:A1784*/
                              /*~-1*/
#endif
                              /*~E:I1783*/
                              /*~E:A1782*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1781*/
                              /*~F:1785*/
                              case 1:
                              /*~-1*/
                              {
                              /*~A:1786*/
                              /*~+:Kanal 1*/
                              /*~I:1787*/
#ifdef CHANNEL_1
                              /*~T*/
                              ADuC836_DACEnableLimit(Parameter[1].nLong,bOnOff);
                              /*~A:1788*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              lText2Send = TEXT_LIMIT_STATE_CLEARED_CHANNEL_1;
                              /*~E:A1788*/
                              /*~-1*/
#endif
                              /*~E:I1787*/
                              /*~E:A1786*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1785*/
                              /*~O:C1780*/
                              /*~-2*/
                              default:
                              {
                              /*~A:1789*/
                              /*~+:Kanal 0*/
                              /*~I:1790*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I1790*/
                              /*~E:A1789*/
                              /*~-1*/
                              }
                           /*~-1*/
                           }
                           /*~E:C1780*/
                        /*~-1*/
                        }
                        /*~O:I1779*/
                        /*~-2*/
                        else
                        {
                           /*~A:1791*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1791*/
                        /*~-1*/
                        }
                        /*~E:I1779*/
                     /*~-1*/
                     }
                     /*~E:I1776*/
                     /*~E:A1775*/
                     /*~I:1792*/
#ifdef MOF
                     /*~A:1793*/
                     /*~+:SMF - SetMotionFilter*/
                     /*~I:1794*/
                     if ((!strcmp(szCommand,"SMF"))||(!strcmp(szCommand,"SMT")))
                     /*~-1*/
                     {
                        /*~A:1795*/
                        /*~+:Variablendeklarationen*/
                        /*~T*/
                        MEASUREMENT_MOTIONPARAMETER MotionParameter;
                        /*~E:A1795*/
                        /*~A:1796*/
                        /*~+:Variableninitialisierungen*/
                        /*~T*/

                        /*~E:A1796*/
                        /*~T*/
                        // Text wurde bereits gesendet
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;

                        /*~I:1797*/
                        if (!InstructionDecoder_CheckNbParameters(2,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           // Parameter auslesen
                           Parameter[0].nLong = Communication_GetLongParameter(0);
                           Parameter[1].nLong = Communication_GetLongParameter(1);

                           // Motionparameter auslesen
                           Weight_GetMotionParameter(&MotionParameter);
                           /*~I:1798*/
                           if (!GET_RESPONSE)
                           /*~-1*/
                           {
                              /*~T*/
                              // Alles okay
                              /*~I:1799*/
                              if (!Parameter[0].nLong)
                              /*~-1*/
                              {
                              /*~T*/
                              // Motion-Parameter setzen
                              MotionParameter.byMotionFilter = (unsigned char)Parameter[1].nLong;
                              /*~A:1800*/
                              /*~+:Kanal 0 - Textausgabe*/
                              /*~I:1801*/
#ifdef CHANNEL_0
                              /*~A:1802*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              lText2Send = TEXT_MEASUREMENT_MOTIONFILTER_SET;
                              /*~E:A1802*/
                              /*~-1*/
#endif
                              /*~E:I1801*/
                              /*~E:A1800*/
                              /*~-1*/
                              }
                              /*~O:I1799*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              // No-Motion-Parameter setzen
                              MotionParameter.byNoMotionFilter = (unsigned char)Parameter[1].nLong;
                              /*~A:1803*/
                              /*~+:Kanal 0 - Textausgabe*/
                              /*~I:1804*/
#ifdef CHANNEL_0
                              /*~A:1805*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              lText2Send = TEXT_MEASUREMENT_NOMOTIONFILTER_SET;
                              /*~E:A1805*/
                              /*~-1*/
#endif
                              /*~E:I1804*/
                              /*~E:A1803*/
                              /*~-1*/
                              }
                              /*~E:I1799*/
                              /*~A:1806*/
                              /*~+:Ausf�hrungsstatus auf 'OKAY' setzen*/
                              /*~+:*/
                              /*~T*/
                              // Ausf�hrungsstatus auf 'OKAY' setzen
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              /*~E:A1806*/
                              /*~T*/
                              Weight_SetMotionParameter(MotionParameter,1);

                           /*~-1*/
                           }
                           /*~O:I1798*/
                           /*~-2*/
                           else
                           {
                              /*~K*/
                              /*~+:Fehler !!!*/
                              /*~A:1807*/
                              /*~+:Ausf�hrungsstatus auf 'E005' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A1807*/
                           /*~-1*/
                           }
                           /*~E:I1798*/
                        /*~-1*/
                        }
                        /*~O:I1797*/
                        /*~-2*/
                        else
                        {
                           /*~A:1808*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1808*/
                        /*~-1*/
                        }
                        /*~E:I1797*/
                     /*~-1*/
                     }
                     /*~E:I1794*/
                     /*~E:A1793*/
                     /*~-1*/
#endif
                     /*~E:I1792*/
                     /*~A:1809*/
                     /*~+:SML - SetMotionLimit*/
                     /*~I:1810*/
                     if (!strcmp(szCommand,"SML"))
                     /*~-1*/
                     {
                        /*~A:1811*/
                        /*~+:Variablendeklarationen*/
                        /*~T*/
                        MEASUREMENT_MOTIONPARAMETER MotionParameter;
                        /*~E:A1811*/
                        /*~A:1812*/
                        /*~+:Variableninitialisierungen*/
                        /*~T*/

                        /*~E:A1812*/
                        /*~T*/
                        // Text wurde bereits gesendet
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;

                        /*~I:1813*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           // Parameter auslesen
                           Parameter[0].fFloat = Communication_GetFloatParameter(0);

                           // Motionparameter auslesen
                           Weight_GetMotionParameter(&MotionParameter);
                           /*~I:1814*/
                           if (!GET_RESPONSE)
                           /*~-1*/
                           {
                              /*~T*/
                              // Alles okay
                              /*~T*/
                              // Motion-Parameter setzen
                              MotionParameter.fMotionLimit = Parameter[0].fFloat;

                              Weight_SetMotionParameter(MotionParameter,1);

                              /*~A:1815*/
                              /*~+:Ausf�hrungsstatus auf 'OKAY' setzen*/
                              /*~+:*/
                              /*~T*/
                              // Ausf�hrungsstatus auf 'OKAY' setzen
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              /*~E:A1815*/
                              /*~A:1816*/
                              /*~+:Kanal 0 - Textausgabe*/
                              /*~I:1817*/
#ifdef CHANNEL_0
                              /*~A:1818*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              lText2Send = TEXT_MEASUREMENT_MOTIONFILTER_SET;
                              /*~E:A1818*/
                              /*~-1*/
#endif
                              /*~E:I1817*/
                              /*~E:A1816*/
                           /*~-1*/
                           }
                           /*~O:I1814*/
                           /*~-2*/
                           else
                           {
                              /*~K*/
                              /*~+:Fehler !!!*/
                              /*~A:1819*/
                              /*~+:Ausf�hrungsstatus auf 'E005' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A1819*/
                           /*~-1*/
                           }
                           /*~E:I1814*/
                        /*~-1*/
                        }
                        /*~O:I1813*/
                        /*~-2*/
                        else
                        {
                           /*~A:1820*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1820*/
                        /*~-1*/
                        }
                        /*~E:I1813*/
                     /*~-1*/
                     }
                     /*~E:I1810*/
                     /*~E:A1809*/
                     /*~A:1821*/
                     /*~+:SMT - SetMotionTimer*/
                     /*~I:1822*/
                     if (!strcmp(szCommand,"SMT"))
                     /*~-1*/
                     {
                        /*~A:1823*/
                        /*~+:Variablendeklarationen*/
                        /*~T*/
                        MEASUREMENT_MOTIONPARAMETER MotionParameter;
                        /*~E:A1823*/
                        /*~A:1824*/
                        /*~+:Variableninitialisierungen*/
                        /*~T*/

                        /*~E:A1824*/
                        /*~T*/
                        // Text wurde bereits gesendet
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;

                        /*~I:1825*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           // Parameter auslesen
                           Parameter[0].nLong = Communication_GetLongParameter(0);

                           // Motionparameter auslesen
                           Weight_GetMotionParameter(&MotionParameter);
                           /*~I:1826*/
                           if (!GET_RESPONSE)
                           /*~-1*/
                           {
                              /*~T*/
                              // Alles okay
                              /*~T*/
                              // Motion-Parameter setzen
                              MotionParameter.byMotionFilter = (unsigned char)Parameter[0].nLong;
                              /*~A:1827*/
                              /*~+:Kanal 0 - Textausgabe*/
                              /*~I:1828*/
#ifdef CHANNEL_0
                              /*~A:1829*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              lText2Send = TEXT_MEASUREMENT_MOTIONTIMER_SET;
                              /*~E:A1829*/
                              /*~-1*/
#endif
                              /*~E:I1828*/
                              /*~E:A1827*/
                              /*~A:1830*/
                              /*~+:Ausf�hrungsstatus auf 'OKAY' setzen*/
                              /*~+:*/
                              /*~T*/
                              // Ausf�hrungsstatus auf 'OKAY' setzen
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              /*~E:A1830*/
                              /*~T*/
                              Weight_SetMotionParameter(MotionParameter,1);

                           /*~-1*/
                           }
                           /*~O:I1826*/
                           /*~-2*/
                           else
                           {
                              /*~K*/
                              /*~+:Fehler !!!*/
                              /*~A:1831*/
                              /*~+:Ausf�hrungsstatus auf 'E005' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A1831*/
                           /*~-1*/
                           }
                           /*~E:I1826*/
                        /*~-1*/
                        }
                        /*~O:I1825*/
                        /*~-2*/
                        else
                        {
                           /*~A:1832*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1832*/
                        /*~-1*/
                        }
                        /*~E:I1825*/
                     /*~-1*/
                     }
                     /*~E:I1822*/
                     /*~E:A1821*/
                     /*~I:1833*/
#ifdef MIT_EINSTELLBARER_MESSWERTTIEFE
                     /*~A:1834*/
                     /*~+:SNM - SetNumberofMeasurements*/
                     /*~I:1835*/
                     if (!strcmp(szCommand,"SNM"))
                     /*~-1*/
                     {
                        /*~A:1836*/
                        /*~+:Variablendeklarationen*/
                        /*~T*/
                        unsigned char byMeasurementDepth;
                        /*~E:A1836*/
                        /*~A:1837*/
                        /*~+:Variableninitialisierungen*/
                        /*~T*/

                        /*~E:A1837*/
                        /*~T*/
                        // Text wurde bereits gesendet
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;

                        /*~I:1838*/
                        if (!InstructionDecoder_CheckNbParameters(2,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           // Parameter auslesen
                           Parameter[0].nLong = Communication_GetLongParameter(0);
                           Parameter[1].nLong = Communication_GetLongParameter(1);

                           byMeasurementDepth = (unsigned char)Parameter[1].nLong;
                           /*~I:1839*/
                           if (!GET_RESPONSE)
                           /*~-1*/
                           {
                              /*~T*/
                              // Alles okay
                              /*~I:1840*/
                              if (byMeasurementDepth)
                              /*~-1*/
                              {
                              /*~C:1841*/
                              switch (Parameter[0].nLong)
                              /*~-1*/
                              {
                              /*~F:1842*/
                              case 0: // Messwerttiefe f�r Gewichtswert
                              /*~-1*/
                              {
                              /*~I:1843*/
                              if (byMeasurementDepth > 0)
                              /*~-1*/
                              {
                              /*~A:1844*/
                              /*~+:Messwerttiefe setzen*/
                              /*~T*/
                              // Messwerttiefe setzen
                              ADuC836_ADCSetMeasurementDepth(ADuC836_ADC_PRIMARY,byMeasurementDepth);
                              /*~E:A1844*/
                              /*~A:1845*/
                              /*~+:und speichern*/
                              /*~T*/
                              // und speichern
                              Save_Parameter(LOAD_SAVE_WEIGHT_MEASUREMENT_DEPTH,&byMeasurementDepth,1);
                              /*~E:A1845*/
                              /*~A:1846*/
                              /*~+:Eintrag in Diagnosespeicher vornehmen*/
                              /*~T*/
                              ulDiagnosisEntry2Set = DIAGNOSIS_MESSAGE_MEASUREMENT_DEPTH_RMW_SET;
                              /*~E:A1846*/
                              /*~A:1847*/
                              /*~+:Ausf�hrungsstatus auf 'OKAY' setzen*/
                              /*~+:*/
                              /*~T*/
                              // Ausf�hrungsstatus auf 'OKAY' setzen
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              /*~E:A1847*/
                              /*~A:1848*/
                              /*~+:Kanal 0 - Textausgabe*/
                              /*~I:1849*/
#ifdef CHANNEL_0
                              /*~A:1850*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              lText2Send = TEXT_MEASUREMENT_DEPTH_RMW_SET;
                              /*~E:A1850*/
                              /*~-1*/
#endif
                              /*~E:I1849*/
                              /*~E:A1848*/
                              /*~-1*/
                              }
                              /*~O:I1843*/
                              /*~-2*/
                              else
                              {
                              /*~A:1851*/
                              /*~+:Ausf�hrungsstatus auf 'E002' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E002;
                              /*~E:A1851*/
                              /*~-1*/
                              }
                              /*~E:I1843*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1842*/
                              /*~I:1852*/
#ifndef OHNE_STROMRUECKFUEHRUNG 
                              /*~F:1853*/
                              case 1:	// Messwerttiefe f�r Stromr�ckf�hrung
                              /*~-1*/
                              {
                              /*~I:1854*/
                              if (byMeasurementDepth > 0)
                              /*~-1*/
                              {
                              /*~A:1855*/
                              /*~+:Messwerttiefe setzen*/
                              /*~T*/
                              // Messwerttiefe setzen
                              ADuC836_ADCSetMeasurementDepth(ADuC836_ADC_PRIMARY_TOGGLE,byMeasurementDepth);

                              /*~E:A1855*/
                              /*~A:1856*/
                              /*~+:und speichern*/
                              /*~T*/
                              // und speichern
                              Save_Parameter(LOAD_SAVE_MEASUREMENT_DEPTH_FEEDBACK,&byMeasurementDepth,1);
                              /*~E:A1856*/
                              /*~A:1857*/
                              /*~+:Eintrag in Diagnosespeicher vornehmen*/
                              /*~T*/
                              ulDiagnosisEntry2Set = DIAGNOSIS_MESSAGE_MEASUREMENT_DEPTH_CURRENT_SET;
                              /*~E:A1857*/
                              /*~A:1858*/
                              /*~+:Ausf�hrungsstatus auf 'OKAY' setzen*/
                              /*~+:*/
                              /*~T*/
                              // Ausf�hrungsstatus auf 'OKAY' setzen
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              /*~E:A1858*/
                              /*~A:1859*/
                              /*~+:Kanal 0 - Textausgabe*/
                              /*~I:1860*/
#ifdef CHANNEL_0
                              /*~A:1861*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              lText2Send = TEXT_MEASUREMENT_DEPTH_FEEDBACK_SET;
                              /*~E:A1861*/
                              /*~-1*/
#endif
                              /*~E:I1860*/
                              /*~E:A1859*/
                              /*~-1*/
                              }
                              /*~O:I1854*/
                              /*~-2*/
                              else
                              {
                              /*~A:1862*/
                              /*~+:Ausf�hrungsstatus auf 'E002' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E002;
                              /*~E:A1862*/
                              /*~-1*/
                              }
                              /*~E:I1854*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1853*/
                              /*~-1*/
#endif
                              /*~E:I1852*/
                              /*~O:C1841*/
                              /*~-2*/
                              default:
                              {
                              /*~A:1863*/
                              /*~+:Ausf�hrungsstatus auf 'E002' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E002;
                              /*~E:A1863*/
                              /*~-1*/
                              }
                              /*~-1*/
                              }
                              /*~E:C1841*/
                              /*~-1*/
                              }
                              /*~O:I1840*/
                              /*~-2*/
                              else
                              {
                              /*~A:1864*/
                              /*~+:Ausf�hrungsstatus auf 'E002' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E002;
                              /*~E:A1864*/
                              /*~-1*/
                              }
                              /*~E:I1840*/
                           /*~-1*/
                           }
                           /*~O:I1839*/
                           /*~-2*/
                           else
                           {
                              /*~K*/
                              /*~+:Fehler !!!*/
                              /*~A:1865*/
                              /*~+:Ausf�hrungsstatus auf 'E005' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A1865*/
                           /*~-1*/
                           }
                           /*~E:I1839*/
                        /*~-1*/
                        }
                        /*~O:I1838*/
                        /*~-2*/
                        else
                        {
                           /*~A:1866*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1866*/
                        /*~-1*/
                        }
                        /*~E:I1838*/
                     /*~-1*/
                     }
                     /*~E:I1835*/
                     /*~E:A1834*/
                     /*~-1*/
#endif
                     /*~E:I1833*/
                     /*~I:1867*/
#ifdef DEVELOPMENT_SW
                     /*~A:1868*/
                     /*~+:SSC - SetSpiCheck*/
                     /*~I:1869*/
                     if (!strcmp(szCommand,"SSC"))
                     /*~-1*/
                     {
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;

                        /*~I:1870*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           // Parameter auslesen
                           Parameter[0].nLong = Communication_GetLongParameter(0);
                           /*~I:1871*/
                           if (Parameter[0].nLong)
                           /*~-1*/
                           {
                              /*~T*/
                              // SPI-Test einschalten
                              CommunicationControl.bTestSPI = 1;


                              /*~I:1872*/
#ifdef CHANNEL_0
                              /*~T*/
                              CommunicationControl.ulSPIE1CounterLast = -1; 
                              /*~-1*/
#endif
                              /*~E:I1872*/
                              /*~A:1873*/
                              /*~+:Kanal 0 - Textausgabe*/
                              /*~I:1874*/
#ifdef CHANNEL_0
                              /*~A:1875*/
                              /*~+:Ausf�hrungsstatus auf 'OKAY' setzen*/
                              /*~T*/
                              // Ausf�hrungsstatus auf 'OKAY' setzen
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              /*~E:A1875*/
                              /*~T*/
                              lText2Send = TEXT_SYSTEM_SPI_CHECK_ON;
                              /*~-1*/
#endif
                              /*~E:I1874*/
                              /*~E:A1873*/
                           /*~-1*/
                           }
                           /*~O:I1871*/
                           /*~-2*/
                           else
                           {
                              /*~T*/
                              // SPI-Test einschalten
                              CommunicationControl.bTestSPI = 0; 
                              /*~A:1876*/
                              /*~+:Kanal 0 - Textausgabe*/
                              /*~I:1877*/
#ifdef CHANNEL_0
                              /*~A:1878*/
                              /*~+:Ausf�hrungsstatus auf 'OKAY' setzen*/
                              /*~T*/
                              // Ausf�hrungsstatus auf 'OKAY' setzen
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              /*~E:A1878*/
                              /*~T*/
                              lText2Send = TEXT_SYSTEM_SPI_CHECK_OFF;
                              /*~-1*/
#endif
                              /*~E:I1877*/
                              /*~E:A1876*/
                           /*~-1*/
                           }
                           /*~E:I1871*/
                        /*~-1*/
                        }
                        /*~O:I1870*/
                        /*~-2*/
                        else
                        {
                           /*~A:1879*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1879*/
                        /*~-1*/
                        }
                        /*~E:I1870*/
                     /*~-1*/
                     }
                     /*~E:I1869*/
                     /*~E:A1868*/
                     /*~-1*/
#endif
                     /*~E:I1867*/
                     /*~A:1880*/
                     /*~+:SSN - SetSerialNumber*/
                     /*~I:1881*/
                     if (!strcmp(szCommand,"SSN"))
                     /*~-1*/
                     {
                        /*~A:1882*/
                        /*~+:Variablendeklarationen*/
                        /*~T*/
                        char *szSerialNumber;
                        /*~E:A1882*/
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;

                        /*~I:1883*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           szSerialNumber = Communication_GetStringParameter(0);

                           /*~I:1884*/
                           if (!System_SetSerialNumber(szSerialNumber))
                           /*~-1*/
                           {
                              /*~A:1885*/
                              /*~+:Kanal 0 - Textausgabe*/
                              /*~I:1886*/
#ifdef CHANNEL_0 
                              /*~A:1887*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              lText2Send = TEXT_SERAIL_NUMBER_SET;
                              /*~E:A1887*/
                              /*~-1*/
#endif
                              /*~E:I1886*/
                              /*~E:A1885*/
                           /*~-1*/
                           }
                           /*~O:I1884*/
                           /*~-2*/
                           else
                           {
                              /*~K*/
                              /*~+:Fehler !!!*/
                              /*~I:1888*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~-1*/
#endif
                              /*~E:I1888*/
                           /*~-1*/
                           }
                           /*~E:I1884*/
                        /*~-1*/
                        }
                        /*~O:I1883*/
                        /*~-2*/
                        else
                        {
                           /*~A:1889*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1889*/
                        /*~-1*/
                        }
                        /*~E:I1883*/
                     /*~-1*/
                     }
                     /*~E:I1881*/
                     /*~E:A1880*/
                     /*~A:1890*/
                     /*~+:SSP - SetStatisticsdataParameter*/
                     /*~I:1891*/
                     if (!strcmp(szCommand,"SSP"))
                     /*~-1*/
                     {
                        /*~A:1892*/
                        /*~+:Variablendeklarationen*/
                        /*~T*/
                        STATISTICSLIBRARY_SETUP StatisticsSetup;
                        float fLimit;
                        /*~E:A1892*/
                        /*~A:1893*/
                        /*~+:Variableninitialisierungen*/
                        /*~T*/

                        /*~E:A1893*/
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;

                        /*~I:1894*/
                        if (!InstructionDecoder_CheckNbParameters(2,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           // Parameter auslesen
                           Parameter[0].nLong = Communication_GetLongParameter(0);
                           Parameter[1].nLong = Communication_GetLongParameter(1);
                           fLimit = Communication_GetFloatParameter(1); 
                           /*~I:1895*/
                           if (!GET_RESPONSE)
                           /*~-1*/
                           {
                              /*~K*/
                              /*~+:// Alles okay*/
                              /*~T*/
                              // die aktuellen Parameter einlesen
                              StatisticsSetup = Statistics_GetSetup();
                              /*~A:1896*/
                              /*~+:Ausf�hrungsstatus auf 'OKAY' setzen*/
                              /*~+:*/
                              /*~T*/
                              // Ausf�hrungsstatus auf 'OKAY' setzen
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              /*~E:A1896*/
                              /*~C:1897*/
                              switch (Parameter[0].nLong)
                              /*~-1*/
                              {
                              /*~F:1898*/
                              case 0:	// Filter Temperatur�berwachung
                              /*~-1*/
                              {
                              /*~T*/
                              StatisticsSetup.chFilterCheckTemperature = (unsigned char)Parameter[1].nLong;
                              /*~A:1899*/
                              /*~+:Text f�r Terminalbetrieb - 2.Teil*/
                              /*~I:1900*/
#ifdef CHANNEL_0
                              /*~T*/
                              lText2Send = TEXT_STATISTICS_FILTER_TEMPERATURE_SET;
                              /*~-1*/
#endif
                              /*~E:I1900*/
                              /*~E:A1899*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1898*/
                              /*~F:1901*/
                              case 1:	// Filter Gewichts�berwachung
                              /*~-1*/
                              {
                              /*~T*/
                              StatisticsSetup.chFilterCheckWeight = (unsigned char)Parameter[1].nLong;
                              /*~A:1902*/
                              /*~+:Text f�r Terminalbetrieb - 2.Teil*/
                              /*~I:1903*/
#ifdef CHANNEL_0
                              /*~T*/
                              lText2Send = TEXT_STATISTICS_FILTER_WEIGHT_SET;
                              /*~-1*/
#endif
                              /*~E:I1903*/
                              /*~E:A1902*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1901*/
                              /*~F:1904*/
                              case 2:	// MotionLimit Gewichts�berwachung
                              /*~-1*/
                              {
                              /*~T*/
                              // StatisticsSetup.fMotionLimitCheckWeight = Parameter[2].fFloat;
                              StatisticsSetup.fMotionLimitCheckWeight = fLimit;
                              /*~A:1905*/
                              /*~+:Text f�r Terminalbetrieb - 2.Teil*/
                              /*~I:1906*/
#ifdef CHANNEL_0
                              /*~T*/
                              lText2Send = TEXT_STATISTICS_MOTIONLIMIT_WEIGHT_SET;
                              /*~-1*/
#endif
                              /*~E:I1906*/
                              /*~E:A1905*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1904*/
                              /*~F:1907*/
                              case 3:	// Filter Grenzwert�berschreitung und �berlast
                              /*~-1*/
                              {
                              /*~T*/
                              StatisticsSetup.chFilterOverLimit = (unsigned char)Parameter[1].nLong;
                              /*~A:1908*/
                              /*~+:Text f�r Terminalbetrieb - 2.Teil*/
                              /*~I:1909*/
#ifdef CHANNEL_0
                              /*~T*/
                              lText2Send = TEXT_STATISTICS_FILTER_OVERLIMIT_SET;
                              /*~-1*/
#endif
                              /*~E:I1909*/
                              /*~E:A1908*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1907*/
                              /*~F:1910*/
                              case 4:	// Grenzwert
                              /*~-1*/
                              {
                              /*~T*/
                              StatisticsSetup.fLimitOverLimit = fLimit;
                              /*~A:1911*/
                              /*~+: Text f�r Terminalbetrieb - 2.Teil*/
                              /*~I:1912*/
#ifdef CHANNEL_0
                              /*~T*/
                              lText2Send = TEXT_STATISTICS_LIMIT_OVERLIMIT_SET;
                              /*~-1*/
#endif
                              /*~E:I1912*/
                              /*~E:A1911*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1910*/
                              /*~O:C1897*/
                              /*~-2*/
                              default:
                              {
                              /*~K*/
                              /*~+:Fehler !!!*/
                              /*~A:1913*/
                              /*~+:Ausf�hrungsstatus auf 'E001' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~E:A1913*/
                              /*~-1*/
                              }
                              /*~-1*/
                              }
                              /*~E:C1897*/
                              /*~T*/
                              // Werte �bertragen
                              Statistics_SetSetup(StatisticsSetup);
                           /*~-1*/
                           }
                           /*~O:I1895*/
                           /*~-2*/
                           else
                           {
                              /*~K*/
                              /*~+:Fehler !!!*/
                              /*~A:1914*/
                              /*~+:Ausf�hrungsstatus auf 'E005' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A1914*/
                           /*~-1*/
                           }
                           /*~E:I1895*/
                        /*~-1*/
                        }
                        /*~O:I1894*/
                        /*~-2*/
                        else
                        {
                           /*~A:1915*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1915*/
                        /*~-1*/
                        }
                        /*~E:I1894*/
                     /*~-1*/
                     }
                     /*~E:I1891*/
                     /*~E:A1890*/
                     /*~A:1916*/
                     /*~+:SSS - SetSystemState*/
                     /*~I:1917*/
                     if (!strcmp(szCommand,"SSS"))
                     /*~-1*/
                     {
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;

                        /*~I:1918*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           // Parameter auslesen
                           Parameter[0].nLong = Communication_GetLongParameter(0);
                           /*~I:1919*/
                           if (!GET_RESPONSE)
                           /*~-1*/
                           {
                              /*~K*/
                              /*~+:// Acknowledge empfangen - Alles okay*/
                              /*~I:1920*/
                              if (Parameter[0].nLong)
                              /*~-1*/
                              {
                              /*~T*/
                              // Betriebszustand manuell setzen
                              System_SetSystemState(Parameter[0].nLong);

                              Global.Mode.bySetStateManualy = 1; 
                              /*~-1*/
                              }
                              /*~O:I1920*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              // Wieder zum normalen Betrieb �bergehen
                              System_SetSystemState(SYSTEM_RUNNING);

                              Global.Mode.bySetStateManualy = 0; 
                              /*~-1*/
                              }
                              /*~E:I1920*/
                              /*~A:1921*/
                              /*~+:Ausf�hrungsstatus auf 'OKAY' setzen*/
                              /*~+:*/
                              /*~T*/
                              // Ausf�hrungsstatus auf 'OKAY' setzen
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              /*~E:A1921*/
                              /*~A:1922*/
                              /*~+:Kanal 0 - Textausgabe*/
                              /*~I:1923*/
#ifdef CHANNEL_0
                              /*~C:1924*/
                              switch (Parameter[0].nLong)
                              /*~-1*/
                              {
                              /*~A:1925*/
                              /*~+:SYSTEM_RUNNING*/
                              /*~F:1926*/
                              case 0:
                              case SYSTEM_RUNNING:
                              /*~-1*/
                              {
                              /*~T*/
                              lText2Send = TEXT_SYSTEM_STATE_SET_2_RUNNING;
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1926*/
                              /*~E:A1925*/
                              /*~A:1927*/
                              /*~+:SYSTEM_REC_CHARACTERISTICS_ON*/
                              /*~F:1928*/
                              case SYSTEM_REC_CHARACTERISTICS_ON:
                              /*~-1*/
                              {
                              /*~T*/
                              lText2Send = TEXT_SYSTEM_STATE_SET_2_REC_CHARACTERISTICS;
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1928*/
                              /*~E:A1927*/
                              /*~A:1929*/
                              /*~+:SYSTEM_REC_CHARACTERISTICS_1ST_DRIFT*/
                              /*~F:1930*/
                              case SYSTEM_REC_CHARACTERISTICS_1ST_DRIFT:
                              /*~-1*/
                              {
                              /*~T*/
                              lText2Send = TEXT_SYSTEM_STATE_SET_2_FIRST_DRIFT_VALUE_DETERMINED;
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1930*/
                              /*~E:A1929*/
                              /*~A:1931*/
                              /*~+:SYSTEM_REC_CHARACTERISTICS_OKAY*/
                              /*~F:1932*/
                              case SYSTEM_REC_CHARACTERISTICS_OKAY:
                              /*~-1*/
                              {
                              /*~T*/
                              lText2Send = TEXT_SYSTEM_STATE_SET_2_REC_CHARACTERISTICS_FINISHED_SUCCESSFUL;
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1932*/
                              /*~E:A1931*/
                              /*~A:1933*/
                              /*~+:SYSTEM_REC_CHARACTERISTICS_ERROR*/
                              /*~F:1934*/
                              case SYSTEM_REC_CHARACTERISTICS_ERROR:
                              /*~-1*/
                              {
                              /*~T*/
                              lText2Send = TEXT_SYSTEM_STATE_SET_2_REC_CHARACTERISTICS_FINISHED_WITH_ERROR;
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1934*/
                              /*~E:A1933*/
                              /*~A:1935*/
                              /*~+:SYSTEM_ERROR*/
                              /*~F:1936*/
                              case SYSTEM_ERROR:
                              /*~-1*/
                              {
                              /*~T*/
                              lText2Send = TEXT_SYSTEM_STATE_SET_2_SYSTEM_ERROR;
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1936*/
                              /*~E:A1935*/
                              /*~O:C1924*/
                              /*~-2*/
                              default:
                              {
                              /*~K*/
                              /*~+:Fehler !!!*/
                              /*~I:1937*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E002;
                              /*~-1*/
#endif
                              /*~E:I1937*/
                              /*~-1*/
                              }
                              /*~-1*/
                              }
                              /*~E:C1924*/
                              /*~-1*/
#endif
                              /*~E:I1923*/
                              /*~E:A1922*/
                           /*~-1*/
                           }
                           /*~O:I1919*/
                           /*~-2*/
                           else
                           {
                              /*~K*/
                              /*~+:Fehler !!!*/
                              /*~A:1938*/
                              /*~+:Ausf�hrungsstatus auf 'E005' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A1938*/
                           /*~-1*/
                           }
                           /*~E:I1919*/
                        /*~-1*/
                        }
                        /*~O:I1918*/
                        /*~-2*/
                        else
                        {
                           /*~A:1939*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1939*/
                        /*~-1*/
                        }
                        /*~E:I1918*/
                     /*~-1*/
                     }
                     /*~E:I1917*/
                     /*~E:A1916*/
                     /*~A:1940*/
                     /*~+:SST - SetSimulatedTemperature*/
                     /*~I:1941*/
                     if (!strcmp(szCommand,"SST"))
                     /*~-1*/
                     {
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;

                        /*~I:1942*/
                        if (!InstructionDecoder_CheckNbParameters(2,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           // Parameter auslesen
                           Parameter[0].nLong = Communication_GetLongParameter(0);
                           Parameter[1].fFloat = Communication_GetFloatParameter(1);
                           /*~C:1943*/
                           switch (Parameter[0].nLong)
                           /*~-1*/
                           {
                              /*~F:1944*/
                              case 0:
                              /*~-1*/
                              {
                              /*~A:1945*/
                              /*~+:Kanal 0*/
                              /*~I:1946*/
#ifdef CHANNEL_0
                              /*~I:1947*/
                              if ((Parameter[1].fFloat >= -100)&&(Parameter[1].fFloat <= 100))
                              /*~-1*/
                              {
                              /*~T*/
                              g_SystemControl.bySimulate |= 0x02;
                              /*~T*/
                              // simulierte Temperatur setzen
                              Global.bySimulatedTemperature = (char)Parameter[1].fFloat;
                              /*~A:1948*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              lText2Send = TEXT_SIMULATED_TEMPERATURE_SET_CHANNEL_0;
                              /*~E:A1948*/
                              /*~-1*/
                              }
                              /*~O:I1947*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              g_SystemControl.bySimulate &= 0xFD;
                              /*~A:1949*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              lText2Send = lText2Send = TEXT_TEMPERATURE_SIMULATION_CHANCELD_CHANNEL_0;
                              /*~E:A1949*/
                              /*~-1*/
                              }
                              /*~E:I1947*/
                              /*~-1*/
#endif
                              /*~E:I1946*/
                              /*~E:A1945*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1944*/
                              /*~F:1950*/
                              case 1:
                              /*~-1*/
                              {
                              /*~A:1951*/
                              /*~+:Kanal 1*/
                              /*~I:1952*/
#ifdef CHANNEL_1
                              /*~I:1953*/
                              if ((Parameter[1].fFloat >= -100)&&(Parameter[1].fFloat <= 100))
                              /*~-1*/
                              {
                              /*~T*/
                              g_SystemControl.bySimulate |= 0x02;
                              /*~T*/
                              // simulierte Temperatur setzen
                              Global.bySimulatedTemperature = (char)Parameter[1].fFloat;
                              /*~A:1954*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              lText2Send = TEXT_SIMULATED_TEMPERATURE_SET_CHANNEL_1;
                              /*~E:A1954*/
                              /*~-1*/
                              }
                              /*~O:I1953*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              g_SystemControl.bySimulate &= 0xFD;
                              /*~A:1955*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              lText2Send = lText2Send = TEXT_TEMPERATURE_SIMULATION_CHANCELD_CHANNEL_1;
                              /*~E:A1955*/
                              /*~-1*/
                              }
                              /*~E:I1953*/
                              /*~-1*/
#endif
                              /*~E:I1952*/
                              /*~E:A1951*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1950*/
                              /*~O:C1943*/
                              /*~-2*/
                              default:
                              {
                              /*~A:1956*/
                              /*~+:Kanal 0*/
                              /*~I:1957*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I1957*/
                              /*~E:A1956*/
                              /*~-1*/
                              }
                           /*~-1*/
                           }
                           /*~E:C1943*/
                        /*~-1*/
                        }
                        /*~O:I1942*/
                        /*~-2*/
                        else
                        {
                           /*~A:1958*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1958*/
                        /*~-1*/
                        }
                        /*~E:I1942*/
                     /*~-1*/
                     }
                     /*~E:I1941*/
                     /*~E:A1940*/
                     /*~A:1959*/
                     /*~+:STA - SetTaretoActualweight*/
                     /*~K*/
                     /*~+:STA - identisch mit TET (TEachTare)*/
                     /*~E:A1959*/
                     /*~A:1960*/
                     /*~+:STH - SetTimeHysteresis*/
                     /*~I:1961*/
                     if (!strcmp(szCommand,"STH"))
                     /*~-1*/
                     {
                        /*~T*/
                        // Text wurde bereits gesendet
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;

                        /*~I:1962*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~I:1963*/
                           if (!GET_RESPONSE)
                           /*~-1*/
                           {
                              /*~T*/
                              // Parameter auslesen
                              Parameter[0].nLong = Communication_GetLongParameter(0);

                              /*~I:1964*/
                              if (Parameter[0].nLong <= 30)	// maximal 30 Sekunden
                              /*~-1*/
                              {
                              /*~T*/
                              CurrentInterface_SetTimeHysteresis(Parameter[0].nLong);
                              /*~A:1965*/
                              /*~+:Ausf�hrungsstatus auf 'OKAY' setzen*/
                              /*~+:*/
                              /*~T*/
                              // Ausf�hrungsstatus auf 'OKAY' setzen
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              /*~E:A1965*/
                              /*~A:1966*/
                              /*~+:Kanal 0 - Textausgabe*/
                              /*~I:1967*/
#ifdef CHANNEL_0
                              /*~A:1968*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              lText2Send = TEXT_CURRENT_INTERFACE_SET_TIME_HYSTERESIS;
                              /*~E:A1968*/
                              /*~-1*/
#endif
                              /*~E:I1967*/
                              /*~E:A1966*/
                              /*~-1*/
                              }
                              /*~O:I1964*/
                              /*~-2*/
                              else
                              {
                              /*~K*/
                              /*~+:Fehler !!!*/
                              /*~A:1969*/
                              /*~+:Ausf�hrungsstatus auf 'E002' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E002;
                              /*~E:A1969*/
                              /*~-1*/
                              }
                              /*~E:I1964*/
                           /*~-1*/
                           }
                           /*~O:I1963*/
                           /*~-2*/
                           else
                           {
                              /*~K*/
                              /*~+:Fehler !!!*/
                              /*~A:1970*/
                              /*~+:Ausf�hrungsstatus auf 'E005' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A1970*/
                           /*~-1*/
                           }
                           /*~E:I1963*/
                        /*~-1*/
                        }
                        /*~O:I1962*/
                        /*~-2*/
                        else
                        {
                           /*~A:1971*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1971*/
                        /*~-1*/
                        }
                        /*~E:I1962*/
                     /*~-1*/
                     }
                     /*~E:I1961*/
                     /*~E:A1960*/
                     /*~A:1972*/
                     /*~+:STO - SetTemperatureOffset*/
                     /*~I:1973*/
                     if (!strcmp(szCommand,"STO"))
                     /*~-1*/
                     {
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;

                        /*~I:1974*/
                        if (!InstructionDecoder_CheckNbParameters(2,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           // Parameter auslesen
                           Parameter[0].nLong = Communication_GetLongParameter(0);
                           Parameter[1].nLong = Communication_GetLongParameter(1);
                           /*~C:1975*/
                           switch (Parameter[0].nLong)
                           /*~-1*/
                           {
                              /*~F:1976*/
                              case 0:	// Temperaturoffset des Kanal 0 setzen
                              /*~-1*/
                              {
                              /*~A:1977*/
                              /*~+:Kanal 0*/
                              /*~I:1978*/
#ifdef CHANNEL_0
                              /*~T*/
                              // Temperaturoffset setzen und speichern
                              Analog_SetTemperatureOffset((char)Parameter[1].nLong,ANALOG_TEMPERATURE_CALIBRATION_SET_OFFSET_MANUALY); 
                              /*~A:1979*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              lText2Send = TEXT_TEMPERATURE_OFFSET_SET_CHANNEL_0;
                              /*~E:A1979*/
                              /*~-1*/
#endif
                              /*~E:I1978*/
                              /*~E:A1977*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1976*/
                              /*~F:1980*/
                              case 1:	// Temperaturoffset des Kanal 1 setzen
                              /*~-1*/
                              {
                              /*~A:1981*/
                              /*~+:Kanal 1*/
                              /*~I:1982*/
#ifdef CHANNEL_1
                              /*~T*/
                              // Temperaturoffset setzen und speichern
                              Analog_SetTemperatureOffset((char)Parameter[1].nLong,ANALOG_TEMPERATURE_CALIBRATION_SET_OFFSET_MANUALY); 
                              /*~A:1983*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              lText2Send = TEXT_TEMPERATURE_OFFSET_SET_CHANNEL_1;
                              /*~E:A1983*/
                              /*~-1*/
#endif
                              /*~E:I1982*/
                              /*~E:A1981*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1980*/
                              /*~F:1984*/
                              case 255: // Temperaturoffset berechnen
                              /*~-1*/
                              {
                              /*~I:1985*/
                              if (!GET_RESPONSE)
                              /*~-1*/
                              {
                              /*~K*/
                              /*~+:// Acknowledge empfangen - Alles okay*/
                              /*~T*/
                              Analog_SetTemperatureOffset((char)Parameter[1].nLong,ANALOG_TEMPERATURE_CALIBRATION_SET_OFFSET_AUTOMATICLY);
                              /*~A:1986*/
                              /*~+:Ausf�hrungsstatus auf 'OKAY' setzen*/
                              /*~+:*/
                              /*~T*/
                              // Ausf�hrungsstatus auf 'OKAY' setzen
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              /*~E:A1986*/
                              /*~A:1987*/
                              /*~+:Kanal 0 - Textausgabe*/
                              /*~I:1988*/
#ifdef CHANNEL_0
                              /*~A:1989*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              lText2Send = TEXT_TEMPERATURE_SENSOR_CALIBRATED;
                              /*~E:A1989*/
                              /*~-1*/
#endif
                              /*~E:I1988*/
                              /*~E:A1987*/
                              /*~-1*/
                              }
                              /*~O:I1985*/
                              /*~-2*/
                              else
                              {
                              /*~K*/
                              /*~+:Fehler !!!*/
                              /*~A:1990*/
                              /*~+:Ausf�hrungsstatus auf 'E005' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A1990*/
                              /*~-1*/
                              }
                              /*~E:I1985*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1984*/
                              /*~O:C1975*/
                              /*~-2*/
                              default:
                              {
                              /*~I:1991*/
#ifdef CHANNEL_0
                              /*~T*/
                              // Fehler
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I1991*/
                              /*~-1*/
                              }
                           /*~-1*/
                           }
                           /*~E:C1975*/
                        /*~-1*/
                        }
                        /*~O:I1974*/
                        /*~-2*/
                        else
                        {
                           /*~A:1992*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A1992*/
                        /*~-1*/
                        }
                        /*~E:I1974*/
                     /*~-1*/
                     }
                     /*~E:I1973*/
                     /*~E:A1972*/
                     /*~A:1993*/
                     /*~+:STR - SetTaRa*/
                     /*~I:1994*/
                     if (!strcmp(szCommand,"STR"))
                     /*~-1*/
                     {
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;

                        /*~I:1995*/
                        if (!InstructionDecoder_CheckNbParameters(2,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           // Parameter auslesen
                           Parameter[0].nLong = Communication_GetLongParameter(0);
                           Parameter[1].fFloat = Communication_GetFloatParameter(1);
                           /*~C:1996*/
                           switch (Parameter[0].nLong)
                           /*~-1*/
                           {
                              /*~F:1997*/
                              case 0:
                              /*~-1*/
                              {
                              /*~A:1998*/
                              /*~+:Kanal 0*/
                              /*~I:1999*/
#ifdef CHANNEL_0
                              /*~I:2000*/
                              // Tara setzen und speichern
                              if (!Weight_SetTareValue(Parameter[1].fFloat,1))
                              /*~-1*/
                              {
                              /*~A:2001*/
                              /*~+:Eintrag in Diagnosespeicher vornehmen*/
                              /*~T*/
                              ulDiagnosisEntry2Set = DIAGNOSIS_MESSAGE_TARE_MANUAL;
                              /*~E:A2001*/
                              /*~A:2002*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              /*~I:2003*/
                              if (Parameter[1].fFloat)
                              /*~-1*/
                              {
                              /*~T*/
                              lText2Send = TEXT_MEASUREMENT_TARA_SET_2_FIX_VALUE_CHANNEL_0;
                              /*~-1*/
                              }
                              /*~O:I2003*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              lText2Send = TEXT_MEASUREMENT_TARA_CLEARED_CHANNEL_0;
                              /*~-1*/
                              }
                              /*~E:I2003*/
                              /*~E:A2002*/
                              /*~-1*/
                              }
                              /*~O:I2000*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~-1*/
                              }
                              /*~E:I2000*/
                              /*~-1*/
#endif
                              /*~E:I1999*/
                              /*~E:A1998*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F1997*/
                              /*~F:2004*/
                              case 1:
                              /*~-1*/
                              {
                              /*~A:2005*/
                              /*~+:Kanal 1*/
                              /*~I:2006*/
#ifdef CHANNEL_1
                              /*~I:2007*/
                              // Tara setzen und speichern
                              if (!Weight_SetTareValue(Parameter[1].fFloat,1))
                              /*~-1*/
                              {
                              /*~A:2008*/
                              /*~+:Eintrag in Diagnosespeicher vornehmen*/
                              /*~T*/
                              ulDiagnosisEntry2Set = DIAGNOSIS_MESSAGE_TARE_MANUAL;
                              /*~E:A2008*/
                              /*~A:2009*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              /*~I:2010*/
                              if (Parameter[1].fFloat)
                              /*~-1*/
                              {
                              /*~T*/
                              lText2Send = TEXT_MEASUREMENT_TARA_SET_2_FIX_VALUE_CHANNEL_1;
                              /*~-1*/
                              }
                              /*~O:I2010*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              lText2Send = TEXT_MEASUREMENT_TARA_CLEARED_CHANNEL_1;
                              /*~-1*/
                              }
                              /*~E:I2010*/
                              /*~E:A2009*/
                              /*~-1*/
                              }
                              /*~O:I2007*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~-1*/
                              }
                              /*~E:I2007*/
                              /*~-1*/
#endif
                              /*~E:I2006*/
                              /*~E:A2005*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F2004*/
                              /*~O:C1996*/
                              /*~-2*/
                              default:
                              {
                              /*~A:2011*/
                              /*~+:Kanal 0*/
                              /*~I:2012*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I2012*/
                              /*~E:A2011*/
                              /*~-1*/
                              }
                           /*~-1*/
                           }
                           /*~E:C1996*/
                        /*~-1*/
                        }
                        /*~O:I1995*/
                        /*~-2*/
                        else
                        {
                           /*~A:2013*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A2013*/
                        /*~-1*/
                        }
                        /*~E:I1995*/
                     /*~-1*/
                     }
                     /*~E:I1994*/
                     /*~E:A1993*/
                     /*~A:2014*/
                     /*~+:SZA - SetZeroActualweight*/
                     /*~I:2015*/
                     if (!strcmp(szCommand,"SZA"))
                     /*~-1*/
                     {
                        /*~A:2016*/
                        /*~+:Variablendeklarationen*/
                        /*~T*/
                        char byRetVal;
                        /*~E:A2016*/
                        /*~A:2017*/
                        /*~+:Variableninitialisierungen*/
                        /*~T*/

                        /*~E:A2017*/
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:2018*/
                        if (!InstructionDecoder_CheckNbParameters(0,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           byRetVal = Weight_SetZeroRegardingActualWeight();
                           //byRetVal = 0;
                           /*~I:2019*/
                           if (!GET_RESPONSE)
                           /*~-1*/
                           {
                              /*~I:2020*/
                              if (!byRetVal)
                              /*~-1*/
                              {
                              /*~T*/
                              // Alles okay
                              /*~A:2021*/
                              /*~+:Ausf�hrungsstatus auf 'OKAY' setzen*/
                              /*~+:*/
                              /*~T*/
                              // Ausf�hrungsstatus auf 'OKAY' setzen
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              /*~E:A2021*/
                              /*~A:2022*/
                              /*~+:Eintrag in Diagnosespeicher vornehmen*/
                              /*~T*/
                              ulDiagnosisEntry2Set = DIAGNOSIS_MESSAGE_ZERO;
                              /*~E:A2022*/
                              /*~A:2023*/
                              /*~+:Kanal 0 - Text f�r Terminalbetrieb*/
                              /*~I:2024*/
#ifdef CHANNEL_0
                              /*~T*/
                              lText2Send = TEXT_MEASUREMENT_OFFSET_SET_2_ACTUAL;
                              /*~-1*/
#endif
                              /*~E:I2024*/
                              /*~E:A2023*/
                              /*~-1*/
                              }
                              /*~O:I2020*/
                              /*~-2*/
                              else
                              {
                              /*~K*/
                              /*~+:Fehler !!!*/
                              /*~A:2025*/
                              /*~+:Ausf�hrungsstatus auf 'E005' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A2025*/
                              /*~I:2026*/
#ifdef MOF
                              /*~A:2027*/
                              /*~+:diverse Ausgaben zur genaueren Aufschl�sselung des Fehlers*/
                              /*~C:2028*/
                              switch (byRetVal)
                              /*~-1*/
                              {
                              /*~F:2029*/
                              case 1:
                              /*~-1*/
                              {
                              /*~A:2030*/
                              /*~+:Ausf�hrungsstatus auf 'E105' setzen*/
                              /*~T*/
                              Communication_SendString(COMMUNICATION_RS232,"E105",1,0);
                              /*~E:A2030*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F2029*/
                              /*~F:2031*/
                              case 2:
                              /*~-1*/
                              {
                              /*~A:2032*/
                              /*~+:Ausf�hrungsstatus auf 'E205' setzen*/
                              /*~T*/
                              Communication_SendString(COMMUNICATION_RS232,"E205",1,0);
                              /*~E:A2032*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F2031*/
                              /*~O:C2028*/
                              /*~-2*/
                              default:
                              {
                              /*~A:2033*/
                              /*~+:Ausf�hrungsstatus auf 'E305' setzen*/
                              /*~T*/
                              Communication_SendString(COMMUNICATION_RS232,"E305",1,0);
                              /*~E:A2033*/
                              /*~-1*/
                              }
                              /*~-1*/
                              }
                              /*~E:C2028*/
                              /*~E:A2027*/
                              /*~-1*/
#endif
                              /*~E:I2026*/
                              /*~-1*/
                              }
                              /*~E:I2020*/
                           /*~-1*/
                           }
                           /*~O:I2019*/
                           /*~-2*/
                           else
                           {
                              /*~K*/
                              /*~+:Fehler !!!*/
                              /*~A:2034*/
                              /*~+:Ausf�hrungsstatus auf 'E005' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A2034*/
                           /*~-1*/
                           }
                           /*~E:I2019*/
                        /*~-1*/
                        }
                        /*~O:I2018*/
                        /*~-2*/
                        else
                        {
                           /*~A:2035*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A2035*/
                        /*~-1*/
                        }
                        /*~E:I2018*/
                     /*~-1*/
                     }
                     /*~E:I2015*/
                     /*~E:A2014*/
                     /*~A:2036*/
                     /*~+:SZP - SetZeroPoint*/
                     /*~I:2037*/
                     if (!strcmp(szCommand,"SZP"))
                     /*~-1*/
                     {
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;

                        /*~I:2038*/
                        if (!InstructionDecoder_CheckNbParameters(2,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~T*/
                           // Parameter auslesen
                           Parameter[0].nLong = Communication_GetLongParameter(0);
                           Parameter[1].nLong = Communication_GetLongParameter(1);
                           /*~C:2039*/
                           switch (Parameter[0].nLong)
                           /*~-1*/
                           {
                              /*~F:2040*/
                              case 0:
                              /*~-1*/
                              {
                              /*~A:2041*/
                              /*~+:Kanal 0*/
                              /*~I:2042*/
#ifdef CHANNEL_0
                              /*~I:2043*/
                              if (!Weight_SetZero(Parameter[1].nLong))
                              /*~-1*/
                              {
                              /*~A:2044*/
                              /*~+:Eintrag in Diagnosespeicher vornehmen*/
                              /*~T*/
                              ulDiagnosisEntry2Set = DIAGNOSIS_MESSAGE_ZERO_TO_VALUE;
                              /*~E:A2044*/
                              /*~A:2045*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              lText2Send = TEXT_MEASUREMENT_OFFSET_SET_2_VALUE_CHANNEL_0;
                              /*~E:A2045*/
                              /*~-1*/
                              }
                              /*~O:I2043*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~-1*/
                              }
                              /*~E:I2043*/
                              /*~-1*/
#endif
                              /*~E:I2042*/
                              /*~E:A2041*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F2040*/
                              /*~F:2046*/
                              case 1:
                              /*~-1*/
                              {
                              /*~A:2047*/
                              /*~+:Kanal 1*/
                              /*~I:2048*/
#ifdef CHANNEL_1
                              /*~I:2049*/
                              if (!Weight_SetZero(Parameter[1].nLong))
                              /*~-1*/
                              {
                              /*~A:2050*/
                              /*~+:Eintrag in Diagnosespeicher vornehmen*/
                              /*~T*/
                              ulDiagnosisEntry2Set = DIAGNOSIS_MESSAGE_ZERO_TO_VALUE;
                              /*~E:A2050*/
                              /*~A:2051*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                              lText2Send = TEXT_MEASUREMENT_OFFSET_SET_2_VALUE_CHANNEL_1;
                              /*~E:A2051*/
                              /*~-1*/
                              }
                              /*~O:I2049*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~-1*/
                              }
                              /*~E:I2049*/
                              /*~-1*/
#endif
                              /*~E:I2048*/
                              /*~E:A2047*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F2046*/
                              /*~O:C2039*/
                              /*~-2*/
                              default:
                              {
                              /*~A:2052*/
                              /*~+:Kanal 0*/
                              /*~I:2053*/
#ifdef CHANNEL_0
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E001;
                              /*~-1*/
#endif
                              /*~E:I2053*/
                              /*~E:A2052*/
                              /*~-1*/
                              }
                           /*~-1*/
                           }
                           /*~E:C2039*/
                        /*~-1*/
                        }
                        /*~O:I2038*/
                        /*~-2*/
                        else
                        {
                           /*~A:2054*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A2054*/
                        /*~-1*/
                        }
                        /*~E:I2038*/
                     /*~-1*/
                     }
                     /*~E:I2037*/
                     /*~E:A2036*/
                     /*~T*/
                     break;
                  /*~-1*/
                  }
                  /*~E:F1454*/
                  /*~E:A1453*/
                  /*~A:2055*/
                  /*~+:T*/
                  /*~F:2056*/
                  case 'T':
                  /*~-1*/
                  {
                     /*~I:2057*/
#ifdef MIT_LIMITTEACH_VIA_RS232
                     /*~A:2058*/
                     /*~+:TEC - TEaCh*/
                     /*~I:2059*/
                     if (!strcmp(szCommand,"TEC"))
                     /*~-1*/
                     {
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:2060*/
                        if (!InstructionDecoder_CheckNbParameters(0,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~I:2061*/
                           if (!GET_RESPONSE)
                           /*~-1*/
                           {
                              /*~K*/
                              /*~+:// Alles okay*/
                              /*~I:2062*/
                              if (!Limit_SetAlarmLimitByWeight(1,0))
                              /*~-1*/
                              {
                              /*~A:2063*/
                              /*~+:Ausf�hrungsstatus auf 'OKAY' setzen*/
                              /*~+:*/
                              /*~T*/
                              // Ausf�hrungsstatus auf 'OKAY' setzen
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              /*~E:A2063*/
                              /*~A:2064*/
                              /*~+:Kanal 0 - Textausgabe*/
                              /*~I:2065*/
#ifdef CHANNEL_0
                              /*~T*/
                              lText2Send = TEXT_LIMIT_TEACHED;
                              /*~-1*/
#endif
                              /*~E:I2065*/
                              /*~E:A2064*/
                              /*~-1*/
                              }
                              /*~O:I2062*/
                              /*~-2*/
                              else
                              {
                              /*~K*/
                              /*~+:Fehler !!!*/
                              /*~A:2066*/
                              /*~+:Ausf�hrungsstatus auf 'E005' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A2066*/
                              /*~-1*/
                              }
                              /*~E:I2062*/
                           /*~-1*/
                           }
                           /*~O:I2061*/
                           /*~-2*/
                           else
                           {
                              /*~K*/
                              /*~+:Fehler !!!*/
                              /*~A:2067*/
                              /*~+:Ausf�hrungsstatus auf 'E005' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A2067*/
                           /*~-1*/
                           }
                           /*~E:I2061*/
                        /*~-1*/
                        }
                        /*~O:I2060*/
                        /*~-2*/
                        else
                        {
                           /*~A:2068*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A2068*/
                        /*~-1*/
                        }
                        /*~E:I2060*/
                     /*~-1*/
                     }
                     /*~E:I2059*/
                     /*~E:A2058*/
                     /*~-1*/
#endif
                     /*~E:I2057*/
                     /*~I:2069*/
#ifdef MIT_TARATEACH_VIA_RS232
                     /*~A:2070*/
                     /*~+:TET - TEachTare*/
                     /*~I:2071*/
                     if (!strcmp(szCommand,"TET"))
                     /*~-1*/
                     {
                        /*~A:2072*/
                        /*~+:Variablendeklarationen*/
                        /*~T*/

                        /*~E:A2072*/
                        /*~A:2073*/
                        /*~+:Variableninitialisierungen*/
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~E:A2073*/
                        /*~A:2074*/
                        /*~+:Kanal 0*/
                        /*~I:2075*/
#ifdef CHANNEL_0
                        /*~I:2076*/
                        if (!InstructionDecoder_CheckNbParameters(0,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~I:2077*/
                           if (!GET_RESPONSE)
                           /*~-1*/
                           {
                              /*~I:2078*/
                              if (!Limit_TeachTara())
                              /*~-1*/
                              {
                              /*~K*/
                              /*~+:Tarierung erfolgreich*/
                              /*~T*/
                              // Tara �bernehmen
                              Weight_TareWeight = Measurement_GetResult(WEIGHT_WEIGHTCHANNEL,MEASUREMENT_GET_TARE);
                              /*~A:2079*/
                              /*~+:Ausf�hrungsstatus auf 'OKAY' setzen*/
                              /*~+:*/
                              /*~T*/
                              // Ausf�hrungsstatus auf 'OKAY' setzen
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              /*~E:A2079*/
                              /*~A:2080*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              lText2Send = TEXT_TARE_TEACHED;
                              /*~E:A2080*/
                              /*~-1*/
                              }
                              /*~O:I2078*/
                              /*~-2*/
                              else
                              {
                              /*~K*/
                              /*~+:Fehler beim Teachen Kanal 0*/
                              /*~A:2081*/
                              /*~+:Ausf�hrungsstatus auf 'E005' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A2081*/
                              /*~-1*/
                              }
                              /*~E:I2078*/
                           /*~-1*/
                           }
                           /*~O:I2077*/
                           /*~-2*/
                           else
                           {
                              /*~K*/
                              /*~+:Fehler beim Teachen Kanal 1*/
                              /*~A:2082*/
                              /*~+:Ausf�hrungsstatus auf 'E005' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A2082*/
                           /*~-1*/
                           }
                           /*~E:I2077*/
                        /*~-1*/
                        }
                        /*~O:I2076*/
                        /*~-2*/
                        else
                        {
                           /*~A:2083*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A2083*/
                        /*~-1*/
                        }
                        /*~E:I2076*/
                        /*~-1*/
#endif
                        /*~E:I2075*/
                        /*~E:A2074*/
                        /*~A:2084*/
                        /*~+:Kanal 1*/
                        /*~I:2085*/
#ifdef CHANNEL_1
                        /*~I:2086*/
                        if (!InstructionDecoder_CheckNbParameters(0,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~I:2087*/
                           if (!Limit_TeachTara())
                           /*~-1*/
                           {
                              /*~T*/
                              // Tara �bernehmen
                              Weight_TareWeight = Measurement_GetResult(WEIGHT_WEIGHTCHANNEL,MEASUREMENT_GET_TARE);
                              /*~T*/
                              Communication_SendMessage(COMMUNICATION_SPI,COMMUNICATION_SHORT_ACK);
                           /*~-1*/
                           }
                           /*~O:I2087*/
                           /*~-2*/
                           else
                           {
                              /*~T*/
                              Communication_SendMessage(COMMUNICATION_SPI,COMMUNICATION_NOK);
                           /*~-1*/
                           }
                           /*~E:I2087*/
                        /*~-1*/
                        }
                        /*~O:I2086*/
                        /*~-2*/
                        else
                        {
                           /*~A:2088*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A2088*/
                        /*~-1*/
                        }
                        /*~E:I2086*/
                        /*~-1*/
#endif
                        /*~E:I2085*/
                        /*~E:A2084*/
                     /*~-1*/
                     }
                     /*~E:I2071*/
                     /*~E:A2070*/
                     /*~-1*/
#endif
                     /*~E:I2069*/
                     /*~A:2089*/
                     /*~+:TSL - TeStLimits*/
                     /*~I:2090*/
                     if (!strcmp(szCommand,"TSL"))
                     /*~-1*/
                     {
                        /*~A:2091*/
                        /*~+:Variablendeklarationen*/
                        /*~T*/

                        /*~E:A2091*/
                        /*~A:2092*/
                        /*~+:Variableninitialisierungen*/
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~E:A2092*/
                        /*~T*/
                        Parameter[0].nLong = Communication_GetLongParameter(0);
                        /*~A:2093*/
                        /*~+:Kanal 0*/
                        /*~I:2094*/
#ifdef CHANNEL_0
                        /*~I:2095*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~I:2096*/
                           if (!GET_RESPONSE)
                           /*~-1*/
                           {
                              /*~C:2097*/
                              switch (Parameter[0].nLong)
                              /*~-1*/
                              {
                              /*~F:2098*/
                              case 0:
                              /*~-1*/
                              {
                              /*~T*/
                              Limit_SetLimitCheckFlag(0x55);
                              /*~A:2099*/
                              /*~+:Ausf�hrungsstatus auf 'OKAY' setzen*/
                              /*~+:*/
                              /*~T*/
                              // Ausf�hrungsstatus auf 'OKAY' setzen
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              /*~E:A2099*/
                              /*~A:2100*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              lText2Send = TEXT_LOWER_LIMIT_TEST_STARTED;
                              /*~E:A2100*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F2098*/
                              /*~F:2101*/
                              case 1:
                              /*~-1*/
                              {
                              /*~T*/
                              Limit_SetLimitCheckFlag(0xAA);
                              /*~A:2102*/
                              /*~+:Ausf�hrungsstatus auf 'OKAY' setzen*/
                              /*~+:*/
                              /*~T*/
                              // Ausf�hrungsstatus auf 'OKAY' setzen
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              /*~E:A2102*/
                              /*~A:2103*/
                              /*~+:Text f�r Terminalbetrieb*/
                              /*~T*/
                              lText2Send = TEXT_UPPER_LIMIT_TEST_STARTED;
                              /*~E:A2103*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F2101*/
                              /*~O:C2097*/
                              /*~-2*/
                              default:
                              {
                              /*~A:2104*/
                              /*~+:Ausf�hrungsstatus auf 'E002' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E002;
                              /*~E:A2104*/
                              /*~-1*/
                              }
                              /*~-1*/
                              }
                              /*~E:C2097*/
                           /*~-1*/
                           }
                           /*~O:I2096*/
                           /*~-2*/
                           else
                           {
                              /*~K*/
                              /*~+:Kanal 1 sendete keine Best�tigung*/
                              /*~A:2105*/
                              /*~+:Ausf�hrungsstatus auf 'E005' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A2105*/
                           /*~-1*/
                           }
                           /*~E:I2096*/
                        /*~-1*/
                        }
                        /*~O:I2095*/
                        /*~-2*/
                        else
                        {
                           /*~A:2106*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A2106*/
                        /*~-1*/
                        }
                        /*~E:I2095*/
                        /*~-1*/
#endif
                        /*~E:I2094*/
                        /*~E:A2093*/
                        /*~A:2107*/
                        /*~+:Kanal 1*/
                        /*~I:2108*/
#ifdef CHANNEL_1
                        /*~I:2109*/
                        if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                        /*~-1*/
                        {
                           /*~I:2110*/
                           if (!GET_RESPONSE)
                           /*~-1*/
                           {
                              /*~C:2111*/
                              switch (Parameter[0].nLong)
                              /*~-1*/
                              {
                              /*~F:2112*/
                              case 0:
                              /*~-1*/
                              {
                              /*~A:2113*/
                              /*~+:Ausf�hrungsstatus auf 'OKAY' setzen*/
                              /*~+:*/
                              /*~T*/
                              // Ausf�hrungsstatus auf 'OKAY' setzen
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              /*~E:A2113*/
                              /*~T*/
                              Limit_SetLimitCheckFlag(0x55);
                              /*~T*/
                              Communication_SendMessage(COMMUNICATION_SPI,COMMUNICATION_SHORT_ACK);
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F2112*/
                              /*~F:2114*/
                              case 1:
                              /*~-1*/
                              {
                              /*~A:2115*/
                              /*~+:Ausf�hrungsstatus auf 'OKAY' setzen*/
                              /*~+:*/
                              /*~T*/
                              // Ausf�hrungsstatus auf 'OKAY' setzen
                              byCommandStatus = INSTRUCTIONDECODER_SEND_OK;

                              /*~E:A2115*/
                              /*~T*/
                              Limit_SetLimitCheckFlag(0xAA);
                              /*~T*/
                              Communication_SendMessage(COMMUNICATION_SPI,COMMUNICATION_SHORT_ACK);
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F2114*/
                              /*~O:C2111*/
                              /*~-2*/
                              default:
                              {
                              /*~A:2116*/
                              /*~+:Ausf�hrungsstatus auf 'E002' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E002;
                              /*~E:A2116*/
                              /*~-1*/
                              }
                              /*~-1*/
                              }
                              /*~E:C2111*/
                           /*~-1*/
                           }
                           /*~O:I2110*/
                           /*~-2*/
                           else
                           {
                              /*~A:2117*/
                              /*~+:Ausf�hrungsstatus auf 'E005' setzen*/
                              /*~T*/
                              byCommandStatus = INSTRUCTIONDECODER_SEND_E005;
                              /*~E:A2117*/
                           /*~-1*/
                           }
                           /*~E:I2110*/
                        /*~-1*/
                        }
                        /*~O:I2109*/
                        /*~-2*/
                        else
                        {
                           /*~A:2118*/
                           /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                           /*~T*/

                           /*~E:A2118*/
                        /*~-1*/
                        }
                        /*~E:I2109*/
                        /*~-1*/
#endif
                        /*~E:I2108*/
                        /*~E:A2107*/
                     /*~-1*/
                     }
                     /*~E:I2090*/
                     /*~E:A2089*/
                     /*~T*/
                     break;
                  /*~-1*/
                  }
                  /*~E:F2056*/
                  /*~E:A2055*/
                  /*~A:2119*/
                  /*~+:V*/
                  /*~F:2120*/
                  case 'V':
                  /*~-1*/
                  {
                     /*~A:2121*/
                     /*~+:VAS - ViewAlarmStatus*/
                     /*~K*/
                     /*~+:*/
                     /*~+:=> VDG*/
                     /*~E:A2121*/
                     /*~A:2122*/
                     /*~+:VDG - ViewDiaGnosis*/
                     /*~I:2123*/
                     // if ((!strcmp(szCommand,"VAS"))||(!strcmp(szCommand,"VDG")))
                     if (!strcmp(szCommand,"VAS"))

                     /*~-1*/
                     {
                        /*~A:2124*/
                        /*~+:Variablendeklarationen*/
                        /*~T*/
                        unsigned char byCounter;
                        /*~E:A2124*/
                        /*~A:2125*/
                        /*~+:Variableninitialisierungen*/
                        /*~T*/
                        byCounter = 3;
                        /*~E:A2125*/
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~I:2126*/
                        if (!SYSTEM_MRW_MANAGER)
                        /*~-1*/
                        {
                           /*~I:2127*/
                           if (!InstructionDecoder_CheckNbParameters(0,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                           /*~-1*/
                           {
                              /*~I:2128*/
#ifdef CHANNEL_0
                              /*~T*/
                              //  Wg. der langen Dauer der Ausgabe die Synchronisationspr�fung ausschalten
                              Communication_SendSPICommand("iSCS 0");
                              /*~I:2129*/
                              if (Communication_IsOK())
                              /*~-1*/
                              {
                              /*~T*/
                              Diagnosis_PrintMemory();
                              /*~T*/
                              Communication_SendSPICommand("iVDG");
                              /*~I:2130*/
                              if (Communication_IsOK())
                              /*~-1*/
                              {
                              /*~T*/
                              // Wg. der langen Dauer der Ausgabe die Synchronisationspr�fung ausschalten
                              System_SetCheckSynchronisation(0);
                              /*~-1*/
                              }
                              /*~E:I2130*/
                              /*~-1*/
                              }
                              /*~E:I2129*/
                              /*~-1*/
#endif
                              /*~E:I2128*/
                              /*~A:2131*/
                              /*~+:ausgeklammert*/
                              /*~I:2132*/
#ifdef MOF
                              /*~I:2133*/
#ifdef CHANNEL_0
                              /*~U:2134*/
                              /*~-2*/
                              do
                              {
                              /*~T*/
                              Communication_SendSPICommand("iSCS 0");
                              /*~-1*/
                              }
                              /*~O:U2134*/
                              while (!Communication_IsOK() && --byCounter);
                              /*~E:U2134*/
                              /*~T*/
                              Diagnosis_PrintMemory();
                              /*~T*/
                              byCounter = 3;
                              /*~U:2135*/
                              /*~-2*/
                              do
                              {
                              /*~T*/
                              Communication_SendSPICommand("iVDG");
                              /*~-1*/
                              }
                              /*~O:U2135*/
                              while (!Communication_IsOK() && --byCounter);
                              /*~E:U2135*/
                              /*~I:2136*/
                              if (byCounter)
                              /*~-1*/
                              {
                              /*~T*/
                              // Wg. der langen Dauer der Ausgabe die Synchronisationspr�fung ausschalten
                              System_SetCheckSynchronisation(0);
                              /*~-1*/
                              }
                              /*~E:I2136*/
                              /*~-1*/
#endif
                              /*~E:I2133*/
                              /*~-1*/
#endif
                              /*~E:I2132*/
                              /*~E:A2131*/
                           /*~-1*/
                           }
                           /*~O:I2127*/
                           /*~-2*/
                           else
                           {
                              /*~A:2137*/
                              /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                              /*~T*/

                              /*~E:A2137*/
                           /*~-1*/
                           }
                           /*~E:I2127*/
                        /*~-1*/
                        }
                        /*~O:I2126*/
                        /*~-2*/
                        else
                        {
                           /*~I:2138*/
                           if (!InstructionDecoder_CheckNbParameters(1,SHOW_ERRORS_BY_CH0,&byCommandStatus))
                           /*~-1*/
                           {
                              /*~T*/
                              Parameter[0].nLong = Communication_GetLongParameter(0); 
                              /*~C:2139*/
                              switch (Parameter[0].nLong)
                              /*~-1*/
                              {
                              /*~F:2140*/
                              case 0:
                              /*~-1*/
                              {
                              /*~T*/
                              // Kanal 0

                              /*~I:2141*/
#ifdef CHANNEL_0
                              /*~T*/
                              //  Wg. der langen Dauer der Ausgabe die Synchronisationspr�fung ausschalten
                              Communication_SendSPICommand("iSCS 0");
                              /*~I:2142*/
                              if (Communication_IsOK())
                              /*~-1*/
                              {
                              /*~T*/
                              Diagnosis_PrintMemory();
                              /*~T*/
                              Communication_SendSPICommand("iSCS 1");
                              /*~-1*/
                              }
                              /*~E:I2142*/
                              /*~-1*/
#endif
                              /*~E:I2141*/
                              /*~A:2143*/
                              /*~+:ausgeklammert*/
                              /*~I:2144*/
#ifdef MOF
                              /*~I:2145*/
#ifdef CHANNEL_0
                              /*~U:2146*/
                              /*~-2*/
                              do
                              {
                              /*~T*/
                              Communication_SendSPICommand("iSCS 0");
                              /*~-1*/
                              }
                              /*~O:U2146*/
                              while (!Communication_IsOK() && --byCounter);
                              /*~E:U2146*/
                              /*~T*/
                              Diagnosis_PrintMemory();
                              /*~T*/
                              byCounter = 3;
                              /*~U:2147*/
                              /*~-2*/
                              do
                              {
                              /*~T*/
                              Communication_SendSPICommand("iSCS 1");
                              /*~-1*/
                              }
                              /*~O:U2147*/
                              while (!Communication_IsOK() && --byCounter);
                              /*~E:U2147*/
                              /*~-1*/
#endif
                              /*~E:I2145*/
                              /*~-1*/
#endif
                              /*~E:I2144*/
                              /*~E:A2143*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F2140*/
                              /*~F:2148*/
                              case 1:
                              /*~-1*/
                              {
                              /*~T*/
                              // Kanal 1
                              /*~I:2149*/
#ifdef CHANNEL_0
                              /*~T*/
                              Communication_SendSPICommand("iVDG");
                              /*~I:2150*/
                              if (Communication_IsOK())
                              /*~-1*/
                              {
                              /*~T*/
                              // Wg. der langen Dauer der Ausgabe die Synchronisationspr�fung ausschalten
                              System_SetCheckSynchronisation(0);
                              /*~-1*/
                              }
                              /*~E:I2150*/
                              /*~-1*/
#endif
                              /*~E:I2149*/
                              /*~A:2151*/
                              /*~+:ausgeklammert*/
                              /*~I:2152*/
#ifdef MOF
                              /*~I:2153*/
#ifdef CHANNEL_0
                              /*~U:2154*/
                              /*~-2*/
                              do
                              {
                              /*~T*/
                              Communication_SendSPICommand("iVDG");
                              /*~-1*/
                              }
                              /*~O:U2154*/
                              while (!Communication_IsOK() && --byCounter);
                              /*~E:U2154*/
                              /*~I:2155*/
                              if (byCounter)
                              /*~-1*/
                              {
                              /*~T*/
                              // Wg. der langen Dauer der Ausgabe die Synchronisationspr�fung ausschalten
                              System_SetCheckSynchronisation(0);
                              /*~-1*/
                              }
                              /*~E:I2155*/
                              /*~-1*/
#endif
                              /*~E:I2153*/
                              /*~-1*/
#endif
                              /*~E:I2152*/
                              /*~E:A2151*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F2148*/
                              /*~F:2156*/
                              case 2:
                              /*~-1*/
                              {
                              /*~T*/
                              // Freier Speicher Kanal 0
                              /*~I:2157*/
#ifdef CHANNEL_0
                              /*~T*/
                              Diagnosis_PrintFreeMemory();
                              /*~-1*/
#endif
                              /*~E:I2157*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F2156*/
                              /*~F:2158*/
                              case 3:
                              /*~-1*/
                              {
                              /*~T*/
                              // Freier Speicher Kanal 1
                              /*~I:2159*/
#ifdef CHANNEL_1
                              /*~T*/
                              Diagnosis_PrintFreeMemory();
                              /*~-1*/
#endif
                              /*~E:I2159*/
                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F2158*/
                              /*~O:C2139*/
                              /*~-2*/
                              default:
                              {
                              /*~T*/
                              // Zur�cksetzen der Lese-Prozedur

                              Diagnosis_InitReadProcedure();
                              /*~-1*/
                              }
                              /*~-1*/
                              }
                              /*~E:C2139*/
                           /*~-1*/
                           }
                           /*~O:I2138*/
                           /*~-2*/
                           else
                           {
                              /*~A:2160*/
                              /*~+:Fehler - Ausgabe �ber Pr�ffunktion*/
                              /*~T*/

                              /*~E:A2160*/
                           /*~-1*/
                           }
                           /*~E:I2138*/
                        /*~-1*/
                        }
                        /*~E:I2126*/
                     /*~-1*/
                     }
                     /*~E:I2123*/
                     /*~E:A2122*/
                     /*~T*/
                     break;
                  /*~-1*/
                  }
                  /*~E:F2120*/
                  /*~E:A2119*/
                  /*~K*/
                  /*~+:// interne Befehle (iXXX)*/
                  /*~A:2161*/
                  /*~+:i*/
                  /*~F:2162*/
                  case 'i':
                  /*~-1*/
                  {
                     /*~I:2163*/
#ifdef CHANNEL_0
                     /*~T*/
                     // Text wurde bereits gesendet
                     byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                     /*~-1*/
#endif
                     /*~E:I2163*/
                     /*~I:2164*/
#ifdef CHANNEL_1
                     /*~A:2165*/
                     /*~+:iACR - internal Command - AutomaticCompensationResults */
                     /*~I:2166*/
                     if (!strcmp(szCommand,"iACR"))
                     /*~-1*/
                     {
                        /*~A:2167*/
                        /*~+:SPI-Debugging - nur zu Testzwecken*/
                        /*~I:2168*/
#ifdef DEVELOPMENT_SW
                        /*~T*/
                        CommunicationControl.ulSPICounter++;
                        /*~-1*/
#endif
                        /*~E:I2168*/
                        /*~E:A2167*/
                        /*~T*/
                        Parameter[0].nLong = Communication_GetLongParameter(0);
                        Parameter[1].nLong = Communication_GetLongParameter(1);
                        /*~T*/
                        // Befehlsbest�tigung senden
                        Communication_SendSPICommand("OK");
                        /*~T*/
                        Compensation_PrintCompensationValues(1,Parameter[0].nLong,Parameter[1].nLong,0);
                     /*~-1*/
                     }
                     /*~E:I2166*/
                     /*~E:A2165*/
                     /*~A:2169*/
                     /*~+:iACS - internal Command - AutomaticCompensationStatus */
                     /*~I:2170*/
                     if (!strcmp(szCommand,"iACS"))
                     /*~-1*/
                     {
                        /*~A:2171*/
                        /*~+:Variablendeklarationen*/
                        /*~T*/
                        char byRecCharacteristicsOn;
                        /*~E:A2171*/
                        /*~A:2172*/
                        /*~+:Variableninitialisierungen*/
                        /*~T*/

                        /*~E:A2172*/
                        /*~A:2173*/
                        /*~+:SPI-Debugging - nur zu Testzwecken*/
                        /*~I:2174*/
#ifdef DEVELOPMENT_SW
                        /*~T*/
                        CommunicationControl.ulSPICounter++;
                        /*~-1*/
#endif
                        /*~E:I2174*/
                        /*~E:A2173*/
                        /*~T*/
                        MRW_Compensation_GetData(MRW_COMPENSATION_GET_REC_CHARACTERISTICS_ONOFF,0,&byRecCharacteristicsOn); 
                        /*~I:2175*/
                        if (byRecCharacteristicsOn)
                        /*~-1*/
                        {
                           /*~T*/
                           // Ausgabe Kanal 1
                           Compensation_PrintCompensationValues(0,0xFF,0,1);
                           /*~T*/
                           byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                        /*~-1*/
                        }
                        /*~E:I2175*/
                        /*~T*/
                        bDoNotWriteResult2Buffer = 0;
                     /*~-1*/
                     }
                     /*~E:I2170*/
                     /*~E:A2169*/
                     /*~A:2176*/
                     /*~+:iART - internal Command - AutomaticRecordTemperaturecompensation stoppen */
                     /*~I:2177*/
                     if (!strcmp(szCommand,"iART"))
                     /*~-1*/
                     {
                        /*~A:2178*/
                        /*~+:SPI-Debugging - nur zu Testzwecken*/
                        /*~I:2179*/
#ifdef DEVELOPMENT_SW
                        /*~T*/
                        CommunicationControl.ulSPICounter++;
                        /*~-1*/
#endif
                        /*~E:I2179*/
                        /*~E:A2178*/
                        /*~T*/
                        // Kennlinienaufnahme stoppen
                        MRW_Compensation_SetRecCharacteristicsOn(0);

                        System_SetSystemState(SYSTEM_RUNNING);
                        /*~A:2180*/
                        /*~+:Eintrag in Diagnosespeicher vornehmen*/
                        /*~T*/
                        ulDiagnosisEntry2Set = DIAGNOSIS_MESSAGE_TEMPCOMPENSATION_STOPPED;
                        /*~E:A2180*/
                        /*~T*/
                        // Best�tigung
                        byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                     /*~-1*/
                     }
                     /*~E:I2177*/
                     /*~E:A2176*/
                     /*~A:2181*/
                     /*~+:iCDL - internal Command - Connect2Docklight*/
                     /*~I:2182*/
                     if (!strcmp(szCommand,"iCDL"))
                     /*~-1*/
                     {
                        /*~A:2183*/
                        /*~+:SPI-Debugging - nur zu Testzwecken*/
                        /*~I:2184*/
#ifdef DEVELOPMENT_SW
                        /*~T*/
                        CommunicationControl.ulSPICounter++;
                        /*~-1*/
#endif
                        /*~E:I2184*/
                        /*~E:A2183*/
                        /*~T*/
                        // Docklightmodus setzen
                        System_Connect2MRW_Manager(0);

                        byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                     /*~-1*/
                     }
                     /*~E:I2182*/
                     /*~E:A2181*/
                     /*~A:2185*/
                     /*~+:iGDG - internal Command - GetDiaGnosis*/
                     /*~I:2186*/
                     if (!strcmp(szCommand,"iGDG"))
                     /*~-1*/
                     {
                        /*~A:2187*/
                        /*~+:Variablendeklarationen*/
                        /*~T*/
                        unsigned long 	ulMessage;
                        unsigned long 	ulTime;
                        /*~E:A2187*/
                        /*~A:2188*/
                        /*~+:SPI-Debugging - nur zu Testzwecken*/
                        /*~I:2189*/
#ifdef DEVELOPMENT_SW
                        /*~T*/
                        CommunicationControl.ulSPICounter++;
                        /*~-1*/
#endif
                        /*~E:I2189*/
                        /*~E:A2188*/
                        /*~T*/
                        byRetVal = Diagnosis_ReadMessageFromFlash(&ulTime,&ulMessage);
                        /*~T*/
                        Communication_SendLong(COMMUNICATION_SPI,0,ulTime,0,0);
                        Communication_SendLong(COMMUNICATION_SPI,0,ulMessage,0,0);
                        Communication_SendLong(COMMUNICATION_SPI,0,byRetVal,0,0);
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                     /*~-1*/
                     }
                     /*~E:I2186*/
                     /*~E:A2185*/
                     /*~A:2190*/
                     /*~+:iGLP - internal Command - GetLimitstatePartner*/
                     /*~I:2191*/
                     if (!strcmp(szCommand,"iGLP"))
                     /*~-1*/
                     {
                        /*~A:2192*/
                        /*~+:SPI-Debugging - nur zu Testzwecken*/
                        /*~I:2193*/
#ifdef DEVELOPMENT_SW
                        /*~T*/
                        CommunicationControl.ulSPICounter++;
                        /*~-1*/
#endif
                        /*~E:I2193*/
                        /*~E:A2192*/
                        /*~T*/
                        // Limitstatus des Partners auslesen
                        Global.chLimitStatus_Partner = (char)Communication_GetLongParameter(1);
                        /*~I:2194*/
                        if (!Communication_SendLong(COMMUNICATION_SPI,0,Limit_GetLimitState(),0,1))
                        /*~-1*/
                        {
                           /*~A:2195*/
                           /*~+:jetzt noch Ma�nahmen zur �berpr�fung der Gegenstelle treffen */
                           /*~T*/
                           System_IncCheckSynchronisationCounter();
                           /*~E:A2195*/
                        /*~-1*/
                        }
                        /*~E:I2194*/
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                     /*~-1*/
                     }
                     /*~E:I2191*/
                     /*~E:A2190*/
                     /*~A:2196*/
                     /*~+:iGPS - internal Command - GetPartnerState*/
                     /*~I:2197*/
                     if (!strcmp(szCommand,"iGPS"))
                     /*~-1*/
                     {
                        /*~A:2198*/
                        /*~+:Variablendeklarationen*/
                        /*~T*/
                        long lSystemStatePartner;

                        /*~E:A2198*/
                        /*~A:2199*/
                        /*~+:SPI-Debugging - nur zu Testzwecken*/
                        /*~I:2200*/
#ifdef DEVELOPMENT_SW
                        /*~T*/
                        CommunicationControl.ulSPICounter++;
                        /*~-1*/
#endif
                        /*~E:I2200*/
                        /*~E:A2199*/
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~C:2201*/
                        switch (Communication_GetLongParameter(0))
                        /*~-1*/
                        {
                           /*~F:2202*/
                           case 0:
                           /*~-1*/
                           {
                              /*~T*/
                              lSystemStatePartner = Communication_GetLongParameter(1);
                              /*~I:2203*/
                              // Partner-Systemstatus kann nur gesetzt werden, wenn das System nicht im Fehlerzustand ist !
                              if (SYSTEMSTATE != SYSTEM_ERROR)
                              /*~-1*/
                              {
                              /*~T*/
                              // Systemstatus des Partners auslesen
                              SYSTEMSTATE_PARTNER = lSystemStatePartner;
                              /*~-1*/
                              }
                              /*~E:I2203*/
                              /*~I:2204*/
#ifdef MIT_SYSTEMFEHLER_BEI_PARTNER_SYSTEMFEHLER
                              /*~I:2205*/
                              if (SYSTEMSTATE_PARTNER == SYSTEM_ERROR)
                              /*~-1*/
                              {
                              /*~A:2206*/
                              /*~+:Sicherheitsfunktion aufrufen*/
                              /*~T*/
                              // Sicherheitsfunktion aufrufen
                              Diagnosis_SecurityPartnerSystemError(SYSTEM_PARTNER_IN_SYSTEMERROR);
                              /*~E:A2206*/
                              /*~-1*/
                              }
                              /*~E:I2205*/
                              /*~-1*/
#endif
                              /*~E:I2204*/
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_SPI,0,SYSTEMSTATE,0,1);
                              /*~T*/
                              break;
                           /*~-1*/
                           }
                           /*~E:F2202*/
                           /*~F:2207*/
                           case 1:
                           /*~-1*/
                           {
                              /*~T*/
                              // Limitstatus des Partners auslesen
                              Global.chLimitStatus_Partner = (char)Communication_GetLongParameter(1);
                              /*~I:2208*/
                              if (!Communication_SendLong(COMMUNICATION_SPI,0,Limit_GetLimitState(),0,1))
                              /*~-1*/
                              {
                              /*~A:2209*/
                              /*~+:jetzt noch Ma�nahmen zur �berpr�fung der Gegenstelle treffen */
                              /*~T*/
                              System_IncCheckSynchronisationCounter();
                              /*~E:A2209*/
                              /*~-1*/
                              }
                              /*~E:I2208*/
                              /*~T*/
                              break;
                           /*~-1*/
                           }
                           /*~E:F2207*/
                        /*~-1*/
                        }
                        /*~E:C2201*/
                     /*~-1*/
                     }
                     /*~E:I2197*/
                     /*~E:A2196*/
                     /*~A:2210*/
                     /*~+:iGRS - internal Command - GetlastcommadexecutionReSult*/
                     /*~I:2211*/
                     if (!strcmp(szCommand,"iGRS"))
                     /*~-1*/
                     {
                        /*~A:2212*/
                        /*~+:SPI-Debugging - nur zu Testzwecken*/
                        /*~I:2213*/
#ifdef DEVELOPMENT_SW
                        /*~T*/
                        CommunicationControl.ulSPICounter++;
                        /*~-1*/
#endif
                        /*~E:I2213*/
                        /*~E:A2212*/
                        /*~A:2214*/
                        /*~+:Eintrag in Diagnosespeicher vornehmen*/
                        /*~I:2215*/
                        if (ulDiagnosisEntry2SetAtiGRS)
                        /*~-1*/
                        {
                           /*~T*/
                           Diagnosis_WriteMessage2Flash(ulDiagnosisEntry2SetAtiGRS);

                           ulDiagnosisEntry2SetAtiGRS = 0;
                        /*~-1*/
                        }
                        /*~E:I2215*/
                        /*~E:A2214*/
                        /*~I:2216*/
                        if (!Communication_SendLong(COMMUNICATION_SPI,0,g_byLastCommandExecutionResult,0,1))
                        /*~-1*/
                        {
                           /*~T*/
                           // Inhalt wieder l�schen
                           g_byLastCommandExecutionResult = 0xA5;
                        /*~-1*/
                        }
                        /*~E:I2216*/
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                        /*~K*/
                        /*~+:/~* Hinzugef�gt am 09.02.2022 *~/*/
                        /*~I:2217*/
#ifndef DEVELOPMENT_SW	/* Nur definiert in der Debug-Version */
                        /*~I:2218*/
                        if (bDoReset != 0)
                        /*~-1*/
                        {
                           /*~T*/
                           System_Reset();
                        /*~-1*/
                        }
                        /*~E:I2218*/
                        /*~-1*/
#endif
                        /*~E:I2217*/
                        /*~K*/
                        /*~+:/~* Ende - Hinzugef�gt am 09.02.2022 *~/*/
                     /*~-1*/
                     }
                     /*~E:I2211*/
                     /*~E:A2210*/
                     /*~A:2219*/
                     /*~+:iGSV - internal Command - GetStoredValue */
                     /*~I:2220*/
                     if (!strcmp(szCommand,"iGSV"))
                     /*~-1*/
                     {
                        /*~A:2221*/
                        /*~+:Variablendeklarationen*/
                        /*~T*/
                        unsigned char byValue2Get;
                        /*~E:A2221*/
                        /*~A:2222*/
                        /*~+:Variableninitialisierungen*/
                        /*~T*/

                        /*~E:A2222*/
                        /*~A:2223*/
                        /*~+:SPI-Debugging - nur zu Testzwecken*/
                        /*~I:2224*/
#ifdef DEVELOPMENT_SW
                        /*~T*/
                        CommunicationControl.ulSPICounter++;
                        /*~-1*/
#endif
                        /*~E:I2224*/
                        /*~E:A2223*/
                        /*~T*/
                        byValue2Get = (unsigned char)Communication_GetLongParameter(0);
                        /*~I:2225*/
                        if (g_ulTimeoutValue < SYSTEMTIME)
                        /*~-1*/
                        {
                           /*~T*/
                           // Timeout

                           // Inhalt wieder l�schen

                           /*~T*/
                           g_byValueStored = 0;
                        /*~-1*/
                        }
                        /*~O:I2225*/
                        /*~-2*/
                        else
                        {
                           /*~I:2226*/
                           if (!g_byValueStored)
                           /*~-1*/
                           {
                              /*~T*/
                              // Es liegt z.Z. kein Wert vor
                           /*~-1*/
                           }
                           /*~O:I2226*/
                           /*~-2*/
                           else
                           {
                              /*~I:2227*/
                              if (g_byValueStored == byValue2Get)
                              /*~-1*/
                              {
                              /*~T*/
                              // Der zu holende Wert entspricht dem abgespeicherten
                              /*~T*/
                              g_byValueStored = 0;
                              /*~C:2228*/
                              switch (byValue2Get)
                              /*~-1*/
                              {
                              /*~F:2229*/
                              case COMMUNICATION_NUMBER_OF_MEASUREMENTS:
                              case COMMUNICATION_FILTER_DEPTH:
                              case COMMUNICATION_LOADCELL:
                              case COMMUNICATION_MOTION_FILTER:
                              case COMMUNICATION_COMPENSATION_STATE:
                              case COMMUNICATION_E_COMPENSATION_STATE:
                              case COMMUNICATION_CURRENTINTERFACE_FEEDBACK_STATE:

                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_SPI,0,g_Value.byChar,0,0);
                              /*~T*/
                              return;
                              /*~-1*/
                              }
                              /*~E:F2229*/
                              /*~F:2230*/
                              case COMMUNICATION_FILTER_WIDTH:
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_SPI,0,g_Value.nInt,0,0);
                              /*~T*/
                              return;
                              /*~-1*/
                              }
                              /*~E:F2230*/
                              /*~F:2231*/
                              case COMMUNICATION_TIME_HYSTERESIS:
                              case COMMUNICATION_RS232_BAUDRATE:
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendLong(COMMUNICATION_SPI,0,g_Value.nLong,0,0);
                              /*~T*/
                              return;
                              /*~-1*/
                              }
                              /*~E:F2231*/
                              /*~F:2232*/
                              case COMMUNICATION_CHECKLIMIT_ZEROPOINTCHECK:
                              case COMMUNICATION_CHECKLIMIT_MAX_DEVIATION:
                              case COMMUNICATION_CHECKLIMIT_MAX_DRIFT:
                              case COMMUNICATION_MOTION_LIMIT:
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendFloat(COMMUNICATION_SPI,0,g_Value.fFloat,2,0,0);
                              /*~T*/
                              return;
                              /*~-1*/
                              }
                              /*~E:F2232*/
                              /*~-1*/
                              }
                              /*~E:C2228*/
                              /*~-1*/
                              }
                              /*~E:I2227*/
                           /*~-1*/
                           }
                           /*~E:I2226*/
                        /*~-1*/
                        }
                        /*~E:I2225*/
                        /*~T*/
                        Communication_SendString(COMMUNICATION_SPI,"NAV",0,0);
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                     /*~-1*/
                     }
                     /*~E:I2220*/
                     /*~E:A2219*/
                     /*~A:2233*/
                     /*~+:iGVR - internal Command - GetVeRsion */
                     /*~I:2234*/
                     if (!strcmp(szCommand,"iGVR"))
                     /*~-1*/
                     {
                        /*~A:2235*/
                        /*~+:SPI-Debugging - nur zu Testzwecken*/
                        /*~I:2236*/
#ifdef DEVELOPMENT_SW
                        /*~T*/
                        CommunicationControl.ulSPICounter++;
                        /*~-1*/
#endif
                        /*~E:I2236*/
                        /*~E:A2235*/
                        /*~T*/
                        Parameter[0].nLong = Communication_GetLongParameter(0); 
                        /*~C:2237*/
                        switch (Parameter[0].nLong)
                        /*~-1*/
                        {
                           /*~F:2238*/
                           case 0:		// Hardware-Version
                           /*~-1*/
                           {
                              /*~T*/
                              Communication_SendString(COMMUNICATION_SPI,TEXT_HARDWARE_VERSION,0,0);
                              /*~T*/
                              break;
                           /*~-1*/
                           }
                           /*~E:F2238*/
                           /*~F:2239*/
                           case 1:		// Software-Version
                           /*~-1*/
                           {
                              /*~T*/
                              Communication_SendString(COMMUNICATION_SPI,TEXT_SOFTWARE_VERSION,0,0);
                              /*~T*/
                              break;
                           /*~-1*/
                           }
                           /*~E:F2239*/
                        /*~-1*/
                        }
                        /*~E:C2237*/
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                     /*~-1*/
                     }
                     /*~E:I2234*/
                     /*~E:A2233*/
                     /*~A:2240*/
                     /*~+:iLED - internal Command - LEDset*/
                     /*~I:2241*/
                     if (!strcmp(szCommand,"iLED"))
                     /*~-1*/
                     {
                        /*~A:2242*/
                        /*~+:SPI-Debugging - nur zu Testzwecken*/
                        /*~I:2243*/
#ifdef DEVELOPMENT_SW
                        /*~T*/
                        CommunicationControl.ulSPICounter++;
                        /*~-1*/
#endif
                        /*~E:I2243*/
                        /*~E:A2242*/
                        /*~I:2244*/
                        if (Communication_GetLongParameter(0))
                        /*~-1*/
                        {
                           /*~I:2245*/
#ifndef SYSTEM_CND_LEDS_4_DEBUG
                           /*~T*/
                           // Platinen-LED einschalten
                           P06 = 0;

                           /*~-1*/
#endif
                           /*~E:I2245*/
                        /*~-1*/
                        }
                        /*~O:I2244*/
                        /*~-2*/
                        else
                        {
                           /*~I:2246*/
#ifndef SYSTEM_CND_LEDS_4_DEBUG 
                           /*~T*/
                           // Platinen-LED ausschalten
                           P06 = 1;

                           /*~-1*/
#endif
                           /*~E:I2246*/
                        /*~-1*/
                        }
                        /*~E:I2244*/
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                        // byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                     /*~-1*/
                     }
                     /*~E:I2241*/
                     /*~E:A2240*/
                     /*~A:2247*/
                     /*~+:iSCS - internal Command - SetCheckSysnchronisation onoff */
                     /*~I:2248*/
                     if (!strcmp(szCommand,"iSCS"))
                     /*~-1*/
                     {
                        /*~A:2249*/
                        /*~+:SPI-Debugging - nur zu Testzwecken*/
                        /*~I:2250*/
#ifdef DEVELOPMENT_SW
                        /*~T*/
                        CommunicationControl.ulSPICounter++;
                        /*~-1*/
#endif
                        /*~E:I2250*/
                        /*~E:A2249*/
                        /*~I:2251*/
                        if (Communication_GetLongParameter(0))
                        /*~-1*/
                        {
                           /*~T*/
                           // Synchronisationspr�fung ausschalten
                           System_SetCheckSynchronisation(1);
                        /*~-1*/
                        }
                        /*~O:I2251*/
                        /*~-2*/
                        else
                        {
                           /*~T*/
                           // Synchronisationspr�fung einschalten
                           System_SetCheckSynchronisation(0);
                        /*~-1*/
                        }
                        /*~E:I2251*/
                        /*~T*/
                        byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                        // byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                     /*~-1*/
                     }
                     /*~E:I2248*/
                     /*~E:A2247*/
                     /*~I:2252*/
#ifdef MIT_TEACHIN_FUNKTION
                     /*~A:2253*/
                     /*~+:iTIS - internal Command - TeachInStatus*/
                     /*~I:2254*/
                     if (!strcmp(szCommand,"iTIS"))
                     /*~-1*/
                     {
                        /*~A:2255*/
                        /*~+:SPI-Debugging - nur zu Testzwecken*/
                        /*~I:2256*/
#ifdef DEVELOPMENT_SW
                        /*~T*/
                        CommunicationControl.ulSPICounter++;
                        /*~-1*/
#endif
                        /*~E:I2256*/
                        /*~E:A2255*/
                        /*~T*/
                        Communication_SendLong(COMMUNICATION_SPI,0,(long)Global.chTeachInStatus,0,1);

                        // TeachIn-Interface aufrufen
                        TeachIn_Interface((char)Communication_GetLongParameter(0));

                        /*~T*/
                        // Merker f�r ein interpretierbares Kommando setzen
                        byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
                     /*~-1*/
                     }
                     /*~E:I2254*/
                     /*~E:A2253*/
                     /*~-1*/
#endif
                     /*~E:I2252*/
                     /*~A:2257*/
                     /*~+:iTSY - internal Command - TimerSYnchronize*/
                     /*~I:2258*/
                     if (!strcmp(szCommand,"iTSY"))
                     /*~-1*/
                     {
                        /*~A:2259*/
                        /*~+:Variablendeklartionen*/
                        /*~T*/
                        long lTimerDeviation;
                        unsigned long ulOperatingTimePartner;
                        /*~E:A2259*/
                        /*~A:2260*/
                        /*~+:SPI-Debugging - nur zu Testzwecken*/
                        /*~I:2261*/
#ifdef DEVELOPMENT_SW
                        /*~T*/
                        CommunicationControl.ulSPICounter++;
                        /*~-1*/
#endif
                        /*~E:I2261*/
                        /*~E:A2260*/
                        /*~T*/
                        // Differenz der beiden Zeitgeber errechnen
                        ulOperatingTimePartner = (unsigned long)Communication_GetLongParameter(0);
                        lTimerDeviation = (long)OPERATINGHOURS - (long)ulOperatingTimePartner;

                        // Timerstand korrigieren
                        OPERATINGHOURS -= lTimerDeviation;
                        CUSTOMTIMER -= lTimerDeviation;

                        byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                     /*~-1*/
                     }
                     /*~E:I2258*/
                     /*~E:A2257*/
                     /*~A:2262*/
                     /*~+:iVDG - internal Command - ViewDiaGnosis*/
                     /*~I:2263*/
                     if (!strcmp(szCommand,"iVDG"))
                     /*~-1*/
                     {
                        /*~A:2264*/
                        /*~+:SPI-Debugging - nur zu Testzwecken*/
                        /*~I:2265*/
#ifdef DEVELOPMENT_SW
                        /*~T*/
                        CommunicationControl.ulSPICounter++;
                        /*~-1*/
#endif
                        /*~E:I2265*/
                        /*~E:A2264*/
                        /*~T*/
                        // Befehlsbest�tigung senden
                        Communication_SendSPICommand("OK");
                        /*~T*/
                        Diagnosis_PrintMemory();
                     /*~-1*/
                     }
                     /*~O:I2263*/
                     /*~-2*/
                     else
                     {
                        /*~T*/
                        //                     byCommandStatus = INSTRUCTIONDECODER_SEND_OK;
                     /*~-1*/
                     }
                     /*~E:I2263*/
                     /*~E:A2262*/
                     /*~K*/
                     /*~+:*/
                     /*~A:2266*/
                     /*~+:SPI-Debugging - nur zu Testzwecken*/
                     /*~I:2267*/
#ifdef DEVELOPMENT_SW
                     /*~I:2268*/
#ifdef SYSTEM_CND_ENABLE_SPI_DEBUGGING
                     /*~I:2269*/
                     if (CommunicationControl.bTestSPI == 1)
                     /*~-1*/
                     {
                        /*~I:2270*/
#ifdef SYSTEM_CND_ALL_SPI_COMMUNICATIONS
                        /*~T*/
                        // Nur zu Debugzwecken
                        sprintf(achString,"%s - S:%ld",szCommand,CommunicationControl.ulSPICounter);
                        Communication_SendString(COMMUNICATION_RS232,achString,0,1);
                        /*~O:I2270*/
                        /*~-1*/
#else
                        /*~I:2271*/
                        if (strlen(szCommand) != 4)
                        /*~-1*/
                        {
                           /*~T*/
                           // Nur zu Debugzwecken
                           sprintf(achString,"%s - S:%ld",szCommand,CommunicationControl.ulSPICounter);
                           Communication_SendString(COMMUNICATION_RS232,achString,0,1);
                        /*~-1*/
                        }
                        /*~E:I2271*/
                        /*~-1*/
#endif
                        /*~E:I2270*/
                     /*~-1*/
                     }
                     /*~E:I2269*/
                     /*~-1*/
#endif
                     /*~E:I2268*/
                     /*~-1*/
#endif
                     /*~E:I2267*/
                     /*~E:A2266*/
                     /*~-1*/
#endif
                     /*~E:I2164*/
                     /*~T*/
                     break;
                  /*~-1*/
                  }
                  /*~E:F2162*/
                  /*~E:A2161*/
               /*~-1*/
               }
               /*~E:C61*/
            /*~-1*/
            }
            /*~O:I60*/
            /*~-2*/
            else
            {
               /*~K*/
               /*~+:/~* Ge�ndert am 09.02.2022 *~/*/
               /*~T*/
               /* Else-Zweig von 'if ((Communication_IsCommunicationEnabled() != 0)||(strcmp(szCommand,"ENA") == 0)||(strcmp(szCommand,"CDL") == 0)||(CommunicationControl.chLine2Interprete != COMMUNICATION_RS232))' */

               byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
               /*~K*/
               /*~+:/~* Ende - Ge�ndert am 09.02.2022 *~/*/
            /*~-1*/
            }
            /*~E:I60*/
         /*~-1*/
         }
         /*~O:I59*/
         /*~-2*/
         else
         {
            /*~T*/
            /* Else-Zweig von 'if ((byChecksumError == FALSE)||(strcmp(szCommand,"CDL") == 0))' */
            byCommandStatus = INSTRUCTIONDECODER_SEND_NOTHING;
         /*~-1*/
         }
         /*~E:I59*/
         /*~I:2272*/
#ifdef OLD
         /*~A:2273*/
         /*~+:Eintrag in Diagnosespeicher vornehmen*/
         /*~I:2274*/
         if (ulDiagnosisEntry2Set)
         /*~-1*/
         {
            /*~T*/
            Diagnosis_WriteMessage2Flash(ulDiagnosisEntry2Set);
         /*~-1*/
         }
         /*~E:I2274*/
         /*~E:A2273*/
         /*~A:2275*/
         /*~+:Kommandostatus auswerten*/
         /*~C:2276*/
         switch (byCommandStatus)
         /*~-1*/
         {
            /*~F:2277*/
            case INSTRUCTIONDECODER_SEND_OK:	// Kommando wurde ordnungsgem�� interpretiert
            //case INSTRUCTIONDECODER_SEND_TEXT	// Beide Bedingungen identisch
            /*~-1*/
            {
               /*~A:2278*/
               /*~+:INSTRUCTIONDECODER_SEND_OK*/
               /*~I:2279*/
               if (CommunicationControl.chLine2Interprete == COMMUNICATION_RS232)
               /*~-1*/
               {
                  /*~I:2280*/
                  if (!SYSTEM_MRW_MANAGER)
                  /*~-1*/
                  {
                     /*~I:2281*/
#ifdef CHANNEL_0
                     /*~I:2282*/
                     if (lText2Send)
                     /*~-1*/
                     {
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                     /*~-1*/
                     }
                     /*~E:I2282*/
                     /*~-1*/
#endif
                     /*~E:I2281*/
                     /*~I:2283*/
#ifdef CHANNEL_1
                     /*~I:2284*/
                     if (bDoNotWriteResult2Buffer)
                     /*~-1*/
                     {
                        /*~I:2285*/
                        if (lText2Send)
                        /*~-1*/
                        {
                           /*~T*/
                           sprintf(szString2Send,"T%04ld",lText2Send);
                           /*~T*/
                           Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~-1*/
                        }
                        /*~O:I2285*/
                        /*~-2*/
                        else
                        {
                           /*~T*/
                           Communication_SendMessage(COMMUNICATION_RS232,COMMUNICATION_OK);
                        /*~-1*/
                        }
                        /*~E:I2285*/
                     /*~-1*/
                     }
                     /*~E:I2284*/
                     /*~-1*/
#endif
                     /*~E:I2283*/
                  /*~-1*/
                  }
                  /*~O:I2280*/
                  /*~-2*/
                  else
                  {
                     /*~I:2286*/
#ifdef CHANNEL_0
                     /*~T*/
                     Communication_SendMessage(COMMUNICATION_RS232,COMMUNICATION_OK);
                     /*~-1*/
#endif
                     /*~E:I2286*/
                     /*~I:2287*/
#ifdef CHANNEL_1
                     /*~I:2288*/
                     if (bDoNotWriteResult2Buffer)
                     /*~-1*/
                     {
                        /*~T*/
                        Communication_SendMessage(COMMUNICATION_RS232,COMMUNICATION_OK);
                     /*~-1*/
                     }
                     /*~E:I2288*/
                     /*~-1*/
#endif
                     /*~E:I2287*/
                  /*~-1*/
                  }
                  /*~E:I2280*/
               /*~-1*/
               }
               /*~O:I2279*/
               /*~-2*/
               else
               {
                  /*~I:2289*/
                  if (CommunicationControl.chLine2Interprete == COMMUNICATION_SPI)
                  /*~-1*/
                  {
                     /*~T*/
                     // Befehlsbest�tigung senden
                     Communication_SendSPICommand("OK");
                  /*~-1*/
                  }
                  /*~E:I2289*/
               /*~-1*/
               }
               /*~E:I2279*/
               /*~T*/
               break;
               /*~E:A2278*/
            /*~-1*/
            }
            /*~E:F2277*/
            /*~F:2290*/
            case INSTRUCTIONDECODER_SEND_E001:			// Kanal existiert nicht
            /*~-1*/
            {
               /*~A:2291*/
               /*~+:INSTRUCTIONDECODER_SEND_E001*/
               /*~I:2292*/
               if (CommunicationControl.chLine2Interprete == COMMUNICATION_RS232)
               /*~-1*/
               {
                  /*~I:2293*/
                  if (!SYSTEM_MRW_MANAGER)
                  /*~-1*/
                  {
                     /*~I:2294*/
                     if (lText2Send)
                     /*~-1*/
                     {
                        /*~I:2295*/
#ifdef CHANNEL_0
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~-1*/
#endif
                        /*~E:I2295*/
                        /*~I:2296*/
#ifdef CHANNEL_1
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~-1*/
#endif
                        /*~E:I2296*/
                        /*~T*/
                        break;
                     /*~-1*/
                     }
                     /*~E:I2294*/
                  /*~-1*/
                  }
                  /*~E:I2293*/
                  /*~I:2297*/
#ifdef CHANNEL_0
                  /*~T*/
                  Communication_SendString(COMMUNICATION_RS232,TEXT_E001,1,0);
                  /*~-1*/
#endif
                  /*~E:I2297*/
                  /*~I:2298*/
#ifdef CHANNEL_1
                  /*~I:2299*/
                  if (bDoNotWriteResult2Buffer)
                  /*~-1*/
                  {
                     /*~T*/
                     Communication_SendString(COMMUNICATION_RS232,TEXT_E001,1,0);
                  /*~-1*/
                  }
                  /*~E:I2299*/
                  /*~-1*/
#endif
                  /*~E:I2298*/
               /*~-1*/
               }
               /*~O:I2292*/
               /*~-2*/
               else
               {
                  /*~T*/
                  // NotAcknowledge senden
                  byRetVal = ADuC836_SPISendChar(NAK);
               /*~-1*/
               }
               /*~E:I2292*/
               /*~T*/
               break;
               /*~E:A2291*/
            /*~-1*/
            }
            /*~E:F2290*/
            /*~F:2300*/
            case INSTRUCTIONDECODER_SEND_E002:			// Fehler in Parameterlist
            /*~-1*/
            {
               /*~A:2301*/
               /*~+:INSTRUCTIONDECODER_SEND_E002*/
               /*~I:2302*/
               if (CommunicationControl.chLine2Interprete == COMMUNICATION_RS232)
               /*~-1*/
               {
                  /*~I:2303*/
                  if (!SYSTEM_MRW_MANAGER)
                  /*~-1*/
                  {
                     /*~I:2304*/
                     if (lText2Send)
                     /*~-1*/
                     {
                        /*~I:2305*/
#ifdef CHANNEL_0
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~-1*/
#endif
                        /*~E:I2305*/
                        /*~I:2306*/
#ifdef CHANNEL_1
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~-1*/
#endif
                        /*~E:I2306*/
                        /*~T*/
                        break;
                     /*~-1*/
                     }
                     /*~E:I2304*/
                  /*~-1*/
                  }
                  /*~E:I2303*/
                  /*~I:2307*/
#ifdef CHANNEL_0
                  /*~T*/
                  Communication_SendString(COMMUNICATION_RS232,TEXT_E002,1,0);
                  /*~-1*/
#endif
                  /*~E:I2307*/
                  /*~I:2308*/
#ifdef CHANNEL_1
                  /*~I:2309*/
                  if (bDoNotWriteResult2Buffer)
                  /*~-1*/
                  {
                     /*~T*/
                     Communication_SendString(COMMUNICATION_RS232,TEXT_E002,1,0);
                  /*~-1*/
                  }
                  /*~E:I2309*/
                  /*~-1*/
#endif
                  /*~E:I2308*/
               /*~-1*/
               }
               /*~O:I2302*/
               /*~-2*/
               else
               {
                  /*~T*/
                  // NotAcknowledge senden
                  byRetVal = ADuC836_SPISendChar(NAK);
               /*~-1*/
               }
               /*~E:I2302*/
               /*~T*/
               break;
               /*~E:A2301*/
            /*~-1*/
            }
            /*~E:F2300*/
            /*~F:2310*/
            case INSTRUCTIONDECODER_SEND_E003:			// ReadOnly-Fehler
            /*~-1*/
            {
               /*~A:2311*/
               /*~+:INSTRUCTIONDECODER_SEND_E003*/
               /*~I:2312*/
               if (CommunicationControl.chLine2Interprete == COMMUNICATION_RS232)
               /*~-1*/
               {
                  /*~I:2313*/
                  if (!SYSTEM_MRW_MANAGER)
                  /*~-1*/
                  {
                     /*~I:2314*/
                     if (lText2Send)
                     /*~-1*/
                     {
                        /*~I:2315*/
#ifdef CHANNEL_0
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~-1*/
#endif
                        /*~E:I2315*/
                        /*~I:2316*/
#ifdef CHANNEL_1
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~-1*/
#endif
                        /*~E:I2316*/
                        /*~T*/
                        break;
                     /*~-1*/
                     }
                     /*~E:I2314*/
                  /*~-1*/
                  }
                  /*~E:I2313*/
                  /*~I:2317*/
#ifdef CHANNEL_0
                  /*~T*/
                  Communication_SendString(COMMUNICATION_RS232,TEXT_E003,1,0);
                  /*~-1*/
#endif
                  /*~E:I2317*/
                  /*~I:2318*/
#ifdef CHANNEL_1
                  /*~I:2319*/
                  if (bDoNotWriteResult2Buffer)
                  /*~-1*/
                  {
                     /*~T*/
                     Communication_SendString(COMMUNICATION_RS232,TEXT_E003,1,0);
                  /*~-1*/
                  }
                  /*~E:I2319*/
                  /*~-1*/
#endif
                  /*~E:I2318*/
               /*~-1*/
               }
               /*~O:I2312*/
               /*~-2*/
               else
               {
                  /*~T*/
                  // NotAcknowledge senden
                  byRetVal = ADuC836_SPISendChar(NAK);
               /*~-1*/
               }
               /*~E:I2312*/
               /*~T*/
               break;
               /*~E:A2311*/
            /*~-1*/
            }
            /*~E:F2310*/
            /*~F:2320*/
            case INSTRUCTIONDECODER_SEND_E004:			// Kommando konnte nicht interpretiert werden
            /*~-1*/
            {
               /*~A:2321*/
               /*~+:INSTRUCTIONDECODER_SEND_E004*/
               /*~I:2322*/
               if (CommunicationControl.chLine2Interprete == COMMUNICATION_RS232)
               /*~-1*/
               {
                  /*~I:2323*/
                  if (!SYSTEM_MRW_MANAGER)
                  /*~-1*/
                  {
                     /*~I:2324*/
                     if (lText2Send)
                     /*~-1*/
                     {
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~T*/
                        break;
                     /*~-1*/
                     }
                     /*~E:I2324*/
                  /*~-1*/
                  }
                  /*~E:I2323*/
                  /*~I:2325*/
#ifdef CHANNEL_0
                  /*~T*/
                  Communication_SendString(COMMUNICATION_RS232,TEXT_E004,1,0);
                  /*~-1*/
#endif
                  /*~E:I2325*/
               /*~-1*/
               }
               /*~O:I2322*/
               /*~-2*/
               else
               {
                  /*~T*/
                  // NotAcknowledge senden
                  byRetVal = ADuC836_SPISendChar(NAK);
               /*~-1*/
               }
               /*~E:I2322*/
               /*~T*/
               break;
               /*~E:A2321*/
            /*~-1*/
            }
            /*~E:F2320*/
            /*~F:2326*/
            case INSTRUCTIONDECODER_SEND_E005:			// Kommunikationsfehler mit dem Partner
            /*~-1*/
            {
               /*~A:2327*/
               /*~+:INSTRUCTIONDECODER_SEND_E005*/
               /*~I:2328*/
               if (CommunicationControl.chLine2Interprete == COMMUNICATION_RS232)
               /*~-1*/
               {
                  /*~I:2329*/
                  if (!SYSTEM_MRW_MANAGER)
                  /*~-1*/
                  {
                     /*~I:2330*/
                     if (lText2Send)
                     /*~-1*/
                     {
                        /*~I:2331*/
#ifdef CHANNEL_0
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~-1*/
#endif
                        /*~E:I2331*/
                        /*~I:2332*/
#ifdef CHANNEL_1
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~-1*/
#endif
                        /*~E:I2332*/
                        /*~T*/
                        break;
                     /*~-1*/
                     }
                     /*~E:I2330*/
                  /*~-1*/
                  }
                  /*~E:I2329*/
                  /*~I:2333*/
#ifdef CHANNEL_0
                  /*~T*/
                  Communication_SendString(COMMUNICATION_RS232,TEXT_E005,1,0);
                  /*~-1*/
#endif
                  /*~E:I2333*/
                  /*~I:2334*/
#ifdef CHANNEL_1
                  /*~I:2335*/
                  if (bDoNotWriteResult2Buffer)
                  /*~-1*/
                  {
                     /*~T*/
                     Communication_SendString(COMMUNICATION_RS232,TEXT_E005,1,0);
                  /*~-1*/
                  }
                  /*~E:I2335*/
                  /*~-1*/
#endif
                  /*~E:I2334*/
               /*~-1*/
               }
               /*~O:I2328*/
               /*~-2*/
               else
               {
                  /*~T*/
                  // NotAcknowledge senden
                  byRetVal = ADuC836_SPISendChar(NAK);
               /*~-1*/
               }
               /*~E:I2328*/
               /*~T*/
               break;
               /*~E:A2327*/
            /*~-1*/
            }
            /*~E:F2326*/
            /*~F:2336*/
            case INSTRUCTIONDECODER_SEND_E006:			// Kommando noch nicht implementiert
            /*~-1*/
            {
               /*~A:2337*/
               /*~+:INSTRUCTIONDECODER_SEND_E006*/
               /*~I:2338*/
               if (CommunicationControl.chLine2Interprete == COMMUNICATION_RS232)
               /*~-1*/
               {
                  /*~I:2339*/
                  if (!SYSTEM_MRW_MANAGER)
                  /*~-1*/
                  {
                     /*~I:2340*/
                     if (lText2Send)
                     /*~-1*/
                     {
                        /*~I:2341*/
#ifdef CHANNEL_0
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~-1*/
#endif
                        /*~E:I2341*/
                        /*~I:2342*/
#ifdef CHANNEL_1
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~-1*/
#endif
                        /*~E:I2342*/
                        /*~T*/
                        break;
                     /*~-1*/
                     }
                     /*~E:I2340*/
                  /*~-1*/
                  }
                  /*~E:I2339*/
                  /*~I:2343*/
#ifdef CHANNEL_0
                  /*~T*/
                  Communication_SendString(COMMUNICATION_RS232,TEXT_E006,1,0);
                  /*~-1*/
#endif
                  /*~E:I2343*/
                  /*~I:2344*/
#ifdef CHANNEL_1
                  /*~I:2345*/
                  if (bDoNotWriteResult2Buffer)
                  /*~-1*/
                  {
                     /*~T*/
                     Communication_SendString(COMMUNICATION_RS232,TEXT_E006,1,0);
                  /*~-1*/
                  }
                  /*~E:I2345*/
                  /*~-1*/
#endif
                  /*~E:I2344*/
               /*~-1*/
               }
               /*~O:I2338*/
               /*~-2*/
               else
               {
                  /*~T*/
                  // NotAcknowledge senden
                  byRetVal = ADuC836_SPISendChar(NAK);
               /*~-1*/
               }
               /*~E:I2338*/
               /*~T*/
               break;
               /*~E:A2337*/
            /*~-1*/
            }
            /*~E:F2336*/
            /*~F:2346*/
            case INSTRUCTIONDECODER_SEND_E007:			// Parameter fehlt 
            /*~-1*/
            {
               /*~A:2347*/
               /*~+:INSTRUCTIONDECODER_SEND_E007*/
               /*~I:2348*/
               if (CommunicationControl.chLine2Interprete == COMMUNICATION_RS232)
               /*~-1*/
               {
                  /*~I:2349*/
                  if (!SYSTEM_MRW_MANAGER)
                  /*~-1*/
                  {
                     /*~I:2350*/
                     if (lText2Send)
                     /*~-1*/
                     {
                        /*~I:2351*/
#ifdef CHANNEL_0
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~-1*/
#endif
                        /*~E:I2351*/
                        /*~I:2352*/
#ifdef CHANNEL_1
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~-1*/
#endif
                        /*~E:I2352*/
                        /*~T*/
                        break;
                     /*~-1*/
                     }
                     /*~E:I2350*/
                  /*~-1*/
                  }
                  /*~E:I2349*/
                  /*~I:2353*/
#ifdef CHANNEL_0
                  /*~T*/
                  Communication_SendString(COMMUNICATION_RS232,TEXT_E007,1,0);
                  /*~-1*/
#endif
                  /*~E:I2353*/
                  /*~I:2354*/
#ifdef CHANNEL_1
                  /*~I:2355*/
                  if (bDoNotWriteResult2Buffer)
                  /*~-1*/
                  {
                     /*~T*/
                     Communication_SendString(COMMUNICATION_RS232,TEXT_E007,1,0);
                  /*~-1*/
                  }
                  /*~E:I2355*/
                  /*~-1*/
#endif
                  /*~E:I2354*/
               /*~-1*/
               }
               /*~O:I2348*/
               /*~-2*/
               else
               {
                  /*~T*/
                  // NotAcknowledge senden
                  byRetVal = ADuC836_SPISendChar(NAK);
               /*~-1*/
               }
               /*~E:I2348*/
               /*~T*/
               break;
               /*~E:A2347*/
            /*~-1*/
            }
            /*~E:F2346*/
            /*~F:2356*/
            case INSTRUCTIONDECODER_SEND_E008:			// Unerwartetes Zeichen im Kommandostring 
            /*~-1*/
            {
               /*~A:2357*/
               /*~+:INSTRUCTIONDECODER_SEND_E008*/
               /*~I:2358*/
               if (CommunicationControl.chLine2Interprete == COMMUNICATION_RS232)
               /*~-1*/
               {
                  /*~I:2359*/
                  if (!SYSTEM_MRW_MANAGER)
                  /*~-1*/
                  {
                     /*~I:2360*/
                     if (lText2Send)
                     /*~-1*/
                     {
                        /*~I:2361*/
#ifdef CHANNEL_0
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~-1*/
#endif
                        /*~E:I2361*/
                        /*~I:2362*/
#ifdef CHANNEL_1
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~-1*/
#endif
                        /*~E:I2362*/
                        /*~T*/
                        break;
                     /*~-1*/
                     }
                     /*~E:I2360*/
                  /*~-1*/
                  }
                  /*~E:I2359*/
                  /*~I:2363*/
#ifdef CHANNEL_0
                  /*~T*/
                  Communication_SendString(COMMUNICATION_RS232,TEXT_E008,1,0);
                  /*~-1*/
#endif
                  /*~E:I2363*/
                  /*~I:2364*/
#ifdef CHANNEL_1
                  /*~I:2365*/
                  if (bDoNotWriteResult2Buffer)
                  /*~-1*/
                  {
                     /*~T*/
                     Communication_SendString(COMMUNICATION_RS232,TEXT_E008,1,0);
                  /*~-1*/
                  }
                  /*~E:I2365*/
                  /*~-1*/
#endif
                  /*~E:I2364*/
               /*~-1*/
               }
               /*~O:I2358*/
               /*~-2*/
               else
               {
                  /*~T*/
                  // NotAcknowledge senden
                  byRetVal = ADuC836_SPISendChar(NAK);
               /*~-1*/
               }
               /*~E:I2358*/
               /*~T*/
               break;
               /*~E:A2357*/
            /*~-1*/
            }
            /*~E:F2356*/
            /*~F:2366*/
            case INSTRUCTIONDECODER_SEND_E009:			// Wert au�erhalb des Grenzwertes

            /*~-1*/
            {
               /*~A:2367*/
               /*~+:INSTRUCTIONDECODER_SEND_E009*/
               /*~I:2368*/
               if (CommunicationControl.chLine2Interprete == COMMUNICATION_RS232)
               /*~-1*/
               {
                  /*~I:2369*/
                  if (!SYSTEM_MRW_MANAGER)
                  /*~-1*/
                  {
                     /*~I:2370*/
                     if (lText2Send)
                     /*~-1*/
                     {
                        /*~I:2371*/
#ifdef CHANNEL_0
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~-1*/
#endif
                        /*~E:I2371*/
                        /*~I:2372*/
#ifdef CHANNEL_1
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~-1*/
#endif
                        /*~E:I2372*/
                        /*~T*/
                        break;
                     /*~-1*/
                     }
                     /*~E:I2370*/
                  /*~-1*/
                  }
                  /*~E:I2369*/
                  /*~I:2373*/
#ifdef CHANNEL_0
                  /*~T*/
                  Communication_SendString(COMMUNICATION_RS232,TEXT_E009,1,0);
                  /*~-1*/
#endif
                  /*~E:I2373*/
                  /*~I:2374*/
#ifdef CHANNEL_1
                  /*~I:2375*/
                  if (bDoNotWriteResult2Buffer)
                  /*~-1*/
                  {
                     /*~T*/
                     Communication_SendString(COMMUNICATION_RS232,TEXT_E009,1,0);
                  /*~-1*/
                  }
                  /*~E:I2375*/
                  /*~-1*/
#endif
                  /*~E:I2374*/
               /*~-1*/
               }
               /*~O:I2368*/
               /*~-2*/
               else
               {
                  /*~T*/
                  // NotAcknowledge senden
                  byRetVal = ADuC836_SPISendChar(NAK);
               /*~-1*/
               }
               /*~E:I2368*/
               /*~T*/
               break;
               /*~E:A2367*/
            /*~-1*/
            }
            /*~E:F2366*/
            /*~F:2376*/
            case INSTRUCTIONDECODER_SEND_E010:			// Drifterkennung l�uft (nur SLC)

            /*~-1*/
            {
               /*~A:2377*/
               /*~+:INSTRUCTIONDECODER_SEND_E010*/
               /*~I:2378*/
               if (CommunicationControl.chLine2Interprete == COMMUNICATION_RS232)
               /*~-1*/
               {
                  /*~I:2379*/
                  if (!SYSTEM_MRW_MANAGER)
                  /*~-1*/
                  {
                     /*~I:2380*/
                     if (lText2Send)
                     /*~-1*/
                     {
                        /*~I:2381*/
#ifdef CHANNEL_0
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~-1*/
#endif
                        /*~E:I2381*/
                        /*~I:2382*/
#ifdef CHANNEL_1
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~-1*/
#endif
                        /*~E:I2382*/
                        /*~T*/
                        break;
                     /*~-1*/
                     }
                     /*~E:I2380*/
                     /*~I:2383*/
#ifdef CHANNEL_0
                     /*~T*/
                     Communication_SendString(COMMUNICATION_RS232,TEXT_E010,1,0);
                     /*~-1*/
#endif
                     /*~E:I2383*/
                     /*~I:2384*/
#ifdef CHANNEL_1 
                     /*~I:2385*/
                     if (bDoNotWriteResult2Buffer)
                     /*~-1*/
                     {
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,TEXT_E010,1,0);
                     /*~-1*/
                     }
                     /*~E:I2385*/
                     /*~-1*/
#endif
                     /*~E:I2384*/
                  /*~-1*/
                  }
                  /*~E:I2379*/
               /*~-1*/
               }
               /*~O:I2378*/
               /*~-2*/
               else
               {
                  /*~T*/
                  // NotAcknowledge senden
                  byRetVal = ADuC836_SPISendChar(NAK);
               /*~-1*/
               }
               /*~E:I2378*/
               /*~T*/
               break;
               /*~E:A2377*/
            /*~-1*/
            }
            /*~E:F2376*/
            /*~F:2386*/
            case INSTRUCTIONDECODER_SEND_E011:			// Parameter der Partner sind unterschiedlich 
            /*~-1*/
            {
               /*~A:2387*/
               /*~+:INSTRUCTIONDECODER_SEND_E011*/
               /*~I:2388*/
               if (CommunicationControl.chLine2Interprete == COMMUNICATION_RS232)
               /*~-1*/
               {
                  /*~I:2389*/
                  if (!SYSTEM_MRW_MANAGER)
                  /*~-1*/
                  {
                     /*~I:2390*/
                     if (lText2Send)
                     /*~-1*/
                     {
                        /*~I:2391*/
#ifdef CHANNEL_0
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~-1*/
#endif
                        /*~E:I2391*/
                        /*~I:2392*/
#ifdef CHANNEL_1
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~-1*/
#endif
                        /*~E:I2392*/
                        /*~T*/
                        break;
                     /*~-1*/
                     }
                     /*~E:I2390*/
                  /*~-1*/
                  }
                  /*~E:I2389*/
                  /*~I:2393*/
#ifdef CHANNEL_0
                  /*~T*/
                  Communication_SendString(COMMUNICATION_RS232,TEXT_E011,1,0);
                  /*~-1*/
#endif
                  /*~E:I2393*/
                  /*~I:2394*/
#ifdef CHANNEL_1 
                  /*~I:2395*/
                  if (bDoNotWriteResult2Buffer)
                  /*~-1*/
                  {
                     /*~T*/
                     Communication_SendString(COMMUNICATION_RS232,TEXT_E011,1,0);
                  /*~-1*/
                  }
                  /*~E:I2395*/
                  /*~-1*/
#endif
                  /*~E:I2394*/
               /*~-1*/
               }
               /*~O:I2388*/
               /*~-2*/
               else
               {
                  /*~T*/
                  // NotAcknowledge senden
                  byRetVal = ADuC836_SPISendChar(NAK);
               /*~-1*/
               }
               /*~E:I2388*/
               /*~T*/
               break;
               /*~E:A2387*/
            /*~-1*/
            }
            /*~E:F2386*/
            /*~F:2396*/
            case INSTRUCTIONDECODER_SEND_E012:			// Checksummenfehler
            /*~-1*/
            {
               /*~A:2397*/
               /*~+:INSTRUCTIONDECODER_SEND_E012*/
               /*~I:2398*/
               if (CommunicationControl.chLine2Interprete == COMMUNICATION_RS232)
               /*~-1*/
               {
                  /*~I:2399*/
                  if (!SYSTEM_MRW_MANAGER)
                  /*~-1*/
                  {
                     /*~I:2400*/
                     if (lText2Send)
                     /*~-1*/
                     {
                        /*~I:2401*/
#ifdef CHANNEL_0
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~-1*/
#endif
                        /*~E:I2401*/
                        /*~I:2402*/
#ifdef CHANNEL_1
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~-1*/
#endif
                        /*~E:I2402*/
                        /*~T*/
                        break;
                     /*~-1*/
                     }
                     /*~E:I2400*/
                  /*~-1*/
                  }
                  /*~E:I2399*/
                  /*~T*/
                  Communication_SendString(COMMUNICATION_RS232,TEXT_E012,1,0);
               /*~-1*/
               }
               /*~O:I2398*/
               /*~-2*/
               else
               {
                  /*~T*/
                  // NotAcknowledge senden
                  byRetVal = ADuC836_SPISendChar(NAK);
               /*~-1*/
               }
               /*~E:I2398*/
               /*~T*/
               break;
               /*~E:A2397*/
            /*~-1*/
            }
            /*~E:F2396*/
            /*~F:2403*/
            case INSTRUCTIONDECODER_SEND_NOK:			// NOK senden
            /*~-1*/
            {
               /*~A:2404*/
               /*~+:INSTRUCTIONDECODER_SEND_NOK*/
               /*~I:2405*/
               if (CommunicationControl.chLine2Interprete == COMMUNICATION_RS232)
               /*~-1*/
               {
                  /*~I:2406*/
                  if (!SYSTEM_MRW_MANAGER)
                  /*~-1*/
                  {
                     /*~I:2407*/
                     if (lText2Send)
                     /*~-1*/
                     {
                        /*~A:2408*/
                        /*~+:RS232-Ausgabe*/
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~E:A2408*/
                        /*~T*/
                        break;
                     /*~-1*/
                     }
                     /*~E:I2407*/
                  /*~-1*/
                  }
                  /*~E:I2406*/
                  /*~A:2409*/
                  /*~+:RS232-Ausgabe*/
                  /*~T*/
                  Communication_SendMessage(COMMUNICATION_RS232,COMMUNICATION_NOK);
                  /*~E:A2409*/
               /*~-1*/
               }
               /*~E:I2405*/
               /*~T*/
               break;
               /*~E:A2404*/
            /*~-1*/
            }
            /*~E:F2403*/
            /*~F:2410*/
            case INSTRUCTIONDECODER_SEND_NOTHING:
            /*~-1*/
            {
               /*~T*/
               break;
            /*~-1*/
            }
            /*~E:F2410*/
         /*~-1*/
         }
         /*~E:C2276*/
         /*~I:2411*/
#ifdef CHANNEL_1
         /*~I:2412*/
         if (!bDoNotWriteResult2Buffer)
         /*~-1*/
         {
            /*~T*/
            bDoNotWriteResult2Buffer = 1;

            g_byLastCommandExecutionResult = byCommandStatus;
         /*~-1*/
         }
         /*~E:I2412*/
         /*~-1*/
#endif
         /*~E:I2411*/
         /*~E:A2275*/
         /*~-1*/
#endif
         /*~E:I2272*/
         /*~A:2413*/
         /*~+:Eintrag in Diagnosespeicher vornehmen*/
         /*~I:2414*/
#ifdef CHANNEL_0
         /*~A:2415*/
         /*~+:Kanal 0*/
         /*~I:2416*/
         if (ulDiagnosisEntry2Set)
         /*~-1*/
         {
            /*~T*/
            Diagnosis_WriteMessage2Flash(ulDiagnosisEntry2Set);
         /*~-1*/
         }
         /*~E:I2416*/
         /*~E:A2415*/
         /*~-1*/
#endif
         /*~E:I2414*/
         /*~I:2417*/
#ifdef CHANNEL_1
         /*~A:2418*/
         /*~+:Kanal 1*/
         /*~I:2419*/
         if (ulDiagnosisEntry2Set)
         /*~-1*/
         {
            /*~I:2420*/
            if (bDoNotWriteResult2Buffer)
            /*~-1*/
            {
               /*~T*/
               Diagnosis_WriteMessage2Flash(ulDiagnosisEntry2Set);
            /*~-1*/
            }
            /*~O:I2420*/
            /*~-2*/
            else
            {
               /*~T*/
               ulDiagnosisEntry2SetAtiGRS = ulDiagnosisEntry2Set;
            /*~-1*/
            }
            /*~E:I2420*/
         /*~-1*/
         }
         /*~E:I2419*/
         /*~E:A2418*/
         /*~-1*/
#endif
         /*~E:I2417*/
         /*~E:A2413*/
         /*~A:2421*/
         /*~+:Kommandostatus auswerten*/
         /*~C:2422*/
         switch (byCommandStatus)
         /*~-1*/
         {
            /*~F:2423*/
            case INSTRUCTIONDECODER_SEND_OK:	// Kommando wurde ordnungsgem�� interpretiert
            //case INSTRUCTIONDECODER_SEND_TEXT	// Beide Bedingungen identisch
            /*~-1*/
            {
               /*~A:2424*/
               /*~+:INSTRUCTIONDECODER_SEND_OK*/
               /*~I:2425*/
               if (CommunicationControl.chLine2Interprete == COMMUNICATION_RS232)
               /*~-1*/
               {
                  /*~I:2426*/
                  if (!SYSTEM_MRW_MANAGER)
                  /*~-1*/
                  {
                     /*~I:2427*/
#ifdef CHANNEL_0
                     /*~I:2428*/
                     if (lText2Send)
                     /*~-1*/
                     {
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                     /*~-1*/
                     }
                     /*~E:I2428*/
                     /*~-1*/
#endif
                     /*~E:I2427*/
                     /*~I:2429*/
#ifdef CHANNEL_1
                     /*~I:2430*/
                     if (bDoNotWriteResult2Buffer)
                     /*~-1*/
                     {
                        /*~I:2431*/
                        if (lText2Send)
                        /*~-1*/
                        {
                           /*~T*/
                           sprintf(szString2Send,"T%04ld",lText2Send);
                           /*~T*/
                           Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~-1*/
                        }
                        /*~O:I2431*/
                        /*~-2*/
                        else
                        {
                           /*~T*/
                           Communication_SendMessage(COMMUNICATION_RS232,COMMUNICATION_OK);
                        /*~-1*/
                        }
                        /*~E:I2431*/
                     /*~-1*/
                     }
                     /*~E:I2430*/
                     /*~-1*/
#endif
                     /*~E:I2429*/
                  /*~-1*/
                  }
                  /*~O:I2426*/
                  /*~-2*/
                  else
                  {
                     /*~I:2432*/
#ifdef CHANNEL_0
                     /*~T*/
                     Communication_SendMessage(COMMUNICATION_RS232,COMMUNICATION_OK);
                     /*~-1*/
#endif
                     /*~E:I2432*/
                     /*~I:2433*/
#ifdef CHANNEL_1
                     /*~I:2434*/
                     if (bDoNotWriteResult2Buffer)
                     /*~-1*/
                     {
                        /*~T*/
                        Communication_SendMessage(COMMUNICATION_RS232,COMMUNICATION_OK);
                     /*~-1*/
                     }
                     /*~E:I2434*/
                     /*~-1*/
#endif
                     /*~E:I2433*/
                  /*~-1*/
                  }
                  /*~E:I2426*/
                  /*~K*/
                  /*~+:/~* Hinzugef�gt am 09.02.2022 *~/*/
                  /*~I:2435*/
#ifdef CHANNEL_0 
                  /*~I:2436*/
                  if (lText2Send == TEXT_RETAIN_VARIABLES_REORGANIZED)
                  /*~-1*/
                  {
                     /*~T*/
                     // Reset nach der Reorganisation der Retain-Variablen ausf�hren
                     /*~I:2437*/
#ifndef DEVELOPMENT_SW	/* Nur definiert in der Debug-Version */ 
                     /*~T*/
                     System_Reset();
                     /*~-1*/
#endif
                     /*~E:I2437*/
                  /*~-1*/
                  }
                  /*~E:I2436*/
                  /*~-1*/
#endif
                  /*~E:I2435*/
                  /*~K*/
                  /*~+:/~* Ende - Hinzugef�gt am 09.02.2022 *~/*/
               /*~-1*/
               }
               /*~O:I2425*/
               /*~-2*/
               else
               {
                  /*~I:2438*/
                  if (CommunicationControl.chLine2Interprete == COMMUNICATION_SPI)
                  /*~-1*/
                  {
                     /*~T*/
                     // Befehlsbest�tigung senden
                     Communication_SendSPICommand("OK");
                  /*~-1*/
                  }
                  /*~E:I2438*/
               /*~-1*/
               }
               /*~E:I2425*/
               /*~T*/
               break;
               /*~E:A2424*/
            /*~-1*/
            }
            /*~E:F2423*/
            /*~F:2439*/
            case INSTRUCTIONDECODER_SEND_E001:			// Kanal existiert nicht
            /*~-1*/
            {
               /*~A:2440*/
               /*~+:INSTRUCTIONDECODER_SEND_E001*/
               /*~I:2441*/
               if (CommunicationControl.chLine2Interprete == COMMUNICATION_RS232)
               /*~-1*/
               {
                  /*~I:2442*/
                  if (!SYSTEM_MRW_MANAGER)
                  /*~-1*/
                  {
                     /*~I:2443*/
                     if (lText2Send)
                     /*~-1*/
                     {
                        /*~I:2444*/
#ifdef CHANNEL_0
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~-1*/
#endif
                        /*~E:I2444*/
                        /*~I:2445*/
#ifdef CHANNEL_1
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~-1*/
#endif
                        /*~E:I2445*/
                        /*~T*/
                        break;
                     /*~-1*/
                     }
                     /*~E:I2443*/
                  /*~-1*/
                  }
                  /*~E:I2442*/
                  /*~I:2446*/
#ifdef CHANNEL_0
                  /*~T*/
                  Communication_SendString(COMMUNICATION_RS232,TEXT_E001,1,0);
                  /*~-1*/
#endif
                  /*~E:I2446*/
                  /*~I:2447*/
#ifdef CHANNEL_1
                  /*~I:2448*/
                  if (bDoNotWriteResult2Buffer)
                  /*~-1*/
                  {
                     /*~T*/
                     Communication_SendString(COMMUNICATION_RS232,TEXT_E001,1,0);
                  /*~-1*/
                  }
                  /*~E:I2448*/
                  /*~-1*/
#endif
                  /*~E:I2447*/
               /*~-1*/
               }
               /*~O:I2441*/
               /*~-2*/
               else
               {
                  /*~T*/
                  // NotAcknowledge senden
                  byRetVal = ADuC836_SPISendChar(NAK);
               /*~-1*/
               }
               /*~E:I2441*/
               /*~T*/
               break;
               /*~E:A2440*/
            /*~-1*/
            }
            /*~E:F2439*/
            /*~F:2449*/
            case INSTRUCTIONDECODER_SEND_E002:			// Fehler in Parameterlist
            /*~-1*/
            {
               /*~A:2450*/
               /*~+:INSTRUCTIONDECODER_SEND_E002*/
               /*~I:2451*/
               if (CommunicationControl.chLine2Interprete == COMMUNICATION_RS232)
               /*~-1*/
               {
                  /*~I:2452*/
                  if (!SYSTEM_MRW_MANAGER)
                  /*~-1*/
                  {
                     /*~I:2453*/
                     if (lText2Send)
                     /*~-1*/
                     {
                        /*~I:2454*/
#ifdef CHANNEL_0
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~-1*/
#endif
                        /*~E:I2454*/
                        /*~I:2455*/
#ifdef CHANNEL_1
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~-1*/
#endif
                        /*~E:I2455*/
                        /*~T*/
                        break;
                     /*~-1*/
                     }
                     /*~E:I2453*/
                  /*~-1*/
                  }
                  /*~E:I2452*/
                  /*~I:2456*/
#ifdef CHANNEL_0
                  /*~T*/
                  Communication_SendString(COMMUNICATION_RS232,TEXT_E002,1,0);
                  /*~-1*/
#endif
                  /*~E:I2456*/
                  /*~I:2457*/
#ifdef CHANNEL_1
                  /*~I:2458*/
                  if (bDoNotWriteResult2Buffer)
                  /*~-1*/
                  {
                     /*~T*/
                     Communication_SendString(COMMUNICATION_RS232,TEXT_E002,1,0);
                  /*~-1*/
                  }
                  /*~E:I2458*/
                  /*~-1*/
#endif
                  /*~E:I2457*/
               /*~-1*/
               }
               /*~O:I2451*/
               /*~-2*/
               else
               {
                  /*~T*/
                  // NotAcknowledge senden
                  byRetVal = ADuC836_SPISendChar(NAK);
               /*~-1*/
               }
               /*~E:I2451*/
               /*~T*/
               break;
               /*~E:A2450*/
            /*~-1*/
            }
            /*~E:F2449*/
            /*~F:2459*/
            case INSTRUCTIONDECODER_SEND_E003:			// ReadOnly-Fehler
            /*~-1*/
            {
               /*~A:2460*/
               /*~+:INSTRUCTIONDECODER_SEND_E003*/
               /*~I:2461*/
               if (CommunicationControl.chLine2Interprete == COMMUNICATION_RS232)
               /*~-1*/
               {
                  /*~I:2462*/
                  if (!SYSTEM_MRW_MANAGER)
                  /*~-1*/
                  {
                     /*~I:2463*/
                     if (lText2Send)
                     /*~-1*/
                     {
                        /*~I:2464*/
#ifdef CHANNEL_0
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~-1*/
#endif
                        /*~E:I2464*/
                        /*~I:2465*/
#ifdef CHANNEL_1
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~-1*/
#endif
                        /*~E:I2465*/
                        /*~T*/
                        break;
                     /*~-1*/
                     }
                     /*~E:I2463*/
                  /*~-1*/
                  }
                  /*~E:I2462*/
                  /*~I:2466*/
#ifdef CHANNEL_0
                  /*~T*/
                  Communication_SendString(COMMUNICATION_RS232,TEXT_E003,1,0);
                  /*~-1*/
#endif
                  /*~E:I2466*/
                  /*~I:2467*/
#ifdef CHANNEL_1
                  /*~I:2468*/
                  if (bDoNotWriteResult2Buffer)
                  /*~-1*/
                  {
                     /*~T*/
                     Communication_SendString(COMMUNICATION_RS232,TEXT_E003,1,0);
                  /*~-1*/
                  }
                  /*~E:I2468*/
                  /*~-1*/
#endif
                  /*~E:I2467*/
               /*~-1*/
               }
               /*~O:I2461*/
               /*~-2*/
               else
               {
                  /*~T*/
                  // NotAcknowledge senden
                  byRetVal = ADuC836_SPISendChar(NAK);
               /*~-1*/
               }
               /*~E:I2461*/
               /*~T*/
               break;
               /*~E:A2460*/
            /*~-1*/
            }
            /*~E:F2459*/
            /*~F:2469*/
            case INSTRUCTIONDECODER_SEND_E004:			// Kommando konnte nicht interpretiert werden
            /*~-1*/
            {
               /*~A:2470*/
               /*~+:INSTRUCTIONDECODER_SEND_E004*/
               /*~I:2471*/
               if (CommunicationControl.chLine2Interprete == COMMUNICATION_RS232)
               /*~-1*/
               {
                  /*~I:2472*/
                  if (!SYSTEM_MRW_MANAGER)
                  /*~-1*/
                  {
                     /*~I:2473*/
                     if (lText2Send)
                     /*~-1*/
                     {
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~T*/
                        break;
                     /*~-1*/
                     }
                     /*~E:I2473*/
                  /*~-1*/
                  }
                  /*~E:I2472*/
                  /*~I:2474*/
#ifdef CHANNEL_0
                  /*~T*/
                  Communication_SendString(COMMUNICATION_RS232,TEXT_E004,1,0);
                  /*~-1*/
#endif
                  /*~E:I2474*/
               /*~-1*/
               }
               /*~O:I2471*/
               /*~-2*/
               else
               {
                  /*~T*/
                  // NotAcknowledge senden
                  byRetVal = ADuC836_SPISendChar(NAK);
               /*~-1*/
               }
               /*~E:I2471*/
               /*~T*/
               break;
               /*~E:A2470*/
            /*~-1*/
            }
            /*~E:F2469*/
            /*~F:2475*/
            case INSTRUCTIONDECODER_SEND_E005:			// Kommunikationsfehler mit dem Partner
            /*~-1*/
            {
               /*~A:2476*/
               /*~+:INSTRUCTIONDECODER_SEND_E005*/
               /*~I:2477*/
               if (CommunicationControl.chLine2Interprete == COMMUNICATION_RS232)
               /*~-1*/
               {
                  /*~I:2478*/
                  if (!SYSTEM_MRW_MANAGER)
                  /*~-1*/
                  {
                     /*~I:2479*/
                     if (lText2Send)
                     /*~-1*/
                     {
                        /*~I:2480*/
#ifdef CHANNEL_0
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~-1*/
#endif
                        /*~E:I2480*/
                        /*~I:2481*/
#ifdef CHANNEL_1
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~-1*/
#endif
                        /*~E:I2481*/
                        /*~T*/
                        break;
                     /*~-1*/
                     }
                     /*~E:I2479*/
                  /*~-1*/
                  }
                  /*~E:I2478*/
                  /*~I:2482*/
#ifdef CHANNEL_0
                  /*~T*/
                  Communication_SendString(COMMUNICATION_RS232,TEXT_E005,1,0);
                  /*~-1*/
#endif
                  /*~E:I2482*/
                  /*~I:2483*/
#ifdef CHANNEL_1
                  /*~I:2484*/
                  if (bDoNotWriteResult2Buffer)
                  /*~-1*/
                  {
                     /*~T*/
                     Communication_SendString(COMMUNICATION_RS232,TEXT_E005,1,0);
                  /*~-1*/
                  }
                  /*~E:I2484*/
                  /*~-1*/
#endif
                  /*~E:I2483*/
               /*~-1*/
               }
               /*~O:I2477*/
               /*~-2*/
               else
               {
                  /*~T*/
                  // NotAcknowledge senden
                  byRetVal = ADuC836_SPISendChar(NAK);
               /*~-1*/
               }
               /*~E:I2477*/
               /*~T*/
               break;
               /*~E:A2476*/
            /*~-1*/
            }
            /*~E:F2475*/
            /*~F:2485*/
            case INSTRUCTIONDECODER_SEND_E006:			// Kommando noch nicht implementiert
            /*~-1*/
            {
               /*~A:2486*/
               /*~+:INSTRUCTIONDECODER_SEND_E006*/
               /*~I:2487*/
               if (CommunicationControl.chLine2Interprete == COMMUNICATION_RS232)
               /*~-1*/
               {
                  /*~I:2488*/
                  if (!SYSTEM_MRW_MANAGER)
                  /*~-1*/
                  {
                     /*~I:2489*/
                     if (lText2Send)
                     /*~-1*/
                     {
                        /*~I:2490*/
#ifdef CHANNEL_0
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~-1*/
#endif
                        /*~E:I2490*/
                        /*~I:2491*/
#ifdef CHANNEL_1
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~-1*/
#endif
                        /*~E:I2491*/
                        /*~T*/
                        break;
                     /*~-1*/
                     }
                     /*~E:I2489*/
                  /*~-1*/
                  }
                  /*~E:I2488*/
                  /*~I:2492*/
#ifdef CHANNEL_0
                  /*~T*/
                  Communication_SendString(COMMUNICATION_RS232,TEXT_E006,1,0);
                  /*~-1*/
#endif
                  /*~E:I2492*/
                  /*~I:2493*/
#ifdef CHANNEL_1
                  /*~I:2494*/
                  if (bDoNotWriteResult2Buffer)
                  /*~-1*/
                  {
                     /*~T*/
                     Communication_SendString(COMMUNICATION_RS232,TEXT_E006,1,0);
                  /*~-1*/
                  }
                  /*~E:I2494*/
                  /*~-1*/
#endif
                  /*~E:I2493*/
               /*~-1*/
               }
               /*~O:I2487*/
               /*~-2*/
               else
               {
                  /*~T*/
                  // NotAcknowledge senden
                  byRetVal = ADuC836_SPISendChar(NAK);
               /*~-1*/
               }
               /*~E:I2487*/
               /*~T*/
               break;
               /*~E:A2486*/
            /*~-1*/
            }
            /*~E:F2485*/
            /*~F:2495*/
            case INSTRUCTIONDECODER_SEND_E007:			// Parameter fehlt 
            /*~-1*/
            {
               /*~A:2496*/
               /*~+:INSTRUCTIONDECODER_SEND_E007*/
               /*~I:2497*/
               if (CommunicationControl.chLine2Interprete == COMMUNICATION_RS232)
               /*~-1*/
               {
                  /*~I:2498*/
                  if (!SYSTEM_MRW_MANAGER)
                  /*~-1*/
                  {
                     /*~I:2499*/
                     if (lText2Send)
                     /*~-1*/
                     {
                        /*~I:2500*/
#ifdef CHANNEL_0
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~-1*/
#endif
                        /*~E:I2500*/
                        /*~I:2501*/
#ifdef CHANNEL_1
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~-1*/
#endif
                        /*~E:I2501*/
                        /*~T*/
                        break;
                     /*~-1*/
                     }
                     /*~E:I2499*/
                  /*~-1*/
                  }
                  /*~E:I2498*/
                  /*~I:2502*/
#ifdef CHANNEL_0
                  /*~T*/
                  Communication_SendString(COMMUNICATION_RS232,TEXT_E007,1,0);
                  /*~-1*/
#endif
                  /*~E:I2502*/
                  /*~I:2503*/
#ifdef CHANNEL_1
                  /*~I:2504*/
                  if (bDoNotWriteResult2Buffer)
                  /*~-1*/
                  {
                     /*~T*/
                     Communication_SendString(COMMUNICATION_RS232,TEXT_E007,1,0);
                  /*~-1*/
                  }
                  /*~E:I2504*/
                  /*~-1*/
#endif
                  /*~E:I2503*/
               /*~-1*/
               }
               /*~O:I2497*/
               /*~-2*/
               else
               {
                  /*~T*/
                  // NotAcknowledge senden
                  byRetVal = ADuC836_SPISendChar(NAK);
               /*~-1*/
               }
               /*~E:I2497*/
               /*~T*/
               break;
               /*~E:A2496*/
            /*~-1*/
            }
            /*~E:F2495*/
            /*~F:2505*/
            case INSTRUCTIONDECODER_SEND_E008:			// Unerwartetes Zeichen im Kommandostring 
            /*~-1*/
            {
               /*~A:2506*/
               /*~+:INSTRUCTIONDECODER_SEND_E008*/
               /*~I:2507*/
               if (CommunicationControl.chLine2Interprete == COMMUNICATION_RS232)
               /*~-1*/
               {
                  /*~I:2508*/
                  if (!SYSTEM_MRW_MANAGER)
                  /*~-1*/
                  {
                     /*~I:2509*/
                     if (lText2Send)
                     /*~-1*/
                     {
                        /*~I:2510*/
#ifdef CHANNEL_0
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~-1*/
#endif
                        /*~E:I2510*/
                        /*~I:2511*/
#ifdef CHANNEL_1
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~-1*/
#endif
                        /*~E:I2511*/
                        /*~T*/
                        break;
                     /*~-1*/
                     }
                     /*~E:I2509*/
                  /*~-1*/
                  }
                  /*~E:I2508*/
                  /*~I:2512*/
#ifdef CHANNEL_0
                  /*~T*/
                  Communication_SendString(COMMUNICATION_RS232,TEXT_E008,1,0);
                  /*~-1*/
#endif
                  /*~E:I2512*/
                  /*~I:2513*/
#ifdef CHANNEL_1
                  /*~I:2514*/
                  if (bDoNotWriteResult2Buffer)
                  /*~-1*/
                  {
                     /*~T*/
                     Communication_SendString(COMMUNICATION_RS232,TEXT_E008,1,0);
                  /*~-1*/
                  }
                  /*~E:I2514*/
                  /*~-1*/
#endif
                  /*~E:I2513*/
               /*~-1*/
               }
               /*~O:I2507*/
               /*~-2*/
               else
               {
                  /*~T*/
                  // NotAcknowledge senden
                  byRetVal = ADuC836_SPISendChar(NAK);
               /*~-1*/
               }
               /*~E:I2507*/
               /*~T*/
               break;
               /*~E:A2506*/
            /*~-1*/
            }
            /*~E:F2505*/
            /*~F:2515*/
            case INSTRUCTIONDECODER_SEND_E009:			// Wert au�erhalb des Grenzwertes

            /*~-1*/
            {
               /*~A:2516*/
               /*~+:INSTRUCTIONDECODER_SEND_E009*/
               /*~I:2517*/
               if (CommunicationControl.chLine2Interprete == COMMUNICATION_RS232)
               /*~-1*/
               {
                  /*~I:2518*/
                  if (!SYSTEM_MRW_MANAGER)
                  /*~-1*/
                  {
                     /*~I:2519*/
                     if (lText2Send)
                     /*~-1*/
                     {
                        /*~I:2520*/
#ifdef CHANNEL_0
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~-1*/
#endif
                        /*~E:I2520*/
                        /*~I:2521*/
#ifdef CHANNEL_1
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~-1*/
#endif
                        /*~E:I2521*/
                        /*~T*/
                        break;
                     /*~-1*/
                     }
                     /*~E:I2519*/
                  /*~-1*/
                  }
                  /*~E:I2518*/
                  /*~I:2522*/
#ifdef CHANNEL_0
                  /*~T*/
                  Communication_SendString(COMMUNICATION_RS232,TEXT_E009,1,0);
                  /*~-1*/
#endif
                  /*~E:I2522*/
                  /*~I:2523*/
#ifdef CHANNEL_1
                  /*~I:2524*/
                  if (bDoNotWriteResult2Buffer)
                  /*~-1*/
                  {
                     /*~T*/
                     Communication_SendString(COMMUNICATION_RS232,TEXT_E009,1,0);
                  /*~-1*/
                  }
                  /*~E:I2524*/
                  /*~-1*/
#endif
                  /*~E:I2523*/
               /*~-1*/
               }
               /*~O:I2517*/
               /*~-2*/
               else
               {
                  /*~T*/
                  // NotAcknowledge senden
                  byRetVal = ADuC836_SPISendChar(NAK);
               /*~-1*/
               }
               /*~E:I2517*/
               /*~T*/
               break;
               /*~E:A2516*/
            /*~-1*/
            }
            /*~E:F2515*/
            /*~F:2525*/
            case INSTRUCTIONDECODER_SEND_E010:			// Drifterkennung l�uft (nur SLC)

            /*~-1*/
            {
               /*~A:2526*/
               /*~+:INSTRUCTIONDECODER_SEND_E010*/
               /*~I:2527*/
               if (CommunicationControl.chLine2Interprete == COMMUNICATION_RS232)
               /*~-1*/
               {
                  /*~I:2528*/
                  if (!SYSTEM_MRW_MANAGER)
                  /*~-1*/
                  {
                     /*~I:2529*/
                     if (lText2Send)
                     /*~-1*/
                     {
                        /*~I:2530*/
#ifdef CHANNEL_0
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~-1*/
#endif
                        /*~E:I2530*/
                        /*~I:2531*/
#ifdef CHANNEL_1
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~-1*/
#endif
                        /*~E:I2531*/
                        /*~T*/
                        break;
                     /*~-1*/
                     }
                     /*~E:I2529*/
                     /*~I:2532*/
#ifdef CHANNEL_0
                     /*~T*/
                     Communication_SendString(COMMUNICATION_RS232,TEXT_E010,1,0);
                     /*~-1*/
#endif
                     /*~E:I2532*/
                     /*~I:2533*/
#ifdef CHANNEL_1 
                     /*~I:2534*/
                     if (bDoNotWriteResult2Buffer)
                     /*~-1*/
                     {
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,TEXT_E010,1,0);
                     /*~-1*/
                     }
                     /*~E:I2534*/
                     /*~-1*/
#endif
                     /*~E:I2533*/
                  /*~-1*/
                  }
                  /*~E:I2528*/
               /*~-1*/
               }
               /*~O:I2527*/
               /*~-2*/
               else
               {
                  /*~T*/
                  // NotAcknowledge senden
                  byRetVal = ADuC836_SPISendChar(NAK);
               /*~-1*/
               }
               /*~E:I2527*/
               /*~T*/
               break;
               /*~E:A2526*/
            /*~-1*/
            }
            /*~E:F2525*/
            /*~F:2535*/
            case INSTRUCTIONDECODER_SEND_E011:			// Parameter der Partner sind unterschiedlich 
            /*~-1*/
            {
               /*~A:2536*/
               /*~+:INSTRUCTIONDECODER_SEND_E011*/
               /*~I:2537*/
               if (CommunicationControl.chLine2Interprete == COMMUNICATION_RS232)
               /*~-1*/
               {
                  /*~I:2538*/
                  if (!SYSTEM_MRW_MANAGER)
                  /*~-1*/
                  {
                     /*~I:2539*/
                     if (lText2Send)
                     /*~-1*/
                     {
                        /*~I:2540*/
#ifdef CHANNEL_0
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~-1*/
#endif
                        /*~E:I2540*/
                        /*~I:2541*/
#ifdef CHANNEL_1
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~-1*/
#endif
                        /*~E:I2541*/
                        /*~T*/
                        break;
                     /*~-1*/
                     }
                     /*~E:I2539*/
                  /*~-1*/
                  }
                  /*~E:I2538*/
                  /*~I:2542*/
#ifdef CHANNEL_0
                  /*~T*/
                  Communication_SendString(COMMUNICATION_RS232,TEXT_E011,1,0);
                  /*~-1*/
#endif
                  /*~E:I2542*/
                  /*~I:2543*/
#ifdef CHANNEL_1 
                  /*~I:2544*/
                  if (bDoNotWriteResult2Buffer)
                  /*~-1*/
                  {
                     /*~T*/
                     Communication_SendString(COMMUNICATION_RS232,TEXT_E011,1,0);
                  /*~-1*/
                  }
                  /*~E:I2544*/
                  /*~-1*/
#endif
                  /*~E:I2543*/
               /*~-1*/
               }
               /*~O:I2537*/
               /*~-2*/
               else
               {
                  /*~T*/
                  // NotAcknowledge senden
                  byRetVal = ADuC836_SPISendChar(NAK);
               /*~-1*/
               }
               /*~E:I2537*/
               /*~T*/
               break;
               /*~E:A2536*/
            /*~-1*/
            }
            /*~E:F2535*/
            /*~F:2545*/
            case INSTRUCTIONDECODER_SEND_E012:			// Checksummenfehler
            /*~-1*/
            {
               /*~A:2546*/
               /*~+:INSTRUCTIONDECODER_SEND_E012*/
               /*~I:2547*/
               if (CommunicationControl.chLine2Interprete == COMMUNICATION_RS232)
               /*~-1*/
               {
                  /*~I:2548*/
                  if (!SYSTEM_MRW_MANAGER)
                  /*~-1*/
                  {
                     /*~I:2549*/
                     if (lText2Send)
                     /*~-1*/
                     {
                        /*~I:2550*/
#ifdef CHANNEL_0
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~-1*/
#endif
                        /*~E:I2550*/
                        /*~I:2551*/
#ifdef CHANNEL_1
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~-1*/
#endif
                        /*~E:I2551*/
                        /*~T*/
                        break;
                     /*~-1*/
                     }
                     /*~E:I2549*/
                  /*~-1*/
                  }
                  /*~E:I2548*/
                  /*~T*/
                  Communication_SendString(COMMUNICATION_RS232,TEXT_E012,1,0);
               /*~-1*/
               }
               /*~O:I2547*/
               /*~-2*/
               else
               {
                  /*~T*/
                  // NotAcknowledge senden
                  byRetVal = ADuC836_SPISendChar(NAK);
               /*~-1*/
               }
               /*~E:I2547*/
               /*~T*/
               break;
               /*~E:A2546*/
            /*~-1*/
            }
            /*~E:F2545*/
            /*~F:2552*/
            case INSTRUCTIONDECODER_SEND_NOK:			// NOK senden
            /*~-1*/
            {
               /*~A:2553*/
               /*~+:INSTRUCTIONDECODER_SEND_NOK*/
               /*~I:2554*/
               if (CommunicationControl.chLine2Interprete == COMMUNICATION_RS232)
               /*~-1*/
               {
                  /*~I:2555*/
                  if (!SYSTEM_MRW_MANAGER)
                  /*~-1*/
                  {
                     /*~I:2556*/
                     if (lText2Send)
                     /*~-1*/
                     {
                        /*~A:2557*/
                        /*~+:RS232-Ausgabe*/
                        /*~T*/
                        sprintf(szString2Send,"T%04ld",lText2Send);
                        /*~T*/
                        Communication_SendString(COMMUNICATION_RS232,szString2Send,1,0);
                        /*~E:A2557*/
                        /*~T*/
                        break;
                     /*~-1*/
                     }
                     /*~E:I2556*/
                  /*~-1*/
                  }
                  /*~E:I2555*/
                  /*~A:2558*/
                  /*~+:RS232-Ausgabe*/
                  /*~T*/
                  Communication_SendMessage(COMMUNICATION_RS232,COMMUNICATION_NOK);
                  /*~E:A2558*/
               /*~-1*/
               }
               /*~E:I2554*/
               /*~T*/
               break;
               /*~E:A2553*/
            /*~-1*/
            }
            /*~E:F2552*/
            /*~F:2559*/
            case INSTRUCTIONDECODER_SEND_NOTHING:
            /*~-1*/
            {
               /*~T*/
               break;
            /*~-1*/
            }
            /*~E:F2559*/
         /*~-1*/
         }
         /*~E:C2422*/
         /*~I:2560*/
#ifdef CHANNEL_1
         /*~I:2561*/
         if (!bDoNotWriteResult2Buffer)
         /*~-1*/
         {
            /*~T*/
            bDoNotWriteResult2Buffer = 1;

            g_byLastCommandExecutionResult = byCommandStatus;
         /*~-1*/
         }
         /*~E:I2561*/
         /*~-1*/
#endif
         /*~E:I2560*/
         /*~E:A2421*/
      /*~-1*/
      }
      /*~E:I58*/
   /*~-1*/
   }
   /*~E:I57*/
   /*~I:2562*/
#ifdef MOF
   /*~I:2563*/
   if (CommunicationControl.chLine2Interprete == COMMUNICATION_RS232)
   /*~-1*/
   {
      /*~A:2564*/
      /*~+:Kanal 0 - Freigabesteuerung*/
      /*~I:2565*/
#ifdef CHANNEL_0
      /*~T*/
      ulTimeout = SYSTEMTIME + HANDSHAKING_TIMEOUT; 
      /*~L:2566*/
      while ((byStatelineStatus == COMMUNICATION_INSTUCTIONDECODER_STATE_LINE)&&(ulTimeout >= SYSTEMTIME))
      /*~-1*/
      {
         /*~T*/

      /*~-1*/
      }
      /*~E:L2566*/
      /*~T*/
      // Freigabeleitung f�r Start des Instruction-Dekoders auf Partner-Seite wieder l�schen
      COMMUNICATION_INSTUCTIONDECODER_RELEASE_LINE = 0;	
      /*~-1*/
#endif
      /*~E:I2565*/
      /*~E:A2564*/
      /*~A:2567*/
      /*~+:Kanal 1 - Freigabesteuerung*/
      /*~I:2568*/
#ifdef CHANNEL_1
      /*~T*/
      ulTimeout = SYSTEMTIME + HANDSHAKING_TIMEOUT; 
      /*~L:2569*/
      while ((ADuC836_RS232IsTransmissionReady() == FALSE)&&(ulTimeout >= SYSTEMTIME))
      /*~-1*/
      {
         /*~T*/

      /*~-1*/
      }
      /*~E:L2569*/
      /*~T*/
      ulTimeout = SYSTEMTIME + HANDSHAKING_TIMEOUT; 
      /*~T*/
      COMMUNICATION_INSTUCTIONDECODER_RELEASE_LINE = !COMMUNICATION_INSTUCTIONDECODER_RELEASE_LINE;
      /*~L:2570*/
      while ((COMMUNICATION_INSTUCTIONDECODER_STATE_LINE == TRUE)&&(ulTimeout >= SYSTEMTIME))
      /*~-1*/
      {
         /*~T*/

      /*~-1*/
      }
      /*~E:L2570*/
      /*~L:2571*/
      while ((COMMUNICATION_INSTUCTIONDECODER_STATE_LINE == FALSE)&&(ulTimeout >= SYSTEMTIME))
      /*~-1*/
      {
         /*~T*/

      /*~-1*/
      }
      /*~E:L2571*/
      /*~-1*/
#endif
      /*~E:I2568*/
      /*~E:A2567*/
   /*~-1*/
   }
   /*~E:I2563*/
   /*~-1*/
#endif
   /*~E:I2562*/
   /*~E:A20*/
   /*~A:2572*/
   /*~+:Letzes Kommando f�r immer l�schen*/
   /*~T*/
   // letzes Kommando f�r immer l�schen
   memset(pCommunicationCommand,0,sizeof(COMMUNICATION_COMMAND));
   /*~E:A2572*/
/*~-1*/
}
/*~E:F10*/
/*~E:A9*/
/*~A:2573*/
/*~+:char 			InstructionDecoder_CheckLimits(void *pParameter2Check, void *pLimitLow, void *pLimitHigh, unsigned char chDataType)*/
/*~F:2574*/
char InstructionDecoder_CheckLimits(void *pParameter2Check, void *pLimitLow, void *pLimitHigh, unsigned char chDataType)
/*~-1*/
{
   /*~A:2575*/
   /*~+:Variablendeklarationen*/
   /*~T*/
   char byRetVal;
   /*~E:A2575*/
   /*~A:2576*/
   /*~+:Variableninitialisierungen*/
   /*~T*/

   /*~E:A2576*/
   /*~C:2577*/
   switch (chDataType)
   /*~-1*/
   {
      /*~F:2578*/
      case DATATYPE_CHAR:
      /*~-1*/
      {
         /*~A:2579*/
         /*~+:Variablendeklarationen*/
         /*~T*/
         char byTempLimit;
         /*~E:A2579*/
         /*~A:2580*/
         /*~+:Variableninitialisierungen*/
         /*~T*/

         /*~E:A2580*/
         /*~I:2581*/
         if (*(char*)pLimitLow > *(char*)pLimitHigh)
         /*~-1*/
         {
            /*~T*/
            // unterer und oberer Grenzwert vertauscht

            byTempLimit = *(char*)pLimitLow;

            *(char*)pLimitLow = *(char*)pLimitHigh;
            *(char*)pLimitHigh = byTempLimit;
         /*~-1*/
         }
         /*~E:I2581*/
         /*~I:2582*/
         if (*(char*)pParameter2Check < *(char*)pLimitLow)
         /*~-1*/
         {
            /*~T*/
            // Parameter liegt unterhalb des unteren Grenzwertes
            *(char*)pParameter2Check = *(char*)pLimitLow;

            // 1 zur�ckliefern
            byRetVal = 1;
         /*~-1*/
         }
         /*~O:I2582*/
         /*~-2*/
         else
         {
            /*~I:2583*/
            if (*(char*)pParameter2Check > *(char*)pLimitHigh)
            /*~-1*/
            {
               /*~T*/
               // Parameter liegt oberhalb des oberen Grenzwertes
               *(char*)pParameter2Check = *(char*)pLimitHigh;

               // 2 zur�ckliefern
               byRetVal = 2;
            /*~-1*/
            }
            /*~O:I2583*/
            /*~-2*/
            else
            {
               /*~T*/
               // Grenzwert innerhalb der Grenzen - R�ckgabe von 0 und Ausstieg

               return 0;
            /*~-1*/
            }
            /*~E:I2583*/
         /*~-1*/
         }
         /*~E:I2582*/
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F2578*/
      /*~F:2584*/
      case DATATYPE_INT:
      /*~-1*/
      {
         /*~A:2585*/
         /*~+:Variablendeklarationen*/
         /*~T*/
         int nTempLimit;
         /*~E:A2585*/
         /*~A:2586*/
         /*~+:Variableninitialisierungen*/
         /*~T*/

         /*~E:A2586*/
         /*~I:2587*/
         if (*(int*)pLimitLow > *(int*)pLimitHigh)
         /*~-1*/
         {
            /*~T*/
            // unterer und oberer Grenzwert vertauscht

            nTempLimit = *(int*)pLimitLow;

            *(int*)pLimitLow = *(int*)pLimitHigh;
            *(int*)pLimitHigh = nTempLimit;
         /*~-1*/
         }
         /*~E:I2587*/
         /*~I:2588*/
         if (*(int*)pParameter2Check < *(int*)pLimitLow)
         /*~-1*/
         {
            /*~T*/
            // Parameter liegt unterhalb des unteren Grenzwertes
            *(int*)pParameter2Check = *(int*)pLimitLow;

            // 1 zur�ckliefern
            byRetVal = 1;
         /*~-1*/
         }
         /*~O:I2588*/
         /*~-2*/
         else
         {
            /*~I:2589*/
            if (*(int*)pParameter2Check > *(int*)pLimitHigh)
            /*~-1*/
            {
               /*~T*/
               // Parameter liegt oberhalb des oberen Grenzwertes
               *(int*)pParameter2Check = *(int*)pLimitHigh;

               // 2 zur�ckliefern
               byRetVal = 2;
            /*~-1*/
            }
            /*~O:I2589*/
            /*~-2*/
            else
            {
               /*~T*/
               // Grenzwert innerhalb der Grenzen - R�ckgabe von 0 und Ausstieg

               return 0;
            /*~-1*/
            }
            /*~E:I2589*/
         /*~-1*/
         }
         /*~E:I2588*/
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F2584*/
      /*~F:2590*/
      case DATATYPE_LONG:
      /*~-1*/
      {
         /*~A:2591*/
         /*~+:Variablendeklarationen*/
         /*~T*/
         long lTempLimit;
         /*~E:A2591*/
         /*~A:2592*/
         /*~+:Variableninitialisierungen*/
         /*~T*/

         /*~E:A2592*/
         /*~I:2593*/
         if (*(long*)pLimitLow > *(long*)pLimitHigh)
         /*~-1*/
         {
            /*~T*/
            // unterer und oberer Grenzwert vertauscht

            lTempLimit = *(long*)pLimitLow;

            *(long*)pLimitLow = *(long*)pLimitHigh;
            *(long*)pLimitHigh = lTempLimit;
         /*~-1*/
         }
         /*~E:I2593*/
         /*~I:2594*/
         if (*(long*)pParameter2Check < *(long*)pLimitLow)
         /*~-1*/
         {
            /*~T*/
            // Parameter liegt unterhalb des unteren Grenzwertes
            *(long*)pParameter2Check = *(long*)pLimitLow;

            // 1 zur�ckliefern
            byRetVal = 1;
         /*~-1*/
         }
         /*~O:I2594*/
         /*~-2*/
         else
         {
            /*~I:2595*/
            if (*(long*)pParameter2Check > *(long*)pLimitHigh)
            /*~-1*/
            {
               /*~T*/
               // Parameter liegt oberhalb des oberen Grenzwertes
               *(long*)pParameter2Check = *(long*)pLimitHigh;

               // 2 zur�ckliefern
               byRetVal = 2;
            /*~-1*/
            }
            /*~O:I2595*/
            /*~-2*/
            else
            {
               /*~T*/
               // Grenzwert innerhalb der Grenzen - R�ckgabe von 0 und Ausstieg

               return 0;
            /*~-1*/
            }
            /*~E:I2595*/
         /*~-1*/
         }
         /*~E:I2594*/
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F2590*/
      /*~F:2596*/
      case DATATYPE_FLOAT:
      /*~-1*/
      {
         /*~A:2597*/
         /*~+:Variablendeklarationen*/
         /*~T*/
         float fTempLimit;
         /*~E:A2597*/
         /*~A:2598*/
         /*~+:Variableninitialisierungen*/
         /*~T*/

         /*~E:A2598*/
         /*~I:2599*/
         if (*(float*)pLimitLow > *(float*)pLimitHigh)
         /*~-1*/
         {
            /*~T*/
            // unterer und oberer Grenzwert vertauscht

            fTempLimit = *(float*)pLimitLow;

            *(float*)pLimitLow = *(float*)pLimitHigh;
            *(float*)pLimitHigh = fTempLimit;
         /*~-1*/
         }
         /*~E:I2599*/
         /*~I:2600*/
         if (*(float*)pParameter2Check < *(float*)pLimitLow)
         /*~-1*/
         {
            /*~T*/
            // Parameter liegt unterhalb des unteren Grenzwertes
            *(float*)pParameter2Check = *(float*)pLimitLow;

            // 1 zur�ckliefern
            byRetVal = 1;
         /*~-1*/
         }
         /*~O:I2600*/
         /*~-2*/
         else
         {
            /*~I:2601*/
            if (*(float*)pParameter2Check > *(float*)pLimitHigh)
            /*~-1*/
            {
               /*~T*/
               // Parameter liegt oberhalb des oberen Grenzwertes
               *(float*)pParameter2Check = *(float*)pLimitHigh;

               // 2 zur�ckliefern
               byRetVal = 2;
            /*~-1*/
            }
            /*~O:I2601*/
            /*~-2*/
            else
            {
               /*~T*/
               // Grenzwert innerhalb der Grenzen - R�ckgabe von 0 und Ausstieg

               return 0;
            /*~-1*/
            }
            /*~E:I2601*/
         /*~-1*/
         }
         /*~E:I2600*/
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F2596*/
   /*~-1*/
   }
   /*~E:C2577*/
   /*~T*/
   // Meldung ausgeben
   Communication_SendString(COMMUNICATION_RS232,TEXT_E002,0,0);
   /*~T*/
   return byRetVal;
/*~-1*/
}
/*~E:F2574*/
/*~E:A2573*/
/*~A:2602*/
/*~+:char 			InstructionDecoder_CheckNbParameters(unsigned char byNbParametersExpected,char byShowErrorsBy,unsigned char *pStatus)*/
/*~F:2603*/
char InstructionDecoder_CheckNbParameters(unsigned char byNbParametersExpected,char byShowErrorsBy,unsigned char *pStatus)
/*~-1*/
{
   /*~A:2604*/
   /*~+:Variablendeklarationen*/
   /*~T*/
   // Variablendeklarationen
   unsigned char byNumberOfParameters;
   /*~E:A2604*/
   /*~A:2605*/
   /*~+:Variableninitialisierungen*/
   /*~T*/
   // Variableninitialisierungen
   /*~E:A2605*/
   /*~T*/
   byNumberOfParameters = Communication_GetNumberOfParameters();
   /*~I:2606*/
   if (byNumberOfParameters == byNbParametersExpected)
   /*~-1*/
   {
      /*~T*/
      // Anzahl der Parameter stimmt
      /*~T*/
      return 0;
   /*~-1*/
   }
   /*~O:I2606*/
   /*~-2*/
   else
   {
      /*~I:2607*/
      if (byNbParametersExpected > byNumberOfParameters)
      /*~-1*/
      {
         /*~T*/
         // Anzahl der �bergebenen Parameter zu klein
         /*~I:2608*/
#ifdef CHANNEL_0
         /*~I:2609*/
         if (byShowErrorsBy & 0x01)
         /*~-1*/
         {
            /*~A:2610*/
            /*~+:E007*/
            /*~T*/
            Communication_SendString(COMMUNICATION_RS232,TEXT_E007,1,0);
            /*~E:A2610*/
         /*~-1*/
         }
         /*~E:I2609*/
         /*~-1*/
#endif
         /*~E:I2608*/
         /*~I:2611*/
#ifdef CHANNEL_1
         /*~I:2612*/
         if (byShowErrorsBy & 0x02)
         /*~-1*/
         {
            /*~A:2613*/
            /*~+:E007*/
            /*~T*/
            *pStatus = INSTRUCTIONDECODER_SEND_E007; 
            /*~E:A2613*/
         /*~-1*/
         }
         /*~E:I2612*/
         /*~-1*/
#endif
         /*~E:I2611*/
         /*~T*/
         return 1;
      /*~-1*/
      }
      /*~O:I2607*/
      /*~-2*/
      else
      {
         /*~T*/
         // Anzahl der �bergebenen Parameter zu gro�
         /*~I:2614*/
#ifdef CHANNEL_0
         /*~I:2615*/
         if (byShowErrorsBy & 0x01)
         /*~-1*/
         {
            /*~A:2616*/
            /*~+:E008*/
            /*~T*/
            Communication_SendString(COMMUNICATION_RS232,TEXT_E008,1,0);
            /*~E:A2616*/
         /*~-1*/
         }
         /*~E:I2615*/
         /*~-1*/
#endif
         /*~E:I2614*/
         /*~I:2617*/
#ifdef CHANNEL_1
         /*~I:2618*/
         if (byShowErrorsBy & 0x02)
         /*~-1*/
         {
            /*~A:2619*/
            /*~+:E008*/
            /*~T*/
            *pStatus = INSTRUCTIONDECODER_SEND_E008; 
            /*~E:A2619*/
         /*~-1*/
         }
         /*~E:I2618*/
         /*~-1*/
#endif
         /*~E:I2617*/
         /*~T*/
         return 2;
      /*~-1*/
      }
      /*~E:I2607*/
   /*~-1*/
   }
   /*~E:I2606*/
/*~-1*/
}
/*~E:F2603*/
/*~E:A2602*/
/*~I:2620*/
#ifdef CHANNEL_1
/*~A:2621*/
/*~+:void 			InstructionDecoder_StoreValue(unsigned char byValue2Store,GLOBAL_UNIVALUE Value)*/
/*~F:2622*/
void InstructionDecoder_StoreValue(unsigned char byValue2Store,GLOBAL_UNIVALUE_SHORT* pValue)
/*~-1*/
{
   /*~T*/
   g_byValueStored = byValue2Store;
   g_Value = *pValue;
   g_ulTimeoutValue = SYSTEMTIME + 500;
/*~-1*/
}
/*~E:F2622*/
/*~E:A2621*/
/*~-1*/
#endif
/*~E:I2620*/
