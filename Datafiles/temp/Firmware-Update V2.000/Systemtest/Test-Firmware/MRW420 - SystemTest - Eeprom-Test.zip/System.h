/*~-1*/
/*~XSF_LANGUAGE: C/C++*/
/*~A:1*/
/*~+:Versions-Beschreibung*/
/*~A:2*/
/*~+:Version und Versionsdatum*/
/*~T*/
/*!
\mainpage "Modul-Beschreibung"
\author Michael Offenbach
\date 
\version V1.000
\warning
*/
/*~E:A2*/
/*~A:3*/
/*~+:Lifecycle*/
/*~T*/
/*!\page LifeCyclePage Lifecycle

\section sec_LifeCyclePage_Systemtimer 'Systemtimer'

<table border=1 width=100% height=1% rules=rows cellspacing=0 bgcolor="#E0E0F0">

<tr align=left valign=top>
	<th>Version</th>
	<th>Datum</th>
	<th>Programmierer</th>
	<th>�nderungen</th>
</tr>

<tr>
	<td>1.000</td>
	<td>24.08.05</td>
	<td>Michael Offenbach</td>
	<td>Erste lauff�hige Version</td>
</tr>
</table>

*/
/*~E:A3*/
/*~E:A1*/
/*~I:4*/
#ifndef __SYSTEM_H

/*~T*/
#define __SYSTEM_H

/*~A:5*/
/*~+:Includes*/
/*~T*/
// erweiterte Dateitypen
#include <Var_Types.h>
/*~E:A5*/
/*~A:6*/
/*~+:Definitionen*/
/*~T*/
#define SYSTEMTIME			Timer.ulOperatingTime	///< Systemzeit in ms
#define OPERATINGHOURS		Global.ulOperatingHours	///< Betriebsstundenz�hler
#define CUSTOMTIMER			Global.ulOperatingHours_2	///< Relativer Betriebsstundenz�hler
#define SYSTEM_MRW_MANAGER	System_IsConnected2MRW_Manager()
/*~E:A6*/
/*~A:7*/
/*~+:Struktur-Definitionen*/
/*~T*/
typedef struct
{
	unsigned char 	chSyncErrorCounter;
	unsigned char 	chSystemSynchronized;
	unsigned char 	bCheckSynchronisationOn;
	unsigned char 	chCheckSynchronisationCounter;
	char 			szItemNumber[12];
	char 			szSerialNumber[14];
	BYTE 			byMRWManagerMode;
	BYTE			byLoadCellType;
	BYTE			bySimulate;					///< Simulationsmodus
												///< 0Xxxxx xxx1 = Rohmesswert ADC
												///< 0Xxxxx xx1x = Temperatur
}
SYSTEM;
/*~E:A7*/
/*~A:8*/
/*~+:Funktionsdeklarationen*/
/*~T*/
extern void 			System(void);
extern unsigned long 	System_BuildAdminCode(void);
extern char 			System_CheckVersion(void);
extern void 			System_ClearOperatingHours(char byTimer);
extern void	 			System_ClearSystemError(void);
extern void 			System_Connect2MRW_Manager(char byMode);
extern char* 			System_GetItemNumber(void);
extern long 			System_GetOperatingHours(char byTimer,unsigned char bHighResolution);

extern unsigned char*	System_GetOperatingHoursAsString(char byTimer);
extern void 			System_GetPartnerStates(void);
extern char* 			System_GetSerialNumber(void);
/*~I:9*/
#ifdef CHANNEL_1
/*~T*/
extern void 			System_IncCheckSynchronisationCounter(void);

/*~-1*/
#endif
/*~E:I9*/
/*~T*/
extern void 			System_Ini(unsigned char chMode);
extern unsigned char	System_IsConnected2MRW_Manager(void);

/*~I:10*/
#ifdef MOF
/*~T*/
extern void 			System_ReleaseExternalInterrupt(void);

/*~-1*/
#endif
/*~E:I10*/
/*~T*/
extern void 			System_Reset(void);
extern void 			System_SaveOperatingHours(void);
extern void 			System_SetCheckSynchronisation(unsigned char chOnOff);
extern char 			System_SetItemNumber(char *szItemNumber2Set);
extern char 			System_SetSerialNumber(char *szSerialNumber2Set);
extern void 			System_SetSystemState(unsigned long ulState2Set);
extern void 			System_Synchronization(void);
extern void 			System_SystemErrorSetWatchdog(void);
extern void 			System_UpdateOperatingHours(unsigned char byMode);
extern void				System_Wait(unsigned int uTimeMS);
/*~E:A8*/
/*~A:11*/
/*~+:Variablen*/
/*~T*/
extern SYSTEM g_SystemControl;
/*~E:A11*/
/*~-1*/
#endif
/*~E:I4*/
