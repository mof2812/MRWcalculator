/*~-1*/
/*~XSF_LANGUAGE: C/C++*/
/*~K*/
/*~+:File :        CurrentInterface.c*/
/*~+:*/
/*~+:Version :     V1.0*/
/*~+:*/
/*~+:Date :        17.03.2005*/
/*~+:*/
/*~+:Time :        10:23*/
/*~+:*/
/*~+:Author :      MOF*/
/*~+:*/
/*~+:Hardware :*/
/*~+:*/
/*~+:Description :*/
/*~+:*/
/*~+:*/
/*~A:1*/
/*~+:Includes*/
/*~T*/
#include "CurrentInterface.h"
#include "Diagnosis.h"
#include "Global.h"
#include <math.h>
#include <string.h>
#include <Stdlib.h>
/*~E:A1*/
/*~A:2*/
/*~+:Funktionseigene Definitionen*/
/*~T*/
#define CURRENTINTERFACE_MIT_PI_Regler
#define CURRENTINTERFACE_TIMETICS2SEC		100		///< Anzahl der Durchl�ufe pro Sekunde (wird nur f�r die Einstellung der Zeithystere ben�tigt)
/*~E:A2*/
/*~A:3*/
/*~+:Funktionseigene Struktur-Definitionen*/
/*~T*/

/*~E:A3*/
/*~A:4*/
/*~+:Funktionsprototypen*/
/*~T*/
void 			CurrentInterface(long lValue2Convert);
char 			CurrentInterface_Calibration(unsigned char chWhat2Do,float fTrueValue);

/*~K*/
/*~+:/~* Hinzugef�gt am 09.02.2022 *~/*/
/*~T*/
unsigned char 		CurrentInterface_EvaluateDeviation(unsigned char bCurrentOn, float fDeviation, unsigned char *pbyDisableFeedbackCounter);
/*~K*/
/*~+:/~* Ende - Hinzugef�gt am 09.02.2022 *~/*/
/*~T*/
void 			CurrentInterface_FeedBack(void);
float 			CurrentInterface_GetCurrent(unsigned char byMode);
char 			CurrentInterface_GetFeedBackIntegralPortion(void);
char 			CurrentInterface_GetFeedBackProportionalPortion(void);
char 			CurrentInterface_GetFeedBackState(void);
unsigned int 		CurrentInterface_GetTimeHysteresis(void);
char 			CurrentInterface_Ini(unsigned char byMode);

/*~K*/
/*~+:/~* Hinzugef�gt am 09.02.2022 *~/*/
/*~T*/
void 			CurrentInterface_Ini_2(unsigned char byMode);

/*~K*/
/*~+:/~* Ende - Hinzugef�gt am 09.02.2022 *~/*/
/*~T*/
void			CurrentInterface_LoadDACSettings(unsigned char chWhat2Load);
void 			CurrentInterface_PrepareCalibration(unsigned char byCalPoint,float fWeight);

void 			CurrentInterface_SaveDACSettings(unsigned char chWhat2Save);
char 			CurrentInterface_SetCalibrationFactorOfFeedBack(float fCalibrationFactor);
void 			CurrentInterface_SetFeedBackOnOff(unsigned char bOnOff,unsigned char bSave);
void 			CurrentInterface_SetFeedBackIntegralPortion(char chIntegralPortion);
void 			CurrentInterface_SetFeedBackProportionalPortion(char chProportionalPortion);
void 			CurrentInterface_SetLimits(long lLowerLimit,long lUpperLimit);
void 			CurrentInterface_SetManualMode(unsigned char byOnOff,long lRatedDACOutput);
void 			CurrentInterface_SetTimeHysteresis(unsigned int uTime);
char			CurrentInterface_SetZeroOfFeedBack(long lZero2Set);
char			CurrentInterface_SetZeroOfFeedBackRegardingActualWeight(void);

/*~E:A4*/
/*~A:5*/
/*~+:Globale Variablen*/
/*~T*/
CURRENT_INTERFACE g_CurrentInterface;
unsigned char byDisableFeedbackCounter = 0;
/*~E:A5*/
/*~K*/
/*~+:*/
/*~A:6*/
/*~+:void 			CurrentInterface(long lValue2Convert)*/
/*~F:7*/
void CurrentInterface(long lValue2Convert)
/*~-1*/
{
   /*~A:8*/
   /*~+:Beschreibung*/
   /*~T*/
   /*!
   \fn void CurrentInterface(long lValue2Convert)
   
   <b>Beschreibung:</b><br>
   Hauptfunktion zur Stromschnittstelle. Diese ruft die Wandlungsroutine des DACs auf und gibt den Nullpunkt korrigierten Rohmesswert aus.
   
   \param
   lValue2Convert: zu wandelnder Wert.
   
   \return
   ./.
   
   <b>Zugriff:</b><br>
   [X] �ffentlich / [ ] Privat
   */

   /*~E:A8*/
   /*~A:9*/
   /*~+:Variablendeklarationen*/
   /*~T*/
   //float 	fDeviation = 0;
   float 		fP;
   float 		fI;
   long 		lDAC;
   static long lLastConverted = 0;
   static long lLastValue2Convert;

   /*~E:A9*/
   /*~A:10*/
   /*~+:Variablendeklarationen*/
   /*~+:FOR_DEBUGGING_ONLY - ausgeklammert*/
   /*~I:11*/
#ifdef MOF
   /*~T*/
   static long lValue2ConvertCopy = 0;
   static unsigned long ulStartTime = 0;
   static unsigned long ulMaxTime = 0;
   unsigned long ulDuration = 0;
   /*~-1*/
#endif
   /*~E:I11*/
   /*~E:A10*/
   /*~A:12*/
   /*~+:Variableninitialisierungen*/
   /*~T*/
   fP = (float)g_CurrentInterface.FeedBack.chProportionalPortion * 0.01;
   fI = (float)g_CurrentInterface.FeedBack.chIntegralPortion * 0.01;
   /*~E:A12*/
   /*~I:13*/
   if (1)//(Flag100ms)
   /*~-1*/
   {
      /*~A:14*/
      /*~+:FOR_DEBUGGING_ONLY - ausgeklammert*/
      /*~I:15*/
#ifdef MOF
      /*~I:16*/
      if (lValue2Convert == lValue2ConvertCopy)
      /*~-1*/
      {
         /*~T*/
         ulDuration = SYSTEMTIME - ulStartTime;
         /*~I:17*/
         if (ulDuration < 0x80000000)
         /*~-1*/
         {
            /*~I:18*/
            if ((ulMaxTime < ulDuration)&&(SYSTEMTIME > 5000))
            /*~-1*/
            {
               /*~T*/
               ulMaxTime = ulDuration;
               /*~I:19*/
#ifdef CHANNEL_0
               /*~T*/
               //Communication_SendString(COMMUNICATION_RS232,"MAX_0 = ",0,0);
               Communication_SendLong(COMMUNICATION_RS232,9990,(long)ulMaxTime,0,1);
               /*~-1*/
#endif
               /*~E:I19*/
               /*~I:20*/
#ifdef CHANNEL_1
               /*~T*/
               //Communication_SendString(COMMUNICATION_RS232,"MAX_1 = ",0,0);
               Communication_SendLong(COMMUNICATION_RS232,9991,(long)ulMaxTime,0,1);
               /*~-1*/
#endif
               /*~E:I20*/
            /*~-1*/
            }
            /*~E:I18*/
         /*~-1*/
         }
         /*~E:I17*/
         /*~A:21*/
         /*~+:STOP_IF_t_GREATER_THAN_300*/
         /*~I:22*/
#ifdef STOP_IF_t_GREATER_THAN_300
         /*~I:23*/
         if (ulDuration > 300)
         /*~-1*/
         {
            /*~I:24*/
#ifdef CHANNEL_0
            /*~T*/
            Communication_SendString(COMMUNICATION_RS232,"Error_0 : ",0,1);
            /*~-1*/
#endif
            /*~E:I24*/
            /*~I:25*/
#ifdef CHANNEL_1
            /*~T*/
            Communication_SendString(COMMUNICATION_RS232,"Error_1 : ",0,1);
            /*~-1*/
#endif
            /*~E:I25*/
            /*~T*/
            Communication_SendLong(COMMUNICATION_RS232,0,ulDuration,0,1);
            /*~L:26*/
            while (1)
            /*~-1*/
            {
               /*~T*/
               Watchdog();
            /*~-1*/
            }
            /*~E:L26*/
         /*~-1*/
         }
         /*~E:I23*/
         /*~-1*/
#endif
         /*~E:I22*/
         /*~E:A21*/
      /*~-1*/
      }
      /*~O:I16*/
      /*~-2*/
      else
      {
         /*~T*/
         ulStartTime = SYSTEMTIME;

         lValue2ConvertCopy = lValue2Convert;
      /*~-1*/
      }
      /*~E:I16*/
      /*~I:27*/
#ifdef FOR_DEBUGGING_ONLY
      /*~T*/
      //Communication_SendString(COMMUNICATION_RS232,"Value2Convert = ",0,0);
      Communication_SendLong(COMMUNICATION_RS232,0,lValue2Convert,0,1);
      /*~T*/
      Communication_SendString(COMMUNICATION_RS232,"DAC-Value = ",0,0);
      Communication_SendLong(COMMUNICATION_RS232,0,lLastConverted,0,1);
      /*~T*/
      Communication_SendString(COMMUNICATION_RS232,"DAC-Value[mA] = ",0,0);
      Communication_SendFloat(COMMUNICATION_RS232,0,fLastConverted,2,0,1);
      /*~-1*/
#endif
      /*~E:I27*/
      /*~-1*/
#endif
      /*~E:I15*/
      /*~E:A14*/
      /*~I:28*/
#ifdef MIT_SYSTEMFEHLER_BEI_PARTNER_SYSTEMFEHLER

      if (((SYSTEMSTATE != SYSTEM_ERROR)&&(SYSTEMSTATE_PARTNER != SYSTEM_ERROR))||(g_CurrentInterface.byAdjustCurrentInterface))

#else

      if ((SYSTEMSTATE != SYSTEM_ERROR)||(g_CurrentInterface.byAdjustCurrentInterface))

#endif

      /*~-1*/
      {
         /*~A:29*/
         /*~+:Stromausgang bei Abgleich der Stromschnittstelle freigeben*/
         /*~I:30*/
         if (ADuC836_DACIsOutputCleared())
         /*~-1*/
         {
            /*~T*/
            // Stromausgang freigeben
            ADuC836_DACClearOutput(0);

            // Korrekturwert der Stromregelung zur�cksetzen
            ADuC836_DACClearCurrentDeviation();
            /*~T*/
            // Stromr�ckf�hrung das n�chste mal �bergehen

            byDisableFeedbackCounter = 1;
         /*~-1*/
         }
         /*~E:I30*/
         /*~E:A29*/
         /*~I:31*/
         if (g_CurrentInterface.byAdjustCurrentInterface == 1)
         /*~-1*/
         {
            /*~T*/
            lValue2Convert = g_CurrentInterface.lRMWForCalibration[0];
         /*~-1*/
         }
         /*~O:I31*/
         /*~-2*/
         else
         {
            /*~I:32*/
            if (g_CurrentInterface.byAdjustCurrentInterface == 2)
            /*~-1*/
            {
               /*~T*/
               lValue2Convert = g_CurrentInterface.lRMWForCalibration[1];
            /*~-1*/
            }
            /*~E:I32*/
         /*~-1*/
         }
         /*~E:I31*/
         /*~A:33*/
         /*~+:Wandlung und Grenzwert�berwachung*/
         /*~I:34*/
         if (!DAC_TESTMODE)
         /*~-1*/
         {
            /*~I:35*/
#ifdef CURRENTINTERFACE_MIT_PI_Regler
            /*~T*/
            // PI-Regler

            // P-Anteil berechnen
            lLastConverted += (long)((float)(lValue2Convert - lLastValue2Convert) * fP);

            // I-Anteil berechnen
            lLastConverted += (long)((float)(lValue2Convert - lLastConverted) * fI);

            lLastValue2Convert = lValue2Convert;
            lDAC = lLastConverted;
            /*~T*/
            g_CurrentInterface.DAC.lRatedDACOutput = lLastValue2Convert;
            /*~T*/
            g_CurrentInterface.byConversionState = ADuC836_DACConvert(&lDAC,0);
            /*~O:I35*/
            /*~-1*/
#else
            /*~T*/
            g_CurrentInterface.DAC.lRatedDACOutput = lValue2Convert;
            /*~T*/
            g_CurrentInterface.byConversionState = ADuC836_DACConvert(&lValue2Convert,0);
            /*~-1*/
#endif
            /*~E:I35*/
            /*~I:36*/
            if (g_CurrentInterface.byConversionState & 0x06)
            /*~-1*/
            {
               /*~T*/
               // unterer Grenzwert unterschritten

               Limit_SetLimitState(LIMIT_HANGINGLIMT_EXCEEDED);
            /*~-1*/
            }
            /*~E:I36*/
            /*~I:37*/
            if (g_CurrentInterface.byConversionState & 0x60)
            /*~-1*/
            {
               /*~T*/
               // oberer Grenzwert �berschritten

               Limit_SetLimitState(LIMIT_ALARMLIMIT_EXCEEDED);
               /*~T*/
               ADuC836_DACClearOutput(1);
            /*~-1*/
            }
            /*~O:I37*/
            /*~-2*/
            else
            {
               /*~I:38*/
               if (g_CurrentInterface.byLastConversionState & 0x60)
               /*~-1*/
               {
                  /*~T*/
                  // Wenn zuletzt eine �berlast anlag, den DAC-Ausgang wieder freigeben
                  ADuC836_DACClearOutput(0);
               /*~-1*/
               }
               /*~E:I38*/
            /*~-1*/
            }
            /*~E:I37*/
            /*~I:39*/
            if (!g_CurrentInterface.byConversionState)
            /*~-1*/
            {
               /*~T*/
               // kein Grenzwert erreicht

               // Digital_SetLED(DIGITAL_LED_ST_OUT,DIGITAL_OFF);
               Limit_ClearLimitState(LIMIT_HANGINGLIMT_EXCEEDED | LIMIT_ALARMLIMIT_EXCEEDED);

            /*~-1*/
            }
            /*~E:I39*/
            /*~I:40*/
#ifndef OHNE_STROMRUECKFUEHRUNG 
            /*~T*/
            // R�ckkopplung
            CurrentInterface_FeedBack(); 
            /*~-1*/
#endif
            /*~E:I40*/
            /*~T*/
            g_CurrentInterface.byLastConversionState = g_CurrentInterface.byConversionState;
         /*~-1*/
         }
         /*~O:I34*/
         /*~-2*/
         else
         {
            /*~T*/
            lValue2Convert = g_CurrentInterface.DAC.lRatedDACOutput;
            /*~T*/
            g_CurrentInterface.byConversionState = ADuC836_DACConvert(&lValue2Convert,0);
         /*~-1*/
         }
         /*~E:I34*/
         /*~E:A33*/
      /*~-1*/
      }
      /*~O:I28*/
      /*~-2*/
      else
      {
         /*~T*/
         // System-Fehler - Stromausgang l�schen

         ADuC836_DACClearOutput(1);
         /*~I:41*/
#ifndef OHNE_STROMRUECKFUEHRUNG
         /*~T*/
         // R�ckkopplung
         CurrentInterface_FeedBack(); 
         /*~-1*/
#endif
         /*~E:I41*/
      /*~-1*/
      }
      /*~E:I28*/
   /*~-1*/
   }
   /*~E:I13*/
/*~-1*/
}
/*~E:F7*/
/*~E:A6*/
/*~A:42*/
/*~+:char 			CurrentInterface_Calibration(unsigned char chWhat2Do,float fTrueValue)*/
/*~F:43*/
char CurrentInterface_Calibration(unsigned char chWhat2Do,float fTrueValue)
/*~-1*/
{
   /*~A:44*/
   /*~+:Beschreibung*/
   /*~T*/
   /*!
   \fn void CurrentInterface_Calibration(unsigned char chWhat2Do,float fTrueValue, float fDesiredValue)
   
   <b>Beschreibung:</b><br>
   Kalibrierung/Normierung der Stromschnittstelle. Diese l�uft in der Regel in mehreren Schritten ab. Zun�chst werden zwei Punkte angefahren und bei dem Aufruf dieser Funktion jeweils Ist- und Sollwert des Stromausgangs �bergeben. Anschlie�end wird diese Funktion mit der Aufforderung zur Berechnung der Kalibrier-/Normierwerte aufgerufen.
   
   \param
   chWhat2Do: 
   \param
   CURRENTINTERFACE_SETPOINT_0 bzw. 0 = Setzen des Ist- und Sollwertes am ersten Kalibrierpunkt.
   \param
   CURRENTINTERFACE_SETPOINT_1 bzw. 1 = Setzen des Ist- und Sollwertes am zweiten Kalibrierpunkt. 
   \param
   CURRENTINTERFACE_CALIBRATE bzw.2 = Berechnung der Kalibrier-/Normierwerte.
   \param
   \param
   fTrueValue: Istwert
   
   \param
   fDesiredValue: Sollwert
   
   \retval
   0: Alles okay.
   \retval
   2: ertser Wert wurde noch nicht erfasst.
   
   <b>Zugriff:</b><br>
   [X] �ffentlich / [ ] Privat
   */

   /*~E:A44*/
   /*~A:45*/
   /*~+:Variablendeklarationen*/
   /*~I:46*/
#ifndef OHNE_STROMRUECKFUEHRUNG 
   /*~T*/
   float fGain;
   float fOffset;
   /*~-1*/
#endif
   /*~E:I46*/
   /*~E:A45*/
   /*~A:47*/
   /*~+:Variableninitialisierungen*/
   /*~T*/

   /*~E:A47*/
   /*~I:48*/
   if (!chWhat2Do)
   /*~-1*/
   {
      /*~T*/
      // 4mA
      ADuC836_DACCalibrationSetPoint(chWhat2Do,fTrueValue,4);
   /*~-1*/
   }
   /*~O:I48*/
   /*~-2*/
   else
   {
      /*~T*/
      // 20mA
      ADuC836_DACCalibrationSetPoint(chWhat2Do,fTrueValue,20);
   /*~-1*/
   }
   /*~E:I48*/
   /*~I:49*/
   // R�ckkoplung-Kalibrierpunkte setzen
   if (!chWhat2Do)
   /*~-1*/
   {
      /*~T*/
      g_CurrentInterface.lCalPointFeedBack_RMW[0] = g_CurrentInterface.FeedBack.Results.FilteredMeasurementFromADC.nLong;

      g_CurrentInterface.fCalPointFeedBack_Actual[0] = fTrueValue;
   /*~-1*/
   }
   /*~O:I49*/
   /*~-2*/
   else
   {
      /*~I:50*/
#ifndef OHNE_STROMRUECKFUEHRUNG
      /*~T*/
      g_CurrentInterface.lCalPointFeedBack_RMW[1] = g_CurrentInterface.FeedBack.Results.FilteredMeasurementFromADC.nLong;

      g_CurrentInterface.fCalPointFeedBack_Actual[1] = fTrueValue;
      /*~I:51*/
      if (g_CurrentInterface.lCalPointFeedBack_RMW[0] == 0x80000000)
      /*~-1*/
      {
         /*~T*/
         // ertser Wert wurde noch nicht erfasst
         return 2;
      /*~-1*/
      }
      /*~O:I51*/
      /*~-2*/
      else
      {
         /*~T*/
         // Verst�rkung und Offset berechnen

         fGain = (g_CurrentInterface.lCalPointFeedBack_RMW[1] - g_CurrentInterface.lCalPointFeedBack_RMW[0]) / (g_CurrentInterface.fCalPointFeedBack_Actual[1] - g_CurrentInterface.fCalPointFeedBack_Actual[0]);

         fOffset = g_CurrentInterface.lCalPointFeedBack_RMW[1] - fGain * g_CurrentInterface.fCalPointFeedBack_Actual[1];

         /*~T*/
         // Verst�rkung setzen
         CurrentInterface_SetCalibrationFactorOfFeedBack(1/fGain);

         // neuen Nullpunkt setzen
         CurrentInterface_SetZeroOfFeedBack((long)fOffset);
      /*~-1*/
      }
      /*~E:I51*/
      /*~-1*/
#endif
      /*~E:I50*/
   /*~-1*/
   }
   /*~E:I49*/
   /*~T*/
   return 0;
/*~-1*/
}
/*~E:F43*/
/*~E:A42*/
/*~K*/
/*~+:/~* Hinzugef�gt am 09.02.2022 *~/*/
/*~A:52*/
/*~+:unsigned char 		CurrentInterface_EvaluateDeviation(unsigned char bCurrentOn, float fDeviation, unsigned char *pbyDisableFeedbackCounter)*/
/*~F:53*/
/*#LJ:CurrentInterface_EvaluateDeviation=15*/
unsigned char CurrentInterface_EvaluateDeviation(unsigned char bCurrentOn, float fDeviation, unsigned char *pbyDisableFeedbackCounter)
/*~-1*/
{
   /*~A:54*/
   /*~+:Beschreibung*/
   /*~T*/
   /*!
   \fn unsigned char CurrentInterface_EvaluateDeviation(unsigned char bCurrentOn, float fDeviation, unsigned char *pbyDisableFeedbackCounter)
   
   <b>Beschreibung:</b><br>
   Diese Funktion wertet die Ist-/Sollstrom-Abweichung aus und schaltet bei mehrfacher Grenzwert�berschreitung in den Sicherheitszustand.
   
   \param
   bCurrentOn: Es flie�t ein Ausgangsstrom von �ber 1.5mA
   \param
   fDeviation: Ermittelte Stromabweichung in mA.
   \param
   pbyDisableFeedbackCounter: Zeiger auf den Feedback-Sperr-Z�hler
   
   \return
   Status: 0: B�rde abgeklemmt, 1: B�rde angeklemmt, 2: Mehrfache Stromabweichung erkannt 
   
   <b>Zugriff:</b><br>
   [X] �ffentlich / [ ] Privat
   */

   /*~E:A54*/
   /*~A:55*/
   /*~+:Variablendeklarationen*/
   /*~T*/
   static char chDeviationSign = 0;			// Vorzeichen der Stromabweichung
   unsigned char byRetVal;
   /*~E:A55*/
   /*~A:56*/
   /*~+:Variableninitialisierungen*/
   /*~T*/
   byRetVal = 1;	//
   /*~E:A56*/
   /*~I:57*/
   if (bCurrentOn != 0) // Strom flie�t - B�rde angeschlossen
   /*~-1*/
   {
      /*~A:58*/
      /*~+:Ber�cksichtige das Vorzeichen bei der Untersuchung der Stromabweichung*/
      /*~I:59*/
      if (fDeviation > g_CurrentInterface.FeedBack.fMaxDeviation)
      /*~-1*/
      {
         /*~T*/
         /* Positive Stromabweichung �ber Grenzwert erkannt */
         /*~I:60*/
         if (chDeviationSign <= 0 )
         /*~-1*/
         {
            /*~T*/
            /* Die letzte Stromabweichung war negativ oder es wurde zuvor noch keine ausgewertet (=0) */
            /*~T*/
            // Vorzeichen der Stromabweichung setzen
            chDeviationSign = 1;
            /* Stromabweichungsz�hler initialisieren */
            g_CurrentInterface.FeedBack.byMaxDeviationCounter = SYSTEMCND_CURRENT_DEVIATION_COUNTER_LIMIT - 1;
         /*~-1*/
         }
         /*~E:I60*/
         /*~I:61*/
         if (g_CurrentInterface.FeedBack.byMaxDeviationCounter == 0)
         /*~-1*/
         {
            /*~A:62*/
            /*~+:Stromabweichung lag mehrmals �ber dem Grenzwert*/
            /*~T*/
            /* Stromabweichung lag mehrmals �ber dem Grenzwert */
            /*~T*/
            // Sicherheitsfunktion aufrufen
            Diagnosis_SecurityCurrentInterface(CURRENT_DEVIATION);
            /*~T*/
            // Korrekturwert auf 0 setzen
            ADuC836_DACSetCurrentDeviation(0);
            /*~T*/
            // Flag f�r neue ermittelte R�ckkoppelspannung l�schen
            g_CurrentInterface.FeedBack.Results.byNewMeasurement = 0;
            /*~E:A62*/
            /*~T*/
            // Mehrfache Stromabweichung erkannt
            byRetVal = 2;
         /*~-1*/
         }
         /*~O:I61*/
         /*~-2*/
         else
         {
            /*~T*/
            /* Z�hler der Stromabweichungs-Erkennung dekrementieren */
            g_CurrentInterface.FeedBack.byMaxDeviationCounter--;
         /*~-1*/
         }
         /*~E:I61*/
      /*~-1*/
      }
      /*~O:I59*/
      /*~-2*/
      else
      {
         /*~I:63*/
         if (-fDeviation > g_CurrentInterface.FeedBack.fMaxDeviation)
         /*~-1*/
         {
            /*~T*/
            /* Negative Stromabweichung �ber Grenzwert erkannt */
            /*~I:64*/
            if (chDeviationSign >= 0 )
            /*~-1*/
            {
               /*~T*/
               /* Die letzte Stromabweichung war positiv oder es wurde zuvor noch keine ausgewertet (=0) */
               /*~T*/
               // Vorzeichen der Stromabweichung setzen
               chDeviationSign = -1;
               /* Stromabweichungsz�hler initialisieren */
               g_CurrentInterface.FeedBack.byMaxDeviationCounter = SYSTEMCND_CURRENT_DEVIATION_COUNTER_LIMIT - 1;
            /*~-1*/
            }
            /*~E:I64*/
            /*~I:65*/
            if (g_CurrentInterface.FeedBack.byMaxDeviationCounter == 0)
            /*~-1*/
            {
               /*~A:66*/
               /*~+:Stromabweichung lag mehrmals �ber dem Grenzwert*/
               /*~T*/
               /* Stromabweichung lag mehrmals �ber dem Grenzwert */
               /*~T*/
               // Sicherheitsfunktion aufrufen
               Diagnosis_SecurityCurrentInterface(CURRENT_DEVIATION);
               /*~T*/
               // Korrekturwert auf 0 setzen
               ADuC836_DACSetCurrentDeviation(0);
               /*~T*/
               // Flag f�r neue ermittelte R�ckkoppelspannung l�schen
               g_CurrentInterface.FeedBack.Results.byNewMeasurement = 0;
               /*~E:A66*/
               /*~T*/
               // Mehrfache Stromabweichung erkannt
               byRetVal = 2;
            /*~-1*/
            }
            /*~O:I65*/
            /*~-2*/
            else
            {
               /*~T*/
               /* Z�hler der Stromabweichungs-Erkennung dekrementieren */
               g_CurrentInterface.FeedBack.byMaxDeviationCounter--;
            /*~-1*/
            }
            /*~E:I65*/
         /*~-1*/
         }
         /*~O:I63*/
         /*~-2*/
         else
         {
            /*~T*/
            /* Keine Stromabweichung �ber Grenzwert erkannt - Stromabweichungsz�hler initialisieren */
            /*~T*/
            g_CurrentInterface.FeedBack.byMaxDeviationCounter = SYSTEMCND_CURRENT_DEVIATION_COUNTER_LIMIT - 1;
         /*~-1*/
         }
         /*~E:I63*/
      /*~-1*/
      }
      /*~E:I59*/
      /*~E:A58*/
   /*~-1*/
   }
   /*~O:I57*/
   /*~-2*/
   else
   {
      /*~T*/
      /* Z�hler der Stromabweichungs-Erkennung setzen - Da die B�rde abgeklemmt war, einen Leerdurchlauf der R�ckkopplung initieren */

      /*~T*/
      g_CurrentInterface.FeedBack.byMaxDeviationCounter = SYSTEMCND_CURRENT_DEVIATION_COUNTER_LIMIT - 1;

      *pbyDisableFeedbackCounter = 1;
      /*~T*/
      byRetVal = 0;
   /*~-1*/
   }
   /*~E:I57*/
   /*~T*/
   return(byRetVal);
/*~-1*/
}
/*~E:F53*/
/*~E:A52*/
/*~K*/
/*~+:/~* Ende - Hinzugef�gt am 09.02.2022 *~/*/
/*~A:67*/
/*~+:void 			CurrentInterface_FeedBack(void)*/
/*~F:68*/
void CurrentInterface_FeedBack(void)
/*~-1*/
{
   /*~A:69*/
   /*~+:Variablendeklarationen*/
   /*~T*/
   float fRated;
   float fDeviation;
   long lValue2Convert;
   MEASUREMENT_VALUE ActualRMW_Current;
   /*~E:A69*/
   /*~A:70*/
   /*~+:Variableninitialisierungen*/
   /*~T*/

   /*~E:A70*/
   /*~I:71*/
   // Liegt ein neuer gewandelter Rohmesswert vor ?
   if (ADuC836_ADCIsNewConversionValue(ADuC836_ADC_PRIMARY_TOGGLE))
   /*~-1*/
   {
      /*~A:72*/
      /*~+:R�ckkopplung des Stromausgangs auswerten*/
      /*~T*/
      // R�ckkopplung des Stromausgangs
      /*~T*/
      // Roh-Messwert vom ADC holen
      ActualRMW_Current.nLong = ADuC836_ADCGetConversionValue(ADuC836_ADC_PRIMARY_TOGGLE,0);
      /*~T*/
      // Communication_SendLong(COMMUNICATION_RS232,TEXT_CURRENT_INTERFACE_ACTUAL_CURRENT_CHANNEL_0,ActualRMW_Current.nLong,1,0);
      /*~T*/
      g_CurrentInterface.FeedBack.Results.FilteredMeasurementFromADC = ActualRMW_Current;

      // Nullpunktverrechnung
      Measurement_Processing(MEASUREMENT_PROCESSING_ZERO,CURRENTINTERFACE_FEEDBACKCHANEL,&ActualRMW_Current);
      //            g_CurrentInterface.FeedBack.Results.ZeroCorrectedMeasurement = Measurement;

      // Normierung
      Measurement_Processing(MEASUREMENT_PROCESSING_STANDARDIZATION,CURRENTINTERFACE_FEEDBACKCHANEL,&ActualRMW_Current);
      /*~A:73*/
      /*~+:ggf. Ist-Sollwert-Abweichung simulieren */
      /*~I:74*/
#ifdef MIT_STROM_ABWEICHUNGSSIMULATION
      /*~T*/
      ActualRMW_Current.fFloat+= g_CurrentInterface.FeedBack.fSimulatedDerivation;
      /*~-1*/
#endif
      /*~E:I74*/
      /*~E:A73*/
      /*~T*/
      g_CurrentInterface.FeedBack.Results.CalibratedMeasurement.fFloat = ActualRMW_Current.fFloat;

      // Motion-�berpr�fung
      Measurement_Processing(MEASUREMENT_PROCESSING_MOTION,CURRENTINTERFACE_FEEDBACKCHANEL,&ActualRMW_Current);

      // Flag f�r neuen Messwert setzen
      g_CurrentInterface.FeedBack.Results.byNewMeasurement = 1;

      /*~E:A72*/
      /*~F:75*/
      // neu hinzu
      /*~-1*/
      {
         /*~I:76*/
         if (!byDisableFeedbackCounter)
         /*~-1*/
         {
            /*~I:77*/
            if (!(Limit_GetLimitState() & LIMIT_ALARMLIMIT_EXCEEDED)&& (SYSTEMSTATE != SYSTEM_ERROR) && (SYSTEMSTATE_PARTNER != SYSTEM_ERROR)/* && (SYSTEMSTATE != SYSTEM_ERROR_CURRENT_DEVIATION)*/)
            /*~-1*/
            {
               /*~T*/
               // Sollwert auslesen
               fRated = ADuC836_DACGetLastConvertedCurrent(); 
               /*~T*/
               // Abweichung = Sollwert - Istwert;
               g_CurrentInterface.FeedBack.Results.Deviation.fFloat = fDeviation = fRated - ActualRMW_Current.fFloat;
               /*~I:78*/
               if (ADuC836_DACGetCurrentDeviationCorrectionState())
               /*~-1*/
               {
                  /*~T*/
                  // Stromr�ckf�hrung ist eingeschaltet
                  /*~K*/
                  /*~+:/~* Ge�ndert am 09.02.2022 *~/*/
                  /*~C:79*/
                  switch (CurrentInterface_EvaluateDeviation((ActualRMW_Current.fFloat > 1.0), fDeviation, &byDisableFeedbackCounter))
                  /*~-1*/
                  {
                     /*~F:80*/
                     case 0:	// B�rde abgeklemmt
                     /*~-1*/
                     {
                        /*~T*/
                        ADuC836_DACClearCurrentDeviation();	/* Den im DAC-Modul abgelegten Offset l�schen und neu setzen, sobald eine B�rde angeklemmt und die Stromabweichung kleiner 5mA ist. */
                        /*~T*/
                        break;
                     /*~-1*/
                     }
                     /*~E:F80*/
                     /*~F:81*/
                     case 1:	// B�rde angeklemmt - keine mehrfache Stromabweichung erkannt
                     /*~-1*/
                     {
                        /*~T*/
                        /* Die nachfolgende Abfrage wurde notwendig, um nicht beim Ab- und Anklemmen der B�rde in den Sicherheitszustand zu gelangen. Ist die B�rde abgeklemmt, liefert das Stellglied die maximalste Spannung und beim erneuten Anklemmen wird dadurch ein Iststrom ermittelt, welcher weit weg vom Sollstrom liegt. Der Software-Regler korrigiert diese gro�e Abweichung nach. Zus�tzlich wird auch das Stellglied nachregeln. Beide Ma�nahmen haben eine �berkompensation zur Folge und bewirken, dass die Stromabweichung innerhalb der geforderten Zeit von 3s nicht ausgeregelt werden kann. Darum ist es sinnvoll, erst bei einer Stromabweichung von z.Z. kleiner 5mA den Softwareregler zu aktivieren. Dar�ber arbeitet nur das Hardware-Stellglied. */
                        /*~I:82*/
                        if (fabs(fDeviation) < SYSTEMCND_CURRENT_DEVIATION_DISABLE_FEEDBACK)
                        /*~-1*/
                        {
                           /*~T*/
                           /* Die Stromabweichung ist kleiner SYSTEMCND_CURRENT_DEVIATION_DISABLE_FEEDBACK (z.Z. 5mA). Jetzt kommt der Software-Regler zum Einsatz. */ 
                           /*~I:83*/
#ifdef MIT_VARIABLEM_I_ANTEIL
                           /*~T*/
                           // Regelgr��e bestimmen
                           fIntegralPortion = g_CurrentInterface.FeedBack.chIntegralPortion;

                           fDeviation *= (fIntegralPortion * 0.01);
                           /*~O:I83*/
                           /*~-1*/
#else
                           /*~T*/
                           // 50% - I-Anteil
                           fDeviation *= 0.5;
                           /*~-1*/
#endif
                           /*~E:I83*/
                           /*~T*/
                           // Regelabweichung setzen
                           ADuC836_DACSetCurrentDeviation(fDeviation);

                           /*~T*/
                           // Analog-Ausgang aktualisieren
                           lValue2Convert = g_CurrentInterface.DAC.lRatedDACOutput;
                           ADuC836_DACConvert(&lValue2Convert,0);
                        /*~-1*/
                        }
                        /*~O:I82*/
                        /*~-2*/
                        else
                        {
                           /*~T*/
                           /* Die Stromabweichung ist gr��er oder gleich SYSTEMCND_CURRENT_DEVIATION_DISABLE_FEEDBACK (z.Z. 5mA). Jetzt kommt kommt nur das (Hardware-) Stellglied zum Einsatz. */ 
                           /*~T*/
                           ADuC836_DACClearCurrentDeviation(); /* Den im DAC-Modul abgelegten Offset l�schen und mit dem n�chsten Durchlauf des Softwarereglers (Stromabweichung < 5mA) neu setzen. */
                        /*~-1*/
                        }
                        /*~E:I82*/
                        /*~T*/
                        break;
                     /*~-1*/
                     }
                     /*~E:F81*/
                     /*~O:C79*/
                     /*~-2*/
                     default:
                     {
                        /*~T*/
                        /* Mehrfache Stromabweichung erkannt */

                        return;
                     /*~-1*/
                     }
                  /*~-1*/
                  }
                  /*~E:C79*/
                  /*~K*/
                  /*~+:/~* Ende - Ge�ndert am 09.02.2022 *~/*/
               /*~-1*/
               }
               /*~E:I78*/
            /*~-1*/
            }
            /*~O:I77*/
            /*~-2*/
            else
            {
               /*~T*/
               g_CurrentInterface.FeedBack.Results.CalibratedMeasurement.fFloat = 0;
            /*~-1*/
            }
            /*~E:I77*/
         /*~-1*/
         }
         /*~O:I76*/
         /*~-2*/
         else
         {
            /*~T*/
            byDisableFeedbackCounter--;
         /*~-1*/
         }
         /*~E:I76*/
         /*~T*/
         // Flag f�r neue ermittelte R�ckkoppelspannung l�schen
         g_CurrentInterface.FeedBack.Results.byNewMeasurement = 0;
      /*~-1*/
      }
      /*~E:F75*/
   /*~-1*/
   }
   /*~E:I71*/
/*~-1*/
}
/*~E:F68*/
/*~E:A67*/
/*~A:84*/
/*~+:float 			CurrentInterface_GetCurrent(unsigned char byMode)*/
/*~F:85*/
float CurrentInterface_GetCurrent(unsigned char byMode)
/*~-1*/
{
   /*~T*/
   // return ADuC836_ADCGetConversionValue(ADuC836_ADC_AUXILIARY_TOGGLE,1);

   /*~I:86*/
   if (byMode)
   /*~-1*/
   {
      /*~T*/
      return g_CurrentInterface.FeedBack.Results.CalibratedMeasurement.fFloat; 
   /*~-1*/
   }
   /*~O:I86*/
   /*~-2*/
   else
   {
      /*~T*/
      return ADuC836_DACGetLastConvertedCurrent();
   /*~-1*/
   }
   /*~E:I86*/
/*~-1*/
}
/*~E:F85*/
/*~E:A84*/
/*~A:87*/
/*~+:char 			CurrentInterface_GetFeedBackIntegralPortion(void)*/
/*~F:88*/
char CurrentInterface_GetFeedBackIntegralPortion(void)
/*~-1*/
{
   /*~T*/
   return g_CurrentInterface.FeedBack.chIntegralPortion;
/*~-1*/
}
/*~E:F88*/
/*~E:A87*/
/*~A:89*/
/*~+:char 			CurrentInterface_GetFeedBackProportionalPortion(void)*/
/*~F:90*/
char CurrentInterface_GetFeedBackProportionalPortion(void)
/*~-1*/
{
   /*~T*/
   return g_CurrentInterface.FeedBack.chProportionalPortion;
/*~-1*/
}
/*~E:F90*/
/*~E:A89*/
/*~A:91*/
/*~+:char 			CurrentInterface_GetFeedBackState(void)*/
/*~F:92*/
char CurrentInterface_GetFeedBackState(void)
/*~-1*/
{
   /*~T*/
   return ADuC836_DACGetCurrentDeviationCorrectionState();
/*~-1*/
}
/*~E:F92*/
/*~E:A91*/
/*~A:93*/
/*~+:unsigned int 		CurrentInterface_GetTimeHysteresis(void)*/
/*~F:94*/
unsigned int CurrentInterface_GetTimeHysteresis(void)
/*~-1*/
{
   /*~T*/
   return ADuC836_DACGetLimitHysteresis(ADUC836_DAC_UPPER_LIMIT) / CURRENTINTERFACE_TIMETICS2SEC;
/*~-1*/
}
/*~E:F94*/
/*~E:A93*/
/*~A:95*/
/*~+:char 			CurrentInterface_Ini(unsigned char byMode)*/
/*~F:96*/
char CurrentInterface_Ini(unsigned char byMode)
/*~-1*/
{
   /*~A:97*/
   /*~+:Beschreibung*/
   /*~T*/
   /*!
   \fn void CurrentInterface_Ini(unsigned char byMode)
   
   <b>Beschreibung:</b><br>
   Initialisierung der Stromschnittstelle.
   
   \param
   byMode:
   \param
   0 = Initialisierung der Stromschnittstelle mit Defaultwerten.
   \param
   1 = Initialisierung mit den abgespeicherten Werten.  
   \param
   2 = Initialisierung der Stromschnittstelle mit Defaultwerten.Diese werden zus�tzlich abgespeichert und stehen auch beim n�chsten Systemstart zur Verf�gung.
   
   \return
   ./.
   
   <b>Zugriff:</b><br>
   [X] �ffentlich / [ ] Privat
   */
   /*~E:A97*/
   /*~A:98*/
   /*~+:Variablendeklarationen*/
   /*~T*/
   unsigned char 			chDACLimitStatus;
   /*~E:A98*/
   /*~A:99*/
   /*~+:Variableninitialisierungen*/
   /*~T*/
   g_CurrentInterface.lCalPointFeedBack_RMW[0] = 0x80000000L;

   g_CurrentInterface.FeedBack.fSimulatedDerivation = 0;
   g_CurrentInterface.byAdjustCurrentInterface = 0;

   g_CurrentInterface.byLastConversionState = 0;
   /*~E:A99*/
   /*~A:100*/
   /*~+:DAC initialsieren*/
   /*~T*/
   // DAC initialsieren
   ADuC836_DACIni(ADUC836_DAC_OUTPUTPIN_3,ADUC836_DAC_RESOLUTION_12BIT,ADUC836_DAC_RANGE_2_REF,ADUC836_DAC_ENABLE);
   /*~E:A100*/
   /*~C:101*/
   switch (byMode)
   /*~-1*/
   {
      /*~F:102*/
      case 0:		// Initialisierung mit Defaultwerten
      /*~-1*/
      {
         /*~T*/
         // Default-Offset und Default-Verst�runksfaktor setzen

         /*~I:103*/
#ifndef SPEZIALVERSION_FUER_TESTSYSTEME 
         /*~T*/
         ADuC836_DACSetOffset(0,700);
         /*~I:104*/
         if (g_SystemControl.byLoadCellType < 2)
         /*~-1*/
         {
            /*~T*/
            ADuC836_DACSetGain(0.3);

         /*~-1*/
         }
         /*~O:I104*/
         /*~-2*/
         else
         {
            /*~T*/
            ADuC836_DACSetGain(1.5);

         /*~-1*/
         }
         /*~E:I104*/
         /*~T*/
         // Grenzwert�berwachung
         ADuC836_DACEnableLimit(ADUC836_DAC_LOWER_LIMIT,0);
         ADuC836_DACEnableLimit(ADUC836_DAC_UPPER_LIMIT,0);
         chDACLimitStatus = ADuC836_DACGetLimitState(255);

         // Kalibrierpunkte l�schen
         ADuC836_DACCalibrationClearPoints();

         // Zeithysterese bei Grenzwert�berschreitung
         ADuC836_DACSetLimitHysteresis(ADUC836_DAC_LOWER_LIMIT,0);	// 0 Sekunden

         /*~T*/
         ADuC836_DACSetLimitHysteresis(ADUC836_DAC_UPPER_LIMIT,1);	// in 10ms, alter Wert 400
         /*~T*/
         // Stromr�ckkopplung ausschalten
         CurrentInterface_SetFeedBackOnOff(0,0);
         /*~T*/
         // Integralanteil der Stromregelung auf 50%
         CurrentInterface_SetFeedBackIntegralPortion(50);

         /*~T*/
         // Proportionalanteil der Stromregelung auf 50%
         CurrentInterface_SetFeedBackProportionalPortion(50);

         /*~T*/
         // DAC-Settings speichern
         CurrentInterface_SaveDACSettings(CURRENTINTERFACE_ALL_SETTINGS);
         /*~I:105*/
#ifndef OHNE_STROMRUECKFUEHRUNG
         /*~A:106*/
         /*~+:Parameter f�r R�ckkoppelzweig*/
         /*~T*/
         // Verst�rkung setzen
         CurrentInterface_SetCalibrationFactorOfFeedBack(0.000707);

         // neuen Nullpunkt setzen
         CurrentInterface_SetZeroOfFeedBack(0);


         /*~I:107*/
#ifdef MIT_UEBERWACHUNG_SOLL_ISTSTROM_ABWEICHUNG
         /*~T*/
         // maximal zul�ssige Soll-Istwert-Abweichung auf 2mA
         g_CurrentInterface.FeedBack.fMaxDeviation = 2;

         /*~O:I107*/
         /*~-1*/
#else
         /*~T*/
         // maximal zul�ssige Soll-Istwert-Abweichung auf 50mA (= Abschaltung)
         g_CurrentInterface.FeedBack.fMaxDeviation = 50;

         /*~-1*/
#endif
         /*~E:I107*/
         /*~T*/
         // und speichern
         CurrentInterface_SaveDACSettings(CURRENTINTERFACE_MAXDEVIATION_FEEDBACK);

         /*~E:A106*/
         /*~-1*/
#endif
         /*~E:I105*/
         /*~O:I103*/
         /*~-1*/
#else
         /*~A:108*/
         /*~+:Spezialsoftware f�r Testsysteme*/
         /*~T*/
         ADuC836_DACSetOffset(0,0);
         /*~T*/
         ADuC836_DACSetGain(0.175);

         /*~T*/
         // Grenzwert�berwachung
         ADuC836_DACEnableLimit(ADUC836_DAC_LOWER_LIMIT,0);
         ADuC836_DACEnableLimit(ADUC836_DAC_UPPER_LIMIT,0);
         chDACLimitStatus = ADuC836_DACGetLimitState(255);

         // Kalibrierpunkte l�schen
         ADuC836_DACCalibrationClearPoints();

         // Zeithysterese bei Grenzwert�berschreitung
         ADuC836_DACSetLimitHysteresis(ADUC836_DAC_LOWER_LIMIT,0);	// 0 Sekunden

         /*~T*/
         ADuC836_DACSetLimitHysteresis(ADUC836_DAC_UPPER_LIMIT,1);	// in 10ms, alter Wert 400
         /*~T*/
         // Stromr�ckkopplung ausschalten
         CurrentInterface_SetFeedBackOnOff(0,0);
         /*~T*/
         // Integralanteil der Stromregelung auf 50%
         CurrentInterface_SetFeedBackIntegralPortion(50);

         /*~T*/
         // DAC-Settings speichern
         CurrentInterface_SaveDACSettings(CURRENTINTERFACE_ALL_SETTINGS);
         /*~I:109*/
#ifndef OHNE_STROMRUECKFUEHRUNG
         /*~A:110*/
         /*~+:Parameter f�r R�ckkoppelzweig*/
         /*~T*/
         // Verst�rkung setzen
         CurrentInterface_SetCalibrationFactorOfFeedBack(0.000707);

         // neuen Nullpunkt setzen
         CurrentInterface_SetZeroOfFeedBack(0);


         /*~I:111*/
         /*#LJ:0=1*/
#ifdef MIT_UEBERWACHUNG_SOLL_ISTSTROM_ABWEICHUNG
         /*~T*/
         // maximal zul�ssige Soll-Istwert-Abweichung auf 2mA
         g_CurrentInterface.FeedBack.fMaxDeviation = 2;

         /*~O:I111*/
         /*~-1*/
#else
         /*~T*/
         // maximal zul�ssige Soll-Istwert-Abweichung auf 50mA (= Abschaltung)
         g_CurrentInterface.FeedBack.fMaxDeviation = 50;

         /*~-1*/
#endif
         /*~E:I111*/
         /*~T*/
         // und speichern
         CurrentInterface_SaveDACSettings(CURRENTINTERFACE_MAXDEVIATION_FEEDBACK);

         /*~E:A110*/
         /*~-1*/
#endif
         /*~E:I109*/
         /*~E:A108*/
         /*~-1*/
#endif
         /*~E:I103*/
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F102*/
      /*~F:112*/
      case 1:		// Initialisierung mit abgespeicherten Werten
      /*~-1*/
      {
         /*~T*/
         CurrentInterface_LoadDACSettings(CURRENTINTERFACE_ALL_SETTINGS);
         /*~I:113*/
#ifndef OHNE_STROMRUECKFUEHRUNG
         /*~A:114*/
         /*~+:Parameter f�r R�ckkoppelzweig*/
         /*~T*/
         // Messwertoffset setzen
         CurrentInterface_LoadDACSettings(CURRENTINTERFACE_OFFSET_FEEDBACK);
         // Messwert-Kalibrierwert setzen
         CurrentInterface_LoadDACSettings(CURRENTINTERFACE_GAIN_FEEDBACK);
         // maximal zul�ssige Soll-Istwert-Abweichung
         CurrentInterface_LoadDACSettings(CURRENTINTERFACE_MAXDEVIATION_FEEDBACK);
         // Integral-Anteil der Stromregelung
         CurrentInterface_LoadDACSettings(CURRENTINTERFACE_INTEGRALPORTION_FEEDBACK);
         // Integral-Anteil der Stromregelung
         CurrentInterface_LoadDACSettings(CURRENTINTERFACE_PROPORTIONALPORTION_FEEDBACK);
         /*~E:A114*/
         /*~-1*/
#endif
         /*~E:I113*/
         /*~T*/
         // Parameter zur R�ckrechnung des Gewichts vom Ausgangsstrom laden
         CurrentInterface_LoadDACSettings(CURRENTINTERFACE_WEIGHTCALCULATION);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F112*/
      /*~O:C101*/
      /*~-2*/
      default:
      {
         /*~T*/
         return 1;
      /*~-1*/
      }
   /*~-1*/
   }
   /*~E:C101*/
   /*~K*/
   /*~+:/~* Ge�ndert am 09.02.2022 *~/*/
   /*~T*/
   CurrentInterface_Ini_2(byMode);
   /*~K*/
   /*~+:/~* Ende - Ge�ndert am 09.02.2022 *~/*/
   /*~T*/
   return 0;
/*~-1*/
}
/*~E:F96*/
/*~E:A95*/
/*~K*/
/*~+:/~* Hinzugef�gt am 09.02.2022 *~/*/
/*~A:115*/
/*~+:void 			CurrentInterface_Ini_2(unsigned char byMode)*/
/*~F:116*/
/*#LJ:CurrentInterface_Ini_2=6*/
void CurrentInterface_Ini_2(unsigned char byMode)
/*~-1*/
{
   /*~A:117*/
   /*~+:Beschreibung*/
   /*~T*/
   /*!
   \fnvoid CurrentInterface_Ini_2(CURRENTINTERFACE_WHAT_TO_INIT What)
   
   <b>Beschreibung:</b><br>
   Zus�tzliche Initialisierung der Stromschnittstelle f�r V1.104
   
   \param
   byMode:
   \param
   0 = Initialisierung der Stromschnittstelle mit Defaultwerten.
   \param
   1 = Initialisierung mit den abgespeicherten Werten.  
   \param
   2 = Initialisierung der Stromschnittstelle mit Defaultwerten.Diese werden zus�tzlich abgespeichert und stehen auch beim n�chsten Systemstart zur Verf�gung.
   
   \return
   ./.
   
   <b>Zugriff:</b><br>
   [ ] �ffentlich / [X] Privat
   */
   /*~E:A117*/
   /*~A:118*/
   /*~+:Variablendeklarationen*/
   /*~T*/

   /*~E:A118*/
   /*~A:119*/
   /*~+:Variableninitialisierungen*/
   /*~T*/
   g_CurrentInterface.FeedBack.byMaxDeviationCounter = SYSTEMCND_CURRENT_DEVIATION_COUNTER_LIMIT - 1;

   /*~E:A119*/
   /*~A:120*/
   /*~+:Parameter f�r R�ckkoppelzweig*/
   /*~I:121*/
   /* Maximale Stromabweichung �ber den Verst�rkungsfaktor der Stromschnittstelle ermitteln */
   if (ADuC836_DACGetGain(0) < 0.48)
   /*~-1*/
   {
      /*~T*/
      /* 1000kg - Zelle */
      g_CurrentInterface.FeedBack.fMaxDeviation = SYSTEMCND_MAX_CURRENT_DEVIATION_1000KG;
   /*~-1*/
   }
   /*~O:I121*/
   /*~-2*/
   else
   {
      /*~T*/
      /* 500kg - Zelle */
      g_CurrentInterface.FeedBack.fMaxDeviation = SYSTEMCND_MAX_CURRENT_DEVIATION_500KG;
   /*~-1*/
   }
   /*~E:I121*/
   /*~E:A120*/
/*~-1*/
}
/*~E:F116*/
/*~E:A115*/
/*~K*/
/*~+:/~* Ende - Hinzugef�gt am 09.02.2022 *~/*/
/*~A:122*/
/*~+:void 			CurrentInterface_LoadDACSettings(unsigned char chWhat2Load)*/
/*~F:123*/
void CurrentInterface_LoadDACSettings(unsigned char chWhat2Load)
/*~-1*/
{
   /*~A:124*/
   /*~+:Beschreibung*/
   /*~T*/
   /*!
   \fn void CurrentInterface_LoadDACSettings(void)
   
   <b>Beschreibung:</b><br>
   Speicherung aller Stromschnittstellenparameter.
   
   \param
   void:
   
   \return
   ./.
   
   <b>Zugriff:</b><br>
   [X] �ffentlich / [ ] Privat
   */
   /*~E:A124*/
   /*~A:125*/
   /*~+:Variablendeklarationen*/
   /*~T*/
   typedef struct{
   	float fGain_RMV;
   	long lOffset_RMV;
   }COPY_CALIBRATION;

   COPY_CALIBRATION Copy_Calibration;
   /*~T*/
   DAC_SETTINGS DAC_Settings;
   /*~E:A125*/
   /*~A:126*/
   /*~+:Variableninitialisierungen*/
   /*~T*/

   /*~E:A126*/
   /*~C:127*/
   switch (chWhat2Load)
   /*~-1*/
   {
      /*~A:128*/
      /*~+:CURRENTINTERFACE_RMW_1ST_REFPOINT (nicht hinter CURRENTINTERFACE_ALL_SETTINGS einreihen)*/
      /*~F:129*/
      case CURRENTINTERFACE_RMW_1ST_REFPOINT:
      /*~-1*/
      {
         /*~T*/
         Load_Parameter(LOAD_SAVE_DAC_RMW_1ST_REFPOINT,&g_CurrentInterface.lRMWForCalibration[0],4);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F129*/
      /*~E:A128*/
      /*~A:130*/
      /*~+:CURRENTINTERFACE_RMW_2ND_REFPOINT (nicht hinter CURRENTINTERFACE_ALL_SETTINGS einreihen)*/
      /*~F:131*/
      case CURRENTINTERFACE_RMW_2ND_REFPOINT:
      /*~-1*/
      {
         /*~T*/
         Load_Parameter(LOAD_SAVE_DAC_RMW_2ND_REFPOINT,&g_CurrentInterface.lRMWForCalibration[1],4);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F131*/
      /*~E:A130*/
      /*~K*/
      /*~+:*/
      /*~A:132*/
      /*~+:CURRENTINTERFACE_ALL_SETTINGS*/
      /*~F:133*/
      case CURRENTINTERFACE_ALL_SETTINGS:
      /*~-1*/
      {
         /*~T*/
         Load_Parameter(LOAD_SAVE_DAC_SETTINGS,&DAC_Settings,0);

         // DAC-Einstellungen auslesen
         ADuC836_DACLoadSettings(DAC_Settings);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F133*/
      /*~E:A132*/
      /*~A:134*/
      /*~+:CURRENTINTERFACE_CALIBRATION_BACKUP*/
      /*~F:135*/
      case CURRENTINTERFACE_CALIBRATION_BACKUP:
      /*~-1*/
      {
         /*~T*/
         Load_Parameter(LOAD_SAVE_DAC_COPY_CALIBRATION,&Copy_Calibration,8);

         ADuC836_DACSetGain(Copy_Calibration.fGain_RMV);
         ADuC836_DACSetOffset(0,Copy_Calibration.lOffset_RMV);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F135*/
      /*~E:A134*/
      /*~A:136*/
      /*~+:CURRENTINTERFACE_GAIN_FEEDBACK*/
      /*~F:137*/
      case CURRENTINTERFACE_GAIN_FEEDBACK:
      /*~-1*/
      {
         /*~A:138*/
         /*~+:Variablendeklarationen*/
         /*~T*/
         float fGain;
         /*~E:A138*/
         /*~A:139*/
         /*~+:Variableninitialisierungen*/
         /*~T*/

         /*~E:A139*/
         /*~T*/
         // Nullpunkt auslesen
         Load_Parameter(LOAD_SAVE_DAC_GAIN_FEEDBACK,&fGain,4);
         /*~T*/
         // und setzen
         Measurement_SetCalibrationFactor(CURRENTINTERFACE_FEEDBACKCHANEL,fGain);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F137*/
      /*~E:A136*/
      /*~A:140*/
      /*~+:CURRENTINTERFACE_INTEGRALPORTION_FEEDBACK*/
      /*~F:141*/
      case CURRENTINTERFACE_INTEGRALPORTION_FEEDBACK:
      /*~-1*/
      {
         /*~A:142*/
         /*~+:Variablendeklarationen*/
         /*~T*/
         char chPortion;
         /*~E:A142*/
         /*~A:143*/
         /*~+:Variableninitialisierungen*/
         /*~T*/

         /*~E:A143*/
         /*~T*/
         // Integralanteil der Stromregelung auslesen
         Load_Parameter(LOAD_SAVE_INTEGRALPORTION_FEEDBACK,&chPortion,1);
         /*~T*/
         // und setzen
         CurrentInterface_SetFeedBackIntegralPortion(chPortion);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F141*/
      /*~E:A140*/
      /*~A:144*/
      /*~+:CURRENTINTERFACE_OFFSET_FEEDBACK*/
      /*~F:145*/
      case CURRENTINTERFACE_OFFSET_FEEDBACK:
      /*~-1*/
      {
         /*~A:146*/
         /*~+:Variablendeklarationen*/
         /*~T*/
         MEASUREMENT_VALUE Zero;
         /*~E:A146*/
         /*~A:147*/
         /*~+:Variableninitialisierungen*/
         /*~T*/

         /*~E:A147*/
         /*~T*/
         // Nullpunkt auslesen
         Load_Parameter(LOAD_SAVE_DAC_OFFSET_FEEDBACK,&Zero,4);
         /*~T*/
         // und setzen
         Measurement_SetZeroValue(CURRENTINTERFACE_FEEDBACKCHANEL,&Zero);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F145*/
      /*~E:A144*/
      /*~A:148*/
      /*~+:CURRENTINTERFACE_MAXDEVIATION_FEEDBACK*/
      /*~F:149*/
      case CURRENTINTERFACE_MAXDEVIATION_FEEDBACK:
      /*~-1*/
      {
         /*~T*/
         // maximal zul�ssige Soll-Istwert-Abweichung auslesen 
         Load_Parameter(LOAD_SAVE_CURRENTINTERFACE_MAXDEVIATION,&g_CurrentInterface.FeedBack.fMaxDeviation,4);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F149*/
      /*~E:A148*/
      /*~A:150*/
      /*~+:CURRENTINTERFACE_TIME_HYSTERESIS*/
      /*~F:151*/
      case CURRENTINTERFACE_TIME_HYSTERESIS:
      /*~-1*/
      {
         /*~A:152*/
         /*~+:Variablendeklarationen*/
         /*~T*/
         unsigned int uTimeHysteresis;
         /*~E:A152*/
         /*~A:153*/
         /*~+:Variableninitialisierungen*/
         /*~T*/

         /*~E:A153*/
         /*~T*/
         // Zeithysterese auslesen
         Load_Parameter(LOAD_SAVE_CURRENTINTERFACE_TIME_HYSTERESIS,&uTimeHysteresis,2);
         /*~T*/
         // und setzen
         ADuC836_DACSetLimitHysteresis(ADUC836_DAC_UPPER_LIMIT,uTimeHysteresis);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F151*/
      /*~E:A150*/
      /*~A:154*/
      /*~+:CURRENTINTERFACE_PROPORTIONALPORTION_FEEDBACK*/
      /*~F:155*/
      case CURRENTINTERFACE_PROPORTIONALPORTION_FEEDBACK:
      /*~-1*/
      {
         /*~A:156*/
         /*~+:Variablendeklarationen*/
         /*~T*/
         char chPortion;
         /*~E:A156*/
         /*~A:157*/
         /*~+:Variableninitialisierungen*/
         /*~T*/

         /*~E:A157*/
         /*~T*/
         // Integralanteil der Stromregelung auslesen
         Load_Parameter(LOAD_SAVE_PROPORTIONALPORTION_FEEDBACK,&chPortion,1);
         /*~T*/
         // und setzen
         CurrentInterface_SetFeedBackProportionalPortion(chPortion);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F155*/
      /*~E:A154*/
   /*~-1*/
   }
   /*~E:C127*/
/*~-1*/
}
/*~E:F123*/
/*~E:A122*/
/*~A:158*/
/*~+:void 			CurrentInterface_PrepareCalibration(unsigned char byCalPoint,float fWeight)*/
/*~F:159*/
void CurrentInterface_PrepareCalibration(unsigned char byCalPoint,float fWeight)
/*~-1*/
{
   /*~A:160*/
   /*~+:Variablendeklarationen*/
   /*~T*/
   float fCalibrationFactor;
   /*~E:A160*/
   /*~A:161*/
   /*~+:Variableninitialisierungen*/
   /*~I:162*/
#ifndef SPEZIALVERSION_FUER_TESTSYSTEME
   /*~T*/
   Measurement_GetCalibrationFactor(WEIGHT_WEIGHTCHANNEL,&fCalibrationFactor);
   /*~O:I162*/
   /*~-1*/
#else
   /*~T*/
   fCalibrationFactor = 0.001;
   /*~-1*/
#endif
   /*~E:I162*/
   /*~E:A161*/
   /*~C:163*/
   switch (byCalPoint)
   /*~-1*/
   {
      /*~F:164*/
      case 1:		// 4mA-Kalibrierung
      /*~-1*/
      {
         /*~T*/
         g_CurrentInterface.byAdjustCurrentInterface = 1;
         g_CurrentInterface.lRMWForCalibration[0] = (long)(fWeight / fCalibrationFactor); 
         /*~T*/
         // und speichern
         CurrentInterface_SaveDACSettings(CURRENTINTERFACE_RMW_1ST_REFPOINT);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F164*/
      /*~F:165*/
      case 2:		// 20mA-Kalibrierung
      /*~-1*/
      {
         /*~T*/
         g_CurrentInterface.byAdjustCurrentInterface = 2;
         g_CurrentInterface.lRMWForCalibration[1] = (long)(fWeight / fCalibrationFactor); 
         /*~T*/
         // und speichern
         CurrentInterface_SaveDACSettings(CURRENTINTERFACE_RMW_2ND_REFPOINT);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F165*/
      /*~O:C163*/
      /*~-2*/
      default:
      {
         /*~T*/
         g_CurrentInterface.byAdjustCurrentInterface = 0;
      /*~-1*/
      }
   /*~-1*/
   }
   /*~E:C163*/
/*~-1*/
}
/*~E:F159*/
/*~E:A158*/
/*~A:166*/
/*~+:void 			CurrentInterface_SaveDACSettings(unsigned char chWhat2Save)*/
/*~F:167*/
void CurrentInterface_SaveDACSettings(unsigned char chWhat2Save)
/*~-1*/
{
   /*~A:168*/
   /*~+:Beschreibung*/
   /*~T*/
   /*!
   \fn void CurrentInterface_SaveDACSettings(unsigned char chWhat2Save)
   
   <b>Beschreibung:</b><br>
   Speicherung aller Stromschnittstellenparameter.
   
   \param
   chWhat2Save: Angabe �ber den Umfang der zu speichernden Daten (s.CURRENTINTERFACE_ALL_SETTINGS und CURRENTINTERFACE_CALIBRATION_BACKUP). 
   
   \return
   ./.
   
   <b>Zugriff:</b><br>
   [X] �ffentlich / [ ] Privat
   */
   /*~E:A168*/
   /*~A:169*/
   /*~+:Variablendeklarationen*/
   /*~T*/
   typedef struct{
   	float fGain_RMV;
   	long lOffset_RMV;
   }COPY_CALIBRATION;

   COPY_CALIBRATION Copy_Calibration;
   /*~T*/
   DAC_SETTINGS DAC_Settings;
   /*~E:A169*/
   /*~A:170*/
   /*~+:Variableninitialisierungen*/
   /*~T*/
   // DAC-Einstellungen auslesen
   DAC_Settings = ADuC836_DACSaveSettings();

   /*~E:A170*/
   /*~C:171*/
   switch (chWhat2Save)
   /*~-1*/
   {
      /*~A:172*/
      /*~+:CURRENTINTERFACE_RMW_1ST_REFPOINT (nicht hinter CURRENTINTERFACE_ALL_SETTINGS einreihen)*/
      /*~F:173*/
      case CURRENTINTERFACE_RMW_1ST_REFPOINT:
      /*~-1*/
      {
         /*~T*/
         // und speichern
         Save_Parameter(LOAD_SAVE_DAC_RMW_1ST_REFPOINT,&g_CurrentInterface.lRMWForCalibration[0],4);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F173*/
      /*~E:A172*/
      /*~A:174*/
      /*~+:CURRENTINTERFACE_RMW_2ND_REFPOINT (nicht hinter CURRENTINTERFACE_ALL_SETTINGS einreihen)*/
      /*~F:175*/
      case CURRENTINTERFACE_RMW_2ND_REFPOINT:
      /*~-1*/
      {
         /*~T*/
         // und speichern
         Save_Parameter(LOAD_SAVE_DAC_RMW_2ND_REFPOINT,&g_CurrentInterface.lRMWForCalibration[1],4);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F175*/
      /*~E:A174*/
      /*~K*/
      /*~+:*/
      /*~A:176*/
      /*~+:CURRENTINTERFACE_ALL_SETTINGS*/
      /*~F:177*/
      case CURRENTINTERFACE_ALL_SETTINGS:
      /*~-1*/
      {
         /*~T*/
         // alle Parameter speichern
         Save_Parameter(LOAD_SAVE_DAC_SETTINGS,&DAC_Settings,0);
      /*~-1*/
      }
      /*~E:F177*/
      /*~E:A176*/
      /*~A:178*/
      /*~+:CURRENTINTERFACE_GAIN_FEEDBACK (muss direkt hinter CURRENTINTERFACE_ALL_SETTINGS stehen !!!)*/
      /*~F:179*/
      case CURRENTINTERFACE_GAIN_FEEDBACK:
      /*~-1*/
      {
         /*~A:180*/
         /*~+:Variablendeklarationen*/
         /*~T*/
         float fGain;
         /*~E:A180*/
         /*~A:181*/
         /*~+:Variableninitialisierungen*/
         /*~T*/

         /*~E:A181*/
         /*~T*/
         // Kalibrierfaktor auslesen
         Measurement_GetCalibrationFactor(CURRENTINTERFACE_FEEDBACKCHANEL,&fGain);
         /*~T*/
         // und speichern
         Save_Parameter(LOAD_SAVE_DAC_GAIN_FEEDBACK,&fGain,4);
         /*~I:182*/
         if (chWhat2Save != CURRENTINTERFACE_ALL_SETTINGS)
         /*~-1*/
         {
            /*~T*/
            break;
         /*~-1*/
         }
         /*~E:I182*/
      /*~-1*/
      }
      /*~E:F179*/
      /*~E:A178*/
      /*~A:183*/
      /*~+:CURRENTINTERFACE_OFFSET_FEEDBACK (muss direkt hinter CURRENTINTERFACE_GAIN_FEEDBACK stehen !!!)*/
      /*~F:184*/
      case CURRENTINTERFACE_OFFSET_FEEDBACK:
      /*~-1*/
      {
         /*~A:185*/
         /*~+:Variablendeklarationen*/
         /*~T*/
         MEASUREMENT_VALUE Zero;
         /*~E:A185*/
         /*~A:186*/
         /*~+:Variableninitialisierungen*/
         /*~T*/

         /*~E:A186*/
         /*~T*/
         // Nullpunkt auslesen
         Measurement_GetZero(CURRENTINTERFACE_FEEDBACKCHANEL,&Zero);
         /*~T*/
         // und speichern
         Save_Parameter(LOAD_SAVE_DAC_OFFSET_FEEDBACK,&Zero,4);
         /*~I:187*/
         if (chWhat2Save != CURRENTINTERFACE_ALL_SETTINGS)
         /*~-1*/
         {
            /*~T*/
            break;
         /*~-1*/
         }
         /*~E:I187*/
      /*~-1*/
      }
      /*~E:F184*/
      /*~E:A183*/
      /*~A:188*/
      /*~+:CURRENTINTERFACE_INTEGRALPORTION_FEEDBACK (muss direkt hinter CURRENTINTERFACE_OFFSET_FEEDBACK !!!)*/
      /*~F:189*/
      case CURRENTINTERFACE_INTEGRALPORTION_FEEDBACK:
      /*~-1*/
      {
         /*~A:190*/
         /*~+:Variablendeklarationen*/
         /*~T*/
         char chPortion;
         /*~E:A190*/
         /*~A:191*/
         /*~+:Variableninitialisierungen*/
         /*~T*/

         /*~E:A191*/
         /*~T*/
         // Integral-Anteil der Stromregelung auslesen
         chPortion = CurrentInterface_GetFeedBackIntegralPortion();
         /*~T*/
         // und speichern
         Save_Parameter(LOAD_SAVE_INTEGRALPORTION_FEEDBACK,&chPortion,1);
         /*~I:192*/
         if (chWhat2Save != CURRENTINTERFACE_ALL_SETTINGS)
         /*~-1*/
         {
            /*~T*/
            break;
         /*~-1*/
         }
         /*~E:I192*/
      /*~-1*/
      }
      /*~E:F189*/
      /*~E:A188*/
      /*~A:193*/
      /*~+:CURRENTINTERFACE_PROPORTIONALPORTION_FEEDBACK (muss direkt hinter CURRENTINTERFACE_INTEGRALPORTION_FEEDBACK !!!)*/
      /*~F:194*/
      case CURRENTINTERFACE_PROPORTIONALPORTION_FEEDBACK:
      /*~-1*/
      {
         /*~A:195*/
         /*~+:Variablendeklarationen*/
         /*~T*/
         char chPortion;
         /*~E:A195*/
         /*~A:196*/
         /*~+:Variableninitialisierungen*/
         /*~T*/

         /*~E:A196*/
         /*~T*/
         // Integral-Anteil der Stromregelung auslesen
         chPortion = CurrentInterface_GetFeedBackProportionalPortion();
         /*~T*/
         // und speichern
         Save_Parameter(LOAD_SAVE_PROPORTIONALPORTION_FEEDBACK,&chPortion,1);
         /*~I:197*/
         if (chWhat2Save != CURRENTINTERFACE_ALL_SETTINGS)
         /*~-1*/
         {
            /*~T*/
            break;
         /*~-1*/
         }
         /*~E:I197*/
      /*~-1*/
      }
      /*~E:F194*/
      /*~E:A193*/
      /*~A:198*/
      /*~+:CURRENTINTERFACE_TIME_HYSTERESIS (muss direkt hinter CURRENTINTERFACE_INTEGRALPORTION_FEEDBACK !!!)*/
      /*~F:199*/
      case CURRENTINTERFACE_TIME_HYSTERESIS:
      /*~-1*/
      {
         /*~T*/
         // maximal zul�ssige Soll-Istwert-Abweichung speichern 
         Save_Parameter(LOAD_SAVE_CURRENTINTERFACE_TIME_HYSTERESIS,&DAC_Settings.Limits.uHysteresisUpperLimit,2);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F199*/
      /*~E:A198*/
      /*~A:200*/
      /*~+:CURRENTINTERFACE_CALIBRATION_BACKUP*/
      /*~F:201*/
      case CURRENTINTERFACE_CALIBRATION_BACKUP:
      /*~-1*/
      {
         /*~T*/
         Copy_Calibration.fGain_RMV = ADuC836_DACGetGain(0);
         Copy_Calibration.lOffset_RMV = ADuC836_DACGetOffset(0);

         Save_Parameter(LOAD_SAVE_DAC_COPY_CALIBRATION,&Copy_Calibration,8);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F201*/
      /*~E:A200*/
      /*~A:202*/
      /*~+:CURRENTINTERFACE_MAXDEVIATION_FEEDBACK*/
      /*~F:203*/
      case CURRENTINTERFACE_MAXDEVIATION_FEEDBACK:
      /*~-1*/
      {
         /*~T*/
         // maximal zul�ssige Soll-Istwert-Abweichung speichern 
         Save_Parameter(LOAD_SAVE_CURRENTINTERFACE_MAXDEVIATION,&g_CurrentInterface.FeedBack.fMaxDeviation,4);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F203*/
      /*~E:A202*/
   /*~-1*/
   }
   /*~E:C171*/
/*~-1*/
}
/*~E:F167*/
/*~E:A166*/
/*~A:204*/
/*~+:char 			CurrentInterface_SetCalibrationFactorOfFeedBack(float fCalibrationFactor)*/
/*~F:205*/
char CurrentInterface_SetCalibrationFactorOfFeedBack(float fCalibrationFactor)
/*~-1*/
{
   /*~A:206*/
   /*~+:Beschreibung*/
   /*~T*/
   /*!
   \fn char CurrentInterface_SetCalibrationFactor(float fCalibrationFactor)
   
   <b>Beschreibung:</b><br>
   Manuelles Setzen des Kalibrierfaktors.
   
   \param
   fCalibrationFactor: Zu setzender Kalibrierfaktor.
   
   \return
   Status der Funktionsausf�hrung.
   
   \retval
   0: Alles okay.
   \retval
   1: Fehler beim Setzen des Kalibrierfaktors - alter Wert wird beibehalten.
   
   <b>Zugriff:</b><br>
   [X] �ffentlich / [ ] Privat
   */
   /*~E:A206*/
   /*~A:207*/
   /*~+:Variablendeklarationen*/
   /*~T*/
   float fOldCalibrationFactor;
   /*~E:A207*/
   /*~A:208*/
   /*~+:Variableninitialisierungen*/
   /*~T*/
   Measurement_GetCalibrationFactor (CURRENTINTERFACE_FEEDBACKCHANEL,&fOldCalibrationFactor);  
   /*~E:A208*/
   /*~I:209*/
   if ((fCalibrationFactor >= MIN_KALIBRIERFAKTOR)&&(fCalibrationFactor <= MAX_KALIBRIERFAKTOR))
   /*~-1*/
   {
      /*~I:210*/
      // Kalibrierfaktor berechnen
      if (!Measurement_SetCalibrationFactor(CURRENTINTERFACE_FEEDBACKCHANEL,fCalibrationFactor))
      /*~-1*/
      {
         /*~I:211*/
         if (fCalibrationFactor != fOldCalibrationFactor)
         /*~-1*/
         {
            /*~T*/
            // Kalibrierfaktor abspeichern
            //CurrentInterface_SaveDACSettings(CURRENTINTERFACE_GAIN_FEEDBACK);
         /*~-1*/
         }
         /*~E:I211*/
         /*~T*/
         return 0;
         /*~K*/
         /*~+:*/
      /*~-1*/
      }
      /*~O:I210*/
      /*~-2*/
      else
      {
         /*~T*/
         // Fehler
         /*~T*/
         // alten Kalibrierfaktor wieder setzen
         Measurement_SetCalibrationFactor(CURRENTINTERFACE_FEEDBACKCHANEL,fOldCalibrationFactor);
      /*~-1*/
      }
      /*~E:I210*/
   /*~-1*/
   }
   /*~O:I209*/
   /*~-2*/
   else
   {
      /*~T*/
      // Fehler
   /*~-1*/
   }
   /*~E:I209*/
   /*~T*/
   return 1;
/*~-1*/
}
/*~E:F205*/
/*~E:A204*/
/*~A:212*/
/*~+:void 			CurrentInterface_SetFeedBackIntegralPortion(char chIntegralPortion)*/
/*~F:213*/
void CurrentInterface_SetFeedBackIntegralPortion(char chIntegralPortion)
/*~-1*/
{
   /*~T*/
   // Grenzen pr�fen
   chIntegralPortion = MAX(0,chIntegralPortion);
   chIntegralPortion = MIN(100,chIntegralPortion);
   /*~T*/
   g_CurrentInterface.FeedBack.chIntegralPortion = chIntegralPortion;

   // und speichern
   CurrentInterface_SaveDACSettings(CURRENTINTERFACE_INTEGRALPORTION_FEEDBACK);
/*~-1*/
}
/*~E:F213*/
/*~E:A212*/
/*~A:214*/
/*~+:void 			CurrentInterface_SetFeedBackProportionalPortion(char chProportionalPortion)*/
/*~F:215*/
void CurrentInterface_SetFeedBackProportionalPortion(char chProportionalPortion)
/*~-1*/
{
   /*~T*/
   // Grenzen pr�fen
   chProportionalPortion = MAX(0,chProportionalPortion);
   chProportionalPortion = MIN(100,chProportionalPortion);
   /*~T*/
   g_CurrentInterface.FeedBack.chProportionalPortion = chProportionalPortion;

   // und speichern
   CurrentInterface_SaveDACSettings(CURRENTINTERFACE_PROPORTIONALPORTION_FEEDBACK);
/*~-1*/
}
/*~E:F215*/
/*~E:A214*/
/*~A:216*/
/*~+:void 			CurrentInterface_SetFeedBackOnOff(unsigned char bOnOff,unsigned char bSave)*/
/*~F:217*/
void CurrentInterface_SetFeedBackOnOff(unsigned char bOnOff,unsigned char bSave)
/*~-1*/
{
   /*~I:218*/
   if (bOnOff)
   /*~-1*/
   {
      /*~T*/
      // Soll-Istwert-Korrektur einschalten
      ADuC836_DACSetCurrentDeviationCorrectionOn(1);
      // Regelabweichung setzen
      ADuC836_DACSetCurrentDeviation(0);

   /*~-1*/
   }
   /*~O:I218*/
   /*~-2*/
   else
   {
      /*~T*/
      // Soll-Istwert-Korrektur ausschalten
      ADuC836_DACSetCurrentDeviationCorrectionOn(0);
   /*~-1*/
   }
   /*~E:I218*/
   /*~I:219*/
   if (bSave)
   /*~-1*/
   {
      /*~T*/
      CurrentInterface_SaveDACSettings(CURRENTINTERFACE_ALL_SETTINGS);
   /*~-1*/
   }
   /*~E:I219*/
/*~-1*/
}
/*~E:F217*/
/*~E:A216*/
/*~A:220*/
/*~+:void 			CurrentInterface_SetLimits(long lLowerLimit,long lUpperLimit)*/
/*~F:221*/
void CurrentInterface_SetLimits(long lLowerLimit,long lUpperLimit)
/*~-1*/
{
   /*~A:222*/
   /*~+:Beschreibung*/
   /*~T*/
   /*!
   \fn void CurrentInterface_SetLimits(long lLowerLimit,long lUpperLimit)
   
   <b>Beschreibung:</b><br>
   Setzen der Grenzwerte der Stromschnittstelle.
   
   \param
   lLowerLimit: unterer Grenzwert.
   
   \param
   lUpperLimit: oberer Grenzwert.
   
   \return
   ./.
   
   <b>Zugriff:</b><br>
   [X] �ffentlich / [ ] Privat
   */

   /*~E:A222*/
   /*~T*/
   ADuC836_DACSetLimit(ADUC836_DAC_LOWER_LIMIT,lLowerLimit,ADUC836_DAC_KEEP_OUTPUT);
   ADuC836_DACSetLimit(ADUC836_DAC_UPPER_LIMIT,lUpperLimit,ADUC836_DAC_SET2ZERO);

   // und speichern
   CurrentInterface_SaveDACSettings(CURRENTINTERFACE_ALL_SETTINGS);

/*~-1*/
}
/*~E:F221*/
/*~E:A220*/
/*~A:223*/
/*~+:void 			CurrentInterface_SetManualMode(unsigned char byOnOff,long lRatedDACOutput)*/
/*~F:224*/
void CurrentInterface_SetManualMode(unsigned char byOnOff,long lRatedDACOutput)
/*~-1*/
{
   /*~T*/
   // DAC-Testmode aktiv setzen
   SET_DAC_TESTMODE(byOnOff);

   /*~T*/
   g_CurrentInterface.DAC.lRatedDACOutput = lRatedDACOutput;
/*~-1*/
}
/*~E:F224*/
/*~E:A223*/
/*~A:225*/
/*~+:void 			CurrentInterface_SetTimeHysteresis(unsigned int uTime)*/
/*~F:226*/
void CurrentInterface_SetTimeHysteresis(unsigned int uTime)
/*~-1*/
{
   /*~A:227*/
   /*~+:Beschreibung*/
   /*~T*/
   /*!
   \fn void CurrentInterface_SetTimeHysteresis(unsigned int uTime)
   
   <b>Beschreibung:</b><br>
   Setzen der Zeithysterese zum Verlassen des Grenzwertstatus.
   
   \param
   uTime: Zeit in Sekunden.
   
   \return
   ./.
   
   <b>Zugriff:</b><br>
   [X] �ffentlich / [ ] Privat
   */


   /*~E:A227*/
   /*~T*/
   ADuC836_DACSetLimitHysteresis(ADUC836_DAC_UPPER_LIMIT,uTime * CURRENTINTERFACE_TIMETICS2SEC);

   // und speichern
   CurrentInterface_SaveDACSettings(CURRENTINTERFACE_ALL_SETTINGS);

/*~-1*/
}
/*~E:F226*/
/*~E:A225*/
/*~A:228*/
/*~+:char			CurrentInterface_SetZeroOfFeedBack(long lZero2Set)*/
/*~F:229*/
char CurrentInterface_SetZeroOfFeedBack(long lZero2Set)
/*~-1*/
{
   /*~A:230*/
   /*~+:Beschreibung*/
   /*~T*/
   /*!
   \fn char CurrentInterface_SetZero(long lZero2Set)
   
   <b>Beschreibung:</b><br>
   Manuelles Setzen des Nullpunktes.
   
   \param
   lZero2Set: Zu setzender Nullpunkt.
   
   \return
   Status der Funktionsausf�hrung.
   
   \retval
   0: Alles okay.
   \retval
   1: Fehler beim Setzen des Nullpunktes - alter Wert wird beibehalten.
   
   <b>Zugriff:</b><br>
   [X] �ffentlich / [ ] Privat
   */

   /*~E:A230*/
   /*~A:231*/
   /*~+:Variablendeklarationen*/
   /*~T*/
   MEASUREMENT_VALUE Zero;
   MEASUREMENT_VALUE OldZero;
   /*~E:A231*/
   /*~A:232*/
   /*~+:Variabelninitialisierungen*/
   /*~T*/
   Measurement_GetZero (CURRENTINTERFACE_FEEDBACKCHANEL,&OldZero);
   Zero.nLong = lZero2Set;
   /*~E:A232*/
   /*~I:233*/
   if ((Zero.nLong >= MIN_NULLPUNKT)&&(Zero.nLong <= MAX_NULLPUNKT))
   /*~-1*/
   {
      /*~I:234*/
      if (!Measurement_SetZeroValue(CURRENTINTERFACE_FEEDBACKCHANEL,&Zero))
      /*~-1*/
      {
         /*~I:235*/
         if (Zero.nLong != OldZero.nLong)
         /*~-1*/
         {
            /*~T*/
            // Messwertoffset abspeichern
            // CurrentInterface_SaveDACSettings(CURRENTINTERFACE_OFFSET_FEEDBACK);
         /*~-1*/
         }
         /*~E:I235*/
         /*~T*/
         return 0;
         /*~K*/
         /*~+:*/
      /*~-1*/
      }
      /*~O:I234*/
      /*~-2*/
      else
      {
         /*~T*/
         // Fehler
      /*~-1*/
      }
      /*~E:I234*/
   /*~-1*/
   }
   /*~O:I233*/
   /*~-2*/
   else
   {
      /*~T*/
      // Fehler
   /*~-1*/
   }
   /*~E:I233*/
   /*~T*/
   // alten Nullpunkt wieder setzen
   Measurement_SetZeroValue(CURRENTINTERFACE_FEEDBACKCHANEL,&OldZero);
   /*~T*/
   return 1;
/*~-1*/
}
/*~E:F229*/
/*~E:A228*/
/*~K*/
/*~+:*/
