/*~-1*/
/*~XSF_LANGUAGE: C/C++*/
/*~K*/
/*~+:File :        Weight.c*/
/*~+:*/
/*~+:Version :     V1.001*/
/*~+:*/
/*~+:Date :        09.02.2022*/
/*~+:*/
/*~+:Time :        10:23*/
/*~+:*/
/*~+:Author :      MOF*/
/*~+:*/
/*~+:Hardware :*/
/*~+:*/
/*~+:Description : Routinen zur Ermittlung des Gewichtswertes in digitaler und normierter Form. Zus�tzlich wird hier noch die Auswertung der Temperatur und der Netzteilspannung erledigt. */
/*~+:*/
/*~+:*/
/*~A:1*/
/*~+:Includes*/
/*~T*/
#include "Weight.h"
/*~E:A1*/
/*~A:2*/
/*~+:Funktionseigene Definitionen*/
/*~T*/

/*~E:A2*/
/*~A:3*/
/*~+:Funktionseigene Struktur-Definitionen*/
/*~T*/

/*~E:A3*/
/*~A:4*/
/*~+:Funktionsprototypen*/
/*~T*/
void 				Weight(void);
char				Weight_GetEModulCompensationOnOff(void);
void 				Weight_GetMotionParameter(MEASUREMENT_MOTIONPARAMETER *pMotionParameter);
unsigned char 		Weight_Ini(unsigned char byMode);
char 				Weight_IsMotion(void);
char 				Weight_SetCalibrationFactor(float fCalibrationFactor);
char 				Weight_SetCalibrationRegardingActualWeight(float fRatedValue);
void 				Weight_SetEModulCompensationOn(bit bOnOff);
char 				Weight_SetMotionParameter(MEASUREMENT_MOTIONPARAMETER MotionParameter,bit bStore);

char 				Weight_SetTareValue(float fTare2Set,bit bStore);
char 				Weight_SetZero(long lZero2Set);
char 				Weight_SetZeroRegardingActualWeight(void);

/*~E:A4*/
/*~A:5*/
/*~+:Globale Variablen*/
/*~T*/
MEASUREMENT_VALUE Weight_MeasurementFromADC;
MEASUREMENT_VALUE Weight_FilteredMeasurement;
MEASUREMENT_VALUE Weight_CorrectedMeasurement;
MEASUREMENT_VALUE Weight_ZeroCorrectedMeasurement;
MEASUREMENT_VALUE Weight_ZeroCorrectedMeasurementStandardized;
MEASUREMENT_VALUE Weight_ZeroCorrectedMeasurementWithTare;
MEASUREMENT_VALUE Weight_GrossWeight;
MEASUREMENT_VALUE Weight_TareWeight;
MEASUREMENT_VALUE Weight_NetWeight;

long g_Weight_lSimulatedRMW;
unsigned int  g_Weight_uExecuteMotionCounter;


/*~E:A5*/
/*~A:6*/
/*~+:void 				Weight(void)*/
/*~F:7*/
void Weight(void)
/*~-1*/
{
   /*~A:8*/
   /*~+:Beschreibung*/
   /*~T*/
   /*!
   \fn void Weight(void)
   
   <b>Beschreibung:</b><br>
   Ermittelt das normierte Systemgewicht und diverse Zwischenergebnisse.
   
   \retval
   ./.
   
   <b>Zugriff:</b><br>
   [X] �ffentlich / [ ] Privat
   */
   /*~E:A8*/
   /*~A:9*/
   /*~+:Variablendeklarationen*/
   /*~T*/
   MEASUREMENT_VALUE Measurement;
   MEASUREMENT_MOTIONPARAMETER MotionParameter;
   float fCalibrationFactor;
   /*~K*/
   /*~+:*/
   /*~T*/
   MEASUREMENT_VALUE 	MVTemp;
   /*~K*/
   /*~+:*/
   /*~E:A9*/
   /*~A:10*/
   /*~+:Variableninitialsierungen*/
   /*~T*/

   /*~E:A10*/
   /*~I:11*/
   if ((ADuC836_ADCIsNewConversionValue(ADuC836_ADC_PRIMARY) != 0)||(g_SystemControl.bySimulate & 0x01))
   /*~-1*/
   {
      /*~T*/
      // JA

      /*~A:12*/
      /*~+:Nur zu Debugzwecken - SYSTEM_CND_LEDS_4_DEBUG_P06_CHECK_WEIGHING_CYCLE*/
      /*~I:13*/
#ifdef SYSTEM_CND_LEDS_4_DEBUG_P06_CHECK_WEIGHING_CYCLE		// nicht definiert
      /*~T*/
      P06 = 0;
      /*~-1*/
#endif
      /*~E:I13*/
      /*~E:A12*/
      /*~I:14*/
#ifdef MIT_GEWICHTSSIMULATION		// nicht simuliert
      /*~A:15*/
      /*~+:MIT_GEWICHTSSIMULATION*/
      /*~I:16*/
      if (!(g_SystemControl.bySimulate & 0x01))
      /*~-1*/
      {
         /*~T*/
         // Roh-Messwert vom ADC holen
         Measurement.nLong = ADuC836_ADCGetConversionValue(ADuC836_ADC_PRIMARY,0);
      /*~-1*/
      }
      /*~O:I16*/
      /*~-2*/
      else
      {
         /*~A:17*/
         /*~+:Simulation des Gewicht-Rohmesswerts*/
         /*~T*/
         Measurement.nLong = g_Weight_lSimulatedRMW;
         /*~E:A17*/
      /*~-1*/
      }
      /*~E:I16*/
      /*~E:A15*/
      /*~O:I14*/
      /*~-1*/
#else
      /*~T*/
      // Roh-Messwert vom ADC holen
      Measurement.nLong = ADuC836_ADCGetConversionValue(ADuC836_ADC_PRIMARY,0);
      /*~-1*/
#endif
      /*~E:I14*/
      /*~T*/
      Weight_MeasurementFromADC = Measurement;
      /*~T*/
      // Rohmesswertfilterung (nur wenn tats�chlich ein neuer Wert vorliegt !!!)
      Measurement_Processing(MEASUREMENT_PROCESSING_FILTER,WEIGHT_WEIGHTCHANNEL,&Measurement);
      /*~T*/
      // Nullpunktverrechnung
      Measurement_Processing(MEASUREMENT_PROCESSING_ZERO,WEIGHT_WEIGHTCHANNEL,&Measurement);
      /*~K*/
      /*~+:/~* Ge�ndert am 09.02.2022 aufgrund eines Fehlers in der E-Modul-Berechnung *~/*/
      /*~T*/
      // Temperatur- und E-Modul-Kompensation
      Measurement_Processing(MEASUREMENT_PROCESSING_CORRECTION,WEIGHT_WEIGHTCHANNEL,&Measurement);
      Weight_ZeroCorrectedMeasurement = Measurement;
      /*~F:18*/
      /* F�r die Kennlinienaufnahme bedarf des korrigierten, aber nicht nullpunktverrechneten Messwerts */
      /*~-1*/
      {
         /*~T*/
         Measurement_GetZero(WEIGHT_WEIGHTCHANNEL,&MVTemp); /* Nullpunkt holen */

         Weight_FilteredMeasurement.nLong = Weight_ZeroCorrectedMeasurement.nLong + MVTemp.nLong;	/* und verrechnen */

      /*~-1*/
      }
      /*~E:F18*/
      /*~K*/
      /*~+:/~* Ende - Ge�ndert am 09.02.2022 *~/*/
      /*~T*/
      // Normierung
      Measurement_Processing(MEASUREMENT_PROCESSING_STANDARDIZATION,WEIGHT_WEIGHTCHANNEL,&Measurement);
      Weight_ZeroCorrectedMeasurementStandardized = Measurement;

      /*~T*/
      // Tara-Verechnung
      Measurement_Processing(MEASUREMENT_PROCESSING_TARE,WEIGHT_WEIGHTCHANNEL,&Measurement);

      /*~T*/
      //Measurement_GetResults(WEIGHT_WEIGHTCHANNEL,&Results[WEIGHT_WEIGHTCHANNEL],0);
      Measurement_GetResult(WEIGHT_WEIGHTCHANNEL,MEASUREMENT_GET_GROSS,&Weight_GrossWeight);

      Measurement_GetResult(WEIGHT_WEIGHTCHANNEL,MEASUREMENT_GET_TARE,&Weight_TareWeight);

      Measurement_GetResult(WEIGHT_WEIGHTCHANNEL,MEASUREMENT_GET_NET,&Weight_NetWeight);
      /*~T*/
      // Jetzt noch den Tarawert vom nullpunktkorrigiertem Rohmesswert abziehen
      // Dazu zun�chst den Kalibrierfaktor ermitteln
      Measurement_GetCalibrationFactor(WEIGHT_WEIGHTCHANNEL,&fCalibrationFactor);
      // und rechnen
      Weight_ZeroCorrectedMeasurementWithTare.nLong = Weight_ZeroCorrectedMeasurement.nLong - (long)(Weight_TareWeight.fFloat / fCalibrationFactor);
      /*~A:19*/
      /*~+:Nur zu Debugzwecken - SYSTEM_CND_LEDS_4_DEBUG_P06_CHECK_WEIGHING_CYCLE*/
      /*~I:20*/
#ifdef SYSTEM_CND_LEDS_4_DEBUG_P06_CHECK_WEIGHING_CYCLE
      /*~T*/
      P06 = 1;
      /*~-1*/
#endif
      /*~E:I20*/
      /*~E:A19*/
   /*~-1*/
   }
   /*~O:I11*/
   /*~-2*/
   else
   {
      /*~T*/
      // NEIN
      /*~T*/
      // Letzten Messwert �bernehmen

      //Measurement = Weight_MeasurementFromADC;
   /*~-1*/
   }
   /*~E:I11*/
   /*~I:21*/
   if (Flag100ms)
   /*~-1*/
   {
      /*~A:22*/
      /*~+:Motion-�berpr�fung*/
      /*~T*/
      Weight_GetMotionParameter(&MotionParameter);
      /*~I:23*/
      if (g_Weight_uExecuteMotionCounter++ >= MotionParameter.byMotionFilter)
      /*~-1*/
      {
         /*~T*/
         g_Weight_uExecuteMotionCounter = 0;

         // Motion-�berpr�fung
         Measurement_Processing(MEASUREMENT_PROCESSING_MOTION,WEIGHT_WEIGHTCHANNEL,&Weight_ZeroCorrectedMeasurementStandardized);

      /*~-1*/
      }
      /*~E:I23*/
      /*~E:A22*/
   /*~-1*/
   }
   /*~E:I21*/
   /*~A:24*/
   /*~+:Nur zu Debugzwecken - SYSTEM_CND_LEDS_4_DEBUG_P06_MOTION*/
   /*~I:25*/
#ifdef SYSTEM_CND_LEDS_4_DEBUG_P06_MOTION
   /*~I:26*/
   if (Weight_IsMotion())
   /*~-1*/
   {
      /*~T*/
      P06 = 1;
   /*~-1*/
   }
   /*~O:I26*/
   /*~-2*/
   else
   {
      /*~T*/
      P06 = 0;
   /*~-1*/
   }
   /*~E:I26*/
   /*~-1*/
#endif
   /*~E:I25*/
   /*~E:A24*/
/*~-1*/
}
/*~E:F7*/
/*~E:A6*/
/*~A:27*/
/*~+:char				Weight_GetEModulCompensationOnOff(void)*/
/*~F:28*/
char Weight_GetEModulCompensationOnOff(void)
/*~-1*/
{
   /*~T*/
   return Global.chEModulCompensationOn;
/*~-1*/
}
/*~E:F28*/
/*~E:A27*/
/*~A:29*/
/*~+:void 				Weight_GetMotionParameter(MEASUREMENT_MOTIONPARAMETER *pMotionParameter)*/
/*~F:30*/
void Weight_GetMotionParameter(MEASUREMENT_MOTIONPARAMETER *pMotionParameter)
/*~-1*/
{
   /*~T*/
   Measurement_GetMotionParameter(WEIGHT_WEIGHTCHANNEL,pMotionParameter);
/*~-1*/
}
/*~E:F30*/
/*~E:A29*/
/*~A:31*/
/*~+:unsigned char 			Weight_Ini(unsigned char byMode)*/
/*~F:32*/
unsigned char Weight_Ini(unsigned char byMode)
/*~-1*/
{
   /*~A:33*/
   /*~+:Beschreibung*/
   /*~T*/
   /*!
   \fn unsigned char Weight_Ini(unsigned char byMode)
   
   <b>Beschreibung:</b><br>
   Initialisierung der Parameter zur Gewichtsermittlung.
   
   \param
   byMode: 
   \param
   0 = Initialisierung mit Defaultwerten, 
   \param
   1 = Initialisierung mit abgespeicherten Werten.
   
   \return
   Status der Funktionsausf�hrung.
   
   \retval
   0: Alles okay.
   
   \retval
   1: Fehler bei der Messwert-Initialisierung.
   
   \retval
   2: Fehler beim Einrichten des Messwertkanals 'Gewichtskanal'.
   
   \retval
   3: Fehler beim Einrichten des Messwertkanals 'Temperaturkanal' (in Vorbereitung).
   
   \retval
   4: Fehler beim Einrichten des Messwertkanals 'Netzteilkanal' (nur Master) (in Vorbereitung).
   
   \retval
   5: Fehler beim Setzen des Kalibrierfaktors 'Gewichtskanal'.
   
   \retval
   6: Fehler beim Setzen des Kalibrierfaktors 'Temperaturkanal' (in Vorbereitung).
   
   \retval
   7: Fehler beim Setzen des Kalibrierfaktors 'Netzteilkanal' (nur Master) (in Vorbereitung).
   
   \retval
   8: Fehler beim Setzen der Motion-Parameter 'Gewichtskanal'.
   
   \retval
   9: Fehler beim Setzen der Motion-Parameter 'Temperaturkanal' (in Vorbereitung).
   
   \retval
   10: Fehler beim Setzen der Motion-Parameter 'Netzteilkanal' (nur Master) (in Vorbereitung).
   
   \retval
   11: Fehler beim Setzen der Messwert-Sequenz 'Gewichtskanal'.
   
   \retval
   12: Fehler beim Setzen der Messwert-Sequenz 'Temperaturkanal' (in Vorbereitung).
   
   \retval
   13: Fehler beim Setzen der Messwert-Sequenz 'Netzteilkanal' (nur Master) (in Vorbereitung).
   
   \retval
   14: Fehler beim Initialisieren der Korrekturfunktion 'Gewichtskanal'.
   
   \retval
   15: Fehler beim Initialisieren der Korrekturfunktion 'Temperaturkanal' (in Vorbereitung). 
   
   \retval
   16: Fehler beim Initialisieren der Korrekturfunktion 'Netzteilkanal' (nur Master) (in Vorbereitung). 
   
   \retval
   17: Fehler bei der Initialisierung des Filters 'Gewichtskanal'.
   
   \retval
   18: Fehler bei der Initialisierung des Filters 'Temperaturkanal' (in Vorbereitung). 
   
   \retval
   19: Fehler bei der Initialisierung des Filters 'Netzteilkanal' (nur Master) (in Vorbereitung). 
   
   \retval
   20: Fehler beim Setzen des Taras.
   
   <b>Zugriff:</b><br>
   [X] �ffentlich / [ ] Privat
   */
   /*~E:A33*/
   /*~A:34*/
   /*~+:Variablendeklarationen*/
   /*~T*/
   MEASUREMENT_MOTIONPARAMETER MotionParameter;
   unsigned char chRetVal;
   /*~E:A34*/
   /*~A:35*/
   /*~+:Variableninitialsierungen*/
   /*~T*/
   // R�ckgabewert nullen
   chRetVal = 0;

   // Z�hler f�r Aktivierung der Motion-Untersuchung
   g_Weight_uExecuteMotionCounter = 0;
   /*~E:A35*/
   /*~A:36*/
   /*#LJ:Weight_Ini=1*/
   /*~+:Messwert-Routine einrichten.*/
   /*~I:37*/
#ifdef MOF	///< wird jetzt in der Main_Init vorgenommen
   /*~A:38*/
   /*~+:Messwertroutinen initialisieren.*/
   /*~T*/
   // Messwertroutinen initialisieren
   Measurement_Init();
   /*~E:A38*/
   /*~-1*/
#endif
   /*~E:I37*/
   /*~C:39*/
   switch (byMode)
   /*~-1*/
   {
      /*~A:40*/
      /*~+:Initialisierung mit Defaultwerten.*/
      /*~F:41*/
      case 0:		// Initialisierung mit Defaultwerten
      /*~-1*/
      {
         /*~A:42*/
         /*~+:Nullpunkt setzen*/
         /*~T*/
         Weight_SetZero(0);
         /*~E:A42*/
         /*~A:43*/
         /*~+:Kalibrierfaktor setzen. Bei Fehler: R�ckgabe von 5*/
         /*~I:44*/
         // Kalibrierfaktor setzen
         if (Weight_SetCalibrationFactor(0.12))
         /*~-1*/
         {
            /*~T*/
            // Fehler beim Setzen des Kalibrierfaktors
            return 5;
         /*~-1*/
         }
         /*~E:I44*/
         /*~E:A43*/
         /*~A:45*/
         /*~+:Motion-Parameter setzen. Bei Fehler: R�ckgabe von 2*/
         /*~T*/
         // Motion-Grenze und �berpr�fungsrate setzen
         // Motion�berpr�fung erfolgt bei jedem Aufruf von Measurement_Processing und wird
         // bei einer Messwertbewegung von mehr als 10kg als solche erkannt.
         MotionParameter.fMotionLimit = 10;
         // MotionParameter.byMotionCheckOn = 1;
         MotionParameter.byMotionFilter = 4;			// Motionpr�fung alle 400ms
         //         MotionParameter.byNoMotionFilter = 6;		// wird nicht ben�tigt
         /*~T*/
         // Motion-�berpr�fung einstellen
         /*~I:46*/
         if (chRetVal = Weight_SetMotionParameter(MotionParameter,1))
         /*~-1*/
         {
            /*~T*/
            return (chRetVal);
         /*~-1*/
         }
         /*~E:I46*/
         /*~E:A45*/
         /*~A:47*/
         /*~+:Tara setzen. Bei Fehler: R�ckgabe von 20*/
         /*~I:48*/
         if (Weight_SetTareValue(0,1))
         /*~-1*/
         {
            /*~T*/
            // Fehler beim Setzen des Taras
            return 20;
         /*~-1*/
         }
         /*~E:I48*/
         /*~E:A47*/
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F41*/
      /*~E:A40*/
      /*~A:49*/
      /*~+:Initialisierung mit abgespeicherten Werten.*/
      /*~F:50*/
      case 1:		// Initialisierung mit abgespeicherten Werten
      /*~-1*/
      {
         /*~A:51*/
         /*~+:Variablendeklarationen*/
         /*~T*/
         float fValue;
         long lValue;

         /*~E:A51*/
         /*~A:52*/
         /*~+:Nullpunkt*/
         /*~T*/
         // Nullpunkt auslesen 
         Load_Parameter(LOAD_SAVE_WEIGHT_ZERO,&lValue,0);

         // und setzen
         Weight_SetZero(lValue);
         /*~E:A52*/
         /*~A:53*/
         /*~+:Kalibrierfaktor*/
         /*~T*/
         // Kalibrierfaktor auslesen 
         Load_Parameter(LOAD_SAVE_WEIGHT_CALIBRATION_FACTOR,&fValue,0);

         // und setzen
         Weight_SetCalibrationFactor(fValue);
         /*~E:A53*/
         /*~A:54*/
         /*~+:Tara*/
         /*~T*/
         // Kalibrierfaktor auslesen 
         Load_Parameter(LOAD_SAVE_WEIGHT_TARA,&fValue,0);
         /*~T*/
         // und setzen
         /*~I:55*/
         if (Weight_SetTareValue(fValue,1))
         /*~-1*/
         {
            /*~T*/
            return 20;
         /*~-1*/
         }
         /*~E:I55*/
         /*~E:A54*/
         /*~A:56*/
         /*~+:Motion-Parameter*/
         /*~T*/
         // Motionparameter auslesen 
         Load_Parameter(LOAD_SAVE_WEIGHT_MOTIONPARAMETER,&MotionParameter,0);
         /*~T*/
         // und setzen
         /*~I:57*/
         if (chRetVal = Weight_SetMotionParameter(MotionParameter,0))
         /*~-1*/
         {
            /*~T*/
            return (chRetVal);
         /*~-1*/
         }
         /*~E:I57*/
         /*~E:A56*/
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F50*/
      /*~E:A49*/
   /*~-1*/
   }
   /*~E:C39*/
   /*~E:A36*/
   /*~A:58*/
   /*~+:Korrekturfunktion initialisieren. Bei Fehler: R�ckgabe von 14,15 oder 16.*/
   /*~I:59*/
   // Korrekturfunktion initialisieren
   if (Correction_Ini(byMode))
   /*~-1*/
   {
      /*~T*/
      // Fehler beim Initialisieren der Korrekturfunktion
      return 14;
   /*~-1*/
   }
   /*~E:I59*/
   /*~E:A58*/
   /*~A:60*/
   /*~+:E-Modul-Kompensation einschalten*/
   /*~I:61*/
   if (!byMode)
   /*~-1*/
   {
      /*~T*/
      // Global.chEModulCompensationOn = 0;
      // E-Modul-Kompensation defaultm��ig einschalten
      Global.chEModulCompensationOn = 1;

      // und speichern
      Save_Parameter(LOAD_SAVE_E_MODUL_COMPENSATION_ONOFF,&Global.chEModulCompensationOn,1);
   /*~-1*/
   }
   /*~O:I61*/
   /*~-2*/
   else
   {
      /*~T*/
      Load_Parameter(LOAD_SAVE_E_MODUL_COMPENSATION_ONOFF,&Global.chEModulCompensationOn,1);
   /*~-1*/
   }
   /*~E:I61*/
   /*~T*/

   /*~E:A60*/
   /*~T*/
   return 0;
/*~-1*/
}
/*~E:F32*/
/*~E:A31*/
/*~A:62*/
/*~+:char 				Weight_IsMotion(void)*/
/*~F:63*/
char Weight_IsMotion(void)
/*~-1*/
{
   /*~T*/
   return Measurement_IsMotion(WEIGHT_WEIGHTCHANNEL);
/*~-1*/
}
/*~E:F63*/
/*~E:A62*/
/*~A:64*/
/*~+:char 				Weight_SetCalibrationFactor(float fCalibrationFactor)*/
/*~F:65*/
char Weight_SetCalibrationFactor(float fCalibrationFactor)
/*~-1*/
{
   /*~A:66*/
   /*~+:Beschreibung*/
   /*~T*/
   /*!
   \fn char Weight_SetCalibrationFactor(float fCalibrationFactor)
   
   <b>Beschreibung:</b><br>
   Manuelles Setzen des Kalibrierfaktors.
   
   \param
   fCalibrationFactor: Zu setzender Kalibrierfaktor.
   
   \return
   Status der Funktionsausf�hrung.
   
   \retval
   0: Alles okay.
   \retval
   1: Fehler beim Setzen des Kalibrierfaktors - alter Wert wird beibehalten.
   
   <b>Zugriff:</b><br>
   [X] �ffentlich / [ ] Privat
   */
   /*~E:A66*/
   /*~A:67*/
   /*~+:Variablendeklarationen*/
   /*~T*/
   float fOldCalibrationFactor;
   /*~E:A67*/
   /*~A:68*/
   /*~+:Variableninitialisierungen*/
   /*~T*/
   Measurement_GetCalibrationFactor (0,&fOldCalibrationFactor);  
   /*~E:A68*/
   /*~I:69*/
   if ((fCalibrationFactor >= MIN_KALIBRIERFAKTOR)&&(fCalibrationFactor <= MAX_KALIBRIERFAKTOR))
   /*~-1*/
   {
      /*~I:70*/
      // Kalibrierfaktor berechnen
      if (!Measurement_SetCalibrationFactor(0,fCalibrationFactor))
      /*~-1*/
      {
         /*~I:71*/
         if (fCalibrationFactor != fOldCalibrationFactor)
         /*~-1*/
         {
            /*~T*/
            //Kalibrierfaktor abspeichern
            Save_Parameter(LOAD_SAVE_WEIGHT_CALIBRATION_FACTOR,&fCalibrationFactor,0);
         /*~-1*/
         }
         /*~E:I71*/
         /*~T*/
         return 0;
         /*~K*/
         /*~+:*/
      /*~-1*/
      }
      /*~O:I70*/
      /*~-2*/
      else
      {
         /*~T*/
         // Fehler
      /*~-1*/
      }
      /*~E:I70*/
   /*~-1*/
   }
   /*~O:I69*/
   /*~-2*/
   else
   {
      /*~T*/
      // Fehler
   /*~-1*/
   }
   /*~E:I69*/
   /*~T*/
   // alten Kalibrierfaktor wieder setzen
   Measurement_SetCalibrationFactor(0,fOldCalibrationFactor);
   /*~T*/
   return 1;
/*~-1*/
}
/*~E:F65*/
/*~E:A64*/
/*~A:72*/
/*~+:char				Weight_SetCalibrationRegardingActualWeight(float fRatedValue)*/
/*~F:73*/
char Weight_SetCalibrationRegardingActualWeight(float fRatedValue)
/*~-1*/
{
   /*~A:74*/
   /*~+:Beschreibung*/
   /*~T*/
   /*!
   \fn char Weight_SetCalibrationRegardingActualWeight(float fRatedValue)
   
   <b>Beschreibung:</b><br>
   Kalibrierfaktor in Abh�ngigkeit des aktuelle Gewichtes und einem Sollgewicht setzen. Die �berpr�fung auf eine eventuelle Gewichtsbewegung erfolgt in der Messwertbibliotheke.
   
   \param
   fRatedValue: Sollgewicht, auf welches kalibriert wird.
   
   \return
   Status der Funktionsausf�hrung.
   
   \retval
   0: Alles okay.
   \retval
   1: Fehler beim Setzen des Kalibrierfaktors - alter Wert wird beibehalten.
   \retval
   2: Gewicht instabil.
   
   <b>Zugriff:</b><br>
   [X] �ffentlich / [ ] Privat
   */
   /*~E:A74*/
   /*~A:75*/
   /*~+:Variablendeklarationen*/
   /*~T*/
   MEASUREMENT_VALUE Weight;
   float fCalibrationFactor;
   float fOldCalibrationFactor;
   /*~E:A75*/
   /*~A:76*/
   /*~+:Variableninitialisierungen*/
   /*~T*/
   Weight.fFloat = fRatedValue;
   Measurement_GetCalibrationFactor (0,&fOldCalibrationFactor);  
   /*~E:A76*/
   /*~I:77*/
   // Kalibrierfaktor berechnen
   if (!Measurement_CalcCalibrationFactor(0,Weight,0))
   /*~-1*/
   {
      /*~T*/
      // Kalibrierfaktor zur�cklesen
      Measurement_GetCalibrationFactor (0,&fCalibrationFactor);
      /*~I:78*/
      if ((fCalibrationFactor >= MIN_KALIBRIERFAKTOR)&&(fCalibrationFactor <= MAX_KALIBRIERFAKTOR))
      /*~-1*/
      {
         /*~T*/
         //Kalibrierfaktor abspeichern
         Save_Parameter(LOAD_SAVE_WEIGHT_CALIBRATION_FACTOR,&fCalibrationFactor,0);
         /*~T*/
         return 0;
         /*~K*/
         /*~+:*/
      /*~-1*/
      }
      /*~O:I78*/
      /*~-2*/
      else
      {
         /*~T*/
         // Fehler
      /*~-1*/
      }
      /*~E:I78*/
   /*~-1*/
   }
   /*~O:I77*/
   /*~-2*/
   else
   {
      /*~T*/
      // Fehler
   /*~-1*/
   }
   /*~E:I77*/
   /*~T*/
   // alten Kalibrierfaktor wieder setzen
   Measurement_SetCalibrationFactor(0,fOldCalibrationFactor);
   /*~T*/
   return 1;
/*~-1*/
}
/*~E:F73*/
/*~E:A72*/
/*~A:79*/
/*~+:void 				Weight_SetEModulCompensationOn(bit bOnOff)*/
/*~F:80*/
void Weight_SetEModulCompensationOn(bit bOnOff)
/*~-1*/
{
   /*~T*/
   Global.chEModulCompensationOn = bOnOff;

   // und speichern
   Save_Parameter(LOAD_SAVE_E_MODUL_COMPENSATION_ONOFF,&Global.chEModulCompensationOn,1);
/*~-1*/
}
/*~E:F80*/
/*~E:A79*/
/*~A:81*/
/*~+:char 				Weight_SetMotionParameter(MEASUREMENT_MOTIONPARAMETER MotionParameter,bit bStore)*/
/*~F:82*/
char Weight_SetMotionParameter(MEASUREMENT_MOTIONPARAMETER MotionParameter,bit bStore)
/*~-1*/
{
   /*~I:83*/
   // Motion-�berpr�fung einstellen
   if (Measurement_SetMotionParameter(WEIGHT_WEIGHTCHANNEL,MotionParameter))
   /*~-1*/
   {
      /*~T*/
      // Fehler beim Setzen der Motion-Parameter
      return 8;
   /*~-1*/
   }
   /*~O:I83*/
   /*~-2*/
   else
   {
      /*~I:84*/
      if (bStore)
      /*~-1*/
      {
         /*~T*/
         // Motionparameter speichern 
         Save_Parameter(LOAD_SAVE_WEIGHT_MOTIONPARAMETER,&MotionParameter,0);
      /*~-1*/
      }
      /*~E:I84*/
   /*~-1*/
   }
   /*~E:I83*/
/*~-1*/
}
/*~E:F82*/
/*~E:A81*/
/*~A:85*/
/*~+:char 				Weight_SetTareValue(float fTare2Set,bit bStore)*/
/*~F:86*/
char Weight_SetTareValue(float fTare2Set,bit bStore)
/*~-1*/
{
   /*~A:87*/
   /*~+:Variablendeklarationen*/
   /*~T*/
   MEASUREMENT_VALUE Tare;
   /*~E:A87*/
   /*~I:88*/
   // nur positive Tara-Werte zulassen
   // if (fTare2Set >= 0)
   if(1)
   /*~-1*/
   {
      /*~T*/
      Tare.fFloat = fTare2Set;

      /*~I:89*/
      // Tara setzen
      if (!Measurement_SetTareValue(WEIGHT_WEIGHTCHANNEL,&Tare.fFloat))
      /*~-1*/
      {
         /*~I:90*/
         if (bStore)
         /*~-1*/
         {
            /*~T*/
            // Tara speichern 
            Save_Parameter(LOAD_SAVE_WEIGHT_TARA,&fTare2Set,0);
         /*~-1*/
         }
         /*~E:I90*/
         /*~T*/
         return 0;
      /*~-1*/
      }
      /*~O:I89*/
      /*~-2*/
      else
      {
         /*~T*/
         return 1;
      /*~-1*/
      }
      /*~E:I89*/
   /*~-1*/
   }
   /*~O:I88*/
   /*~-2*/
   else
   {
      /*~T*/
      return 2;
   /*~-1*/
   }
   /*~E:I88*/
/*~-1*/
}
/*~E:F86*/
/*~E:A85*/
/*~A:91*/
/*~+:char 				Weight_SetZero(long lZero2Set)*/
/*~F:92*/
char Weight_SetZero(long lZero2Set)
/*~-1*/
{
   /*~A:93*/
   /*~+:Beschreibung*/
   /*~T*/
   /*!
   \fn char Weight_SetZero(long lZero2Set)
   
   <b>Beschreibung:</b><br>
   Manuelles Setzen des Nullpunktes.
   
   \param
   lZero2Set: Zu setzender Nullpunkt.
   
   \return
   Status der Funktionsausf�hrung.
   
   \retval
   0: Alles okay.
   \retval
   1: Fehler beim Setzen des Nullpunktes - alter Wert wird beibehalten.
   
   <b>Zugriff:</b><br>
   [X] �ffentlich / [ ] Privat
   */

   /*~E:A93*/
   /*~A:94*/
   /*~+:Variablendeklarationen*/
   /*~T*/
   MEASUREMENT_VALUE Zero;
   MEASUREMENT_VALUE OldZero;
   /*~E:A94*/
   /*~A:95*/
   /*~+:Variabelninitialisierungen*/
   /*~T*/
   Measurement_GetZero (WEIGHT_WEIGHTCHANNEL,&OldZero);
   Zero.nLong = lZero2Set;
   /*~E:A95*/
   /*~I:96*/
   if ((Zero.nLong >= MIN_NULLPUNKT)&&(Zero.nLong <= MAX_NULLPUNKT))
   /*~-1*/
   {
      /*~I:97*/
      if (!Measurement_SetZeroValue(WEIGHT_WEIGHTCHANNEL,&Zero))
      /*~-1*/
      {
         /*~I:98*/
         if (Zero.nLong != OldZero.nLong)
         /*~-1*/
         {
            /*~T*/
            //Nullpunkt abspeichern
            Save_Parameter(LOAD_SAVE_WEIGHT_ZERO,&Zero,0);
         /*~-1*/
         }
         /*~E:I98*/
         /*~T*/
         return 0;
         /*~K*/
         /*~+:*/
      /*~-1*/
      }
      /*~O:I97*/
      /*~-2*/
      else
      {
         /*~T*/
         // Fehler
      /*~-1*/
      }
      /*~E:I97*/
   /*~-1*/
   }
   /*~O:I96*/
   /*~-2*/
   else
   {
      /*~T*/
      // Fehler
   /*~-1*/
   }
   /*~E:I96*/
   /*~T*/
   // alten Nullpunkt wieder setzen
   Measurement_SetZeroValue(WEIGHT_WEIGHTCHANNEL,&OldZero);
   /*~T*/
   return 1;
/*~-1*/
}
/*~E:F92*/
/*~E:A91*/
/*~A:99*/
/*~+:char 				Weight_SetZeroRegardingActualWeight(void)*/
/*~F:100*/
char Weight_SetZeroRegardingActualWeight(void)
/*~-1*/
{
   /*~A:101*/
   /*~+:Beschreibung*/
   /*~T*/
   /*!
   \fn char Weight_SetZeroRegardingActualWeight(void)
   
   <b>Beschreibung:</b><br>
   Setzen des Nullpunkts auf den augenblicklichen Gewichtswert. Die �berpr�fung auf eine eventuelle Gewichtsbewegung erfolgt in der Messwertbibliotheke.
   
   \param
   ./.
   
   \return
   Status der Funktionsausf�hrung.
   
   \retval
   0: Alles okay.
   \retval
   1: Fehler beim Setzen des Nullpunktes - alter Wert wird beibehalten.
   
   <b>Zugriff:</b><br>
   [X] �ffentlich / [ ] Privat
   */
   /*~E:A101*/
   /*~A:102*/
   /*~+:Variablendeklarationen*/
   /*~T*/
   MEASUREMENT_VALUE Zero;
   /*~E:A102*/
   /*~A:103*/
   /*~+:Variableninitialisierungen*/
   /*~T*/
     
   /*~E:A103*/
   /*~I:104*/
   // Setzen des Nullpunktes auf den aktuellen Rohmesswert
   if (!Measurement_SetZero(WEIGHT_WEIGHTCHANNEL))
   /*~-1*/
   {
      /*~T*/
      // neuen Nullpunkt auslesen
      Measurement_GetZero (WEIGHT_WEIGHTCHANNEL,&Zero);

      /*~I:105*/
      if ((Zero.nLong >= MIN_NULLPUNKT)&&(Zero.nLong <= MAX_NULLPUNKT))
      /*~-1*/
      {
         /*~T*/
         //Nullpunkt abspeichern
         Save_Parameter(LOAD_SAVE_WEIGHT_ZERO,&Zero,0);
         /*~T*/
         return 0;
      /*~-1*/
      }
      /*~O:I105*/
      /*~-2*/
      else
      {
         /*~T*/
         // Fehler
         /*~T*/
         return 1;
      /*~-1*/
      }
      /*~E:I105*/
   /*~-1*/
   }
   /*~O:I104*/
   /*~-2*/
   else
   {
      /*~T*/
      // Fehler
      /*~T*/
      return 2;
   /*~-1*/
   }
   /*~E:I104*/
/*~-1*/
}
/*~E:F100*/
/*~E:A99*/
