/*~-1*/
/*~XSF_LANGUAGE: C/C++*/
/*~A:1*/
/*~+:Versions-Beschreibung*/
/*~A:2*/
/*~+:Version und Versionsdatum*/
/*~T*/
/*!
\mainpage "Modul-Beschreibung"
\author Michael Offenbach
\date 09.02.2022
\version V1.001
\warning
*/
/*~E:A2*/
/*~A:3*/
/*~+:Ziel-Hardware*/
/*~T*/
/*!\page HardwarePage Ziel-Hardware

\section sec_HardwarePage_MRW420 'Applikation MRW420'

<table border=1 width=100% height=1% rules=rows cellspacing=0 bgcolor="#E0E0F0">

<tr align=left valign=top>
	<th>Motherboard</th>
	<th>Prozessor</th>
	<th>ROM</th>
	<th>RAM</th>
</tr>

<tr>
	<td>MRW420 </td>
	<td>8051-Core</td>
	<td>62 <B>kByte</B></td>
	<td>2 <B>kByte</B></td>
</tr></table>

*/
/*~E:A3*/
/*~A:4*/
/*~+:Compiler-Einstellungen*/
/*~T*/
/*!\page CompilerPage Compiler-Einstellungen

\section sec_CompilerPage_MRW420 'Applikation MRW420'

<table border=1 width=100% height=1% rules=rows cellspacing=0 bgcolor="#E0E0F0">

<tr align=left valign=top>
	<th>Compiler</th>
	<th>Betriebssystem</th>
	<th>Speichermodell</th>
	<th>Code-Speicher-Gr��e</th>
	<th>Optimierungen</th>
	<th>Sonstiges</th>
</tr>

<tr>
	<td>Keil uVision2 V2.40<BR>C51 V7.08<BR>A51 V7.08a</td>
	<td>Kein Betriebssystem</td>
	<td>Large: variables in XDATA</td>
	<td>Large: 64k program</td>
	<td>
	[ ] 0 Constant Folding<BR>
	[ ] 1 Dead Code Elimination<BR>
	[ ] 2 Data Overlaying<BR>
	[ ] 3 Peephole Optimization<BR>
	[ ] 4 Register Variables<BR>
	[ ] 5 Common Subexpression Elimination<BR>
	[X] 6 Loop Rotation<BR>
	[ ] 7 Extended Index Access Optimizing<BR>
	[ ] 8 Reuse Common Entry Code<BR>
	[ ] 9 Common Block Subroutines<BR>
	<BR>
	[X]Favor size<BR>
	[ ]Favor speed</td>
	<td>---</td>
</tr></table>

*/
/*~E:A4*/
/*~A:5*/
/*~+:Ressourcen*/
/*~T*/
/*!\page RessourcePage Ressourcen

\section sec_RessourcePage_MRW420 'Applikation MRW420'

<table border=1 width=100% height=1% rules=rows cellspacing=0 bgcolor="#E0E0F0">

<tr align=left valign=top>
	<th>CODE</th>
	<th>IDATA</th>
	<th>XDATA</th>
	<th>Dynamische Variablen</th>
</tr>

<tr>
	<td>--- <B>Bytes</B></td>
	<td>--- <B>Bytes</B></td>
	<td>--- <B>Bytes</B></td>
	<td>(2*(Anzahl der Sequenzeintr�ge+1)+46) * Anzahl der Messwertkan�le <B>Bytes</B></td>
</tr></table>

*/
/*~E:A5*/
/*~A:6*/
/*~+:Zykluszeiten*/
/*~T*/
/*!\page CycletimePage Zykluszeiten

\section sec_CycletimePage_MRW420 'Applikation MRW420'

<table border=1 width=100% height=1% rules=rows cellspacing=0 bgcolor="#E0E0F0">

<tr align=left valign=top>
	<th>Minimale Durchlaufzeit</th>
	<th>Maximale Durchlaufzeit</th>
</tr>

<tr>
	<td>--- <B>ms</B></td>
	<td>--- <B>ms</B></td>
</tr></table>

*/
/*~E:A6*/
/*~A:7*/
/*~+:Verschiedenes*/
/*~T*/
/*!\page MiscPage Verschiedenes

\section sec_MiscPage_MRW420 'Applikation MRW420'

<table border=1 width=100% height=1% rules=rows cellspacing=0 bgcolor="#E0E0F0">

<tr align=left valign=top>
	<th>Benutzte Interrups</th>
	<th>Benutzte Registerb�nke</th>
</tr>

<tr>
	<td>4,6</td>
	<td>---</td>
</tr></table>

*/
/*~E:A7*/
/*~A:8*/
/*~+:Lifecycle*/
/*~T*/
/*!\page LifeCyclePage Lifecycle

\section sec_LifeCyclePage_MRW420 'Applikation MRW420'

<table border=1 width=100% height=1% rules=rows cellspacing=0 bgcolor="#E0E0F0">

<tr align=left valign=top>
	<th>Version</th>
	<th>Datum</th>
	<th>Programmierer</th>
	<th>�nderungen</th>
</tr>

<tr>
	<td>1.000</td>
	<td>04.08.08</td>
	<td>Michael Offenbach</td>
	<td>Erste lauff�hige Version</td>
</tr>

<tr>
	<td>1.001</td>
	<td>29.11.21</td>
	<td>Michael Offenbach</td>
	<td>Update zu V1.103</td>
</tr>
</table>

*/
/*~E:A8*/
/*~E:A1*/
/*~K*/
/*~+:*/
/*~A:9*/
/*~+:Includes*/
/*~T*/
#include "Global.h"
#include "Version.h"
#include <Stdlib.h>
#include <Stdio.h>
#include <String.h>
/*~E:A9*/
/*~T*/
extern SPI_T SPI;
/*~A:10*/
/*~+:Funktionseigene Definitionen*/
/*~T*/

/*~E:A10*/
/*~A:11*/
/*~+:Funktionseigene Struktur-Definitionen*/
/*~T*/

/*~E:A11*/
/*~A:12*/
/*~+:Funktionsprototypen*/
/*~I:13*/
#ifdef SYSTEM_CND_PRINT_SPI_ERRORS
/*~T*/
void Main_Check4SPIErrors(void);

/*~-1*/
#endif
/*~E:I13*/
/*~T*/
void Main_ClearTimerFlags(void);
unsigned long Main_Init(void);
void Main_SetTimerFlags(void);
/*~K*/
/*~+:/~* Hinzugef�gt am 09.02.2022 *~/*/
/*~T*/
unsigned long Main_UpdateRetains(void);
/*~K*/
/*~+:/~* Ende - Hinzugef�gt am 09.02.2022 *~/*/
/*~E:A12*/
/*~A:14*/
/*~+:Globale Variablen*/
/*~T*/

/*~E:A14*/
/*~A:15*/
/*~+:void Main(void)*/
/*~F:16*/
void Main(void)
/*~-1*/
{
   /*~A:17*/
   /*~+:Variablendeklarationen*/
   /*~T*/
   unsigned char 	*ptrTest;					// Speicherplatzpr�fung 'Dynamische Variablen'
   unsigned char 	byFailed;
   unsigned char 	byCounter;
   /*~I:18*/
#ifdef CHANNEL_0
   /*~T*/
   unsigned char 	byInitializationReady;
   unsigned char 	byPrintState;

   /*~-1*/
#endif
   /*~E:I18*/
   /*~E:A17*/
   /*~I:19*/
#ifdef DEVELOPMENT_SW
   /*~T*/
   DPP = 0;
   /*~-1*/
#endif
   /*~E:I19*/
   /*~A:20*/
   /*~+:Variableninitialisierungen*/
   /*~T*/
   byFailed = 0;
   byCounter = 3;
   /*~I:21*/
#ifdef CHANNEL_0
   /*~T*/
   byInitializationReady = 0;
   byPrintState = 0;
   /*~-1*/
#endif
   /*~E:I21*/
   /*~E:A20*/
   /*~T*/
   // Interne Taktrate: 12 MHz
   PLLCON = 0;
   /*~T*/
   // Dynamischen Speicherbereich festlegen
   init_mempool(ptrDynVar,sizeof(ptrDynVar));
   /*~A:22*/
   /*~+:Initialisierung*/
   /*~I:23*/
   if (!Main_Init())
   /*~-1*/
   {
      /*~T*/
      // Intialisierung fehlerfrei abgelaufen
      /*~A:24*/
      /*~+:ausgeklammert*/
      /*~I:25*/
#ifdef MOF
      /*~I:26*/
#ifdef CHANNEL_0
      /*~I:27*/
      if (!SYSTEM_MRW_MANAGER)
      /*~-1*/
      {
         /*~T*/
         Communication_SendString(COMMUNICATION_RS232,T_TEXT_SYSTEM_INITIALISATION,1,0);

         Communication_SendString(COMMUNICATION_RS232,T_TEXT_2_OKAY,0,0);
      /*~-1*/
      }
      /*~E:I27*/
      /*~-1*/
#endif
      /*~E:I26*/
      /*~-1*/
#endif
      /*~E:I25*/
      /*~E:A24*/
   /*~-1*/
   }
   /*~O:I23*/
   /*~-2*/
   else
   {
      /*~T*/
      // Fehler bei der Initialisierung
      /*~A:28*/
      /*~+:ausgeklammert*/
      /*~I:29*/
#ifdef MOF
      /*~I:30*/
#ifdef CHANNEL_0
      /*~I:31*/
      if (!SYSTEM_MRW_MANAGER)
      /*~-1*/
      {
         /*~T*/
         Communication_SendMessage(COMMUNICATION_RS232,COMMUNICATION_NOK);
      /*~-1*/
      }
      /*~O:I31*/
      /*~-2*/
      else
      {
         /*~T*/
         Communication_SendString(COMMUNICATION_RS232,T_TEXT_SYSTEM_INITIALISATION,1,0);

         Communication_SendString(COMMUNICATION_RS232,T_TEXT_SYSTEM_INITIALISATION_ERROR,0,0);
      /*~-1*/
      }
      /*~E:I31*/
      /*~-1*/
#endif
      /*~E:I30*/
      /*~-1*/
#endif
      /*~E:I29*/
      /*~E:A28*/
      /*~T*/
      Diagnosis_SecurityInitialization(SYTEM_ERROR_INITIALIZATION);
   /*~-1*/
   }
   /*~E:I23*/
   /*~E:A22*/
   /*~K*/
   /*~+:/~* Hinzugef�gt am 09.02.2022 *~/*/
   /*~T*/
   /* Eeprom-Reorganisation falls notwendig */
   Main_UpdateRetains();
   /*~K*/
   /*~+:/~* Ende - Hinzugef�gt am 09.02.2022 *~/*/
   /*~A:32*/
   /*~+:Watchdog-�berwachung einschalten*/
   /*~T*/
   Watchdog_Ini();
   /*~E:A32*/
   /*~I:33*/
   /* ausgeklammert ab Version V1.009 */
#ifdef MOF
   /*~A:34*/
   /*~+:Docklight-Modus einschalten*/
   /*~T*/
   // Wenn das Docklight-Terminal angeschlossen ist, in den Docklight-Modus schalten

   /*~I:35*/
#ifdef CHANNEL_0
   /*~T*/
   // Wenn das Docklight-Terminal angeschlossen ist, in den Docklight-Modus schalten

   /*~I:36*/
#ifdef MIT_CRC16
   /*~T*/
   // Doch zun�chst die CRC16-Pr�fung ausschalten
   Communication_EnableCRC16(FALSE);

   /*~-1*/
#endif
   /*~E:I36*/
   /*~T*/
   Communication_SendString(COMMUNICATION_RS232,"ISDL",1,0);
   /*~I:37*/
#ifdef MIT_CRC16
   /*~T*/
   // Die CRC16-Pr�fung wieder einschalten
   Communication_EnableCRC16(TRUE);

   /*~-1*/
#endif
   /*~E:I37*/
   /*~T*/
   byFailed = 0;
   /*~U:38*/
   /*~-2*/
   do
   {
      /*~T*/
      System_Wait(100);
      /*~T*/
      InstructionDecoder();
   /*~-1*/
   }
   /*~O:U38*/
   /* neu ab Version V1.009 */
   while ((SYSTEM_MRW_MANAGER)&&(byFailed++ < 2));
   /* bis Version V1.008
   while ((SYSTEM_MRW_MANAGER)&&(byFailed++ < 5));
    */
   /*~E:U38*/
   /*~-1*/
#endif
   /*~E:I35*/
   /*~E:A34*/
   /*~-1*/
#endif
   /*~E:I33*/
   /*~A:39*/
   /*~+:Flags zur Signalisierung eines neuen Kommandos l�schen*/
   /*~T*/
   // Flags zur Signalisierung eines neuen Kommandos l�schen
   ADuC836_RS232SetNewCommandFlag(0);
   /*~E:A39*/
   /*~A:40*/
   /*~+:�berpr�fung, ob gen�gend dynamische Speicher vorhanden ist.*/
   /*~I:41*/
#ifdef CHANNEL_0
   /*~I:42*/
   if (!SYSTEM_MRW_MANAGER)
   /*~-1*/
   {
      /*~T*/
      Communication_SendString(COMMUNICATION_RS232,T_TEXT_SYSTEM_CHECK_DYNAMIC_VARIABLES_MEMORY,1,0);
   /*~-1*/
   }
   /*~E:I42*/
   /*~-1*/
#endif
   /*~E:I41*/
   /*~I:43*/
   ptrTest = (unsigned char*)malloc(1);

   if ((unsigned char)ptrTest == 0)
   /*~-1*/
   {
      /*~A:44*/
      /*~+:Nicht genug dynamischer Speicher vorhanden*/
      /*~I:45*/
#ifdef CHANNEL_0
      /*~I:46*/
      if (SYSTEM_MRW_MANAGER)
      /*~-1*/
      {
         /*~T*/
         Communication_SendMessage(COMMUNICATION_RS232,COMMUNICATION_NOK);
      /*~-1*/
      }
      /*~O:I46*/
      /*~-2*/
      else
      {
         /*~T*/
         Communication_SendString(COMMUNICATION_RS232,T_TEXT_SYSTEM_NOT_ENOUGH_MEMORY_4_DYNAMIC_VARIABLES,0,0);
      /*~-1*/
      }
      /*~E:I46*/
      /*~-1*/
#endif
      /*~E:I45*/
      /*~T*/
      Diagnosis_SecurityMemory(DYNAMIC_VARIABLES);
      /*~T*/
      // System-Reset ausf�hren
      System_Reset();
      /*~E:A44*/
   /*~-1*/
   }
   /*~O:I43*/
   /*~-2*/
   else
   {
      /*~A:47*/
      /*~+:okay*/
      /*~I:48*/
#ifdef CHANNEL_0
      /*~I:49*/
      if (!SYSTEM_MRW_MANAGER)
      /*~-1*/
      {
         /*~T*/
         Communication_SendString(COMMUNICATION_RS232,T_TEXT_2_OKAY,0,0);
      /*~-1*/
      }
      /*~E:I49*/
      /*~-1*/
#endif
      /*~E:I48*/
      /*~E:A47*/
   /*~-1*/
   }
   /*~E:I43*/
   /*~T*/
   free(ptrTest);
   /*~E:A40*/
   /*~I:50*/
#ifndef NO_STARTSYNC 
   /*~A:51*/
   /*~+:Synchronisation*/
   /*~A:52*/
   /*~+:Textausgabe Kanal 0*/
   /*~I:53*/
#ifdef CHANNEL_0
   /*~I:54*/
   if (!SYSTEM_MRW_MANAGER)
   /*~-1*/
   {
      /*~T*/
      Communication_SendString(COMMUNICATION_RS232,T_TEXT_SYSTEM_CHECK_SYNCHRONISATION,1,0);
   /*~-1*/
   }
   /*~E:I54*/
   /*~-1*/
#endif
   /*~E:I53*/
   /*~E:A52*/
   /*~T*/
   System_Synchronization();
   /*~T*/
   // Synchronisation abgeschlossen
   /*~A:55*/
   /*~+:Textausgabe Kanal 0*/
   /*~I:56*/
#ifdef CHANNEL_0
   /*~I:57*/
   if (!SYSTEM_MRW_MANAGER)
   /*~-1*/
   {
      /*~T*/
      Communication_SendString(COMMUNICATION_RS232,T_TEXT_2_OKAY,0,0);
   /*~-1*/
   }
   /*~E:I57*/
   /*~-1*/
#endif
   /*~E:I56*/
   /*~E:A55*/
   /*~E:A51*/
   /*~-1*/
#endif
   /*~E:I50*/
   /*~A:58*/
   /*~+:�berpr�fung auf vorhandene System-ID */
   /*~I:59*/
#ifdef CHANNEL_0
   /*~I:60*/
   if (!SYSTEM_MRW_MANAGER)
   /*~-1*/
   {
      /*~T*/
      Communication_SendString(COMMUNICATION_RS232,T_TEXT_SYSTEM_CHECK_ID,1,0);
   /*~-1*/
   }
   /*~E:I60*/
   /*~I:61*/
   if (!Global.ulSystemID)
   /*~-1*/
   {
      /*~A:62*/
      /*~+:Keine ID vergeben*/
      /*~I:63*/
      if (SYSTEM_MRW_MANAGER)
      /*~-1*/
      {
         /*~T*/
         Communication_SendMessage(COMMUNICATION_RS232,COMMUNICATION_NOK);
      /*~-1*/
      }
      /*~O:I63*/
      /*~-2*/
      else
      {
         /*~T*/
         Communication_SendString(COMMUNICATION_RS232,T_TEXT_SYSTEM_ID_MISSING,0,0);
      /*~-1*/
      }
      /*~E:I63*/
      /*~A:64*/
      /*~+:Eintrag in Diagnosespeicher vornehmen*/
      /*~T*/
      Diagnosis_WriteMessage2Flash(DIAGNOSIS_ERROR_ID);
      /*~E:A64*/
      /*~I:65*/
#ifdef SPAETER_WIEDER_EINBAUEN
      /*~L:66*/
      while (!Global.ulSystemID)
      /*~-1*/
      {
         /*~T*/
         // Systemfehler
         System_SetSystemState(SYSTEM_ERROR);
         /*~T*/
         InstructionDecoder();
         Digital();						///< Digitalkan�le zur Anzeige des System-Alarms
      /*~-1*/
      }
      /*~E:L66*/
      /*~-1*/
#endif
      /*~E:I65*/
      /*~E:A62*/
   /*~-1*/
   }
   /*~O:I61*/
   /*~-2*/
   else
   {
      /*~A:67*/
      /*~+:ID vorhanden*/
      /*~I:68*/
      if (!SYSTEM_MRW_MANAGER)
      /*~-1*/
      {
         /*~T*/
         // Communication_SendString(COMMUNICATION_RS232,T_TEXT_2_OKAY,0,0);
         Communication_SendLong(COMMUNICATION_RS232,0,(long)Global.ulSystemID,0,0);
      /*~-1*/
      }
      /*~E:I68*/
      /*~E:A67*/
   /*~-1*/
   }
   /*~E:I61*/
   /*~-1*/
#endif
   /*~E:I59*/
   /*~E:A58*/
   /*~I:69*/
   /* neu ab Version V1.009 */
#ifdef PRUEFE_SW_VERSIONEN 
   /*~A:70*/
   /*~+:�berpr�fung der Software-Versionen*/
   /*~I:71*/
#ifndef NO_VERSIONCHECK
   /*~I:72*/
#ifdef CHANNEL_0
   /*~I:73*/
   if (!SYSTEM_MRW_MANAGER)
   /*~-1*/
   {
      /*~T*/
      Communication_SendString(COMMUNICATION_RS232,T_TEXT_SYSTEM_CHECK_SOFTWARE_VERSIONS,1,0);
      /*~I:74*/
      if (System_CheckVersion())
      /*~-1*/
      {
         /*~A:75*/
         /*~+:Fehler bei der Versionspr�fung*/
         /*~A:76*/
         /*~+:Eintrag in Diagnosespeicher vornehmen*/
         /*~T*/
         Diagnosis_WriteMessage2Flash(DIAGNOSIS_ERROR_SOFTWARE_INCOMPATIBILITY);
         /*~E:A76*/
         /*~I:77*/
#ifdef CHANNEL_0
         /*~I:78*/
         if (SYSTEM_MRW_MANAGER)
         /*~-1*/
         {
            /*~T*/
            Communication_SendMessage(COMMUNICATION_RS232,COMMUNICATION_NOK);
         /*~-1*/
         }
         /*~O:I78*/
         /*~-2*/
         else
         {
            /*~T*/
            Communication_SendString(COMMUNICATION_RS232,T_TEXT_SYSTEM_SOFTWARE_INCOMPATIBLE,0,0);
         /*~-1*/
         }
         /*~E:I78*/
         /*~-1*/
#endif
         /*~E:I77*/
         /*~L:79*/
         while (1)
         /*~-1*/
         {
            /*~T*/
            // Systemfehler
            System_SetSystemState(SYSTEM_ERROR);
            /*~T*/
            InstructionDecoder();			///< Instruction-Dekoder wg. der M�glichkeit, sich den Diagnosespeicher anzusehen
            Digital();						///< Digitalkan�le zur Anzeige des System-Alarms
         /*~-1*/
         }
         /*~E:L79*/
         /*~E:A75*/
      /*~-1*/
      }
      /*~O:I74*/
      /*~-2*/
      else
      {
         /*~A:80*/
         /*~+:Softwaren sind kompatibel*/
         /*~I:81*/
#ifdef CHANNEL_0
         /*~I:82*/
         if (!SYSTEM_MRW_MANAGER)
         /*~-1*/
         {
            /*~T*/
            Communication_SendString(COMMUNICATION_RS232,T_TEXT_2_OKAY,0,0);
         /*~-1*/
         }
         /*~E:I82*/
         /*~-1*/
#endif
         /*~E:I81*/
         /*~E:A80*/
      /*~-1*/
      }
      /*~E:I74*/
   /*~-1*/
   }
   /*~E:I73*/
   /*~-1*/
#endif
   /*~E:I72*/
   /*~-1*/
#endif
   /*~E:I71*/
   /*~E:A70*/
   /*~-1*/
#endif
   /*~E:I69*/
   /*~A:83*/
   /*~+:Systemstart f�r Diagnose merken*/
   /*~T*/
   /* Systemstart f�r Diagnose merken */
   Diagnosis_SetSystemStart();
   /*~E:A83*/
   /*~I:84*/
   /* ausgeklammert ab Version V1.009 */
#ifdef MOF
   /*~A:85*/
   /*~+:Alles okay - SW-Versionen,Zellentyp,... ausgeben*/
   /*~T*/
   Diagnosis_SetSystemStart();
   /*~I:86*/
#ifdef CHANNEL_0
   /*~I:87*/
   if (SYSTEM_MRW_MANAGER)
   /*~-1*/
   {
      /*~T*/
      Communication_SendMessage(COMMUNICATION_RS232,COMMUNICATION_OK);
   /*~-1*/
   }
   /*~O:I87*/
   /*~-2*/
   else
   {
      /*~U:88*/
      /*~-2*/
      do
      {
         /*~C:89*/
         switch (byPrintState)
         /*~-1*/
         {
            /*~F:90*/
            case 0:
            /*~-1*/
            {
               /*~A:91*/
               /*~+:Hardware-Version ausgeben*/
               /*~T*/
               Communication_SendString(COMMUNICATION_RS232,T_TEXT_MOBA_AG_HW,2,0);
               /*~T*/
               Communication_SendString(COMMUNICATION_RS232,TEXT_HARDWARE_VERSION,0,1);
               /*~E:A91*/
               /*~T*/
               break;
            /*~-1*/
            }
            /*~E:F90*/
            /*~F:92*/
            case 1:
            /*~-1*/
            {
               /*~A:93*/
               /*~+:Software-Modul-Versionen ausgeben*/
               /*~T*/
               Version_PrintVersions(1);
               /*~E:A93*/
               /*~T*/
               break;
            /*~-1*/
            }
            /*~E:F92*/
            /*~F:94*/
            case 2:
            /*~-1*/
            {
               /*~A:95*/
               /*~+:Zellentyp ausgeben*/
               /*~T*/
               Communication_SendString(COMMUNICATION_RS232,T_TEXT_LOADCELL_TYPE,1,0);

               /*~C:96*/
               switch (g_SystemControl.byLoadCellType)
               /*~-1*/
               {
                  /*~F:97*/
                  case 1:
                  /*~-1*/
                  {
                     /*~T*/
                     Communication_SendString(COMMUNICATION_RS232,"Std-W�gezelle",0,0);

                     /*~T*/
                     break;
                  /*~-1*/
                  }
                  /*~E:F97*/
                  /*~F:98*/
                  case 2:
                  /*~-1*/
                  {
                     /*~T*/
                     Communication_SendString(COMMUNICATION_RS232,"XL-W�gezelle",0,0);

                     /*~T*/
                     break;
                  /*~-1*/
                  }
                  /*~E:F98*/
                  /*~O:C96*/
                  /*~-2*/
                  default:
                  {
                     /*~T*/
                     Communication_SendString(COMMUNICATION_RS232,"nicht definiert",0,0);

                  /*~-1*/
                  }
               /*~-1*/
               }
               /*~E:C96*/
               /*~E:A95*/
               /*~T*/
               break;
            /*~-1*/
            }
            /*~E:F94*/
            /*~F:99*/
            case 3:
            /*~-1*/
            {
               /*~A:100*/
               /*~+:Status der Temperaturkompensation*/
               /*~I:101*/
               if (MRW_Compensation_GetCompensationOnOffStatus())
               /*~-1*/
               {
                  /*~T*/
                  Communication_SendString(COMMUNICATION_RS232,T_TEXT_COMPENSATION_SWITCHED_ON,2,0);

               /*~-1*/
               }
               /*~O:I101*/
               /*~-2*/
               else
               {
                  /*~T*/
                  Communication_SendString(COMMUNICATION_RS232,T_TEXT_COMPENSATION_SWITCHED_OFF,2,0);

               /*~-1*/
               }
               /*~E:I101*/
               /*~E:A100*/
               /*~T*/
               break;
            /*~-1*/
            }
            /*~E:F99*/
            /*~F:102*/
            case 4:
            /*~-1*/
            {
               /*~A:103*/
               /*~+:Status der E-Modul-Kompensation*/
               /*~I:104*/
               if (Weight_GetEModulCompensationOnOff())
               /*~-1*/
               {
                  /*~T*/
                  Communication_SendString(COMMUNICATION_RS232,T_TEXT_E_MODUL_COMPENSATION_SWITCHED_ON,1,0);

               /*~-1*/
               }
               /*~O:I104*/
               /*~-2*/
               else
               {
                  /*~T*/
                  Communication_SendString(COMMUNICATION_RS232,T_TEXT_E_MODUL_COMPENSATION_SWITCHED_OFF,1,0);

               /*~-1*/
               }
               /*~E:I104*/
               /*~E:A103*/
               /*~T*/
               break;
            /*~-1*/
            }
            /*~E:F102*/
            /*~F:105*/
            case 5:
            /*~-1*/
            {
               /*~A:106*/
               /*~+:Status der Stromr�ckf�hrung*/
               /*~I:107*/
               if (CurrentInterface_GetFeedBackState())
               /*~-1*/
               {
                  /*~T*/
                  Communication_SendString(COMMUNICATION_RS232,T_TEXT_FEEDBACK_STATE_ON,1,0);

               /*~-1*/
               }
               /*~O:I107*/
               /*~-2*/
               else
               {
                  /*~T*/
                  Communication_SendString(COMMUNICATION_RS232,T_TEXT_FEEDBACK_STATE_OFF,1,0);

               /*~-1*/
               }
               /*~E:I107*/
               /*~E:A106*/
               /*~T*/
               break;
            /*~-1*/
            }
            /*~E:F105*/
         /*~-1*/
         }
         /*~E:C89*/
         /*~T*/
         // Da alle Ausgaben zusammen recht lange dauern, zyklisch den Watchdog neu antriggern
         Watchdog();
      /*~-1*/
      }
      /*~O:U88*/
      while (byPrintState++ < 0x06);
      /*~E:U88*/
   /*~-1*/
   }
   /*~E:I87*/
   /*~-1*/
#endif
   /*~E:I86*/
   /*~E:A85*/
   /*~A:108*/
   /*~+:ggf. in den Docklight-Modus wechseln*/
   /*~I:109*/
#ifdef CHANNEL_0
   /*~I:110*/
   if (!SYSTEM_MRW_MANAGER)
   /*~-1*/
   {
      /*~I:111*/
#ifdef SYSTEM_CND_DISABLE_SPI_COMMUNICATION_AT_FAULTS 
      /*~A:112*/
      /*~+:Mit Abschaltung der SPI-Kommunikation bei Ausfall der SPI-Schnittstelle*/
      /*~I:113*/
      if (!Communication_IsSPICommuncationDisabled())
      /*~-1*/
      {
         /*~U:114*/
         /*~-2*/
         do
         {
            /*~T*/
            Communication_SendSPICommand("iCDL");
         /*~-1*/
         }
         /*~O:U114*/
         while (!Communication_IsOK() && --byCounter);
         /*~E:U114*/
      /*~-1*/
      }
      /*~E:I113*/
      /*~E:A112*/
      /*~O:I111*/
      /*~-1*/
#else
      /*~A:115*/
      /*~+:Ohne Abschaltung der SPI-Kommunikation bei Ausfall der SPI-Schnittstelle*/
      /*~U:116*/
      /*~-2*/
      do
      {
         /*~T*/
         Communication_SendSPICommand("iCDL");
      /*~-1*/
      }
      /*~O:U116*/
      while (!Communication_IsOK() && --byCounter);
      /*~E:U116*/
      /*~E:A115*/
      /*~-1*/
#endif
      /*~E:I111*/
   /*~-1*/
   }
   /*~E:I110*/
   /*~T*/
   // Z�hler f�r sp�tere Benutzung l�schen
   byCounter = 0;
   /*~-1*/
#endif
   /*~E:I109*/
   /*~E:A108*/
   /*~-1*/
#endif
   /*~E:I84*/
   /*~A:117*/
   /*~+:RS232-Empfangspuffer l�schen*/
   /*~T*/
   ADuC836_RS232SetNewCommandFlag(0);
   /*~E:A117*/
   /*~T*/
   System_SetSystemState(SYSTEM_RUNNING);
   /*~I:118*/
#ifdef CHANNEL_0
   /*~A:119*/
   /*~+:Wenn das Docklight-Terminal angeschlossen ist, in den Docklight-Modus schalten*/
   /*~T*/
   // Wenn das Docklight-Terminal angeschlossen ist, in den Docklight-Modus schalten

   /*~I:120*/
#ifdef MIT_CRC16
   /*~T*/
   // Doch zun�chst die CRC16-Pr�fung ausschalten
   Communication_EnableCRC16(FALSE);

   /*~-1*/
#endif
   /*~E:I120*/
   /*~T*/
   // Noch etwas auf den Slave warten
   ADuC836_TimerDelay(300);
   /*~T*/
   Communication_SendString(COMMUNICATION_RS232,"ISDL",1,0);
   /*~I:121*/
#ifdef MIT_CRC16 
   /*~T*/
   // Jetzt die die CRC16-Pr�fung wieder zuschalten
   Communication_EnableCRC16(TRUE);
   /*~-1*/
#endif
   /*~E:I121*/
   /*~E:A119*/
   /*~-1*/
#endif
   /*~E:I118*/
   /*~K*/
   /*~+:*/
   /*~+:*/
   /*~+:// E N D L E S S L O O P //*/
   /*~+:*/
   /*~L:122*/
   while (1)
   /*~-1*/
   {
      /*~A:123*/
      /*~+:LED-Anzeige zur Zykluszeitermittlung*/
      /*~I:124*/
#ifdef SYSTEM_CND_LEDS_4_DEBUG_P06_CYCLETIME
      /*~T*/
      P06 = !P06;
      /*~-1*/
#endif
      /*~E:I124*/
      /*~E:A123*/
      /*~A:125*/
      /*~+:Zeitflags setzen*/
      /*~T*/
      // Zeitflags setzen
      Main_SetTimerFlags();
      /*~E:A125*/
      /*~K*/
      /*~+:*/
      /*~A:126*/
      /*~+:ausgeklammert - NUR_ZU_TESTZWECKEN*/
      /*~I:127*/
#ifdef NUR_ZU_TESTZWECKEN
      /*~I:128*/
      // Untersuchung des Kanal 1
      if (i == 1)// Nur Kanal 1
      /*~-1*/
      {
         /*~I:129*/
         if (ADuC836_SPIIsNewCommand())
         /*~-1*/
         {
            /*~I:130*/
            if (j++ >= 2)
            /*~-1*/
            {
               /*~T*/
               j = 0;
               /*~T*/
               ADuC836_TimerDelay(20);
            /*~-1*/
            }
            /*~E:I130*/
         /*~-1*/
         }
         /*~E:I129*/
      /*~-1*/
      }
      /*~E:I128*/
      /*~-1*/
#endif
      /*~E:I127*/
      /*~E:A126*/
      /*~T*/
      ADuC836();
      Analog();						///< Analogeing�nge
      Weight();

      /*~I:131*/
#ifndef SPEZIALVERSION_FUER_TESTSYSTEME
      /*~T*/
      // CurrentInterface(Weight_ZeroCorrectedMeasurement.nLong);			///< ohne Tara
      CurrentInterface(Weight_ZeroCorrectedMeasurementWithTare.nLong + g_lWeightOffset4Limitest);	///< Stromausgang
      /*~O:I131*/
      /*~-1*/
#else
      /*~T*/
      CurrentInterface(g_Weight_lSimulatedRMW); // Stromausgang mit vorgegebenem Stromwert setzen
      /*~-1*/
#endif
      /*~E:I131*/
      /*~T*/
      System();						///< Systemparameter austauschen
      Compensation();					///< Temperaturkompensation
      Digital();						///< Digitalkan�le
      InstructionDecoder();			///< Befehlsbearbeitung
      /*~I:132*/
      if (Flag100ms)
      /*~-1*/
      {
         /*~A:133*/
         /*~+:Alle 100ms: Grenzwertbetrachtung*/
         /*~T*/
         Limit();						///< Grenzwert�berwachung
         /*~A:134*/
         /*~+:bis Version V1.008*/
         /*~F:135*/
         /* bis Version V1.008 */

         /*~-1*/
         {
            /*~I:136*/
#ifdef MOF
            /*~T*/
            Watchdog();						///< Watchdog

            /*~-1*/
#endif
            /*~E:I136*/
         /*~-1*/
         }
         /*~E:F135*/
         /*~E:A134*/
         /*~E:A133*/
      /*~-1*/
      }
      /*~E:I132*/
      /*~K*/
      /*~+:*/
      /*~I:137*/
      if (Flag300ms)
      /*~-1*/
      {
         /*~A:138*/
         /*~+:Alle 300ms: Statistik, einmalig die Ausgabe der Softwareversionen*/
         /*~F:139*/
         /* neu ab Version V1.009 */
         /*~-1*/
         {
            /*~A:140*/
            /*~+:Kanal 0: Beim zweiten Eintreffen SW-Versionen,Zellentyp,... im Docklightmodus ausgeben*/
            /*~I:141*/
#ifdef CHANNEL_0
            /*~C:142*/
            switch (byInitializationReady)
            /*~-1*/
            {
               /*~F:143*/
               case 0:
               /*~-1*/
               {
                  /*~T*/
                  byInitializationReady++;
                  /*~T*/
                  break;
               /*~-1*/
               }
               /*~E:F143*/
               /*~F:144*/
               case 1:
               /*~-1*/
               {
                  /*~T*/
                  byInitializationReady++;
                  /*~I:145*/
                  if (!SYSTEM_MRW_MANAGER)
                  /*~-1*/
                  {
                     /*~U:146*/
                     /*~-2*/
                     do
                     {
                        /*~C:147*/
                        switch (byPrintState)
                        /*~-1*/
                        {
                           /*~F:148*/
                           case 0:
                           /*~-1*/
                           {
                              /*~A:149*/
                              /*~+:Hardware-Version ausgeben*/
                              /*~T*/
                              Communication_SendString(COMMUNICATION_RS232,T_TEXT_MOBA_AG_HW,2,0);
                              /*~T*/
                              Communication_SendString(COMMUNICATION_RS232,TEXT_HARDWARE_VERSION,0,1);
                              /*~E:A149*/
                              /*~T*/
                              break;
                           /*~-1*/
                           }
                           /*~E:F148*/
                           /*~F:150*/
                           case 1:
                           /*~-1*/
                           {
                              /*~A:151*/
                              /*~+:Software-Modul-Versionen ausgeben*/
                              /*~T*/
                              Version_PrintVersions(1);
                              /*~E:A151*/
                              /*~T*/
                              break;
                           /*~-1*/
                           }
                           /*~E:F150*/
                           /*~F:152*/
                           case 2:
                           /*~-1*/
                           {
                              /*~A:153*/
                              /*~+:Zellentyp ausgeben*/
                              /*~T*/
                              Communication_SendString(COMMUNICATION_RS232,T_TEXT_LOADCELL_TYPE,1,0);

                              /*~C:154*/
                              switch (g_SystemControl.byLoadCellType)
                              /*~-1*/
                              {
                              /*~F:155*/
                              case 1:
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendString(COMMUNICATION_RS232,"Std-W�gezelle",0,0);

                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F155*/
                              /*~F:156*/
                              case 2:
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendString(COMMUNICATION_RS232,"XL-W�gezelle",0,0);

                              /*~T*/
                              break;
                              /*~-1*/
                              }
                              /*~E:F156*/
                              /*~O:C154*/
                              /*~-2*/
                              default:
                              {
                              /*~T*/
                              Communication_SendString(COMMUNICATION_RS232,"nicht definiert",0,0);

                              /*~-1*/
                              }
                              /*~-1*/
                              }
                              /*~E:C154*/
                              /*~E:A153*/
                              /*~T*/
                              break;
                           /*~-1*/
                           }
                           /*~E:F152*/
                           /*~F:157*/
                           case 3:
                           /*~-1*/
                           {
                              /*~A:158*/
                              /*~+:Status der Temperaturkompensation*/
                              /*~I:159*/
                              if (MRW_Compensation_GetCompensationOnOffStatus())
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendString(COMMUNICATION_RS232,T_TEXT_COMPENSATION_SWITCHED_ON,2,0);

                              /*~-1*/
                              }
                              /*~O:I159*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              Communication_SendString(COMMUNICATION_RS232,T_TEXT_COMPENSATION_SWITCHED_OFF,2,0);

                              /*~-1*/
                              }
                              /*~E:I159*/
                              /*~E:A158*/
                              /*~T*/
                              break;
                           /*~-1*/
                           }
                           /*~E:F157*/
                           /*~F:160*/
                           case 4:
                           /*~-1*/
                           {
                              /*~A:161*/
                              /*~+:Status der E-Modul-Kompensation*/
                              /*~I:162*/
                              if (Weight_GetEModulCompensationOnOff())
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendString(COMMUNICATION_RS232,T_TEXT_E_MODUL_COMPENSATION_SWITCHED_ON,1,0);

                              /*~-1*/
                              }
                              /*~O:I162*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              Communication_SendString(COMMUNICATION_RS232,T_TEXT_E_MODUL_COMPENSATION_SWITCHED_OFF,1,0);

                              /*~-1*/
                              }
                              /*~E:I162*/
                              /*~E:A161*/
                              /*~T*/
                              break;
                           /*~-1*/
                           }
                           /*~E:F160*/
                           /*~F:163*/
                           case 5:
                           /*~-1*/
                           {
                              /*~A:164*/
                              /*~+:Status der Stromr�ckf�hrung*/
                              /*~I:165*/
                              if (CurrentInterface_GetFeedBackState())
                              /*~-1*/
                              {
                              /*~T*/
                              Communication_SendString(COMMUNICATION_RS232,T_TEXT_FEEDBACK_STATE_ON,1,0);

                              /*~-1*/
                              }
                              /*~O:I165*/
                              /*~-2*/
                              else
                              {
                              /*~T*/
                              Communication_SendString(COMMUNICATION_RS232,T_TEXT_FEEDBACK_STATE_OFF,1,0);

                              /*~-1*/
                              }
                              /*~E:I165*/
                              /*~E:A164*/
                              /*~T*/
                              break;
                           /*~-1*/
                           }
                           /*~E:F163*/
                           /*~F:166*/
                           case 6:
                           /*~-1*/
                           {
                              /*~I:167*/
#ifdef SYSTEM_CND_ADC_MIT_WANDLERRATENERMITTLUNG
                              /*~A:168*/
                              /*~+:Wandlungsrate der Gewichtsermittlung*/
                              /*~T*/
                              /* Die Wandlungsrate muss durch vier geteilt werden, da der ADC im Togglebetrieb l�uft. D.h. es wird nur mit bei jeder zweiten Wandlung der DMS-Messwert ermittelt - bei der anderen Messung der Rohmesswert der Stromr�ckf�hrung. Zudem wird bei jeder Umschaltung ein Reset der ADCs ausgef�hrt, was zur Folge hat, dass der Messwert erst nach zweiten Wandlung zur Verf�gung steht.
                              /*~T*/
                              Communication_SendFloat(COMMUNICATION_RS232,TEXT_WEIGHT_CONVERSIONRATE_CHANNEL_0,ADuC836_ADCGetConversionRate(ADuC836_ADC_FREQUENCY_32KHZ)/4,2,1,0);
                              /*~E:A168*/
                              /*~-1*/
#endif
                              /*~E:I167*/
                              /*~T*/
                              break;
                           /*~-1*/
                           }
                           /*~E:F166*/
                        /*~-1*/
                        }
                        /*~E:C147*/
                        /*~T*/
                        // Da alle Ausgaben zusammen recht lange dauern, zyklisch den Watchdog neu antriggern
                        Watchdog();
                     /*~-1*/
                     }
                     /*~O:U146*/
                     while (byPrintState++ < 0x07);
                     /*~E:U146*/
                  /*~-1*/
                  }
                  /*~E:I145*/
                  /*~T*/
                  break;
               /*~-1*/
               }
               /*~E:F144*/
            /*~-1*/
            }
            /*~E:C142*/
            /*~-1*/
#endif
            /*~E:I141*/
            /*~E:A140*/
         /*~-1*/
         }
         /*~E:F139*/
         /*~T*/
         Statistics();					///< Statistik
         /*~E:A138*/
      /*~-1*/
      }
      /*~E:I137*/
      /*~I:169*/
      if (Flag500ms)
      /*~-1*/
      {
         /*~F:170*/
         /* neu ab Version V1.009 */

         /*~-1*/
         {
            /*~A:171*/
            /*~+:Alle 500ms: Watchdog*/
            /*~T*/
            Watchdog();						///< Watchdog

            /*~E:A171*/
         /*~-1*/
         }
         /*~E:F170*/
      /*~-1*/
      }
      /*~E:I169*/
      /*~K*/
      /*~+:*/
      /*~I:172*/
      if (Flag1000ms)
      /*~-1*/
      {
         /*~A:173*/
         /*~+:Alle 1000ms: Betriebsstundenz�hler*/
         /*~T*/
         System_UpdateOperatingHours(0);	///< Betriebsstundenz�hler

         /*~I:174*/
#ifdef SYSTEM_CND_PRINT_SPI_ERRORS
         /*~T*/
         Main_Check4SPIErrors();
         /*~-1*/
#endif
         /*~E:I174*/
         /*~E:A173*/
      /*~-1*/
      }
      /*~E:I172*/
      /*~K*/
      /*~+:*/
      /*~I:175*/
      if (Flag2000ms)
      /*~-1*/
      {
         /*~A:176*/
         /*~+:Alle 2000ms: */
         /*~T*/

         /*~E:A176*/
      /*~-1*/
      }
      /*~E:I175*/
      /*~K*/
      /*~+:*/
      /*~I:177*/
      if (Flag10000ms)
      /*~-1*/
      {
         /*~I:178*/
#ifdef SYSTEM_CND_DISABLE_SPI_COMMUNICATION_AT_FAULTS
         /*~A:179*/
         /*~+:Mit Abschaltung der SPI-Kommunikation bei Ausfall der SPI-Schnittstelle - Wiederholungsz�hler der erfolgten Resets l�schen*/
         /*~T*/
         // Mit Abschaltung der SPI-Kommunikation bei Ausfall der SPI-Schnittstelle - Wiederholungsz�hler der erfolgten Resets l�schen
         /*~I:180*/
         if (byCounter++ >= 6)
         /*~-1*/
         {
            /*~T*/
            byCounter = 0;

            Communication_ClearSPIFaultCounter(1);
         /*~-1*/
         }
         /*~E:I180*/
         /*~E:A179*/
         /*~-1*/
#endif
         /*~E:I178*/
      /*~-1*/
      }
      /*~E:I177*/
      /*~A:181*/
      /*~+:Alle Zeitflags wieder l�schen*/
      /*~T*/
      // Alle Zeitflags wieder l�schen
      Main_ClearTimerFlags();
      /*~E:A181*/
   /*~-1*/
   }
   /*~E:L122*/
/*~-1*/
}
/*~E:F16*/
/*~E:A15*/
/*~I:182*/
#ifdef SYSTEM_CND_PRINT_SPI_ERRORS
/*~A:183*/
/*~+:void Main_Check4SPIErrors(void)*/
/*~F:184*/
void Main_Check4SPIErrors(void)
/*~-1*/
{
   /*~A:185*/
   /*~+:Variablendeklarationen*/
   /*~T*/
   // Variablendeklarationen
   SPI_ERRORBUFFER_T ErrorBuffer;
   /*~E:A185*/
   /*~A:186*/
   /*~+:Variableninitialisierungen*/
   /*~T*/
   // Variableninitialisierungen
   /*~E:A186*/
   /*~T*/
   ErrorBuffer = ADuC836_SPIGetErrors();
   /*~I:187*/
   if (ErrorBuffer.bNewError)
   /*~-1*/
   {
      /*~I:188*/
#ifdef CHANNEL_0
      /*~T*/
      Communication_SendLong(COMMUNICATION_RS232,TEXT_SPI_ERRORS_RECCHAR_CHANNEL_0,ErrorBuffer.uiErrorCounterSPI_RecChar,1,0);
      Communication_SendLong(COMMUNICATION_RS232,TEXT_SPI_ERRORS_SENDCHAR_CHANNEL_0,ErrorBuffer.uiErrorCounterSPI_SendChar,1,0);
      Communication_SendLong(COMMUNICATION_RS232,TEXT_SPI_ERRORS_WAIT4FRAME_CHANNEL_0,ErrorBuffer.uiErrorCounterSPI_WaitForFrame,1,0);
      Communication_SendLong(COMMUNICATION_RS232,TEXT_SPI_ERRORS_MISC_1_CHANNEL_0,ErrorBuffer.uiErrorCounterSPI_Misc_1,1,0);
      Communication_SendLong(COMMUNICATION_RS232,TEXT_SPI_ERRORS_MISC_2_CHANNEL_0,ErrorBuffer.uiErrorCounterSPI_Misc_2,1,1);
      /*~-1*/
#endif
      /*~E:I188*/
      /*~I:189*/
#ifdef CHANNEL_1
      /*~T*/
      Communication_SendLong(COMMUNICATION_RS232,TEXT_SPI_ERRORS_RECCHAR_CHANNEL_1,ErrorBuffer.uiErrorCounterSPI_RecChar,1,0);
      Communication_SendLong(COMMUNICATION_RS232,TEXT_SPI_ERRORS_SENDCHAR_CHANNEL_1,ErrorBuffer.uiErrorCounterSPI_SendChar,1,0);
      Communication_SendLong(COMMUNICATION_RS232,TEXT_SPI_ERRORS_WAIT4FRAME_CHANNEL_1,ErrorBuffer.uiErrorCounterSPI_WaitForFrame,1,0);
      Communication_SendLong(COMMUNICATION_RS232,TEXT_SPI_ERRORS_MISC_1_CHANNEL_1,ErrorBuffer.uiErrorCounterSPI_Misc_1,1,0);
      Communication_SendLong(COMMUNICATION_RS232,TEXT_SPI_ERRORS_MISC_2_CHANNEL_1,ErrorBuffer.uiErrorCounterSPI_Misc_2,1,1);
      /*~-1*/
#endif
      /*~E:I189*/
   /*~-1*/
   }
   /*~E:I187*/
/*~-1*/
}
/*~E:F184*/
/*~E:A183*/
/*~-1*/
#endif
/*~E:I182*/
/*~A:190*/
/*~+:void Main_ClearTimerFlags(void)*/
/*~F:191*/
void Main_ClearTimerFlags(void)
/*~-1*/
{
   /*~T*/
   Flag100ms = 0;
   Flag300ms = 0;
   Flag500ms = 0;
   Flag1000ms = 0;
   Flag2000ms = 0;
   Flag10000ms = 0;
/*~-1*/
}
/*~E:F191*/
/*~E:A190*/
/*~A:192*/
/*~+:unsigned long Main_Init(void)*/
/*~F:193*/
#pragma NOAREGS    // Wichtig f�r internen 2k-XDATA-RAM !!
unsigned long Main_Init(void)

/*~-1*/
{
   /*~A:194*/
   /*~+:Beschreibung*/
   /*~K*/
   /*~+:*/
   /*~E:A194*/
   /*~A:195*/
   /*~+:Variablendeklarationen*/
   /*~T*/
   unsigned long ulRetVal;
   unsigned long ulInititializationStep;
   unsigned char chCounter;
   unsigned char chIniMode;
   //   unsigned char byMeasurementDepth;

   unsigned long ulInitialIdentification = 0L;
   /*~E:A195*/
   /*~A:196*/
   /*~+:Variableninitialisierungen*/
   /*~T*/
   memset(&Global,0,sizeof(GLOBAL));
   /*~T*/
   ulRetVal = 0L;
   ulInititializationStep = 1L;
   chCounter = 0;
   ulInitialIdentification = 0;
   chIniMode = BYDEFAULT;
   /*~E:A196*/
   /*~A:197*/
   /*~+:Eeprom initialisieren*/
   /*~T*/
   Ee24c64_Init();
   Ee24c64_WriteEnable();
   /*~E:A197*/
   /*~A:198*/
   /*~+:Diagnose initialisieren*/
   /*~T*/
   Diagnosis_Ini();
   /*~E:A198*/
   /*~A:199*/
   /*~+:Kennung f�r eine Erstinbetriebnahme abfragen*/
   /*~U:200*/
   /*~-2*/
   do
   {
      /*~T*/
      Load_Parameter(LOAD_SAVE_INITIALIZE_IDENTIFICATION,(void*)&ulInitialIdentification,0);
      /*~I:201*/
      if (ulInitialIdentification == 0xA5A5A5A5)
      /*~-1*/
      {
         /*~T*/
         // Kennung gefunden - Parameter m�ssen im Eeprom liegen
         chCounter = 5;
         chIniMode = BYMEMORY; 
      /*~-1*/
      }
      /*~O:I201*/
      /*~-2*/
      else
      {
         /*~I:202*/
         if (ulInitialIdentification == 0xAAAA5555)
         /*~-1*/
         {
            /*~T*/
            // Neuinitialisierung
            chCounter = 5;
            chIniMode = REINITIALISATION;
            /*~T*/
            // Reinitialisierung

            // Kennung setzen
            ulInitialIdentification = 0xA5A5A5A5;

            Save_Parameter(LOAD_SAVE_INITIALIZE_IDENTIFICATION,&ulInitialIdentification,0);
         /*~-1*/
         }
         /*~O:I202*/
         /*~-2*/
         else
         {
            /*~I:203*/
            if (chCounter >= 4)
            /*~-1*/
            {
               /*~T*/
               // Erstinbetriebnahme

               // Kennung setzen
               ulInitialIdentification = 0xA5A5A5A5;

               Save_Parameter(LOAD_SAVE_INITIALIZE_IDENTIFICATION,&ulInitialIdentification,0);

               // Diagnosespeicher l�schen
               Diagnosis_ClearDiagnosis(DIAGNOSIS_CLEAR_ALL_BY_INITITALISATION);

               // System ID l�schen
               Global.ulSystemID = 0;

               Save_Parameter(LOAD_SAVE_SYSTEM_ID,&Global.ulSystemID,4);
            /*~-1*/
            }
            /*~E:I203*/
         /*~-1*/
         }
         /*~E:I202*/
      /*~-1*/
      }
      /*~E:I201*/
   /*~-1*/
   }
   /*~O:U200*/
   while (++chCounter < 5);
   /*~E:U200*/
   /*~E:A199*/
   /*~A:204*/
   /*~+:ADuC836-Bibliothek initialisieren*/
   /*~+:*/
   /*~T*/
   ///< ADuC836-Bibliothek initialisieren
   ADuC836_Ini();
   /*~E:A204*/
   /*~A:205*/
   /*~+:Messwert-Modul initialisieren*/
   /*~T*/
   Measurement_Init();
   /*~E:A205*/
   /*~A:206*/
   /*~+:ADC initialsieren*/
   /*~T*/
   // ADC mit Defaultwerten initialsieren


   // Hauptkanal mit folgenden Einstellungen initialisieren:
   // Messbereich +/-20mV
   // Bipolare Betriebsart
   // Eingangspins A1 und A2
   // Externe Referenzquelle
   // 19.79Hz Abtastrate
   // Togglebetrieb

   // 1.Hilfskanal mit folgenden Einstellungen initialisieren:
   // Bipolare Betriebsart
   // Temperatursensor als Messeingang
   // Interne Referenzquelle
   // 5.35Hz Abtastrate

   // 2.Hilfskanal mit folgenden Einstellungen initialisieren:
   // Bipolare Betriebsart
   // AIN3 als Messeingang
   // Externe Referenzquelle
   // 5.35Hz Abtastrate
   /*~T*/
   ADuC836_ADCIni(DEFAULT_PRIMARY_ADC_SETTING,0);
   ADuC836_ADCIni(DEFAULT_AUXILIARY_ADC_SETTING,0);

   /*~I:207*/
#ifndef OHNE_STROMRUECKFUEHRUNG
   /*~T*/
   ADuC836_ADCIni(DEFAULT_PRIMARY_TOGGLE_ADC_SETTING,0);

   /*~-1*/
#endif
   /*~E:I207*/
   /*~T*/
   // Messwertoffset vorgeben
   ADuC836_ADCSetZeroOffset(ADuC836_ADC_PRIMARY,0x8000);
   /*~T*/
   // Messwerttiefe vorgeben.
   ADuC836_ADCSetMeasurementDepth(ADuC836_ADC_AUXILIARY,1);

   /*~A:208*/
   /*~+:Kanal 0 - Netzteilspannung*/
   /*~I:209*/
#ifdef CHANNEL_0
   /*~T*/
   ADuC836_ADCIni(DEFAULT_AUXILIARY_TOGGLE_ADC_SETTING,0);

   /*~T*/
   ADuC836_ADCSetMeasurementDepth(ADuC836_ADC_AUXILIARY_TOGGLE,1);
   /*~-1*/
#endif
   /*~E:I209*/
   /*~E:A208*/
   /*~K*/
   /*~+:*/
   /*~I:210*/
#ifdef MIT_EINSTELLBARER_MESSWERTTIEFE
   /*~A:211*/
   /*~+:Mit einstellbarer Messwerttiefe*/
   /*~C:212*/
   switch (chIniMode)
   /*~-1*/
   {
      /*~F:213*/
      case BYDEFAULT:
      case REINITIALISATION:
      /*~-1*/
      {
         /*~T*/
         byMeasurementDepth = 1;	// Werte kleiner von 2 �berlasten den ADC - Hilfs-ADC kommt nicht zum Zuge
         /*~T*/
         // Messwerttiefe der Gewichtsermittlung vorgeben.
         ADuC836_ADCSetMeasurementDepth(ADuC836_ADC_PRIMARY,byMeasurementDepth);
         /*~A:214*/
         /*~+:und speichern*/
         /*~T*/
         // und speichern
         Save_Parameter(LOAD_SAVE_WEIGHT_MEASUREMENT_DEPTH,&byMeasurementDepth,1);
         /*~E:A214*/
         /*~I:215*/
#ifndef OHNE_STROMRUECKFUEHRUNG
         /*~T*/
         byMeasurementDepth = 1;
         /*~T*/
         // Messwerttiefe der Stromr�ckf�hrung vorgeben.
         ADuC836_ADCSetMeasurementDepth(ADuC836_ADC_PRIMARY_TOGGLE,byMeasurementDepth);

         /*~A:216*/
         /*~+:und speichern*/
         /*~T*/
         // und speichern
         Save_Parameter(LOAD_SAVE_MEASUREMENT_DEPTH_FEEDBACK,&byMeasurementDepth,1);
         /*~E:A216*/
         /*~-1*/
#endif
         /*~E:I215*/
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F213*/
      /*~F:217*/
      case BYMEMORY:
      /*~-1*/
      {
         /*~T*/
         Load_Parameter(LOAD_SAVE_WEIGHT_MEASUREMENT_DEPTH,&byMeasurementDepth,1);
         /*~T*/
         // Messwerttiefe der Gewichtsermittlung vorgeben.
         ADuC836_ADCSetMeasurementDepth(ADuC836_ADC_PRIMARY,byMeasurementDepth);
         /*~K*/
         /*~+:*/
         /*~T*/
         Load_Parameter(LOAD_SAVE_MEASUREMENT_DEPTH_FEEDBACK,&byMeasurementDepth,1);
         /*~T*/
         // Messwerttiefe der Stromr�ckf�hrung vorgeben.
         ADuC836_ADCSetMeasurementDepth(ADuC836_ADC_PRIMARY_TOGGLE,byMeasurementDepth);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F217*/
   /*~-1*/
   }
   /*~E:C212*/
   /*~E:A211*/
   /*~O:I210*/
   /*~-1*/
#else
   /*~I:218*/
#ifndef OHNE_STROMRUECKFUEHRUNG 
   /*~T*/
   // Messwerttiefe der Gewichtsermittlung vorgeben.
   ADuC836_ADCSetMeasurementDepth(ADuC836_ADC_PRIMARY,1);
   /*~T*/
   // Messwerttiefe der Stromr�ckf�hrung vorgeben.
   ADuC836_ADCSetMeasurementDepth(ADuC836_ADC_PRIMARY_TOGGLE,1);
   /*~O:I218*/
   /*~-1*/
#else
   /*~T*/
   // Messwerttiefe der Gewichtsermittlung vorgeben.
   ADuC836_ADCSetMeasurementDepth(ADuC836_ADC_PRIMARY,1);
   /*~-1*/
#endif
   /*~E:I218*/
   /*~-1*/
#endif
   /*~E:I210*/
   /*~E:A206*/
   /*~A:219*/
   /*~+:Analogteil initialisieren*/
   /*~C:220*/
   switch (chIniMode)
   /*~-1*/
   {
      /*~F:221*/
      case BYDEFAULT:
      case REINITIALISATION:
      /*~-1*/
      {
         /*~T*/
         Analog_Ini(0);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F221*/
      /*~F:222*/
      case BYMEMORY:
      /*~-1*/
      {
         /*~T*/
         Analog_Ini(1);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F222*/
   /*~-1*/
   }
   /*~E:C220*/
   /*~E:A219*/
   /*~A:223*/
   /*~+:Stromschnittstelle initialisieren*/
   /*~T*/
   // Stromschnittstelle initialisieren
   /*~C:224*/
   switch (chIniMode)
   /*~-1*/
   {
      /*~F:225*/
      case BYDEFAULT:
      case REINITIALISATION:
      /*~-1*/
      {
         /*~T*/
         CurrentInterface_Ini(0);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F225*/
      /*~F:226*/
      case BYMEMORY:
      /*~-1*/
      {
         /*~T*/
         CurrentInterface_Ini(1);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F226*/
   /*~-1*/
   }
   /*~E:C224*/
   /*~I:227*/
   /* neu ab Version V1.009 */
#ifdef STROM_SOFORT_EINSCHALTEN
   /*~T*/
   // Ausgangsstrom sofort auf Defaultwert (ca. 4mA) setzen
   CurrentInterface(0);
   /*~-1*/
#endif
   /*~E:I227*/
   /*~E:A223*/
   /*~A:228*/
   /*~+:Digitalteil initialisieren*/
   /*~T*/
   Digital_Init();
   /*~E:A228*/
   /*~A:229*/
   /*~+:Kommunikationsroutine initialisieren*/
   /*~T*/
   // Kommunikation initialisieren
   // Parametertrennzeichen ist ein SPACE
   Communication_Ini(' ',chIniMode);
   /*~E:A229*/
   /*~A:230*/
   /*~+:Gewichtsermittlung initialisieren*/
   /*~T*/
   ulInititializationStep <<= 1;
   /*~C:231*/
   switch (chIniMode)
   /*~-1*/
   {
      /*~F:232*/
      case BYDEFAULT:
      case REINITIALISATION:
      /*~-1*/
      {
         /*~I:233*/
         if (Weight_Ini(0))
         /*~-1*/
         {
            /*~T*/
            ulRetVal |= ulInititializationStep;
         /*~-1*/
         }
         /*~E:I233*/
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F232*/
      /*~F:234*/
      case BYMEMORY:
      /*~-1*/
      {
         /*~I:235*/
         if (Weight_Ini(1))
         /*~-1*/
         {
            /*~T*/
            ulRetVal |= ulInititializationStep;
         /*~-1*/
         }
         /*~E:I235*/
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F234*/
   /*~-1*/
   }
   /*~E:C231*/
   /*~E:A230*/
   /*~A:236*/
   /*~+:Filterfunktion initialisieren.*/
   /*~T*/
   ulInititializationStep <<= 1;
   /*~C:237*/
   switch (chIniMode)
   /*~-1*/
   {
      /*~F:238*/
      case BYDEFAULT:
      case REINITIALISATION:
      /*~-1*/
      {
         /*~I:239*/
         if (Filter_Ini(0))
         /*~-1*/
         {
            /*~T*/
            // Fehler bei der Initialisierung des Filters
            ulRetVal |= ulInititializationStep;
         /*~-1*/
         }
         /*~E:I239*/
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F238*/
      /*~F:240*/
      case BYMEMORY:
      /*~-1*/
      {
         /*~T*/
         Analog_Ini(1);
         /*~I:241*/
         if (Filter_Ini(1))
         /*~-1*/
         {
            /*~T*/
            // Fehler bei der Initialisierung des Filters
            ulRetVal |= ulInititializationStep;
         /*~-1*/
         }
         /*~E:I241*/
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F240*/
   /*~-1*/
   }
   /*~E:C237*/
   /*~E:A236*/
   /*~A:242*/
   /*~+:Zeitgeber initialisieren*/
   /*~I:243*/
#ifdef MIT_TEACHIN_FUNKTION
   /*~T*/
   ADuC836_TimerIni(1,0);
   /*~O:I243*/
   /*~-1*/
#else
   /*~T*/
   ADuC836_TimerIni(0,0);
   /*~-1*/
#endif
   /*~E:I243*/
   /*~T*/
   ADuC836_TimerSetTimer(T100MS,100);
   ADuC836_TimerSetTimer(T300MS,300);
   ADuC836_TimerSetTimer(T500MS,500);
   ADuC836_TimerSetTimer(T1000MS,1000);
   ADuC836_TimerSetTimer(T2000MS,2000);
   ADuC836_TimerSetTimer(T10000MS,10000);
   /*~E:A242*/
   /*~A:244*/
   /*~+:Systemfunktionen initialisieren*/
   /*~C:245*/
   switch (chIniMode)
   /*~-1*/
   {
      /*~F:246*/
      case BYDEFAULT:
      /*~-1*/
      {
         /*~T*/
         System_Ini(0);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F246*/
      /*~F:247*/
      case BYMEMORY:
      case REINITIALISATION:
      /*~-1*/
      {
         /*~T*/
         System_Ini(1);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F247*/
   /*~-1*/
   }
   /*~E:C245*/
   /*~E:A244*/
   /*~I:248*/
#ifdef MIT_TEACHIN_FUNKTION
   /*~I:249*/
#ifdef CHANNEL_0
   /*~A:250*/
   /*~+:TeachIn-Modul f�r zwei Level initialisieren*/
   /*~T*/
   TeachIn_Ini(2);
   /*~E:A250*/
   /*~-1*/
#endif
   /*~E:I249*/
   /*~-1*/
#endif
   /*~E:I248*/
   /*~A:251*/
   /*~+:Temperaturkompensation initialisieren*/
   /*~T*/
   // Temperaturkompensation initialisieren
   /*~C:252*/
   switch (chIniMode)
   /*~-1*/
   {
      /*~F:253*/
      case BYDEFAULT:
      case REINITIALISATION:
      /*~-1*/
      {
         /*~T*/
         Compensation_Ini(0);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F253*/
      /*~F:254*/
      case BYMEMORY:
      /*~-1*/
      {
         /*~T*/
         Compensation_Ini(1);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F254*/
   /*~-1*/
   }
   /*~E:C252*/
   /*~E:A251*/
   /*~I:255*/
#ifdef MOF
   /*~A:256*/
   /*~+:Externen Interrupt initialisieren*/
   /*~T*/
   ADuC836_ExternalIni(EXTERNAL_EDGE_CONTROLLED|EXTERNAL_LOW_PRIORITY,1,EXTERNAL_EDGE_CONTROLLED|EXTERNAL_LOW_PRIORITY,0);
   /*~E:A256*/
   /*~-1*/
#endif
   /*~E:I255*/
   /*~A:257*/
   /*~+:Statistik initialisieren*/
   /*~I:258*/
   if (chIniMode == BYDEFAULT)
   /*~-1*/
   {
      /*~T*/
      Statistics_Ini(1);
   /*~-1*/
   }
   /*~O:I258*/
   /*~-2*/
   else
   {
      /*~T*/
      Statistics_Ini(0);
   /*~-1*/
   }
   /*~E:I258*/
   /*~E:A257*/
   /*~A:259*/
   /*~+:Grenzwert�berwachung initialisieren*/
   /*~T*/
   // Grenzwert�berwachung initialisieren
   /*~C:260*/
   switch (chIniMode)
   /*~-1*/
   {
      /*~F:261*/
      case BYDEFAULT:
      case REINITIALISATION:
      /*~-1*/
      {
         /*~T*/
         Limit_Init(0);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F261*/
      /*~F:262*/
      case BYMEMORY:
      /*~-1*/
      {
         /*~T*/
         Limit_Init(1);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F262*/
   /*~-1*/
   }
   /*~E:C260*/
   /*~E:A259*/
   /*~T*/
   return ulRetVal;
/*~-1*/
}
/*~E:F193*/
/*~E:A192*/
/*~A:263*/
/*~+:void Main_SetTimerFlags(void)*/
/*~F:264*/
/*#LJ:Main_SetTimerFlags=6*/
void Main_SetTimerFlags(void)
/*~-1*/
{
   /*~T*/
   Flag100ms = ADuC836_TimerCheckTime(T100MS,2);
   Flag300ms = ADuC836_TimerCheckTime(T300MS,2);
   Flag500ms = ADuC836_TimerCheckTime(T500MS,2);
   Flag1000ms = ADuC836_TimerCheckTime(T1000MS,2);
   Flag2000ms = ADuC836_TimerCheckTime(T2000MS,2);
   Flag10000ms = ADuC836_TimerCheckTime(T10000MS,2); 
/*~-1*/
}
/*~E:F264*/
/*~E:A263*/
/*~K*/
/*~+:/~* Hinzugef�gt am 09.02.2022 *~/*/
/*~A:265*/
/*~+:unsigned long Main_UpdateRetains(void)*/
/*~F:266*/
unsigned long Main_UpdateRetains(void)

/*~-1*/
{
   /*~A:267*/
   /*~+:Beschreibung*/
   /*~K*/
   /*~+:*/
   /*~E:A267*/
   /*~A:268*/
   /*~+:Variablendeklarationen*/
   /*~T*/
   unsigned long ulRetVal;
   unsigned char byRetValSave;
   unsigned long ulReorganisationFlag;
   unsigned long ulVersion;
   unsigned long ulVersionByEeprom;
   float fTemp;
   unsigned char byTemp;
   unsigned long ulTemp;
   /*~E:A268*/
   /*~A:269*/
   /*~+:Variableninitialisierungen*/
   /*~T*/
   ulRetVal = 0L;
   ulReorganisationFlag = 1L;
   ulVersion = 0L;
   /*~E:A269*/
   /*~A:270*/
   /*~+:Software-Version in eine unsigned long Variable wandeln*/
   /*~T*/
   ulVersion = Version_SoftwareVersionToLong();
   /*~E:A270*/
   /*~T*/
   Load_Parameter(LOAD_SAVE_VERSION, &ulVersionByEeprom, 4);		// Get Version
   /*~I:271*/
   if (ulVersion != ulVersionByEeprom)
   /*~-1*/
   {
      /*~T*/
      ulReorganisationFlag = 1L;
      /*~I:272*/
      if (Save_Parameter(LOAD_SAVE_E2REORGANISATIONFLAG,&ulReorganisationFlag,4) == 0)
      /*~-1*/
      {
         /*~T*/
         /* Okay */
         /* Aktuelle Softwareversion im Eeprom eintragen */
         /*~I:273*/
         if (Save_Parameter(LOAD_SAVE_VERSION, 0, 4) != 0)
         /*~-1*/
         {
            /*~T*/
            ulRetVal = 0x10000000;
         /*~-1*/
         }
         /*~E:I273*/
      /*~-1*/
      }
      /*~O:I272*/
      /*~-2*/
      else
      {
         /*~T*/
         /* Fehler */
         ulRetVal = 0x20000000;
      /*~-1*/
      }
      /*~E:I272*/
   /*~-1*/
   }
   /*~O:I271*/
   /*~-2*/
   else
   {
      /*~T*/
      /* Reorganisations-Flag aus dem Eeprom auslesen */
      Load_Parameter(LOAD_SAVE_E2REORGANISATIONFLAG,&ulReorganisationFlag,4);
   /*~-1*/
   }
   /*~E:I271*/
   /*~K*/
   /*~+:*/
   /*~L:274*/
   while ((ulRetVal == 0) && (ulReorganisationFlag != 0xFFFFFFFF))
   /*~-1*/
   {
      /*~C:275*/
      switch (ulReorganisationFlag)
      /*~-1*/
      {
         /*~F:276*/
         case 0x00000001:
         /*~-1*/
         {
            /*~T*/
            fTemp = SYSTEM_CND_DEFAULT_CONVERSION_RATE_WEIGHT;
            byRetValSave = Save_Parameter(LOAD_SAVE_MEASUREMENT_CONVERSIONRATE,&fTemp,4);
            /*~T*/
            break;
         /*~-1*/
         }
         /*~E:F276*/
         /*~F:277*/
         case 0x00000002:
         /*~-1*/
         {
            /*~T*/
            byTemp = 0;

            /*~T*/
            byRetValSave = Save_Parameter(LOAD_SAVE_SPI_FAULT_COUNTER,&byTemp,1);
            /*~T*/
            break;
         /*~-1*/
         }
         /*~E:F277*/
         /*~F:278*/
         case 0x00000004:
         /*~-1*/
         {
            /*~T*/
            byTemp = 1;
            byRetValSave = Save_Parameter(LOAD_SAVE_FLAG_DONOT_RESET,&byTemp,1);
            /*~T*/
            break;
         /*~-1*/
         }
         /*~E:F278*/
         /*~F:279*/
         case 0x00000008:
         /*~-1*/
         {
            /*~T*/
            ulTemp = 0L;
            byRetValSave = Save_Parameter(LOAD_SAVE_RS232_DISABLE_CODE,&ulTemp,4);
            /*~T*/
            break;
         /*~-1*/
         }
         /*~E:F279*/
         /*~F:280*/
         case 0x00000010:
         /*~-1*/
         {
            /*~T*/
            byTemp = 50;
            byRetValSave = Save_Parameter(LOAD_SAVE_PROPORTIONALPORTION_FEEDBACK,&byTemp,1);
            /*~T*/
            break;
         /*~-1*/
         }
         /*~E:F280*/
         /*~F:281*/
         case 0x00000020:
         /*~-1*/
         {
            /*~T*/
            Statistics_Ini(1);	/* Die gesamte Statistik auf Defaultwerte setzen - Relativ- und Absolutstatistik */
            ulReorganisationFlag = 0xFFFFFFFF;
            byRetValSave = Save_Parameter(LOAD_SAVE_E2REORGANISATIONFLAG,&ulReorganisationFlag,4);
            /*~I:282*/
            if (byRetValSave == 0)
            /*~-1*/
            {
               /*~T*/
               /* Okay */
               /* System zur�cksetzen - Reset ausf�hren */
               /*~I:283*/
#ifdef TEST_UPDATE_RETAINS
               /*~T*/
               Communication_SendRawString(COMMUNICATION_RS232, "Reset !");
               Communication_SendCR(1);
               /*~-1*/
#endif
               /*~E:I283*/
               /*~T*/
               Watchdog_Ini();

               System_Reset();
            /*~-1*/
            }
            /*~O:I282*/
            /*~-2*/
            else
            {
               /*~T*/
               ulReorganisationFlag = 0x00000020;
            /*~-1*/
            }
            /*~E:I282*/
            /*~T*/
            break;
         /*~-1*/
         }
         /*~E:F281*/
         /*~O:C275*/
         /*~-2*/
         default:
         {
            /*~T*/
            /* Ung�ltiger Wert des Reorganisationsflags. Dieses mit dem Fehlercode vorbesetzen, der sp�ter dem R�ckgabewert zugewiesen wird. */
            ulReorganisationFlag = 0x40000000;
            byRetValSave = 1;
         /*~-1*/
         }
      /*~-1*/
      }
      /*~E:C275*/
      /*~I:284*/
      if (byRetValSave == 0)
      /*~-1*/
      {
         /*~T*/
         /* Okay */
         ulReorganisationFlag <<= 1;

         /*~I:285*/
         if (Save_Parameter(LOAD_SAVE_E2REORGANISATIONFLAG,&ulReorganisationFlag,4) != 0)
         /*~-1*/
         {
            /*~T*/
            /* Fehler */
            ulRetVal = ulReorganisationFlag >> 1;
         /*~-1*/
         }
         /*~O:I285*/
         /*~-2*/
         else
         {
            /*~T*/
            /* Okay */

         /*~-1*/
         }
         /*~E:I285*/
      /*~-1*/
      }
      /*~O:I284*/
      /*~-2*/
      else
      {
         /*~T*/
         /* Fehler */
         ulRetVal = ulReorganisationFlag;
      /*~-1*/
      }
      /*~E:I284*/
   /*~-1*/
   }
   /*~E:L274*/
   /*~I:286*/
   if (ulRetVal != 0L)
   /*~-1*/
   {
      /*~T*/
      // Fehler bei der Reorganisation des Eeproms => Sicherheitszustand
      Diagnosis_SecuritySystemError();
   /*~-1*/
   }
   /*~E:I286*/
   /*~T*/
   return ulRetVal;
/*~-1*/
}
/*~E:F266*/
/*~E:A265*/
/*~K*/
/*~+:/~* Ende - Hinzugef�gt am 09.02.2022 *~/*/
