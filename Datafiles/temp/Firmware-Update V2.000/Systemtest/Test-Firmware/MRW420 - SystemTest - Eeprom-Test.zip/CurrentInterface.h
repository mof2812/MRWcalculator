/*~-1*/
/*~XSF_LANGUAGE: C/C++*/
/*~A:1*/
/*~+:Versions-Beschreibung*/
/*~A:2*/
/*~+:Version und Versionsdatum*/
/*~T*/
/*!
\mainpage "Modul-Beschreibung"
\author Michael Offenbach
\date 08.06.2005 
\version V1.000
\warning
*/
/*~E:A2*/
/*~A:3*/
/*~+:Lifecycle*/
/*~T*/
/*!\page LifeCyclePage Lifecycle

\section sec_LifeCyclePage_CurrentInterface 'Stromschnittstelle'

<table border=1 width=100% height=1% rules=rows cellspacing=0 bgcolor="#E0E0F0">

<tr align=left valign=top>
	<th>Version</th>
	<th>Datum</th>
	<th>Programmierer</th>
	<th>�nderungen</th>
</tr>

<tr>
	<td>1.000</td>
	<td>27.05.05</td>
	<td>Michael Offenbach</td>
	<td>Erste lauff�hige Version</td>
</tr>
</table>

*/
/*~E:A3*/
/*~E:A1*/
/*~I:4*/
#ifndef __CURRENTINTERFACE_H

/*~T*/
#define __CURRENTINTERFACE_H

/*~A:5*/
/*~+:Includes*/
/*~T*/
#include "Measurement.h"
/*~E:A5*/
/*~A:6*/
/*~+:Definitionen*/
/*~T*/
#define CURRENTINTERFACE_FEEDBACKCHANEL					1	///< R�ckkopplungs-Kanal

/*~T*/
#define CURRENTINTERFACE_SETPOINT_0						0 	///< Wert nicht �ndern !
///< Setzen der Werte zum ersten Kalibrierpunkt
#define CURRENTINTERFACE_SETPOINT_1						1 	///< Wert nicht �ndern !
///< Setzen der Werte zum zweiten Kalibrierpunkt
#define CURRENTINTERFACE_CALIBRATE						2 	///< Kalibrierung/Normierung ausf�hren
/*~T*/
// Speicher-/Ladeoptionen

#define CURRENTINTERFACE_ALL_SETTINGS					0	///< Alle Einstellungen
#define CURRENTINTERFACE_CALIBRATION_BACKUP				1	///< Kalibrierwerte
#define CURRENTINTERFACE_GAIN_FEEDBACK					2	///< Kalibrierwert der R�ckkopplung
#define CURRENTINTERFACE_OFFSET_FEEDBACK				3	///< Offset der R�ckkopplung
#define CURRENTINTERFACE_MAXDEVIATION_FEEDBACK			4	///< maximal zul�ssige Soll-Istwert-Abweichung
#define CURRENTINTERFACE_INTEGRALPORTION_FEEDBACK		5	///< Integral-Anteil der Stromregelung
#define CURRENTINTERFACE_RMW_1ST_REFPOINT				6	///< Rohmesswert des ersten Referenzpunktes 
#define CURRENTINTERFACE_RMW_2ND_REFPOINT				7	///< Rohmesswert des zweiten Referenzpunktes
#define CURRENTINTERFACE_TIME_HYSTERESIS				8	///< Zeithysterese f�r Grenzwert
#define CURRENTINTERFACE_WEIGHTCALCULATION				9	///< Parameter zur R�ckrechnung des Gewichtswerts �ber den Ausgangsstrom 
#define CURRENTINTERFACE_PROPORTIONALPORTION_FEEDBACK	10	///< Proportional-Anteil der Stromregelung

/*~T*/
// Status der Statemachine

#define CURRENT_INTERFACE_STATE_DACCONVERT				0	///< DAC-Wandlung
#define CURRENT_INTERFACE_STATE_CHECKLIMITS				1//4	///< Grenzwert�berpr�fung
#define CURRENT_INTERFACE_STATE_FEEDBACK				4	///< Stromr�ckf�hrung
/*~E:A6*/
/*~A:7*/
/*~+:Struktur-Definitionen*/
/*~T*/
typedef struct
{
	MEASUREMENT_VALUE FilteredMeasurementFromADC;	///< r�ckgekoppelte Spannung des DACs
	MEASUREMENT_VALUE Deviation;					///< Abweichung Sollwert zu Istwert 
	MEASUREMENT_VALUE CalibratedMeasurement;
//	MEASUREMENT_VALUE ZeroCorrectedMeasurement;
	unsigned char byNewMeasurement;					///< Flag f�r neuen Messwert
}RESULTS;
/*~T*/
typedef struct
{
	RESULTS 		Results;
	float 			fSimulatedDerivation;			///< simulierte Soll-Istwert-Abweichung
	float			fMaxDeviation;					///< maximal zul�ssige Soll-Istwert-Abweichung 
	unsigned char	byMaxDeviationCounter;			///< Fehlerz�hler f�r �berschrittene Grenze der Soll-Istwert-Abweichung
	char 			chIntegralPortion;				///< Integral-Anteil der Stromregelung
	char 			chProportionalPortion;			///< Proportional-Anteil der Stromregelung
}FEEDBACK;

/*~T*/
typedef struct
{
	long 		lRatedDACOutput;					///< DAC-Sollausgangsgr��e
}DAC_T;
/*~T*/
typedef struct
{
	FEEDBACK 		FeedBack;
	DAC_T 			DAC;							///< Struktur f�r den DAC
	long 			lCalPointFeedBack_RMW[2];		///< Kalibrierpunkte f�r R�ckkopplung (ADC_RMW)
	float 			fCalPointFeedBack_Actual[2];	///< Kalibrierpunkte f�r R�ckkopplung (Istwert)
//	unsigned char 	byState;						///< Status der Statemachnine
	unsigned char 	byAdjustCurrentInterface;		///< Kalibriermodus der Stromschnittstelle
	long 			lRMWForCalibration[2];			///< Rohmesswert f�r 4mA und 20mA-Abgleich
	unsigned char 	byConversionState;				///< Status der Digital-Analog-Wandlung
	unsigned char 	byLastConversionState;			///< letzter Status der Digital-Analog-Wandlung
}CURRENT_INTERFACE;
/*~E:A7*/
/*~A:8*/
/*~+:Funktionsdeklarationen*/
/*~T*/
extern void 			CurrentInterface(long lValue2Convert);
extern char 			CurrentInterface_Calibration(unsigned char chWhat2Do,float fTrueValue);

extern float 			CurrentInterface_GetCurrent(unsigned char byMode);
extern char 			CurrentInterface_GetFeedBackIntegralPortion(void);
extern char 			CurrentInterface_GetFeedBackProportionalPortion(void);
extern char 			CurrentInterface_GetFeedBackState(void);
extern unsigned int 	CurrentInterface_GetTimeHysteresis(void);
extern char 			CurrentInterface_Ini(unsigned char byMode);
extern void				CurrentInterface_LoadDACSettings(unsigned char chWhat2Load);
extern void 			CurrentInterface_PrepareCalibration(unsigned char byCalPoint,float fWeight);

extern void 			CurrentInterface_SaveDACSettings(unsigned char chWhat2Save);
extern char 			CurrentInterface_SetCalibrationFactorOfFeedBack(float fCalibrationFactor);

extern void 			CurrentInterface_SetFeedBackIntegralPortion(char chIntegralPortion);

extern void 			CurrentInterface_SetFeedBackProportionalPortion(char chProportionalPortion);

extern void 			CurrentInterface_SetLimits(long lLowerLimit,long lUpperLimit);
extern void 			CurrentInterface_SetFeedBackOnOff(unsigned char bOnOff,unsigned char bSave);

extern void 			CurrentInterface_SetTimeHysteresis(unsigned int uTime);
extern void 			CurrentInterface_SetManualMode(unsigned char byOnOff,long lRatedDACOutput);

extern char				CurrentInterface_SetZeroOfFeedBack(long lZero2Set);

/*~E:A8*/
/*~A:9*/
/*~+:Variablen*/
/*~T*/
extern CURRENT_INTERFACE g_CurrentInterface;
/*~E:A9*/
/*~-1*/
#endif
/*~E:I4*/
