/*~-1*/
/*~XSF_LANGUAGE: C/C++*/
/*~A:1*/
/*~+:Versions-Beschreibung*/
/*~T*/
/*!
\addtogroup versions_externals
@{
<tr>
	<td>MRW_Compensation.h</td>
	<td>Michael Offenbach</td>
	<td>1.005</td>
	<td>25.10.2007</td>
	<td></td>
</tr>
@}
*/
/*~E:A1*/
/*~A:2*/
/*~+:Manual*/
/*~A:3*/
/*~+:Ziel-Hardware*/
/*~T*/
/*!\page HardwarePage Ziel-Hardware

\section sec_HardwarePage_MRW_Compensation 'MRW-Kompensation'

<table border=1 width=100% height=1% rules=rows cellspacing=0 bgcolor="#E0E0F0">

<tr align=left valign=top>
	<th>Motherboard</th>
	<th>Prozessor</th>
	<th>ROM</th>
	<th>RAM</th>
</tr>

<tr>
	<td>MRW-Limit V1.2B 2/2004</td>
	<td>8051-Core</td>
	<td>62 <B>kByte</B></td>
	<td>2 <B>kByte</B></td>
</tr></table>

*/
/*~E:A3*/
/*~A:4*/
/*~+:Compiler-Einstellungen*/
/*~T*/
/*!\page CompilerPage Compiler-Einstellungen

\section sec_CompilerPage_MRW_Compensation 'MRW-Kompensation'

<table border=1 width=100% height=1% rules=rows cellspacing=0 bgcolor="#E0E0F0">

<tr align=left valign=top>
	<th>Compiler</th>
	<th>Betriebssystem</th>
	<th>Speichermodell</th>
	<th>Code-Speicher-Gr��e</th>
	<th>Optimierungen</th>
	<th>Sonstiges</th>
</tr>

<tr>
	<td>Keil uVision2 V2.40<BR>C51 V7.08<BR>A51 V7.08a</td>
	<td>Kein Betriebssystem</td>
	<td>Large: variables in XDATA</td>
	<td>Large: 64k program</td>
	<td>6 Loop rotation<BR>Favor speed</td>
	<td>---</td>
</tr></table>

*/
/*~E:A4*/
/*~A:5*/
/*~+:Ressourcen*/
/*~T*/
/*!\page RessourcePage Ressourcen

\section sec_RessourcePage_MRW_Compensation 'MRW-Kompensation'

<table border=1 width=100% height=1% rules=rows cellspacing=0 bgcolor="#E0E0F0">

<tr align=left valign=top>
	<th>CODE</th>
	<th>IDATA</th>
	<th>XDATA</th>
	<th>Dynamische Variablen</th>
</tr>

<tr>
	<td>--- <B>Bytes</B></td>
	<td>--- <B>Bytes</B></td>
	<td>--- <B>Bytes</B></td>
	<td>Anzahl der Kennlinienpunkte * 2<B>Bytes</B></td>
</tr></table>

*/
/*~E:A5*/
/*~A:6*/
/*~+:Zykluszeiten*/
/*~T*/
/*!\page CycletimePage Zykluszeiten

\section sec_CycletimePage_MRW_Compensation 'MRW-Kompensation'

<table border=1 width=100% height=1% rules=rows cellspacing=0 bgcolor="#E0E0F0">

<tr align=left valign=top>
	<th>Minimale Durchlaufzeit</th>
	<th>Maximale Durchlaufzeit</th>
</tr>

<tr>
	<td>--- <B>ms</B></td>
	<td>--- <B>ms</B></td>
</tr></table>

*/
/*~E:A6*/
/*~A:7*/
/*~+:Verschiedenes*/
/*~T*/
/*!\page MiscPage Verschiedenes

\section sec_MiscPage_MRW_Compensation 'MRW-Kompensation'

<table border=1 width=100% height=1% rules=rows cellspacing=0 bgcolor="#E0E0F0">

<tr align=left valign=top>
	<th>Benutzte Interrups</th>
	<th>Benutzte Registerb�nke</th>
</tr>

<tr>
	<td>---</td>
	<td>---</td>
</tr></table>

*/
/*~E:A7*/
/*~A:8*/
/*~+:Lifecycle*/
/*~T*/
/*!\page LifeCyclePage Lifecycle

\section sec_LifeCyclePage_MRW_Compensation 'MRW-Kompensation'

<table border=1 width=100% height=1% rules=rows cellspacing=0 bgcolor="#E0E0F0">

<tr align=left valign=top>
	<th>Version</th>
	<th>Datum</th>
	<th>Programmierer</th>
	<th>�nderungen</th>
</tr>

<tr>
	<td>1.000</td>
	<td>25.08.05</td>
	<td>Michael Offenbach</td>
	<td>Erste lauff�hige Version</td>
</tr>

</table>
*/
/*~E:A8*/
/*~E:A2*/
/*~I:9*/
#ifndef __MRW_COMPENSATION_H

/*~T*/
#define __MRW_COMPENSATION_H

/*~A:10*/
/*~+:Includes*/
/*~T*/

/*~E:A10*/
/*~T*/
// #define MRW_COMPENSATION_TEST
/*~A:11*/
/*~+:Definitionen*/
/*~T*/
#define MRW_COMPENSATION_LIMIT_DEVIATIONS		10	// kg
#define MRW_COMPENSATION_LIMIT_DEVIATIONS_XL	15	// kg

#define MRW_COMPENSATION_LIMIT_DRIFT			5	// kg
#define MRW_COMPENSATION_LIMIT_DRIFT_XL			25	// kg
/*~T*/
#define MRW_COMPENSATION_CORR_TEMP_HI			70	///< Temperatur oberster Korrekturpunkt
#define MRW_COMPENSATION_CORR_TEMP_LO			-30	///< Temperatur unterster Korrekturpunkt
#define MRW_COMPENSATION_CORR_TEMP_SPAN			5	///< Temperatur-Abstand zwischen zwei Korrekturpunkten
#define MRW_COMPENSATION_NB_SAMPLINGPOINTS		1 + (MRW_COMPENSATION_CORR_TEMP_HI - MRW_COMPENSATION_CORR_TEMP_LO) / MRW_COMPENSATION_CORR_TEMP_SPAN	///< Anzahl der Kennlinienpunkte

#define MRW_COMPENSATION_REF_TEMP				20	///< Referenztemperatur
#define MRW_COMPENSATION_TEMP_REC_DRIFT			MRW_COMPENSATION_REF_TEMP	///< Prozessortemperatur der Driftpunkt(Nr.2)-Aufnahme

#define MRW_COMPENSATION_RECTRIGGER_TEMP		MRW_COMPENSATION_CORR_TEMP_HI + 2	///< Triggertemperatur zum Starten der Kennlinienaufnahme	
/*~T*/
// #define MRW_COMPENSATION_MAX_DRIFT				80	///< Maximaler Drift: 80 Digit
#define MRW_COMPENSATION_MAX_DRIFT				5	///< Maximaler Drift: 5 kg
#define MAX_COMPENSATION_MAX_DEVIATION			10	///< Maximale Abweichung: 10kg
/*~T*/
// Modus der Kompensationswertaufnahme
#define MRW_COMPENSATION_MODE_REC_DRIFT				0x01	///< Aufnahme des Drifts
#define MRW_COMPENSATION_MODE_REC_CHARACTERISTICS	0x02	///< Kennlinienaufnahme
#define MRW_COMPENSATION_MODE_TEST_COMPENSATION		0x04	///< Test der Kompensation 
#define MRW_COMPENSATION_TEST_1						0x08	///< Testmode f�r SW-Entwicklung
#define MRW_COMPENSATION_MODE_ALL					0xFF
/*~T*/
// Statusmaschine
#define MRW_COMPENSATION_STATE_INIT						0	///< Initialisierung der Statemachine
#define MRW_COMPENSATION_STATE_WAIT_30					5	///< Wartezustand
#define MRW_COMPENSATION_STATE_WAIT4STABILE				10	///< Warten auf stabile Temperatur
#define MRW_COMPENSATION_STATE_REC_1ST_RMW20			15	///< ersten Driftwert ermitteln
#define MRW_COMPENSATION_STATE_WAIT_RECTRIGGER_TEMP		50	///< Warte bis Triggertemperatur zur Kennlinienaufnahme erreicht ist
#define MRW_COMPENSATION_STATE_INIT_GET_POINT			55	///< Initialisierungsroutine zur Aufnahme eines Kennlinienpunktes
#define MRW_COMPENSATION_STATE_GET_POINT				60	///< Kennlinienpunkt aufnehmen 
#define MRW_COMPENSATION_STATE_SUB_OFFSET				65	///< 20�C-Offset herausrechnen
#define MRW_COMPENSATION_STATE_SWITCH_COMPENSATION_ON	70	///< Einschalten der Kompensation
#define MRW_COMPENSATION_STATE_WAIT_TESTTRIGGER_TEMP	100	///< Warte bis Triggertemperatur zum Test der Temperaturkompensation erreicht ist
#define MRW_COMPENSATION_STATE_WAIT_4_DEC_TEMPERATURE	105	///< Warten bis die Temperatur wieder abgesunken ist
#define MRW_COMPENSATION_STATE_INIT_TEST_COMPENSATION	110	///< Initialisierung zum Test der Kompensation
#define MRW_COMPENSATION_STATE_TEST_COMPENSATION		115	///< Test der Temperaturkompensation
#define MRW_COMPENSATION_STATE_WAIT_4_CORR_TEMP_LO		145 ///< Nur bei alleiniger Driftuntersuchung
#define MRW_COMPENSATION_STATE_WAIT_TEMP_4_REC_2ND_RMW20	150	///< warten bis die Temperatur zur Aufnahme des zweiten Driftpunktes erreicht ist.
#define MRW_COMPENSATION_STATE_REC_2ND_RMW20			155	///< zweiten Driftwert ermitteln
#define MRW_COMPENSATION_STATE_ANALYSIS					200	///< Analyse der Ergebnisse
#define MRW_COMPENSATION_STATE_ERROR					250	///< Kennlinienaufnahme mit Fehler
#define MRW_COMPENSATION_STATE_READY					255	///< Kennlinienaufnahme i.O.
/*~T*/
// L�schen der Ergebnisse
#define MRW_COMPENSATION_CLEAR_CHARACTERISTICS	1	///< Kennlinie l�schen
#define MRW_COMPENSATION_CLEAR_ALL_RESULTS		50	///< Alle Ergebnisse l�schen
#define MRW_COMPENSATION_CLEAR_PARAMETER		60	///< Alle Parameter l�schen
#define MRW_COMPENSATION_CLEAR_ALL				255	///< L�schen der gesamten Struktur

/*~T*/
// Laden der Daten
#define MRW_COMPENSATION_LOAD_CHARACTERISTICS	1	///< Kennlinie laden
#define MRW_COMPENSATION_LOAD_STATE				10	///< letzter abgearbeiteter Status
#define MRW_COMPENSATION_LOAD_RESULTS			50	///< Alle Ergebnisse laden
#define MRW_COMPENSATION_LOAD_PARAMETER			60	///< Kompensationsparameter laden 
#define MRW_COMPENSATION_LOAD_ALL				255	///< Laden der gesamten Struktur
/*~T*/
// Speichern der Daten
#define MRW_COMPENSATION_SAVE_CHARACTERISTICS	1	///< Kennlinie abspeichern
#define MRW_COMPENSATION_SAVE_STATE				10	///< letzter abgearbeiteter Status
#define MRW_COMPENSATION_SAVE_RESULTS			50	///< Alle Ergebnisse abspeichern
#define MRW_COMPENSATION_SAVE_PARAMETER			60	///< Kompensationsparameter abspeichern 
#define MRW_COMPENSATION_SAVE_ALL				255	///< Speichern der gesamten Struktur
/*~T*/
// Warten auf Ereignis
#define MRW_COMPENSATION_WAIT_TIME					0x00	///< Auf Ablauf einer Zeit warten
#define MRW_COMPENSATION_WAIT_TEMPERATURE			0x01	///< Warten auf stabile Temperatur
#define MRW_COMPENSATION_WAIT_TEMPERATURE_CHANGE	0x02	///< Warten auf Temperatur�nderung
#define MRW_COMPENSATION_WAIT_TEMPERATURE_RAISE		0x03	///< Warten auf ansteigende Temperatur 
#define MRW_COMPENSATION_WAIT_TEMPERATURE_SINK		0x04	///< Warten auf abfallende Temperatur 
#define MRW_COMPENSATION_WAIT_INIT					0x7F	///< manuelle Initialisierung
/*~T*/
// Ausgabe von Daten
#define MRW_COMPENSATION_GET_STATUS				0	///< aktuelle Status der Kennlinienaufnahme
#define MRW_COMPENSATION_GET_OFFSET_20			1	///< ermittelter Kennlinienoffset bei 20�C
#define MRW_COMPENSATION_GET_CHARACTERISTICS	2	///< Kennlinienpunkt ausgeben
#define MRW_COMPENSATION_GET_CHARACTERISTICS_WITH_OFFSET	3	///< Kennlinienpunkt inkl. Offset

#define MRW_COMPENSATION_GET_ANALYSIS			4	///< aktueller Analysestatus
#define MRW_COMPENSATION_GET_COMPENSATION_ONOFF	5	///< Temperaturkompensation ein-/ausgeschaltet
#define MRW_COMPENSATION_GET_REC_CHARACTERISTICS_ONOFF	6		///< Kennlinienaufnahme ein-/ausgeschaltet
#define MRW_COMPENSATION_GET_DEVIATION			10	///< Aktuelle Abweichung
#define MRW_COMPENSATION_GET_DEVIATION_KG		15	///< Aktuelle Abweichung in KG
#define MRW_COMPENSATION_GET_LAST_CORRVAL		20	///< letzter Korrekturwert
#define MRW_COMPENSATION_GET_POINTS_RECORDED	50	///< Anzahl der aufgenommenen Punkte
#define MRW_COMPENSATION_GET_CORRTEMP_HI		51	///< Temperatur des obersten Kennlinienpunktes

#define MRW_COMPENSATION_GET_CORRTEMP_LO		52	///< Temperatur des untersten Kennlinienpunktes

#define MRW_COMPENSATION_GET_CORRTEMP_SPAN		53	///< Temperaturspanne der Kennlinienpunkte untereinander

#define MRW_COMPENSATION_GET_MINIMUM_DIGIT		100	///< Minimale Abweichung in Digit
#define MRW_COMPENSATION_GET_MINIMUM_KG			101	///< Minimale Abweichung in kg
#define MRW_COMPENSATION_GET_MINIMUM_TEMP		102	///< Minimale Abweichung bei Temperatur
#define MRW_COMPENSATION_GET_MAXIMUM_DIGIT		103	///< Maximale Abweichung in Digit
#define MRW_COMPENSATION_GET_MAXIMUM_KG			104	///< Maximale Abweichung in kg
#define MRW_COMPENSATION_GET_MAXIMUM_TEMP		105	///< Maximale Abweichung bei Temperatur
#define MRW_COMPENSATION_GET_1ST_REF_DRIFT		150	///< erster Drift-Referenzpunkt
#define MRW_COMPENSATION_GET_2ND_REF_DRIFT		151	///< zweiter Drift-Referenzpunkt
#define MRW_COMPENSATION_GET_DRIFT_DIGIT		152	///< resultierender Drift in Digit
#define MRW_COMPENSATION_GET_DRIFT_KG			153	///< resultierender Drift in kg
#define MRW_COMPENSATION_GET_TEMP_1ST_REF_DRIFT	154	///< Temperatur zur Aufnahme des ersten Drift-Referenzpunktes

/*~T*/
// Status des Temperaturverlaufs
#define MRW_COMPENSATION_TEMPERATURE_DECREASING		-128	///< Temperatur f�llt ab
#define MRW_COMPENSATION_TEMPERATURE_STATIC			1		///< Temperatur stabil
#define MRW_COMPENSATION_TEMPERATURE_INCREASING		127		///< Temperatur steigt an
/*~T*/
// Temperaturstatus
#define MRW_COMPENSATION_TEMPERATURE_INSIDE_RANGE	1	///< Temperatur innerhalb des Temperaturbereichs
#define MRW_COMPENSATION_TEMPERATURE_ABOVE_RANGE	127	///< Temperatur oberhalb des Temperaturbereichs
#define MRW_COMPENSATION_TEMPERATURE_BENEATH_RANGE	-128///< Temperatur unterhalb des Temperaturbereichs

/*~T*/
// Allgemeine Definitionen
#define MRW_COMPENSATION_ACCEPT_TEMPERATURE_STATE		5		///< Z�hler bis zur �bernahme des Temperaturstatus


/*~I:12*/
#ifndef MRW_COMPENSATION_TEST
/*~T*/
#define MRW_COMPENSATION_MEASUREMENTS_2_GET_DRIFT		50		///< Anzahl der aufaddierten Messwerte zur Drifterkennung
/*~O:I12*/
/*~-1*/
#else
/*~T*/
// Simulation (5xschneller)
/*~T*/
#define MRW_COMPENSATION_MEASUREMENTS_2_GET_DRIFT		10		///< Anzahl der aufaddierten Messwerte zur Drifterkennung
/*~-1*/
#endif
/*~E:I12*/
/*~T*/
// Wartefunktion
#define MRW_COMPENSATION_NO_REF_TEMPERATURE				-128	///< keine Refernztemperatur
#define MRW_COMPENSATION_NO_TEMPERATURE_SPAN			0		///< kein Temperaturband

// Zeitverhalten

/*~I:13*/
#ifndef MRW_COMPENSATION_TEST
/*~T*/
#define MRW_COMPENSATION_5_SECONDS						5		///< Zeitangabe 5 Sekunden
#define MRW_COMPENSATION_30_SECONDS						30		///< Zeitangabe 30 Sekunden / 30s
#define MRW_COMPENSATION_1_MINUTE						60		///< Zeitangabe 1 Minuten / 60s
#define MRW_COMPENSATION_2_MINUTES						120		///< Zeitangabe 2 Minuten / 120s
#define MRW_COMPENSATION_3_MINUTES						180		///< Zeitangabe 3 Minuten / 180s
#define MRW_COMPENSATION_5_MINUTES						300		///< Zeitangabe 5 Minuten / 300s
#define MRW_COMPENSATION_6_MINUTES						360		///< Zeitangabe 6 Minuten / 360s
#define MRW_COMPENSATION_10_MINUTES						600		///< Zeitangabe 10 Minuten / 600s
#define MRW_COMPENSATION_20_MINUTES						1200		///< Zeitangabe 20 Minuten / 1200s
#define MRW_COMPENSATION_30_MINUTES						1800	///< Zeitangabe 30 Minuten / 1800s

#define MRW_COMPENSATION_60_MINUTES						3600	///< Zeitangabe 60 Minuten / 3600s
/*~O:I13*/
/*~-1*/
#else
/*~T*/
// Simulation (10xschneller)
/*~T*/
#define MRW_COMPENSATION_5_SECONDS						5		///< Zeitangabe 5 Sekunden
#define MRW_COMPENSATION_30_SECONDS						3		///< Zeitangabe 30 Sekunden / 30s
#define MRW_COMPENSATION_1_MINUTE						6		///< Zeitangabe 1 Minuten / 60s
#define MRW_COMPENSATION_2_MINUTES						12		///< Zeitangabe 2 Minuten / 120s
#define MRW_COMPENSATION_3_MINUTES						18		///< Zeitangabe 3 Minuten / 180s
#define MRW_COMPENSATION_5_MINUTES						30		///< Zeitangabe 5 Minuten / 300s
#define MRW_COMPENSATION_6_MINUTES						36		///< Zeitangabe 6 Minuten / 360s
#define MRW_COMPENSATION_10_MINUTES						60		///< Zeitangabe 10 Minuten / 600s
#define MRW_COMPENSATION_20_MINUTES						120		///< Zeitangabe 20 Minuten / 1200s
#define MRW_COMPENSATION_30_MINUTES						180	///< Zeitangabe 30 Minuten / 1800s

#define MRW_COMPENSATION_60_MINUTES						360	///< Zeitangabe 60 Minuten / 3600s
/*~-1*/
#endif
/*~E:I13*/
/*~E:A11*/
/*~A:14*/
/*~+:Struktur-Definitionen*/
/*~T*/
/// @cond PROGRAMMERS_MANUAL
/*~T*/
typedef struct
{
	char 	byTemperature;				///< Temperatur
	long	lDeviation;					///< Abweichung
}POINT;
/*~T*/
typedef struct
{
	unsigned char 	chNbPointsRecorded;	///< Anzahl der bereits aufgenommenen Punkte
	int				nCorrectionTable[MRW_COMPENSATION_NB_SAMPLINGPOINTS];
										///< Korrekturtabelle
	long			lOffset_20;			///< Offset bei 20�C
	POINT			Minimum;			///< Minimale Abweichung
	POINT			Maximum;			///< Maximale Abweichung	
	long			lRMW_20_1;			///< Rohmesswert Nr.1 bei 20�C (Drifterkennung)
	long			lRMW_20_2;			///< Rohmesswert Nr.2 bei 20�C (Drifterkennung)
	char			lRMW_20_RecTemp;	///< Temperatur bei Driftaufnahme
	long			lActualDeviation;	///< aktuelle Abweichung
	int				nCorrectionValue;	///< Letzter errechneter Korrekturwert
	char 			byAnalysisResult;	///< Analyseergebnis
										///< xxxx xxx1	Drift-Fehler
										///< xxxx xx1x	Minimum-Fehler
										///< xxxx x1xx	Maximum-Fehler
										///< xxx1 xxxx	Driftermittlung wurde nicht durchgef�hrt
										///< xx1x xxxx	Kennlinien wurde nicht aufgenommen
										///< x1xx xxxx	Extrema wurden nicht ermittelt
	float			fCalibrationFactor;	///< Kalibrierfaktor zur Digit/kg-Umrechnung
}MRW_COMPENSATION_RESULTS;
/*~T*/
typedef struct
{
	float			fMaxDeviation;		///< maximal zul�ssiger Temperaturgang
	float			fMaxDrift;			///< maximal zul�ssiger Drift
}MRW_COMPENSATION_LIMITS;
/*~T*/
typedef struct
{
	unsigned char 				chStatus;		///< Status der Statemachine
	char 						byTempKompOn;	///< Merker f�r eingeschaltete Kompensation
	char 						byRecCharacteristicsOn;	///< Merker f�r eingeschaltete Kennlinienaufnahme

	unsigned char				chRecMode;		///< Aufnahme-Modus
	unsigned char				byWaitFctInitialized;	///< Wait-Funktion initialisiert
	MRW_COMPENSATION_RESULTS 	Results;		///< Ergebnisse der Kompensationswertaufnahme
}MRW_COMPENSATION_TEMPERATURE_COMPENSATION;
/*~T*/
/// @endcond
/*~E:A14*/
/*~A:15*/
/*~+:Funktionsdeklarationen*/
/*~T*/
extern void 			MRW_Compensation_Clear(unsigned char chWhat2Clear,long lSecurityCode);
extern void 			MRW_Compensation_GetCheckLimits(float *pfMaxDeviation, float *pfMaxDrift);
extern char 			MRW_Compensation_GetCompensationOnOffStatus(void);
extern int 				MRW_Compensation_GetCompensationValue(unsigned char chWhat2Get,char byTemperature);

extern void 			MRW_Compensation_GetData(unsigned char chWhat2Get,char byTemperature,void *pvData);

extern char 			MRW_Compensation_GetRecCharacteristicsOnOffStatus(void);
extern void 			MRW_Compensation_Init(unsigned char chInitMode);
extern void 			MRW_Compensation_InitRecCharacteristics(float fCalibrationFactor,unsigned char chRecMode);


extern unsigned char 	MRW_Compensation_RecCharacteristics(long lRMW2Evaluate,char byTemperature);

extern char 			MRW_Compensation_SetRefPoints(char chTemperature,int nCorVal);

extern unsigned char 	MRW_Compensation_SetCheckLimits(float fMaxDeviation, float fMaxDrift);
extern void 			MRW_Compensation_SetCompensationOn(char byOnOff);
extern void 			MRW_Compensation_SetDefaults(void);
extern void 			MRW_Compensation_SetRecCharacteristicsOn(char byOnOff);
extern char 			MRW_Compensation_TemperatureCompensation(long *plValue2Compensate,char byTemperature);

extern char* 			MRW_Compensation_Version(void);
extern char 			MRW_Compensation_Wait(char byNominalTemperature,char byWait4What,char byTemperature,char byTemperatureSpan,unsigned int uTime);

/*~E:A15*/
/*~A:16*/
/*~+:Variablen*/
/*~T*/

/*~E:A16*/
/*~-1*/
#endif
/*~E:I9*/
