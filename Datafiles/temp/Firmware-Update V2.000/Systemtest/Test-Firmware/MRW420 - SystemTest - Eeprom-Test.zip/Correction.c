/*~-1*/
/*~XSF_LANGUAGE: C/C++*/
/*~K*/
/*~+:File :        Correction.c*/
/*~+:*/
/*~+:Version :     V1.0*/
/*~+:*/
/*~+:Date :        04.07.2005*/
/*~+:*/
/*~+:Time :        10:23*/
/*~+:*/
/*~+:Author :      MOF*/
/*~+:*/
/*~+:Hardware :*/
/*~+:*/
/*~+:Description : Routinen zur Korrektur der Messwerte. */
/*~+:*/
/*~+:*/
/*~A:1*/
/*~+:Includes*/
/*~T*/
#include "Correction.h"

/*~E:A1*/
/*~A:2*/
/*~+:Funktionseigene Definitionen*/
/*~T*/

/*~E:A2*/
/*~A:3*/
/*~+:Funktionseigene Struktur-Definitionen*/
/*~T*/

/*~E:A3*/
/*~A:4*/
/*~+:Funktionsprototypen*/
/*~T*/
unsigned char 		Correction_Ini(unsigned char byMode);
char 				Correction_Interface(unsigned char byChannel,MEASUREMENT_VALUE* pMeasurement2Correct);
/*~E:A4*/
/*~A:5*/
/*~+:Globale Variablen*/
/*~T*/

/*~E:A5*/
/*~A:6*/
/*~+:unsigned char 		Correction_Ini(unsigned char byMode)*/
/*~F:7*/

/*!
\fn unsigned char Correction_Ini(unsigned char byMode)

<b>Beschreibung:</b><br>

\param
byMode:

\return

\retval

<b>Zugriff:</b><br>
[X] �ffentlich / [ ] Privat

\ref
ExamplePage_XXX "Beispiel 'XXX'"
*/
unsigned char Correction_Ini(unsigned char byMode)
/*~-1*/
{
   /*~A:8*/
   /*~+:Beschreibung*/
   /*~T*/
   /*!
   \fn unsigned char Correction_Ini(unsigned char byMode)
   
   <b>Beschreibung:</b><br>
   Initialisierung der Korrektur-Funktion.
   
   \param
   byMode:
   \param
   0 = Initialisierung mit Defaultwerten, 
   \param
   1 = Initialisierung mit abgespeicherten Werten.
   
   \return
   
   \retval
   
   
   <b>Zugriff:</b><br>
   [ ] �ffentlich / [X] Privat
   */
   /*~E:A8*/
   /*~C:9*/
   switch (byMode)
   /*~-1*/
   {
      /*~F:10*/
      case 0:		// Initialisierung mit Defaultwerten
      /*~-1*/
      {
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F10*/
      /*~F:11*/
      case 1:		// Initialisierung mit abgespeicherten Werten
      /*~-1*/
      {
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F11*/
   /*~-1*/
   }
   /*~E:C9*/
   /*~T*/
   return 0;
/*~-1*/
}
/*~E:F7*/
/*~E:A6*/
/*~A:12*/
/*~+:char 				Correction_Interface(unsigned char byChannel,MEASUREMENT_VALUE* pMeasurement2Correct)*/
/*~F:13*/
char Correction_Interface(unsigned char byChannel,MEASUREMENT_VALUE* pMeasurement2Correct)
/*~-1*/
{
   /*~A:14*/
   /*~+:Variablendeklarationen*/
   /*~T*/
   // Variablendeklarationen

   /*~I:15*/
#ifdef MIT_E_MODUL_KOMPENSATION
   /*~T*/
   float fTempDiff,fCorrFactor,fMeassurement2Correct;
   /*~-1*/
#endif
   /*~E:I15*/
   /*~E:A14*/
   /*~A:16*/
   /*~+:Variableninitialisierungen*/
   /*~T*/
   // Variableninitialisierungen
   /*~E:A16*/
   /*~A:17*/
   /*~+:Beschreibung*/
   /*~T*/
   /*!
   \fn char Correction_Interface(MEASUREMENT_CORRECTIONPARAMETERS *pCorrectionParameters)
   
   <b>Beschreibung:</b><br>
   Korrektur-Funktion.
   
   \param
   *pCorrectionParameters:
   
   \return
   
   \retval
   
   
   <b>Zugriff:</b><br>
   [ ] �ffentlich / [X] Privat
   */
   /*~E:A17*/
   /*~C:18*/
   switch (byChannel)
   /*~-1*/
   {
      /*~A:19*/
      /*~+:WEIGHT_WEIGHTCHANNEL*/
      /*~F:20*/
      case WEIGHT_WEIGHTCHANNEL:
      /*~-1*/
      {
         /*~T*/
         // Temperaturkompensation durchf�hren
         MRW_Compensation_TemperatureCompensation(&pMeasurement2Correct->nLong,Global.byTemperature);
         /*~I:21*/
#ifdef MIT_E_MODUL_KOMPENSATION
         /*~I:22*/
         if (Global.chEModulCompensationOn)
         /*~-1*/
         {
            /*~K*/
            /*~+:// E-Modul-Kompensation eingeschaltet*/
            /*~I:23*/
            if (!MRW_Compensation_GetRecCharacteristicsOnOffStatus())
            /*~-1*/
            {
               /*~K*/
               /*~+:// Keine Kennlinienaufnahme*/
               /*~T*/
               // E-Modul-Kompensation
               fTempDiff = (float)Global.byTemperature - 20.0;
               fCorrFactor = 1.0 + fTempDiff * FACTOR_E_MODUL;
               fMeassurement2Correct = (float)pMeasurement2Correct->nLong;

               fMeassurement2Correct = fMeassurement2Correct * fCorrFactor;

               pMeasurement2Correct->nLong = (long)fMeassurement2Correct;
            /*~-1*/
            }
            /*~E:I23*/
         /*~-1*/
         }
         /*~E:I22*/
         /*~-1*/
#endif
         /*~E:I21*/
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F20*/
      /*~E:A19*/
      /*~A:24*/
      /*~+:CURRENTINTERFACE_FEEDBACKCHANEL*/
      /*~F:25*/
      case CURRENTINTERFACE_FEEDBACKCHANEL:
      /*~-1*/
      {
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F25*/
      /*~E:A24*/
   /*~-1*/
   }
   /*~E:C18*/
   /*~T*/
   return 0;
/*~-1*/
}
/*~E:F13*/
/*~E:A12*/
