/*~-1*/
/*~XSF_LANGUAGE: C/C++*/
/*~K*/
/*~+:File :        Structdef.h*/
/*~+:*/
/*~+:Version :     V1.0*/
/*~+:*/
/*~+:Date :        17.05.2005*/
/*~+:*/
/*~+:Time :        10:23*/
/*~+:*/
/*~+:Author :      MOF*/
/*~+:*/
/*~+:Hardware :*/
/*~+:*/
/*~+:Description :*/
/*~I:1*/
#ifndef __STRUCTDEF_H

/*~T*/
#define __STRUCTDEF_H

/*~A:2*/
/*~+:Includes*/
/*~T*/

/*~E:A2*/
/*~A:3*/
/*~+:Definitionen*/
/*~+:*/
/*~T*/
#define GLOBAL_STRINGSIZE	16
/*~E:A3*/
/*~A:4*/
/*~+:Struktur-Definitionen*/
/*~A:5*/
/*~+:GLOBAL_UNIVALUE*/
/*~T*/
typedef union
{
	char 			byChar;			///<Char-Wert;
	int				nInt;			///< Int-Wert.
	long 			nLong;			///< Long-Wert.
	float 			fFloat;			///< Float-Wert.
	unsigned char 	szString[GLOBAL_STRINGSIZE];	///< String.
}GLOBAL_UNIVALUE;		///< UNION zur Speicherung von Long- oder Float-Werten.
/*~E:A5*/
/*~A:6*/
/*~+:GLOBAL_UNIVALUE_SHORT*/
/*~T*/
typedef union
{
	char 			byChar;			///<Char-Wert;
	int				nInt;			///< Int-Wert.
	long 			nLong;			///< Long-Wert.
	float 			fFloat;			///< Float-Wert.
}GLOBAL_UNIVALUE_SHORT;		///< UNION zur Speicherung von Long- oder Float-Werten.
/*~E:A6*/
/*~A:7*/
/*~+:Strukturdefinition GLOBAL*/
/*~T*/
typedef struct
{
//	char byRecCharacteristics;
	char bySetStateManualy;
	unsigned int uTestMode;
}MODE;
/*~T*/
typedef struct
{
	MODE Mode;								///< �bergeordnete Betriebszustandsflags
	long lRMW_PowerSupply;					///< Rohmesswert 5V-Spannungsversorgung
	char byTemperature;						///< Prozessortemperatur
	char byLastTemperature;					///< letzte ermittelte Prozessortemperatur
	char byTemperatureOffset;				///< Temperaturoffset des Prozessors
	char bySimulatedTemperature;			///< simulierte Prozessortemperatur
	unsigned char byErrorPowerSupplyCounter;	///< Z�hler zur Netzteil�berwachung
	unsigned char byErrorPowerSupplyStateCounter;	///< Z�hler zur Netzteilstatus�berwachung
	unsigned long ulSystemstatus;			///< Systemstatus
	unsigned long ulSystemstatus_Partner;	///< Systemstatus des Partners
	unsigned char chLimitStatus_Partner;	///< Grenzwertstatus des Partners
	unsigned char chTeachInStatus;			///< Status des TeachIn-Moduls
	unsigned long ulSystemID;				///< SystemID der Platine
	unsigned long ulOperatingHours;			///< Absoluter Betriebsstundenz�hler
	unsigned long ulOperatingHours_2;		///< Relativer Betriebsstundenz�hler
	unsigned long ulAdminCode;				///< Administrator-Code 
	unsigned char chEModulCompensationOn;	///< E-Modul-Kompensation eingeschaltet
}GLOBAL;
/*~E:A7*/
/*~E:A4*/
/*~A:8*/
/*~+:Funktionsdeklarationen*/
/*~T*/


/*~E:A8*/
/*~A:9*/
/*~+:Variablen*/
/*~T*/

/*~E:A9*/
/*~-1*/
#endif
/*~E:I1*/
