/*~-1*/
/*~XSF_LANGUAGE: C/C++*/
/*~A:1*/
/*~+:Versions-Beschreibung*/
/*~A:2*/
/*~+:Version und Versionsdatum*/
/*~T*/
/*!
\addtogroup versions_externals
@{
<tr>
	<td>AverageFilter.h</td>
	<td>Michael Offenbach</td>
	<td>1.001</td>
	<td>01.06.2005</td>
	<td></td>
</tr>
@}
*/
/*~E:A2*/
/*~A:3*/
/*~+:Manual*/
/*~A:4*/
/*~+:Ziel-Hardware*/
/*~T*/
/*!\page HardwarePage Ziel-Hardware

\section sec_HardwarePage_DeadBandFilter 'Totband-Filter'

<table border=1 width=100% height=1% rules=rows cellspacing=0 bgcolor="#E0E0F0">

<tr align=left valign=top>
	<th>Motherboard</th>
	<th>Prozessor</th>
	<th>ROM</th>
	<th>RAM</th>
</tr>

<tr>
	<td>MRW-Limit V1.2B 2/2004</td>
	<td>8051-Core</td>
	<td>62 <B>kByte</B></td>
	<td>2 <B>kByte</B></td>
</tr></table>

*/
/*~E:A4*/
/*~A:5*/
/*~+:Compiler-Einstellungen*/
/*~T*/
/*!\page CompilerPage Compiler-Einstellungen

\section sec_CompilerPage_DeadBandFilter 'Totband-Filter'

<table border=1 width=100% height=1% rules=rows cellspacing=0 bgcolor="#E0E0F0">

<tr align=left valign=top>
	<th>Compiler</th>
	<th>Betriebssystem</th>
	<th>Speichermodell</th>
	<th>Code-Speicher-Gr��e</th>
	<th>Optimierungen</th>
	<th>Sonstiges</th>
</tr>

<tr>
	<td>Keil uVision2 V2.40<BR>C51 V7.08<BR>A51 V7.08a</td>
	<td>Kein Betriebssystem</td>
	<td>Large: variables in XDATA</td>
	<td>Large: 64k program</td>
	<td>6 Loop rotation<BR>Favor speed</td>
	<td>---</td>
</tr></table>

*/
/*~E:A5*/
/*~A:6*/
/*~+:Ressourcen*/
/*~T*/
/*!\page RessourcePage Ressourcen

\section sec_RessourcePage_DeadBandFilter 'Totband-Filter'

<table border=1 width=100% height=1% rules=rows cellspacing=0 bgcolor="#E0E0F0">

<tr align=left valign=top>
	<th>CODE</th>
	<th>IDATA</th>
	<th>XDATA</th>
	<th>Dynamische Variablen</th>
</tr>

<tr>
	<td>--- <B>Bytes</B></td>
	<td>--- <B>Bytes</B></td>
	<td>--- <B>Bytes</B></td>
	<td>19 * Anzahl der Filterkan�le <B>Bytes</B></td>
</tr></table>

*/
/*~E:A6*/
/*~A:7*/
/*~+:Zykluszeiten*/
/*~T*/
/*!\page CycletimePage Zykluszeiten

\section sec_CycletimePage_DeadBandFilter 'Totband-Filter'

<table border=1 width=100% height=1% rules=rows cellspacing=0 bgcolor="#E0E0F0">

<tr align=left valign=top>
	<th>Minimale Durchlaufzeit</th>
	<th>Maximale Durchlaufzeit</th>
</tr>

<tr>
	<td>--- <B>ms</B></td>
	<td>--- <B>ms</B></td>
</tr></table>

*/
/*~E:A7*/
/*~A:8*/
/*~+:Verschiedenes*/
/*~T*/
/*!\page MiscPage Verschiedenes

\section sec_MiscPage_DeadBandFilter 'Totband-Filter'

<table border=1 width=100% height=1% rules=rows cellspacing=0 bgcolor="#E0E0F0">

<tr align=left valign=top>
	<th>Benutzte Interrups</th>
	<th>Benutzte Registerb�nke</th>
</tr>

<tr>
	<td>---</td>
	<td>---</td>
</tr></table>

*/
/*~E:A8*/
/*~A:9*/
/*~+:Lifecycle*/
/*~T*/
/*!\page LifeCyclePage Lifecycle

\section sec_LifeCyclePage_DeadBandFilter 'Totband-Filter' 

<table border=1 width=100% height=1% rules=rows cellspacing=0 bgcolor="#E0E0F0">

<tr align=left valign=top>
	<th>Version</th>
	<th>Datum</th>
	<th>Programmierer</th>
	<th>�nderungen</th>
</tr>

<tr>
	<td>1.000</td>
	<td>23.03.05</td>
	<td>Michael Offenbach</td>
	<td>Erste lauff�hige Version</td>
</tr>
<tr>
	<td>1.001</td>
	<td>01.06.05</td>
	<td>Michael Offenbach</td>
	<td>Funktion zur Ausgabe der Filterbandbreite eingef�gt und Dokumentation �berarbeitet.</td>
</tr>
<tr>
	<td>1.002</td>
	<td>27.06.05</td>
	<td>Michael Offenbach</td>
	<td>Funktion zum Setzen der Filterbandbreite eingef�gt. Zudem wird jetzt der Referenzwert der Filterung intern auf den letzten gefilterten Wert gesetzt - eine manuelle �bergabe entf�llt somit.</td>
</tr>
<tr>
	<td>1.003</td>
	<td>04.10.05</td>
	<td>Michael Offenbach</td>
	<td>
Beim allokieren dynamischen Speichers wurde die korrekte Ausf�hrung nicht korrekt erkannt - Abfrage auf g�ltigen Pointer beim Allokieren �berarbeitet.
</td>
</tr>
</table>

*/
/*~E:A9*/
/*~A:10*/
/*~+:Beispiel*/
/*~T*/
/*!\page ExamplePage_DeadBandFilter Beispiel 'Totband-Filter'
\code


//Modulbeschreibung:
//Programm zur Demonstration der Einbindung der Totband-Filter-Befehle.


// Includes
#include "DeadBandFilter.h"	// Funktionen der Totband-Filterung einbinden
#include <aduc836.h>
#include <stdlib.h>

// Definitionen
#define MASTER_CHANEL		0
#define SLAVE_CHANEL		1
// Wiederholungen der Werte bis zum n�chsten Wert
#define REPEAT_RMW_VALUE	0

// nur f�r ADuC836
#pragma NOAREGS

// Globale Variablen
// Beispiel-Messwerttabelle 'Master'
code long lWerte_1[] =
{4189, 4190, 4193, 4152, 4157, 4205, 4222, 4230, 4237, 4161, 4068, 4017, 3992, 4031, 4020, 0x7FFF};

// Beispiel-Messwerttabelle 'Slave'
code long lWerte_2[] =
{11963, 12003, 12002, 11746, 11990, 12247, 12106, 12052, 11790, 11550, 11429, 11943, 11957, 12281, 11725, 0x7FFF};

unsigned char ptrDynVar[0x1FF];
unsigned char *pTestVar;

main()
{
// Variablendeklarationen
   int nPtr;
   long lRohmesswert_Master, lLastRohmesswert_Master;
   long lRohmesswert_Slave;
   float fGewicht_Slave, fLastGewicht_Slave;
   unsigned int nCycleCounterRohmesswerte;
   unsigned char byError;

// Variableninitialisierungen
// die n�chsten drei Zeilen m�ssen f�r den ADuC836 gesetzt werden
   CFG836 |= 1;
   PLLCON &= 0xF8;
   T0 = 0;
   
   nCycleCounterRohmesswerte = 0;
   nPtr = 0;
   byError = 0;
   lLastRohmesswert_Master = 0;
   fLastGewicht_Slave = 0;

// Speicherbereich f�r dynamische Variablen reservieren
   init_mempool(ptrDynVar,sizeof(ptrDynVar));
   
// Zwei Totbandfilter f�r Master und Slave anlegen
   byError = DeadBandFilter_Init(2);

// 1.Filterkanal f�r Longwerte parametrieren - Bandbreite +/- 10 
   byError |= DeadBandFilter_Setup(MASTER_CHANEL,10,DEADBANDFILTER_LONGDATA);

// 2.Filterkanal f�r Floatwerte parametrieren - Bandbreite +/- 5.5
   byError |= DeadBandFilter_Setup(SLAVE_CHANEL,5.5,DEADBANDFILTER_FLOATDATA);

// noch gen�gend dynamischer Speicher vorhanden ?
	pTestVar = (char*)malloc(1);
	if ((unsigned char)pTestVar)
   {

// irgendwelche Fehler aufgetaucht ?
      while (!byError)	
      {
         if (nCycleCounterRohmesswerte-- == 0)
         {
            nCycleCounterRohmesswerte = REPEAT_RMW_VALUE;
            if (lWerte_1[nPtr] == 0x7FFF)
            {
               nPtr = 0;
            }
            lRohmesswert_Master = lWerte_1[nPtr];
            lRohmesswert_Slave = lWerte_2[nPtr];
            nPtr++;
         }
// Slave-Rohmesswert kalibrieren
         fGewicht_Slave = (float)lRohmesswert_Slave / 16;

// Filterung des Master-Rohmesswertes 
         byError |= DeadBandFilter_Filter(MASTER_CHANEL,&lRohmesswert_Master,&lLastRohmesswert_Master);

// Filterung des Slave-Gewichtwertes 
         byError |= DeadBandFilter_Filter(SLAVE_CHANEL,&fGewicht_Slave,&fLastGewicht_Slave);

// aktuellen Rohmess-/Gewichtswert als neue Referenz zwischenspeichern
         lLastRohmesswert_Master = lRohmesswert_Master;
         fLastGewicht_Slave = fGewicht_Slave;
      }
   }
}

\endcode
*/ 
/*~E:A10*/
/*~E:A3*/
/*~E:A1*/
/*~I:11*/
#ifndef __DEADBANDFILTER_H

/*~T*/
#define __DEADBANDFILTER_H
/*~A:12*/
/*~+:Includes*/
/*~T*/

/*~E:A12*/
/*~A:13*/
/*~+:Definitionen*/
/*~I:14*/
#ifdef DEADBANDFILTER_1 
/*~T*/
#define DEADBANDFILTER_NB_CHANELS	1	///< Anzahl der Filterkan�le
/*~-1*/
#endif
/*~E:I14*/
/*~I:15*/
#ifdef DEADBANDFILTER_2 
/*~T*/
#define DEADBANDFILTER_NB_CHANELS	2	///< Anzahl der Filterkan�le
/*~-1*/
#endif
/*~E:I15*/
/*~T*/
#define DEADBANDFILTER_LONGDATA		0	///< Long-Werte dienen als Eingangsdaten
#define DEADBANDFILTER_FLOATDATA	1	///< Float-Werte dienen als Eingangsdaten
/*~E:A13*/
/*~A:16*/
/*~+:Struktur-Definitionen*/
/*~T*/

/*~E:A16*/
/*~A:17*/
/*~+:Funktionsdeklarationen*/
/*~T*/
extern char 	DeadBandFilter_Filter(unsigned char byChanel, void* pValue);
extern float 	DeadBandFilter_GetBandWidth(unsigned char byChanel);
extern char 	DeadBandFilter_Init(void);
extern char 	DeadBandFilter_SetBandWidth(unsigned char byChanel, float fBandWidth);
extern void 	DeadBandFilter_SetFilterOn(char byOnOff);
extern char 	DeadBandFilter_Setup(unsigned char byChanel, float fBandWidth, unsigned char byDataType);

extern char* 	DeadBandFilter_Version(void);

/*~E:A17*/
/*~A:18*/
/*~+:Variablen*/
/*~T*/

/*~E:A18*/
/*~-1*/
#endif
/*~E:I11*/
