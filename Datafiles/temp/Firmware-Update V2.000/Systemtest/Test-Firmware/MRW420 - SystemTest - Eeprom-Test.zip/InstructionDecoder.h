/*~-1*/
/*~XSF_LANGUAGE: C/C++*/
/*~A:1*/
/*~+:Versions-Beschreibung*/
/*~A:2*/
/*~+:Version und Versionsdatum*/
/*~T*/
/*!
\mainpage "Modul-Beschreibung"
\author Michael Offenbach
\date 09.02.2022 
\version V1.002
\warning
*/
/*~E:A2*/
/*~A:3*/
/*~+:Lifecycle*/
/*~T*/
/*!\page LifeCyclePage Lifecycle

\section sec_LifeCyclePage_InstructionDecoder 'InstructionDecoder'

<table border=1 width=100% height=1% rules=rows cellspacing=0 bgcolor="#E0E0F0">

<tr align=left valign=top>
	<th>Version</th>
	<th>Datum</th>
	<th>Programmierer</th>
	<th>�nderungen</th>
</tr>

<tr>
	<td>1.000</td>
	<td>27.05.05</td>
	<td>Michael Offenbach</td>
	<td>Erste lauff�hige Version</td>
</tr>

<tr>
	<td>1.002</td>
	<td>29.11.21</td>
	<td>Michael Offenbach</td>
	<td>Befehle 'ENA', 'DIS' und 'UPD' erg�nzt (Kommunikationssperre / Eeprom-Reorganisation wg. Update)</td>
</tr>
</table>

*/
/*~E:A3*/
/*~E:A1*/
/*~I:4*/
#ifndef __INSTRUCTIONDECODER_H

/*~T*/
#define __INSTRUCTIONDECODER_H

/*~A:5*/
/*~+:Includes*/
/*~T*/
#include "Structdef.h"
/*~E:A5*/
/*~A:6*/
/*~+:Definitionen*/
/*~T*/
#define INSTRUCTIONDECODER_SEND_TEXT				0	///< Text senden (Kanal 0)
#define INSTRUCTIONDECODER_SEND_OK					0	///< OK senden (Kanal 1)
#define INSTRUCTIONDECODER_SEND_E001				1	///< E001 senden  
#define INSTRUCTIONDECODER_SEND_E002				2	///< E002 senden
#define INSTRUCTIONDECODER_SEND_E003				3	///< E003 senden
#define INSTRUCTIONDECODER_SEND_E004				4	///< E004 senden
#define INSTRUCTIONDECODER_SEND_E005				5	///< E005 senden
#define INSTRUCTIONDECODER_SEND_E006				6	///< E006 senden
#define INSTRUCTIONDECODER_SEND_E007				7	///< E007 senden
#define INSTRUCTIONDECODER_SEND_E008				8	///< E008 senden
#define INSTRUCTIONDECODER_SEND_E009				9	///< E009 senden
#define INSTRUCTIONDECODER_SEND_E010				10	///< E010 senden
#define INSTRUCTIONDECODER_SEND_E011				11	///< E011 senden
#define INSTRUCTIONDECODER_SEND_E012				12	///< E012 senden
#define INSTRUCTIONDECODER_SEND_NOK					254	///< NOK senden
#define INSTRUCTIONDECODER_SEND_NOTHING				255	///< Nichts senden
/*~T*/
#define INSTRUCTIONDECODER_PARAMETER_FILTERDEPTH						0	
///< Filtertiefe
#define INSTRUCTIONDECODER_PARAMETER_TEMPERATURE						2
///< Temperatur	
#define INSTRUCTIONDECODER_PARAMETER_ADC_RMW							10
///< RMW direkt vom ADC
#define INSTRUCTIONDECODER_PARAMETER_RMW_FILTERED						12
///< gefilterter RMW
#define INSTRUCTIONDECODER_PARAMETER_RMW_ZERO_CORRECTED					14
///< gefilterter und Nullpunkt bereinigter RMW
#define INSTRUCTIONDECODER_PARAMETER_TEMP_OFFSET						20
///< Temperaturoffset
#define INSTRUCTIONDECODER_PARAMETER_OPERATING_HOURS					30
///< Betriebsstunden
#define INSTRUCTIONDECODER_PARAMETER_CHARACTERISTICS_STATUS				100	
///< Status der Kennlinienaufnahme
#define INSTRUCTIONDECODER_PARAMETER_CORRECTION_VALUE					101
///< Korrekturwert der Temperaturkompensation
#define INSTRUCTIONDECODER_PARAMETER_POINTS_RECORDED					102
///< Anzahl der aufgenommenen Kennlinienpunkte
#define INSTRUCTIONDECODER_PARAMETER_MAX_DEVIATION_KG					103
///< Maximale Abweichung der �berpr�fung der Kompensation in KG
#define INSTRUCTIONDECODER_PARAMETER_MAX_DEVIATION_TEMP					104
///< Maximale Abweichung der �berpr�fung der Kompensation in �C
#define INSTRUCTIONDECODER_PARAMETER_MIN_DEVIATION_KG					105
///< Minimale Abweichung der �berpr�fung der Kompensation in KG
#define INSTRUCTIONDECODER_PARAMETER_MIN_DEVIATION_TEMP					106
///< Minimale Abweichung der �berpr�fung der Kompensation in �C
#define INSTRUCTIONDECODER_PARAMETER_ACTUAL_DEVIATION_KG				107
///< Aktuelle Abweichung der �berpr�fung der Kompensation in KG
#define INSTRUCTIONDECODER_PARAMETER_CHARACTERISTICS					108
///< Kennlinienpunkt auslesen
#define INSTRUCTIONDECODER_PARAMETER_CHARACTERISTICS_WITH_OFFSET		109
///< Kennlinienpunkt mit Offset auslesen
#define INSTRUCTIONDECODER_PARAMETER_MAXIMUM_TEMP						110
///< Kompensations�berpr�fung: Maximale Abweichung bei Temperatur				
#define INSTRUCTIONDECODER_PARAMETER_MAXIMUM_KG							111
///< Kompensations�berpr�fung: Maximale Abweichung in KG				
#define INSTRUCTIONDECODER_PARAMETER_MINIMUM_TEMP						112
///< Kompensations�berpr�fung: Minimale Abweichung bei Temperatur
#define INSTRUCTIONDECODER_PARAMETER_MINIMUM_KG							113
///< Kompensations�berpr�fung: Minimale Abweichung in KG				
#define INSTRUCTIONDECODER_PARAMETER_1ST_RMW20							114
///< Erster Rohmesswert bei Referenztemperatur				
#define INSTRUCTIONDECODER_PARAMETER_2ND_RMW20							115
///< Zweiter Rohmesswert bei Referenztemperatur
#define INSTRUCTIONDECODER_PARAMETER_DRIFT								116
///< Drift								
#define INSTRUCTIONDECODER_PARAMETER_REC_CHARCTERISTICS_ERROR			117
///< Fehlerstatus der Kennlinienaufnahme

/*~E:A6*/
/*~A:7*/
/*~+:Struktur-Definitionen*/
/*~T*/

/*~E:A7*/
/*~A:8*/
/*~+:Funktionsdeklarationen*/
/*~T*/
extern void				InstructionDecoder(void);
extern char 			InstructionDecoder_CheckLimits(void *pParameter2Check, void *pLimitLow, void *pLimitHigh,unsigned char chDataType);

/*~E:A8*/
/*~A:9*/
/*~+:Variablen*/
/*~T*/

/*~E:A9*/
/*~-1*/
#endif
/*~E:I4*/
