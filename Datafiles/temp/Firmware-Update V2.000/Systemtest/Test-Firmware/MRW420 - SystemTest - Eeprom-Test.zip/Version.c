/*~-1*/
/*~XSF_LANGUAGE: C/C++*/
/*~K*/
/*~+:File :        Version.c*/
/*~+:*/
/*~+:Version :     V1.104*/
/*~+:*/
/*~+:Date :        09.02.2022*/
/*~+:*/
/*~+:Time :        10:23*/
/*~+:*/
/*~+:Author :      MOF*/
/*~+:*/
/*~+:Hardware :*/
/*~+:*/
/*~+:Description :*/
/*~+:*/
/*~+:*/
/*~A:1*/
/*~+:Lifecycle*/
/*~T*/

/*~E:A1*/
/*~A:2*/
/*~+:Includes*/
/*~T*/
#include "Version.h"
#include "Global.h"
/*~E:A2*/
/*~A:3*/
/*~+:Funktionseigene Definitionen*/
/*~T*/

/*~E:A3*/
/*~A:4*/
/*~+:Funktionseigene Struktur-Definitionen*/
/*~T*/

/*~E:A4*/
/*~A:5*/
/*~+:Funktionsprototypen*/
/*~T*/
void 		Version_PrintVersions(unsigned char byWhat2Print);

/*~K*/
/*~+:/~* Hinzugef�gt am 09.02.2022 *~/*/
/*~T*/
unsigned long 	Version_SoftwareVersionToLong(void);

/*~K*/
/*~+:/~* Ende - Hinzugef�gt am 09.02.2022 *~/*/
/*~E:A5*/
/*~A:6*/
/*~+:Globale Variablen*/
/*~T*/
// Globale Variablen
/*~E:A6*/
/*~I:7*/
#ifdef DEVELOPMENT_SW 
/*~T*/
// Entwicklungs-Softwareversion
unsigned char code TEXT_SOFTWARE_VERSION[] = {"E1.200, 09.02.2022"};

/*~O:I7*/
/*~-1*/
#else
/*~T*/
// Softwareversion
unsigned char code TEXT_SOFTWARE_VERSION[] = {"V1.200, 09.02.2022"};

/*~-1*/
#endif
/*~E:I7*/
/*~T*/
// Hardwareversion
unsigned char code TEXT_HARDWARE_VERSION[] = {"V1.2_,     02/2007"};
// Application
unsigned char code TEXT_APPLICATION_TYPE[] = {"MRW420"};
/*~A:8*/
/*~+:void Version_PrintVersions(unsigned char byWhat2Print)*/
/*~F:9*/
void Version_PrintVersions(unsigned char byWhat2Print)
/*~-1*/
{
   /*~C:10*/
   switch (byWhat2Print)
   /*~-1*/
   {
      /*~A:11*/
      /*~+:Hardware-Version*/
      /*~F:12*/
      case 0:	// Hardware-Version
      /*~-1*/
      {
         /*~I:13*/
         if (!SYSTEM_MRW_MANAGER)
         /*~-1*/
         {
            /*~T*/
            Communication_SendString(COMMUNICATION_RS232,T_TEXT_HARDWAREVERSION,1,0);

         /*~-1*/
         }
         /*~E:I13*/
         /*~T*/
         Communication_SendString(COMMUNICATION_RS232,TEXT_HARDWARE_VERSION,0,0);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F12*/
      /*~E:A11*/
      /*~A:14*/
      /*~+:Software/-Modul-Verionen*/
      /*~F:15*/
      case 1:	// Software/-Modul-Verionen
      /*~-1*/
      {
         /*~I:16*/
         if (!SYSTEM_MRW_MANAGER)
         /*~-1*/
         {
            /*~T*/
            Communication_SendString(COMMUNICATION_RS232,T_TEXT_SOFTWAREVERSION,1,0);

         /*~-1*/
         }
         /*~E:I16*/
         /*~T*/
         Communication_SendString(COMMUNICATION_RS232,TEXT_SOFTWARE_VERSION,0,1);
         /*~I:17*/
         if (!SYSTEM_MRW_MANAGER)
         /*~-1*/
         {
            /*~T*/
            ///< Modulversionen ausgeben
            /*~T*/
            Communication_SendString(COMMUNICATION_RS232,T_TEXT_SOFTWARE_VERSION_ADC,0,0);
            Communication_SendString(COMMUNICATION_RS232,ADuC836_Version(1),0,1);
            /*~T*/
            Communication_SendString(COMMUNICATION_RS232,T_TEXT_SOFTWARE_VERSION_DAC,0,0);
            Communication_SendString(COMMUNICATION_RS232,ADuC836_Version(2),0,1);
            /*~T*/
            Communication_SendString(COMMUNICATION_RS232,T_TEXT_SOFTWARE_VERSION_EXTERNAL,0,0);
            Communication_SendString(COMMUNICATION_RS232,ADuC836_Version(3),0,1);
            /*~T*/
            Communication_SendString(COMMUNICATION_RS232,T_TEXT_SOFTWARE_VERSION_FLASH,0,0);
            Communication_SendString(COMMUNICATION_RS232,ADuC836_Version(4),0,1);
            /*~T*/
            Communication_SendString(COMMUNICATION_RS232,T_TEXT_SOFTWARE_VERSION_RS232,0,0);
            Communication_SendString(COMMUNICATION_RS232,ADuC836_Version(5),0,1);
            /*~T*/
            Communication_SendString(COMMUNICATION_RS232,T_TEXT_SOFTWARE_VERSION_SPI,0,0);
            Communication_SendString(COMMUNICATION_RS232,ADuC836_Version(6),0,1);
            /*~T*/
            Communication_SendString(COMMUNICATION_RS232,T_TEXT_SOFTWARE_VERSION_TIMER,0,0);
            Communication_SendString(COMMUNICATION_RS232,ADuC836_Version(7),0,1);
            /*~T*/
            Communication_SendString(COMMUNICATION_RS232,T_TEXT_SOFTWARE_VERSION_WATCHDOG,0,0);
            Communication_SendString(COMMUNICATION_RS232,ADuC836_Version(8),0,1);
            /*~T*/
            Communication_SendString(COMMUNICATION_RS232,T_TEXT_SOFTWARE_VERSION_MEASUREMENT,0,0);
            Communication_SendString(COMMUNICATION_RS232,Measurement_Version(),0,1);
            /*~T*/
            Communication_SendString(COMMUNICATION_RS232,T_TEXT_SOFTWARE_VERSION_AVERAGEFILTER,0,0);
            Communication_SendString(COMMUNICATION_RS232,AverageFilter_Version(),0,1);
            /*~I:18*/
#ifdef SYSTEM_CND_WITH_DEADBAND_FILTER
            /*~T*/
            Communication_SendString(COMMUNICATION_RS232,T_TEXT_SOFTWARE_VERSION_DEADBANDFILTER,0,0);
            Communication_SendString(COMMUNICATION_RS232,DeadBandFilter_Version(),0,1);
            /*~-1*/
#endif
            /*~E:I18*/
            /*~T*/
            Communication_SendString(COMMUNICATION_RS232,T_TEXT_SOFTWARE_VERSION_COMPENSATION,0,0);
            Communication_SendString(COMMUNICATION_RS232,MRW_Compensation_Version(),0,1);
            /*~I:19*/
#ifdef MIT_TEACHIN_FUNKTION
            /*~T*/
            Communication_SendString(COMMUNICATION_RS232,T_TEXT_SOFTWARE_VERSION_TEACHIN,0,0);
            Communication_SendString(COMMUNICATION_RS232,TeachIn_Version(),0,1);
            /*~-1*/
#endif
            /*~E:I19*/
            /*~T*/
            Communication_SendString(COMMUNICATION_RS232,T_TEXT_SOFTWARE_VERSION_STATISTICS,0,0);
            Communication_SendString(COMMUNICATION_RS232,StatisticsLibrary_Version(),0,1);
            /*~T*/
            Communication_SendString(COMMUNICATION_RS232,T_TEXT_SOFTWARE_VERSION_EE24C64,0,0);
            Communication_SendString(COMMUNICATION_RS232,Ee24c64_Version(),0,1);
         /*~-1*/
         }
         /*~E:I17*/
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F15*/
      /*~E:A14*/
   /*~-1*/
   }
   /*~E:C10*/
/*~-1*/
}
/*~E:F9*/
/*~E:A8*/
/*~K*/
/*~+:/~* Hinzugef�gt am 09.02.2022 *~/*/
/*~A:20*/
/*~+:unsigned long Version_SoftwareVersionToLong(void)*/
/*~F:21*/
unsigned long Version_SoftwareVersionToLong(void)
/*~-1*/
{
   /*~A:22*/
   /*~+:Variablendeklarationen*/
   /*~T*/
   unsigned long ulVersion;
   unsigned char i;
   /*~E:A22*/
   /*~A:23*/
   /*~+:Variableninitialisierungen*/
   /*~T*/
   ulVersion = 0L;
   /*~E:A23*/
   /*~L:24*/
   for (i=1;i<6;i++)
   /*~-1*/
   {
      /*~I:25*/
      if ((TEXT_SOFTWARE_VERSION[i] >= '0')&&(TEXT_SOFTWARE_VERSION[i] <= '9'))
      /*~-1*/
      {
         /*~T*/
         ulVersion *= 10;
         ulVersion += (TEXT_SOFTWARE_VERSION[i] - 0x30);
      /*~-1*/
      }
      /*~E:I25*/
   /*~-1*/
   }
   /*~E:L24*/
   /*~T*/
   return(ulVersion);
/*~-1*/
}
/*~E:F21*/
/*~E:A20*/
/*~K*/
/*~+:/~* Ende - Hinzugef�gt am 09.02.2022 *~/*/
