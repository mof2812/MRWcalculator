/*~-1*/
/*~XSF_LANGUAGE: C/C++*/
/*~K*/
/*~+:File :        Weight.h*/
/*~+:*/
/*~+:Version :     V1.001*/
/*~+:*/
/*~+:Date :        09.02.2022*/
/*~+:*/
/*~+:Time :        10:23*/
/*~+:*/
/*~+:Author :      MOF*/
/*~+:*/
/*~+:Hardware :*/
/*~+:*/
/*~+:Description :*/
/*~I:1*/
#ifndef __WEIGHT_H

/*~T*/
#define __WEIGHT_H

/*~A:2*/
/*~+:Includes*/
/*~T*/
#include "Global.h"
/*~E:A2*/
/*~A:3*/
/*~+:Definitionen*/
/*~A:4*/
/*~+:Messwertkan�le*/
/*~T*/
#define WEIGHT_WEIGHTCHANNEL					0	///< Gewichtskanal

/*~T*/
#define WEIGHT_FILTERED_MEASUREMENT			0	///< Zwischenspeicher 'Gefilterter Rohmesswert'
#define WEIGHT_ZEROCORRECTED_MEASUREMENT	1	///< Zwischenspeicher 'Nullpunkt korrigierter Rohmesswert'	
/*~E:A4*/
/*~E:A3*/
/*~A:5*/
/*~+:Struktur-Definitionen*/
/*~T*/

/*~E:A5*/
/*~A:6*/
/*~+:Funktionsdeklarationen*/
/*~T*/
extern void 			Weight(void);
extern char				Weight_GetEModulCompensationOnOff(void);
extern void 			Weight_GetMotionParameter(MEASUREMENT_MOTIONPARAMETER *pMotionParameter);

extern unsigned char 	Weight_Ini(unsigned char byMode);
extern char 			Weight_IsMotion(void);
extern char 			Weight_SetCalibrationFactor(float fCalibrationFactor);
extern char 			Weight_SetCalibrationRegardingActualWeight(float fRatedValue);
extern void 			Weight_SetEModulCompensationOn(bit bOnOff);
extern char				Weight_SetMotionParameter(MEASUREMENT_MOTIONPARAMETER MotionParameter,bit bStore);

extern char 			Weight_SetTareValue(float fTare2Set,bit bStore);
extern char 			Weight_SetZero(long lZero2Set);
extern char 			Weight_SetZeroRegardingActualWeight(void);
/*~E:A6*/
/*~A:7*/
/*~+:Variablen*/
/*~T*/
extern MEASUREMENT_VALUE Weight_MeasurementFromADC;
extern MEASUREMENT_VALUE Weight_FilteredMeasurement;
extern MEASUREMENT_VALUE Weight_CorrectedMeasurement;
extern MEASUREMENT_VALUE Weight_ZeroCorrectedMeasurement;
extern MEASUREMENT_VALUE Weight_ZeroCorrectedMeasurementStandardized;
extern MEASUREMENT_VALUE Weight_ZeroCorrectedMeasurementWithTare;
extern MEASUREMENT_VALUE Weight_GrossWeight;
extern MEASUREMENT_VALUE Weight_TareWeight;
extern MEASUREMENT_VALUE Weight_NetWeight;

extern long g_Weight_lSimulatedRMW;

/*~E:A7*/
/*~-1*/
#endif
/*~E:I1*/
