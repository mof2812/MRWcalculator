/*~-1*/
/*~XSF_LANGUAGE: C/C++*/
/*~K*/
/*~+:File :        Limit.c*/
/*~+:*/
/*~+:Version :     V1.0*/
/*~+:*/
/*~+:Date :        08.06.2005*/
/*~+:*/
/*~+:Time :        10:23*/
/*~+:*/
/*~+:Author :      MOF*/
/*~+:*/
/*~+:Hardware :*/
/*~+:*/
/*~+:Description :*/
/*~+:*/
/*~+:*/
/*~A:1*/
/*~+:Includes*/
/*~T*/
#include "Global.h"
#include "Limit.h"
#include <Math.h>
#include <stdio.h>
#include <stdlib.h>
/*~E:A1*/
/*~A:2*/
/*~+:Funktionseigene Definitionen*/
/*~T*/
// Konfiguration
#define LIMIT_TEACH_LIMIT
/*~I:3*/
#ifndef LIMIT_TEACH_LIMIT 
/*~T*/
#define LIMIT_TEACH_20MA
/*~-1*/
#endif
/*~E:I3*/
/*~K*/
/*~+:*/
/*~T*/
#define LIMIT_LOWERLIMIT			2.5		///< unterer Grenzwert f�r die Stromschnittstelle bei 2.5mA

/*~I:4*/
#ifdef LIMIT_TEACH_LIMIT
/*~T*/
#define LIMIT_UPPERLIMIT			21.6	///< oberer Grenzwert f�r die Stromschnittstelle bei 21.6mA
/*~O:I4*/
/*~-1*/
#else
/*~I:5*/
#ifdef LIMIT_TEACH_20MA
/*~T*/
#define LIMIT_UPPERLIMIT			20	///< oberer Grenzwert f�r die Stromschnittstelle bei 20mA
/*~-1*/
#endif
/*~E:I5*/
/*~-1*/
#endif
/*~E:I4*/
/*~E:A2*/
/*~A:6*/
/*~+:Funktionseigene Struktur-Definitionen*/
/*~T*/

/*~E:A6*/
/*~A:7*/
/*~+:Funktionsprototypen*/
/*~T*/
void 			Limit(void);
void 			Limit_ClearLimitState(unsigned char chLimitState2Clear);
void 			Limit_EnableAlarmLimits(bit bOnOff);
float 			Limit_GetAlarmLimit(unsigned char byWhichLimit);
unsigned char 	Limit_GetLimitCheckFlag(void);
unsigned char 	Limit_GetLimitState(void);
void 			Limit_Init(unsigned char byMode);
char 			Limit_SetAlarmLimits(void);
char 			Limit_SetAlarmLimitByWeight(unsigned char byActualWeight,float fWeight);
void 			Limit_SetLimitCheckFlag(unsigned char byFlag2Set);
void 			Limit_SetLimitState(unsigned char LimitState2Set);
char 			Limit_TeachTara(void);

/*~E:A7*/
/*~A:8*/
/*~+:Globale Variablen*/
/*~T*/
LIMIT g_Limit;
/*~E:A8*/
/*~A:9*/
/*~+:void 			Limit(void)*/
/*~F:10*/
void Limit(void)
/*~-1*/
{
   /*~A:11*/
   /*~+:Variablendeklarationen*/
   /*~T*/
   float fCalibrationFactor;
   static unsigned char byCounter;
   /*~E:A11*/
   /*~A:12*/
   /*~+:Variableninitialisierungen*/
   /*~T*/
   fCalibrationFactor = ADuC836_DACGetGain(0) * ADuC836_DACGetGain(1);
   /*~E:A12*/
   /*~I:13*/
   if (fabs(Weight_NetWeight.fFloat) > g_Limit.fLimitZeroPointCheck)
   /*~-1*/
   {
      /*~T*/
      g_Limit.chLimitState |= LIMIT_TARALIMIT_EXCEEDED;
   /*~-1*/
   }
   /*~O:I13*/
   /*~-2*/
   else
   {
      /*~T*/
      g_Limit.chLimitState &= 0xFD;
   /*~-1*/
   }
   /*~E:I13*/
   /*~K*/
   /*~+:// �berpr�fung der Grenzwertfunktionen*/
   /*~C:14*/
   switch (Limit_GetLimitCheckFlag())
   /*~-1*/
   {
      /*~F:15*/
      case 0x55:
      /*~-1*/
      {
         /*~T*/
         Limit_SetLimitCheckFlag(0xA5);

         g_lWeightOffset4Limitest = -Weight_ZeroCorrectedMeasurementWithTare.nLong;

         byCounter = 0;

         CurrentInterface_LoadDACSettings(CURRENTINTERFACE_RMW_1ST_REFPOINT);
         CurrentInterface_LoadDACSettings(CURRENTINTERFACE_RMW_2ND_REFPOINT);


         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F15*/
      /*~F:16*/
      case 0xA5:
      /*~-1*/
      {
         /*~T*/
         g_lWeightOffset4Limitest -= (long)((g_CurrentInterface.lRMWForCalibration[1] - g_CurrentInterface.lRMWForCalibration[0])/320); 
         /*~I:17*/
         if (byCounter++ > 50)
         /*~-1*/
         {
            /*~T*/
            // Strom ist sicher bis unter 2.5mA gelaufen
            Limit_SetLimitCheckFlag(0x00);
         /*~-1*/
         }
         /*~E:I17*/
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F16*/
      /*~F:18*/
      case 0xAA:
      /*~-1*/
      {
         /*~T*/
         Limit_SetLimitCheckFlag(0x5A);

         byCounter = 0;

         g_lWeightOffset4Limitest = (long)(16 / fCalibrationFactor) - Weight_ZeroCorrectedMeasurementWithTare.nLong;
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F18*/
      /*~F:19*/
      case 0x5A:
      /*~-1*/
      {
         /*~T*/
         g_lWeightOffset4Limitest += (long)((g_CurrentInterface.lRMWForCalibration[1] - g_CurrentInterface.lRMWForCalibration[0])/320); 
         /*~I:20*/
         if (byCounter++ > 50)
         /*~-1*/
         {
            /*~T*/
            // Strom ist sicher bis �ber 21.6mA gelaufen
            Limit_SetLimitCheckFlag(0x00);
         /*~-1*/
         }
         /*~E:I20*/
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F19*/
      /*~O:C14*/
      /*~-2*/
      default:
      {
         /*~T*/
         g_lWeightOffset4Limitest = 0;
      /*~-1*/
      }
   /*~-1*/
   }
   /*~E:C14*/
/*~-1*/
}
/*~E:F10*/
/*~E:A9*/
/*~A:21*/
/*~+:void 			Limit_ClearLimitState(unsigned char chLimitState2Clear)*/
/*~F:22*/
void Limit_ClearLimitState(unsigned char chLimitState2Clear)
/*~-1*/
{
   /*~T*/
   g_Limit.chLimitState &= (0xFF - chLimitState2Clear); 
/*~-1*/
}
/*~E:F22*/
/*~E:A21*/
/*~A:23*/
/*~+:void 			Limit_EnableAlarmLimits(bit bOnOff)*/
/*~F:24*/
void Limit_EnableAlarmLimits(bit bOnOff)
/*~-1*/
{
   /*~A:25*/
   /*~+:Beschreibung*/
   /*~T*/
   /*!
   \fn void Limit_EnableAlarmLimits(bit bOnOff)
   
   <b>Beschreibung:</b><br>
   Aktivieren/Deaktivieren der Reaktion auf Grenzwert�berschreitungen.
   
   \param
   bOnOff: 0 deaktiviert die Grenzwertbeachtung, 1 schaltet sie frei.
   
   <b>Zugriff:</b><br>
   [X] �ffentlich / [ ] Privat
   
   \ref
   */
   /*~E:A25*/
   /*~A:26*/
   /*~+:Variablendeklarationen*/
   /*~T*/
   unsigned char chClearStatus;
   /*~E:A26*/
   /*~A:27*/
   /*~+:Variableninitialisierungen*/
   /*~T*/

   /*~E:A27*/
   /*~T*/
   // Unterer Grenzwert l�schen
   // ADuC836_DACEnableLimit(LIMIT_LOWERLIMIT,bOnOff);
   ADuC836_DACEnableLimit(ADUC836_DAC_LOWER_LIMIT,bOnOff);
   // Oberer Grenzwert l�schen
   // ADuC836_DACEnableLimit(LIMIT_UPPERLIMIT,bOnOff);
   ADuC836_DACEnableLimit(ADUC836_DAC_UPPER_LIMIT,bOnOff);

   chClearStatus = ADuC836_DACGetLimitState(255);
   // und speichern
   CurrentInterface_SaveDACSettings(CURRENTINTERFACE_ALL_SETTINGS);
/*~-1*/
}
/*~E:F24*/
/*~E:A23*/
/*~A:28*/
/*~+:float 			Limit_GetAlarmLimit(unsigned char byWhichLimit)*/
/*~F:29*/
float Limit_GetAlarmLimit(unsigned char byWhichLimit)
/*~-1*/
{
   /*~A:30*/
   /*~+:Variablendeklarationen*/
   /*~T*/
   float fCalFactor;
   float fLimit;
   long lAlarmLimit;
   /*~E:A30*/
   /*~A:31*/
   /*~+:Variableninitialisierungen*/
   /*~T*/


   /*~E:A31*/
   /*~T*/
   Measurement_GetCalibrationFactor(WEIGHT_WEIGHTCHANNEL,&fCalFactor);
   /*~I:32*/
   if (!byWhichLimit)
   /*~-1*/
   {
      /*~T*/
      // Unterer Grenzwert
      lAlarmLimit = ADuC836_DACGetDigital(LIMIT_LOWERLIMIT);
   /*~-1*/
   }
   /*~O:I32*/
   /*~-2*/
   else
   {
      /*~T*/
      // Oberer Grenzwert
      lAlarmLimit = ADuC836_DACGetDigital(LIMIT_UPPERLIMIT);
   /*~-1*/
   }
   /*~E:I32*/
   /*~I:33*/
#ifdef LIMIT_TEACH_20MA 
   /*~T*/
   fLimit = lAlarmLimit * fCalFactor;
   /*~O:I33*/
   /*~-1*/
#else
   /*~I:34*/
#ifdef LIMIT_TEACH_LIMIT 
   /*~T*/
   fLimit = lAlarmLimit * fCalFactor / 1.1;
   /*~-1*/
#endif
   /*~E:I34*/
   /*~-1*/
#endif
   /*~E:I33*/
   /*~T*/
   return fLimit;
/*~-1*/
}
/*~E:F29*/
/*~E:A28*/
/*~A:35*/
/*~+:unsigned char 	Limit_GetLimitCheckFlag(void)*/
/*~F:36*/
unsigned char Limit_GetLimitCheckFlag(void)
/*~-1*/
{
   /*~T*/
   return g_Limit.chLimitCheckFlag; 
/*~-1*/
}
/*~E:F36*/
/*~E:A35*/
/*~A:37*/
/*~+:unsigned char 	Limit_GetLimitState(void)*/
/*~F:38*/
unsigned char Limit_GetLimitState(void)
/*~-1*/
{
   /*~T*/
   return g_Limit.chLimitState; 
/*~-1*/
}
/*~E:F38*/
/*~E:A37*/
/*~A:39*/
/*~+:void 			Limit_Init(unsigned char byMode)*/
/*~F:40*/
void Limit_Init(unsigned char byMode)
/*~-1*/
{
   /*~C:41*/
   switch (byMode)
   /*~-1*/
   {
      /*~F:42*/
      /*#LJ:Filter_Ini=12*/
      case 0:		// Initialisierung mit Defaultwerten
      /*~-1*/
      {
         /*~T*/
         g_Limit.fLimitZeroPointCheck = LIMIT_ZERODRIFT_DETECTION;
         // speichern
         Save_Parameter(LOAD_SAVE_LIMIT_ZEROPOINTCHECK,&g_Limit.fLimitZeroPointCheck,4);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F42*/
      /*~F:43*/
      case 1:		// Initialisierung mit abgespeicherten Werten
      /*~-1*/
      {
         /*~T*/
         Load_Parameter(LOAD_SAVE_LIMIT_ZEROPOINTCHECK,&g_Limit.fLimitZeroPointCheck,4);
         /*~T*/
         break;
      /*~-1*/
      }
      /*~E:F43*/
   /*~-1*/
   }
   /*~E:C41*/
   /*~T*/
   g_Limit.chLimitCheckFlag = 0;
/*~-1*/
}
/*~E:F40*/
/*~E:A39*/
/*~A:44*/
/*~+:char 			Limit_SetAlarmLimits(void)*/
/*~F:45*/
char Limit_SetAlarmLimits(void)
/*~-1*/
{
   /*~A:46*/
   /*~+:Beschreibung*/
   /*~T*/
   /*!
   \fn char Limit_SetAlarmLimits(void)
   
   <b>Beschreibung:</b><br>
   Setzen des Alarm-Grenzwertes und der 2.5mA-Grenze.
   
   \param
   void:
   
   \return
   Status der Funktionsausf�hrung
   
   \retval
   immer 0;
   
   <b>Zugriff:</b><br>
   [X] �ffentlich / [ ] Privat
   */

   /*~E:A46*/
   /*~A:47*/
   /*~+:Variablendeklarationen*/
   /*~T*/
   long lAlarmLimitHigh;
   long lAlarmLimitLow;

   /*~E:A47*/
   /*~A:48*/
   /*~+:Variableninitialisierungen*/
   /*~T*/

   /*~E:A48*/
   /*~I:49*/
   if (!Weight_IsMotion())
   /*~-1*/
   {
      /*~T*/
      // Unterer Grenzwert
      lAlarmLimitLow = ADuC836_DACGetDigital(LIMIT_LOWERLIMIT);

      // Oberer Grenzwert
      lAlarmLimitHigh = ADuC836_DACGetDigital(LIMIT_UPPERLIMIT);

      // und setzen
      CurrentInterface_SetLimits(lAlarmLimitLow,lAlarmLimitHigh);

      /*~T*/
      return 0;
   /*~-1*/
   }
   /*~O:I49*/
   /*~-2*/
   else
   {
      /*~T*/
      // Messwert schwankt noch

      return 1;
   /*~-1*/
   }
   /*~E:I49*/
/*~-1*/
}
/*~E:F45*/
/*~E:A44*/
/*~A:50*/
/*~+:char 			Limit_SetAlarmLimitByWeight(unsigned char byActualWeight,float fWeight)*/
/*~F:51*/
char Limit_SetAlarmLimitByWeight(unsigned char byActualWeight,float fWeight)
/*~-1*/
{
   /*~A:52*/
   /*~+:Beschreibung*/
   /*~T*/
   /*!
   \fn char Limit_SetAlarmLimitByActualWeight(void)
   
   <b>Beschreibung:</b><br>
   Setzen des Alarm-Grenzwertes und der 2.5mA-Grenze in Abh�ngigkeit des aktuellen Gewichts.
   
   \param
   void:
   
   \return
   Status der Funktionsausf�hrung
   
   \retval
   immer 0;
   
   <b>Zugriff:</b><br>
   [X] �ffentlich / [ ] Privat
   */

   /*~E:A52*/
   /*~A:53*/
   /*~+:Variablendeklarationen*/
   /*~T*/
   float fCalFactor;
   /*~E:A53*/
   /*~A:54*/
   /*~+:Variableninitialisierungen*/
   /*~T*/

   /*~E:A54*/
   /*~I:55*/
   if ((!Weight_IsMotion())||(!byActualWeight))
   /*~-1*/
   {
      /*~T*/
      Measurement_GetCalibrationFactor(WEIGHT_WEIGHTCHANNEL,&fCalFactor);
      /*~T*/
      // Grenzwert abgleichen

      /*~I:56*/
#ifdef LIMIT_TEACH_20MA
      /*~I:57*/
      if (byActualWeight)
      /*~-1*/
      {
         /*~I:58*/
         if ((Weight_GrossWeight.fFloat >= 0)&&(Weight_GrossWeight.fFloat <= 1500))
         /*~-1*/
         {
            /*~T*/
            ADuC836_DACSetDigital2Value(Weight_ZeroCorrectedMeasurementWithTare.nLong,20,4);
         /*~-1*/
         }
         /*~O:I58*/
         /*~-2*/
         else
         {
            /*~T*/
            return 2;
         /*~-1*/
         }
         /*~E:I58*/
      /*~-1*/
      }
      /*~O:I57*/
      /*~-2*/
      else
      {
         /*~I:59*/
         if ((fWeight + Weight_TareWeight.fFloat>= 0)&&(fWeight + Weight_TareWeight.fFloat <= 1500))
         /*~-1*/
         {
            /*~T*/
            ADuC836_DACSetDigital2Value(fWeight / fCalFactor,20,4);
         /*~-1*/
         }
         /*~O:I59*/
         /*~-2*/
         else
         {
            /*~T*/
            return 2;
         /*~-1*/
         }
         /*~E:I59*/
      /*~-1*/
      }
      /*~E:I57*/
      /*~-1*/
#endif
      /*~E:I56*/
      /*~I:60*/
      /*#LJ:0=8*/
#ifdef LIMIT_TEACH_LIMIT
      /*~I:61*/
      if (byActualWeight)
      /*~-1*/
      {
         /*~I:62*/
         if ((Weight_GrossWeight.fFloat >= 0)&&(Weight_GrossWeight.fFloat <= 1500))
         /*~-1*/
         {
            /*~T*/
            //ADuC836_DACSetDigital2Value(Weight_ZeroCorrectedMeasurementWithTare.nLong,21.6,4);

            ADuC836_DACSetDigital2Value(Weight_ZeroCorrectedMeasurementWithTare.nLong,20,4);
         /*~-1*/
         }
         /*~O:I62*/
         /*~-2*/
         else
         {
            /*~T*/
            return 2;
         /*~-1*/
         }
         /*~E:I62*/
      /*~-1*/
      }
      /*~O:I61*/
      /*~-2*/
      else
      {
         /*~I:63*/
         if ((fWeight + Weight_TareWeight.fFloat >= 0)&&(fWeight + Weight_TareWeight.fFloat <= 1500))
         /*~-1*/
         {
            /*~T*/
            ADuC836_DACSetDigital2Value(fWeight * 1.1 / fCalFactor,21.6,4);
         /*~-1*/
         }
         /*~O:I63*/
         /*~-2*/
         else
         {
            /*~T*/
            return 2;
         /*~-1*/
         }
         /*~E:I63*/
      /*~-1*/
      }
      /*~E:I61*/
      /*~-1*/
#endif
      /*~E:I60*/
      /*~T*/
      return Limit_SetAlarmLimits();
   /*~-1*/
   }
   /*~O:I55*/
   /*~-2*/
   else
   {
      /*~T*/
      // Messwert schwankt noch

      return 1;
   /*~-1*/
   }
   /*~E:I55*/
/*~-1*/
}
/*~E:F51*/
/*~E:A50*/
/*~A:64*/
/*~+:void 			Limit_SetLimitCheckFlag(unsigned char byFlag2Set)*/
/*~F:65*/
void Limit_SetLimitCheckFlag(unsigned char byFlag2Set)
/*~-1*/
{
   /*~T*/
   g_Limit.chLimitCheckFlag = byFlag2Set;
/*~-1*/
}
/*~E:F65*/
/*~E:A64*/
/*~A:66*/
/*~+:void 			Limit_SetLimitState(unsigned char LimitState2Set)*/
/*~F:67*/
void Limit_SetLimitState(unsigned char LimitState2Set)
/*~-1*/
{
   /*~T*/
   g_Limit.chLimitState |= LimitState2Set;
/*~-1*/
}
/*~E:F67*/
/*~E:A66*/
/*~A:68*/
/*~+:char 			Limit_TeachTara(void)*/
/*~F:69*/
char Limit_TeachTara(void)
/*~-1*/
{
   /*~A:70*/
   /*~+:Variablendeklarationen*/
   /*~T*/
   float fTare;
   /*~E:A70*/
   /*~I:71*/
   if (!Weight_IsMotion())
   /*~-1*/
   {
      /*~T*/
      // Es liegt keine Messwertschwankung vor - es kann tariert werden
      /*~K*/
      /*~+:1. Stromschnittstelle auf 4mA setzen*/
      /*~+:(Implementierung vielleicht sp�ter)*/
      /*~K*/
      /*~+:2. Gewichtswert tarieren*/
      /*~I:72*/
      if (!Measurement_SetTare(WEIGHT_WEIGHTCHANNEL,&fTare))
      /*~-1*/
      {
         /*~T*/
         Save_Parameter(LOAD_SAVE_WEIGHT_TARA,&fTare,0);
         /*~T*/
         // Alles okay
         return 0;
      /*~-1*/
      }
      /*~O:I72*/
      /*~-2*/
      else
      {
         /*~T*/
         // Fehler w�hrend des Teachvorgangs

         return -1;
      /*~-1*/
      }
      /*~E:I72*/
   /*~-1*/
   }
   /*~O:I71*/
   /*~-2*/
   else
   {
      /*~T*/
      // Der Messwert schwankt noch

      return 1;
   /*~-1*/
   }
   /*~E:I71*/
/*~-1*/
}
/*~E:F69*/
/*~E:A68*/
